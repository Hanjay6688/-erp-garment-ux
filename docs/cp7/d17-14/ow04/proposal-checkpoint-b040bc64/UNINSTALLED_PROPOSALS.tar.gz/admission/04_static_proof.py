"""Source/metadata-mechanism checks only. No SQL execution, DB or installer.

Synthetic metadata below exercises rejection of changed predecessor attributes;
it is NEVER an approved Native predecessor manifest. Native release footprints
are reported by03 as a different codec from installed pg_get_functiondef.
"""
from dataclasses import replace
from hashlib import sha256
from pathlib import Path
import argparse
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('ow04_admission_static_transform', HERE/'03_native_admission_transform.py')
transform = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = transform
SPEC.loader.exec_module(transform)


def refuses(operation):
    try:
        operation()
    except ValueError:
        return
    raise AssertionError('SOURCE_ONLY_EXPECTED_REFUSAL_NOT_OBSERVED')


def body(text, identity):
    found = re.findall(r'create function '+re.escape(identity)+r'\([^$]*?as \$\$(.*?)\$\$;', text, re.S)
    assert len(found) == 1, ('SOURCE_FUNCTION_NOT_UNIQUE',identity,len(found))
    return found[0]


def ordered(text, *fragments):
    positions = [text.index(fragment) for fragment in fragments]
    assert positions == sorted(positions) and len(set(positions)) == len(positions), fragments


def run(repo):
    results = transform.static_check(repo)
    results['scope'] = 'STATIC_SOURCE_AND_SYNTHETIC_METADATA_ONLY_NOT_NATIVE'
    results['complete_feature_installation'] = 'BLOCKED_REQUIRED_OWNING_SOURCE_AND_FINANCIAL_IMPLEMENTATIONS'
    # An entirely synthetic fixture. No installed owner/ACL/hash is fabricated.
    source = 'begin\n perform synthetic_probe();\nend\n'
    definition = 'CREATE FUNCTION erp.synthetic_probe(uuid) RETURNS void AS $function$'+source+'$function$ LANGUAGE plpgsql;'
    capture = transform.Capture('erp.synthetic_probe(uuid)',definition,source,'postgres',('postgres=X/postgres',),True,'v',('search_path=""',))
    approved = transform.Approved(capture.identity,transform.digest(definition),transform.digest(source),capture.owner,capture.acl,
        capture.security_definer,capture.volatility,capture.config)
    derived,_ = transform.derive(capture,approved,lambda value:value.replace('synthetic_probe','changed_synthetic_probe'))
    assert 'changed_synthetic_probe' in derived
    changed = [replace(capture,identity='erp.another_probe(uuid)'),replace(capture,definition=definition+'\n'),
        replace(capture,body=source+'\n'),replace(capture,owner='another_owner'),replace(capture,acl=()),
        replace(capture,security_definer=False),replace(capture,volatility='s'),replace(capture,config=())]
    for candidate in changed:
        refuses(lambda candidate=candidate:transform.derive(candidate,approved,lambda value:value))
    results['synthetic_metadata_changed_attribute_refusals'] = len(changed)
    contexts = ('erp.synthetic_execution_context','cp7_example.synthetic_context')
    generated = transform.derive_no_ambient_context(contexts,contexts)
    assert 'backend_pid=pg_backend_pid() and c.transaction_id=txid_current()' in generated
    assert 'owner to postgres' in generated and 'revoke all' in generated
    for candidate,expected in [((),()),(contexts,contexts[::-1]),(contexts+contexts,contexts+contexts),
        (('erp.bad_context;drop table unsafe',),('erp.bad_context;drop table unsafe',))]:
        refuses(lambda candidate=candidate,expected=expected:transform.derive_no_ambient_context(candidate,expected))
    results['synthetic_context_manifest_refusals'] = 4

    typed = (HERE/'01_typed_context_and_preclaim.proposal.sql').read_text()
    wrapper = (HERE/'02_owning_wrapper.proposal.sql').read_text()
    for text in (typed,wrapper):
        assert text.index("raise exception 'OW04_") < text.index('create ')
        assert re.search(r'create\s+function\s+public\.',text,re.I) is None
        assert re.search(r'create\s+or\s+replace\s+function\s+erp\.require_internal',text,re.I) is None
    pending = body(typed,'cp7_sales.preclaim_credit_return')
    ordered(pending,"cp7_credit.assert_pending_return_outer(","insert into cp7_sales.requests",
        "for update;","CP7_CREDIT_ACCESS_CHANGED_AFTER_REQUEST_WAIT","CP7_CREDIT_STANDALONE_INNER_RECEIPT_REFUSED")
    outer = body(wrapper,'cp7_credit.return_settlement_command')
    ordered(outer,'a:=cp7_credit.return_command_access(mode);','insert into cp7_credit.return_requests',
        'for update;','CP7_CREDIT_ACCESS_CHANGED_AFTER_REQUEST_WAIT','if r.response is not null then',
        'insert into cp7_credit.return_command_scope','cp7_sales.preclaim_credit_return(',
        "pg_advisory_xact_lock(hashtextextended('FG_HPP_SALES_V2620C'",'CP7_CREDIT_ACCESS_CHANGED_AFTER_FG_WAIT',
        'cp7_credit.seal_return_settlement(','cp7_sales.execute_preclaimed_credit_return(',
        'cp7_credit.finish_return_settlement(',"s.stage<>'COMPLETE'",'delete from cp7_credit.return_command_scope',
        'update cp7_credit.return_requests set response=result')
    bridge = body(wrapper,'cp7_sales.execute_preclaimed_credit_return')
    ordered(bridge,'cp7_credit.assert_locked_return_outer(',"cp7_sales.command_access('RETURN')",'for update;',
        'r.response is not null',"cp7_sales.command('RETURN',p_legacy,p_request,p_expected)")
    assert re.findall(r'cp7_sales\.command\(([^,]+)',bridge) == ["'RETURN'"]
    assert 'alter function cp7_sales.execute_preclaimed_credit_return(uuid,jsonb,text)owner to cp7_sales_write;' in wrapper
    # Intentional holes remain executable blockers. Never register these as
    # successful no-op source/closure implementations just to compile a bundle.
    callbacks = ('assert_no_ambient_native_context','seal_return_settlement','assert_sealed_return_source',
        'finish_return_settlement','assert_completed_return_receipt')
    for name in callbacks:
        assert 'cp7_credit.'+name+'(' in typed+wrapper
        assert 'create function cp7_credit.'+name+'(' not in typed+wrapper
    results['wrapper_source_order_only'] = 'PASS'
    results['required_missing_source_callbacks'] = list(callbacks)
    results['required_missing_Native_hooks'] = ['native_return_enter','native_return_guard','native_return_complete',
        'native_return_leave','native_source_enter','native_source_complete','current_effective_paid']
    results['private_inverse_composition'] = 'BLOCKED_REQUIRES_EXACT_SIX_NOTE_PLUS_FOUR_RETURN_COPIES'
    results['sql_executed'] = False
    results['sql_compiled'] = False
    results['installed_metadata_captured'] = False
    results['Native_auth_cash_browser_or_provider_executed'] = False
    results['proposal_sha256'] = {p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.iterdir())
        if p.is_file() and p.name in ('EXPECTED.json','01_typed_context_and_preclaim.proposal.sql',
            '02_owning_wrapper.proposal.sql','03_native_admission_transform.py','04_static_proof.py','README.md','FIRST_STATIC_FAILURE.json')}
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo',type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.repo.resolve()),indent=2))
