# OW04 parent wiring proposal — outside the active repository

The primary artifact is `ui-parent-integration.patch`, based on the exact source
snapshot in `BASE_MANIFEST.json` at commit
`9b323f135074a56cf652aab7b0dd3990b3e1b3bf`. It changes four existing files and adds
one parent integration test. `PATCH_MANIFEST.json` pins every resulting file and
both patch artifacts. No active repository file was edited by this task.

The four adopted contract/section files already present in the root writer's
working tree match this isolated mirror byte-for-byte. They are prerequisites,
not redundant additions in the primary patch. The separate
`ui-parent-prerequisites.patch` is only for a clean source checkout without those
files. **Do not apply it over the root's existing copies.** Their logic is the
settled parser53/section31 proposal; only import paths were adapted.

The primary patch passes `git apply --check` against the actual root working
tree. Both patches were also applied to an outside original-source copy and all
nine resulting files matched the tested mirror exactly. These checks did not
apply anything to the active repository.

## Wiring

- `SalesReturnPanel.tsx` keeps the existing allocation, receiver, grade, quantity,
  return amount, notes and explicitly blank physical time. Connected new returns
  normalize user line amounts to exact two-place cent strings and quote every
  complete draft. Mode and accounts start blank. No browser calculation selects
  credit/refund amount, book dates or recognition components.
- The optional `settlement` prop enables the new section. Its absence preserves
  the standalone original RETURN caller. Original reverse and correction paths
  remain. An enabled form cannot dispatch old RETURN through Enter/native form
  submission. Missing, refused, unknown or unsupported quote results do not fall
  back to the old command. Empty/null settlement also uses the fixed wrapper.
- Every relevant parent edit advances generation. Explicit account-row
  re-selection advances it even when the typed UUID remains equal. The section's
  own review event is stopped at its wrapper so it does not immediately retire
  its own final review. The section receives the actual current owning return
  read ticket, validator, authority scope and global stale/lock/pending flags.
- Both quote and ACCOUNT_OPTIONS call the fixed
  `erp_cp7_get_sales_return_settlement_quote_v1({p_query})`; options remain paged25
  and explicitly selected. These names/arguments match coordinator09 and the
  Native12 packet; they are not calls to a generic arbitrary RPC dispatcher.
- `ConnectedSalesPage.tsx` routes only `RETURN_SETTLEMENT` to
  `erp_cp7_settle_sales_return_v1({p_payload,p_request,p_expected})`. It forwards
  the exact `{document,expected_version}` recovery payload without rebuilding the
  plan or replacing the UUID. The outcome parser uses the frozen document and
  full quote SHA, so reload/replay requires no in-memory quote. Current source
  refusals close the new form and retire the parent source facts.
- `productionRecovery.ts` adds one **frontend** SALES action. The shared
  `useProductionMutation.ts`, storage version/fingerprint, Web Lock, uncertain
  replay policy and hooks are unchanged. No legacy SQL action/context enum is
  extended. Public function argument declarations are added to the existing
  client database type file.

The existing mutation hook owns persistence before dispatch, UUID allocation,
replay, current-session/source checks and result handling. Only a validated
committed receipt retires the form; all writers remain locked if the subsequent
authoritative reload fails. A lost, malformed or replay-refused response keeps
the same pending intent. Opening/remounting a new form does not clear that
global pending state.

## Atomic reader prerequisite

This wiring assumes the **same atomic installation** includes the reviewed
`readers/03_reader_transforms.py` changes. In that reader, the legacy wire field
`financial.paid_total` supplies effective settlement E=P+U−I and open balance is
net−E. The invoice header label therefore becomes **Pelunasan efektif invoice**.
The browser does not derive E from old raw payment totals or invent extra
header fields. Raw payment history continues to show P1000 while the refreshed
example invoice shows E800 and AR0. The new quote section separately displays
server P/U/I/E/AR.

Installing only this frontend while keeping the old reader would display the
wrong meaning after paid returns. Reader transformations, complete locked
source/coordinator/ledger/refund callbacks, Native admission/closure and current
rights guards remain root-owned integration requirements. No database/RPC was
called to qualify them here.

## Captured verification

The unchanged isolated source passed the four retained suites (73 tests) and
the entire app TypeScript check before implementation. The final packet passes
seven suites, **167 tests**: retained73 + parser53 + section31 + parent10. Complete
stdout/footer, stderr and actual exit codes are saved in the result/log files.
The entire isolated app's final strict TypeScript check also exits0.

The ten new parent cases exercise the actual `ConnectedSalesPage`,
`SalesReturnPanel`, section and shared mutation hook with declared SDK response
stand-ins. They cover CREDIT and REFUND fixed routing, E800/AR0 versus raw P1000,
explicit physical time and form-submit bypass refusal, EMPTY/null settlement,
same-UUID account recheck, latest draft input retirement, lost reply/remount/
permission-refused replay with identical envelope, wrong-quote receipt,
authoritative reload failure, and current403 source retirement. They do not
mock the parent, section or recovery hook.

One additional same-batch input/submit sequence was investigated before adding
any production guard. It **passed** against the existing implementation: no old
intent was emitted. Its expected record and output are retained as a passing
control, not a first-red claim; no speculative generation-ref redesign was made.

Earlier setup failures remain visible: the first isolated baseline lacked two
unchanged raw SQL test imports (copied before the successful baseline); the
first new test file used a combined `vi.hoisted` declaration rejected by Vitest
(split without changing behavior). Initial packaging stopped on already-present
root prerequisites before producing a patch, followed by a premature missing-
patch check; the final artifacts/checks are separate and successful. None of
these was recorded as a Native/product failure or silently removed.

To reproduce the local tests in the saved mirror:

```sh
cd /workspace/scratch/9442228ed2dc/ow04-proposals/ui-parent/worktree
node /workspace/scratch/9442228ed2dc/erp-d1714/node_modules/vitest/vitest.mjs run --config vitest.parent.config.mjs --reporter verbose
node /workspace/scratch/9442228ed2dc/erp-d1714/node_modules/typescript/bin/tsc --noEmit -p tsconfig.app.json
```

The final React best-practices review kept the existing independent source reads
parallel, retained stable reset callbacks and functional generation updates,
used render-time current-context fencing, kept all section buttons explicit
`type="button"`, and reused versioned recovery storage without a new cache or
request engine. No broad styling/performance refactor was introduced.

This packet establishes local frontend wiring and preservation of its selected
regressions. It does not establish actual public endpoint installation, Native
money/stock/cash correctness, browser behavior, full credit workspace/use/
refund/undo/correction integration, or OW04 completion.
