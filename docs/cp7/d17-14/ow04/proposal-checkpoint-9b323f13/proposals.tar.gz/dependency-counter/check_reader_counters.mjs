// Isolated actual SQL branch/hash mechanics. Never a Native feature claim.
import {readFile,writeFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const dir=dirname(fileURLToPath(import.meta.url)),parent=dirname(dir);
const {PGlite}=await import(process.env.PGLITE_MODULE??'/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js');
const callerTimezone=process.env.READER_COUNTER_TIMEZONE??'UTC';
let actualCoreConfig;
const sha=s=>createHash('sha256').update(s).digest('hex');
const paths=['readers/01_current_reader_capability.proposal.sql','coordinator/05_factual_profile.sql',
 'coordinator/06_finish_and_closed_routes.sql','ledger/01_immutable_facts.proposal.sql',
 'ledger/02_uuid_poster.proposal.sql','refund/01_initial_refund.proposal.sql'];
const texts=Object.fromEntries(await Promise.all(paths.map(async p=>[p,await readFile(resolve(parent,p),'utf8')])));
const pins=Object.fromEntries(paths.map(p=>[p,sha(texts[p])]));
const expectedText=await readFile(resolve(dir,'EXPECTED.json'),'utf8'),expected=JSON.parse(expectedText);
const frozen=await readFile(resolve(dir,'frozen_current_effective_paid_06.sql'),'utf8');
function extract(source,name){
 const re=new RegExp('create(?: or replace)? function '+name.replaceAll('.','\\.')+'\\(' ,'g');
 const matches=[...source.matchAll(re)];assert(matches.length,`missing ${name}`);
 const start=matches.at(-1).index,body=source.indexOf('$$',start),end=source.indexOf('$$;',body+2);
 assert(body>=start&&end>body);return source.slice(start,end+3);
}
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
async function branches(finalFunction){
 const db=new PGlite();try{
  await db.query("select set_config('TimeZone',$1,false)",[callerTimezone]);
  await db.exec(`create schema erp;create schema cp7_credit;create schema cp7_note;
create table erp.sales_headers(id uuid primary key,customer_id uuid,status text);
create table erp.sales_payments(id uuid primary key,sale_id uuid,amount numeric,status text);
create table cp7_note.revisions(root_sale_id uuid,previous_sale_id uuid,replacement_sale_id uuid,revision bigint);
create table erp.journal_entries(id uuid primary key,source_type text,source_id uuid);
create table erp.journal_lines(id uuid primary key,journal_entry_id uuid,customer_id uuid);
create table cp7_credit.return_families(id uuid primary key,family_root_sale_id uuid);
create table cp7_credit.cohorts(id uuid primary key,family_id uuid);
create table cp7_credit.recognition_plans(id uuid primary key,cohort_id uuid);
create table cp7_credit.recognition_components(id uuid primary key,plan_id uuid);
create table cp7_credit.component_parts(id uuid primary key,component_id uuid,amount numeric);
create table cp7_credit.component_journals(journal_id uuid,part_id uuid);
create table cp7_credit.consumption_events(id uuid primary key,journal_id uuid,cohort_id uuid,event_kind text,target_sale_id uuid,amount numeric);`);
  for(const n of['cp7_credit.current_leaf_assignment','cp7_credit.assert_current_materialized_profile','erp._cp7_current_credit_adjustment'])
   await db.exec(extract(texts[paths[0]],n));
  await db.exec(finalFunction);
  actualCoreConfig=(await db.query("select proconfig from pg_proc where oid='erp._cp7_current_credit_adjustment(uuid)'::regprocedure")).rows[0].proconfig;
  await db.query("insert into erp.sales_headers values($1,$2,'PAID')",[id(1),id(10)]);
  await db.query("insert into erp.sales_payments values($1,$2,700,'POSTED')",[id(2),id(1)]);
  const invoke=async n=>{try{return{value:(await db.query(`select ${n}($1::uuid) value`,[id(1)])).rows[0].value};}
   catch(e){return{refusal:e.message,code:e.code};}};
  const cases=[],capture=async name=>cases.push({case:name,final:await invoke('cp7_credit.current_effective_paid'),core:await invoke('erp._cp7_current_credit_adjustment')});
  await capture('CLEAN_LEGACY');
  await db.query("insert into erp.journal_entries values($1,'CP7_CUSTOMER_CREDIT_RECOGNITION',$2)",[id(3),id(4)]);
  await db.query('insert into erp.journal_lines values($1,$2,$3)',[id(5),id(3),id(99)]);
  await capture('GLOBAL_ORPHAN_OTHER_CUSTOMER');
  await db.exec('truncate erp.journal_entries,erp.journal_lines;');
  await db.query("insert into erp.journal_entries values($1,'CP7_CUSTOMER_CREDIT_REFUND',$2)",[id(3),id(4)]);
  await db.query('insert into erp.journal_lines values($1,$2,$3)',[id(5),id(3),id(10)]);
  await db.query('insert into cp7_credit.return_families values($1,$2)',[id(8),id(90)]);
  await db.query('insert into cp7_credit.cohorts values($1,$2)',[id(9),id(8)]);
  await db.query("insert into cp7_credit.consumption_events values($1,$2,$3,'REFUND',null,200)",[id(6),id(3),id(9)]);
  await capture('RETAINED_REFUND_WRONG_SOURCE_ID');
  await db.exec('truncate erp.journal_entries,erp.journal_lines,cp7_credit.return_families,cp7_credit.cohorts,cp7_credit.consumption_events;');
  await db.query("insert into erp.sales_headers values($1,$2,'REVERSED')",[id(7),id(10)]);
  await db.query('insert into cp7_note.revisions values($1,$1,$2,1)',[id(7),id(1)]);
  await db.query('insert into cp7_credit.return_families values($1,$2)',[id(8),id(7)]);
  await capture('CURRENT_LEAF_WITH_EMPTY_ROOT_FAMILY');return cases;
 }finally{await db.close();}
}
async function refundOrder(){
 const db=new PGlite();try{
  await db.exec(`create schema erp;create schema cp7_credit;create schema counter;
create table cp7_credit.initial_refund_operations(id uuid primary key,cohort_id uuid,full_amount numeric,physical_at timestamptz,cash_account_snapshot jsonb);
create table cp7_credit.cohorts(id uuid primary key,credit_account_id uuid,customer_id uuid);
create table erp.journal_entries(id uuid primary key,source_type text,source_id uuid,status text,reversal_of_id uuid,economic_date date,transaction_date date);
create table erp.journal_lines(id uuid primary key,journal_entry_id uuid,account_id uuid,customer_id uuid,description text,debit numeric,credit numeric,vendor_id uuid,contractor_id uuid,po_id uuid,product_id uuid);`);
  for(const[file,names]of[[paths[3],['pg_jsonb_sha256','native_journal_cent_max']],
   [paths[4],['native_cent_lines','native_lines_sha256']],[paths[5],['initial_refund_lines','verify_initial_refund_journal']]])
   for(const n of names)await db.exec(extract(texts[file],`cp7_credit.${n}`));
  const liability='ffffffff-ffff-ffff-ffff-ffffffffffff',cash=id(1),customer=id(2),op=id(3),cohort=id(4),journal=id(5);
  await db.query('insert into cp7_credit.cohorts values($1,$2,$3)',[cohort,liability,customer]);
  await db.query("insert into cp7_credit.initial_refund_operations values($1,$2,200,'2026-10-19T05:00:00Z',$3::jsonb)",
   [op,cohort,JSON.stringify({account:{id:cash}})]);
  await db.query("insert into erp.journal_entries values($1,'CP7_CUSTOMER_CREDIT_REFUND',$2,'POSTED',null,'2026-10-19','2026-10-20')",[journal,op]);
  for(const[n,a,d,c]of[[6,liability,200,0],[7,cash,0,200]])await db.query(
   "insert into erp.journal_lines(id,journal_entry_id,account_id,customer_id,description,debit,credit)values($1,$2,$3,$4,'Kredit retur: pengembalian uang',$5,$6)",[id(n),journal,a,customer,d,c]);
  const stored=(await db.query("select cp7_credit.verify_initial_refund_journal($1,$2,'2026-10-20') value",[op,journal])).rows[0].value;
  const liabilityFirst=(await db.query('select cp7_credit.native_lines_sha256(cp7_credit.initial_refund_lines($1,$2,$3,200)) value',[liability,cash,customer])).rows[0].value;
  assert.notEqual(liabilityFirst,stored,'first-red digest order must actually differ');
  const profile=texts[paths[1]],start=profile.indexOf('  expected_lines:=cp7_credit.initial_refund_lines('),end=profile.indexOf("raise exception 'CP7_CREDIT_REFUND_ACTUAL_LINES_CHANGED';end if;",start);
  assert(start>0&&end>start);const fragment=profile.slice(start,end+"raise exception 'CP7_CREDIT_REFUND_ACTUAL_LINES_CHANGED';end if;".length);
  await db.exec(`create function counter.actual_refund_read(p_operation uuid,p_journal uuid,p_stored_hash text)returns void language plpgsql stable as $$
declare o cp7_credit.initial_refund_operations;ch cp7_credit.cohorts;j erp.journal_entries;ce record;expected_lines jsonb;lines jsonb;
begin select *into strict o from cp7_credit.initial_refund_operations where id=p_operation;
select *into strict ch from cp7_credit.cohorts where id=o.cohort_id;select *into strict j from erp.journal_entries where id=p_journal;
select p_stored_hash as lines_sha256_pg,cp7_credit.pg_jsonb_sha256(to_jsonb(o))as source_sha256,200::numeric as amount,'2026-10-20'::date as transaction_date into ce;
${fragment}
end $$;`);
  await db.query('select counter.actual_refund_read($1,$2,$3)',[op,journal,stored]);
  return{case:'CASH_UUID_BEFORE_LIABILITY_UUID',first_red_digest:liabilityFirst,poster_stored_digest:stored,
   first_red_matches:false,repaired_actual_fragment_accepts:true,actual_fragment_sha256:sha(fragment)};
 }finally{await db.close();}
}
const before=await branches(frozen);
const first={scope:expected.scope,status:'EXPECTED_FIRST_RED',source_pins:{coordinator06:'51a2e04318f65d0fb51f04bbac9de6cf0fb1ca7783ee7c913a53c1d587ce0c3b',reader01:pins[paths[0]]},cases:before,Native_executed:false};
assert.deepEqual(before[0].final,expected.cases[0].expected_final);
for(const c of before.slice(1))assert.deepEqual(c.final,{value:'700'});
try{await writeFile(resolve(dir,'FIRST_RED_RESULT.json'),JSON.stringify(first,null,2)+'\n',{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;}
// Latest corrected definition wins in actual installation order; 06 must not reintroduce an override.
const finalSource=texts[paths[2]].includes('function cp7_credit.current_effective_paid(')?texts[paths[2]]:texts[paths[1]];
const after=await branches(extract(finalSource,'cp7_credit.current_effective_paid'));
assert.deepEqual(after[0].final,expected.cases[0].expected_final);assert.deepEqual(after[0].core,expected.cases[0].expected_core);
for(const c of after.slice(1)){
 const e=expected.cases.find(x=>x.case===c.case);assert.equal(c.final.refusal,e.expected_refusal);assert.equal(c.core.refusal,e.expected_refusal);
}
const refund=await refundOrder();
const result={scope:expected.scope,status:'PASS',count:5,cases:[...after,refund],source_sha256:pins,expected_sha256:sha(expectedText),
 caller_timezone:callerTimezone,actual_core_proconfig:actualCoreConfig,
 driver_sha256:sha(await readFile(fileURLToPath(import.meta.url),'utf8')),Native_executed:false,positive_posting_proven:false,
 actual_full_materialized_validator_executed:false,limits:expected.limits};
await writeFile(resolve(dir,'RESULT.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({scope:result.scope,status:result.status,count:result.count,Native_executed:false}));
