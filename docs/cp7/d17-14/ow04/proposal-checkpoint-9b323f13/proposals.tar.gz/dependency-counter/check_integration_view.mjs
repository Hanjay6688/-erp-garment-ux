// PostgreSQL deparser mechanics over the retained Native view source and actual
// product reader transform. No Native feature, data, role, or money execution.
import {readFile,writeFile}from'node:fs/promises';
import{execFileSync}from'node:child_process';
import{dirname,resolve}from'node:path';
import{fileURLToPath}from'node:url';
import{createHash}from'node:crypto';
import assert from'node:assert/strict';
const dir=dirname(fileURLToPath(import.meta.url));
const workspace=resolve(dir,'../..');
const repo=process.env.OW04_REPO??resolve(workspace,'erp-d1714');
const {PGlite}=await import(process.env.PGLITE_MODULE??resolve(workspace,'sql-dev/node_modules/@electric-sql/pglite/dist/index.js'));
const sha=s=>createHash('sha256').update(s).digest('hex');
const inputText=await readFile(resolve(workspace,'ow04-proposals/readers/root-transforms/DERIVATION.json'),'utf8');
const input=JSON.parse(inputText),transform=resolve(repo,'scripts/cp7_customer_credit/readers/03_reader_transforms.py');
const bundleText=await readFile(resolve(repo,'scripts/cp7_customer_credit/integration/owning_bundle.py'),'utf8');
const db=new PGlite();
try{
 await db.exec(`create schema erp;
create table erp.customers(id uuid,customer_name text);
create table erp.sales_headers(id uuid,customer_id uuid,sale_number text,sale_date timestamptz,due_date date,status text);
create table erp.sales_items(sale_id uuid,line_total numeric);
create table erp.sales_payments(sale_id uuid,amount numeric,status text);
create table erp.sales_returns(id uuid,sale_id uuid,status text);
create table erp.sales_return_items(return_id uuid,refund_amount numeric);
create function erp._cp7_receivable_credit_adjustment(uuid)returns numeric language plpgsql stable as $$
begin raise exception 'NEVER_EXECUTED_DEPARSE_ONLY';end $$;`);
 await db.exec(input.original_view);
 const capture=async()=>(await db.query("select pg_get_viewdef(c.oid,true)definition,pg_get_userbyid(c.relowner)owner,c.relacl::text[] acl,c.reloptions options from pg_class c where c.oid='erp.v_customer_receivables'::regclass")).rows[0];
 const before=await capture();
 const python="import importlib.util,sys;s=importlib.util.spec_from_file_location('r',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);sys.stdout.write(m.receivables_view(sys.stdin.read()))";
 const derived=execFileSync(process.env.PYTHON??'python',['-B','-c',python,transform],{input:before.definition,encoding:'utf8'});
 await db.exec('create or replace view erp.v_customer_receivables with(security_invoker=true)as '+derived);
 const installed=await capture();
 const diff=derived.split('\n').map((x,i)=>x===installed.definition.split('\n')[i]?null:{expected:x,actual:installed.definition.split('\n')[i]}).filter(Boolean);
 assert.equal(diff.length,1);assert(diff[0].expected.endsWith('AS credit_amount'));
 const first={scope:'ISOLATED_ACTUAL_READER_TRANSFORM_VIEW_DEPARSE_NOT_NATIVE',status:'EXPECTED_FIRST_RED',
  old_verify_compares_raw_derived:false,diff,reader_transform_sha256:sha(await readFile(transform,'utf8')),input_derivation_sha256:sha(inputText),Native_executed:false};
 try{await writeFile(resolve(dir,'FIRST_VIEW_DEPARSE_RESULT.json'),JSON.stringify(first,null,2)+'\n',{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;}
 // Same canonical contract now used by the root installer, not a looser
 // comparison or a financial acceptance stub. No helper call is executed.
 for(const k of['owner','acl','options'])assert.deepEqual(installed[k],before[k]);
 const expectedCanonical=installed.definition;
 assert.equal((await capture()).definition,expectedCanonical);
 assert(bundleText.includes("view_after=view_installed['definition'], view_derived=view_after"));
 assert(bundleText.includes("if view['definition'] != state['view_after']"));
 await db.exec('create or replace view erp.v_customer_receivables with(security_invoker=true)as '+before.definition);
 assert.deepEqual(await capture(),before);
 const result={scope:first.scope,status:'PASS',first_red_preserved:'FIRST_VIEW_DEPARSE_RESULT.json',
  installed_canonical_matches:true,raw_derived_retained:true,owner_acl_options_exact:true,original_view_restored:true,
  derived_sha256:sha(derived),canonical_sha256:sha(expectedCanonical),
  owning_bundle_sha256:sha(bundleText),reader_transform_sha256:first.reader_transform_sha256,
  driver_sha256:sha(await readFile(fileURLToPath(import.meta.url),'utf8')),Native_executed:false,
  full_installer_executed:false,financial_helper_executed:false};
 await writeFile(resolve(dir,'INTEGRATION_VIEW_RESULT.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify(result));
}finally{await db.close();}
