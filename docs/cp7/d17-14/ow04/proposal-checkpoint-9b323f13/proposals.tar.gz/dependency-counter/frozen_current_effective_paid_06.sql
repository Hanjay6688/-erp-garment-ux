-- Exact function body captured from coordinator06 before its override was removed.
-- Whole original source SHA: 51a2e04318f65d0fb51f04bbac9de6cf0fb1ca7783ee7c913a53c1d587ce0c3b.
create or replace function cp7_credit.current_effective_paid(p_sale uuid)returns numeric
language plpgsql stable security definer set search_path=''as $$
declare paid numeric;adjustment numeric;
begin
 select coalesce(sum(amount),0)into paid from erp.sales_payments where sale_id=p_sale and status='POSTED';
 if exists(select 1 from erp.journal_entries j join erp.journal_lines l on l.journal_entry_id=j.id
  join erp.sales_headers h on h.customer_id=l.customer_id and h.id=p_sale
  where j.source_type in('CP7_CUSTOMER_CREDIT_RECOGNITION','CP7_CUSTOMER_CREDIT_APPLY','CP7_CUSTOMER_CREDIT_REFUND','CP7_CUSTOMER_CREDIT_EVENT_REVERSE')
   and not exists(select 1 from cp7_credit.component_journals cj where cj.journal_id=j.id)
   and not exists(select 1 from cp7_credit.consumption_events ce where ce.journal_id=j.id))then
  raise exception 'CP7_CREDIT_UNREPRESENTED_FINANCIAL_JOURNAL';end if;
 if not exists(select 1 from cp7_credit.return_families where family_root_sale_id=p_sale)
  and not exists(select 1 from cp7_credit.consumption_events where event_kind='APPLY'and target_sale_id=p_sale)then return paid;end if;
 adjustment:=erp._cp7_current_credit_adjustment(p_sale);
 if paid+adjustment<0 then raise exception 'CP7_CREDIT_NEGATIVE_EFFECTIVE_PAID';end if;
 return paid+adjustment;
end $$;
