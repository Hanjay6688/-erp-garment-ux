// Same immutable UTC operation/hash across caller timezones. Not Native.
import {readFile,writeFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const dir=dirname(fileURLToPath(import.meta.url)),base=dirname(dir);
const {PGlite}=await import(process.env.PGLITE_MODULE??'/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js');
const sha=s=>createHash('sha256').update(s).digest('hex');
const before=process.argv.includes('--first-red');
const expectedText=await readFile(resolve(dir,'TZ_EXPECTED.json'),'utf8'),expected=JSON.parse(expectedText);
const files=['ledger/01_immutable_facts.proposal.sql','ledger/02_uuid_poster.proposal.sql',
 'refund/01_initial_refund.proposal.sql','coordinator/05_factual_profile.sql'];
const texts=Object.fromEntries(await Promise.all(files.map(async f=>[f,await readFile(resolve(base,f),'utf8')])));
function extract(s,n){const start=s.indexOf('create function '+n+'(');assert(start>=0,n);
 const body=s.indexOf('$$',start),end=s.indexOf('$$;',body+2);assert(end>body);return s.slice(start,end+3);}
const profile=extract(texts[files[3]],'cp7_credit.assert_current_source_plan_profile');
const bodyStart=profile.indexOf('$$'),headerCurrent=profile.slice(profile.indexOf('language '),bodyStart+2);
const header=before?(await readFile(resolve(dir,'FROZEN_TZ_PROFILE_HEADER.sql'),'utf8')).trim():headerCurrent;
const start=profile.indexOf('  expected_lines:=cp7_credit.initial_refund_lines(');
const endMarker="raise exception 'CP7_CREDIT_REFUND_ACTUAL_LINES_CHANGED';end if;";
const end=profile.indexOf(endMarker,start);assert(start>0&&end>start);
const fragment=profile.slice(start,end+endMarker.length);
assert.equal(sha(fragment),'27b78c7d795d5324919a3fe0c13a5a7cce8a9295e5b46ab9d7dd4e4bcba54136',
 'Keep this regression tied to the actual previously observed fragment; review changed SQL before updating its pin');
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const db=new PGlite();const cases=[];
try{
 await db.exec(`create schema erp;create schema cp7_credit;create schema counter;
create table cp7_credit.initial_refund_operations(id uuid primary key,cohort_id uuid,full_amount numeric,physical_at timestamptz,cash_account_snapshot jsonb);
create table cp7_credit.cohorts(id uuid primary key,credit_account_id uuid,customer_id uuid);
create table erp.journal_entries(id uuid primary key,source_type text,source_id uuid,status text,reversal_of_id uuid,economic_date date,transaction_date date);
create table erp.journal_lines(id uuid primary key,journal_entry_id uuid,account_id uuid,customer_id uuid,description text,debit numeric,credit numeric,vendor_id uuid,contractor_id uuid,po_id uuid,product_id uuid);
create table counter.stored_event(source_sha text,lines_sha text);`);
 for(const[f,names]of[[files[0],['pg_jsonb_sha256','native_journal_cent_max']],
  [files[1],['native_cent_lines','native_lines_sha256']],
  [files[2],['initial_refund_lines','verify_initial_refund_journal']]])
  for(const n of names)await db.exec(extract(texts[f],`cp7_credit.${n}`));
 const liability='ffffffff-ffff-ffff-ffff-ffffffffffff',cash=id(1),customer=id(2),op=id(3),cohort=id(4),journal=id(5);
 await db.exec("set TimeZone='UTC'");
 await db.query('insert into cp7_credit.cohorts values($1,$2,$3)',[cohort,liability,customer]);
 await db.query("insert into cp7_credit.initial_refund_operations values($1,$2,200,'2026-10-19T05:00:00Z',$3::jsonb)",
  [op,cohort,JSON.stringify({account:{id:cash}})]);
 await db.query("insert into erp.journal_entries values($1,'CP7_CUSTOMER_CREDIT_REFUND',$2,'POSTED',null,'2026-10-19','2026-10-20')",[journal,op]);
 for(const[n,a,d,c]of[[6,liability,200,0],[7,cash,0,200]])await db.query(
  "insert into erp.journal_lines(id,journal_entry_id,account_id,customer_id,description,debit,credit)values($1,$2,$3,$4,'Kredit retur: pengembalian uang',$5,$6)",[id(n),journal,a,customer,d,c]);
 await db.query("insert into counter.stored_event select cp7_credit.pg_jsonb_sha256(to_jsonb(o)),cp7_credit.verify_initial_refund_journal(o.id,$2,'2026-10-20')from cp7_credit.initial_refund_operations o where id=$1",[op,journal]);
 await db.exec(`create function counter.actual_profile_refund(p_operation uuid,p_journal uuid)returns void ${header}
declare o cp7_credit.initial_refund_operations;ch cp7_credit.cohorts;j erp.journal_entries;ce record;expected_lines jsonb;lines jsonb;
begin select *into strict o from cp7_credit.initial_refund_operations where id=p_operation;
select *into strict ch from cp7_credit.cohorts where id=o.cohort_id;select *into strict j from erp.journal_entries where id=p_journal;
select e.lines_sha as lines_sha256_pg,e.source_sha as source_sha256,200::numeric as amount,'2026-10-20'::date as transaction_date into ce from counter.stored_event e;
${fragment}
end $$;`);
 for(const zone of expected.cases){
  await db.query("select set_config('TimeZone',$1,false)",[zone]);
  let refusal=null;try{await db.query('select counter.actual_profile_refund($1,$2)',[op,journal]);}catch(e){refusal=e.message;}
  cases.push({caller_timezone:zone,observed:refusal??'ACCEPT'});
 }
 const sourcePins=Object.fromEntries(files.map(f=>[f,sha(texts[f])]));
 const result={scope:expected.scope,status:before?'EXPECTED_FIRST_RED':'PASS',cases,
  source_sha256:sourcePins,actual_fragment_sha256:sha(fragment),actual_header:header,
  expected_sha256:sha(expectedText),driver_sha256:sha(await readFile(fileURLToPath(import.meta.url),'utf8')),
  first_red_whole_profile_source_sha256:'c674a4fd9bfa2f35a83799bf5c8fd477cf2af85ca3f0f6815e6864f8d515bb67',
  Native_executed:false,full_callback_executed:false,limits:expected.limits};
 if(before){for(const c of cases)assert.equal(c.observed,expected.first_red[c.caller_timezone]);
  try{await writeFile(resolve(dir,'FIRST_TZ_RED_RESULT.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;}
 }else{for(const c of cases)assert.equal(c.observed,'ACCEPT');
  await writeFile(resolve(dir,'TZ_RESULT.json'),JSON.stringify(result,null,2)+'\n');}
 console.log(JSON.stringify({scope:result.scope,status:result.status,cases,Native_executed:false}));
}finally{await db.close();}
