# Independent ordinal expectation controls

EXPECTED.json was frozen before writing ordinal_oracle.py. SHA256:
5a47a026f386f9fb66570260731ddff6480d6674db2049cca029effcd0e475db.

```bash
python /workspace/scratch/9442228ed2dc/ow04-proposals/ordinal-tests/ordinal_oracle.py
```

The15 literal synthetic controls pass330 independent Decimal/scalar-rectangle
checks. RESULT.json is a standalone arithmetic/model result only. No SQL kernel,
Native command, source collector, account choice, journal poster or database
registration guard was executed. This proposal edits nothing in the product.

Immutable family registration must include initially empty recognition plans.
Funding/return corrections recompute every affected family's target, and append
exact-pair differences against retained signed recognition; they cannot remove
original recognition rows or deregister a family. Cohort capacity cannot borrow
from another cohort sharing the customer/account.

Two important authority controls are separated from arithmetic acceptance:
ORD11 has a family inverse booked before its original, producing a negative
family rectangle while aggregate overflow remains nonnegative. ORD15 has
pre-return funding above recognized gross. Both remain valid arithmetic inputs
to the pure kernel; the source authority must refuse them. The ordinal telescope
is SUM(T_i)=F_all-F_base. Equating it to F_all additionally requires the authority
to establish F_base=0 on every rectangle.

After independent lock, the other reviewer countered all15 without a numerical
conflict. Its separately frozen8 controls add a later consumer inverse which
cannot repair an intervening deficit, a four-atom joint-capacity example where
both marginal balances exceed the spendable joint balance, and correction-root
source date floors. Keep those complementary controls; the15 here do not replace
them or prove Native completeness/authorization.
