-- SOURCE-ONLY OW04 PROPOSAL. No installer, authority API, or Native proof.
do $not_an_installer$begin
 raise exception 'OW04_SOURCE_PROPOSAL_REQUIRES_COMPLETE_OWNING_INTEGRATION';
end $not_an_installer$;
create schema ow04_source_proposal authorization postgres;
revoke all on schema ow04_source_proposal from public,anon,authenticated,service_role;

create function ow04_source_proposal.sha(p jsonb)returns text
language sql immutable strict security invoker set search_path=''as $$
 select encode(pg_catalog.sha256(convert_to(p::text,'UTF8')),'hex')
$$;
create function ow04_source_proposal.cents(p numeric)returns text
language plpgsql immutable strict security invoker set search_path=''as $$
begin
 if p::text in('NaN','Infinity','-Infinity')or p*100<>trunc(p*100)then
  raise exception 'OW04_SOURCE_EXACT_CENTS_REQUIRED';end if;
 return(case when p<0 then'-'else''end)||trunc(abs(p))::text||'.'||
  lpad(trunc((abs(p)-trunc(abs(p)))*100)::text,2,'0');
end $$;

-- Actual immutable monetary payload, separate from mutable POSTED->REVERSED.
-- Native journal_entries has no updated clock; status is its changing fact.
create function ow04_source_proposal.journal_payload(p_journal uuid)returns jsonb
language sql volatile security invoker set search_path=''as $$
 select jsonb_build_object('journal',to_jsonb(j)-'status','lines',
  coalesce((select jsonb_agg(to_jsonb(l)order by l.id)from erp.journal_lines l where l.journal_entry_id=j.id),'[]'))
 from erp.journal_entries j where j.id=p_journal
$$;
create function ow04_source_proposal.line_vector(p_journal uuid,p_flip boolean)returns jsonb
language sql volatile security invoker set search_path=''as $$
 select coalesce(jsonb_agg(x.v order by x.v::text collate"C"),'[]')from(
  select jsonb_build_object('account_id',l.account_id,'customer_id',l.customer_id,'vendor_id',l.vendor_id,
   'contractor_id',l.contractor_id,'po_id',l.po_id,'product_id',l.product_id,
   'debit',ow04_source_proposal.cents(case when p_flip then l.credit else l.debit end),
   'credit',ow04_source_proposal.cents(case when p_flip then l.debit else l.credit end))v
  from erp.journal_lines l where l.journal_entry_id=p_journal)x
$$;

-- Resolve the real linear note revision graph. IDs sorted for locks only,
-- NEVER used as historical return ordinals. A detached/forked chain refuses.
create function ow04_source_proposal.sale_family(p_sale uuid)returns jsonb
language plpgsql volatile security invoker set search_path=''as $$
declare root uuid;roots uuid[];sales uuid[];r record;previous uuid;n bigint:=0;customer uuid;revisions jsonb;
begin
 select array_agg(distinct x.root_sale_id)into roots from cp7_note.revisions x
  where p_sale in(x.root_sale_id,x.previous_sale_id,x.replacement_sale_id);
 if cardinality(roots)>1 then raise exception 'OW04_SOURCE_NOTE_FAMILY_AMBIGUOUS';end if;
 root:=coalesce(roots[1],p_sale);previous:=root;sales:=array[root];
 for r in select *from cp7_note.revisions where root_sale_id=root order by revision loop
  n:=n+1;
  if r.revision<>n or r.previous_sale_id<>previous or r.replacement_sale_id=any(sales)then
   raise exception 'OW04_SOURCE_NOTE_CHAIN_INVALID';end if;
  sales:=sales||r.replacement_sale_id;previous:=r.replacement_sale_id;
 end loop;
 if not p_sale=any(sales)or exists(select 1 from unnest(sales)x left join erp.sales_headers h on h.id=x where h.id is null)then
  raise exception 'OW04_SOURCE_SALE_NOT_FOUND';end if;
 select customer_id into strict customer from erp.sales_headers where id=root;
 if customer is null or exists(select 1 from erp.sales_headers where id=any(sales)and customer_id is distinct from customer)then
  raise exception 'OW04_SOURCE_NOTE_CUSTOMER_CHANGED';end if;
 select coalesce(jsonb_agg(to_jsonb(x)order by x.revision),'[]')into revisions from cp7_note.revisions x where x.root_sale_id=root;
 return jsonb_build_object('root_sale_id',root,'current_leaf_id',previous,'sale_ids',to_jsonb(sales),
  'customer_id',customer,'note_revisions',revisions);
end $$;

-- One actual financial journal has one base document owner. Capture all Native
-- reversal descendants and both recorded neutral/effective restatement rows.
create function ow04_source_proposal.journal_scope(p_sales uuid[],p_returns uuid[],p_payments uuid[])
returns table(journal_id uuid,origin_journal_id uuid,document_kind text,document_id uuid,role text)
language sql volatile security invoker set search_path=''as $$
 with recursive originals as materialized(
  select j.id,'SALE'::text kind,j.source_id doc from erp.journal_entries j
   where j.source_type='SALE'and j.source_id=any(p_sales)and j.reversal_of_id is null
  union all select j.id,'RETURN',j.source_id from erp.journal_entries j
   where j.source_type='SALES_RETURN'and j.source_id=any(p_returns)and j.reversal_of_id is null
  union all select j.id,'PAYMENT',j.source_id from erp.journal_entries j
   where j.source_type='SALES_PAYMENT'and j.source_id=any(p_payments)and j.reversal_of_id is null
 ),restatements as materialized(
  select x.source_journal_id original,x.inverse_journal_id inverse,x.neutral_journal_id neutral,
   x.effective_journal_id effective,'NOTE'::text owner from cp7_note.journal_restatements x where x.previous_sale_id=any(p_sales)
  union all select x.source_journal_id,x.inverse_journal_id,x.neutral_journal_id,x.effective_journal_id,'RETURN'
   from cp7_sales_return_correction.journal_restatements x where x.original_return_id=any(p_returns)
  union all select f.original_journal_entry_id,r.reversal_journal_entry_id,x.time_neutral_id,x.effective_inverse_id,'PAYMENT'
   from cp7_payment_correction.links x join erp.sales_payment_posting_facts f on f.payment_id=x.original_id
   join erp.sales_payment_reversal_facts r on r.payment_id=x.original_id
   where x.original_id=any(p_payments)and x.time_neutral_id is not null
 ),walk(jid,origin,kind,doc,role)as(
  select id,id,kind,doc,'ORIGINAL'::text from originals
  union
  select child.id,w.origin,w.kind,w.doc,
   case when child.source_type='JOURNAL_REVERSAL'then'INVERSE'
    when child.id=x.neutral then x.owner||'_NEUTRAL'else x.owner||'_EFFECTIVE'end
   from walk w join erp.journal_entries child on child.reversal_of_id=w.jid
    or(child.source_type='JOURNAL_REVERSAL'and child.source_id=w.jid)
    or exists(select 1 from restatements rr where rr.original=w.jid and child.id in(rr.neutral,rr.effective))
   left join restatements x on x.original=w.jid and child.id in(x.neutral,x.effective)
 )select jid,origin,kind,doc,role from walk
$$;

create function ow04_source_proposal.locked_source_family(p_sale uuid)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare family jsonb;check_family jsonb;sales uuid[];returns uuid[];payments uuid[];locked_payments uuid[];
 customer uuid;root uuid;doc record;j record;f erp.sales_payment_posting_facts;rf erp.sales_payment_reversal_facts;
 original erp.journal_entries;candidate uuid;ar uuid;accounts uuid[]:='{}';ar_delta numeric;amount numeric;n bigint;
 documents jsonb:='[]';journals jsonb:='[]';events jsonb:='[]';bindings jsonb:='[]';blockers jsonb:='[]';
 snapshot jsonb;payload jsonb;lineage jsonb;registration jsonb:='[]';members jsonb:='[]';proof jsonb;stock_state jsonb;
 jf jsonb;state jsonb;vectors jsonb;source_hash text;unknown_returns uuid[];financial_state text;src_type text;
 inverse_id uuid;expected_type text;expected_source uuid;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'OW04_SOURCE_READ_COMMITTED_REQUIRED';end if;
 if p_sale is null then raise exception 'OW04_SOURCE_SALE_REQUIRED';end if;
 -- Owning writers must all take this FIRST. No new permission/context is minted.
 perform pg_advisory_xact_lock(hashtextextended('FG_HPP_SALES_V2620C',0));
 family:=ow04_source_proposal.sale_family(p_sale);
 select array_agg(value::uuid)into sales from jsonb_array_elements_text(family->'sale_ids');
 root:=(family->>'root_sale_id')::uuid;customer:=(family->>'customer_id')::uuid;
 select coalesce(array_agg(id order by id),'{}')into payments from erp.sales_payments where sale_id=any(sales);
 select coalesce(array_agg(id order by id),'{}')into returns from erp.sales_returns where sale_id=any(sales);
 -- External reallocation predecessor is provenance only, not this invoice's P.
 with recursive predecessors(id)as(
  select unnest(payments)union select p.replaces_payment_id from predecessors x join erp.sales_payments p on p.id=x.id where p.replaces_payment_id is not null
 )select coalesce(array_agg(id order by id),'{}')into locked_payments from predecessors;
 perform 1 from erp.sales_payments where id=any(locked_payments)order by id for share;
 perform 1 from erp.sales_returns where id=any(returns)order by id for share;
 perform 1 from erp.sales_headers where id=any(sales)order by id for share;
 -- Re-read after waits. Never discover and lock an earlier-order new row here.
 check_family:=ow04_source_proposal.sale_family(p_sale);
 if check_family is distinct from family or payments is distinct from
  (select coalesce(array_agg(id order by id),'{}')from erp.sales_payments where sale_id=any(sales))
  or returns is distinct from(select coalesce(array_agg(id order by id),'{}')from erp.sales_returns where sale_id=any(sales))then
  raise exception 'OW04_SOURCE_LOCK_SET_CHANGED';end if;
 perform 1 from erp.sales_items where sale_id=any(sales)order by id for share;
 perform 1 from erp.sales_return_items where return_id=any(returns)order by id for share;
 perform 1 from erp.sales_payment_posting_facts where payment_id=any(locked_payments)order by payment_id for share;
 perform 1 from erp.sales_payment_reversal_facts where payment_id=any(locked_payments)order by payment_id for share;
 perform 1 from erp.initial_import_prepayment_payments where payment_id=any(locked_payments)order by payment_id for share;
 perform 1 from erp.initial_import_prepayments where id in(select advance_id from erp.initial_import_prepayment_payments where payment_id=any(locked_payments))order by id for share;
 perform 1 from cp7_note.revisions where root_sale_id=root order by revision for share;
 perform 1 from cp7_note.payment_replays where previous_payment_id=any(payments)or replacement_payment_id=any(payments)order by previous_payment_id for share;
 perform 1 from cp7_sales_return_correction.links where original_id=any(returns)or replacement_id=any(returns)order by original_id for share;
 perform 1 from cp7_payment_correction.links where original_id=any(payments)or replacement_id=any(payments)order by original_id for share;
 perform 1 from cp7_note.journal_restatements where previous_sale_id=any(sales)order by source_journal_id for share;
 perform 1 from cp7_sales_return_correction.journal_restatements where original_return_id=any(returns)order by source_journal_id for share;
 perform 1 from erp.customers where id=customer for share;
 lock table erp.accounting_account_mappings in share mode;
 perform 1 from erp.journal_entries where id in(select journal_id from ow04_source_proposal.journal_scope(sales,returns,payments))order by id for share;
 perform 1 from erp.journal_lines where journal_entry_id in(select journal_id from ow04_source_proposal.journal_scope(sales,returns,payments))order by id for share;
 perform 1 from erp.chart_accounts where id in(select l.account_id from erp.journal_lines l
  where l.journal_entry_id in(select journal_id from ow04_source_proposal.journal_scope(sales,returns,payments)))order by id for share;

 -- Actual base document proof. No created/physical/UUID ordering is interpreted
 -- as an immutable family posting ordinal. DRAFT rows are dependencies only.
 for doc in
  select 'SALE'::text kind,h.id,h.id sale_id,h.status,h.customer_id,
   round(coalesce((select sum(i.line_total)from erp.sales_items i where i.sale_id=h.id),0),2)amount,to_jsonb(h)row
   from erp.sales_headers h where h.id=any(sales)
  union all select 'RETURN',r.id,r.sale_id,r.status,r.customer_id,
   round(coalesce((select sum(i.refund_amount)from erp.sales_return_items i where i.return_id=r.id),0),2),to_jsonb(r)
   from erp.sales_returns r where r.id=any(returns)
  union all select 'PAYMENT',p.id,p.sale_id,p.status,customer,round(p.amount,2),to_jsonb(p)
   from erp.sales_payments p where p.id=any(payments)
 loop
  if doc.customer_id is distinct from customer then raise exception 'OW04_SOURCE_CUSTOMER_MISMATCH';end if;
  perform ow04_source_proposal.cents(doc.amount);
  if doc.amount<0 then raise exception 'OW04_SOURCE_NEGATIVE_BASE_DOCUMENT';end if;
  src_type:=case doc.kind when'RETURN'then'SALES_RETURN'when'PAYMENT'then'SALES_PAYMENT'else'SALE'end;
  select count(*),(array_agg(id order by id))[1]into n,candidate from erp.journal_entries where source_type=src_type and source_id=doc.id and reversal_of_id is null;
  if n>1 then raise exception 'OW04_SOURCE_MULTIPLE_BASE_JOURNALS';end if;
  if doc.status='DRAFT'then
   if n<>0 then raise exception 'OW04_SOURCE_DRAFT_HAS_FINANCIAL_JOURNAL';end if;
   financial_state:='DRAFT';
  elsif doc.status not in('POSTED','PARTIAL_PAID','PAID','REVERSED')then raise exception 'OW04_SOURCE_DOCUMENT_STATUS_UNSUPPORTED';
  elsif n=0 then
   if doc.amount<>0 or doc.kind='PAYMENT'then raise exception 'OW04_SOURCE_MONETARY_JOURNAL_MISSING';end if;
   financial_state:='NO_JOURNAL';
  else
   financial_state:='JOURNAL';select *into strict original from erp.journal_entries where id=candidate;
   if original.status is distinct from(case when doc.status='REVERSED'then'REVERSED'else'POSTED'end)then
    raise exception 'OW04_SOURCE_DOCUMENT_JOURNAL_STATUS_MISMATCH';end if;
   if doc.amount<>0 then
    -- Native base AR line has no HPP product/PO dimensions. HPP and revenue
    -- ALSO carry customer_id, so a customer-only sum would be corrupt.
    select count(*),(array_agg(l.account_id order by l.id))[1]into n,ar from erp.journal_lines l
     where l.journal_entry_id=candidate and l.customer_id=customer
      and l.vendor_id is null and l.contractor_id is null and l.po_id is null and l.product_id is null
      and l.debit-l.credit=case doc.kind when'SALE'then doc.amount else-doc.amount end
      and(case when doc.kind='SALE'then l.credit=0 else l.debit=0 end);
    if n<>1 then raise exception 'OW04_SOURCE_AR_LINE_AMBIGUOUS';end if;
    if not ar=any(accounts)then accounts:=accounts||ar;end if;
   end if;
  end if;
  stock_state:=null;
  snapshot:=jsonb_build_object('kind',doc.kind,'document',doc.row-array['status','row_version','updated_at'],
   'items',case doc.kind when'SALE'then(select coalesce(jsonb_agg(to_jsonb(i)order by i.id),'[]')from erp.sales_items i where i.sale_id=doc.id)
    when'RETURN'then(select coalesce(jsonb_agg(to_jsonb(i)order by i.id),'[]')from erp.sales_return_items i where i.return_id=doc.id)else'[]'::jsonb end);
  if doc.kind='RETURN'then
   proof:=(select coalesce(jsonb_agg(to_jsonb(m)-'book_order'order by m.id),'[]')from erp.fg_stock_movements m
    where exists(select 1 from erp.sales_return_items i where i.return_id=doc.id and i.id=m.source_id and m.source_type='SALES_RETURN_ITEM')
     or exists(select 1 from erp.fg_stock_movements o join erp.sales_return_items i on i.id=o.source_id and i.return_id=doc.id
      where o.source_type='SALES_RETURN_ITEM'and m.reversal_of_id=o.id));
   stock_state:=proof;
   snapshot:=snapshot||jsonb_build_object('actual_original_fg_movements',
    (select coalesce(jsonb_agg(x order by x->>'id'),'[]')from jsonb_array_elements(proof)x where x->>'reversal_of_id'is null));
   if financial_state='NO_JOURNAL'and(
    not exists(select 1 from erp.sales_return_items where return_id=doc.id)
    or exists(select 1 from erp.sales_return_items i where i.return_id=doc.id and(i.qty_pcs<=0 or i.refund_amount<>0
     or(select count(*)from erp.fg_stock_movements m where m.source_type='SALES_RETURN_ITEM'and m.source_id=i.id
      and m.movement_type='SALE_RETURN'and m.reversal_of_id is null and m.product_id=i.product_id
      and m.lot_id is not distinct from i.lot_id and m.location_id=i.location_id and m.quality_grade=i.quality_grade
      and m.qty_signed=i.qty_pcs and m.physical_at=(doc.row->>'physical_at')::timestamptz
      and m.unit_hpp_snapshot=0)<>1)))then raise exception 'OW04_SOURCE_NO_JOURNAL_PROOF_UNSUPPORTED';end if;
  end if;
  if doc.kind='PAYMENT'and financial_state='JOURNAL'then
   select *into strict f from erp.sales_payment_posting_facts where payment_id=doc.id;
   if f.payment_snapshot is distinct from doc.row-'status'or f.sale_id<>doc.sale_id or f.customer_id<>customer
    or f.amount<>doc.amount or f.original_journal_entry_id<>candidate
    or(f.journal_economic_date,f.journal_transaction_date,f.journal_posting_at)is distinct from
     (original.economic_date,original.transaction_date,original.posting_at)
    or f.lineage_sha256 is distinct from ow04_source_proposal.sha(jsonb_build_array(f.payment_id,f.sale_id,f.customer_id,
     f.payment_number,f.payment_date,f.amount,f.cash_account_id,f.original_journal_entry_id,f.journal_economic_date,
     f.journal_transaction_date,f.journal_posting_at,f.replaces_payment_id,f.predecessor_reversal_journal_id,f.payment_snapshot))then
    raise exception 'OW04_SOURCE_PAYMENT_FACT_INVALID';end if;
   select *into rf from erp.sales_payment_reversal_facts where payment_id=doc.id;
   if(doc.status='REVERSED')<>(rf.payment_id is not null)then raise exception 'OW04_SOURCE_PAYMENT_REVERSAL_FACT_MISSING';end if;
   if rf.payment_id is not null and not exists(select 1 from erp.journal_entries q where q.id=rf.reversal_journal_entry_id
    and q.source_type='JOURNAL_REVERSAL'and q.source_id=candidate and q.reversal_of_id=candidate and q.status='POSTED'
    and(q.economic_date,q.transaction_date,q.posting_at)=(rf.reversal_economic_date,rf.reversal_transaction_date,rf.reversal_posting_at)
    and rf.original_journal_entry_id=candidate and rf.lineage_sha256=ow04_source_proposal.sha(jsonb_build_array(
     rf.payment_id,rf.original_journal_entry_id,rf.reversal_journal_entry_id,rf.reversal_economic_date,rf.reversal_transaction_date,rf.reversal_posting_at)))then
    raise exception 'OW04_SOURCE_PAYMENT_REVERSAL_FACT_INVALID';end if;
   snapshot:=snapshot||jsonb_build_object('posting_fact',to_jsonb(f),
    'funding_channel',case when exists(select 1 from erp.initial_import_prepayment_payments where payment_id=doc.id)then'ADVANCE_NATIVE_PAYMENT'else'CASH_NATIVE_PAYMENT'end,
    'advance', (select jsonb_build_object('link',to_jsonb(l),'wallet',to_jsonb(a))from erp.initial_import_prepayment_payments l
     join erp.initial_import_prepayments a on a.id=l.advance_id where l.payment_id=doc.id));
  end if;
  documents:=documents||jsonb_build_array(jsonb_build_object('kind',doc.kind,'id',doc.id,'sale_id',doc.sale_id,
   'status',doc.status,'current_document_state',doc.row,'current_stock_lineage',stock_state,
   'current_reversal_fact',case when doc.kind='PAYMENT'and rf.payment_id is not null then to_jsonb(rf)end,
   'amount',ow04_source_proposal.cents(doc.amount),'financial_state',financial_state,
   'original_journal_id',candidate,'source',snapshot,'source_sha256',ow04_source_proposal.sha(snapshot)));
 end loop;
 if cardinality(accounts)>1 then raise exception 'OW04_SOURCE_MIXED_AR_ACCOUNTS';end if;
 ar:=accounts[1];
 if ar is not null and not exists(select 1 from erp.accounting_account_mappings m join erp.chart_accounts a on a.id=m.account_id
  where m.mapping_key='AR_CUSTOMER'and m.account_id=ar and a.account_type='ASSET'and a.normal_balance='DEBIT')then
  blockers:=blockers||jsonb_build_array(jsonb_build_object('code','AR_MAPPING_OR_ACCOUNT_CHANGED','actual_ar_account_id',ar));end if;
 if exists(select 1 from ow04_source_proposal.journal_scope(sales,returns,payments)group by journal_id having count(*)<>1)then
  raise exception 'OW04_SOURCE_JOURNAL_OWNER_AMBIGUOUS';end if;
 for j in select s.*,q.*from ow04_source_proposal.journal_scope(sales,returns,payments)s join erp.journal_entries q on q.id=s.journal_id order by q.id loop
  if j.status not in('POSTED','REVERSED')or j.transaction_date<j.economic_date then raise exception 'OW04_SOURCE_JOURNAL_STATE_OR_PAIR_INVALID';end if;
  if exists(select 1 from erp.journal_lines l where l.journal_entry_id=j.id and(l.debit<0 or l.credit<0
   or l.debit::text in('NaN','Infinity','-Infinity')or l.credit::text in('NaN','Infinity','-Infinity')))
   or not exists(select 1 from erp.journal_lines l where l.journal_entry_id=j.id group by l.journal_entry_id
    having sum(l.debit)=sum(l.credit)and sum(l.debit)>0)then raise exception 'OW04_SOURCE_JOURNAL_LINES_INVALID';end if;
  if j.role='INVERSE'and not exists(select 1 from erp.journal_entries o where o.id=j.reversal_of_id and o.id=j.source_id
   and j.source_type='JOURNAL_REVERSAL'and o.status='REVERSED'and j.economic_date>=o.economic_date and j.transaction_date>=o.transaction_date)then
   blockers:=blockers||jsonb_build_array(jsonb_build_object('code','INVERSE_SOURCE_FLOOR_OR_LINK_INVALID','journal_id',j.id));end if;
  if j.role='INVERSE'and ow04_source_proposal.line_vector(j.id,false)is distinct from ow04_source_proposal.line_vector(j.reversal_of_id,true)then
   raise exception 'OW04_SOURCE_INVERSE_LINES_CHANGED';end if;
  if j.role like'%_NEUTRAL'or j.role like'%_EFFECTIVE'then
   inverse_id:=null;
   if j.role like'NOTE_%'then select x.inverse_journal_id into strict inverse_id from cp7_note.journal_restatements x where x.source_journal_id=j.origin_journal_id;
   elsif j.role like'RETURN_%'then select x.inverse_journal_id into strict inverse_id from cp7_sales_return_correction.journal_restatements x where x.source_journal_id=j.origin_journal_id;
   else select r.reversal_journal_entry_id into strict inverse_id from erp.sales_payment_reversal_facts r where r.original_journal_entry_id=j.origin_journal_id;end if;
   expected_type:=case j.role when'NOTE_NEUTRAL'then'NOTE_REVERSAL_TIME_NEUTRAL'when'NOTE_EFFECTIVE'then'NOTE_REVERSAL_EFFECTIVE'
    when'RETURN_NEUTRAL'then'RETURN_CORRECTION_TIME_NEUTRAL'when'RETURN_EFFECTIVE'then'RETURN_CORRECTION_EFFECTIVE'
    when'PAYMENT_NEUTRAL'then'PAYMENT_CORRECTION_TIME_NEUTRAL'else'PAYMENT_CORRECTION_EFFECTIVE'end;
   expected_source:=case when j.role like'PAYMENT_%'then j.document_id else inverse_id end;
   if inverse_id is null or j.source_type<>expected_type or j.source_id is distinct from expected_source
    or ow04_source_proposal.line_vector(j.id,false)is distinct from ow04_source_proposal.line_vector(inverse_id,j.role like'%_NEUTRAL')then
    raise exception 'OW04_SOURCE_RESTATEMENT_LINES_OR_LINK_INVALID';end if;
   if j.role like'%_NEUTRAL'and(j.economic_date,j.transaction_date)is distinct from
    (select(q.economic_date,q.transaction_date)from erp.journal_entries q where q.id=inverse_id)then
    raise exception 'OW04_SOURCE_NEUTRAL_PAIR_CHANGED';end if;
   if j.role like'%_EFFECTIVE'and j.economic_date is distinct from(select economic_date from erp.journal_entries where id=j.origin_journal_id)then
    raise exception 'OW04_SOURCE_EFFECTIVE_ECONOMIC_DATE_CHANGED';end if;
  end if;
  if j.role like'%_EFFECTIVE'and j.transaction_date<(select transaction_date from erp.journal_entries where id=j.origin_journal_id)then
   blockers:=blockers||jsonb_build_array(jsonb_build_object('code','RESTATEMENT_PRECEDES_ORIGINAL_BOOK','journal_id',j.id));end if;
  payload:=ow04_source_proposal.journal_payload(j.id);
  select coalesce(sum(l.debit-l.credit),0)into ar_delta from erp.journal_lines l where l.journal_entry_id=j.id and l.account_id=ar;
  if exists(select 1 from erp.journal_lines l where l.journal_entry_id=j.id and l.account_id=ar and l.customer_id is distinct from customer)then raise exception 'OW04_SOURCE_AR_CUSTOMER_CHANGED';end if;
  amount:=case when j.document_kind='PAYMENT'then-ar_delta else ar_delta end;
  snapshot:=(select x->'source'from jsonb_array_elements(documents)x where x->>'kind'=j.document_kind and(x->>'id')::uuid=j.document_id);
  source_hash:=ow04_source_proposal.sha(jsonb_build_object('payload',payload,'base_source',snapshot,'origin_journal_id',j.origin_journal_id,'role',j.role));
  events:=events||jsonb_build_array(jsonb_build_object('id','journal:'||j.id::text,'kind',case when j.document_kind='PAYMENT'then'FUNDING'else'NET'end,
   'amount',ow04_source_proposal.cents(amount),'economic_date',j.economic_date::text,'transaction_date',j.transaction_date::text,'source_sha256',source_hash));
  bindings:=bindings||jsonb_build_array(jsonb_build_object('id','journal:'||j.id::text,'document_kind',j.document_kind,'document_id',j.document_id,
   'origin_journal_id',j.origin_journal_id,'role',j.role,'ar_account_id',ar));
  journals:=journals||jsonb_build_array(jsonb_build_object('id',j.id,'status',j.status,'payload',payload,'source_sha256',source_hash));
 end loop;
 select coalesce(jsonb_agg(x order by x->>'id'collate"C"),'[]')into events from jsonb_array_elements(events)x;
 -- No authority/default/fake historical ordinal is supplied by this reader.
 if to_regclass('cp7_credit.return_families')is not null and to_regclass('cp7_credit.return_family_members')is not null then
  execute 'select coalesce(jsonb_agg(to_jsonb(f)order by f.family_ordinal),''[]'')from cp7_credit.return_families f where f.family_root_sale_id=$1'into registration using root;
  execute 'select coalesce(jsonb_agg(to_jsonb(m)order by m.return_id),''[]'')from cp7_credit.return_family_members m where m.return_id=any($1)'into members using returns;
 end if;
 select coalesce(array_agg(r.id order by r.id),'{}')into unknown_returns from erp.sales_returns r where r.id=any(returns)and r.status<>'DRAFT'
  and not exists(select 1 from jsonb_array_elements(members)m where(m->>'return_id')::uuid=r.id);
 if cardinality(unknown_returns)>0 then blockers:=blockers||jsonb_build_array(jsonb_build_object('code','IMMUTABLE_RETURN_FAMILY_OR_ORDER_MISSING','return_ids',unknown_returns));end if;
 if jsonb_array_length(family->'note_revisions')>0 and cardinality(unknown_returns)>0 then blockers:=blockers||jsonb_build_array(jsonb_build_object('code','NOTE_RETURN_REPLAY_HEADER_LINK_UNPROVEN'));end if;
 lineage:=jsonb_build_object('note_revisions',family->'note_revisions',
  'note_restatements',(select coalesce(jsonb_agg(to_jsonb(x)order by x.source_journal_id),'[]')from cp7_note.journal_restatements x where x.previous_sale_id=any(sales)),
  'payment_replays',(select coalesce(jsonb_agg(to_jsonb(x)order by x.previous_payment_id),'[]')from cp7_note.payment_replays x where x.previous_payment_id=any(payments)or x.replacement_payment_id=any(payments)),
  'return_corrections',(select coalesce(jsonb_agg(to_jsonb(x)order by x.original_id),'[]')from cp7_sales_return_correction.links x where x.original_id=any(returns)or x.replacement_id=any(returns)),
  'return_restatements',(select coalesce(jsonb_agg(to_jsonb(x)order by x.source_journal_id),'[]')from cp7_sales_return_correction.journal_restatements x where x.original_return_id=any(returns)),
  'payment_corrections',(select coalesce(jsonb_agg(to_jsonb(x)order by x.original_id),'[]')from cp7_payment_correction.links x where x.original_id=any(payments)or x.replacement_id=any(payments)),
  'family_registration',registration,'family_members',members);
 state:=jsonb_build_object('family',family,'documents',documents,'journals',journals,'lineage',lineage,
  'customer',(select to_jsonb(c)from erp.customers c where c.id=customer),
  'ar_account',(select to_jsonb(a)from erp.chart_accounts a where a.id=ar),
  'ar_mapping',(select to_jsonb(m)from erp.accounting_account_mappings m where m.mapping_key='AR_CUSTOMER'),
  'source_lock_ids',jsonb_build_object('sales',sales,'returns',returns,'payments',locked_payments));
 return state||jsonb_build_object('contract_version','ow04.actual-base-source-family.v1','source_status',case when jsonb_array_length(blockers)=0 then'BASE_COLLECTED'else'BLOCKED'end,
  'blockers',blockers,'events',events,'event_bindings',bindings,'events_sha256',ow04_source_proposal.sha(events),
  'state_sha256',ow04_source_proposal.sha(state),'raw_funding_basis','ALL_NATIVE_PAYMENT_AR_JOURNALS_INCLUDING_ADVANCES_ONCE_NO_U_DUPLICATION',
  'scope','ACTUAL_EXISTING_BASE_JOURNALS_ONLY_NO_PROJECTION_AUTHORITY_OR_COHORT_RECONCILIATION');
end $$;

-- Read after locked_source_family has acquired source locks BEFORE period
-- SHARE. This function discovers no new locks and confers no write authority.
-- A replacement not yet linked must use the owning sealed projection binding
-- from its ACTUAL original return; it may not masquerade as an ordinary return.
create function ow04_source_proposal.return_causal_book_floor(p_return uuid)returns date
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare r erp.sales_returns;family jsonb;sales uuid[];related uuid[];root uuid;members jsonb:='[]';registered_root uuid;floor date;
begin
 select *into strict r from erp.sales_returns where id=p_return;
 family:=ow04_source_proposal.sale_family(r.sale_id);root:=(family->>'root_sale_id')::uuid;
 select array_agg(value::uuid)into sales from jsonb_array_elements_text(family->'sale_ids');
 with recursive predecessors(id)as(select p_return union select l.original_id from predecessors p
  join cp7_sales_return_correction.links l on l.replacement_id=p.id)
 select array_agg(id)into related from predecessors;
 if to_regclass('cp7_credit.return_family_members')is not null then
  execute 'select coalesce(jsonb_agg(to_jsonb(m)),''[]'')from cp7_credit.return_family_members m where m.family_id=(select family_id from cp7_credit.return_family_members where return_id=$1)'into members using p_return;
  if jsonb_array_length(members)>0 then select array_agg((x->>'return_id')::uuid)into related from jsonb_array_elements(members)x;end if;
 end if;
 if jsonb_array_length(family->'note_revisions')>0 and jsonb_array_length(members)=0 then
  raise exception 'OW04_SOURCE_NOTE_RETURN_FAMILY_UNPROVEN';end if;
 if exists(select 1 from cp7_sales_return_correction.context c where c.sale_id=r.sale_id and c.return_id<>p_return
  and c.backend_pid=pg_backend_pid()and c.transaction_id=txid_current())and jsonb_array_length(members)=0 then
  raise exception 'OW04_SOURCE_PROJECTION_FAMILY_BINDING_REQUIRED';end if;
 select max(j.transaction_date)into floor from erp.journal_entries j where j.reversal_of_id is null and j.status in('POSTED','REVERSED')
  and(j.source_type='SALE'and j.source_id=any(sales)or j.source_type='SALES_RETURN'and j.source_id=any(related));
 if floor is null then raise exception 'OW04_SOURCE_NO_DATED_CAUSAL_JOURNAL';end if;
 return floor;
end $$;
revoke all on all functions in schema ow04_source_proposal from public,anon,authenticated,service_role,
 cp7_capture,cp7_sales_read,cp7_sales_write;
