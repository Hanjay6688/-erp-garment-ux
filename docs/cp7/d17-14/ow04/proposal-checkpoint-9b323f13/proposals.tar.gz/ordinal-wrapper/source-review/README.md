# Independent actual-SQL boundary counters

`EXPECTED.json` declares 15 literal outcomes before executing the captured source
proposal. `source-reviewed.sql` preserves the exact initial source SHA
`0c3888366f89aabd85af0432b6d0e815c923cddb3d3ee9d1769febfa4be683e4`.
The executable harness loads those actual collector functions into a new PGlite
database using the other reviewer's selected Native table DDL and explicit
synthetic rows/registration tables. It removes only the proposal's deliberate
not-an-installer exception for this isolated execution.

This is source SQL boundary evidence. It is not Native posting, complete Native
schema/constraint behavior, actor/permission authority, or financial feature
acceptance. The fixture contains direct synthetic data mutations; no product or
hosted database is touched.

The initial run compiled and completed all 15 controls: eight matched the
declared boundary and seven reproduced acceptance holes. The first counter is
preserved in `FIRST_BOUNDARY_COUNTER.json`; the full result is
`INITIAL_BOUNDARY_RESULT.json`. No harness failure occurred.

| Required boundary | Observed initial collector |
| --- | --- |
| A reversed SALE requires its actual inverse | `BASE_COLLECTED`, retains NET1000 without inverse |
| A reversed RETURN requires its actual inverse | `BASE_COLLECTED`, retains NET-200 without inverse |
| Base AR total equals its document amount | SALE1000 plus extra balanced DrAR100/CrRevenue100 emits NET1100 |
| SALE economic date equals its Native source day | Changed journal day accepted |
| RETURN economic date equals its physical source day | Changed journal day accepted |
| Return membership belongs to this root registration | A member in another root family suppresses UNKNOWN |
| Member original journal matches the actual RETURN | Member pointing at the SALE journal suppresses UNKNOWN |

The wrong-root fixture includes another root's actual first-return registration
and member, then assigns this root's return to that family. The observed gap is
the missing root/membership proof; an orphan-only registry is not necessary.

The positive controls retain customer-bearing HPP lines while extracting only
AR, accept a proper original/inverse pair, retain ordinary draft dependencies,
and block a legacy unregistered return. Missing monetary originals and duplicate
originals correctly refuse. Thus this review does not classify all legacy or
all original-journal handling as broken.

Run the preserved initial snapshot:

```sh
node /workspace/scratch/9442228ed2dc/ow04-proposals/ordinal-wrapper/source-review/check_source_boundary.mjs
```

To evaluate a repaired source without overwriting initial source/results:

```sh
OW04_SOURCE_RECHECK_PATH=/workspace/scratch/9442228ed2dc/ow04-proposals/source/source.sql \
OW04_SOURCE_RECHECK_OUTPUT=REPAIRED_BOUNDARY_RESULT.json \
node /workspace/scratch/9442228ed2dc/ow04-proposals/ordinal-wrapper/source-review/check_source_boundary.mjs
```

A revised collector may require a richer real registration proof than this
synthetic table supplies. Such a fixture mismatch must be repaired and labeled;
it must not be counted as a passing business refusal or a Native failure. The
harness treats unexpected SQL/schema errors as harness failures.

The initial source-level assessment was sent before reading peer conclusions.
The ledger reviewer independently executed the four original counter classes;
this harness then reproduced those and their RETURN/member-journal variants
against the same source hash. Repairs and further proof remain with the source
writer and root integrator.

## Repaired source recheck

`REPAIRED_BOUNDARY_RESULT.json` records source SHA
`60726c8b96a16af731f10539c5f4186faa37c1c4e187897272f55c307921da15`.
All seven original unsafe acceptances now refuse: missing inverse history,
aggregate base AR mismatch, original source economic-day mismatch, wrong root
membership, and member financial-source mismatch. The frozen initial source,
expected values and first counter remain unchanged.

The raw recheck has 14 matches and one positive-fixture mismatch. The initial
fixture named `valid_registered_return` supplies the old minimal synthetic
member shape, without the newly required `financial_state`, and now refuses
with `OW04_SOURCE_RETURN_MEMBER_FINANCIAL_SOURCE_MISMATCH`. It is not evidence of
an unsafe acceptance or a product regression. Even a structurally matching
member is explicitly blocked in the revised source until the owning immutable
proof verifier exists. That positive authority path remains unproven; this
review makes no 15/15 or Native-success claim.
