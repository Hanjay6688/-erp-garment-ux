#!/usr/bin/env node
// Actual source proposal functions; selected Native DDL; SYNTHETIC rows only.
import { PGlite } from '/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
const here = dirname(fileURLToPath(import.meta.url));
const expected = JSON.parse(await readFile(resolve(here, 'EXPECTED.json'), 'utf8'));
const sourcePath = process.env.OW04_SOURCE_RECHECK_PATH ?? resolve(here, 'source-reviewed.sql');
const source = await readFile(sourcePath, 'utf8');
const tablesPath = resolve(here, '../../source/ISOLATED_TABLES.sql');
const tables = await readFile(tablesPath, 'utf8');
const hash = x => createHash('sha256').update(x).digest('hex');
const id = n => `00000000-0000-0000-0000-${String(n).padStart(12, '0')}`;
const outputName = process.env.OW04_SOURCE_RECHECK_OUTPUT ?? 'INITIAL_BOUNDARY_RESULT.json';
const results = [];
let db;
let active = 'fixture_setup';
try {
  db = new PGlite();
  const q = (s, p = []) => db.query(s, p), ex = s => db.exec(s);
  await ex(tables);
  await ex(source.replace(/do \$not_an_installer\$[\s\S]*?end \$not_an_installer\$;/, ''));
  await ex(`create schema cp7_credit;
    create table cp7_credit.return_families(id uuid primary key,family_root_sale_id uuid not null, family_ordinal bigint not null,first_return_id uuid,source_sha256 text);
    create table cp7_credit.return_family_members(family_id uuid not null references cp7_credit.return_families(id),return_id uuid primary key,source_journal_id uuid,source_sha256 text,unique(family_id,return_id));
    alter table cp7_credit.return_families add foreign key(id,first_return_id) references cp7_credit.return_family_members(family_id,return_id) deferrable initially deferred;`);
  for (const [n, name, type, normal] of [[1,'AR','ASSET','DEBIT'],[2,'REVENUE','REVENUE','CREDIT'],[3,'COGS','EXPENSE','DEBIT'],[4,'FG','ASSET','DEBIT']]) await q('insert into erp.chart_accounts(id,account_code,account_name,account_type,report_group,normal_balance)values($1,$2,$2,$3,$2,$4)', [id(n),name,type,normal]);
  await q("insert into erp.accounting_account_mappings values('AR_CUSTOMER',$1,null)", [id(1)]);
  await q("insert into erp.customers(id,customer_code,customer_name)values($1,'FIXTURE','Synthetic')", [id(10)]);
  const header = (n, status = 'POSTED') => q("insert into erp.sales_headers(id,sale_number,customer_id,sale_date,status)values($1,$2,$3,'2026-10-17 01:00Z',$4)", [id(n),`S${n}`,id(10),status]);
  const journal = (n, type, src, e = '2026-10-17', b = e, status = 'POSTED', reversal = null) => q("insert into erp.journal_entries(id,journal_number,transaction_date,economic_date,posting_at,description,source_type,source_id,status,reversal_of_id)values($1,$2,$3,$4,$3::date::timestamptz,'Synthetic boundary fixture',$5,$6,$7,$8)", [id(n),`J${n}`,b,e,type,id(src),status,reversal === null ? null : id(reversal)]);
  const line = (n,j,a,d,c,product = null) => q('insert into erp.journal_lines(id,journal_entry_id,account_id,debit,credit,customer_id,product_id)values($1,$2,$3,$4,$5,$6,$7)', [id(n),id(j),id(a),d,c,id(10),product === null ? null : id(product)]);
  await header(100);
  await q('insert into erp.sales_items(id,sale_id,product_id,qty_pcs,unit_price_snapshot)values($1,$2,$3,5,200)', [id(101),id(100),id(11)]);
  await journal(200,'SALE',100); await line(201,200,1,'1000','0'); await line(202,200,2,'0','1000');
  await line(203,200,3,'50','0',11); await line(204,200,4,'0','50',11);
  const returned = async (n = 300, sale = 100, j = 400, status = 'POSTED') => {
    await q("insert into erp.sales_returns(id,return_number,sale_id,customer_id,physical_at,status)values($1,$2,$3,$4,'2026-10-19 01:00Z',$5)", [id(n),`R${n}`,id(sale),id(10),status]);
    await q('insert into erp.sales_return_items(id,return_id,product_id,location_id,qty_pcs,refund_amount,sale_stock_allocation_id)values($1,$2,$3,$4,1,200,$5)', [id(n+1),id(n),id(11),id(12),id(13)]);
    if (status !== 'DRAFT') { await journal(j,'SALES_RETURN',n,'2026-10-19','2026-10-19',status); await line(j+1,j,2,'200','0'); await line(j+2,j,1,'0','200'); }
  };
  const registration = async (f = 900, root = 100, ret = 300, j = 400) => {
    await q('insert into cp7_credit.return_families values($1,$2,1,$3,$4)', [id(f),id(root),id(ret),'a'.repeat(64)]);
    await q('insert into cp7_credit.return_family_members values($1,$2,$3,$4)', [id(f),id(ret),id(j),'b'.repeat(64)]);
  };
  const read = async () => (await q('select ow04_source_proposal.locked_source_family($1) AS value', [id(100)])).rows[0].value;
  const mutations = {
    valid_posted_sale: async () => {},
    valid_registered_return: async () => { await returned(); await registration(); },
    legacy_unregistered_return: async () => { await returned(); },
    draft_return_is_dependency_only: async () => { await returned(300,100,400,'DRAFT'); },
    missing_monetary_sale_journal: async () => { await q('delete from erp.journal_lines where journal_entry_id=$1', [id(200)]); await q('delete from erp.journal_entries where id=$1',[id(200)]); },
    missing_monetary_return_journal: async () => { await returned(); await q('delete from erp.journal_lines where journal_entry_id=$1', [id(400)]); await q('delete from erp.journal_entries where id=$1',[id(400)]); },
    reversed_sale_missing_inverse: async () => { await q("update erp.sales_headers set status='REVERSED'where id=$1", [id(100)]); await q("update erp.journal_entries set status='REVERSED'where id=$1", [id(200)]); },
    reversed_return_missing_inverse: async () => { await returned(300,100,400,'REVERSED'); await registration(); },
    extra_same_ar_net_line: async () => { await line(205,200,1,'100','0'); await line(206,200,2,'0','100'); },
    sale_economic_date_not_header_date: async () => { await q("update erp.journal_entries set economic_date='2026-10-18',transaction_date='2026-10-18'where id=$1",[id(200)]); },
    return_economic_date_not_header_date: async () => { await returned(); await registration(); await q("update erp.journal_entries set economic_date='2026-10-20',transaction_date='2026-10-20'where id=$1",[id(400)]); },
    wrong_root_member_suppresses_unknown: async () => { await returned(); await header(110); await returned(310,110,410); await registration(900,110,310,410); await q('insert into cp7_credit.return_family_members values($1,$2,$3,$4)',[id(900),id(300),id(400),'b'.repeat(64)]); },
    member_wrong_original_journal: async () => { await returned(); await registration(900,100,300,200); },
    duplicate_base_journal: async () => { await journal(210,'SALE',100); await line(211,210,1,'1000','0'); await line(212,210,2,'0','1000'); },
    valid_exact_reversed_sale: async () => { await q("update erp.sales_headers set status='REVERSED'where id=$1", [id(100)]); await q("update erp.journal_entries set status='REVERSED'where id=$1", [id(200)]); await journal(500,'JOURNAL_REVERSAL',200,'2026-10-20','2026-10-20','POSTED',200); await line(501,500,1,'0','1000'); await line(502,500,2,'1000','0'); await line(503,500,3,'0','50',11); await line(504,500,4,'50','0',11); },
  };
  for (const control of expected.controls) {
    active = control.name;
    await ex('begin');
    let observed, error;
    try { await mutations[control.name](); observed = await read(); }
    catch (caught) { error = { message: caught.message, code: caught.code }; }
    await ex('rollback');
    if (error && !['P0001','22023'].includes(error.code)) throw Object.assign(new Error(`Unexpected SQL/harness error in ${active}: ${error.message}`), { code: error.code });
    const actual = error ? 'REFUSE' : observed.source_status;
    let matches = control.expected_outcome === 'BASE_COLLECTED' ? actual === 'BASE_COLLECTED' : ['REFUSE','BLOCKED'].includes(actual);
    if (matches && actual === 'BASE_COLLECTED') matches = JSON.stringify(observed.events.map(x => x.amount).sort()) === JSON.stringify([...control.expected].sort());
    if (matches && control.expected_outcome === 'BLOCKED' && control.expected[0].startsWith('IMMUTABLE_') && !error) matches = observed.blockers.some(x => x.code === control.expected[0]);
    const record = { name: active, status: matches ? 'MATCHES_LITERAL_BOUNDARY_EXPECTED' : 'BOUNDARY_COUNTER_REPRODUCED', expected_outcome: control.expected_outcome, observed_outcome: actual, error, events: observed?.events?.map(x => ({ kind: x.kind, amount: x.amount, economic_date: x.economic_date, transaction_date: x.transaction_date })), blockers: observed?.blockers, lineage: observed?.lineage };
    results.push(record);
    if (!matches) try { await writeFile(resolve(here,'FIRST_BOUNDARY_COUNTER.json'), `${JSON.stringify(record,null,2)}\n`, { flag:'wx' }); } catch (caught) { if (caught.code !== 'EEXIST') throw caught; }
  }
  const report = { classification:'ACTUAL_COLLECTOR_SQL_SYNTHETIC_BOUNDARY_COUNTERS_NOT_NATIVE', native_executed:false, source_authority_proven:false, source_path:sourcePath, source_sha256:hash(source), selected_tables_path:tablesPath, selected_tables_sha256:hash(tables), synthetic_registry:true, controls:results.length, counters:results.filter(x=>x.status==='BOUNDARY_COUNTER_REPRODUCED').length, results };
  await writeFile(resolve(here,outputName), `${JSON.stringify(report,null,2)}\n`);
  console.log(JSON.stringify({ classification:report.classification, controls:report.controls, counters:report.counters, source_sha256:report.source_sha256, output:outputName }));
} catch (error) {
  const failure = { case:active, message:error.message, code:error.code, stack:error.stack, source_sha256:hash(source) };
  try { await writeFile(resolve(here,'FIRST_HARNESS_FAILURE.json'),`${JSON.stringify(failure,null,2)}\n`,{flag:'wx'}); } catch(caught) {if(caught.code!=='EEXIST')throw caught;}
  console.error(JSON.stringify(failure,null,2)); process.exitCode=1;
} finally {if(db)await db.close();}
