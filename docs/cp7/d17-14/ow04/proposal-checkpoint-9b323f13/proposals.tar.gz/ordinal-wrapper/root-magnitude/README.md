# Root magnitude counter

This separate packet freezes the literal expected result before executing the unchanged pure kernel and ordinal wrapper. It does not change either earlier expected set.

Run with `node oracle.mjs` from this directory. The first run passed; its stdout and stderr remain in `first-run.stdout.log` and `first-run.stderr.log`.

With `M = 999999999999999999.99`, the supplied base contains SALE `+M` at 2026-10-16/16, FUNDING `+M` at 17/19, FUNDING `+M` at 18/18, and FUNDING `−M` at 18/19. One family contains RETURN `−M` at 17/17 and its supplied inverse `+M` at 18/19. All dates use October 2026. The synthetic source hashes label fixture inputs.

All 12 economic/book breakpoint pairs satisfy nonnegative base and combined NET/FUNDING prefixes, zero base excess funding, and nonpositive family NET. Both kernel and wrapper produce:

| Economic date | Transaction date | Signed component |
| --- | --- | ---: |
| 2026-10-17 | 2026-10-19 | 999999999999999999.99 |
| 2026-10-18 | 2026-10-18 | 999999999999999999.99 |
| 2026-10-18 | 2026-10-19 | -1999999999999999999.98 |

The current sum is `0.00`. At the negative component the four D corners are `0, M, M, 0`, giving `−2M`. Every prefix D is either zero or M: a bound on the prefix value does not imply the same bound on its mixed component.

The driver also executes PostgreSQL `numeric(20,2)` controls: M fits, while 2M raises `22003`. Exact deterministic mechanical parts `[-M, -M]` preserve the negative component and fit that typmod individually. This verifies arithmetic slicing only; no journal poster or persisted part manifest is implemented here. Both positive component pairs have all-future capacity `0.00`, so summing positive parts would invent available credit.

The result is **pure arithmetic from supplied vectors**. No Native call ran, and it proves neither source provenance nor the lawful dates or pairing of the supplied inverse events.

Frozen expected SHA-256: `9e62b8738a6f201bc143f86d62aad0b6a5949371e427046c68605963f2860c8e`.

Unchanged kernel SHA-256: `f531f50d5a1c7ddc0a2f22f607be5ba0625a2e0388af3e7a4c6d129bf82e15fc`.

Unchanged wrapper SHA-256: `ed66c7f09433956d18368b7a804b1b04f0dcb7f9e0457686400421a849d671d1`.
