#!/usr/bin/env node
import { PGlite } from '/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
const here = dirname(fileURLToPath(import.meta.url));
const hash = x => createHash('sha256').update(x).digest('hex');
const expectedText = await readFile(resolve(here,'EXPECTED.json'),'utf8');
const fixture = JSON.parse(expectedText);
const receipt = JSON.parse(await readFile(resolve(here,'EXPECTED_RECEIPT.json'),'utf8'));
const kernel = await readFile(resolve(here,'../../kernel/kernel.sql'),'utf8');
const wrapper = await readFile(resolve(here,'../wrapper.sql'),'utf8');
assert.equal(hash(expectedText),receipt.expected_sha256);
assert.equal(hash(kernel),fixture.kernel_sha256);
assert.equal(hash(wrapper),fixture.wrapper_sha256);
const cents = x => {
  const neg=x.startsWith('-'),[whole,fraction='']=x.replace(/^[+-]/,'').split('.');
  const n=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
  return neg?-n:n;
};
const text = n => `${n<0n?'-':''}${(n<0n?-n:n)/100n}.${((n<0n?-n:n)%100n).toString().padStart(2,'0')}`;
const sum = xs => xs.reduce((a,b)=>a+b,0n);
const prefix = (xs,e,b,kind) => sum(xs.filter(x=>x.economic_date<=e&&x.transaction_date<=b&&(!kind||x.kind===kind)).map(x=>cents(x.amount)));
const partial = x => ({amount:x.amount,economic_date:x.economic_date,transaction_date:x.transaction_date});
const absolute = n=>n<0n?-n:n;
let db;
let phase='load_unchanged_pure_proposals';
try {
  db=new PGlite();await db.exec(kernel);await db.exec(wrapper);
  const input=fixture.input,base=input.base_events,family=input.families[0],all=[...base,...family.events],M=cents(fixture.M);
  const es=[...new Set(all.map(x=>x.economic_date))].sort(),bs=[...new Set(all.map(x=>x.transaction_date))].sort();
  phase='independent_bigint_prefix_conditions';
  const prefixes=[];
  for(const e of es)for(const b of bs){
    const n=prefix(base,e,b,'NET'),f=prefix(base,e,b,'FUNDING'),r=prefix(family.events,e,b,'NET');
    assert(n>=0n&&f>=0n&&r<=0n);
    assert.equal(f>n?f-n:0n,0n);
    assert(n+r>=0n);
    const d=f>n+r?f-(n+r):0n;
    assert(d===0n||d===M);
    prefixes.push({economic_date:e,transaction_date:b,base_NET:text(n),base_FUNDING:text(f),family_NET:text(r),base_F:'0.00',target_D:text(d)});
  }
  assert(all.every(x=>absolute(cents(x.amount))<=M));
  phase='actual_existing_kernel_and_wrapper';
  const q=async(sql,args)=>(await db.query(sql,args)).rows[0].value;
  const basePlan=await q('select ow04_pure_kernel.recognition_plan_v1($1::jsonb,$2::jsonb) value',[JSON.stringify([]),JSON.stringify(base)]);
  assert.deepEqual(basePlan.components,fixture.expected.base_F_components);
  const target=await q('select ow04_pure_kernel.recognition_plan_v1($1::jsonb,$2::jsonb) value',[JSON.stringify(base),JSON.stringify(family.events)]);
  assert.deepEqual(target.components.map(partial),fixture.expected.target_components);
  assert.equal(target.net_current_k,fixture.expected.net_current_k);
  assert.equal(target.has_recognition_effect,fixture.expected.has_recognition_effect);
  const output=await q('select ow04_ordinal_wrapper.reconcile_v1($1::jsonb) value',[JSON.stringify(input)]);
  assert.equal(output.arithmetic_supported,fixture.expected.wrapper_arithmetic_supported);
  assert.equal(output.source_authority_proven,false);
  assert.equal(output.families.length,1);
  const result=output.families[0];
  assert.deepEqual(result.source_target,target);
  assert.deepEqual(result.reconciliation_components.map(partial),fixture.expected.target_components);
  assert.equal(result.plan_kind,fixture.expected.plan_kind);
  assert.equal(result.needs_cohort_configuration,fixture.expected.needs_cohort_configuration);
  const negative=target.components.find(x=>x.amount===fixture.expected_negative_double_M);
  assert(negative);
  assert.deepEqual(negative.corners,fixture.expected.negative_component_corners);
  assert.equal(negative.previous_economic_date,fixture.expected.negative_component_previous_economic_date);
  assert.equal(negative.previous_transaction_date,fixture.expected.negative_component_previous_transaction_date);
  assert.equal(absolute(cents(negative.amount)),2n*M);
  assert.equal(text(absolute(cents(negative.amount))),fixture.expected.largest_target_absolute_amount);
  for(const p of prefixes)assert.equal(prefix(target.components,p.economic_date,p.transaction_date),cents(p.target_D));
  phase='mechanical_exact_slicing_only_not_native_poster';
  const parts=[];let remaining=absolute(cents(negative.amount));
  while(remaining>0n){const amount=remaining>M?M:remaining;parts.push(text(-amount));remaining-=amount;}
  assert.deepEqual(parts,fixture.expected.negative_component_parts);
  assert.equal(sum(parts.map(cents)),cents(negative.amount));
  assert(parts.every(x=>absolute(cents(x))<=M));
  phase='postgres_numeric_typmod_control_not_native_execution';
  assert.equal(await q('select $1::numeric(20,2)::text value',[fixture.M]),fixture.M);
  let overflow;
  try{await q('select $1::numeric(20,2)::text value',[fixture.expected.largest_target_absolute_amount]);}catch(error){overflow=error;}
  assert(overflow);assert.equal(overflow.code,'22003');
  phase='future_joint_capacity_not_refundable_historical_gross';
  const capacities=[];
  for(const component of target.components.filter(x=>cents(x.amount)>0n)){
    const value=await q('select ow04_ordinal_wrapper.capacity_v1($1::jsonb,$2,$3,$4) value',[JSON.stringify(input),family.family_id,component.economic_date,component.transaction_date]);
    capacities.push(value);
  }
  assert.deepEqual(capacities.map(x=>x.capacity.minimum_available),fixture.expected.future_capacity_at_positive_components);
  const report={classification:'ROOT_MAGNITUDE_PURE_ARITHMETIC_SUPPLIED_VECTORS_NOT_NATIVE',native_executed:false,native_inverse_date_authority_proven:false,source_authority_proven:false,source_hashes_are_fixture_labels:true,expected_sha256:hash(expectedText),kernel_sha256:hash(kernel),wrapper_sha256:hash(wrapper),driver_sha256:hash(await readFile(fileURLToPath(import.meta.url))),M:fixture.M,prefix_conditions_hold:true,prefixes,base_plan:basePlan,target,wrapper_family:result,wrapper_input_sha256:output.input_sha256,mechanical_negative_parts:parts,numeric_20_2_double_M_refusal:{code:overflow.code,message:overflow.message},capacities,status:'PASS'};
  await writeFile(resolve(here,'RESULT.json'),`${JSON.stringify(report,null,2)}\n`);
  console.log(JSON.stringify({status:'PASS',classification:report.classification,M:report.M,target_components:target.components.map(partial),net_current_k:target.net_current_k,negative_parts:parts,native_executed:false,source_authority_proven:false}));
}catch(error){
  const failure={phase,message:error.message,code:error.code,stack:error.stack,expected_sha256:hash(expectedText)};
  try{await writeFile(resolve(here,'FIRST_FAILURE.json'),`${JSON.stringify(failure,null,2)}\n`,{flag:'wx'});}catch(caught){if(caught.code!=='EEXIST')throw caught;}
  console.error(JSON.stringify(failure,null,2));process.exitCode=1;
}finally{if(db)await db.close();}
