#!/usr/bin/env node
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
const here = dirname(fileURLToPath(import.meta.url));
const modulePath = process.env.OW04_PGLITE_MODULE ?? '/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
const { PGlite } = await import(modulePath);
const hash = x => createHash('sha256').update(x).digest('hex');
const expectedText = await readFile(resolve(here, 'EXPECTED.json'), 'utf8');
const expected = JSON.parse(expectedText);
const receipt = JSON.parse(await readFile(resolve(here, 'EXPECTED_RECEIPT.json'), 'utf8'));
const kernel = await readFile(resolve(here, '../kernel/kernel.sql'), 'utf8');
const wrapper = await readFile(resolve(here, 'wrapper.sql'), 'utf8');
assert.equal(hash(expectedText), receipt.expected_sha256);
assert.equal(hash(kernel), expected.base_kernel_sha256, 'Existing kernel changed');
assert.equal(hash(await readFile(resolve(here, 'OWN8_LOCKED_EXPECTED.json'))), receipt.own8_frozen_sha256);
assert.equal(hash(await readFile(resolve(here, 'PEER15_LOCKED_EXPECTED.json'))), receipt.peer15_frozen_sha256);
const clone = x => JSON.parse(JSON.stringify(x));
const cents = text => {
  const negative = text.startsWith('-');
  const [a, b = ''] = text.replace(/^[+-]/, '').split('.');
  const n = BigInt(a) * 100n + BigInt(b.padEnd(2, '0'));
  return negative ? -n : n;
};
const money = n => `${n < 0n ? '-' : ''}${(n < 0n ? -n : n) / 100n}.${((n < 0n ? -n : n) % 100n).toString().padStart(2, '0')}`;
const sum = xs => xs.reduce((a, b) => a + b, 0n);
const prefix = (xs, e, b) => sum(xs.filter(x => x.economic_date <= e && x.transaction_date <= b).map(x => cents(x.amount)));
const overflow = (xs, e, b) => {
  const n = prefix(xs.filter(x => x.kind === 'NET'), e, b);
  const f = prefix(xs.filter(x => x.kind === 'FUNDING'), e, b);
  assert(n >= 0n && f >= 0n);
  return f > n ? f - n : 0n;
};
const partial = x => ({ amount: x.amount, economic_date: x.economic_date, transaction_date: x.transaction_date });
const byPair = xs => [...xs].sort((a, b) => a.economic_date < b.economic_date ? -1 : a.economic_date > b.economic_date ? 1 : a.transaction_date < b.transaction_date ? -1 : a.transaction_date > b.transaction_date ? 1 : 0);
const uniqueSorted = xs => [...new Set(xs)].sort();
let db;
let active = 'load_existing_kernel_and_wrapper';
const results = [];
async function one(sql, args) { return (await db.query(sql, args)).rows[0].value; }
async function reconcile(input) { return one('SELECT ow04_ordinal_wrapper.reconcile_v1($1::jsonb) AS value', [JSON.stringify(input)]); }
async function capacity(input, f, e, b) { return one('SELECT ow04_ordinal_wrapper.capacity_v1($1::jsonb,$2,$3,$4) AS value', [JSON.stringify(input), f, e, b]); }
async function canonicalHash(value) { return hash(await one('SELECT $1::jsonb::text AS value', [JSON.stringify(value)])); }
async function refusal(name, run, message) {
  let caught;
  try { await run(); } catch (error) { caught = error; }
  assert(caught, `${name} unexpectedly accepted`);
  assert.equal(caught.message, message);
  assert.equal(caught.code, '22023');
  return { name, status: 'EXPECTED_REFUSAL', reason: caught.message, sqlstate: caught.code };
}
function fullGrid(input, result) {
  let prior = input.base_events;
  for (const family of result.families) {
    const id = family.registration.family_id;
    const supplied = input.families.find(x => x.family_id === id);
    const after = [...prior, ...supplied.events];
    const es = uniqueSorted([...after, ...supplied.retained_recognition].map(x => x.economic_date));
    const bs = uniqueSorted([...after, ...supplied.retained_recognition].map(x => x.transaction_date));
    const delta = (e, b) => e === null || b === null ? 0n : overflow(after, e, b) - overflow(prior, e, b) - prefix(supplied.retained_recognition, e, b);
    for (const e of es) for (const b of bs) {
      assert.equal(prefix(family.reconciliation_components, e, b), delta(e, b), `Incomplete signed I reconciliation for ${id}@${e}/${b}`);
      assert.equal(prefix(family.source_target.components, e, b), overflow(after, e, b) - overflow(prior, e, b));
    }
    for (const c of family.reconciliation_components) {
      const i = es.indexOf(c.economic_date), j = bs.indexOf(c.transaction_date);
      assert(i >= 0 && j >= 0);
      const pe = i === 0 ? null : es[i - 1], pb = j === 0 ? null : bs[j - 1];
      assert.equal(c.previous_economic_date, pe);
      assert.equal(c.previous_transaction_date, pb);
      assert.deepEqual(c.corners, { d_here: money(delta(c.economic_date, c.transaction_date)), d_prev_economic: money(delta(pe, c.transaction_date)), d_prev_transaction: money(delta(c.economic_date, pb)), d_prev_both: money(delta(pe, pb)) });
      assert.equal(cents(c.target_amount), sum(family.source_target.components.filter(x => x.economic_date === c.economic_date && x.transaction_date === c.transaction_date).map(x => cents(x.amount))));
      assert.equal(cents(c.retained_amount), sum(supplied.retained_recognition.filter(x => x.economic_date === c.economic_date && x.transaction_date === c.transaction_date).map(x => cents(x.amount))));
      assert.equal(cents(c.amount), cents(c.target_amount) - cents(c.retained_amount));
      assert(c.transaction_date >= c.economic_date);
    }
    assert.equal(cents(family.reconciliation_net_current), cents(family.target_net_current) - cents(family.retained_net_current));
    prior = after;
  }
  const all = [...input.base_events, ...input.families.flatMap(x => x.events)];
  const es = uniqueSorted(all.map(x => x.economic_date)), bs = uniqueSorted(all.map(x => x.transaction_date));
  for (const e of es) for (const b of bs) assert.equal(sum(result.families.map(x => prefix(x.source_target.components, e, b))), overflow(all, e, b) - overflow(input.base_events, e, b), 'Ordinal targets do not telescope');
}
try {
  db = new PGlite();
  await db.exec(kernel);
  await db.exec(wrapper);
  for (const fixture of expected.fixtures) {
    active = fixture.name;
    if (fixture.source_control) {
      assert.equal(fixture.classification, 'RETAINED_EXTERNAL_DATE_AUTHORITY_CONTROL');
      results.push({ name: active, status: 'RETAINED_EXTERNAL_SCOPE_CONTROL_NOT_CLAIMED_AS_WRAPPER_PROOF' });
      continue;
    }
    if (fixture.expected_error) {
      results.push(await refusal(active, () => reconcile(fixture.input), fixture.expected_error));
      continue;
    }
    const observed = await reconcile(fixture.input);
    assert.equal(observed.contract_version, 'ow04.ordinal-reconciliation.v1');
    assert.equal(observed.evidence_class, 'PURE_ARITHMETIC_FROM_SUPPLIED_VECTORS');
    assert.equal(observed.source_authority_proven, false);
    assert.equal(observed.arithmetic_supported, fixture.expected_arithmetic_supported);
    const targetMap = {}, diffMap = {}, currentMap = {};
    assert.equal(observed.family_registrations.length, fixture.input.families.length);
    assert.equal(observed.families.length, fixture.input.families.length);
    for (const family of observed.families) {
      const id = family.registration.family_id;
      const supplied = observed.input.families.find(x => x.family_id === id);
      targetMap[id] = family.source_target.components.map(partial);
      diffMap[id] = family.reconciliation_components.map(partial);
      currentMap[id] = family.target_net_current;
      assert.equal(family.registration_required, true);
      assert.equal(family.plan_kind, fixture.expected_plan_kinds?.[id] ?? (supplied.retained_recognition.length ? 'ADJUSTMENT' : 'INITIAL'));
      assert.equal(family.supplied_retained_history_present, supplied.retained_recognition.length > 0);
      assert.equal(family.needs_cohort_configuration, supplied.retained_recognition.length === 0 && family.source_target.has_recognition_effect);
      assert.equal(family.component_basis, 'FAMILY_TARGET_MINUS_ALL_SUPPLIED_RETAINED_RECOGNITION');
      assert.equal(family.source_authority_proven, false);
      assert.equal(family.source_target_sha256, await canonicalHash(family.source_target));
      assert.equal(family.retained_recognition_sha256, await canonicalHash(supplied.retained_recognition));
      assert.equal(family.consumptions_sha256, await canonicalHash(supplied.consumptions));
      assert.equal(family.reconciliation_sha256, await canonicalHash(family.reconciliation_components));
      assert.equal(family.cohort_input_sha256, await canonicalHash({ wrapper_version: 'ow04-ordinal-wrapper-v1', input_sha256: observed.input_sha256, family_root_sale_id: observed.input.family_root_sale_id, registration: family.registration, source_target: family.source_target, retained_recognition: supplied.retained_recognition, consumptions: supplied.consumptions, reconciliation_components: family.reconciliation_components }));
    }
    assert.deepEqual(targetMap, fixture.expected_targets);
    assert.deepEqual(diffMap, fixture.expected_reconciliations);
    assert.deepEqual(currentMap, fixture.expected_current_faces);
    fullGrid(observed.input, observed);
    assert.equal(observed.input_sha256, await canonicalHash(observed.input));
    const withoutResultHash = { ...observed }; delete withoutResultHash.result_sha256;
    assert.equal(observed.result_sha256, await canonicalHash(withoutResultHash));
    const reordered = clone(fixture.input);
    reordered.base_events.reverse(); reordered.families.reverse();
    for (const f of reordered.families) for (const k of ['events','retained_recognition','consumptions']) f[k].reverse();
    assert.deepEqual(await reconcile(reordered), observed, 'Retrieval order changed full bound protocol');
    const capacityResults = [];
    for (const control of fixture.capacity_controls ?? []) {
      const cap = await capacity(fixture.input, control.cohort, ...control.proposed_pair);
      assert.equal(cap.source_authority_proven, false);
      assert.equal(cap.all_cohorts_arithmetic_supported, observed.arithmetic_supported);
      const f = observed.families.find(x => x.registration.family_id === control.cohort);
      assert.equal(cap.cohort_input_sha256, f.cohort_input_sha256);
      for (const key of ['minimum_available','requested_pair_balance','current_balance','source_prefixes_nonnegative']) if (control[key] !== undefined) assert.equal(cap.capacity[key], control[key]);
      capacityResults.push(cap);
    }
    results.push({ name: active, status: 'MATCHES_LITERAL_TARGET_DIFF_CAPACITY_AND_RAW_PREFIX_ORACLE', arithmetic_supported: observed.arithmetic_supported, families: observed.families.map(x => ({ family_id: x.registration.family_id, plan_kind: x.plan_kind, source_components: x.source_target.components.map(partial), reconciliation_components: x.reconciliation_components, cohort_input_sha256: x.cohort_input_sha256 })), capacity_results: capacityResults });
  }
  const valid = clone(expected.fixtures.find(x => x.name === 'OWN8:cohort1_consumer_cannot_silently_borrow_cohort2_after_funding_inverse').input);
  for (const fixture of expected.invalid_input_fixtures) {
    active = fixture.name;
    const x = clone(valid), a = x.families[0], b = x.families[1];
    if (fixture.mutation === 'duplicate_ordinal') b.ordinal = a.ordinal;
    if (fixture.mutation === 'duplicate_family_id') b.family_id = a.family_id;
    if (fixture.mutation === 'duplicate_first_return') b.first_return_id = a.first_return_id;
    if (fixture.mutation === 'numeric_ordinal') a.ordinal = 1;
    if (fixture.mutation === 'ordinal_leading_zero') a.ordinal = '01';
    if (fixture.mutation === 'funding_in_family') a.events[0].kind = 'FUNDING';
    if (fixture.mutation === 'missing_registration_hash') delete a.registration_sha256;
    if (fixture.mutation === 'bad_registration_hash') a.registration_sha256 = 'bad';
    if (fixture.mutation === 'duplicate_source_id') b.events[0].id = a.events[0].id;
    if (fixture.mutation === 'duplicate_retained_id') b.retained_recognition[0].id = a.retained_recognition[0].id;
    if (fixture.mutation === 'duplicate_consumption_id') b.consumptions = [clone(a.consumptions[0])];
    if (fixture.mutation === 'extra_input_key') x.extra = true;
    if (fixture.mutation === 'wrong_contract') x.contract_version = 'unbound';
    results.push(await refusal(active, () => fixture.mutation === 'unknown_capacity_family' ? capacity(x, 'MISSING', '2026-10-21', '2026-10-21') : reconcile(x), fixture.expected_error));
  }
  active = 'full_input_and_cohort_hash_dependency_controls';
  const clean = clone(expected.fixtures.find(x => x.name === 'PEER15:ORD01_SIBLING_BASE').input);
  const original = await reconcile(clean);
  const changedRegistration = clone(clean); changedRegistration.families[0].registration_sha256 = 'f'.repeat(64);
  const registrationResult = await reconcile(changedRegistration);
  assert.notEqual(registrationResult.input_sha256, original.input_sha256);
  assert.notEqual(registrationResult.source_input_sha256, original.source_input_sha256);
  assert(registrationResult.families.every((f, i) => f.cohort_input_sha256 !== original.families[i].cohort_input_sha256));
  const changedI = clone(clean);
  const date = changedI.families[0].events[0].economic_date;
  changedI.families[0].retained_recognition = [
    { id: 'retained-positive', amount: '100.00', economic_date: date, transaction_date: date, source_sha256: 'a'.repeat(64) },
    { id: 'retained-negative', amount: '-100.00', economic_date: date, transaction_date: date, source_sha256: 'b'.repeat(64) },
  ];
  const changedIResult = await reconcile(changedI);
  assert.deepEqual(changedIResult.families[0].reconciliation_components.map(partial), original.families[0].reconciliation_components.map(partial));
  assert.equal(changedIResult.families[0].plan_kind, 'ADJUSTMENT');
  assert.equal(changedIResult.input.families[0].retained_recognition.length, 2);
  assert.notEqual(changedIResult.retained_recognition_input_sha256, original.retained_recognition_input_sha256);
  assert.equal(changedIResult.source_input_sha256, original.source_input_sha256);
  assert.notEqual(changedIResult.families[0].cohort_input_sha256, original.families[0].cohort_input_sha256);
  const changedC = clone(valid), current = await reconcile(changedC);
  changedC.families[0].consumptions[0].source_sha256 = 'e'.repeat(64);
  const changedCResult = await reconcile(changedC);
  assert.notEqual(changedCResult.consumption_input_sha256, current.consumption_input_sha256);
  assert.notEqual(changedCResult.input_sha256, current.input_sha256);
  assert.notEqual(changedCResult.families[0].cohort_input_sha256, current.families[0].cohort_input_sha256);
  results.push({ name: active, status: 'PASS', authority_proven: false });
  active = 'ordinal_swap_is_a_hash_bound_authority_counter';
  const peer = JSON.parse(await readFile(resolve(here, 'PEER15_LOCKED_EXPECTED.json'), 'utf8'));
  const swapFixture = expected.fixtures.find(x => x.name === 'PEER15:ORD12_ORDINAL_MUTATION_REJECTED');
  const swapped = clone(swapFixture.input);
  swapped.families[0].ordinal = '2'; swapped.families[1].ordinal = '1';
  const beforeSwap = await reconcile(swapFixture.input), afterSwap = await reconcile(swapped);
  const wantedSwap = peer.cases.find(x => x.id === 'ORD12_ORDINAL_MUTATION_REJECTED').expected.swapped_ordinal_wrong_vectors;
  assert.deepEqual(Object.fromEntries(afterSwap.families.map(x => [x.registration.family_id, x.source_target.components.map(partial)])), wantedSwap);
  assert.notEqual(afterSwap.input_sha256, beforeSwap.input_sha256);
  assert.equal(afterSwap.source_authority_proven, false);
  results.push({ name: active, status: 'ARITHMETIC_ACCEPTS_CHANGED_INPUT_BINDER_MUST_PROVE_IMMUTABLE_REGISTRY', before_hash: beforeSwap.input_sha256, changed_hash: afterSwap.input_sha256 });
  active = 'immutable_invoker_session_independence';
  await db.exec("SET DateStyle='SQL, DMY'; SET TimeZone='Pacific/Honolulu';");
  assert.deepEqual(await reconcile(clean), original);
  const audit = (await db.query("SELECT p.proname,p.provolatile,p.prosecdef FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='ow04_ordinal_wrapper' ORDER BY p.proname")).rows;
  assert.equal(audit.length, 7);
  assert(audit.every(x => x.provolatile === 'i' && x.prosecdef === false));
  results.push({ name: active, status: 'PASS', functions: audit });
  const report = { classification: 'ISOLATED_PGLITE_ORDINAL_WRAPPER_PROPOSAL', native_executed: false, source_authority_proven: false, product_installed: false, kernel_modified: false, expected_sha256: hash(expectedText), kernel_sha256: hash(kernel), wrapper_sha256: hash(wrapper), driver_sha256: hash(await readFile(fileURLToPath(import.meta.url))), postgresql_version: await one('SELECT version() AS value'), counts: { retained_fixtures: expected.fixtures.length, invalid_inputs: expected.invalid_input_fixtures.length, total_results: results.length }, results };
  await writeFile(resolve(here, 'RESULT.json'), `${JSON.stringify(report, null, 2)}\n`);
  console.log(JSON.stringify({ status: 'PASS', ...report.counts, wrapper_sha256: report.wrapper_sha256, native_executed: false, source_authority_proven: false }));
} catch (error) {
  const failure = { case: active, message: error.message, code: error.code, stack: error.stack, expected_sha256: hash(expectedText), wrapper_sha256: hash(wrapper) };
  try { await writeFile(resolve(here, 'FIRST_FAILURE.json'), `${JSON.stringify(failure, null, 2)}\n`, { flag: 'wx' }); } catch (writeError) { if (writeError.code !== 'EEXIST') throw writeError; }
  console.error(JSON.stringify(failure, null, 2)); process.exitCode = 1;
} finally { if (db) await db.close(); }
