# Pure ordinal wrapper proposal

This directory is outside the active ERP repository. `wrapper.sql` is not a
product migration, installer, source collector, authority boundary, or date/account
proof. It uses the existing unchanged pure kernel in `../kernel/kernel.sql`.
All functions are immutable invokers with an empty search path. No tables,
grants, accounts, source journals, Native functions, or product files are changed.

The inputs are **supplied vectors**, not validated Native facts. The wrapper can
check their shape and arithmetic and bind them by hash. It cannot establish that
they include every source/history row, belong to the stated customer/root,
reflect immutable causal ordinals, use lawful source date pairs, or were read
fresh under the owning locks. Every result says `source_authority_proven:false`.

## Evidence

The exact independently frozen own8 and peer15 expected files are retained as
`OWN8_LOCKED_EXPECTED.json` and `PEER15_LOCKED_EXPECTED.json`. Their original
hashes and the wrapper's expected-first hash are in `EXPECTED_RECEIPT.json`.
`EXPECTED.json` adapts their literal arithmetic controls to this protocol and
adds a signed net-zero retained-I control, a family with an empty NET vector,
and 14 malformed-input controls. The root/date-floor control remains explicitly
external; it is not counted as SQL date-authority proof.

```sh
node /workspace/scratch/9442228ed2dc/ow04-proposals/ordinal-wrapper/oracle.mjs
```

The driver loads only the two pure proposals into a new in-memory PGlite database.
Its dependency defaults to the already installed PGlite module in `sql-dev`;
`OW04_PGLITE_MODULE` can override that module path/URL. The first run produced
41 passing executable result records plus one retained external source control
(42 total records). No first-failure file exists. A later failure creates
`FIRST_FAILURE.json` once and preserves it across reruns.

The checks cover literal targets and exact differences, independent BigInt
source-prefix reconstruction, difference corners, ordinal telescoping, per-cohort
future capacity, all signed retained rows, input-order/session independence,
hash dependencies, and immutable invoker metadata. `RESULT.json` records the
actual SQL, driver and expected hashes and the explicit non-Native scope.

## Input protocol

`ow04_ordinal_wrapper.reconcile_v1(input jsonb)` requires exactly these top keys:

| Key | Value |
| --- | --- |
| `contract_version` | `ow04.ordinal-input.v1` |
| `family_root_sale_id` | Nonblank context identity, at most 512 characters |
| `base_events` | Complete supplied gross SALE-family and raw funding contributions |
| `families` | Complete supplied logical return families, including initially empty ones |

Each family requires exactly:

| Key | Value |
| --- | --- |
| `family_id` | Nonblank immutable-family identity |
| `ordinal` | Positive canonical integer **string**, within signed bigint range |
| `first_return_id` | Nonblank logical root-return identity |
| `registration_sha256` | Lowercase 64-hex supplied registration digest |
| `events` | All supplied signed NET contributions for that return family |
| `retained_recognition` | Every supplied retained signed recognition event for the cohort |
| `consumptions` | Every supplied signed consumption and real inverse event for the cohort |

Ordinals, family IDs and first-return IDs are unique. Ordinals need not be
contiguous; continuity cannot prove authoritative completeness. Families are
normalized in ordinal order. Registration is retained even when `events` is
empty or the target has no components. Normalization does not assign an ordinal,
create a registration, choose a credit account, or prove a registration digest.

Source events use the existing six-field protocol:
`{id,kind,amount,economic_date,transaction_date,source_sha256}`. Base events allow
NET/FUNDING; return-family events allow NET only. Recognition/consumption events
use the same fields except `kind`. Monetary values are exact decimal strings;
scalar validation and canonical money/date formatting come from the existing
kernel. All raw source IDs are unique across base and all return families.
Recognition/consumption IDs are globally unique across those movement arrays.
These are separate source and movement identity namespaces.

No original/inverse/status filter is applied. An inverse is a distinct signed
row. Zero-effect and net-zero histories remain in normalized inputs and hashes.
The wrapper does not accept current/unspent scalar balances as substitutes for
the retained recognition vector.

The real collector must supply materialized signed recognition, backed by actual
journals and complete part coverage, including every adjustment and inverse.
Registering a plan or component does not materialize its amount. An aggregate
component may stand for parts only after exact complete part/journal coverage is
proven; partial own-plan postings require separate manifest accounting below.

## Target and difference

The wrapper first evaluates `F(base)` using the existing kernel and refuses any
nonempty recognition profile. A current scalar zero is insufficient: historical
`+800/-800` base overflow also refuses with `BASE_OVERFLOW_NONZERO`.

Every return family's cumulative NET must be nonpositive at **every joint date
prefix**, or the wrapper refuses with `FAMILY_NET_PREFIX_POSITIVE`. This catches
the algebraic negative-target hole caused by an inverse visible before its
original book date. It does not establish real inverse pairing: a different
negative contribution could conceal a bad pair, which the authoritative source
boundary must independently reject.

For normalized causal ordinals, each exact existing-kernel result is:

\[
T_i=F(base+families_{1..i})-F(base+families_{1..i-1}).
\]

The output `source_target` is that complete untouched `recognition_plan_v1`
result. Recognition components are never fed into the raw NET/FUNDING kernel.
The wrapper separately groups target coefficients and **all supplied retained
recognition coefficients** by exact economic/book pair, then emits:

\[
adjustment(e,b)=targetCoefficient(e,b)-retainedCoefficient(e,b).
\]

Each nonzero `reconciliation_components` row contains `amount`, both dates,
`target_amount`, `retained_amount`, both previous-axis dates, and `corners`.
The corners are cumulative **target-minus-retained recognition** differences on
the union of source axes and retained-recognition axes. They are not a raw
source-only kernel claim. Amounts reconstruct every 2D difference prefix and
sum to `target_net_current - retained_net_current`.

`component_basis=FAMILY_TARGET_MINUS_ALL_SUPPLIED_RETAINED_RECOGNITION` names this
distinction. A storage/posting validator must adopt this wrapper contract; it
must not compare an ADJUSTMENT to an ordinary whole-invoice raw ΔF result.

`plan_kind` is `INITIAL` if the supplied retained-recognition array is empty and
`ADJUSTMENT` if it has any rows. This is a classification of the supplied
history, not proof that a real cohort exists/does not exist. In particular,
`[+100@19,-100@20]` is retained ADJUSTMENT history even though its current net is
zero. If the target adds `+100@21`, the difference is only `+100@21`.

`has_reconciliation_effect` tests nonempty signed difference history, not net
amount. `needs_cohort_configuration` is true when no recognition history was
supplied and the target has a nonempty profile, including net-zero profiles.
It does not choose CREDIT/REFUND, an account, a journal amount, or a cash event.
An empty registration requires no financial cohort solely because it appears in
the output. Existing original issued-face facts are never modified here.

## Capacity

Each family is checked independently using the existing `credit_capacity_v1`.
`target_full_prefix_capacity` evaluates the target against all supplied consumers
at/beyond the earliest relevant date pair, covering every joint prefix.
`retained_full_prefix_capacity` also checks the supplied old recognition/consumer
state. `arithmetic_supported` is true only when both sets of credit-balance
prefixes are nonnegative. The whole-result flag requires every cohort to pass.
This refuses a claimed repair that merely conceals an already unsupported old
consumer state. These flags prove no source authority or posting permission.

`ow04_ordinal_wrapper.capacity_v1(input jsonb, family_id text, economic_date text,
transaction_date text)` first recomputes the entire reconciliation protocol,
then queries the selected family's **reconciled target** against its supplied
consumptions at the requested pair. Its `capacity` is the existing kernel result:
the signed minimum over all later joint breakpoints, including requested and
current pairs. A caller must also honor both wrapper arithmetic flags, even if
the requested later minimum is positive after an earlier deficit recovered.

One family cannot borrow another family's remaining credit. Current credit and
separate economic/book margins cannot replace the joint minimum. A later
consumer inverse cannot repair an earlier deficit. The retained controls cover
all three distinctions.

Capacity calls use mechanically role-namespaced movement IDs to avoid collisions
between supplied IDs and derived target atoms. Their kernel-level capacity
hashes concern those derived vectors. Wrapper hashes below separately bind the
complete original supplied vectors. Positive consumption uses credit; negative
consumption restores it mathematically. Real original/inverse pairing is an
external requirement; a fabricated inverse can still inflate arithmetic.

## Hash and binding protocol

All hashes use the existing kernel's PostgreSQL JSONB-text/UTF-8/SHA-256 contract.
Equivalent cent spellings and retrieval order normalize identically. This is not
ordinary JavaScript JSON serialization or an RFC 8785 promise.

| Output | Bound data |
| --- | --- |
| `input_sha256` | Complete normalized input, root, all family registrations, sources, retained recognition and consumptions |
| `source_input_sha256` | Root, base sources, all ordinal/registration metadata and all return-family sources |
| `retained_recognition_input_sha256` | All family/ordinal-tagged retained recognition vectors |
| `consumption_input_sha256` | All family/ordinal-tagged consumption vectors |
| Per-family `source_target_sha256` | Exact existing-kernel result |
| Per-family `retained_recognition_sha256`, `consumptions_sha256` | Complete normalized supplied cohort vectors |
| Per-family `reconciliation_sha256` | Exact signed difference coefficients and corner evidence |
| Per-family `cohort_input_sha256` | Wrapper version, full batch hash, root, family registration, source target, all old I/C rows, and exact difference |
| `result_sha256` | Complete result before adding this self-hash |

The cohort hash deliberately depends on the entire batch input. A later-family
or sibling-input change can therefore require a fresh bound result even when
one target's numeric coefficients stay unchanged. Account/mode/source rights
and actual Native journals must be bound separately by the complete owning
feature; they are not present in this arithmetic protocol.

`family_registrations` contains every normalized supplied registration. Every
per-family result retains its registration and says `registration_required:true`;
neither field claims that this pure function wrote or verified a database row.

The deliberate ordinal-swap control demonstrates the boundary. Swapping two
supplied ordinals changes attribution and all relevant binding hashes but is
arithmetically accepted with `source_authority_proven:false`. The complete
feature must compare the supplied registrations with fresh immutable registered
ordinals and reject unauthorized changes. The same applies to omitted source,
retained-I, consumption, inverse, or zero-effect rows.

## Whole-feature integration requirements

The owning coordinator must prove root/current-leaf/return-family membership and
ordinal assignment, complete original/inverse/neutral/effective histories, actual
source hashes and both date axes, lawful period/root/pair floors, old ledger and
GL/AR/liability reconciliation, account/customer dimensions, current permissions,
request idempotency, consumer lineage, and final dated cash/application capacity
under its established locks. It must post all required signed differences and
dependent consumer handling atomically or refuse. Input shape/arithmetic success
is never a replacement for these checks.

Missing persisted note-to-return replay/family membership is a source ambiguity,
not permission to infer identity from amounts, dates or UUID order. Current
readers may run between a Native source write and recognition posting inside a
compound action. That coordinator must handle its explicit intermediate/final
read boundary; reports and ordinary current readers cannot count a merely
planned recognition amount as actual materialized I.

When posting a bound multi-component plan, the coordinator must distinguish its
frozen complete pre-plan retained-I baseline from its own exactly matched
pending/posted current-plan members. It must prove actual I equals that baseline
plus those members, rather than dropping unexplained rows or naively expecting
the same whole-plan hash after the first member posts. Alternatively it can
recompute against all current I and prove the exact remaining difference against
the immutable plan manifest. This proposal provides neither authority mechanism.

The wrapper cannot authorize a source mutation because it creates positive
credit, an automatic new refund because an earlier return chose REFUND, a new
credit account default, a legacy ordinal backfill, or shifting a closed-period
component to another date. Those decisions remain in the complete source-owned
review/posting flow. No part of this proposal is installed independently.
