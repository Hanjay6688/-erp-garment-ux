# Initial twelve OW04 settlement cases

`cp7_ow04_initial_settlement_cases.py` exports `NATIVE_IDS` and
`cases(cur, today) -> [(id, zero_argument_callable), ...]`. Registration is pure.
The caller supplies the closed Native harness cursor and serializes these
period-global fixtures. No database is started or connected by this packet.

The literal matrix in `EXPECTED.json` was frozen before the test module. The
disposable account-master authorization was clarified in its metadata before
implementation; all financial/date/replay literals stayed unchanged. Each
case creates a uniquely named empty LIABILITY/CREDIT master, explicitly labeled
`ADMINISTRATIVE_DISPOSABLE_MASTER_FIXTURE`, alongside the retained source
fixture's bank/location masters. It creates no import batch, opening balance,
default account or artificial cash funding. Business transactions use the
accepted source fixture and the fixed proposed public quote/settle calls.

The twelve combinations are P1000/P900 × OPEN/CLOSED/REOPENED × CREDIT/REFUND.
Each obtains a fresh actual READY quote with the explicit selected accounts,
builds the exact existing SALES `{document, expected_version}` envelope, calls
the proposed settlement RPC, then retries the identical UUID and document.
Missing APIs, incomplete ledger or any refused/non-READY quote fails the case;
none is skipped or counted as success.

Assertions inspect actual Native journals and raw sources: payment/header/fact
and original sale/payment journals stay byte-equal; original allocation, HPP
source and stock movements stay intact; one return adds one real movement with
unit HPP10; final FG6/value60, revenue800, COGS40, effective paid800 and AR0.
Recognition is K200/K100 and is distinct from refund consumption. REFUND uses
the existing payment-funded cash account, consumes full K once, leaves I
unchanged, liability0 and bank800. Actual support events must be exactly the
stored SALE, PAYMENT and RETURN journals; part/journal links, counts, signed
amounts and both date axes must match. No additional journal or stock movement
is permitted. The Native lot's legitimate quantity/open cache changes to6;
its other stored identity fields stay byte-equal.

The refund physical time is explicitly entered at D2 13:00:00.654321+07:00,
separate from the return's D2 noon. OPEN requires book D2; CLOSED/REOPENED require
book D3 for return, recognition and refund. The REOPENED fixture's ordinary
resolver D2 is retained as the counter; no requested book date enters either
public payload. The current ledger prototype stores the consumption's two
date axes, not a standalone refund physical timestamp column: this packet
checks the exact physical input/quote echo and actual journal date pair without
claiming an additional persisted timestamp field.

The raw checks target the pinned `cp7_credit` typed ledger proposal, including
recognition source type `CP7_CUSTOMER_CREDIT_RECOGNITION` with part UUID and
refund source type `CP7_CUSTOMER_CREDIT_REFUND` with event UUID. These are owning
storage integration assertions, not extra browser fields. If the final owning
implementation changes that internal protocol, root must reconcile it against
actual source before registration. The packet does not provide a substitute
coordinator, source-authority verifier or financial installer.

To perform source-only checks, run `PYTHONDONTWRITEBYTECODE=1 python -B
check_proposal.py` in this folder. It imports the accepted source dependencies
from the writer checkout, forbids database connection, confirms twelve distinct
bound closures and passes twelve explicitly synthetic wire packets through the
actual unchanged UI parser/commit builder. `STATIC_RESULT.json` records that
limited result. The first local checker failure (wrong working directory for
an accepted dependency's relative source file) is retained in
`FIRST_STATIC_FAILURE.json`; the checker now uses the writer working directory.

Keep the fixture and this packet in their separate directories when loading:
each module reads its own adjacent frozen `EXPECTED.json`. Root owns any later
relocation into registered product tests, preserving both expected digests.

No Native case, settlement, cash movement or provider call has run here.
