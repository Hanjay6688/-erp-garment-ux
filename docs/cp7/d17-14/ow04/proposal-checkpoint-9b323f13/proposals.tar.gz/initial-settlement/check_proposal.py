"""Source/registration and actual UI-parser compatibility; never a Native run."""
from datetime import date
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import traceback

HERE = Path(__file__).resolve().parent
PROPOSALS = HERE.parent
REPO = PROPOSALS.parent / 'erp-d1714'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    sys.dont_write_bytecode = True
    # Accepted Native fixture dependencies read retained source files relative
    # to the writer checkout, matching the real closed harness working directory.
    os.chdir(REPO)
    sys.path[:0] = [str(HERE), str(PROPOSALS / 'native'), str(REPO / 'scripts')]
    import psycopg

    def forbid(*args, **kwargs):
        raise AssertionError('STATIC_CHECK_MUST_NOT_CONNECT')

    psycopg.connect = forbid
    import cp7_ow04_initial_settlement_cases as cases
    compile((HERE / 'cp7_ow04_initial_settlement_cases.py').read_text(), 'proposal.py', 'exec')
    exp = cases.expected()
    for path, sha in exp['source_pins'].items():
        assert digest(PROPOSALS / path) == sha, ('OW04_INITIAL_SOURCE_PIN_CHANGED', path)
    planned = cases.cases(None, date(2026, 10, 20))
    assert [key for key, _ in planned] == list(cases.NATIVE_IDS)
    assert len(planned) == len({key for key, _ in planned}) == 12
    assert [fn.__defaults__[0]['id'] for _, fn in planned] == list(cases.NATIVE_IDS)
    # No callable is invoked: None cannot act as a database cursor.
    packets = []
    ident = lambda n: str(n) * 8 + '-' + str(n) * 4 + '-4' + str(n) * 3 + '-8' + str(n) * 3 + '-' + str(n) * 12
    sale, customer, bank, liability, allocation, location, cohort, returned, refund = [ident(n) for n in range(1, 10)]
    days = {'D0': '2026-10-13', 'D1': '2026-10-14', 'D2': '2026-10-15', 'D3': '2026-10-16'}
    sha = lambda label: hashlib.sha256(('SYNTHETIC_WIRE_ONLY:' + label).encode()).hexdigest()
    for gold in exp['cases']:
        x = dict(dates=days, f=dict(sale=sale, customer=customer, bank=bank), return_version='9007199254740993',
            return_payload=dict(sale_id=sale, review_token='a' * 32, change_reason='Explicit physical source return reviewed',
                return_number='WIRE-' + gold['id'], physical_at=days['D2'] + 'T12:00:00.123456+07:00',
                notes=None, items=[dict(allocation_id=allocation, location_id=location, qty_pcs='1',
                    quality_grade='GRADE_A', refund_amount='200', notes=None)]))
        query = cases._input(x, gold, dict(id=liability))
        binding = {key: sha(key) for key in ('immutable_source_sha256', 'current_state_sha256', 'draft_sha256',
            'choice_sha256', 'projection_sha256', 'authority_sha256', 'period_sha256', 'dependency_sha256', 'quote_sha256')}
        quote = dict(contract_version='cp7.sales-return-settlement-quote.v1', kind='QUOTE', read_only=True,
            business_DML=False, captured_at='2026-10-20T00:00:00Z', input_echo=query,
            source=dict(sale_id=sale, sale_number='SYNTHETIC-WIRE', customer_id=customer, customer_name='Wire fixture',
                row_version=query['expected_version'], review_token=query['review_token']), binding=binding,
            has_recognition_effect=True, current_credit_amount=gold['current_credit_amount'],
            components=[dict(component_key=sha('component'), economic_date=days['D2'], book_date=days[gold['return_pair'][1]],
                signed_amount=gold['current_credit_amount'], support_sha256=sha('support'))],
            return_projection=dict(economic_date=days['D2'], prior_causal=dict(contract_version='ow04.prior-causal-book-proof.v1',
                scope='PRIOR_CAUSAL_SALE_RETURN', state='DATED', causal_book_floor=days[gold['prior_causal_book_floor']],
                proof_sha256=sha('prior')), journal_effect='JOURNAL_EXPECTED', planned_book_date=days[gold['return_pair'][1]],
                return_amount='200.00', hpp_amount='10.00', receivable_account_id=ident(9)),
            totals=dict(before=gold['before'], after=gold['after']),
            credit_account=dict(id=liability, code='EXPLICIT-CREDIT', name='Credit wire', facts_sha256=sha('credit')),
            cash_account=None, refund_projection=None,
            capabilities=dict(record_return=True, recognize_credit=True, refund_cash=gold['mode'] == 'REFUND'),
            readiness=dict(state='READY', issues=[]))
        if gold['mode'] == 'REFUND':
            quote['cash_account'] = dict(id=bank, code='EXPLICIT-BANK', name='Cash wire', facts_sha256=sha('cash'))
            quote['refund_projection'] = dict(amount=gold['refund_amount'], physical_at=query['settlement']['refund_physical_at'],
                economic_date=days['D2'], book_date=days[gold['refund_pair'][1]], safe_capacity=gold['refund_amount'], capacity_sha256=sha('capacity'))
        envelope = cases._envelope(query, quote)
        assert set(envelope) == {'document', 'expected_version'}
        assert envelope['expected_version'] == '9007199254740993'
        assert set(envelope['document']) == {'sale_id', 'review_token', 'return_number', 'physical_at', 'notes', 'items', 'change_reason', 'settlement', 'quote_sha256'}
        assert not {'amount', 'components', 'economic_date', 'book_date', 'source_journal_id'} & set(envelope['document']['settlement'])
        request = ident(1)
        outcome = dict(contract_version='cp7.sales-return-settlement-outcome.v1', kind='COMMITTED_OUTCOME', action='RETURN_SETTLEMENT',
            request_id=request, sale_id=sale, return_id=returned, return_status='POSTED', row_version='9007199254740994', family_ordinal='1',
            credit_id=cohort, refund_event_id=refund if gold['mode'] == 'REFUND' else None, quote_sha256=binding['quote_sha256'],
            projection_sha256=binding['projection_sha256'], actual_manifest_sha256=sha('actual'),
            projection_actual_proof_sha256=sha('mapping'), production_go=False)
        cases._assert_outcome(outcome, request, envelope, quote, gold['mode'])
        packets.append(dict(id=gold['id'], query=query, quote=quote, envelope=envelope, request=request, outcome=outcome))
    wire = HERE / 'SYNTHETIC_WIRE_ONLY.json'
    wire.write_text(json.dumps(dict(classification='SYNTHETIC_WIRE_COMPATIBILITY_ONLY_NOT_NATIVE', packets=packets), indent=2) + '\n')
    # Execute the actual unchanged UI proposal parser and commit builder. This
    # checks wire compatibility, not account, financial or source authority.
    js = '''
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const ui = await import(pathToFileURL(process.argv[2]).href);
const input = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
for (const p of input.packets) {
  ui.parseQuoteInput(p.query);
  const q = ui.parseSettlementQuote(p.quote, p.query);
  assert.deepEqual(ui.commitIntent(q), {action:'RETURN_SETTLEMENT',payload:p.envelope,expectedVersion:null});
  ui.parseSettlementOutcome(p.outcome,p.request,p.envelope);
}
console.log(JSON.stringify({classification:'ACTUAL_UI_PARSER_SYNTHETIC_WIRE_ONLY_NOT_NATIVE',packets:input.packets.length,status:'PASS'}));
'''
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    executed = subprocess.run(['node', '--experimental-strip-types', '--input-type=module', '-',
        str(PROPOSALS / 'ui/salesReturnSettlementProposal.ts'), str(wire)], input=js, text=True, capture_output=True, env=env)
    (HERE / 'ui-wire.stdout.log').write_text(executed.stdout)
    (HERE / 'ui-wire.stderr.log').write_text(executed.stderr)
    assert executed.returncode == 0, ('UI_WIRE_CHECK_PROCESS_FAILED', executed.stderr[-3000:])
    result = dict(classification='SOURCE_ONLY_SYNTAX_IMPORT_REGISTRATION_AND_UI_WIRE_NOT_NATIVE',
        syntax='PASS', registration_count=12, registration_ids_exact=True, closures_bound_separately=True,
        registration_connected=False, actual_ui_wire=json.loads(executed.stdout.strip().splitlines()[-1]),
        expected_sha256=digest(HERE / 'EXPECTED.json'), test_module_sha256=digest(HERE / 'cp7_ow04_initial_settlement_cases.py'),
        source_pins=exp['source_pins'], native_executed=False, Native_PASS_claimed=False,
        required_runtime_preconditions=['complete owning OW04 bundle installed', 'closed disposable Native harness cursor',
            'serialized period fixtures', 'actual fresh eligible account quote and settlement; no skipping/refusal counted PASS'])
    (HERE / 'STATIC_RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    try:
        main()
    except Exception:
        failure = dict(classification='SOURCE_ONLY_CHECK_FAILURE_NOT_NATIVE', traceback=traceback.format_exc(), native_executed=False)
        first = HERE / 'FIRST_STATIC_FAILURE.json'
        if not first.exists():
            first.write_text(json.dumps(failure, indent=2) + '\n')
        raise
