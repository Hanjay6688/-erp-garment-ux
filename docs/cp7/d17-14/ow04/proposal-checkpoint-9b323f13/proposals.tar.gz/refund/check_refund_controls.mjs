// ISOLATED SYNTHETIC MECHANICS. No Native writer, auth/permission callback,
// coordinator or cash guard is stubbed. A successful refund is NOT executed.
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';

const directory=dirname(fileURLToPath(import.meta.url));
const parent=dirname(directory);
const {PGlite}=await import(process.env.PGLITE_MODULE??process.env.OW04_PGLITE_MODULE??
 '/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js');
const sha=s=>createHash('sha256').update(s).digest('hex');
const expectedText=await readFile(resolve(directory,'EXPECTED.json'),'utf8');
const expected=JSON.parse(expectedText);
const additionalText=await readFile(resolve(directory,'ADDITIONAL_EXPECTED.json'),'utf8');
const additional=JSON.parse(additionalText);
const journalExpectedText=await readFile(resolve(directory,'JOURNAL_EXPECTED.json'),'utf8');
const journalExpected=JSON.parse(journalExpectedText);
const sourceCountersText=await readFile(resolve(directory,'SOURCE_COUNTERS.json'),'utf8');
const sourceCounters=JSON.parse(sourceCountersText);
const files=['ledger/01_immutable_facts.proposal.sql','ledger/02_uuid_poster.proposal.sql',
 'readers/02_materialized_profile.proposal.sql','admission/01_typed_context_and_preclaim.proposal.sql',
 'kernel/kernel.sql','refund/01_initial_refund.proposal.sql'];
const sources=await Promise.all(files.map(f=>readFile(resolve(parent,f),'utf8')));
const sourcePins=Object.fromEntries(files.map((f,i)=>[f,sha(sources[i])]));
const db=new PGlite();
const cases=[];
let step='DDL_SCAFFOLD_ONLY';
const q=(sql,args=[])=>db.query(sql,args);
const one=async(sql,args=[])=>(await q(sql,args)).rows[0].value;
const pass=(name,observed)=>cases.push({name,status:'PASS',...(observed===undefined?{}:{observed})});
const refused=async(name,fn,code)=>{
 step=name;let caught;
 try{await fn();}catch(e){caught=e;}
 assert(caught,`${name}: required refusal absent`);
 if(code)assert(caught.message.includes(code),`${name}: ${caught.message}`);
 pass(name,{refusal:code??caught.code});
};
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;

try{
 await db.exec(`create role anon;create role authenticated;create role service_role;
 create role cp7_capture;create role cp7_sales_read;create role cp7_sales_write;
 create schema erp;create schema auth;create schema cp7_sales;create schema cp7_guard;
 create schema cp7_note;create schema cp7_sales_return_correction;create schema cp7_payment_correction;
 create table erp.customers(id uuid primary key);
 create table erp.sales_headers(id uuid primary key,customer_id uuid,status text);
 create table erp.sales_returns(id uuid primary key,sale_id uuid,customer_id uuid,physical_at timestamptz,status text);
 create table erp.chart_accounts(id uuid primary key,is_active boolean,is_postable boolean,account_type text,normal_balance text);
 create table erp.cash_accounts(id uuid primary key,coa_account_id uuid,is_active boolean);
 create table erp.accounting_account_mappings(mapping_key text primary key,account_id uuid);
 create table erp.accounting_period_control(singleton_id integer primary key);
 create table erp.journal_entries(id uuid primary key,source_type text,source_id uuid,economic_date date,
  transaction_date date,status text,reversal_of_id uuid,posting_at timestamptz);
 create table erp.journal_lines(id uuid primary key,journal_entry_id uuid,account_id uuid,customer_id uuid,
  description text,debit numeric,credit numeric,vendor_id uuid,contractor_id uuid,po_id uuid,product_id uuid);
 create table erp.sales_items(id uuid primary key,sale_id uuid);
 create table erp.sale_stock_allocations(id uuid primary key,sale_item_id uuid,lot_id uuid);
 create table erp.sales_return_items(id uuid primary key,return_id uuid);
 create table erp.fg_lots(id uuid primary key);create table erp.fg_stock_movements(id uuid primary key,lot_id uuid,qty_signed numeric,unit_hpp_snapshot numeric);
 create table erp.sales_payments(id uuid primary key,sale_id uuid,replaces_payment_id uuid,amount numeric,status text);
 create table erp.sales_payment_posting_facts(payment_id uuid primary key);
 create table erp.sales_payment_reversal_facts(payment_id uuid primary key);
 create table erp.initial_import_prepayment_payments(payment_id uuid primary key,advance_id uuid);
 create table erp.initial_import_prepayments(id uuid primary key);
 create table cp7_sales.requests(actor uuid,request_id uuid,action text,payload jsonb,expected_version text,response jsonb);
 create table cp7_sales.command_context(backend_pid integer,transaction_id bigint,actor uuid,sale_id uuid,action text);
 create table cp7_guard.compound_scope(txid bigint);
 create table cp7_note.revisions(root_sale_id uuid,previous_sale_id uuid,replacement_sale_id uuid,revision bigint);
 create table cp7_note.journal_restatements(previous_sale_id uuid,neutral_journal_id uuid,effective_journal_id uuid);
 create table cp7_sales_return_correction.journal_restatements(original_return_id uuid,neutral_journal_id uuid,effective_journal_id uuid);
 create table cp7_payment_correction.links(original_id uuid,time_neutral_id uuid,effective_inverse_id uuid);
 `);
 // No test objects emulate money/auth: only empty FK/composite scaffolding.
 for(let i=0;i<sources.length;i++){
  step=`DDL:${files[i]}`;
  const barrier=/do \$not_an_installer\$[\s\S]*?end \$not_an_installer\$;/g;
  if(files[i]!=='kernel/kernel.sql')assert.equal([...sources[i].matchAll(barrier)].length,1,'install barrier count');
  await db.exec(sources[i].replace(barrier,'-- Barrier removed in isolated in-memory DDL control only.'));
  pass(step);
 }
 const proof={contract_version:'ow04.initial-refund-operation-proof.v1',operation_id:id(20),cohort_id:id(9),
  actor:id(100),request_id:id(101),backend_pid:'123',transaction_id:'456',phase:'PREPOST',owning_action:'RETURN_SETTLEMENT',
  stage:'NATIVE',initial_plan_id:id(10),family_id:id(8),family_root_sale_id:id(1),current_leaf_id:id(1),
  source_sale_id:id(1),source_return_id:id(2),full_k:'200.00',cash_account_id:id(7),physical_at:'2026-10-19T05:00:00.000000Z',
  reason:'Actual initial full refund',reference:'R-1',payload_sha256:'a'.repeat(64),quote_sha256:'b'.repeat(64),
  source_lock_sha256:'c'.repeat(64),projection_sha256:'d'.repeat(64),recognition_manifest_sha256:'e'.repeat(64),
  materialization_ordinal:'2',required_book_floor:'2026-10-20',book_floor_manifest_sha256:'9'.repeat(64),authority_sha256:'f'.repeat(64),cash_snapshot_sha256:'0'.repeat(64)};
 for(const[name,p]of[['VALID_KNOWN_PROOF',proof],['VALID_NULL_REFERENCE',{...proof,reference:null}]]){
  step=name;await q('select cp7_credit.initial_refund_proof_shape($1::jsonb)',[JSON.stringify(p)]);pass(name);
 }
 assert.deepEqual(cases.slice(-2).map(x=>x.name),expected.proof_accept);
 const malformed={
  EXTRA_FIELD:{...proof,book_date:'2026-10-20'},MISSING_FIELD:Object.fromEntries(Object.entries(proof).filter(([k])=>k!=='physical_at')),
  NULL_PHASE:{...proof,phase:null},BOOLEAN_STAGE:{...proof,stage:true},NUMERIC_COUNTER:{...proof,backend_pid:123},
  ZERO_FULL_K:{...proof,full_k:'0.00'},FRACTIONAL_CENT:{...proof,full_k:'200.001'},
  NONCANONICAL_PHYSICAL:{...proof,physical_at:'2026-10-19T12:00:00+07:00'},NULL_FLOOR:{...proof,required_book_floor:null},
  WRONG_ACTION:{...proof,owning_action:'PAYMENT'},WRONG_PHASE:{...proof,phase:'COMPLETE'}};
 assert.deepEqual(Object.keys(malformed),expected.proof_reject);
 for(const[name,p]of Object.entries(malformed))await refused(name,()=>q('select cp7_credit.initial_refund_proof_shape($1::jsonb)',[JSON.stringify(p)]),'CP7_CREDIT_REFUND_PROOF_');
 for(const c of expected.date_pairs){
  step=c.case;const b=await one('select cp7_credit.initial_refund_pair($1::timestamptz,$2::date,$3::date,$4::timestamptz)::text value',[c.physical,c.lawful,c.floor,c.clock]);
  assert.equal(b,c.expected);pass(c.case,b);
 }
 const dates={FUTURE_PHYSICAL:['2026-10-22T05:00:00Z','2026-10-22','2026-10-22','2026-10-21T05:00:00Z'],
  INFINITE_PHYSICAL:['infinity','2026-10-20','2026-10-20','2026-10-21T05:00:00Z'],
  NULL_SOURCE_FLOOR:['2026-10-19T05:00:00Z','2026-10-19',null,'2026-10-21T05:00:00Z'],
  FUTURE_BOOK_FLOOR:['2026-10-19T05:00:00Z','2026-10-19','2026-10-22','2026-10-21T05:00:00Z'],
  LAWFUL_BOOK_BEFORE_ECONOMIC:['2026-10-19T05:00:00Z','2026-10-18','2026-10-20','2026-10-21T05:00:00Z']};
 assert.deepEqual(Object.keys(dates),expected.date_reject);
 for(const[name,p]of Object.entries(dates))await refused(name,()=>q('select cp7_credit.initial_refund_pair($1::timestamptz,$2::date,$3::date,$4::timestamptz)',p),'CP7_CREDIT_REFUND_');
 const events=(rows,prefix)=>rows.map(([amount,economic_date,transaction_date],i)=>({id:prefix+i,amount,economic_date,transaction_date,source_sha256:'1'.repeat(64)}));
 for(const c of expected.capacity_cases){
  const fn=()=>one('select cp7_credit.initial_refund_capacity($1::jsonb,$2::jsonb,$3::date,$4::date,$5::numeric) value',
   [JSON.stringify(events(c.recognition,'I:')),JSON.stringify(events(c.consumptions,'C:')),c.economic,c.book,c.full_k]);
  if(c.expected==='PASS'){step=c.case;const got=await fn();assert.equal(got.current_balance,c.full_k);assert.equal(got.source_prefixes_nonnegative,true);pass(c.case,{minimum_available:got.minimum_available});}
  else await refused(c.case,fn,c.expected);
 }
 const noShift=sourceCounters.book_adaptation_cannot_move_economic_source;
 await refused('SOURCE_COUNTER_REFUND_ECONOMIC_MUST_NOT_SHIFT',()=>q(
  'select cp7_credit.initial_refund_capacity($1::jsonb,\'[]\'::jsonb,$2::date,$3::date,$4::numeric)',
  [JSON.stringify(events(noShift.recognition,'I:')),noShift.explicit_refund_economic,'2026-10-20',noShift.full_k]),'CP7_CREDIT_REFUND_DATED_CAPACITY');
 step='FIXED_LIABILITY_DEBIT_CASH_CREDIT';
 const lines=await one('select cp7_credit.initial_refund_lines($1,$2,$3,$4::numeric) value',[id(5),id(6),id(3),'200.00']);
 assert.deepEqual(lines,[{account_id:id(5),customer_id:id(3),description:'Kredit retur: pengembalian uang',debit:200,credit:0},
  {account_id:id(6),customer_id:id(3),description:'Kredit retur: pengembalian uang',debit:0,credit:200}]);pass(step);
 const badLines={ZERO:[id(5),id(6),id(3),'0'],NEGATIVE:[id(5),id(6),id(3),'-1'],NONFINITE:[id(5),id(6),id(3),'NaN'],
  FRACTIONAL_CENT:[id(5),id(6),id(3),'0.001'],COLLIDING_ACCOUNT:[id(5),id(5),id(3),'200'],
  MISSING_CUSTOMER:[id(5),id(6),null,'200'],NATIVE_TOTAL_OVERFLOW:[id(5),id(6),id(3),'1000000000000000000.00']};
 assert.deepEqual(Object.keys(badLines),expected.line_reject);
 for(const[name,p]of Object.entries(badLines))await refused('LINES_'+name,()=>q('select cp7_credit.initial_refund_lines($1,$2,$3,$4::numeric)',p),'CP7_CREDIT_REFUND_LINES_INVALID');
 step='SYNTHETIC_CONSTRAINED_FACTS_FOR_ANCESTRY';
 // Actual ledger constraints/immutability stay enabled. These rows are only
 // mechanical ancestry fixtures and confer no Native/operation authority.
 await db.exec('begin');
 await q('insert into erp.customers values($1)',[id(3)]);
 await q("insert into erp.sales_headers values($1,$2,'PAID')",[id(1),id(3)]);
 await q("insert into erp.sales_returns values($1,$2,$3,'2026-10-19T05:00:00Z','POSTED')",[id(2),id(1),id(3)]);
 for(const[n,type,normal]of[[4,'ASSET','DEBIT'],[5,'LIABILITY','CREDIT'],[6,'ASSET','DEBIT']])await q('insert into erp.chart_accounts values($1,true,true,$2,$3)',[id(n),type,normal]);
 await q('insert into erp.cash_accounts values($1,$2,true)',[id(7),id(6)]);
 const journals=[[11,'SALE',1,null],[12,'SALES_RETURN',2,null],[501,'CP7_CUSTOMER_CREDIT_REFUND',20,null],
  [502,'JOURNAL_REVERSAL',501,501],[503,'JOURNAL_REVERSAL',502,502],[504,'JOURNAL_REVERSAL',501,null],
  [505,'MISC',null,null],[506,'MISC',null,507],[507,'MISC',null,506],[508,'UNKNOWN_SOURCE',null,null]];
 for(const[n,type,source,rev]of journals)await q("insert into erp.journal_entries values($1,$2,$3,'2026-10-19','2026-10-20','POSTED',$4,'2026-10-21T00:00:00Z')",[id(n),type,source===null?null:id(source),rev===null?null:id(rev)]);
 await q(`insert into cp7_credit.return_families values($1,$2,1,$3,'NEW_POST','{}',$4,$5,$6,statement_timestamp())`,[id(8),id(1),id(2),'1'.repeat(64),id(100),id(101)]);
 await q(`insert into cp7_credit.return_family_members values($1,$2,'ORIGINAL',$3,$4,'{}',$5,$6,statement_timestamp())`,[id(8),id(2),id(12),'1'.repeat(64),id(100),id(101)]);
 await q(`insert into cp7_credit.cohorts values($1,$2,$3,$4,$5,$6,'{}',$7,'{}','REFUND',200,$8,$9,$10,$11,$11,$12,$13,statement_timestamp())`,
  [id(9),id(8),id(1),id(2),id(3),id(4),id(5),id(10),id(11),id(12),'1'.repeat(64),id(100),id(101)]);
 await q(`insert into cp7_credit.recognition_plans values($1,$2,'INITIAL','RETURN_SETTLEMENT',$3,$4,1,$5,$5,$6,'[]','[]','{}','ow04-2d-difference-v1',$5,$5,$5,$5,$5,200,false,0,0,statement_timestamp())`,[id(10),id(9),id(100),id(101),'1'.repeat(64),id(1)]);
 await q(`insert into cp7_credit.consumption_events(id,cohort_id,event_kind,amount,economic_date,transaction_date,cash_account_id,journal_id,source_sha256,lines_sha256_pg,actor,request_id,reason)
  values($1,$2,'REFUND',200,'2026-10-19','2026-10-20',$3,$4,$5,$5,$6,$7,'Synthetic ancestry fact only')`,[id(21),id(9),id(7),id(508),'1'.repeat(64),id(100),id(101)]);
 await db.exec('commit');
 step='ACTUAL_SOURCE_FAMILY_READ_HELPER_SYNTHETIC_ROWS';
 const memberText=await readFile(resolve(parent,'source/member-proof.sql'),'utf8');
 const familyFunction=memberText.match(/create function ow04_source_proposal\.family_read_v1\(p_sale uuid\)[\s\S]*?end \$\$;/);
 assert(familyFunction,'actual pure source-family helper not found');
 await db.exec('create schema ow04_source_proposal;'+familyFunction[0]);
 sourcePins['source/member-proof.sql']=sha(memberText);
 await q("insert into erp.sales_payments values($1,$2,null,1000,'POSTED')",[id(30),id(1)]);
 await q('insert into erp.sales_payment_posting_facts values($1)',[id(30)]);
 await q("insert into erp.journal_entries values($1,'SALES_PAYMENT',$2,'2026-10-18','2026-10-20','POSTED',null,'2026-10-21T00:00:00Z')",[id(31),id(30)]);
 await q("insert into erp.journal_lines(id,journal_entry_id,account_id,customer_id,debit,credit)values($1,$2,$3,$4,1000,0)",[id(32),id(31),id(6),id(3)]);
 await q('insert into erp.sales_items values($1,$2)',[id(43),id(1)]);
 await q('insert into erp.fg_lots values($1)',[id(41)]);
 await q('insert into erp.sale_stock_allocations values($1,$2,$3)',[id(42),id(43),id(41)]);
 await q('insert into erp.fg_stock_movements values($1,$2,5,10)',[id(40),id(41)]);
 const nativeSnapshot=()=>one('select cp7_credit.initial_refund_native_snapshot($1) value',[id(1)]);
 const baseline=await nativeSnapshot();assert.deepEqual(await nativeSnapshot(),baseline);
 const detectorCases=[
  ['PAYMENT_AMOUNT_CHANGE_DETECTED','update erp.sales_payments set amount=999 where id=$1','update erp.sales_payments set amount=1000 where id=$1',id(30)],
  ['PAYMENT_STATUS_CHANGE_DETECTED',"update erp.sales_payments set status='REVERSED'where id=$1","update erp.sales_payments set status='POSTED'where id=$1",id(30)],
  ['PAYMENT_JOURNAL_LINE_CHANGE_DETECTED','update erp.journal_lines set debit=999 where id=$1','update erp.journal_lines set debit=1000 where id=$1',id(32)],
  ['FROZEN_STOCK_HPP_CHANGE_DETECTED','update erp.fg_stock_movements set unit_hpp_snapshot=11 where id=$1','update erp.fg_stock_movements set unit_hpp_snapshot=10 where id=$1',id(40)],
 ];
 assert.deepEqual(detectorCases.map(x=>x[0]),additional.cases);
 for(const[name,mutation,restore,ident]of detectorCases){
  step=name;await q(mutation,[ident]);assert.notDeepEqual(await nativeSnapshot(),baseline);await q(restore,[ident]);assert.deepEqual(await nativeSnapshot(),baseline);pass(name);
 }
 const ancestry={DIRECT_REFUND:501,INVERSE:502,INVERSE_OF_INVERSE:503,SOURCE_ID_ONLY_ANCESTOR:504,FACT_LINKED_UNKNOWN_SOURCE:508,UNRELATED:505,UNRELATED_CYCLE:506};
 for(const[name,n]of Object.entries(ancestry)){
  const fn=()=>q('select cp7_credit.assert_no_generic_initial_refund_reverse($1)',[id(n)]);
  if(expected.ancestry[name]==='REFUSE')await refused(name,fn,'CP7_CREDIT_REFUND_USE_OWNING_INVERSE_WORKFLOW');
  else{step=name;await fn();pass(name);}
 }
 step='SYNTHETIC_STORED_REFUND_READ_VERIFIER';
 await q(`insert into cp7_credit.initial_refund_operations(id,cohort_id,initial_plan_id,actor,request_id,backend_pid,transaction_id,
  root_sale_id,current_leaf_id,full_amount,cash_account_id,physical_at,reason,reference,payload_sha256,quote_sha256,
  source_lock_sha256,projection_sha256,recognition_manifest_sha256,required_book_floor,book_floor_manifest,materialization_ordinal,authority_snapshot,cash_account_snapshot)
  values($1,$2,$3,$4,$5,pg_backend_pid(),txid_current(),$6,$6,200,$7,'2026-10-19T05:00:00Z','Synthetic stored-line verifier',null,
   $8,$8,$8,$8,$8,'2026-10-20','{}',2,'{}',cp7_credit.initial_refund_cash_snapshot($7))`,
  [id(60),id(9),id(10),id(100),id(101),id(1),id(7),'a'.repeat(64)]);
 await q("insert into erp.journal_entries values($1,'CP7_CUSTOMER_CREDIT_REFUND',$2,'2026-10-19','2026-10-20','POSTED',null,'2026-10-21T00:00:00Z')",[id(601),id(60)]);
 for(const[n,account,debit,credit]of[[602,5,200,0],[603,6,0,200]])await q(
  "insert into erp.journal_lines(id,journal_entry_id,account_id,customer_id,description,debit,credit)values($1,$2,$3,$4,'Kredit retur: pengembalian uang',$5,$6)",
  [id(n),id(601),id(account),id(3),debit,credit]);
 const verifyStored=()=>one("select cp7_credit.verify_initial_refund_journal($1,$2,'2026-10-20') value",[id(60),id(601)]);
 const storedHash=await verifyStored();assert.match(storedHash,/^[0-9a-f]{64}$/);pass('VALID_FIXED_STORED_JOURNAL_READ_ONLY',storedHash);
 const journalMutations=[
  ['WRONG_BOOK',"update erp.journal_entries set transaction_date='2026-10-19'where id='"+id(601)+"'","update erp.journal_entries set transaction_date='2026-10-20'where id='"+id(601)+"'"],
  ['WRONG_SOURCE',"update erp.journal_entries set source_id='"+id(61)+"'where id='"+id(601)+"'","update erp.journal_entries set source_id='"+id(60)+"'where id='"+id(601)+"'"],
  ['WRONG_DIRECTION',"update erp.journal_lines set debit=0,credit=200 where id='"+id(602)+"'","update erp.journal_lines set debit=200,credit=0 where id='"+id(602)+"'"],
  ['WRONG_CUSTOMER',"update erp.journal_lines set customer_id='"+id(4)+"'where id='"+id(603)+"'","update erp.journal_lines set customer_id='"+id(3)+"'where id='"+id(603)+"'"],
  ['EXTRA_DIMENSION',"update erp.journal_lines set vendor_id='"+id(100)+"'where id='"+id(603)+"'","update erp.journal_lines set vendor_id=null where id='"+id(603)+"'"],
  ['EXTRA_LINE',"insert into erp.journal_lines(id,journal_entry_id,debit,credit)values('"+id(604)+"','"+id(601)+"',0,0)","delete from erp.journal_lines where id='"+id(604)+"'"],
  ['UNBOUND_INVERSE',"insert into erp.journal_entries(id,source_type,source_id,reversal_of_id)values('"+id(605)+"','JOURNAL_REVERSAL','"+id(601)+"','"+id(601)+"')","delete from erp.journal_entries where id='"+id(605)+"'"],
  ['REVERSED_STATUS',"update erp.journal_entries set status='REVERSED'where id='"+id(601)+"'","update erp.journal_entries set status='POSTED'where id='"+id(601)+"'"],
 ];
 assert.deepEqual(journalMutations.map(x=>x[0]),journalExpected.malformed);
 for(const[name,mutation,restore]of journalMutations){
  step='STORED_'+name;await db.exec(mutation);await refused(step,verifyStored,journalExpected.malformed_refusal);await db.exec(restore);assert.equal(await verifyStored(),storedHash);
 }
 const immutableControls={UPDATE:()=>q('update cp7_credit.initial_refund_operations set reason=reason where id=$1',[id(60)]),
  DELETE:()=>q('delete from cp7_credit.initial_refund_operations where id=$1',[id(60)]),
  TRUNCATE:()=>db.exec('truncate cp7_credit.initial_refund_operations cascade')};
 assert.deepEqual(Object.keys(immutableControls),journalExpected.immutable_operation);
 for(const[name,fn]of Object.entries(immutableControls))await refused('IMMUTABLE_OPERATION_'+name,fn,journalExpected.immutable_refusal);
 step='MISSING_COORDINATOR_REFUSES_ACTUAL_ENTRY';
 const before=await one('select count(*)::integer value from cp7_credit.consumption_events');
 await refused(step,()=>q('select cp7_credit.post_initial_refund($1,$2)',[id(20),id(9)]),expected.required_missing_callback);
 assert.equal(await one('select count(*)::integer value from cp7_credit.consumption_events'),before);
 step='PRIVATE_UUID_ONLY_SIGNATURE';
 assert.deepEqual((await q("select oid::regprocedure::text signature from pg_proc where pronamespace='cp7_credit'::regnamespace and proname='post_initial_refund'")).rows.map(x=>x.signature),[expected.private_writer_signature]);pass(step);
 step='PRIVATE_OWNERS_RLS_AND_NO_CLIENT_EXEC_DML';
 const functions=(await q("select oid::regprocedure::text signature,pg_get_userbyid(proowner)owner from pg_proc where pronamespace='cp7_credit'::regnamespace and proname in('refund_physical_text','initial_refund_proof_shape','initial_refund_pair','initial_refund_capacity','initial_refund_lines','initial_refund_cash_snapshot','initial_refund_recognition','initial_refund_native_snapshot','require_refund_coordinator','assert_initial_refund_operation','assert_initial_refund_bound_post','initial_refund_bound_book_date','initial_refund_bound_audit','verify_initial_refund_journal','post_initial_refund','assert_no_generic_initial_refund_reverse')")).rows;
 assert.equal(functions.length,16);
 for(const f of functions){assert.equal(f.owner,'postgres');for(const r of['anon','authenticated','service_role','cp7_capture','cp7_sales_read','cp7_sales_write'])assert.equal(await one("select has_function_privilege($1,$2,'EXECUTE') value",[r,f.signature]),false);}
 for(const t of['initial_refund_operations','initial_refund_posting_scope']){
  const row=(await q('select pg_get_userbyid(relowner)owner,relrowsecurity from pg_class where oid=$1::regclass',[`cp7_credit.${t}`])).rows[0];
  assert.equal(row.owner,'postgres');assert.equal(row.relrowsecurity,true);
  for(const r of['anon','authenticated','service_role','cp7_capture','cp7_sales_read','cp7_sales_write'])assert.equal(await one("select has_table_privilege($1,$2,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE') value",[r,`cp7_credit.${t}`]),false);
 }pass(step);
 step='NO_NATIVE_AUTH_OR_COORDINATOR_STUBS';
 assert.equal(await one("select count(*)::integer value from pg_proc where pronamespace in('erp'::regnamespace,'auth'::regnamespace)"),0);
 assert.equal(await one("select to_regprocedure('cp7_credit.assert_refund_operation_v1(uuid,uuid,text)')is null value"),true);
 assert.equal(await one("select to_regprocedure('cp7_credit._post_initial_refund_bound(text,uuid,date,text,jsonb)')is null value"),true);pass(step);
 const result={scope:expected.scope,status:'PASS',count:cases.length,cases,expected_sha256:sha(expectedText),additional_expected_sha256:sha(additionalText),journal_expected_sha256:sha(journalExpectedText),source_counters_sha256:sha(sourceCountersText),source_sha256:sourcePins,
  driver_sha256:sha(await readFile(fileURLToPath(import.meta.url),'utf8')),Native_executed:false,positive_posting_proven:false,
  coordinator_callback_defined:false,Native_or_auth_writer_stub_defined:false,feature_installed:false};
 await writeFile(resolve(directory,'RESULT.json'),JSON.stringify(result,null,2)+'\n');
 process.stdout.write(JSON.stringify({scope:result.scope,status:'PASS',count:cases.length,Native_executed:false,positive_posting_proven:false})+'\n');
}catch(error){
 const failure={scope:expected.scope,status:'FAIL',step,message:error.message,code:error.code,cases,source_sha256:sourcePins,Native_executed:false,positive_posting_proven:false};
 try{await writeFile(resolve(directory,'FIRST_FAILURE.json'),JSON.stringify(failure,null,2)+'\n',{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;}
 await writeFile(resolve(directory,'LAST_FAILURE.json'),JSON.stringify(failure,null,2)+'\n');
 process.stderr.write(JSON.stringify(failure)+'\n');process.exitCode=1;
}finally{await db.close();}
