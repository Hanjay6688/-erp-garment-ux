# Private initial Native-credit refund proposal

Nothing here is installed. `01_initial_refund.proposal.sql` raises before DDL.
The entry is `cp7_credit.post_initial_refund(operation_uuid, cohort_uuid)`.
It accepts no caller money, accounts, dates, journal UUID or lines. The protected
operation is minted by the owning RETURN coordinator, inside its actual NATIVE
request and Native RETURN context, after every recognition part has its journal.

The first REFUND consumes the entire freshly proved positive K. Existing
consumption/history, zero K, later adjustments and automatic second refunds
refuse. It posts Dr the cohort's actual credit liability / Cr the explicitly
selected configured cash COA, then an immutable REFUND consumption. It leaves
recognition I, incoming U and original Native payments unchanged. Actual Native
payment documents/facts/journals, stock and HPP are compared before/after;
the stored refund journal is checked for exact source, pair, two lines and all
dimensions. The source ID and consumption ID are the operation UUID.

`assert_refund_operation_v1(uuid,uuid,text)` is a REQUIRED owning coordinator
callback with PREPOST/POSTPOST phases and the exact closed 31-field proof in SQL.
No success stub is supplied. Its owner is postgres, SECURITY DEFINER, VOLATILE,
empty search_path, with no browser/service/sales EXECUTE. The proof validates
actual source, complete INITIAL recognition, current full K, explicit choice,
owned request/scopes and all already-held locks. It revalidates current facts
after period and CASH waits without acquiring earlier-order locks. Data-complete
materialization is distinct from the final command receipt and live authority.

The coordinator's `initial_refund_book_plan_v1` supplies the complete immutable
`book_floor_manifest`: earliest lawful book candidate for the fixed actual
refund economic date and full K, from Native resolver/causal floor plus actual
recognition book boundaries, checked against every later joint cutoff. Quote,
operation and callback bind its entire candidate/capacity manifest, not K alone.
The poster independently checks actual I/C capacity. Period/manifest drift
refuses and requires replanning. No refund economic date shifts.

The canonical-only alternative is incomplete after reopen. A sale/payment on
book D3 can require a refund economic D2/book D3 even when today's resolver
returns D2. A RETURN book day alone is also insufficient when actual recognition
is delayed by a payment's book day. Literal counters are in SOURCE_COUNTERS.json.
`02_native_refund_transform.py` derives a separate narrowly bound Native copy:
fixed refund source/operation and exact lines; after Native period SHARE it uses
the proved book pair. Native internal admission, cent/balance/source guards,
actual inserts, cash trigger and daily balances remain. Exact installed
definition/owner/ACL/config must match the approved capture; release text is
never accepted as that capture. No Native function is replaced by this proposal.

The refund opens no cash compound scope; ambient compound admission refuses.
It takes the same cash COA advisory lock and rechecks current owning rights
before Native posting. Generic reversals and inverse descendants must use the
owning source workflow; the cycle-safe guard is composed with the existing
Native/private inverse guards. No refund-reversal writer is invented here.

Run `node check_refund_controls.mjs` from this directory (optional PGLITE_MODULE
or OW04_PGLITE_MODULE), and `python 02_native_refund_transform.py --static-check
/absolute/product/repo`. The controls exercise actual proposed SQL over explicitly
synthetic rows: closed proofs, date/capacity arithmetic, exact journal read
verification, immutability, conservation detection, ancestry and private ACLs.
They define no Native writer or permission/coordinator success callback. The
missing coordinator refuses the real entry. They do not prove a Native refund,
cash balance/race/revocation, complete API or feature installation.

Root must compose the actual source/plan/provenance callbacks and source-bound
book planner, approved Native copy, current-reader updates, context-free deferred
closure, exact install/restore, real cash/period races and source navigation.
The generic cash/journal reports can read a genuine refund journal; a credit
workspace/public facade and complete route remain separate integration work.
