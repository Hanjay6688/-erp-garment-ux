# OW04 settlement section — outside proposal only

`SalesReturnSettlementSection.tsx` is a controlled React section, not an installed
screen or a backend. It imports the final typed prior-proof parser at
`../ui/salesReturnSettlementProposal.ts` (SHA
`fa9e916cdfddeae72cfe842d4dd40c74a257f541396fa9ea55f09694ad7463cf`). It uses the
existing ERP WIB conversion and exact decimal display helpers. It adds no
financial date resolver, recognition formula, account default or mutation UUID.

`EXPECTED_DOM.json` was saved before the component or tests. The first run had
24 passing and four failing cases because the test helper selected the outer
labelled section instead of the mode `select`. The initial source, complete
stdout/stderr and actual exit remain in `first-source/` and `first-dom.*`.
Correcting that selector retained every blank, explicit-choice and time oracle;
the 28-case result remains in `second-dom.*`.

A subsequent literal review-label check exposed a real omission: the label
named the selected accounts but referred to dates without showing them. The
complete first-red result is 1 failed / 28 passed, retained in
`review-dates-first-red.*` and `before-review-dates/`. The label now shows the
exact server return/refund economic and book dates. The final 29-case DOM result
has complete stdout/footer, empty stderr and recorded exit0; strict TypeScript
has a separate exit0 record. These are synthetic jsdom/parser checks, not
Native source, permission, browser, journal, cash or financial-posting evidence.

## Parent contract and integration

The parent supplies `source`, complete normalized `input: QuoteInput | null`,
explicit `choice`, monotonic `generation`, its actual opaque `parentReadTicket`
and `isReadCurrent`, current `authorityScope`, and the global
`locked/stale/pendingEnvelope` flags. The generic ticket type accepts the existing
hook's real object ticket without serializing session data. A local string is
only a parser/read-fence label. The actual ticket validator remains necessary at
both response acceptance and submit.

Map the owning invoice summary explicitly: `sale_id = source.id`,
`sale_number = source.number`, and actual customer, row-version and review-token
fields. The parent owns draft validation and canonical cent normalization. A
complete input must repeat the exact controlled choice and current source
identity; otherwise the quote button is disabled. Parent increments generation
on every physical-return or choice edit, including changes that later return to
the same values. `onChoiceChange` receives a complete cloned choice; all fields
start with `blankChoice()`.

`getQuote` and `getAccountOptions` must return the raw data body from the proposed
read endpoints and reject actual API errors, preserving status/code for access
retirement. They are not implemented here. Account queries use the existing
source identity, exact search and 25-row offsets. The section never selects the
first account, invents eligibility or shows an account UUID as its label.

`onInvalid` must retire the parent's owning source/read proof and other visible
source facts. The section independently hides its own quote, source names,
financial facts and account pages on current refusals. It renders safe messages
instead of raw SQL/server error details. It retains controlled operator inputs;
the parent owns their authorized retention and form retirement.

`onIntent` receives **only** `commitIntent(quote).payload`, the unchanged
`{document, expected_version}` envelope. The parent calls its existing SALES
mutation/recovery hook with the fixed action `RETURN_SETTLEMENT`; that hook owns
the UUID, persistence, actor/session guards, Web Lock, dispatch, replay and
receipt validation. No in-memory quote is required for recovery. Do not wrap the
payload in new envelope metadata or issue a second UUID after a lost reply.

The local one-emit latch closes the interval before the parent persists its
global pending state. It intentionally remains locked across later prop edits.
After a proved final outcome and authoritative source reload, the parent closes
or remounts the form. Do not key/remount it on ordinary input generations or
uncertain responses to clear that latch. Other SALES forms must respect the same
global pending envelope.

All section buttons use `type="button"` so it can sit inside the existing return
form. When installing, replace that form's old review/submit path with this
section's owning settlement submission. Preserve allocation, receiver, grade,
quantity, physical time and notes controls; do not leave a second legacy submit
button that bypasses the quote. Keep legacy public RETURN's omitted-required-
choice negative test. Root owns the actual `SalesReturnPanel` and
`ConnectedSalesPage` routing/recovery changes.

The relative helper imports point to the current repository solely for this
outside proposal. On installation use the real in-repository helper paths and
parser/module ownership, then run the actual app's tests/build. The current
configs and result commands retain the exact proposal paths for reproduction.

## Facts and fences exercised

The section shows server K, separately labelled P/U/I/effective settlement/AR,
the signed dated recognition vector, vetted account snapshots and independent
cash-refund time/capacity. It has no editable monetary plan, book date, journal
line or future Native ID. Negative recognition adjustments are not cash refunds.
Unknown source facts never become numeric0 or an ordinary-return fallback.

The new typed prior proof stays separate from the projected journal: PF01
ABSENT/noJ, PF02 ABSENT/new HPP-only J and PF04 DATED/current-HPP0 noJ render
without inventing a financial date. Exact large signed components are rendered
through the existing string decimal formatter, without Number rounding.

Every observed input, source, authority or lock transition produces a new local
read token. Old facts are hidden during render before effects. Async acceptance
also checks that token, request sequence and live actual parent ticket. A local
choice barrier hides facts even before a deferred controlled parent updates.
Final submit rechecks the latest props/ticket and exact quote context. Deferred
promise, A→B→A, 401/403/42501, malformed response, lock/unlock and double-click
cases exercise these paths through real React/jsdom events.

Native credit balance/apply/refund/undo workspaces, source resolver routes,
dependency graphs/correction instructions, owning quote/writer callbacks,
backend closure and whole-flow Native/HTTP/browser/race evidence remain separate
integration work. These files do not establish OW04 completion.
