# OW04 Native fixture proposal, not an executed feature

Candidate source:b7fc541ca2b0221865ed7982155e844e1a9bed80; paid-return product
behavior remains the754f387a source. No active repo edit, Native session,
installation, quote, settlement, or positive feature PASS was performed here.

EXPECTED.json was frozen before executable setup/read code and peer exchange.
SHA256:f6d7efdde1a409094b8c5485fb7942209175bce1d869e8c05f1a1d097b7cadde.
The static SOURCE_CHECKS.json verifies syntax, retained helper names, exact
fixture/mapping declarations and literal money conservation. It is not a Native
receipt and does not compile SQL against an ERP catalog.

```bash
python /workspace/scratch/9442228ed2dc/ow04-proposals/native/check_proposal.py
```

The fixture makes found stock10 at explicit value10/PCS, sells5 at200, and records
payment1000 or900 through current accepted commands. A selected original
allocation returns1PCS with value200 into a distinct FG warehouse. That last
step is only a prospective intent in prepared(): the current paid-return guard
must still reject it without a settlement choice. No posted paid return is
seeded or fabricated.

| Payment P | Before return AR | Future CREDIT I | E after return | AR after return | Bank after CREDIT | Bank after full REFUND |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
|1000|0|200|800|0|1000|800|
|900|100|100|800|0|900|800|

Both modes leave source5PCS and returned1PCS, FG value60, COGS40, revenue800.
This is a found-stock source proof, not the E01 production-HPP fixture. Preserve
E01 separately. The full original payment header including POSTED status,
posting fact, original journal header including both dates/status/posting clock,
every journal line and the empty reversal-fact array must remain byte-identical
through settlement, credit usage/refund and consumer undo. Explicit correction
of the payment itself has a separate retained-history/status contract.

D0 is the actual Native WIB day minus7days. Stock is D-1, sale D0, payment D1,
prospective return D2. All physical times are explicit microsecond timestamps.
The fixture never modifies a stored source date to make an expectation pass.

| Profile | Actual SALE pair | Actual PAY pair | Current resolver for D2 | Required future RETURN/credit pair |
| --- | --- | --- | --- | --- |
|OPEN|D0/D0|D1/D1|D2|D2/D2|
|CLOSED|D0/D3|D1/D3|D3|D2/D3|
|REOPENED|D0/D3|D1/D3|D2|D2/D3|

The initial cutoff is the retained administrative disposable-period fixture,
explicitly labelled; it is not a legal-close/archive proof. The reopened branch
uses the current public period-review/command facade, which calls Native reopen.
It checks unchanged filings, original SALE journal and entire original payment
snapshot. A future writer without the proven RETURN/root book-floor hook must
refuse the reopened profile atomically; that refusal is not positive feature
completion. Native found-stock/sale/payment writers enforce their own date and
cutover guards; setup also asserts product effective range, nonzero allocation
HPP10, stored journal pairs and the actual private current resolver. A failed
source precondition is a failed setup, not permission to change the oracle.

Use the existing closed harness's already-owned cur/today. The following setup
and reads are executable without inventing new API fields:

```python
import importlib.util
from pathlib import Path

path = Path('/workspace/scratch/9442228ed2dc/ow04-proposals/native/cp7_ow04_native_source_fixture.py')
spec = importlib.util.spec_from_file_location('ow04_native_source_fixture', path)
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)

with fixture.isolated(cur):
    x = fixture.prepared(cur, today, paid='900.00', profile='REOPENED')
    actual_initial_events = x['source_events_before']
    raw_source = fixture.source_manifest(cur, x)
    negative = fixture.legacy_omitted_choice_refused(cur, x)
    assert negative['classification'] == 'LEGACY_NEGATIVE_ONLY_NOT_SETTLEMENT_SUCCESS'
```

source_probes(cur,today) serializes all six source variants and rolls each back.
It returns source-only classifications, never feature PASS. It captures actual
Native function bodies/hash/owner/ACL/config, raw PostgreSQL JSON text and hashes
of source facts/journals, true economic/book pairs, product/found receipt,
allocation/stock, the note revision graph, payment/return correction links and
neutral/effective IDs, and recursive journal inverses. Original REVERSED rows
are retained. Absent optional schema is explicit installed:false/rows:null.
It does not claim to be the product's authoritative collector or derive
immutable return ordinal registrations from UUID/date order.

No connection string, DB startup, installer, legacy ERP write or hosted action
is provided by this artifact. Load it by absolute path within the already-owned
closed harness. Do not copy it alone to scripts/ without also arranging its
EXPECTED.json path in the future owning phase.

The only prospective adapter is call_quote(cur, caller_supplied_jsonb, subject).
It calls the tentative positional signature
public.erp_cp7_get_sales_return_settlement_quote_v1(jsonb) only if present;
otherwise it raises OW04_SETTLEMENT_QUOTE_API_NOT_INSTALLED. Payload fields,
request context and RETURN_SETTLEMENT are still the writer's API choice. No
positive feature case is registered or callable from this proposal. After an
actual defined writer succeeds, assert_payment_unchanged and
assert_first_settlement_gl provide independent raw payment/stock/GL checks. The
latter also checks existing P11 net800, E800, AR0; it must run before adding a
second invoice or consumer to the same fixture.

liability_account_review reads actual active/postable LIABILITY/CREDIT account
rows plus cash/mapping/prepayment/history flags. It never chooses or creates an
account. Existing unexplained or BB-only history still needs the future Native
reconciler; shape alone does not authorize reuse. No expiry, default company
account, migration batch or artificial bank funding is invented.

The14 future risk IDs in EXPECTED.json are a mapping only:7Native,2HTTP,3races,
2browser. Six source variants are not six extra completed feature cases. The
existing P11_RETURN_PAID_REFUSAL and its payment-inverse/ordinary-return control
remain unchanged. Real Auth/HTTP, observed blocking and source/cash revocation,
last-step rollback, actual browser journeys, new collector/poster integration,
finance/report detectors, install/restore and performance remain to run.

Peer source/admission counter: a current-product legal Native source exercise
can return200 while unpaid then pay500/800; it cannot pretend that pay900 then
return200 already works. The uninstalled source collector proposal correctly
blocks any existing posted return lacking real immutable family registration
with IMMUTABLE_RETURN_FAMILY_OR_ORDER_MISSING. Do not insert fake ordinal rows
to make that control green. A zero-value/zero-HPP return may have no return
journal; this fixture explicitly requires R200/HPP10, so the zero/no-journal case
needs its own independent source control.

Independent bounded source review found no additional concrete setup blocker in
these six positive-cost fixtures after checking the actual retained writers and
period facade. The actual private resolver read is an administrative/read-only
source witness, not an application permission grant. The UI counter agrees the
quote must bind all return/choice/refund-time changes and invalidate stale or
401/403 results; the fixture continues to accept only caller-defined payloads
until the writer fixes that API. The admission peer received the exact legal
current-source/blocked-registration protocol above. None of these peer source
checks is Native execution or an independent production audit.
