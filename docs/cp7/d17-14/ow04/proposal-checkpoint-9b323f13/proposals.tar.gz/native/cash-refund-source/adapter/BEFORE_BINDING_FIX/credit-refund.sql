-- UNINSTALLED READ ADAPTER PROPOSAL. No Native/source/posting authority.
do $not_an_installer$begin
 raise exception 'OW04_REFUND_SOURCE_REQUIRES_COMPLETE_OWNING_INTEGRATION';
end $not_an_installer$;

-- Install after the complete owning refund facts. Existing source-reader role
-- only: no new role, browser table access, writer EXEC or business DML grant.
grant usage on schema cp7_credit to cp7_transaction_source_read;
grant select on cp7_credit.consumption_events,cp7_credit.initial_refund_operations,
 cp7_credit.cohorts,cp7_credit.recognition_plans,cp7_credit.return_families,
 cp7_credit.return_family_members to cp7_transaction_source_read;
grant select(id,auth_user_id)on erp.app_users to cp7_transaction_source_read;
grant select(id,coa_account_id)on erp.cash_accounts to cp7_transaction_source_read;
grant select(id,account_type,normal_balance)on erp.chart_accounts to cp7_transaction_source_read;
grant select(id,journal_entry_id,account_id,customer_id,description,debit,credit,
 vendor_id,contractor_id,po_id,product_id)on erp.journal_lines to cp7_transaction_source_read;

create function cp7_transaction_source.refund_source_access()returns jsonb
language plpgsql stable security invoker set search_path=''as $$
declare a jsonb;
begin
 a:=cp7_transaction_source.authority();
 -- Preserve current cash UI/report and exact owning sales-source read gates.
 -- This does not change the shared finance-analysis backend's reports gate.
 if a->'profile'->>'role_code'not in('OWNER','ADMIN')
  or not erp.has_permission('finance.cash.view')
  or not erp.has_permission('finance.reports.view')
  or not erp.has_permission('sales.invoice.view')
  or not erp.has_permission('sales.return.view')
  or not erp.has_permission('finance.ar.view')then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
 return a;
end $$;

-- Called only by the unchanged public resolver's protected fixed-source branch.
-- p may echo an original JOURNAL_REVERSAL; its loop has already proved the real
-- journal link and retained its extra finance.journal.view owner gate.
create function cp7_transaction_source.refund_source_resolution(p jsonb,p_kind text,p_event uuid,p_authority jsonb)returns jsonb
language plpgsql stable security invoker set search_path=''set TimeZone='UTC'as $$
declare a jsonb;ev cp7_credit.consumption_events;o cp7_credit.initial_refund_operations;
 c cp7_credit.cohorts;plan cp7_credit.recognition_plans;family cp7_credit.return_families;
 sale erp.sales_headers;ret erp.sales_returns;j erp.journal_entries;
 cash_coa uuid;cash_snapshot_coa uuid;liability_kind text;liability_normal text;
 expected_lines jsonb;actual_lines jsonb;source_sha text;line_sha text;
begin
 -- Current authority is checked BEFORE looking up any source/customer facts.
 a:=cp7_transaction_source.refund_source_access();
 if a is distinct from p_authority then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_CHANGED';end if;
 if p_kind is distinct from'CP7_CUSTOMER_CREDIT_REFUND'or p_event is null then
  raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 select *into ev from cp7_credit.consumption_events where id=p_event;
 if ev.id is null or ev.event_kind<>'REFUND'or ev.amount<=0
  or ev.amount::text in('NaN','Infinity','-Infinity')or ev.amount*100<>trunc(ev.amount*100)
  or ev.target_sale_id is not null or ev.restores_event_id is not null then
  raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 select *into o from cp7_credit.initial_refund_operations where id=ev.id;
 select *into c from cp7_credit.cohorts where id=ev.cohort_id;
 if o.id is null or c.id is null then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 select *into plan from cp7_credit.recognition_plans where id=o.initial_plan_id;
 select *into family from cp7_credit.return_families where id=c.family_id;
 select *into sale from erp.sales_headers where id=c.source_sale_id;
 select *into ret from erp.sales_returns where id=c.source_return_id;
 if plan.id is null or family.id is null or sale.id is null or ret.id is null
  or(o.cohort_id,o.initial_plan_id,o.current_leaf_id,o.root_sale_id,o.full_amount,o.cash_account_id,o.actor,o.request_id,o.reason)is distinct from
   (c.id,c.initial_plan_id,c.source_sale_id,family.family_root_sale_id,ev.amount,ev.cash_account_id,ev.actor,ev.request_id,ev.reason)
  or(c.initial_mode,c.initial_net_amount,c.actor,c.request_id)is distinct from('REFUND',ev.amount,ev.actor,ev.request_id)
  or(plan.cohort_id,plan.plan_kind,plan.actor,plan.request_id,plan.family_root_sale_id)is distinct from
   (c.id,'INITIAL',ev.actor,ev.request_id,o.root_sale_id)
  or(ret.sale_id,ret.customer_id,sale.customer_id)is distinct from(sale.id,c.customer_id,c.customer_id)
  or not exists(select 1 from erp.sales_headers root_sale where root_sale.id=family.family_root_sale_id and root_sale.customer_id=c.customer_id)
  or not exists(select 1 from cp7_credit.return_family_members m where m.family_id=c.family_id and m.return_id=ret.id and m.source_journal_id=c.source_return_journal_id)
  or not exists(select 1 from erp.journal_entries sj where sj.id=c.source_sale_journal_id and sj.source_type='SALE'and sj.source_id=sale.id and sj.status='POSTED'and sj.reversal_of_id is null)
  or not exists(select 1 from erp.journal_entries rj where rj.id=c.source_return_journal_id and rj.source_type='SALES_RETURN'and rj.source_id=ret.id and rj.status='POSTED'and rj.reversal_of_id is null)
  or sale.status not in('POSTED','PARTIAL_PAID','PAID')or ret.status<>'POSTED'then
  raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 -- Compare the exact immutable operation hash, including recorded_at, using
 -- the poster's PostgreSQL jsonb::text codec; no client/cross-language hash.
 source_sha:=encode(pg_catalog.sha256(convert_to(to_jsonb(o)::text,'UTF8')),'hex');
 if ev.source_sha256 is distinct from source_sha then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 select coa_account_id into cash_coa from erp.cash_accounts where id=ev.cash_account_id;
 cash_snapshot_coa:=(o.cash_account_snapshot#>>'{account,id}')::uuid;
 select account_type,normal_balance into liability_kind,liability_normal from erp.chart_accounts where id=c.credit_account_id;
 if cash_coa is null or cash_snapshot_coa is null or cash_coa<>cash_snapshot_coa
  or(o.cash_account_snapshot#>>'{cash,id}')::uuid is distinct from ev.cash_account_id
  or(o.cash_account_snapshot#>>'{cash,coa_account_id}')::uuid is distinct from cash_snapshot_coa
  or o.cash_account_snapshot#>>'{account,account_type}'is distinct from'ASSET'
  or liability_kind is distinct from'LIABILITY'or liability_normal is distinct from'CREDIT'
  or c.credit_account_id=cash_coa then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 -- Historical account deactivation is not a source-deletion or read filter.
 -- Current active/postable selection belongs to the owning refund writer.
 select *into j from erp.journal_entries where id=ev.journal_id;
 if j.id is null or(j.source_type,j.source_id,j.status,j.reversal_of_id,j.economic_date,j.transaction_date)is distinct from
  ('CP7_CUSTOMER_CREDIT_REFUND',ev.id,'POSTED',null::uuid,ev.economic_date,ev.transaction_date)
  or ev.economic_date is distinct from(o.physical_at at time zone'Asia/Jakarta')::date
  or ev.transaction_date<ev.economic_date or ev.transaction_date<o.required_book_floor
  or(select count(*)from erp.journal_entries x where x.source_type='CP7_CUSTOMER_CREDIT_REFUND'and x.source_id=ev.id)<>1
  or exists(select 1 from erp.journal_entries x where x.reversal_of_id=j.id or(x.source_type='JOURNAL_REVERSAL'and x.source_id=j.id))
  or not exists(select 1 from erp.app_users u where u.id=j.created_by and u.auth_user_id=ev.actor)
  or(select count(*)from erp.journal_lines l where l.journal_entry_id=j.id)<>2
  or exists(select 1 from erp.journal_lines l where l.journal_entry_id=j.id and
   (l.vendor_id is not null or l.contractor_id is not null or l.po_id is not null or l.product_id is not null))then
  raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 select jsonb_agg(x order by x->>'account_id'collate"C")into expected_lines from jsonb_array_elements(jsonb_build_array(
  jsonb_build_object('account_id',c.credit_account_id,'customer_id',c.customer_id,'description','Kredit retur: pengembalian uang','debit',round(ev.amount,2),'credit',round(0::numeric,2)),
  jsonb_build_object('account_id',cash_coa,'customer_id',c.customer_id,'description','Kredit retur: pengembalian uang','debit',round(0::numeric,2),'credit',round(ev.amount,2))))x;
 select jsonb_agg(jsonb_build_object('account_id',l.account_id,'customer_id',l.customer_id,'description',l.description,
  'debit',round(l.debit,2),'credit',round(l.credit,2))order by l.account_id::text collate"C")into actual_lines
  from erp.journal_lines l where l.journal_entry_id=j.id;
 line_sha:=encode(pg_catalog.sha256(convert_to(actual_lines::text,'UTF8')),'hex');
 if actual_lines is distinct from expected_lines or ev.lines_sha256_pg is distinct from line_sha then
  raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 if cp7_transaction_source.refund_source_access()is distinct from a then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_CHANGED';end if;
 -- The actual Native credit/refund workspace/reader does not exist yet. Keep
 -- the exact reference visible and explicitly unavailable, never alias it to
 -- an expense, imported BB credit, invoice, or ordinary physical-return form.
 return jsonb_build_object('contract_version','cp7.transaction-source.v1','actor_scope_id',auth.uid(),'source',p,
  'status','UNSUPPORTED_SOURCE','document',null,'read_at',statement_timestamp(),'business_DML',false);
end $$;

alter function cp7_transaction_source.refund_source_access()owner to cp7_transaction_source_read;
alter function cp7_transaction_source.refund_source_resolution(jsonb,text,uuid,jsonb)owner to cp7_transaction_source_read;
revoke all on function cp7_transaction_source.refund_source_access(),
 cp7_transaction_source.refund_source_resolution(jsonb,text,uuid,jsonb)from public,anon,authenticated,service_role;
