// Isolated actual adapter/resolver SQL with SYNTHETIC rows and auth predicates.
// NOT Native creation/posting, Supabase Auth, PostgREST, or permission proof.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

const dir=path.dirname(fileURLToPath(import.meta.url));
const {PGlite}=await import(process.env.OW04_PGLITE_MODULE??'/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js');
const sha=s=>createHash('sha256').update(s).digest('hex');
const expectedText=await fs.readFile(path.join(dir,'EXPECTED.json'),'utf8');
const expected=JSON.parse(expectedText),results=[];
const source=await fs.readFile(path.join(dir,'credit-refund.sql'),'utf8');
const base=await fs.readFile(path.join(dir,'generated/scripts/cp7-src/transactions/source.sql'),'utf8');
const refund=await fs.readFile('/workspace/scratch/9442228ed2dc/ow04-proposals/refund/01_initial_refund.proposal.sql','utf8');
const result={classification:'ISOLATED_ACTUAL_READ_ADAPTER_SQL_SYNTHETIC_AUTH_ROWS_NOT_NATIVE',native_execution_proven:false,active_repo_modified:false,
 expected_sha256:sha(expectedText),adapter_sha256:sha(source),resolver_sha256:sha(base),refund_protocol_sha256:sha(refund),results};
const db=new PGlite();
const q=(sql,args=[])=>db.query(sql,args),ex=sql=>db.exec(sql);
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const ids={sale:id(1),customer:id(2),ret:id(3),family:id(4),cohort:id(5),plan:id(6),event:id(7),request:id(8),cash:id(9),liability:id(10),coa:id(11),poster:id(12),posterAuth:id(13),viewer:id(14),journal:id(15),saleJ:id(16),returnJ:id(17),payment:id(18)};
const permissions=expected.current_access.permissions.join(',');
const sourceRef={source_type:expected.source_type,source_id:ids.event};
const fn=name=>{
 const pattern=new RegExp(`create function cp7_transaction_source\\.${name}\\([^]*?end \\$\\$;`);
 const found=base.match(pattern);assert.ok(found,`missing actual resolver function ${name}`);return found[0];
};
const sourceHashSQL=`update cp7_credit.consumption_events e set source_sha256=(select encode(pg_catalog.sha256(convert_to(to_jsonb(o)::text,'UTF8')),'hex')from cp7_credit.initial_refund_operations o where o.id=e.id)`;
const lineHashSQL=`update cp7_credit.consumption_events e set lines_sha256_pg=(select encode(pg_catalog.sha256(convert_to(jsonb_agg(jsonb_build_object('account_id',l.account_id,'customer_id',l.customer_id,'description',l.description,'debit',round(l.debit,2),'credit',round(l.credit,2))order by l.account_id::text collate"C")::text,'UTF8')),'hex')from erp.journal_lines l where l.journal_entry_id=e.journal_id)`;
let stage='setup';
try{
 await ex(`
 set TimeZone='UTC';
 create role anon;create role authenticated;create role service_role;
 create role cp7_transaction_source_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
 create schema auth;create schema erp;create schema cp7_credit;create schema cp7_transaction_source authorization cp7_transaction_source_read;
 create function auth.uid()returns uuid language sql stable as $$select nullif(current_setting('adapter.actor',true),'')::uuid$$;
 create function auth.jwt()returns jsonb language sql stable as $$select jsonb_build_object('role','authenticated')$$;
 create function erp.get_my_access_v1()returns jsonb language sql stable as $$select jsonb_build_object('allowed',true,'profile',jsonb_build_object('role_code',current_setting('adapter.role',true)))$$;
 create function erp.has_permission(p text)returns boolean language sql stable as $$select p=any(string_to_array(current_setting('adapter.permissions',true),','))$$;
 create table erp.app_users(id uuid primary key,auth_user_id uuid,is_active boolean default true);
 create table erp.sales_headers(id uuid primary key,sale_number text,customer_id uuid,sale_date timestamptz,status text,row_version bigint default 1);
 create table erp.sales_returns(id uuid primary key,sale_id uuid,customer_id uuid,physical_at timestamptz,status text);
 create table erp.sales_payments(id uuid primary key,sale_id uuid,amount numeric(20,2),status text);
 create table erp.chart_accounts(id uuid primary key,account_type text,normal_balance text,is_active boolean default true,is_postable boolean default true);
 create table erp.cash_accounts(id uuid primary key,coa_account_id uuid,is_active boolean default true);
 create table erp.journal_entries(id uuid primary key,source_type text,source_id uuid,status text,reversal_of_id uuid,economic_date date,transaction_date date,created_by uuid);
 create table erp.journal_lines(id uuid primary key,journal_entry_id uuid,account_id uuid,customer_id uuid,description text,debit numeric(20,2),credit numeric(20,2),vendor_id uuid,contractor_id uuid,po_id uuid,product_id uuid);
 create table cp7_credit.return_families(id uuid primary key,family_root_sale_id uuid);
 create table cp7_credit.return_family_members(family_id uuid,return_id uuid,source_journal_id uuid);
 create table cp7_credit.cohorts(id uuid primary key,family_id uuid,source_sale_id uuid,source_return_id uuid,customer_id uuid,credit_account_id uuid,initial_mode text,initial_net_amount numeric,initial_plan_id uuid,source_sale_journal_id uuid,source_return_journal_id uuid,actor uuid,request_id uuid);
 create table cp7_credit.recognition_plans(id uuid primary key,cohort_id uuid,plan_kind text,actor uuid,request_id uuid,family_root_sale_id uuid);
 create domain cp7_credit.cent_amount as numeric check(value is null or(value::text not in('NaN','Infinity','-Infinity')and value*100=trunc(value*100)));
 create table cp7_credit.consumption_events(id uuid primary key,cohort_id uuid,event_kind text,amount numeric,economic_date date,transaction_date date,target_sale_id uuid,cash_account_id uuid,restores_event_id uuid,journal_id uuid,source_sha256 text,lines_sha256_pg text,actor uuid,request_id uuid,reason text);
 grant usage on schema erp,auth to cp7_transaction_source_read;
 grant select on erp.sales_headers,erp.sales_returns,erp.journal_entries to cp7_transaction_source_read;
 grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text)to cp7_transaction_source_read;
 `);
 const operationTable=refund.match(/create table cp7_credit\.initial_refund_operations\([^]*?\n\);/);
 assert.ok(operationTable,'actual refund operation DDL missing');
 await ex(operationTable[0]);
 const barrier=/do \$not_an_installer\$begin\s*raise exception 'OW04_REFUND_SOURCE_REQUIRES_COMPLETE_OWNING_INTEGRATION';\s*end \$not_an_installer\$;/;
 assert.equal([...source.matchAll(new RegExp(barrier,'g'))].length,1,'install barrier changed');
 await ex(fn('authority'));
 await ex(source.replace(barrier,'-- Removed only in this isolated in-memory synthetic check.'));
 await ex(fn('resolve'));
 await ex(`alter function cp7_transaction_source.authority()owner to cp7_transaction_source_read;
 alter function cp7_transaction_source.resolve(jsonb)owner to cp7_transaction_source_read;
 create function public.erp_cp7_resolve_transaction_source_v1(p_source jsonb)returns jsonb language sql stable security definer set search_path=''as $$select cp7_transaction_source.resolve(p_source)$$;
 alter function public.erp_cp7_resolve_transaction_source_v1(jsonb)owner to cp7_transaction_source_read;
 revoke all on function cp7_transaction_source.authority(),cp7_transaction_source.resolve(jsonb)from public,anon,authenticated,service_role;
 revoke all on function public.erp_cp7_resolve_transaction_source_v1(jsonb)from public,anon,authenticated,service_role;
 grant execute on function public.erp_cp7_resolve_transaction_source_v1(jsonb)to authenticated;`);
 await q("select set_config('adapter.actor',$1,false),set_config('adapter.role','OWNER',false),set_config('adapter.permissions',$2,false)",[ids.viewer,permissions]);
 await q('insert into erp.app_users values($1,$2,true)',[ids.poster,ids.posterAuth]);
 await q("insert into erp.sales_headers values($1,'S-NAV-1000',$2,'2026-10-17 04:00Z','PAID',1)",[ids.sale,ids.customer]);
 await q("insert into erp.sales_returns values($1,$2,$3,'2026-10-19 04:00Z','POSTED')",[ids.ret,ids.sale,ids.customer]);
 await q("insert into erp.sales_payments values($1,$2,1000,'POSTED')",[ids.payment,ids.sale]);
 await q("insert into erp.chart_accounts values($1,'LIABILITY','CREDIT',true,true),($2,'ASSET','DEBIT',true,true)",[ids.liability,ids.coa]);
 await q('insert into erp.cash_accounts values($1,$2,true)',[ids.cash,ids.coa]);
 await q('insert into cp7_credit.return_families values($1,$2)',[ids.family,ids.sale]);
 await q('insert into cp7_credit.return_family_members values($1,$2,$3)',[ids.family,ids.ret,ids.returnJ]);
 await q("insert into cp7_credit.cohorts values($1,$2,$3,$4,$5,$6,'REFUND',200,$7,$8,$9,$10,$11)",[ids.cohort,ids.family,ids.sale,ids.ret,ids.customer,ids.liability,ids.plan,ids.saleJ,ids.returnJ,ids.posterAuth,ids.request]);
 await q("insert into cp7_credit.recognition_plans values($1,$2,'INITIAL',$3,$4,$5)",[ids.plan,ids.cohort,ids.posterAuth,ids.request,ids.sale]);
 await q(`insert into cp7_credit.initial_refund_operations(id,cohort_id,initial_plan_id,actor,request_id,backend_pid,transaction_id,root_sale_id,current_leaf_id,full_amount,cash_account_id,physical_at,reason,reference,payload_sha256,quote_sha256,source_lock_sha256,projection_sha256,recognition_manifest_sha256,required_book_floor,book_floor_manifest,materialization_ordinal,authority_snapshot,cash_account_snapshot)
 select $1,$2,$3,$4,$5,123,456,$6,$6,200,$7,'2026-10-19 04:12:13.123456Z','Synthetic navigation source',null,repeat('a',64),repeat('b',64),repeat('c',64),repeat('d',64),repeat('e',64),'2026-10-20','{"contract_version":"ow04.initial-refund-book-plan.v1","economic_date":"2026-10-19","full_k":"200.00","selected_book_date":"2026-10-20"}'::jsonb,1,'{}',jsonb_build_object('cash',to_jsonb(c),'account',to_jsonb(a),'mappings','[]'::jsonb)from erp.cash_accounts c join erp.chart_accounts a on a.id=c.coa_account_id where c.id=$7`,[ids.event,ids.cohort,ids.plan,ids.posterAuth,ids.request,ids.sale,ids.cash]);
 for(const [j,kind,src,e,b]of[[ids.saleJ,'SALE',ids.sale,'2026-10-17','2026-10-17'],[ids.returnJ,'SALES_RETURN',ids.ret,'2026-10-19','2026-10-20'],[ids.journal,expected.source_type,ids.event,'2026-10-19','2026-10-20']]){
  await q("insert into erp.journal_entries values($1,$2,$3,'POSTED',null,$4,$5,$6)",[j,kind,src,e,b,ids.poster]);
 }
 for(const [n,account,debit,credit]of[[101,ids.liability,'200.00','0.00'],[102,ids.coa,'0.00','200.00']]){
  await q("insert into erp.journal_lines(id,journal_entry_id,account_id,customer_id,description,debit,credit)values($1,$2,$3,$4,'Kredit retur: pengembalian uang',$5,$6)",[id(n),ids.journal,account,ids.customer,debit,credit]);
 }
 await q("insert into cp7_credit.consumption_events values($1,$2,'REFUND',200,'2026-10-19','2026-10-20',null,$3,null,$4,null,null,$5,$6,'Synthetic navigation source')",[ids.event,ids.cohort,ids.cash,ids.journal,ids.posterAuth,ids.request]);
 await ex(sourceHashSQL);await ex(lineHashSQL);
 const snapshot=async()=>JSON.stringify((await q(`select jsonb_build_object('sales',(select jsonb_agg(to_jsonb(t)order by id)from erp.sales_headers t),'returns',(select jsonb_agg(to_jsonb(t)order by id)from erp.sales_returns t),'payments',(select jsonb_agg(to_jsonb(t)order by id)from erp.sales_payments t),'journals',(select jsonb_agg(to_jsonb(t)order by id)from erp.journal_entries t),'lines',(select jsonb_agg(to_jsonb(t)order by id)from erp.journal_lines t),'operation',(select jsonb_agg(to_jsonb(t)order by id)from cp7_credit.initial_refund_operations t),'events',(select jsonb_agg(to_jsonb(t)order by id)from cp7_credit.consumption_events t))v`)).rows[0].v);
 const read=async(reference=sourceRef)=>{await ex('savepoint adapter_read');try{await ex('set role authenticated');const reply=(await q('select public.erp_cp7_resolve_transaction_source_v1($1::jsonb)v',[JSON.stringify(reference)])).rows[0].v;await ex('reset role');await ex('release savepoint adapter_read');return reply;}catch(e){await ex('rollback to savepoint adapter_read');await ex('release savepoint adapter_read');throw e;}};
 const unavailable=reply=>{assert.deepEqual(Object.keys(reply).sort(),['actor_scope_id','business_DML','contract_version','document','read_at','source','status']);assert.equal(reply.status,'UNSUPPORTED_SOURCE');assert.equal(reply.document,null);assert.equal(reply.business_DML,false);assert.deepEqual(reply.source,sourceRef);assert.equal(reply.actor_scope_id,ids.viewer);};
 const test=async(name,body)=>{stage=name;await ex('begin');try{await body();await ex('rollback');results.push({id:name,status:'PASS'});}catch(e){await ex('rollback');throw e;}};
 const refuses=async(mutate,message='CP7_TRANSACTION_SOURCE_UNAVAILABLE',reference=sourceRef)=>{await mutate();const before=await snapshot();await assert.rejects(()=>read(reference),e=>e.message.includes(message));assert.equal(await snapshot(),before);};
 await test('VALID_INITIAL_REFUND_EXPLICIT_UNAVAILABLE',async()=>{const before=await snapshot();const reply=await read();unavailable(reply);assert.equal(await snapshot(),before);result.valid_reply=reply;});
 await test('OTHER_AUTHORIZED_VIEWER',async()=>{assert.notEqual(ids.viewer,ids.posterAuth);unavailable(await read());});
 await test('SESSION_TIMEZONE_DOES_NOT_CHANGE_SOURCE_BINDING',async()=>{await ex("set local TimeZone='Etc/GMT-9'");unavailable(await read());});
 await test('CURRENT_ACCESS_REVOKED',()=>refuses(()=>q("select set_config('adapter.permissions','sales.invoice.view,sales.return.view,finance.ar.view,finance.reports.view',true)"),'CP7_TRANSACTION_SOURCE_ACCESS_DENIED',{...sourceRef,source_id:id(999)}));
 await test('WRONG_SOURCE_UUID',()=>refuses(async()=>{},'CP7_TRANSACTION_SOURCE_UNAVAILABLE',{...sourceRef,source_id:ids.cohort}));
 await test('WRONG_EVENT_KIND_OR_SIGN',()=>refuses(()=>q("update cp7_credit.consumption_events set event_kind='APPLY',target_sale_id=$1",[ids.sale])));
 await test('MISMATCH_OPERATION_COHORT_PLAN',()=>refuses(()=>q('update cp7_credit.recognition_plans set cohort_id=$1',[id(999)])));
 await test('MISMATCH_RETURN_SALE_CUSTOMER_FAMILY',()=>refuses(()=>q('update erp.sales_returns set customer_id=$1',[id(999)])));
 await test('MISMATCH_HISTORICAL_ACTOR_OR_REQUEST',()=>refuses(()=>q('update cp7_credit.consumption_events set request_id=$1',[id(999)])));
 await test('MISMATCH_JOURNAL_SOURCE_OR_PAIR',()=>refuses(()=>q("update erp.journal_entries set transaction_date='2026-10-19'where id=$1",[ids.journal])));
 await test('MISMATCH_JOURNAL_LINES_OR_HASH',()=>refuses(async()=>{await q('update erp.journal_lines set customer_id=$1 where id=$2',[id(999),id(101)]);await ex(lineHashSQL);}));
 await test('INACTIVE_USED_CASH_ACCOUNT',async()=>{await ex('update erp.cash_accounts set is_active=false;update erp.chart_accounts set is_active=false;update erp.app_users set is_active=false');unavailable(await read());});
 await test('REVERSED_OR_UNSUPPORTED_REFUND_HISTORY',()=>refuses(()=>q("update erp.journal_entries set status='REVERSED'where id=$1",[ids.journal])));
 await test('ACTUAL_SOURCE_OPERATION_HASH_CHANGED',()=>refuses(()=>q("update cp7_credit.consumption_events set source_sha256=repeat('f',64)")));
 await test('ACTUAL_EXTRA_JOURNAL_LINE_REFUSED',()=>refuses(()=>q("insert into erp.journal_lines(id,journal_entry_id,account_id,customer_id,description,debit,credit)values($1,$2,$3,$4,'extra',1,1)",[id(103),ids.journal,ids.coa,ids.customer])));
 await test('ACTUAL_JOURNAL_POSTER_ACTOR_MISMATCH',()=>refuses(()=>q('update erp.app_users set auth_user_id=$1',[ids.viewer])));
 await test('JOURNAL_INVERSE_CURRENT_RIGHTS_RETAINED',()=>refuses(async()=>{},'CP7_TRANSACTION_SOURCE_ACCESS_DENIED',{source_type:'JOURNAL_REVERSAL',source_id:ids.journal}));
 await test('JOURNAL_INVERSE_VALID_REFERENCE_STILL_UNAVAILABLE',async()=>{await q("select set_config('adapter.permissions',$1,true)",[permissions+',finance.journal.view']);const reference={source_type:'JOURNAL_REVERSAL',source_id:ids.journal},reply=await read(reference);assert.equal(reply.status,'UNSUPPORTED_SOURCE');assert.equal(reply.document,null);assert.deepEqual(reply.source,reference);});
 await test('LEGACY_RESOLVER_UNCHANGED',async()=>{const branch=" if kind='CP7_CUSTOMER_CREDIT_REFUND'then\n  return cp7_transaction_source.refund_source_resolution(p,kind,ident,a);\n end if;\n";const old=await fs.readFile('/workspace/scratch/9442228ed2dc/erp-d1714/scripts/cp7-src/transactions/source.sql','utf8');assert.equal(base.replace(branch,''),old);const reply=await read({source_type:'OLD_UNSUPPORTED_SOURCE',source_id:ids.sale});assert.equal(reply.status,'UNSUPPORTED_SOURCE');assert.equal(reply.document,null);});
 await test('PRIVATE_READ_ONLY_ROLE_AND_FUNCTION_METADATA',async()=>{const role=(await q("select rolsuper,rolcanlogin from pg_roles where rolname='cp7_transaction_source_read'")).rows[0];assert.deepEqual(role,{rolsuper:false,rolcanlogin:false});for(const signature of['cp7_transaction_source.refund_source_access()','cp7_transaction_source.refund_source_resolution(jsonb,text,uuid,jsonb)'])for(const who of['anon','authenticated','service_role'])assert.equal((await q('select has_function_privilege($1,$2,\'EXECUTE\')v',[who,signature])).rows[0].v,false);assert.equal((await q("select exists(select 1 from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname in('erp','cp7_credit')and c.relkind in('r','p')and has_table_privilege('cp7_transaction_source_read',c.oid,'INSERT,UPDATE,DELETE,TRUNCATE,TRIGGER'))v")).rows[0].v,false);});
 await test('NO_CREDIT_WORKSPACE_ROUTE',async()=>{const ts=await import(pathToFileURL(path.join(dir,'generated/src/transactionSource.ts')).href);const reply=await read();const parsed=ts.parseTransactionSource(reply,sourceRef,ids.viewer);assert.equal(parsed.document,null);assert.equal(ts.unavailableTransactionSourceMessage(sourceRef),expected.literal_control.expected_UI_message);assert.equal(ts.unavailableTransactionSourceMessage({source_type:'SALE',source_id:ids.sale}),'Jenis transaksi asal ini belum dapat dibuka dari buku. Referensi asli tetap ditampilkan.');const fake={...reply,status:'AVAILABLE',document:{domain:'SALE',route:'sales-returns',id:ids.sale,number:'S',status:'PAID',revision:'1',focus:{kind:'SALES_RETURN',id:ids.ret,page_offset:0}}};assert.throws(()=>ts.parseTransactionSource(fake,sourceRef,ids.viewer));});
 result.status='PASS';result.executed_isolated_controls=results.length;
}catch(e){result.status='FAIL';result.failed_step=stage;result.error=String(e.stack??e);result.sql_where=e.where??null;result.sql_detail=e.detail??null;process.exitCode=1;}
finally{await db.close();await fs.writeFile(path.join(dir,'RESULT.json'),JSON.stringify(result,null,2)+'\n');}
console.log(JSON.stringify({classification:result.classification,status:result.status,cases:results.length,failed_step:result.failed_step??null}));
