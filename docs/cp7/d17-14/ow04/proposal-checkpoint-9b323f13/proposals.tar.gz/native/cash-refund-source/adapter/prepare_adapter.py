"""Exact, pinned source transforms. Writes ONLY inside this proposal directory.

No DB connection, active repo edit, Native execution, or installation.
"""
from hashlib import sha256
from pathlib import Path
import difflib
import json

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/9442228ed2dc/erp-d1714')
PINS = {
    'scripts/cp7-src/transactions/source.sql': 'dab0d29b7dd2d4d9d27e31e3d483d4f7222f8f48d43a93c954fe67a9cbbce87a',
    'scripts/cp7_transaction_source_bundle.py': '93e943228afbb202b712e0412fc946d39041e1c428af30f35df344dfc5ae3e96',
    'src/transactionSource.ts': '6aea8fef3d8928c93c1f0aa3233ab19f41f21718d866ba3c840549f8d5c22507',
    'src/TransactionSourceNavigation.tsx': 'db0fd1f2dc82157b79130f16425dad374bea59cffb1ea370c1468c4f6544f5cf',
}
MESSAGE = 'Pengembalian uang kredit pelanggan tercatat. Halaman rincian kredit Native belum tersedia; referensi jurnal asli tetap ditampilkan.'


def once(body, anchor, replacement):
    if body.count(anchor) != 1:
        raise ValueError('REFUND_SOURCE_EXACT_ANCHOR_CHANGED: ' + anchor[:100])
    return body.replace(anchor, replacement, 1)


def transformed(name, body):
    if name.endswith('/source.sql'):
        anchor = ' -- Economic-date entries belong to the exact ordinary payment correction.'
        return once(body, anchor, " if kind='CP7_CUSTOMER_CREDIT_REFUND'then\n  return cp7_transaction_source.refund_source_resolution(p,kind,ident,a);\n end if;\n" + anchor)
    if name.endswith('/transactionSource.ts'):
        return body + '\n/** Explicit boundary until the owning Native credit/refund reader and page exist. */\nexport function unavailableTransactionSourceMessage(reference:SourceReference):string{\n return reference.source_type===\'CP7_CUSTOMER_CREDIT_REFUND\'?\'' + MESSAGE + "':'Jenis transaksi asal ini belum dapat dibuka dari buku. Referensi asli tetap ditampilkan.'\n}\n"
    if name.endswith('/TransactionSourceNavigation.tsx'):
        body = once(body, 'parseTransactionSource,sourceId,type SourceReference', 'parseTransactionSource,sourceId,unavailableTransactionSourceMessage,type SourceReference')
        return once(body, "setError('Jenis transaksi asal ini belum dapat dibuka dari buku. Referensi asli tetap ditampilkan.')", 'setError(unavailableTransactionSourceMessage(reference))')
    if name.endswith('/cp7_transaction_source_bundle.py'):
        body = once(body, "('source.sql','dependencies.sql')", "('source.sql','credit-refund.sql','dependencies.sql')")
        body = once(body, "{'authority','resolve','dependencies'}", "{'authority','resolve','dependencies','refund_source_access','refund_source_resolution'}")
        body = once(body, "name in('resolve','dependencies')", "name in('resolve','dependencies','refund_source_resolution')")
        anchor = '    for who in (\'anon\',\'authenticated\',\'service_role\'):'
        verify = '''    # New source adapter is read-only and private; no writer capability.
    for table in ('consumption_events','initial_refund_operations','cohorts','recognition_plans','return_families','return_family_members'):
        assert cur.execute("select has_schema_privilege(%s,'cp7_credit','USAGE')and has_table_privilege(%s,%s,'SELECT')and not has_table_privilege(%s,%s,'INSERT,UPDATE,DELETE,TRUNCATE,TRIGGER')",(ROLE,ROLE,'cp7_credit.'+table,ROLE,'cp7_credit.'+table)).fetchone()[0]
    for who in ('anon','authenticated','service_role'):
        for function in ('cp7_transaction_source.refund_source_access()','cp7_transaction_source.refund_source_resolution(jsonb,text,uuid,jsonb)'):
            assert not cur.execute('select has_function_privilege(%s,%s,\\'EXECUTE\\')',(who,function)).fetchone()[0]
'''
        return once(body, anchor, verify + anchor)
    raise ValueError('UNDECLARED_ADAPTER_PATH')


def prepare():
    generated = HERE / 'generated'
    generated.mkdir(exist_ok=True)
    patches, metadata = [], {}
    for name, pin in PINS.items():
        old = (REPO / name).read_text()
        if sha256(old.encode()).hexdigest() != pin:
            raise ValueError('REFUND_SOURCE_PREDECESSOR_CHANGED: ' + name)
        new = transformed(name, old)
        target = generated / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(new)
        patches.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='a/' + name, tofile='b/' + name))
        metadata[name] = dict(before=pin, after=sha256(new.encode()).hexdigest())
    new_name = 'scripts/cp7-src/transactions/credit-refund.sql'
    sql = (HERE / 'credit-refund.sql').read_text()
    target = generated / new_name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(sql)
    patches.extend(difflib.unified_diff([], sql.splitlines(True), fromfile='/dev/null', tofile='b/' + new_name))
    metadata[new_name] = dict(before=None, after=sha256(sql.encode()).hexdigest())
    (HERE / 'adapter_integration.patch').write_text(''.join(patches))
    (HERE / 'SOURCE_BINDINGS.json').write_text(json.dumps(dict(classification='PINNED_SOURCE_PROPOSAL_NOT_NATIVE', native_execution_proven=False, active_repo_modified=False, files=metadata), indent=2) + '\n')
    return metadata


if __name__ == '__main__':
    print(json.dumps(prepare(), indent=2))
