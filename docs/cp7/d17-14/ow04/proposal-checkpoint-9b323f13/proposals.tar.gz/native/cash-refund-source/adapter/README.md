# Narrow initial-refund source adapter proposal

Current isolated result: **21/21 PASS**. No active repository edit, Native
posting, real Auth/PostgREST, provider, source-authority or complete-feature
claim. `EXPECTED.json` was frozen first; the UTC correction has its separate
expected record `BINDING_FIX_EXPECTED.json`. The initial failures remain in
`BEFORE_BINDING_FIX/` and `FIRST_HARNESS_FAILURE.json`.

The exact reviewed source is `CP7_CUSTOMER_CREDIT_REFUND`, whose `source_id` is
the positive REFUND event UUID: `consumption_events.id` equals
`initial_refund_operations.id`. It is never a cohort, invoice, physical-return,
expense, import/BB, or journal UUID disguised as the refund source.

## Actual integration delta

`adapter_integration.patch` applies against the exact predecessor hashes in
`SOURCE_BINDINGS.json`; `git apply --check` and generated Python AST checks pass.
The patch contains:

1. One fixed-source branch in the existing transaction-source resolver,
   immediately after its unchanged journal-inverse loop. It preserves current
   source echo and the loop's additional journal permission check.
2. `scripts/cp7-src/transactions/credit-refund.sql`: two private STABLE/invoker
   helpers owned by the existing source-reader role, narrowly scoped SELECT
   grants, no business DML or writer EXEC. The checker reads immutable
   event→operation/cohort→initial plan/family→actual return/invoice/source
   journals, verifies actor/request/customer consistency, exact refund source
   journal/dates/two lines/amounts/dimensions, and both actual PostgreSQL hashes.
3. Existing source-bundle composition and exact function/permission verification
   extended for those helpers. No public RPC or browser table privilege added.
4. A source-specific unavailable message in the existing navigation component.
   The existing strict parser still rejects a fabricated AVAILABLE invoice or
   ordinary-return route for this new source.

Current access is OWNER/ADMIN plus the existing cash UI/report read rights and
owning sales invoice/return/AR read rights, checked before source lookup and
again at completion. This adds no access to the shared cash-analysis backend.
The historical poster's event/operation/cohort/initial-plan actor/request must
match one another; an authorized current reader need not be that poster.
Historical account/poster deactivation does not delete the source or reapply
new-posting active-account selection rules as history filters.

The actual Native credit/refund workspace is absent. Therefore a verified
source returns the existing `cp7.transaction-source.v1` shape with exact source
echo, `status: UNSUPPORTED_SOURCE`, `document: null`, `business_DML: false`.
The UI says the refund is recorded but its Native credit detail page is not
available. It retains the original journal/source reference. No AVAILABLE
route, new TransactionDocument domain/focus, Page/SalesView, root-type or access
catalog entry is introduced. Enabling AVAILABLE later requires the actual owning
refund detail reader/page and its proved event focus/pagination; the current
physical-return panel is not a substitute.

The SQL retains its explicit installation barrier. It may only be composed by
the root with complete owning credit/refund tables and exact object owners/ACLs;
do not install this source fragment or its UI text separately. No placeholder
writer or permission stub is supplied by the product proposal.

## The paused failure and correction

Actual PL line42 was the immutable operation **hash** check, after all preceding
whole-binding predicates. PGlite defaults to `Etc/GMT-9` (+09). The old fixture
computed raw `to_jsonb(operation)` SHA in that zone, whereas both the actual
refund poster and this adapter fix `TimeZone=UTC`. Timestamptz JSON text differs.
The fix is fixture UTC before its raw PostgreSQL hash; no source predicate,
expected amount, old payment, or journal assertion was weakened. A separate
control confirms a +09 caller session still resolves the UTC-bound source.

The current protected operation's required `book_floor_manifest` is supplied by
the isolated synthetic fixture and automatically participates in the exact
whole-row hash. This read adapter does not recompute capacity or compare a
historical event to today's resolver after reopen; those are owning posting and
source-authority duties. The isolated manifest is test input, not an admission
proof or a fabricated Native source.

## Reproduce isolated checks

```sh
python -B /workspace/scratch/9442228ed2dc/ow04-proposals/native/cash-refund-source/adapter/prepare_adapter.py
node /workspace/scratch/9442228ed2dc/ow04-proposals/native/cash-refund-source/adapter/check_adapter.mjs
```

The preparer reads pinned predecessors and writes only this proposal's generated
files/diff. The runner compiles the actual adapter and resolver SQL in in-memory
PGlite using explicitly synthetic Auth predicates and rows, including the actual
current immutable operation DDL. It checks valid unavailable receipts, current
rights, source/parent/actor/request/journal/line/hash mismatches, inverse rights,
read-only/private metadata, unchanged source/payment snapshots, and rejection of
counterfeit AVAILABLE navigation. No service/database is started or contacted.

`RESULT.json` and `SOURCE_BINDINGS.json` bind the exercised source. Real
closed-stack Native cash/finance reads, genuine Auth/PostgREST permissions,
source completeness, refund posting/capacity/rollback/races and the missing
credit workspace remain required integration evidence.
