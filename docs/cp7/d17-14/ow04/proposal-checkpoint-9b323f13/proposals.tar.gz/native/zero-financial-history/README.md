# Zero financial history source proposal

No active repo edit, Native run, new settlement API, new phase/manifest or feature PASS.
EXPECTED.json was written before the executable helper. The helper's Python AST parses.
It has not been imported or executed in an ERP database.

`cp7_ow04_zero_financial_history_source.py:prepared(cur,today)` prepares the
current real public AX found-at-opname source with explicit owner value0, then
current public CREATE/POST and RETURN0. It asserts the actual OTHER lot, actual
current HPP0 version, allocation, reservation-to-SALE identity, physical return,
no payment and no original scoped journal. It neither seeds posted stock nor
makes an OPENING lot. Two additional declared keyword profiles are:

```python
prepared(cur, today, price='200.00', discount='200.00', unit_hpp='0.00')
prepared(cur, today, price='0.00', discount='0.00', unit_hpp='10.00')
```

Use the existing closed harness's already-owned cur/today, load this module by
absolute importlib path, and isolate/roll back each call using the existing
fixture rollback scope. No connection/startup or install command is supplied.
A source/cutover/effective-time failure is a setup failure, not permission to
rewrite stored dates or change the literal expected values.

The positive-HPP control expects real HPP-only SALE and RETURN journals even
though the invoice total is zero. The explicit-zero and full-discount controls
expect no receipt/SALE/RETURN journal, no financial event UUID or book pair.
All three are current Native source controls, not completed settlement tests.

CONDITIONAL_RECOST_EXPECTED.json is a separate source-derived counter: a genuine
Native OPENING0 lot, free sale, later accepted controlled opening correction to
HPP10, then return0 with an actual HPP-only RETURN journal. The helper above
DOES NOT implement that opening/recost fixture. Do not call opening correction
on its OTHER lot or change its origin label. That conditional needs genuine
owner opening preparation and an actual stored Native history before runtime
qualification.

The required semantic distinction is prior SALE/RETURN causal journals
ABSENT_PROVEN versus DATED versus UNKNOWN. Proven prior absence does not imply
the next Native return cannot produce HPP lines. Every real resulting journal
keeps its actual stored economic/book pair. Financial cohorts retain their
source-journal requirements; an empty zero-money family must not invent one.
