"""Current accepted public paths only. Proposal outside product, not executed.

EXPECTED.json was frozen first. This helper opens no connection or transaction,
installs nothing, and does not invent a settlement API or a financial book date.
Run only inside the already-owned disposable closed harness and roll back.
"""
from datetime import timedelta
from decimal import Decimal as D
import json
import uuid

import cp7_sales_draft_cases as drafts
import cp7_sales_return_cases as returned

cmd, source, auth, b = drafts.cmd, drafts.source, drafts.auth, drafts.b


def scoped_journals(cur, f):
    return cur.execute("""
      select to_jsonb(j),coalesce((select jsonb_agg(to_jsonb(l)order by l.id)
       from erp.journal_lines l where l.journal_entry_id=j.id),'[]'::jsonb)
      from erp.journal_entries j where
       (j.source_type='FG_UNSOURCED_RECEIPT'and j.source_id=%s)
       or(j.source_type='SALE'and j.source_id=%s)
       or(j.source_type='SALES_RETURN'and j.source_id=%s)
      order by j.source_type,j.id
    """, (f['receipt'], f['sale'], f.get('return'))).fetchall()


def prepared(cur, today, *, price='0.00', discount='0.00', unit_hpp='0.00'):
    """Actual Native receipt -> public CREATE/POST -> public physical RETURN.

    Master setup is the existing new-model/no-reference fixture. The explicit
    owner value is used only after Native preview proves OWNER_INPUT_REQUIRED.
    Physical times come from the real database clock; no period/date rewriting.
    """
    if (price, discount, unit_hpp) not in (
        ('0.00', '0.00', '0.00'),
        ('200.00', '200.00', '0.00'),
        ('0.00', '0.00', '10.00'),
    ):
        raise AssertionError('UNDECLARED_ZERO_HISTORY_SOURCE_PROFILE')
    b.api.admin(cur)
    now = source.fg.ax.r1.now(cur)
    stock_at = now - timedelta(minutes=20, seconds=1, microseconds=123456)
    sale_at = now - timedelta(minutes=10, seconds=2, microseconds=234567)
    return_at = now - timedelta(minutes=5, seconds=3, microseconds=345678)
    product, _ = source.fg.ax.owner_only_model_product(
        cur, effective_from=stock_at - timedelta(days=1))
    tag = 'OW04-ZERO-' + uuid.uuid4().hex[:12]
    f = dict(product=product, location=str(source.fg.base.LOCATION),
             customer=str(source.fg.base.create_customer(cur, tag)), tag=tag,
             sale_at=sale_at.isoformat())
    f['sku'] = cur.execute('select sku from erp.products where id=%s',
                           (product,)).fetchone()[0]
    preview = source.fg.ax.preview(cur, product, stock_at.isoformat())
    assert preview['tier'] == 'OWNER_INPUT_REQUIRED', preview
    receipt = source.fg.ax.post(cur, dict(
        source_kind='FOUND_AT_OPNAME', product_id=product,
        location_id=f['location'], qty_pcs=2, quality_grade='GRADE_A',
        physical_at=stock_at.isoformat(),
        reason='Actual sample stock with explicit owner value, not an opening lot',
        owner_unit_value=unit_hpp,
        owner_value_reason='Explicit owner sample value after no-reference review'))
    f.update(receipt=receipt['receipt_id'], lot=receipt['lot_id'])
    b.api.admin(cur)
    lot = cur.execute('select lot_origin,initial_qty_pcs from erp.fg_lots where id=%s',
                      (f['lot'],)).fetchone()
    assert lot == ('OTHER', 2), lot
    hv = cur.execute('select cost_state,total_cost,hpp_per_pcs from erp.hpp_versions where lot_id=%s and is_current',
                     (f['lot'],)).fetchall()
    assert len(hv) == 1 and hv[0][0] == 'ADJUSTED'
    assert D(hv[0][1]) == 2 * D(unit_hpp) and D(hv[0][2]) == D(unit_hpp)
    assert D(str(receipt['total_value'])) == 2 * D(unit_hpp)
    assert (receipt['journal_entry_id'] is None) == (unit_hpp == '0.00')
    p = drafts.payload(f, qty='1', price=price, discount=discount)
    drafts.create(cur, f, p)
    reserved = cur.execute("""select m.id,m.qty_signed,m.unit_hpp_snapshot
      from erp.fg_stock_movements m join erp.sales_items i on i.id=m.source_id
      where i.sale_id=%s and m.source_type='SALE_ITEM'
       and m.movement_type='SALE_RESERVE'and m.reversal_of_id is null""",
      (f['sale'],)).fetchall()
    assert len(reserved) == 1 and reserved[0][1] == -1 and D(reserved[0][2]) == D(unit_hpp)
    review, version = cmd.review(cur, f)
    cmd.command(cur, 'POST', review, version)
    detail = source.read(cur, f)['detail']
    assert detail['status'] == 'POSTED' and detail['financial']['net_total'] == '0.00'
    posted = cur.execute('select movement_type,qty_signed,unit_hpp_snapshot from erp.fg_stock_movements where id=%s',
                         (reserved[0][0],)).fetchone()
    assert posted[0] == 'SALE' and posted[1] == -1 and D(posted[2]) == D(unit_hpp)
    f['destination'] = returned.location(cur, 'OW04 actual zero-value sample return')
    f['allocations'] = returned.read(cur, f)['page']['rows']
    assert len(f['allocations']) == 1 and f['allocations'][0]['allocated_qty'] == '1'
    rp, rv = returned.payload(cur, f, qty='1', refund='0.00')
    rp['physical_at'] = return_at.isoformat()
    result = cmd.command(cur, 'RETURN', rp, rv)
    f['return'] = result['return_id']
    detail = source.read(cur, f)['detail']
    assert result['return_status'] == 'POSTED' and detail['status'] == 'PAID'
    assert all(D(detail['financial'][k]) == 0 for k in (
        'gross_total', 'return_total', 'net_total', 'paid_total', 'open_balance'))
    assert cur.execute('select count(*)from erp.sales_payments where sale_id=%s',
                       (f['sale'],)).fetchone()[0] == 0
    allocation = cur.execute('select qty_pcs,unit_hpp_snapshot from erp.sale_stock_allocations where id=%s',
                              (f['allocations'][0]['allocation_id'],)).fetchone()
    assert allocation[0] == 1 and D(allocation[1]) == D(unit_hpp)
    items = cur.execute('select qty_pcs,unit_hpp_snapshot,refund_amount from erp.sales_return_items where return_id=%s',
                         (f['return'],)).fetchall()
    assert len(items) == 1 and items[0][0] == 1 and D(items[0][1]) == D(unit_hpp) and D(items[0][2]) == 0
    movements = cur.execute("""select m.qty_signed,m.unit_hpp_snapshot,m.customer_id,m.physical_at
      from erp.fg_stock_movements m join erp.sales_return_items i on i.id=m.source_id
      where i.return_id=%s and m.source_type='SALES_RETURN_ITEM'
       and m.movement_type='SALE_RETURN'and m.reversal_of_id is null""",
      (f['return'],)).fetchall()
    assert len(movements) == 1 and movements[0][0] == 1 and D(movements[0][1]) == D(unit_hpp)
    assert str(movements[0][2]) == f['customer'] and movements[0][3] == return_at
    assert returned.positions(cur, f) == {
        (f['location'], 'GRADE_A'): 1, (f['destination'], 'GRADE_A'): 1}
    journals = scoped_journals(cur, f)
    if unit_hpp == '0.00':
        assert journals == [], journals
    else:
        assert {j['source_type'] for j, _ in journals} == {
            'FG_UNSOURCED_RECEIPT', 'SALE', 'SALES_RETURN'} and len(journals) == 3
        for j, lines in journals:
            assert j['status'] == 'POSTED' and j['transaction_date'] >= j['economic_date']
            assert sum(D(x['debit']) for x in lines) == sum(D(x['credit']) for x in lines)
        for kind in ('SALE', 'SALES_RETURN'):
            j, lines = next(x for x in journals if x[0]['source_type'] == kind)
            assert len(lines) == 2 and sum(D(x['debit']) for x in lines) == 10
            assert all(x['product_id'] == product and x['customer_id'] == f['customer'] for x in lines)
    f['source_journals'] = journals
    f['classification'] = 'ACTUAL_ACCEPTED_SOURCE_FIXTURE_ONLY_NOT_SETTLEMENT_AUTHORITY'
    return f
