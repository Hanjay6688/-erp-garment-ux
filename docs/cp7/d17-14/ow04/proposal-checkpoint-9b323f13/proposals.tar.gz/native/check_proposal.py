#!/usr/bin/env python3
"""Static declarations and literal arithmetic only; no Native module import/DB."""
from pathlib import Path
from decimal import Decimal as D
import ast
import hashlib
import json

HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/scratch/9442228ed2dc/erp-d1714')
SHA='f6d7efdde1a409094b8c5485fb7942209175bce1d869e8c05f1a1d097b7cadde'
p=HERE/'EXPECTED.json'
assert hashlib.sha256(p.read_bytes()).hexdigest()==SHA
x=json.loads(p.read_text())
module=HERE/'cp7_ow04_native_source_fixture.py'
tree=ast.parse(module.read_text())
compile(tree,str(module),'exec')
# A preparer/probe result must not masquerade as an executed feature PASS.
assert not any(isinstance(n,ast.Constant) and n.value=='PASS' for n in ast.walk(tree))
const={}
for n in tree.body:
    if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('EXPECTED_SHA','SOURCE_FIXTURE_IDS'):
        const[n.targets[0].id]=eval(compile(ast.Expression(n.value),'<static declaration>','eval'),{'tuple':tuple})
assert const['EXPECTED_SHA']==SHA
assert list(const['SOURCE_FIXTURE_IDS'])==[f['fixture_id'] for f in x['fixtures']]
assert len(x['fixtures'])==6
ids=[c['id'] for cases in x['proposed_case_mapping'].values() for c in cases]
assert len(ids)==len(set(ids))==14
assert {k:len(v) for k,v in x['proposed_case_mapping'].items()}==x['proposed_required_counts']==dict(native=7,http=2,races=3,browser=2)
for f in x['fixtures']:
    before,credit,refund=f['pre_return'],f['future_credit'],f['future_full_refund']
    assert D(before['gross'])-D(before['P'])==D(before['AR'])
    assert D(credit['P'])-D(credit['I'])==D(credit['E'])==D(credit['net'])
    assert D(credit['AR'])==0
    assert D(refund['bank_from_fixture'])==D(before['P'])-D(refund['refund_amount'])==800
    assert D(refund['I_after_refund'])==D(credit['I'])
    assert D(credit['source_gradeA_qty'])+D(credit['destination_gradeA_qty'])==D(credit['FG_total_qty'])==6
    assert D(credit['FG_total_value'])==60 and D(credit['cogs'])==40
    assert D(credit['revenue'])-D(credit['cogs'])==D(credit['gross_profit'])==760
    assert before['payment_status']=='POSTED'
required={
 'scripts/cp7_note_correction_cases.py':{'stock','posted'},
 'scripts/cp7_sales_payment_cases.py':{'payment_payload','bank_account'},
 'scripts/cp7_sales_return_cases.py':{'payload','read','location','positions'},
 'scripts/cp7_sales_command_cases.py':{'command','accounts','mapping','delta'},
 'scripts/cp7_period_cases.py':{'read','command','intent','filings'},
 'scripts/cp7_snapshot_cases.py':{'actor','refused'},
}
source_hashes={}
for file,names in required.items():
    data=(REPO/file).read_bytes()
    defs={n.name for n in ast.parse(data).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    assert names<=defs,(file,names-defs)
    source_hashes[file]=hashlib.sha256(data).hexdigest()
result={'classification':'SOURCE_ONLY_STATIC_PROPOSAL_CHECKS_NOT_NATIVE','python_syntax':'PASS',
 'literal_expected_arithmetic':'PASS','existing_named_facades':'PASS','source_fixture_variants':6,
 'proposed_unregistered_risk_cases':14,'no_feature_PASS_literal':True,'expected_sha256':SHA,
 'module_sha256':hashlib.sha256(module.read_bytes()).hexdigest(),'facade_file_sha256':source_hashes,
 'native_executed':False,'quote_executed':False,'settlement_executed':False,'source_SQL_compiled':False}
(HERE/'SOURCE_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='facade_file_sha256'}))
