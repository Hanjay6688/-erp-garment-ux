// Actual proposal SQL, isolated selected Native DDL + synthetic rows only.
// No Native writer, fake permission API, context waiver or fake journal poster.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const dir=path.dirname(new URL(import.meta.url).pathname),base=path.dirname(dir);
const {PGlite}=await import('/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=p=>fs.readFileSync(path.join(base,p),'utf8');
const strip=s=>s.replace(/do \$not_an_installer\$[\s\S]*?end \$not_an_installer\$;/,'-- ONLY removed in this isolated SQL exercise');
const db=new PGlite(),results=[],sources={};let stage='setup';
const ex=s=>db.exec(s),q=(s,p=[])=>db.query(s,p),one=async(s,p=[])=>Object.values((await q(s,p)).rows[0])[0];
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const load=async p=>{const t=read(p);sources[p]=sha(t);stage=p;try{await ex(strip(t));}catch(e){
 if(p.startsWith('coordinator/'))for(const m of strip(t).matchAll(/create (?:or replace )?function ([\s\S]*?)\$\$;/g)){
  stage=p+': '+m[1].slice(0,m[1].indexOf('returns')).trim();
  try{await ex(m[0].replace(/^create function/,'create or replace function'));}catch(inner){inner.position=inner.position??inner.cause?.position;throw inner;}
 }
 throw e;
}};
const result={classification:'ACTUAL_PROPOSAL_SQL_ISOLATED_SELECTED_NATIVE_DDL_SYNTHETIC_NOT_NATIVE',native_execution_proven:false,authority_proven:false,poster_execution_proven:false,
 expected_sha256:sha(fs.readFileSync(path.join(dir,'EXPECTED.json'))),refund_book_expected_sha256:sha(fs.readFileSync(path.join(dir,'REFUND_BOOK_EXPECTED.json'))),
 factual_expected_sha256:sha(fs.readFileSync(path.join(dir,'FACTUAL_EXPECTED.json'))),timezone_expected_sha256:sha(fs.readFileSync(path.join(dir,'TIMEZONE_EXPECTED.json'))),sources,results};
const test=async(name,fn,expected)=>{try{const actual=await fn();const pass=JSON.stringify(actual)===JSON.stringify(expected);results.push({id:name,pass,expected,actual});}catch(e){results.push({id:name,pass:false,error:e.message,detail:e.detail,where:e.where});}};
const refuses=async(name,sql,params,pattern)=>{try{await q(sql,params);results.push({id:name,pass:false,expected_refusal:pattern,actual:'ACCEPTED'});}catch(e){results.push({id:name,pass:e.message.includes(pattern),expected_refusal:pattern,error:e.message});}};
const event=(id,kind,amount,e,b=e)=>({id,kind,amount,economic_date:e,transaction_date:b,source_sha256:'a'.repeat(64)});
const kernel=async(before,added)=>one('select ow04_pure_kernel.recognition_plan_v1($1,$2)',[before,added]);
try{
 // Fresh synthetic Native raw-codec facts are CREATED under UTC. The first
 // failed run retained a PGlite default Etc/GMT-9 fixture; later UTC verification
 // correctly could not pretend those differently serialized hashes were UTC.
 // This starts a new fixture, never rewrites a retained fact/digest.
 await ex("set TimeZone='UTC'");
 await load('source/ISOLATED_TABLES.sql');
 for(const t of['customers','chart_accounts','sales_headers','sales_returns','journal_entries','cash_accounts']){
  if(!await one("select exists(select 1 from pg_constraint where conrelid=$1::regclass and contype='p')",[`erp.${t}`]))await ex(`alter table erp.${t}add primary key(id)`);
 }
 await ex("create schema cp7_sales;create schema auth;");
 const commandText=fs.readFileSync('/workspace/scratch/9442228ed2dc/erp-d1714/scripts/cp7-src/sales/commands.sql','utf8');
 for(const name of['requests','command_context']){
  const m=commandText.match(new RegExp(`create table cp7_sales\\.${name}\\([^;]+;`));if(!m)throw Error('actual sales context DDL unavailable');await ex(m[0]);
 }
 const nativeReadText=fs.readFileSync('/workspace/scratch/9442228ed2dc/erp-d1714/scripts/cp7-src/sales/read.sql','utf8');
 const nativeReview=nativeReadText.match(/create function cp7_sales\.review_token\([\s\S]*?\$\$;/)?.[0];
 if(!nativeReview)throw Error('actual Native review codec unavailable');sources['actual_cp7_sales.review_token_body']=sha(nativeReview);await ex(nativeReview);
 await load('kernel/kernel.sql');await load('ordinal-wrapper/wrapper.sql');
 await load('ledger/01_immutable_facts.proposal.sql');await load('ledger/02_uuid_poster.proposal.sql');await load('source/NO_JOURNAL_SCHEMA_DIFF.proposal.sql');
 await load('source/source.sql');await load('source/member-proof.sql');await load('source/absence-proof.sql');
 const reader=read('readers/01_current_reader_capability.proposal.sql');stage='reader private subset';
 await ex(strip(reader.slice(0,reader.indexOf('-- Narrow capability'))));
 await load('readers/02_materialized_profile.proposal.sql');
 await load('admission/01_typed_context_and_preclaim.proposal.sql');await load('admission/02_owning_wrapper.proposal.sql');
 await load('refund/01_initial_refund.proposal.sql');
 for(const name of['01_coordinator_facts.sql','02_initial_projection.sql','03_native_initial_callbacks.sql','04_register_and_materialize.sql','05_factual_profile.sql','06_finish_and_closed_routes.sql'])await load(`coordinator/${name}`);
 const caps=read('coordinator/07_capabilities_and_quote.sql');sources['coordinator/07_capabilities_and_quote.sql']=sha(caps);stage='07 pure functions and scope closure (Native grants unavailable)';
 await ex(strip(caps.slice(0,caps.indexOf('-- Explicit private owners'))));
 // Revoke defaults using the actual list, independently of unavailable actual
 // auth.uid/jwt/context-capture grants. No replacement Auth function is made.
 await ex(caps.slice(caps.indexOf('do $private_functions$')));
 await ex(caps.match(/do \$role\$[\s\S]*?end \$role\$;/)[0]);
 await load('coordinator/08_outer_wrapper.sql');
 await load('coordinator/09_public_facades.sql');
 results.push({id:'ALL_FUNCTION_AND_TABLE_DDL',pass:true,explicit_limit:'07 Native auth/context capability grants intentionally not executed; no substitute supplied'});
 const S=event('S','NET','1000.00','2026-10-18'),R=event('R','NET','-200.00','2026-10-19');
 for(const paid of['1000.00','900.00','500.00']){
  const k=await kernel([S,event('P','FUNDING',paid,'2026-10-18')],[R]);
  await test(`ACTUAL_KERNEL_K_${paid}`,()=>Promise.resolve(k.net_current_k),{'1000.00':'200.00','900.00':'100.00','500.00':'0.00'}[paid]);
 }
 const laterBook=await kernel([S,event('P','FUNDING','1000.00','2026-10-18','2026-10-20')],[R]);
 const bookPlan=(k,full,physical,lawful,ret)=>one('select cp7_credit.initial_refund_book_plan_v1($1,$2,$3,$4,$5)',[k,full,physical,lawful,ret]);
 const a=await bookPlan(laterBook,'200.00','2026-10-19T08:00:00Z','2026-10-19','2026-10-19');
 await test('FUNDING_BOOK_LATER_THAN_RETURN',()=>Promise.resolve({selected:a.selected_book_date,candidates:a.candidate_books}),{selected:'2026-10-20',candidates:['2026-10-19','2026-10-20']});
 await test('COMPLETE_CANDIDATE_MANIFEST',()=>Promise.resolve(a.candidates.map(x=>({b:x.transaction_date,eligible:x.eligible,min:x.capacity.minimum_available}))),[
  {b:'2026-10-19',eligible:false,min:'0.00'},{b:'2026-10-20',eligible:true,min:'200.00'}]);
 await test('REOPENED_PAIR',async()=> (await bookPlan(laterBook,'200.00','2026-10-19T08:00:00Z','2026-10-19','2026-10-20')).selected_book_date,'2026-10-20');
 await test('CLOSED_RESOLVER',async()=> (await bookPlan(laterBook,'200.00','2026-10-19T08:00:00Z','2026-10-20','2026-10-19')).selected_book_date,'2026-10-20');
 const futureE=await kernel([S,event('P','FUNDING','1000.00','2026-10-20')],[R]);
 await test('CREDIT_ECONOMIC_AFTER_REFUND',async()=> (await bookPlan(futureE,'200.00','2026-10-19T08:00:00Z','2026-10-19','2026-10-19')).selected_book_date,null);
 await refuses('ZERO_K','select cp7_credit.initial_refund_book_plan_v1($1,0,$2,$3,$3)',[laterBook,'2026-10-19T08:00:00Z','2026-10-19'],'CP7_CREDIT_REFUND_BOOK_PLAN_INPUT');
 await refuses('FRACTIONAL_CENT_K','select cp7_credit.initial_refund_book_plan_v1($1,0.001,$2,$3,$3)',[laterBook,'2026-10-19T08:00:00Z','2026-10-19'],'CP7_CREDIT_REFUND_BOOK_PLAN_INPUT');
 const mixed=await kernel([S,event('R_OLD','NET','-600.00','2026-10-18'),event('A','FUNDING','600.00','2026-10-19','2026-10-21'),event('B','FUNDING','400.00','2026-10-20','2026-10-20')],[event('NEW','NET','-200.00','2026-10-18')]);
 // Locked counter requests the EARLIER economic19/book20 pair. Economic20
 // legitimately sees the B atom already; first failure preserves that mistaken
 // driver input instead of treating a valid20/20 answer as a planner defect.
 await test('MIXED_ATOMS_NO_FACE_CAPACITY',async()=> (await bookPlan(mixed,'200.00','2026-10-19T08:00:00Z','2026-10-19','2026-10-19')).selected_book_date,'2026-10-21');
 await refuses('HISTORICAL_OVERFUNDING','select cp7_credit.assert_zero_excess_v1($1)',[[S,event('P','FUNDING','1100.00','2026-10-18')]],'CP7_CREDIT_HISTORICAL_BASE_OVERFUNDING');
 await test('EMPTY_FAMILY_REMAINS_NO_EXCESS',async()=>{await q('select cp7_credit.assert_zero_excess_v1($1)',[[S,R,event('P','FUNDING','500.00','2026-10-20')]]);return 'EMPTY';},'EMPTY');
 await refuses('WRONG_QUOTE_WIRE_NO_AUTH_STUB','select cp7_credit.get_initial_return_quote_v1($1)',[{}],'CP7_CREDIT_QUOTE_FIELDS');
 await refuses('NO_NATIVE_AUTH_CAPABILITY','select cp7_credit.assert_initial_work_v1($1,true)',[id(300)],'function auth.uid() does not exist');
 await test('PRIVATE_CALLBACK_ACL',async()=>Number(await one("select count(*)from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='cp7_credit'and p.proname in('assert_refund_operation_v1','native_return_enter','native_return_complete','assert_current_source_plan_profile','assert_financial_materialization_provenance')and not has_function_privilege('authenticated',p.oid,'EXECUTE')and p.proowner='postgres'::regrole")),5);
 await test('PUBLIC_EXACT_OWNERS',async()=> (await q("select p.proname,pg_get_userbyid(p.proowner)owner,p.prosecdef,p.provolatile::text from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public'and p.proname in('erp_cp7_get_sales_return_settlement_quote_v1','erp_cp7_settle_sales_return_v1')order by p.proname")).rows,[
  {proname:'erp_cp7_get_sales_return_settlement_quote_v1',owner:'cp7_sales_read',prosecdef:true,provolatile:'v'},
  {proname:'erp_cp7_settle_sales_return_v1',owner:'cp7_credit_write',prosecdef:true,provolatile:'v'}]);
 await test('AUTHENTICATED_PUBLIC_ONLY',async()=> (await q("select has_function_privilege('authenticated','public.erp_cp7_get_sales_return_settlement_quote_v1(jsonb)','EXECUTE')q,has_function_privilege('authenticated','public.erp_cp7_settle_sales_return_v1(jsonb,uuid,text)','EXECUTE')w,has_function_privilege('authenticated','cp7_credit.get_initial_return_quote_v1(jsonb)','EXECUTE')private_q,has_function_privilege('authenticated','cp7_credit.return_settlement_command(jsonb,uuid,text)','EXECUTE')private_w")).rows[0],{q:true,w:true,private_q:false,private_w:false});
 stage='synthetic actual-source factual fixture';
 await q("insert into erp.customers(id,customer_code,customer_name)values($1,'SYNTHETIC','Synthetic only')",[id(10)]);
 for(const[n,name,type,normal]of[[1,'AR','ASSET','DEBIT'],[2,'REVENUE','REVENUE','CREDIT'],[3,'BANK','ASSET','DEBIT']])await q(
  'insert into erp.chart_accounts(id,account_code,account_name,account_type,report_group,normal_balance)values($1,$2,$2,$3,$2,$4)',[id(n),name,type,normal]);
 await q("insert into erp.accounting_account_mappings(mapping_key,account_id)values('AR_CUSTOMER',$1)",[id(1)]);
 await q("insert into erp.cash_accounts(id,cash_account_code,cash_account_name,coa_account_id,account_kind)values($1,'B','Synthetic bank',$2,'BANK')",[id(50),id(3)]);
 await q("insert into erp.sales_headers(id,sale_number,customer_id,sale_date,status)values($1,'S',$2,'2026-10-18 01:00Z','PARTIAL_PAID')",[id(100),id(10)]);
 await q('insert into erp.sales_items(id,sale_id,product_id,qty_pcs,unit_price_snapshot)values($1,$2,$3,5,200)',[id(101),id(100),id(11)]);
 await q("insert into erp.sales_payments(id,sale_id,payment_number,payment_date,amount,cash_account_id,payment_method,status)values($1,$2,'P','2026-10-18 02:00Z',900,$3,'TRANSFER','POSTED')",[id(500),id(100),id(50)]);
 const journal=async(n,type,src)=>q("insert into erp.journal_entries(id,journal_number,economic_date,transaction_date,posting_at,source_type,source_id,description,status)values($1,$2,'2026-10-18','2026-10-18','2026-10-18 03:00Z',$3,$4,'Synthetic only','POSTED')",[id(n),`J${n}`,type,id(src)]);
 const line=async(n,j,a,d,c)=>q('insert into erp.journal_lines(id,journal_entry_id,account_id,debit,credit,customer_id)values($1,$2,$3,$4,$5,$6)',[id(n),id(j),id(a),d,c,id(10)]);
 await journal(200,'SALE',100);await line(201,200,1,'1000','0');await line(202,200,2,'0','1000');
 await journal(600,'SALES_PAYMENT',500);await line(601,600,3,'900','0');await line(602,600,1,'0','900');
 await q(`insert into erp.sales_payment_posting_facts(payment_id,sale_id,customer_id,payment_number,payment_date,amount,cash_account_id,original_journal_entry_id,
  journal_economic_date,journal_transaction_date,journal_posting_at,payment_snapshot,lineage_sha256)
  select p.id,p.sale_id,$2,p.payment_number,p.payment_date,p.amount,p.cash_account_id,j.id,j.economic_date,j.transaction_date,j.posting_at,to_jsonb(p)-'status',
  ow04_source_proposal.native_sha(jsonb_build_array(p.id,p.sale_id,$2::uuid,p.payment_number,p.payment_date,p.amount,p.cash_account_id,j.id,j.economic_date,j.transaction_date,j.posting_at,p.replaces_payment_id,null,to_jsonb(p)-'status'))
  from erp.sales_payments p join erp.journal_entries j on j.source_type='SALES_PAYMENT'and j.source_id=p.id where p.id=$1`,[id(500),id(10)]);
 result.fixture_payment_codec_diagnostic=(await q(`select current_setting('TimeZone')timezone,f.lineage_sha256 recorded,
  ow04_source_proposal.native_sha(jsonb_build_array(f.payment_id,f.sale_id,f.customer_id,f.payment_number,f.payment_date,f.amount,f.cash_account_id,
  f.original_journal_entry_id,f.journal_economic_date,f.journal_transaction_date,f.journal_posting_at,f.replaces_payment_id,f.predecessor_reversal_journal_id,f.payment_snapshot))recomputed,
  f.payment_snapshot=to_jsonb(p)-'status'snapshot_equal from erp.sales_payment_posting_facts f join erp.sales_payments p on p.id=f.payment_id where p.id=$1`,[id(500)])).rows[0];
 await ex("set TimeZone='UTC'");
 result.fixture_payment_codec_utc_diagnostic=(await q(`select current_setting('TimeZone')timezone,f.lineage_sha256 recorded,
  ow04_source_proposal.native_sha(jsonb_build_array(f.payment_id,f.sale_id,f.customer_id,f.payment_number,f.payment_date,f.amount,f.cash_account_id,
  f.original_journal_entry_id,f.journal_economic_date,f.journal_transaction_date,f.journal_posting_at,f.replaces_payment_id,f.predecessor_reversal_journal_id,f.payment_snapshot))recomputed,
  f.payment_snapshot=to_jsonb(p)-'status'snapshot_equal from erp.sales_payment_posting_facts f join erp.sales_payments p on p.id=f.payment_id where p.id=$1`,[id(500)])).rows[0];
 await test('FACTUAL_SALE_AND_PAYMENT',async()=>{await q('select cp7_credit.assert_simple_native_base_v1($1)',[id(100)]);return 'VALID';},'VALID');
 await test('CURRENT_P_NO_CREDIT',()=>one('select cp7_credit.current_effective_paid($1)::text',[id(100)]),'900.00');
 await test('CURRENT_EMPTY_PROFILE',async()=>{await q('select cp7_credit.assert_current_materialized_profile($1,$1,$1)',[id(100)]);return 'VALID';},'VALID');
 const utcSource=await one('select cp7_credit.initial_preserved_source_v1($1)',[id(100)]);
 await ex("set TimeZone='Asia/Jakarta'");
 await test('PROTECTED_SOURCE_SAME_UTC_AND_JAKARTA',async()=>JSON.stringify(utcSource)===JSON.stringify(await one('select cp7_credit.initial_preserved_source_v1($1)',[id(100)])),true);
 await test('FACTUAL_VALIDATOR_FROM_JAKARTA',async()=>{await q('select cp7_credit.assert_simple_native_base_v1($1)',[id(100)]);return 'VALID';},'VALID');
 await ex("set TimeZone='UTC'");
 await test('PUBLIC_AND_CALLBACK_CONFIG_UTC',async()=>await one("select bool_and(p.proconfig@>array['TimeZone=UTC'])from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in('cp7_credit','public')and p.proname in('initial_preserved_source_v1','initial_base_events_v1','native_return_enter','native_return_guard','native_return_complete','assert_initial_work_v1','assert_current_source_plan_profile','assert_financial_materialization_provenance','assert_initial_return_closed_v1','erp_cp7_get_sales_return_settlement_quote_v1','erp_cp7_settle_sales_return_v1')"),true);
 await ex('begin');
 await test('NATIVE_STATUS_ONLY_PRESERVES_SOURCE',async()=>{const a=await one('select cp7_credit.initial_preserved_source_v1($1)',[id(100)]);await q("update erp.sales_headers set status='POSTED',row_version=row_version+1 where id=$1",[id(100)]);return JSON.stringify(a)===JSON.stringify(await one('select cp7_credit.initial_preserved_source_v1($1)',[id(100)]));},true);await ex('rollback');
 await ex('begin');
 const originalToken=await one('select cp7_sales.review_token($1)',[id(100)]);
 await q("insert into erp.sales_returns(id,return_number,sale_id,customer_id,physical_at,status)values($1,'OWN',$2,$3,'2026-10-19 01:00Z','DRAFT')",[id(300),id(100),id(10)]);
 await q('insert into erp.sales_return_items(id,return_id,product_id,location_id,qty_pcs,refund_amount,sale_stock_allocation_id)values($1,$2,$3,$4,1,200,$5)',[id(301),id(300),id(11),id(12),id(13)]);
 await test('OWN_DRAFT_RESTORES_EXACT_NATIVE_REVIEW',async()=>({raw_changed:originalToken!==await one('select cp7_sales.review_token($1)',[id(100)]),
  own_exclusion_restores:originalToken===await one('select cp7_credit.review_before_own_draft_v1($1,$2)',[id(100),id(300)])}),{raw_changed:true,own_exclusion_restores:true});
 await q("insert into erp.sales_returns(id,return_number,sale_id,customer_id,physical_at,status)values($1,'OTHER',$2,$3,'2026-10-19 02:00Z','DRAFT')",[id(302),id(100),id(10)]);
 await test('OTHER_DRAFT_IS_NOT_EXCLUDED',async()=>originalToken!==await one('select cp7_credit.review_before_own_draft_v1($1,$2)',[id(100),id(300)]),true);await ex('rollback');
 for(const[name,mutate,pattern]of[
  ['EXTRA_NATIVE_AR_LINE',async()=>{await line(203,200,1,'100','0');await line(204,200,2,'0','100');},'CP7_CREDIT_NATIVE_SALE_AR_OR_PAIR_CHANGED'],
  ['WRONG_NATIVE_SALE_ECONOMIC',()=>q("update erp.journal_entries set economic_date='2026-10-19',transaction_date='2026-10-19'where id=$1",[id(200)]),'CP7_CREDIT_NATIVE_SALE_AR_OR_PAIR_CHANGED'],
  ['PAYMENT_POSTING_FACT_AMOUNT_TAMPER',()=>q('update erp.sales_payment_posting_facts set amount=901 where payment_id=$1',[id(500)]),'CP7_CREDIT_NATIVE_PAYMENT_FACT_CHANGED'],
  ['PAYMENT_REVERSED_MISSING_FACT',async()=>{await q("update erp.sales_payments set status='REVERSED'where id=$1",[id(500)]);await q("update erp.journal_entries set status='REVERSED'where id=$1",[id(600)]);},'CP7_CREDIT_NATIVE_PAYMENT_REVERSAL_FACT_CHANGED']]){
  await ex('begin');await mutate();await refuses(name,'select cp7_credit.assert_simple_native_base_v1($1)',[id(100)],pattern);await ex('rollback');
 }
 await ex('begin');await journal(700,'CP7_CUSTOMER_CREDIT_RECOGNITION',800);await line(701,700,1,'200','0');await line(702,700,2,'0','200');
 await refuses('UNREPRESENTED_CREDIT_NO_FASTPATH','select cp7_credit.current_effective_paid($1)',[id(100)],'CP7_CREDIT_UNREPRESENTED_FINANCIAL_JOURNAL');await ex('rollback');
 stage='complete';
 result.status=results.every(x=>x.pass)?'PASS':'FAIL';
}catch(e){result.status='FAIL';result.setup_error={stage,message:e.message,detail:e.detail,where:e.where,position:e.position,internalQuery:e.internalQuery};}
result.stage=stage;
const output=JSON.stringify(result,null,2)+'\n';
if(result.status!=='PASS'&&!fs.existsSync(path.join(dir,'FIRST_FAILURE.json')))fs.writeFileSync(path.join(dir,'FIRST_FAILURE.json'),output);
fs.writeFileSync(path.join(dir,'RESULT.json'),output);
console.log(JSON.stringify({status:result.status,stage,checks:results.length,failures:results.filter(x=>!x.pass).map(x=>x.id),setup_error:result.setup_error??null,native_execution_proven:false}));
await db.close();if(result.status!=='PASS')process.exitCode=1;
