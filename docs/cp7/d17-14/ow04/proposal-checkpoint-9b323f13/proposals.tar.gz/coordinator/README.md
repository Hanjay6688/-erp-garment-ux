# Executable initial coordinator checkpoint

This directory contains concrete SQL outside the product. It is not installable
or a completed Native paid-return feature. Every SQL file retains its installer
barrier. Root owns the atomic builder and actual Native qualification.

01–06 implement protected work/provenance facts, source-locked initial planning,
server quote projection, actual DRAFT mapping, NEW_POST family registration,
ordinal-wrapper binding, immutable INITIAL support/components/parts, actual
recognition materialization, the refund operation callback, final receipt and
context-free deferred factual closure. 07 supplies the exact private role
capabilities;08 derives the existing outer wrapper with factual closure after
persisting its real receipt;09 supplies the two exact public facades and paged
eligible account choices. API_METADATA.json records signatures and capabilities.

The supported initial CP7 path has an active uncorrected Native sale, no
incoming U or existing credit cohort, and complete proved source/registration.
Previous registered empty families are allowed only with identically zero
before excess at every joint economic/book cut. Selected current lot costs
must be exact cents and the complete current Native cumulative HPP target/book
must reconcile. This covers the standard source fixture stock10@10, sale5×200,
P1000/900, return1/value200, I200/100. Native remains responsible for actual
stock, cost freezing and journal construction; the bound poster compares its
exact financial projection before posting. No Native source/payment is changed.

Projected UUID-free return semantics and actual random Native IDs have separate
manifests and an explicit mapping proof. Signed K0 plans still require CREDIT
and a vetted explicit liability account. Native storage parts do not cap or
round the aggregate component. Initial REFUND is the full positive server K.
Its fixed economic date is retained; the earliest source-proved book candidate
must pass the complete future joint-capacity grid. The complete candidate
manifest is bound into the quote, protected operation and post-wait callback.

All own proof serializers and callbacks pin UTC. Native original configs and
retained digest codecs are unchanged. Current E delegates unconditionally to
the shared root-aware core for U−I; this coordinator has no competing early-P
formula. The refund digest uses the poster's exact read-only journal verifier,
while keeping an independent liability-first semantic line comparison.

Current blocking limits are explicit:

- The temporary unparticipating direct-Native route preserves the original
  Native guard/poster and old P11 lifecycle, but leaves genuinely new direct
  Native empty families unregistered. Final installation is blocked until a
  protected technical Native owning-operation/first-post registration exists.
- Bound correction, retained-credit source changes, U, multi-cohort adjustment
  and later consumer/inverse writers remain refused. Historical order is never
  guessed. These are development limits, not new owner policy.
- Root must derive both complete context-manifest capabilities and both narrow
  Native poster copies from approved captures, compose every Native/private
  inverse/reader dependency, then run the real transaction and race cases.

check_coordinator.mjs runs actual proposed SQL against selected Native table
DDL and explicitly synthetic rows in PGlite. No successful permission function,
Native posting writer or authority stub is supplied.07's actual Auth/context
grant composition remains unexecuted where those real capabilities are absent.
RESULT.json records the limited checks and exact source hashes; it is not Native
money evidence. FIRST_FAILURE preserves an IF/CASE compilation failure that was
fixed. FIRST_BOOK_CASE_FAILURE preserves a driver input mistake: the locked
counter's earlier economic19 was accidentally supplied as20;20/20 was valid.
Independent refund-order/shared-core/timezone first-red and repaired receipts
remain in ../dependency-counter, without rewriting their expected outcomes.
FIRST_NATIVE_FACT_TIMEZONE_FIXTURE_FAILURE preserves the PGlite fixture's
unrequested default Etc/GMT-9 creation codec; UTC-pinned verification refused
those unchanged raw Native facts. The repaired driver creates a NEW synthetic
fixture under UTC, then verifies protected reads under both caller timezones.
It never rewrites a retained fact/hash or qualifies historical non-UTC codecs.
