"""Read root's exact transform; all output belongs to this counter directory.

No active write/DB/Native call. Metadata cases are an explicit raw-source
approval MODEL, not a capture or approval of an installed ERP predecessor.
"""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import re

HERE = Path(__file__).resolve().parent
READERS = HERE.parent
REPO = Path('/workspace/scratch/9442228ed2dc/erp-d1714')
spec = importlib.util.spec_from_file_location('root_reader_transforms', READERS / '03_reader_transforms.py')
root = importlib.util.module_from_spec(spec)
spec.loader.exec_module(root)


def extract(text, name):
    match = re.search(r'^create(?: or replace)? function ' + re.escape(name) + r'\s*\(', text, re.M | re.I)
    if not match:
        raise ValueError('ACTUAL_FUNCTION_NOT_FOUND:' + name)
    tail = text[match.start():]
    tag = re.search(r'\bas\s+(\$[A-Za-z_0-9]*\$)', tail, re.I)
    end = tail.index(tag[1] + ';', tag.end())
    return tail[:end + len(tag[1]) + 1], tail[tag.end():end]


def main():
    if '--view' in sys.argv:
        print(json.dumps({'view': root.receivables_view(json.load(sys.stdin)['view'])}))
        return
    sales = (REPO / 'scripts/cp7-src/sales/read.sql').read_text()
    history = (REPO / 'scripts/cp7-src/sales/customer-history.sql').read_text()
    capabilities = (READERS / '01_current_reader_capability.proposal.sql').read_text()
    definitions, changed, approval_cases = {}, {}, []
    identities = [('cp7_sales.header(erp.sales_headers,boolean)', sales, 'cp7_sales_read', False, ['search_path=""']),
                  ('cp7_customer_history.summary(uuid,boolean)', history, 'postgres', True, ['search_path=""']),
                  ('cp7_customer_history.workspace(jsonb)', history, 'postgres', True, ['search_path=""', 'TimeZone=UTC'])]
    for identity, text, owner, definer, config in identities:
        definition, body = extract(text, identity.split('(')[0])
        capture = dict(identity=identity, owner=owner, acl=['EXPLICIT_SYNTHETIC_PRIVATE_SOURCE_APPROVAL_MODEL'],
                       security_definer=definer, volatility='s', config=config, definition=definition, body=body)
        approved = {k: capture[k] for k in ('identity', 'owner', 'acl', 'security_definer', 'volatility', 'config')}
        approved.update(definition_sha256=root.digest(definition), body_sha256=root.digest(body))
        new, receipt = root.derive(capture, approved)
        definitions[identity] = definition
        changed[identity] = new
        for key in ['owner', 'acl', 'security_definer', 'volatility', 'config', 'definition_sha256', 'body_sha256']:
            bad = dict(approved)
            bad[key] = not bad[key] if isinstance(bad[key], bool) else 'UNAPPROVED'
            try:
                root.derive(capture, bad)
            except ValueError:
                approval_cases.append({'identity': identity, 'fault': key, 'status': 'REFUSED'})
            else:
                raise AssertionError('METADATA_NOT_REFUSED:' + key)
    anchor_cases = []
    pairs = [(root.header_body, "||case when p_financial then (select jsonb_build_object('financial',jsonb_build_object(", identities[0][0]),
             (root.summary_body, 'with inv as(select * from cp7_customer_history.invoices(p_customer)),', identities[1][0]),
             (root.workspace_body, 'from cp7_customer_history.invoices(v_cust.id)i', identities[2][0])]
    for fn, anchor, identity in pairs:
        _, body = extract(definitions[identity], identity.split('(')[0])
        for name, broken in [('MISSING', body.replace(anchor, 'BROKEN', 1)), ('DUPLICATE', body + '\n' + anchor)]:
            try:
                fn(broken)
            except ValueError:
                anchor_cases.append({'identity': identity, 'fault': name, 'status': 'REFUSED'})
            else:
                raise AssertionError('ANCHOR_NOT_REFUSED:' + name)
    bootstrap = gzip.decompress((REPO / 'supabase/tests/fixtures/erp_enteng_cp45a_catalog_bootstrap.sql.gz').read_bytes()).decode()
    start = bootstrap.index('create or replace view "erp"."v_customer_receivables" with (security_invoker=true) as')
    end = bootstrap.index('alter view "erp"."v_customer_receivables" owner to "postgres";', start)
    view = bootstrap[start:end]
    view_faults = []
    needle = 'COALESCE(p.paid_amount, 0::numeric)'
    for label, broken in [('MISSING', view.replace(needle, 'BROKEN', 1)), ('DUPLICATE', view + needle)]:
        try:
            root.receivables_view(broken)
        except ValueError:
            view_faults.append({'fault': label, 'status': 'REFUSED'})
        else:
            raise AssertionError('VIEW_ANCHOR_NOT_REFUSED:' + label)
    out = dict(classification='ACTUAL_SOURCE_DERIVATION_WITH_EXPLICIT_METADATA_APPROVAL_MODEL_NOT_NATIVE',
               root_transform_sha256=hashlib.sha256((READERS / '03_reader_transforms.py').read_bytes()).hexdigest(),
               originals=definitions, transformed=changed, history_helper=root.HISTORY_HELPER_SQL,
               history_functions={name: extract(history, 'cp7_customer_history.' + name)[0] for name in ('access_now', 'invoices', 'ended_at', 'events', 'summary', 'workspace')},
               actual_core_functions={name: extract(capabilities, name)[0] for name in ('cp7_credit.current_leaf_assignment', 'cp7_credit.assert_current_materialized_profile', 'erp._cp7_current_credit_adjustment', 'erp._cp7_current_credit_adjustment_visible', 'erp._cp7_receivable_credit_adjustment')},
               original_view=view, transformed_view=root.receivables_view(view), metadata_faults=approval_cases, anchor_faults=anchor_cases, view_faults=view_faults)
    (HERE / 'DERIVATION.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({'metadata_faults': len(approval_cases), 'anchor_faults': len(anchor_cases), 'root_transform_sha256': out['root_transform_sha256']}))


if __name__ == '__main__':
    main()
