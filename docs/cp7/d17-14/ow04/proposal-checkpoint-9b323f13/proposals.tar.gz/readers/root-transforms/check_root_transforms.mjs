// Actual root transforms/core/P11 definitions on explicit synthetic tables.
// No passing materialization stub, Native setup, RLS/Auth or posting claim.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const dir=path.dirname(fileURLToPath(import.meta.url));
const {PGlite}=await import(process.env.OW04_PGLITE_MODULE??'/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js');
const hash=s=>createHash('sha256').update(s).digest('hex');
const expectedText=await fs.readFile(path.join(dir,'LEGACY_EXTENSION_EXPECTED.json'),'utf8'),expected=JSON.parse(expectedText);
const sourceText=await fs.readFile(path.join(dir,'DERIVATION.json'),'utf8'),s=JSON.parse(sourceText);
assert.equal(s.actual_core_file_sha256,expected.actual_core_source_sha256,'reviewed core source changed; freeze a new expected revision before execution');
const result={classification:'ISOLATED_ACTUAL_READER_TRANSFORM_SQL_WITH_REAL_UNIMPLEMENTED_CORE_NOT_NATIVE',native_execution_proven:false,active_repo_modified:false,
 expected_sha256:hash(expectedText),derivation_sha256:hash(sourceText),root_transform_sha256:s.root_transform_sha256,actual_core_file_sha256:s.actual_core_file_sha256,prior_result_preserved:'BEFORE_LEGACY_FASTPATH/RESULT.json',
 auth_stubs:'Explicit synthetic auth.uid/auth.jwt/get_my_access/has_permission; no real Auth/RLS claim',passing_materialization_stub:false,cases:[]};
const db=new PGlite();const q=(sql,args=[])=>db.query(sql,args),ex=sql=>db.exec(sql);
const val=async(sql,args=[])=>(await q(sql,args)).rows[0].v;
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const customer=id(1),sale=id(2),ret=id(3),payment=id(4),location=id(5);
let stage='scaffold';
async function fault(fn,message='CP7_CREDIT_CURRENT_MATERIALIZED_PROFILE_UNIMPLEMENTED'){await ex('savepoint expected_core_fault');let seen;try{await fn();}catch(e){seen=e;}await ex('rollback to savepoint expected_core_fault');await ex('release savepoint expected_core_fault');assert.ok(seen?.message.includes(message),String(seen?.message??'core was silently skipped'));return seen.message;}
async function test(id,fn){stage=id;await ex('begin');try{const observed=await fn();await ex('rollback');result.cases.push({id,status:'PASS',observed:observed??null});}catch(e){await ex('rollback');throw e;}}
try{
 await ex(`
 create role anon;create role authenticated;create role service_role;create role cp7_capture;
 create role cp7_sales_read;create role cp7_sales_write;create role cp7_customer_history_read;
 create schema erp;create schema auth;create schema cp7_sales;create schema cp7_customer_history;create schema cp7_credit;create schema cp7_note;
 create table erp.customers(id uuid primary key,customer_code text,customer_name text,is_active boolean);
 create table erp.locations(id uuid primary key,location_name text);
 create table erp.sales_headers(id uuid primary key,sale_number text,customer_id uuid,source_location_id uuid,sale_date timestamptz,due_date date,status text,row_version bigint,notes text,payment_terms text);
 create table erp.sales_items(id uuid primary key,sale_id uuid,line_total numeric,qty_pcs integer);
 create table erp.sales_returns(id uuid primary key,sale_id uuid,status text,return_number text,physical_at timestamptz);
 create table erp.sales_return_items(id uuid primary key,return_id uuid,refund_amount numeric,qty_pcs integer);
 create table erp.sales_payments(id uuid primary key,sale_id uuid,amount numeric,status text,payment_number text,payment_date timestamptz,payment_method text);
 create table erp.fg_stock_movements(id uuid,source_id uuid,source_type text,movement_type text,qty_signed integer,reversal_of_id uuid);
 create table erp.audit_logs(entity_type text,entity_id uuid,action text,changed_at timestamptz,new_data jsonb,old_data jsonb);
 create table cp7_note.revisions(root_sale_id uuid,previous_sale_id uuid,replacement_sale_id uuid,revision bigint);
 create table erp.journal_entries(id uuid primary key,source_type text,source_id uuid);
 create table cp7_credit.return_families(id uuid primary key,family_root_sale_id uuid);
 create table cp7_credit.cohorts(id uuid primary key,family_id uuid);
 create table cp7_credit.recognition_plans(id uuid primary key,cohort_id uuid);
 create table cp7_credit.recognition_components(id uuid primary key,plan_id uuid);
 create table cp7_credit.component_parts(id uuid primary key,component_id uuid,amount numeric);
 create table cp7_credit.component_journals(part_id uuid,journal_id uuid);
 create table cp7_credit.consumption_events(id uuid primary key,cohort_id uuid,event_kind text,target_sale_id uuid,amount numeric,journal_id uuid);
 create function auth.uid()returns uuid language sql stable as $$select '00000000-0000-0000-0000-000000000099'::uuid$$;
 create function auth.jwt()returns jsonb language sql stable as $$select '{"role":"authenticated"}'::jsonb$$;
 create function erp.get_my_access_v1()returns jsonb language sql stable as $$select '{"allowed":true}'::jsonb$$;
 create function erp.has_permission(p text)returns boolean language sql stable as $$select p='sales.history.view'or(p='finance.ar.view'and coalesce(current_setting('root_counter.financial',true),'false')='true')$$;
 set root_counter.financial='false';set TimeZone='UTC';
 `);
 for(const name of ['cp7_credit.current_leaf_assignment','cp7_credit.assert_current_materialized_profile','erp._cp7_current_credit_adjustment','erp._cp7_current_credit_adjustment_visible','erp._cp7_receivable_credit_adjustment'])await ex(s.actual_core_functions[name]);
 await ex(s.originals['cp7_sales.header(erp.sales_headers,boolean)']);
 await ex('alter function cp7_sales.header(erp.sales_headers,boolean)owner to cp7_sales_read;revoke all on function cp7_sales.header(erp.sales_headers,boolean)from public,anon,authenticated,service_role,cp7_capture;');
 for(const name of ['access_now','invoices','ended_at','events','summary','workspace'])await ex(s.history_functions[name]);
 await ex('revoke all on function cp7_customer_history.summary(uuid,boolean),cp7_customer_history.workspace(jsonb)from public,anon,authenticated,service_role,cp7_capture,cp7_customer_history_read;grant execute on function cp7_customer_history.workspace(jsonb)to cp7_customer_history_read;');
 await ex(s.original_view);await ex('grant select on erp.v_customer_receivables to authenticated;');
 const metadata=async()=> (await q("select p.oid::regprocedure::text identity,pg_get_userbyid(p.proowner)owner,p.proacl::text acl,p.prosecdef definer,p.provolatile::text volatility,p.proconfig config from pg_proc p where p.oid in('cp7_sales.header(erp.sales_headers,boolean)'::regprocedure,'cp7_customer_history.summary(uuid,boolean)'::regprocedure,'cp7_customer_history.workspace(jsonb)'::regprocedure)order by p.oid::regprocedure::text")).rows;
 const viewMeta=async()=> (await q("select pg_get_userbyid(c.relowner)owner,c.relacl::text acl,c.reloptions options,(select jsonb_agg(jsonb_build_array(a.attname,a.atttypid,a.atttypmod)order by a.attnum)from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)columns from pg_class c where c.oid='erp.v_customer_receivables'::regclass")).rows[0];
 const beforeMeta=await metadata(),beforeView=await viewMeta();
 const originalInvoiceBody=await val("select prosrc v from pg_proc where oid='cp7_customer_history.invoices(uuid)'::regprocedure"),originalEventsBody=await val("select prosrc v from pg_proc where oid='cp7_customer_history.events(uuid)'::regprocedure");
 await ex(s.history_helper);
 for(const definition of Object.values(s.transformed))await ex(definition.replace(/^create function/i,'create or replace function'));
 const canonicalView=await val("select pg_get_viewdef('erp.v_customer_receivables'::regclass,true)v");
 const transformedCanonical=JSON.parse(execFileSync('python',['-B',path.join(dir,'derive_controls.py'),'--view'],{input:JSON.stringify({view:canonicalView}),encoding:'utf8'})).view;
 await ex('create or replace view erp.v_customer_receivables with(security_invoker=true)as '+transformedCanonical);
 await q("insert into erp.customers values($1,'SYNTHETIC','Synthetic customer',true)",[customer]);
 await q("insert into erp.locations values($1,'Synthetic warehouse')",[location]);
 await q("insert into erp.sales_headers values($1,'SYNTHETIC1000',$2,$3,'2026-10-17 04:00Z','2026-10-20','PAID',1,null,'CREDIT')",[sale,customer,location]);
 await q('insert into erp.sales_items values($1,$2,1000,5)',[id(6),sale]);
 await q("insert into erp.sales_returns values($1,$2,'POSTED','SYNTHETICR200','2026-10-19 04:00Z')",[ret,sale]);
 await q('insert into erp.sales_return_items values($1,$2,200,1)',[id(7),ret]);
 await q("insert into erp.sales_payments values($1,$2,1000,'POSTED','SYNTHETICP1000','2026-10-18 04:00Z','TRANSFER')",[payment,sale]);
 // Explicit EMPTY registration keeps original financial-refusal controls on
 // the new registered-family branch; no successful proof is substituted.
 await q('insert into cp7_credit.return_families values($1,$2)',[id(8),sale]);
 const header=financial=>val('select cp7_sales.header(h,$2)v from erp.sales_headers h where id=$1',[sale,financial]);
 const invoices=financial=>q('select *from cp7_credit.customer_history_invoices($1,$2)',[customer,financial]);
 await test('THREE_REAL_FUNCTIONS_COMPILE',async()=>{assert.deepEqual(await metadata(),beforeMeta);return await metadata();});
 await test('APPROVED_SOURCE_METADATA_MODEL_AND_FAULTS',async()=>{assert.equal(s.metadata_faults.length,21);assert.ok(s.metadata_faults.every(x=>x.status==='REFUSED'));return{faults:s.metadata_faults.length,scope:'raw-source approval model only, not installed predecessor approval'};});
 await test('EXACT_ANCHOR_MISSING_DUPLICATE_REFUSED',async()=>{assert.equal(s.anchor_faults.length,6);assert.ok(s.anchor_faults.every(x=>x.status==='REFUSED'));assert.equal(s.view_faults.length,2);assert.ok(s.view_faults.every(x=>x.status==='REFUSED'));return{function_faults:s.anchor_faults.length,view_faults:s.view_faults.length};});
 await test('NATIVE_VIEW_THREE_EXPRESSIONS_AND_METADATA',async()=>{assert.equal((transformedCanonical.match(/erp\._cp7_receivable_credit_adjustment\(sh\.id\)/g)??[]).length,3);assert.ok(!/coalesce\s*\(\s*erp\._cp7_receivable_credit_adjustment/i.test(transformedCanonical));assert.deepEqual(await viewMeta(),beforeView);return await viewMeta();});
 await test('HEADER_NONFINANCIAL_DOES_NOT_EXECUTE_CORE',async()=>{const h=await header(false);assert.equal('financial'in h,false);assert.equal(h.number,'SYNTHETIC1000');return h;});
 await test('HEADER_ACTIVE_FINANCIAL_PROPAGATES_REAL_CORE_REFUSAL',async()=>({error:await fault(()=>header(true))}));
 await test('HEADER_INACTIVE_OWN_P_OPEN_NULL',async()=>{await q("update erp.sales_headers set status='REVERSED'where id=$1",[sale]);const h=await header(true);assert.equal(h.financial.paid_total,'1000.00');assert.equal(h.financial.open_balance,null);assert.equal(h.financial.state,'INACTIVE_DOCUMENT');return h.financial;});
 await test('HISTORY_HELPER_EXACT14_COLUMNS',async()=>{const fields=['sale_id','sale_number','sale_date','due_date','sale_status','location_id','qty_pcs','line_count','gross','returned','paid','net','open_balance','state'];const out=await invoices(false);assert.deepEqual(Object.keys(out.rows[0]),fields);assert.equal(await val("select pg_get_function_result('cp7_customer_history.invoices(uuid)'::regprocedure)v"),await val("select pg_get_function_result('cp7_credit.customer_history_invoices(uuid,boolean)'::regprocedure)v"));const same=(await q("select p.proallargtypes::text types,p.proargmodes::text modes from pg_proc p where p.oid in('cp7_customer_history.invoices(uuid)'::regprocedure,'cp7_credit.customer_history_invoices(uuid,boolean)'::regprocedure)order by p.oid")).rows;for(const who of['anon','authenticated','service_role','cp7_customer_history_read'])assert.equal(await val('select has_function_privilege($1,\'cp7_credit.customer_history_invoices(uuid,boolean)\',\'EXECUTE\')v',[who]),false);assert.equal(await val("select prosrc v from pg_proc where oid='cp7_customer_history.invoices(uuid)'::regprocedure"),originalInvoiceBody);return{fields,raw_paid:out.rows[0].paid,types:same,app_or_history_facade_EXEC:false};});
 await test('HISTORY_NONFINANCIAL_DOES_NOT_EXECUTE_CORE',async()=>{const row=(await invoices(false)).rows[0];assert.equal(Number(row.paid),1000);assert.equal(row.state,'ACTIVE_RECEIVABLE');return row;});
 await test('SUMMARY_NONFINANCIAL_COUNTS_NO_CORE',async()=>{const out=await val('select cp7_customer_history.summary($1,false)v',[customer]);assert.equal('financial'in out,false);assert.deepEqual(out.counts,{invoices:'1',payments:'1',returns:'1',cancellations:'0'});return out;});
 await test('WORKSPACE_NONFINANCIAL_TIMELINE_NO_CORE',async()=>{const out=await val('select cp7_customer_history.workspace($1::jsonb)v',[JSON.stringify({customer_id:customer,limit:25,offset:0})]);assert.equal(out.financial_captured,false);assert.equal(out.timeline.total,'3');assert.equal(out.invoices.length,1);assert.ok(!('financial'in out.invoices[0]));assert.ok(out.timeline.rows.every(row=>!('financial'in row)));assert.equal(await val("select prosrc v from pg_proc where oid='cp7_customer_history.events(uuid)'::regprocedure"),originalEventsBody);return out;});
 await test('HISTORY_ACTIVE_FINANCIAL_PROPAGATES_REAL_CORE_REFUSAL',async()=>({helper:await fault(()=>invoices(true)),summary:await fault(()=>val('select cp7_customer_history.summary($1,true)v',[customer]))}));
 await test('HISTORY_INACTIVE_OWN_P_OPEN_NULL',async()=>{await q("update erp.sales_headers set status='REVERSED'where id=$1",[sale]);const row=(await invoices(true)).rows[0];assert.equal(Number(row.paid),1000);assert.equal(row.open_balance,null);assert.equal(row.state,'INACTIVE_DOCUMENT');return row;});
 await test('PRIVATE_HELPER_ONCE_MATERIALIZED',async()=>{assert.ok(/original as materialized/i.test(s.history_helper));assert.ok(/adjusted as materialized/i.test(s.history_helper));assert.equal((s.history_helper.match(/erp\._cp7_current_credit_adjustment\(sale_id\)/g)??[]).length,1);assert.equal((s.transformed['cp7_sales.header(erp.sales_headers,boolean)'].match(/erp\._cp7_current_credit_adjustment\(h\.id\)/g)??[]).length,1);await q("update erp.sales_headers set status='DRAFT'where id=$1",[sale]);const row=(await invoices(true)).rows[0];assert.equal(Number(row.paid),1000);assert.equal(row.open_balance,null);return{source_once_expression:true,materialized:true,draft_ownP:row.paid,call_counter_execution_claimed:false};});
 await test('NATIVE_VIEW_ACTIVE_PROPAGATES_REAL_CORE_REFUSAL',async()=>({error:await fault(()=>q('select *from erp.v_customer_receivables'))}));
 await test('LEGACY_UNREGISTERED_ORDINARY_RETURN_OWN_P',async()=>{await ex('delete from cp7_credit.return_families');await q('update erp.sales_payments set amount=500 where id=$1',[payment]);const h=await header(true),invoice=(await invoices(true)).rows[0],summary=await val('select cp7_customer_history.summary($1,true)v',[customer]);assert.equal(h.financial.paid_total,'500.00');assert.equal(h.financial.open_balance,'300.00');assert.equal(Number(invoice.paid),500);assert.equal(Number(invoice.open_balance),300);assert.equal(summary.financial.paid_total,'500.00');assert.equal(summary.financial.open_balance,'300.00');await ex("set local root_counter.financial='true'");const workspace=await val('select cp7_customer_history.workspace($1::jsonb)v',[JSON.stringify({customer_id:customer})]);assert.equal(workspace.invoices[0].financial.paid_total,'500.00');assert.equal(workspace.invoices[0].financial.open_balance,'300.00');assert.equal(await val('select count(*)::integer v from cp7_credit.return_families'),0);return{header:h.financial,history:workspace.invoices[0].financial,no_invented_family:true};});
 await test('LEGACY_ORPHAN_RECOGNITION_REFUSED',async()=>{await ex('delete from cp7_credit.return_families');await q("insert into erp.journal_entries values($1,'CP7_CUSTOMER_CREDIT_RECOGNITION',$2)",[id(80),id(81)]);return{error:await fault(()=>header(true),'CP7_CREDIT_UNREPRESENTED_FINANCIAL_JOURNAL')};});
 await test('LEGACY_ORPHAN_REFUND_REFUSED',async()=>{await ex('delete from cp7_credit.return_families');await q("insert into erp.journal_entries values($1,'CP7_CUSTOMER_CREDIT_REFUND',$2)",[id(82),id(83)]);return{error:await fault(()=>invoices(true),'CP7_CREDIT_UNREPRESENTED_FINANCIAL_JOURNAL')};});
 await test('REGISTERED_EMPTY_STILL_VALIDATES',async()=>{assert.equal(await val('select count(*)::integer v from cp7_credit.return_families'),1);assert.equal(await val('select count(*)::integer v from cp7_credit.cohorts'),0);return{error:await fault(()=>header(true))};});
 await test('INCOMING_APPLY_STILL_VALIDATES',async()=>{await ex('delete from cp7_credit.return_families');await q("insert into cp7_credit.consumption_events(id,event_kind,target_sale_id,amount)values($1,'APPLY',$2,100)",[id(84),sale]);return{error:await fault(()=>header(true))};});
 assert.deepEqual(result.cases.map(x=>x.id),expected.controls);result.status='PASS';result.executed_controls=result.cases.length;result.positive_financial800_executed=false;
}catch(e){result.status='FAIL';result.failed_step=stage;result.error=String(e.stack??e);result.sql_where=e.where??null;process.exitCode=1;}
finally{await db.close();await fs.writeFile(path.join(dir,'RESULT.json'),JSON.stringify(result,null,2)+'\n');}
console.log(JSON.stringify({status:result.status,controls:result.cases.length,failed_step:result.failed_step??null,positive_financial800_executed:false}));
