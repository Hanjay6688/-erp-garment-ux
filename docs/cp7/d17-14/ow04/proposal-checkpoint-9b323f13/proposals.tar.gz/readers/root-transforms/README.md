# Independent root reader-transform counter

No active proposal/repository edit or Native execution. These controls compile
and execute the actual root-authored transform output, private history helper,
actual original P11/history SQL and Native receivables view in PGlite with
explicitly synthetic tables and Auth predicates. The real proposed core01 is
used. Its deliberate materialization refusal is retained; there is **no passing
materialization stub** and no positive800 financial-source claim.

Initial expected was locked in `EXPECTED_FIRST.json` before execution. The first
result was15/15; its result, exact derived definitions and scripts are preserved
in `BEFORE_LEGACY_FASTPATH/`. After root changed the actual core, the extension
expected was separately frozen in `LEGACY_EXTENSION_EXPECTED.json` before the
fixture/code extension. The latest result is **20/20 PASS**:

- All three actual transformed functions compile. Their owner, ACL, definer
  flag, volatility and configuration remain unchanged across replacement.
- Native view replacement has exactly three adjustment expressions, preserves
  owner/ACL/security_invoker/column names and types, and adds no NULL-to-zero
  adjustment fallback. Real active-core errors propagate out of the view.
- P11 and history nonfinancial calls avoid the actual refusing core, including
  real summary/count/timeline/workspace execution. Original events/invoices
  function bodies are unchanged.
- Private history helper has the same14 output columns and PostgreSQL result
  types as the original, with no app/facade EXEC. One adjustment expression in
  MATERIALIZED is verified per helper-row evaluation; a runtime function-call
  counter is not claimed. Inactive/DRAFT retain ownP and openNULL.
- RegisteredEMPTY families still hit the real materialization refusal. For
  legacy no-family/no-APPLY history, gross1000/ordinaryreturn200/P500 preserves
  P500/AR300 in header/helper/summary/workspace without inventing a family.
- Actual orphan recognition/refund rows refuse before the active legacy
  fastpath returns0. IncomingAPPLY also requires the real validator. These
  journal rows are synthetic control inputs, not Native posted-source evidence.
- Twenty-one metadata mutations and six function-anchor plus two view-anchor
  faults are refused by the pure derivation model.

Run only these isolated controls:

```sh
python -B /workspace/scratch/9442228ed2dc/ow04-proposals/readers/root-transforms/derive_controls.py
node /workspace/scratch/9442228ed2dc/ow04-proposals/readers/root-transforms/check_root_transforms.mjs
```

The runner pins the reviewed core file to the separately frozen extension
expected. `OW04_PGLITE_MODULE` may point to an existing alternative PGlite module.
The generated `DERIVATION.json` binds the root transform and core source hashes;
`RESULT.json` records exact SQL observations and scope.

Raw-source metadata approval is an explicitly labelled **model** in this
counter. Trusted installed-predecessor approval, Native RLS, full ledger
materialization, Auth/PostgREST, posting, current-role races, performance and
whole-feature integration remain unproved. No source-authority success is
inferred from compilation, legacy0 adjustment, or synthetic rows. These20
controls add zero Native/browser/HTTP/race manifest claims.
