// Synthetic PGlite only: Native ACL/Auth/ledger completeness are NOT exercised.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {gunzipSync} from 'node:zlib';
const dir=path.dirname(new URL(import.meta.url).pathname);
const repo=process.env.OW04_REPO??'/workspace/scratch/9442228ed2dc/erp-d1714';
const mod=process.env.PGLITE_MODULE??'/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
const {PGlite}=await import(mod.startsWith('file:')?mod:pathToFileURL(mod).href);
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const proposal=fs.readFileSync(path.join(dir,'01_current_reader_capability.proposal.sql'),'utf8');
const expected=fs.readFileSync(path.join(dir,'EXPECTED.json'),'utf8');
const bootstrap=gunzipSync(fs.readFileSync(path.join(repo,'supabase/tests/fixtures/erp_enteng_cp45a_catalog_bootstrap.sql.gz'))).toString();
const start=bootstrap.indexOf('create or replace view "erp"."v_customer_receivables" with (security_invoker=true) as');
const end=bootstrap.indexOf('alter view "erp"."v_customer_receivables" owner to "postgres";',start);
if(start<0||end<0)throw Error('actual original view missing');
const originalView=bootstrap.slice(start,end);
const needle='COALESCE(p.paid_amount, 0::numeric)';
if(originalView.split(needle).length-1!==3)throw Error('actual payment expressions drift');
const candidateView=originalView.replaceAll(needle,'(COALESCE(p.paid_amount, 0::numeric) + erp._cp7_receivable_credit_adjustment(sh.id))');
const extract=name=>{
 const s=proposal.indexOf(`create function ${name}`);
 const e=proposal.indexOf('end $$;',s);
 if(s<0||e<0)throw Error(`function missing ${name}`);
 return proposal.slice(s,e+'end $$;'.length);
};
const leaf=extract('cp7_credit.current_leaf_assignment(');
const visible=extract('erp._cp7_current_credit_adjustment_visible(');
const dispatch=extract('erp._cp7_receivable_credit_adjustment(');
const db=new PGlite();
const results=[];
const q=async sql=>(await db.query(sql)).rows;
const val=async sql=>Object.values((await q(sql))[0])[0];
const check=async(id,fn)=>{await fn();results.push({id,status:'PASS'});};
const eq=(a,b)=>{if(a!==b)throw Error(`expected ${JSON.stringify(b)}, observed ${JSON.stringify(a)}`);};
const asRole=async(role,actor,fn)=>{
 await db.exec(`set role ${role}`);
 await db.query("select set_config('ow04.synthetic_actor',$1,false)",[actor]);
 try{return await fn();}finally{await db.exec('reset role');}
};
const denied=async sql=>{let caught;try{await db.exec(sql);}catch(e){caught=e;}if(!caught||caught.code!=='42501')throw caught??Error('expected permission denial');};
try{
 await db.exec(`
 create role authenticated nologin noinherit nosuperuser nobypassrls;
 create role anon nologin noinherit nosuperuser nobypassrls;
 create role service_role nologin noinherit nosuperuser bypassrls;
 create role cp7_credit_visible_read nologin noinherit nosuperuser nobypassrls;
 create schema erp;create schema auth;create schema cp7_note;create schema cp7_credit;
 create table erp.customers(id uuid primary key,customer_name text);
 create table erp.sales_headers(id uuid primary key,customer_id uuid,sale_number text,sale_date timestamptz,due_date date,status text);
 create table erp.sales_items(sale_id uuid,line_total numeric);
 create table erp.sales_payments(sale_id uuid,amount numeric,status text);
 create table erp.sales_returns(id uuid,sale_id uuid,status text);
 create table erp.sales_return_items(return_id uuid,refund_amount numeric);
 create table cp7_note.revisions(root_sale_id uuid,previous_sale_id uuid,replacement_sale_id uuid,revision bigint);
 create table cp7_credit.synthetic_adjustments(root_sale_id uuid,adjustment numeric);
 create table cp7_credit.synthetic_fault(fault boolean);insert into cp7_credit.synthetic_fault values(false);
 create function erp.current_app_role()returns text language sql stable security definer set search_path=''as $$
  select nullif(current_setting('ow04.synthetic_actor',true),'') $$;
 grant usage on schema erp to authenticated,service_role,cp7_credit_visible_read;
 grant select on all tables in schema erp to authenticated,service_role;
 grant select on erp.sales_headers,erp.customers,erp.sales_items to cp7_credit_visible_read;
 grant execute on function erp.current_app_role()to authenticated,cp7_credit_visible_read;
 insert into erp.customers values('00000000-0000-0000-0000-000000000001','Synthetic');
 insert into erp.sales_headers values
 ('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','OLD','2026-10-18',null,'REVERSED'),
 ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000001','LEAF','2026-10-18',null,'PAID');
 insert into cp7_note.revisions values('10000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002',1);
 insert into erp.sales_items values('10000000-0000-0000-0000-000000000001',1000),('10000000-0000-0000-0000-000000000002',1000);
 insert into erp.sales_payments values('10000000-0000-0000-0000-000000000002',1000,'POSTED');
 insert into erp.sales_returns values('20000000-0000-0000-0000-000000000002','10000000-0000-0000-0000-000000000002','POSTED');
 insert into erp.sales_return_items values('20000000-0000-0000-0000-000000000002',200);
 insert into cp7_credit.synthetic_adjustments values('10000000-0000-0000-0000-000000000001',-200);
 `);
 for(const table of ['customers','sales_headers','sales_items','sales_payments','sales_returns','sales_return_items']){
  await db.exec(`alter table erp.${table} enable row level security;
   create policy internal_all on erp.${table} for all to public
    using(erp.current_app_role()=any(array['OWNER','ADMIN','STAFF']))
    with check(erp.current_app_role()=any(array['OWNER','ADMIN','STAFF']));`);
 }
 await db.exec(leaf);
 // Synthetic replacement of the deliberately unfinished actual-source core.
 // This exercises exact proposed ACL/dispatch code, NOT Native ledger facts.
 await db.exec(`create function erp._cp7_current_credit_adjustment(p_sale uuid)returns numeric
  language plpgsql stable security definer set search_path=''as $$declare m record;h erp.sales_headers;v numeric;begin
  if(select fault from cp7_credit.synthetic_fault)then raise exception 'SYNTHETIC_CORE_FAULT';end if;
  select *into strict h from erp.sales_headers where id=p_sale;
  if h.status not in('POSTED','PARTIAL_PAID','PAID')then return 0::numeric;end if;
  select *into strict m from cp7_credit.current_leaf_assignment(p_sale);
  select adjustment into strict v from cp7_credit.synthetic_adjustments where root_sale_id=m.root_sale_id;
  return v;end $$;
  revoke all on function erp._cp7_current_credit_adjustment(uuid)from public,anon,authenticated,service_role;
  grant execute on function erp._cp7_current_credit_adjustment(uuid)to cp7_credit_visible_read,service_role;`);
 await db.exec(visible);
 await db.exec(`alter function erp._cp7_current_credit_adjustment_visible(uuid)owner to cp7_credit_visible_read;
  revoke all on function erp._cp7_current_credit_adjustment_visible(uuid)from public,anon,authenticated,service_role;
  grant execute on function erp._cp7_current_credit_adjustment_visible(uuid)to authenticated;`);
 await db.exec(dispatch);
 await db.exec(`revoke all on function erp._cp7_receivable_credit_adjustment(uuid)from public,anon,authenticated,service_role;
  grant execute on function erp._cp7_receivable_credit_adjustment(uuid)to authenticated,service_role;`);
 await db.exec(originalView);
 await db.exec('grant select on erp.v_customer_receivables to authenticated,service_role');
 const originalAcl=await val("select relacl::text from pg_class where oid='erp.v_customer_receivables'::regclass");
 await db.exec(candidateView);
 await db.exec(`create function erp.synthetic_native_engine()returns numeric language sql stable security definer set search_path=''as $$
  select paid_amount from erp.v_customer_receivables $$;
  revoke all on function erp.synthetic_native_engine()from public;
  grant execute on function erp.synthetic_native_engine()to authenticated;
  create function erp.synthetic_header_branch(p_sale uuid,p_financial boolean)returns jsonb
  language sql stable security definer set search_path=''as $$select case when p_financial then
   jsonb_build_object('adjustment',erp._cp7_current_credit_adjustment(p_sale))else'{}'::jsonb end $$;
  revoke all on function erp.synthetic_header_branch(uuid,boolean)from public;
  grant execute on function erp.synthetic_header_branch(uuid,boolean)to authenticated;`);
 const sale="'10000000-0000-0000-0000-000000000002'::uuid";
 const old="'10000000-0000-0000-0000-000000000001'::uuid";
 await check('LEGACY_ROLE_NO_NEW_PERMISSION',()=>asRole('authenticated','STAFF',async()=>{
  eq(await val('select paid_amount::text from erp.v_customer_receivables'),'800.00');
  eq(await val('select outstanding_amount::text from erp.v_customer_receivables'),'0.00');
  eq(await val('select credit_amount::text from erp.v_customer_receivables'),'0.00');
 }));
 await check('PRIVATE_CORE_AUTH_DENIED',()=>asRole('authenticated','STAFF',()=>denied(`select erp._cp7_current_credit_adjustment(${sale})`)));
 await check('PRIVATE_FACTS_AUTH_DENIED',()=>asRole('authenticated','STAFF',()=>denied('select *from cp7_credit.synthetic_adjustments')));
 await check('INVISIBLE_DIRECT_SCALAR',()=>asRole('authenticated','CUSTOMER',async()=>{
  eq(await val(`select erp._cp7_receivable_credit_adjustment(${sale})`),null);
  eq(await val('select count(*)::int from erp.v_customer_receivables'),0);
 }));
 await check('NULL_ACTOR_NO_BYPASS',()=>asRole('authenticated','',async()=>{
  eq(await val(`select erp._cp7_receivable_credit_adjustment(${sale})`),null);
  eq(await val('select count(*)::int from erp.v_customer_receivables'),0);
 }));
 await check('NATIVE_DEFINER_ENGINE',()=>asRole('authenticated','',async()=>{
  eq(await val('select erp.synthetic_native_engine()::text'),'800.00');
 }));
 await check('SERVICE_ROLE_VIEW',()=>asRole('service_role','',async()=>eq(await val('select paid_amount::text from erp.v_customer_receivables'),'800.00')));
 await check('CORE_ACL_NOT_ROLE_ARGUMENT',async()=>{
  for(const [r,expected]of[['authenticated',false],['cp7_credit_visible_read',true],['service_role',true]])
   eq(await val(`select has_function_privilege('${r}','erp._cp7_current_credit_adjustment(uuid)','EXECUTE')`),expected);
 });
 await check('NOBYPASS_NOT_TABLE_OWNER',async()=>{
  eq(await val("select rolbypassrls from pg_roles where rolname='cp7_credit_visible_read'"),false);
  eq(await val("select count(*)::int from pg_class where relnamespace='erp'::regnamespace and relowner='cp7_credit_visible_read'::regrole"),0);
 });
 await check('NONFINANCIAL_SHORT_CIRCUIT',async()=>{
  await db.exec('update cp7_credit.synthetic_fault set fault=true');
  await asRole('authenticated','STAFF',async()=>{
   eq(await val(`select erp.synthetic_header_branch(${sale},false)::text`),'{}');
   let caught;try{await db.exec(`select erp.synthetic_header_branch(${sale},true)`);}catch(e){caught=e;}
   if(!caught?.message.includes('SYNTHETIC_CORE_FAULT'))throw caught??Error('true branch must call core');
  });
  await db.exec('update cp7_credit.synthetic_fault set fault=false');
 });
 await check('ACTUAL_LEAF_NOT_ROOT_ALIAS',async()=>{
  eq(await val(`select erp._cp7_current_credit_adjustment(${old})::text`),'0');
  eq(await val(`select erp._cp7_current_credit_adjustment(${sale})::text`),'-200');
  eq(await val(`select root_sale_id::text from cp7_credit.current_leaf_assignment(${old})`),'10000000-0000-0000-0000-000000000001');
  eq(await val(`select current_leaf_id::text from cp7_credit.current_leaf_assignment(${sale})`),'10000000-0000-0000-0000-000000000002');
 });
 await check('RESTORE_ORIGINAL_VIEW',async()=>{
  await db.exec(originalView);
  eq(await val("select relacl::text from pg_class where oid='erp.v_customer_receivables'::regclass"),originalAcl);
  eq(await val("select reloptions::text from pg_class where oid='erp.v_customer_receivables'::regclass"),'{security_invoker=true}');
  await asRole('authenticated','STAFF',async()=>eq(await val('select paid_amount::text from erp.v_customer_receivables'),'1000.00'));
 });
 if(results.length!==JSON.parse(expected).cases.length)throw Error('expected case count mismatch');
}catch(e){
 const failure={scope:JSON.parse(expected).scope,results,error:{message:e.message,code:e.code,stack:e.stack}};
 const first=path.join(dir,'FIRST_FAILURE.json');if(!fs.existsSync(first))fs.writeFileSync(first,JSON.stringify(failure,null,2)+'\n');
 fs.writeFileSync(path.join(dir,'RESULT.json'),JSON.stringify({...failure,status:'FAIL'},null,2)+'\n');
 throw e;
}finally{await db.close();}
const result={scope:JSON.parse(expected).scope,status:'PASS',count:results.length,results,
 proposal_sha256:hash(proposal),expected_sha256:hash(expected),driver_sha256:hash(fs.readFileSync(new URL(import.meta.url))),
 actual_original_view_sha256:hash(originalView),synthetic_candidate_view_sha256:hash(candidateView),
 native_execution:false,real_auth:false,ledger_materialization_proven:false,concurrency_proven:false};
fs.writeFileSync(path.join(dir,'RESULT.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
