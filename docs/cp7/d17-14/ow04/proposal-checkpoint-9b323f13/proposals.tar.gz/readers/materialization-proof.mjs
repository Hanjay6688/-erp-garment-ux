// Isolated proposed SQL + synthetic rows only. NO Native/Auth/authority proof.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {pathToFileURL}from'node:url';
const dir=path.dirname(new URL(import.meta.url).pathname),base=path.dirname(dir);
const mod=process.env.PGLITE_MODULE??'/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
const {PGlite}=await import(mod.startsWith('file:')?mod:pathToFileURL(mod).href);
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const expectedText=fs.readFileSync(path.join(dir,'MATERIALIZED_EXPECTED.json'),'utf8'),expected=JSON.parse(expectedText);
const receipt=JSON.parse(fs.readFileSync(path.join(dir,'MATERIALIZED_EXPECTED_RECEIPT.json'),'utf8'));
if(sha(expectedText)!==receipt.expected_sha256)throw Error('frozen expected changed');
const additionalText=fs.readFileSync(path.join(dir,'MATERIALIZED_ADDITIONAL_EXPECTED.json'),'utf8');
if(sha(additionalText)!==JSON.parse(fs.readFileSync(path.join(dir,'MATERIALIZED_ADDITIONAL_RECEIPT.json'),'utf8')).expected_sha256)throw Error('additional expected changed');
const recostText=fs.readFileSync(path.join(dir,'MATERIALIZED_RECOST_EXPECTED.json'),'utf8');
if(sha(recostText)!==JSON.parse(fs.readFileSync(path.join(dir,'MATERIALIZED_RECOST_RECEIPT.json'),'utf8')).expected_sha256)throw Error('recost expected changed');
const files={tables:path.join(base,'source/ISOLATED_TABLES.sql'),ledger:path.join(base,'ledger/01_immutable_facts.proposal.sql'),
 poster:path.join(base,'ledger/02_uuid_poster.proposal.sql'),noj:path.join(base,'source/NO_JOURNAL_SCHEMA_DIFF.proposal.sql'),
 reader:path.join(dir,'01_current_reader_capability.proposal.sql'),materialized:path.join(dir,'02_materialized_profile.proposal.sql')};
const texts=Object.fromEntries(Object.entries(files).map(([k,p])=>[k,fs.readFileSync(p,'utf8')]));
const removeBarrier=s=>s.replace(/do \$not_an_installer\$[\s\S]*?end \$not_an_installer\$;/,'-- removed only in isolated synthetic DB');
const extract=(s,name)=>{const a=s.indexOf(`create function ${name}`),b=s.indexOf('end $$;',a);if(a<0||b<0)throw Error(`missing ${name}`);return s.slice(a,b+7);};
const db=new PGlite(),results=[];let stage='setup';
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const q=(s,p=[])=>db.query(s,p),ex=s=>db.exec(s);
const one=async(s,p=[])=>Object.values((await q(s,p)).rows[0])[0];
const roots=[id(100),id(100),id(100)];
const obj=()=>one('select cp7_credit.current_materialized_objects($1,$2,$3)',roots);
const read=()=>one('select cp7_credit.inspect_current_materialized_profile($1,$2,$3)',roots);
const insertJournal=async(n,type,src,e='2026-10-19',b=e,status='POSTED',inverse=null)=>q(
 "insert into erp.journal_entries(id,journal_number,economic_date,transaction_date,posting_at,source_type,source_id,description,status,reversal_of_id)values($1,$2,$3,$4,$4::date::timestamptz,$5,$6,'Synthetic only',$7,$8)",
 [id(n),`J${n}`,e,b,type,id(src),status,inverse===null?null:id(inverse)]);
const insertLine=async(n,j,a,d,c,description='OW04 source-bound recognition',customer=1)=>q(
 'insert into erp.journal_lines(id,journal_entry_id,account_id,debit,credit,customer_id,description)values($1,$2,$3,$4,$5,$6,$7)',[id(n),id(j),id(a),d,c,id(customer),description]);
const setHashes=async()=>{
 await ex(`update cp7_credit.recognition_components cc set kernel_component=jsonb_build_object('amount',cp7_credit.cent_text(cc.amount),
  'economic_date',cc.economic_date::text,'transaction_date',cc.transaction_date::text,'previous_economic_date',cc.previous_economic_date::text,
  'previous_transaction_date',cc.previous_transaction_date::text,'corners',cc.corners);
 update cp7_credit.recognition_components set component_sha256_pg=cp7_credit.pg_jsonb_sha256(kernel_component);
 update cp7_credit.recognition_plans p set components_sha256_pg=(select cp7_credit.pg_jsonb_sha256(coalesce(jsonb_agg(cc.kernel_component order by cc.ordinal),'[]'))from cp7_credit.recognition_components cc where cc.plan_id=p.id),
 parts_sha256_pg=(select cp7_credit.pg_jsonb_sha256(coalesce(jsonb_agg(jsonb_build_object('id',q.id,'component_id',cc.id,'ordinal',q.ordinal,'amount',cp7_credit.cent_text(q.amount))order by cc.ordinal,q.ordinal),'[]'))
  from cp7_credit.recognition_components cc join cp7_credit.component_parts q on q.component_id=cc.id where cc.plan_id=p.id);`);
 await q(`update cp7_credit.component_journals j set lines_sha256_pg=(select cp7_credit.native_lines_sha256(jsonb_agg(
  jsonb_build_object('account_id',l.account_id,'customer_id',l.customer_id,'description',l.description,'debit',l.debit,'credit',l.credit)
  order by case when l.account_id=$1 then 0 else 1 end,l.id))from erp.journal_lines l where l.journal_entry_id=j.journal_id)`,[id(3)]);
};
const seal=async()=>{
 await ex('delete from cp7_credit.financial_materialization_objects;delete from cp7_credit.financial_materializations');
 await q(`insert into cp7_credit.financial_materializations(id,root_sale_id,actor,request_id,request_ordinal,owning_action,payload_sha256,source_plan_sha256,actual_objects,actual_objects_sha256)
  select $1,$2,$3,$4,1,'SYNTHETIC_DATA_ONLY',repeat('1',64),repeat('2',64),v->'actual_objects',v->>'actual_objects_sha256'
  from(select cp7_credit.current_materialized_objects($2,$2,$2)v)s`,[id(700),id(100),id(90),id(91)]);
 await q(`insert into cp7_credit.financial_materialization_objects select x->>'object_kind',(x->>'object_id')::uuid,$1,x->>'fact_sha256'
  from cp7_credit.financial_materializations f cross join lateral jsonb_array_elements(f.actual_objects)x where f.id=$1`,[id(700)]);
};
const consumption=async()=>{
 await insertJournal(610,'CP7_CUSTOMER_CREDIT_APPLY',450,'2026-10-19','2026-10-19','REVERSED');
 await insertLine(6100,610,4,'60','0','Synthetic consumption');await insertLine(6101,610,3,'0','60','Synthetic consumption');
 await insertJournal(611,'JOURNAL_REVERSAL',610,'2026-10-20','2026-10-20','POSTED',610);
 await insertLine(6110,611,4,'0','60','Synthetic consumption');await insertLine(6111,611,3,'60','0','Synthetic consumption');
 await q(`insert into cp7_credit.consumption_events(id,cohort_id,event_kind,amount,economic_date,transaction_date,target_sale_id,restores_event_id,journal_id,source_sha256,lines_sha256_pg,actor,request_id,reason)
  values($1,$3,'APPLY',60,'2026-10-19','2026-10-19',$4,null,$5,repeat('1',64),repeat('2',64),$7,$8,'Synthetic only'),
  ($2,$3,'APPLY',-60,'2026-10-20','2026-10-20',$4,$1,$6,repeat('1',64),repeat('2',64),$7,$8,'Synthetic only')`,
 [id(450),id(451),id(400),id(100),id(610),id(611),id(90),id(92)]);
 await seal();
};
const noJournal=async()=>{
 await ex(`delete from cp7_credit.financial_materialization_objects;delete from cp7_credit.financial_materializations;
  delete from cp7_credit.component_journals;delete from cp7_credit.component_parts;delete from cp7_credit.recognition_components;
  delete from cp7_credit.plan_support_events;delete from cp7_credit.recognition_plans;delete from cp7_credit.cohorts;`);
 await q(`update cp7_credit.return_family_members set financial_state='NO_JOURNAL',source_journal_id=null,
  financial_source_proof=jsonb_build_object('contract_version','ow04.native-no-return-journal-proof.v1','return_id',return_id::text,
   'document',jsonb_build_object('id',return_id),'items',jsonb_build_array(jsonb_build_object('id',$1::uuid)),
   'actual_original_fg_movements','[]'::jsonb,'actual_allocations','[]'::jsonb,'financial_event','ABSENT')`,[id(210)]);
 await q('delete from erp.journal_lines where journal_entry_id=any($1::uuid[])',[[id(501),id(600),id(601)]]);
 await q('delete from erp.journal_entries where id=any($1::uuid[])',[[id(501),id(600),id(601)]]);
 await ex('update erp.sales_return_items set refund_amount=0,unit_hpp_snapshot=0;update erp.sale_stock_allocations set unit_hpp_snapshot=0');
 await q(`insert into erp.fg_stock_movements(id,product_id,lot_id,location_id,movement_type,qty_signed,unit_hpp_snapshot,source_type,source_id,customer_id,physical_at)
  values($1,$2,$3,$4,'SALE_RETURN',1,0,'SALES_RETURN_ITEM',$5,$6,'2026-10-19 01:00Z')`,[id(800),id(10),id(12),id(13),id(210),id(1)]);
 await seal();
};
try{
 await ex(texts.tables);stage='synthetic_native_primary_keys';
 for(const t of['customers','chart_accounts','sales_headers','sales_returns','journal_entries','cash_accounts']){
  const present=await one('select exists(select 1 from pg_constraint where conrelid=$1::regclass and contype=\'p\')',[`erp.${t}`]);
  if(!present)await ex(`alter table erp.${t} add primary key(id)`);
 }
 stage='ledger_ddl';await ex(removeBarrier(texts.ledger));stage='poster_ddl';await ex(removeBarrier(texts.poster));stage='noj_ddl';await ex(removeBarrier(texts.noj));
 stage='assignment_ddl';
 await ex(extract(texts.reader,'cp7_credit.current_leaf_assignment('));
 stage='materialized_ddl';await ex(removeBarrier(texts.materialized));
 // Corruption controls bypass immutable triggers ONLY in this synthetic DB.
 // They do not add any application privilege, Auth admission or Native writer.
 const tables=(await q("select tablename from pg_tables where schemaname='cp7_credit'")).rows;
 for(const {tablename}of tables)await ex(`alter table cp7_credit.${tablename} disable trigger user`);
 stage='synthetic_fixture';
 await ex('begin');
 await q("insert into erp.customers(id,customer_code,customer_name)values($1,'C1','Synthetic1'),($2,'C2','Synthetic2')",[id(1),id(2)]);
 for(const[n,name,type,normal]of[[3,'AR','ASSET','DEBIT'],[4,'CREDIT','LIABILITY','CREDIT'],[5,'REVENUE','REVENUE','CREDIT'],[6,'CASH','ASSET','DEBIT']])
  await q('insert into erp.chart_accounts(id,account_code,account_name,account_type,report_group,normal_balance)values($1,$2,$2,$3,$2,$4)',[id(n),name,type,normal]);
 await q("insert into erp.sales_headers(id,sale_number,customer_id,sale_date,status)values($1,'S1',$3,'2026-10-18 01:00Z','PAID'),($2,'S2',$3,'2026-10-18 01:00Z','POSTED'),($4,'OTHER',$5,'2026-10-18 01:00Z','POSTED')",[id(100),id(101),id(1),id(102),id(2)]);
 await q('insert into erp.sales_items(id,sale_id,product_id,qty_pcs,unit_price_snapshot)values($1,$2,$3,5,200)',[id(110),id(100),id(10)]);
 await q("insert into erp.sales_returns(id,return_number,sale_id,customer_id,physical_at,status)values($1,'R1',$2,$3,'2026-10-19 01:00Z','POSTED')",[id(200),id(100),id(1)]);
 await q('insert into erp.sale_stock_allocations(id,sale_item_id,lot_id,location_id,qty_pcs,unit_hpp_snapshot)values($1,$2,$3,$4,5,10)',[id(220),id(110),id(12),id(13)]);
 await q('insert into erp.sales_return_items(id,return_id,product_id,lot_id,location_id,qty_pcs,unit_hpp_snapshot,refund_amount,sale_stock_allocation_id)values($1,$2,$3,$4,$5,1,10,200,$6)',[id(210),id(200),id(10),id(12),id(13),id(220)]);
 await insertJournal(500,'SALE',100,'2026-10-18');await insertLine(5000,500,3,'1000','0','Native-like sale');await insertLine(5001,500,5,'0','1000','Native-like sale');
 await insertJournal(501,'SALES_RETURN',200);await insertLine(5010,501,5,'200','0','Native-like return');await insertLine(5011,501,3,'0','200','Native-like return');
 await q(`insert into cp7_credit.return_families(id,family_root_sale_id,family_ordinal,first_return_id,assignment_kind,assignment_proof,source_sha256,actor,request_id)
  values($1,$2,1,$3,'NEW_POST','{}',repeat('1',64),$4,$5)`,[id(300),id(100),id(200),id(90),id(91)]);
 await q(`insert into cp7_credit.return_family_members(family_id,return_id,member_kind,source_journal_id,source_sha256,actual_lineage_snapshot,actor,request_id,financial_state)
  values($1,$2,'ORIGINAL',$3,repeat('1',64),'{}',$4,$5,'JOURNAL')`,[id(300),id(200),id(501),id(90),id(91)]);
 await q(`insert into cp7_credit.cohorts(id,family_id,source_sale_id,source_return_id,customer_id,ar_account_id,source_ar_snapshot,credit_account_id,credit_account_snapshot,
  initial_mode,initial_net_amount,initial_plan_id,source_sale_journal_id,source_return_journal_id,source_sale_sha256,source_return_sha256,actor,request_id,source_return_financial_state)
  values($1,$2,$3,$4,$5,$6,'{}',$7,'{}','CREDIT',200,$8,$9,$10,repeat('1',64),repeat('2',64),$11,$12,'JOURNAL')`,
 [id(400),id(300),id(100),id(200),id(1),id(3),id(4),id(410),id(500),id(501),id(90),id(91)]);
 for(const[n,kind,amount,ordinal]of[[410,'INITIAL','200',1],[411,'ADJUSTMENT','-100',2]])await q(`insert into cp7_credit.recognition_plans(
  id,cohort_id,plan_kind,owning_action,actor,request_id,request_ordinal,payload_sha256,review_sha256,family_root_sale_id,before_events,added_events,kernel_result,kernel_version,
  before_source_sha256,after_source_sha256,support_sha256_pg,components_sha256_pg,parts_sha256_pg,net_amount,has_recognition_effect,expected_component_count,expected_part_count)
  values($1,$2,$3,'SYNTHETIC',$4,$5,$6,repeat('1',64),repeat('2',64),$7,'[]','[]','{}','ow04-2d-difference-v1',repeat('1',64),repeat('2',64),repeat('1',64),repeat('1',64),repeat('1',64),$8,true,1,1)`,
 [id(n),id(400),kind,id(90),id(91),ordinal,id(100),amount]);
 for(const[n,plan,amount,date,part,j]of[[420,410,'200','2026-10-19',430,600],[421,411,'-100','2026-10-20',431,601]]){
  await q(`insert into cp7_credit.recognition_components(id,plan_id,ordinal,economic_date,transaction_date,amount,corners,kernel_component,component_sha256_pg)
   values($1,$2,1,$3,$3,$4::numeric,jsonb_build_object('d_here',($4::numeric)::text,'d_prev_economic','0.00','d_prev_transaction','0.00','d_prev_both','0.00'),'{}',repeat('1',64))`,[id(n),id(plan),date,amount]);
  await q('insert into cp7_credit.component_parts values($1,$2,1,$3)',[id(part),id(n),amount]);
  await insertJournal(j,'CP7_CUSTOMER_CREDIT_RECOGNITION',part,date);
  if(Number(amount)>0){await insertLine(j*10,j,3,amount,'0');await insertLine(j*10+1,j,4,'0',amount);}
  else{await insertLine(j*10,j,3,'0',String(-Number(amount)));await insertLine(j*10+1,j,4,String(-Number(amount)),'0');}
  await q('insert into cp7_credit.component_journals(part_id,journal_id,economic_date,transaction_date,lines_sha256_pg)values($1,$2,$3,$3,repeat(\'1\',64))',[id(part),id(j),date]);
 }
 stage='fixture_hashes';await setHashes();stage='fixture_materialization';await seal();await ex('commit');
 const cases={
  ALL_SIGNED_ADJUSTMENTS:read,
  PENDING_PART_NOT_COUNTED:async()=>{await q('delete from cp7_credit.component_journals where part_id=$1',[id(431)]);return read();},
  PART_HASH_CHANGED:async()=>{await q('update cp7_credit.component_parts set amount=199 where id=$1',[id(430)]);return read();},
  COMPONENT_HASH_CHANGED:async()=>{await q("update cp7_credit.recognition_components set component_sha256_pg=repeat('0',64)where id=$1",[id(420)]);return read();},
  PLAN_NET_CHANGED:async()=>{await q('update cp7_credit.recognition_plans set net_amount=-99 where id=$1',[id(411)]);return read();},
  WRONG_ROOT_ARGUMENT:()=>one('select cp7_credit.inspect_current_materialized_profile($1,$2,$1)',[id(100),id(101)]),
  WRONG_LEAF_ARGUMENT:()=>one('select cp7_credit.inspect_current_materialized_profile($1,$1,$2)',[id(100),id(101)]),
  WRONG_MEMBER_ROOT:async()=>{await q('update cp7_credit.return_families set family_root_sale_id=$1',[id(101)]);return read();},
  MISSING_POSTED_RETURN_MEMBER:async()=>{await q("insert into erp.sales_returns(id,return_number,sale_id,customer_id,physical_at,status)values($1,'UNREGISTERED',$2,$3,'2026-10-20 01:00Z','POSTED')",[id(201),id(100),id(1)]);return read();},
  WRONG_MEMBER_JOURNAL:async()=>{await q('update cp7_credit.return_family_members set source_journal_id=$1',[id(500)]);return read();},
  WRONG_COHORT_SOURCE:async()=>{await q('update cp7_credit.cohorts set source_sale_id=$1',[id(101)]);return read();},
  WRONG_PLAN_ROOT:async()=>{await q('update cp7_credit.recognition_plans set family_root_sale_id=$1',[id(101)]);return read();},
  ACTUAL_JOURNAL_WRONG_TYPE:async()=>{await q("update erp.journal_entries set source_type='MISC'where id=$1",[id(600)]);return read();},
  ACTUAL_JOURNAL_WRONG_SOURCE:async()=>{await q('update erp.journal_entries set source_id=$1 where id=$2',[id(431),id(600)]);return read();},
  ACTUAL_JOURNAL_WRONG_ECONOMIC_DATE:async()=>{await q("update erp.journal_entries set economic_date='2026-10-18'where id=$1",[id(600)]);return read();},
  ACTUAL_JOURNAL_WRONG_BOOK_DATE:async()=>{await q("update erp.journal_entries set transaction_date='2026-10-20'where id=$1",[id(600)]);return read();},
  SIDECAR_DATE_CHANGED:async()=>{await q("update cp7_credit.component_journals set transaction_date='2026-10-20'where part_id=$1",[id(430)]);return read();},
  ACTUAL_JOURNAL_DRAFT:async()=>{await q("update erp.journal_entries set status='DRAFT'where id=$1",[id(600)]);return read();},
  ACTUAL_LINES_CUSTOMER_CHANGED:async()=>{await q('update erp.journal_lines set customer_id=$1 where journal_entry_id=$2',[id(2),id(600)]);return read();},
  ACTUAL_LINES_DIMENSION_CHANGED:async()=>{await q('update erp.journal_lines set po_id=$1 where journal_entry_id=$2',[id(10),id(600)]);return read();},
  ACTUAL_LINES_AMOUNT_CHANGED:async()=>{await q('update erp.journal_lines set debit=201 where id=$1',[id(6000)]);return read();},
  ACTUAL_LINES_EXTRA_BALANCED_PAIR:async()=>{await insertLine(6990,600,3,'1','0');await insertLine(6991,600,4,'0','1');return read();},
  ACTUAL_LINE_HASH_CHANGED:async()=>{await q("update cp7_credit.component_journals set lines_sha256_pg=repeat('0',64)where part_id=$1",[id(430)]);return read();},
  UNREGISTERED_PART_JOURNAL:async()=>{await insertJournal(699,'CP7_CUSTOMER_CREDIT_RECOGNITION',999);await insertLine(6990,699,3,'1','0');await insertLine(6991,699,4,'0','1');return read();},
  UNREGISTERED_RECOGNITION_INVERSE:async()=>{await q("update erp.journal_entries set status='REVERSED'where id=$1",[id(600)]);await insertJournal(699,'JOURNAL_REVERSAL',600,'2026-10-20','2026-10-20','POSTED',600);return read();},
  NO_JOURNAL_EMPTY_FAMILY:async()=>{await noJournal();return read();},
  NO_JOURNAL_RETURN_ZERO_ALLOCATION_TEN:async()=>{await noJournal();await ex('update erp.sale_stock_allocations set unit_hpp_snapshot=10');return read();},
  NO_JOURNAL_HAS_NATIVE_JOURNAL:async()=>{await noJournal();await insertJournal(501,'SALES_RETURN',200);return read();},
  NO_JOURNAL_HAS_HPP:async()=>{await noJournal();await ex('update erp.sales_return_items set unit_hpp_snapshot=1');return read();},
  NO_JOURNAL_WRONG_MOVEMENT:async()=>{await noJournal();await ex("update erp.fg_stock_movements set qty_signed=2");return read();},
  NO_FINANCIAL_COMPLETION_FACT:async()=>{await ex('delete from cp7_credit.financial_materialization_objects');return read();},
  COMPLETION_BINDING_CHANGED:async()=>{await ex("update cp7_credit.financial_materialization_objects set fact_sha256=repeat('0',64)where object_kind='PLAN'");return read();},
  DATA_COMPLETE_BEFORE_OUTER_RESPONSE:async()=>{await ex("create schema cp7_sales;create table cp7_sales.requests(response jsonb);insert into cp7_sales.requests values(null)");
   await q("insert into cp7_credit.execution_context values(pg_backend_pid(),txid_current(),$1,$2,$3,'SYNTHETIC',repeat('1',64),repeat('2',64),'{}')",[id(90),id(91),id(410)]);return read();},
  SOURCE_AUTHORITY_NOT_STUBBED:()=>one('select cp7_credit.assert_current_materialized_profile($1,$2,$3)',roots),
  NATIVE_STORAGE_SPLIT:async()=>{
   await ex('delete from cp7_credit.component_journals;delete from cp7_credit.component_parts;delete from cp7_credit.recognition_components;delete from cp7_credit.recognition_plans');
   await q('delete from erp.journal_lines where journal_entry_id=any($1::uuid[])',[[id(600),id(601)]]);await q('delete from erp.journal_entries where id=any($1::uuid[])',[[id(600),id(601)]]);
   await q('update cp7_credit.cohorts set initial_net_amount=$1',["1999999999999999999.98"]);
   await q(`insert into cp7_credit.recognition_plans select $1,$2,'INITIAL','SYNTHETIC',$3,$4,1,repeat('1',64),repeat('2',64),$5,'[]','[]','{}','ow04-2d-difference-v1',
    repeat('1',64),repeat('2',64),repeat('1',64),repeat('1',64),repeat('1',64),1999999999999999999.98,true,1,2,statement_timestamp()`,[id(410),id(400),id(90),id(91),id(100)]);
   await q(`insert into cp7_credit.recognition_components(id,plan_id,ordinal,economic_date,transaction_date,amount,corners,kernel_component,component_sha256_pg)
    values($1,$2,1,'2026-10-19','2026-10-19',1999999999999999999.98,'{"d_here":"1999999999999999999.98","d_prev_economic":"0.00","d_prev_transaction":"0.00","d_prev_both":"0.00"}','{}',repeat('1',64))`,[id(420),id(410)]);
   for(const[part,n,j]of[[430,1,600],[432,2,602]]){
    await q('insert into cp7_credit.component_parts values($1,$2,$3,999999999999999999.99)',[id(part),id(420),n]);await insertJournal(j,'CP7_CUSTOMER_CREDIT_RECOGNITION',part);
    await insertLine(j*10,j,3,'999999999999999999.99','0');await insertLine(j*10+1,j,4,'0','999999999999999999.99');
    await q("insert into cp7_credit.component_journals(part_id,journal_id,economic_date,transaction_date,lines_sha256_pg)values($1,$2,'2026-10-19','2026-10-19',repeat('1',64))",[id(part),id(j)]);
   }
   await setHashes();await seal();return read();
  },
  SIGNED_CONSUMPTION_RESTORE:async()=>{await consumption();return read();},
  CONSUMPTION_RESTORE_AMOUNT_CHANGED:async()=>{await consumption();await q('update cp7_credit.consumption_events set amount=-59 where id=$1',[id(451)]);return read();},
  CONSUMPTION_ACTUAL_PAIR_CHANGED:async()=>{await consumption();await q("update erp.journal_entries set transaction_date='2026-10-21'where id=$1",[id(611)]);return read();},
  CONSUMPTION_WRONG_CUSTOMER:async()=>{await consumption();await q('update cp7_credit.consumption_events set target_sale_id=$1',[id(102)]);return read();},
  CONSUMPTION_NONFINITE_LINES:async()=>{await consumption();await q("update erp.journal_lines set debit='NaN',credit='NaN'where journal_entry_id=$1",[id(610)]);return read();},
  CONSUMPTION_NEGATIVE_LINES:async()=>{await consumption();await q('update erp.journal_lines set debit=-1,credit=-1 where journal_entry_id=$1',[id(610)]);return read();},
  CONSUMPTION_NATIVE_INVERSE_LINK_CHANGED:async()=>{await consumption();await q('update erp.journal_entries set source_id=$1 where id=$2',[id(500),id(611)]);return read();}
 };
 for(const test of[...expected.cases,...JSON.parse(additionalText).cases,...JSON.parse(recostText).cases]){
  stage=test.id;await ex('begin');let actual,error;
  try{actual=await cases[test.id]();}catch(e){error=e;}
  await ex('rollback');
  if(test.expected==='MECHANICAL_ONLY'){
   if(error)throw error;
   if(actual.source_authority_proven!==false||actual.financial_data_complete!==true)throw Error('missing mechanical-only label');
   for(const k of['I','U'])if(test[k]!==undefined&&actual[k]!==test[k])throw Error(`${k} expected ${test[k]} actual ${actual[k]}`);
   results.push({id:test.id,status:'PASS_MECHANICAL_ONLY',I:actual.I,U:actual.U,source_authority_proven:false});
  }else{
   if(!error||!error.message.includes(test.expected))throw error??Error(`expected refusal ${test.expected}`);
   results.push({id:test.id,status:'EXPECTED_REFUSAL',message:error.message,code:error.code});
  }
 }
 stage='private_metadata_and_acl';
 const names=['materialized_fact','materialized_journal_payload','current_materialized_objects','inspect_current_materialized_profile','assert_current_materialized_profile'];
 const metadata=(await q(`select p.oid::regprocedure::text signature,p.proname,pg_get_userbyid(p.proowner)owner,p.provolatile,p.prosecdef,p.proconfig
  from pg_proc p where p.pronamespace='cp7_credit'::regnamespace and p.proname=any($1::text[])order by p.proname`,[names])).rows;
 if(metadata.length!==5)throw Error('exact private function list mismatch');
 for(const p of metadata){
  if(p.owner!=='postgres'||p.provolatile!==(p.proname==='materialized_fact'?'i':'s')||p.prosecdef!==(p.proname!=='materialized_fact')
   ||JSON.stringify(p.proconfig)!==JSON.stringify(['search_path=""',...(p.proname==='materialized_fact'?[]:['TimeZone=UTC'])]))throw Error('private function metadata mismatch');
  for(const r of['anon','authenticated','service_role','cp7_capture','cp7_sales_read','cp7_sales_write'])
   if(await one('select has_function_privilege($1,$2,\'EXECUTE\')',[r,p.signature]))throw Error(`private function EXEC leak ${r}`);
 }
 for(const t of['financial_materializations','financial_materialization_objects']){
  const row=(await q('select pg_get_userbyid(relowner)owner,relrowsecurity from pg_class where oid=$1::regclass',[`cp7_credit.${t}`])).rows[0];
  if(row.owner!=='postgres'||row.relrowsecurity!==true)throw Error('private fact ownership/RLS mismatch');
  for(const r of['anon','authenticated','service_role','cp7_capture','cp7_sales_read','cp7_sales_write'])
   if(await one('select has_table_privilege($1,$2,\'SELECT,INSERT,UPDATE,DELETE,TRUNCATE\')',[r,`cp7_credit.${t}`]))throw Error(`private fact privilege leak ${r}`);
 }
 const result={scope:expected.scope,status:'PASS',count:results.length,results,expected_sha256:sha(expectedText),additional_expected_sha256:sha(additionalText),
  recost_expected_sha256:sha(recostText),
  driver_sha256:sha(fs.readFileSync(new URL(import.meta.url))),private_metadata_and_acl_verified_in_synthetic_database:true,
  source_sha256:Object.fromEntries(Object.entries(texts).map(([k,s])=>[k,sha(s)])),native_execution:false,real_auth:false,
  source_authority_proven:false,owning_materializer_implemented:false,deferred_closure_implemented:false};
 fs.writeFileSync(path.join(dir,'MATERIALIZED_RESULT.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}catch(error){
 const result={scope:expected.scope,status:'FAIL',stage,results,message:error.message,code:error.code,where:error.where,stack:error.stack};
 const first=path.join(dir,'MATERIALIZED_FIRST_FAILURE.json');if(!fs.existsSync(first))fs.writeFileSync(first,JSON.stringify(result,null,2)+'\n');
 const attempts=fs.readdirSync(dir).filter(n=>/^MATERIALIZED_ATTEMPT_\d+\.json$/.test(n)).length;
 fs.writeFileSync(path.join(dir,`MATERIALIZED_ATTEMPT_${String(attempts+1).padStart(2,'0')}.json`),JSON.stringify(result,null,2)+'\n');
 console.error(JSON.stringify(result,null,2));process.exitCode=1;
}finally{await db.close();}
