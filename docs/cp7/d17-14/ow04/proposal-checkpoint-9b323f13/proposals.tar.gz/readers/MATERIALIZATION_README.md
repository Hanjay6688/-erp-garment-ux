# Concrete current materialization proposal

`02_materialized_profile.proposal.sql` is outside the active checkout and has a
mandatory pre-DDL refusal. It extends the earlier reader proposal using the
existing ledger01/02 and source `NO_JOURNAL_SCHEMA_DIFF.proposal.sql` protocols.
It is not installed. The source-plan verifier, protected owning materializer,
coordinator-provenance verifier and final deferred closure remain missing.

The implementation is three separate private STABLE steps, all using the same
statement snapshot and no lock-taking callback:

| Function | Concrete work | What it does not establish |
| --- | --- | --- |
| `current_materialized_objects(uuid sale,uuid root,uuid leaf)` | Validates requested active leaf; follows upstream incoming-credit roots; checks all actual family/member/cohort/plan/component/part/journal objects; emits their exact stable hashes and NET I/U. | Ordinal authority, semantic source target, consumption posting contract, owning operation provenance. |
| `inspect_current_materialized_profile(uuid,uuid,uuid)` | Requires exact private data-completion bindings for every derived actual object and verifies the corresponding protected manifest/binding set hashes. | A client/context/marker cannot authorize a source or journal. Extra objects outside this selected profile still need complete coordinator provenance. |
| `assert_current_materialized_profile(uuid,uuid,uuid)` | Concrete replacement of the previous always-refusing placeholder. Runs both steps, calls the exact pure source member verifier for every member, then requires source-plan and coordinator-provenance verifiers. | Missing callbacks refuse explicitly. No function returning OK is installed as a substitute. |

Every successful inspection says `source_authority_proven:false` and
`consumption_posting_contract_proven:false`. Those are meaningful limitations,
not feature-success flags.

## Exact actual coverage

The local implementation includes INITIAL and every ADJUSTMENT, with signs.
It checks each complete component/part array, contiguous stored ordinals, exact
sum, component/corner hash, deterministic mechanical split and part-array hash.
The bound journals must have the exact part UUID source, recognition source
type, economic/book pair, sidecar pair, two AR/liability cent lines, customer,
description, no unrelated dimensions, and the Native canonical line hash.
Missing links fail before I can be returned. There is no latest-plan, positive-
only, status, pending-own-plan, or incomplete-parts filter that fabricates I.

Unregistered recognition/APPLY/refund/event-reversal journals are detected.
Registered financial history for unrelated roots is not called an orphan just
because it is outside the current root's upstream profile. Full global account
and detector closure remains an integration responsibility.

All selected logical return families remain in the profile, including empty
families. Native finished returns must have registration; foreign roots,
incorrect source sale/member/journal, and contradictory cohort provenance
refuse. The NO_JOURNAL branch checks actual positive-quantity zero-refund and
zero-HPP RETURN lines, exact source allocation and one original matching physical FG
movement, plus absence of a Native return journal. It emits no artificial zero
journal, UUID, economic event or book date. Rebuilding the complete typed proof
and its digest belongs to the pure source member verifier, not this narrower
mechanical inspection.

It does not require the original sold allocation HPP to be zero. Accepted
Native recost10-to0 preserves the frozen sale allocation10 while a later return
can freeze its own return item/movement0 and post no journal. The independent
source peer found this over-restriction; a separate frozen control retains that
allocation10 and requires successful mechanical NOJ inspection.

The independent pure dependency is
`ow04_source_proposal.verify_return_member_v1(uuid)` from `source/member-proof.sql`.
It reads actual Native/member/lineage facts. It must not call current E, this
materialization validator or the VOLATILE locked source collector. The owning
installer must pin this exact helper, its dependencies, owners/config/ACL and
STABLE contract before admitting the full feature.

## Inverses and consumption

An ordinary Native `JOURNAL_REVERSAL` of a recognition part is not representable
as another recognition-part journal in the current ledger01/02 protocol. The
validator refuses it with `CP7_CREDIT_UNREPRESENTED_RECOGNITION_INVERSE`, including
a REVERSED part original. It never drops the original and declares a repaired
current balance. Signed ADJUSTMENT parts posted through the exact part protocol
are included normally. A future owning inverse protocol needs its own immutable
signed mapping/actual journals and tests before this refusal can be narrowed.

Signed APPLY/REFUND consumption and restore rows are retained. Mechanical checks
cover actual stored date pair, balanced journal presence, same-customer target,
finite/nonnegative balanced actual lines, and an exact full negative restore of
its referenced positive event with both source-date floors. An actual Native
JOURNAL_REVERSAL must point to that exact event's actual REVERSED journal on both
Native link fields. Original and restore both count; a restore does not erase
earlier consumption. The complete source-ID, account, dimensions, line hash,
inverse linkage and future joint capacity protocol is not invented where the
owning consumption writer has not been defined. Its verifier is mandatory before
`assert_current_materialized_profile` can return. A balanced journal by itself
does not prove credit funding or authority.

## Data completion before outer response

New private append-only tables are proposed:

- `financial_materializations`: actual-object manifest/hash, root, exact owning
  action/actor/request/ordinal, payload hash and source-plan binding.
- `financial_materialization_objects`: one immutable `(kind,id)` binding to its
  exact fact hash and materialization UUID.

The marker is derived only after actual journals and full part coverage exist.
It is data-complete evidence, not authority. A writer cannot mint it from a
client manifest or a context-exists test. The future owning coordinator must
recompute the exact hashes from actual rows under source/period locks, verify
source-plan equality and owning actor/action/payload, and bind only its **new**
objects. Existing immutable bindings are retained and compared, never deleted,
rebound or overwritten. Multiple historical materializations can therefore
cover one current profile.

Native completion can use this strict actual-data stage before its final header
status update and before the outer request response is saved. Neither outer
`requests.response` nor scopes-cleared is required inside current E. The frozen
`DATA_COMPLETE_BEFORE_OUTER_RESPONSE` control keeps response NULL and an execution
context present while actual complete-data inspection succeeds. Removing its
part/marker still refuses; the context supplies no bypass.

Final deferred owning closure is separately mandatory at COMMIT: final expected
header/status, exact inner/outer receipt, immutable owning-operation provenance
and completion, account/cash
and both-date/joint profile checks, complete operation/object coverage, and no
ephemeral scopes. This file does not install a placeholder deferred trigger.
Live actor and post-wait authority checks remain in the owning command before
the receipt; COMMIT does not reauthorize a recorded actor using a JWT or live
execution context.

`assert_financial_materialization_provenance(jsonb)` must validate the protected
fact's complete operation/source/request provenance without asking for the final
outer response at this earlier stage. The final closure then requires that
response. Confusing these stages creates a completion/status/receipt cycle.

## Source-plan verifier still required

`assert_current_source_plan_profile(uuid,uuid,uuid,jsonb)` must independently
prove full actual base sale/payment/return, inverse/neutral/effective history;
immutable causal ordinal/replay membership; Native account/amount/date-source
identity; all retained signed I and consumers; ordinal targets and exact
adjustments; current E/GL identity; and all relevant future joint-prefix credit
capacities. It must include upstream credit source dependencies from the same
snapshot. A persisted plan JSON/hash does not prove these facts. No current
POSTED-only funding query, latest-leaf-only historical collector, fake prior
credit/import batch or metadata boolean substitutes for this verifier.

The current implementation explicitly refuses when either source member proof,
full source-plan verifier, or coordinator provenance is missing. The mechanical
large-part fixture intentionally has no financial source authority: its huge
recognition exceeds its tiny synthetic source face and only exercises exact
storage splitting. It cannot pass the full assertion.

## Frozen executable checks and retained failures

Run:

```sh
node /workspace/scratch/9442228ed2dc/ow04-proposals/readers/materialization-proof.mjs
```

`PGLITE_MODULE` overrides the local dependency. `MATERIALIZED_EXPECTED.json` and
its receipt were frozen before executing the validator: SHA
`266b91424d6ce2581030f923af06306a618a59e66e6d767d2fd0dec387b172df`.
The original repaired result was38/38. Three additional consumption invariants
were frozen separately before their execution in
`MATERIALIZED_ADDITIONAL_EXPECTED.json` (SHA
`6e6a8f709307ed238d48ffb9bdc329b52a048b527308ff5758b3ec570a69f718`):
nonfinite lines, negative lines and wrong Native inverse link. Their first run
passed. One separate source-peer recost control was then frozen before execution
in `MATERIALIZED_RECOST_EXPECTED.json`; its first run passed after removing only
the unsupported allocation-cost0 requirement. The final result is42/42,
comprising mechanical-only positives and exact
expected refusals. There is no Native/Auth/source-authority PASS.

The harness loads actual proposed ledger/materialization DDL in a new in-memory
PGlite database and synthetic Native-shaped tables. Corruption controls disable
immutable triggers only in that isolated synthetic database; no app privilege,
Native admission function or granting authority is faked. The source/owning
authority callbacks are absent, and the full assertion explicitly refuses.
It also verifies the exact five new helper owner/volatility/definer/search-path
contracts, both new table owners/RLS, and negative EXEC/table privileges for all
six outsider roles in that synthetic database. This does not establish installed
Native role capabilities or real Auth behavior.

`MATERIALIZED_FIRST_FAILURE.json` and attempts01–06 are retained:

| Attempt | Actual first failure | Repair |
| --- | --- | --- |
|01|Synthetic harness missing a space before ADD PRIMARY KEY.|Fixed harness statement.|
|02|Reused isolated source tables already contained their primary keys.|Detected existing catalog keys before adding absent synthetic keys.|
|03|Synthetic parameter used as both domain numeric and text.|Applied one explicit numeric parameter type before text formatting.|
|04|Actual proposed PL/pgSQL `n` variable conflicted with row-number alias.|Qualified both derived-table alias references.|
|05|Attempt to delete a source member was stopped by a real FK before the intended reader counter.|Used a new finished unregistered Native-shaped return, preserving the existing protected member.|
|06|Large-part driver passed actual journal JSON through JS Number and rounded cents before hashing.|Computed actual journal-line hashes entirely in SQL.|

The frozen expected values were not relaxed. The last failure confirms the
importance of preserving large monetary values as exact strings/SQL numerics;
all actual validator money stays in SQL exact cents.

No active product files were edited. Nothing was installed or run on Native,
real Auth, hosted systems, providers, or actual financial data.
