# OW04 current reader capability proposal

Source review against product `b7fc541ca2b0221865ed7982155e844e1a9bed80`,
tree `f047ceb76b26f95f6ade10eb9bc53edb0f669ec8`. This directory is outside
the active checkout. No product install, Native execution, real Auth, account,
stock, journal, permission, or hosted action was performed.

`01_current_reader_capability.proposal.sql` contains a concrete role/ACL
dispatch pattern and actual-requested-invoice assignment. Its installer barrier
and `assert_current_materialized_profile` refusal are deliberate. The missing
validator needs the complete authoritative source/ledger integration; none of
the synthetic checks below establishes it.

## Current facts and assignment

For an active actual invoice, `E = P + U - I`.

| Field | Actual source and exact meaning |
| --- | --- |
| Gross | `sales_items.line_total`, scoped to actual requested `sales_headers.id`. |
| Returned | `sales_return_items.refund_amount` joined to actual requested invoice's `sales_returns.status='POSTED'`. |
| Net | `max(gross-returned,0)`; retain `erp.sale_net_total(uuid)` meaning. |
| P | Actual requested invoice's current `sales_payments.status='POSTED'`, sum of stored cents. Advance-backed Native payments are already included once. |
| U | Net all actual signed Native-credit APPLY/restore events whose exact `target_sale_id` is this active invoice, with actual journal/operation coverage. Not BB fake-import money and not an advance counted twice. |
| I | Net **all retained materialized signed recognition parts**, including later ADJUSTMENT/contras, assigned once from each immutable return family to its proved active current leaf. Never initial face, positive-only sum, remaining availability, current refund amount, latest plan only, or unposted components. |
| Open | Active invoice net minus E. Keep original inactive-document open `NULL` and its own Native payment/return fields. |

`cp7_note.revisions(root_sale_id,previous_sale_id,replacement_sale_id,revision)`
is an actual linear invoice graph. Resolve and validate it, including customer,
contiguity, no fork/cycle/missing header and exactly one active leaf. Do not
implement `E(original_id)=E(current_leaf_id)`: after correction that aliases
another invoice's current money onto an inactive historical original. Conversely,
grouping I only by immutable `cohorts.source_sale_id` loses recognition on the
replacement leaf. The proposed assignment keeps those immutable origin IDs and
maps only the current adjustment onto the proved active leaf.

Historic dated reconstruction is a separate collector. It includes all original,
inverse, neutral and effective journals across the root family, even when the
header/original journal is REVERSED. A current POSTED-header P query cannot be
used to reconstruct historical funding. Both `economic_date` and
`transaction_date` are actual stored journal facts, not header dates or the
resolver's present answer.

## Permission evidence and proposed boundary

Bootstrap line references below are in
`supabase/tests/fixtures/erp_enteng_cp45a_catalog_bootstrap.sql.gz`.

- Native `v_customer_receivables` is `security_invoker=true` at27819–27857,
  ownerpostgres27859, authenticated SELECT35379, service-role view grants35381+.
  The Native internal sales/customer RLS policies permit active app roles
  OWNER/ADMIN/STAFF; they do not require `sales.invoice.view` or
  `finance.ar.view`. Do not silently add either permission to that existing view.
- `run_v263d_case_claim_read_integrity_checks()`29633–29680 is SQL STABLE
  SECURITY DEFINER ownerpostgres, without an app-actor guard. It queries this
  view29675; authenticated/service EXEC is granted36539/36541. A single new
  auth-required scalar in the view would break this existing caller context.
- P11 `cp7_sales.access_now()` (`sales/read.sql`:11–19) separately requires
  invoice-view permission and returns whether financial amounts are allowed.
  Its header financial CASE is49–52. The new private core must execute only
  inside that branch; a false branch must remain successful.
- History access (`sales/customer-history.sql`:27–36) requires
  `sales.history.view` and optionally AR permission. Do not add invoice-view
  permission. Its `invoices(uuid)` is also used by `events`70, summary counts102,
  and workspace invoice metadata; don't put a new guarded core into all those
  nonfinancial paths unconditionally.
- `scripts/cp6_auditor_modes.py`:8–20,78–84 explicitly adds test-only ERP schema
  USAGE for ordinary/race SQL fixtures and omits it in HTTP/browser copies. No
  new authenticated ERP USAGE is proposed here. Catalog grants alone are not
  proof a production browser can enter this private schema.

The view keeps its existing raw P, joins and active WHERE under invoker RLS. It
adds only U-I through an INVOKER dispatcher. If the actual current SQL role
already has EXEC on the private core, it uses that capability. A Native postgres
definer engine therefore works with no app actor, because its actual SQL role
has private EXEC. This is not an `auth.uid() IS NULL`, GUC, role-argument,
`session_user`, or copied role-name escape.

Authenticated has no core EXEC. Its branch enters a narrowly owned
NOBYPASSRLS function which proves the Native view's active header/customer/item
join visible through actual policies before obtaining only the adjustment.
The role owns no source tables and receives no ERP DML/new ledger SELECT.
Private source-profile validation remains mandatory after this visibility gate.

Service-role existing privileged view reads receive narrow core EXEC. Existing
public/P11/history permissions stay in their owning facades. Verify default
PUBLIC EXEC revocation, no role membership escape, owner/volatility/config,
source RLS and view ACL preservation, exact restoration, and no new authenticated
schema grant. The entire future bundle must restore definitions and ACLs in
reverse dependency order, including the Native view and new ERP helper functions.

## Smallest complete reader/status hooks

All Native release files here are under `supabase/release/cp6-t3/`, except20m
which is a migration. New code must transform/capture the current installed
composed definition and preserve exact source bodies, metadata and restoration;
editing accepted CP6 release text is not the integration.

| Current source | Required hook and preserved meaning |
| --- | --- |
| `sales/read.sql`:33–52, `cp7_sales.header(erp.sales_headers,boolean)` | Financial-only E for paid/open; never unconditional core execution when financialfalse. |
| `sales/customer-history.sql`:40–55,100–120,172–179 | Financial projection E for invoice totals and active summary; keep original payment/return/cancellation event amounts and nonfinancial paths. |
| Native bootstrap `v_customer_receivables`:27819–27857 | paid=E, outstanding=max(net-E,0), legacy credit=max(E-net,0), same shape/invoker/ACL. Legacy credit column is not Native credit availability. |
| `20ap`, `initial_prepayment_targets_v1(uuid)`:1078–1094 | CUSTOMER open capacity net-E; signature is exactly one UUID. |
| `20ah`, `post_sales_return(uuid)`:310–315,414–431 | Retain overpayment refusal and all Native guards. Source-bound projected guard before write, actual signed posting/registration before final status, with valid NO_JOURNAL branch supported. |
| `20ap`, `post_sales_payment(uuid)`:5024–5031,5066–5070 | E-based current admission/status plus full temporal root admission, never current-only capacity. FG before first child lock4984. |
| `20ap`, `reverse_sales_payment(uuid,text)`:5227–5236 | Complete full signed source/family adjustment before E/status; preserve original posting facts/inverse lineage. |
| `20ac`, `reverse_sales_return(uuid,text)`:7554–7559 | Complete all affected family adjustments before current E/status. Prior return removal can change a later sibling's target. |
| Bootstrap `run_v253_financial_integrity_checks()`:20302–20319 | SALES_PAYMENT_OVERPAY uses E, so lawful retained P greater than net is not reported as corruption. Preserve all unrelated detector branches; do not claim this checker is called by close without proof. |
| Latest `_v268_financial_report_checks_pre_scope()`,20m:168–219, AR201–215 | Active current net-E plus signed opening AR must reconcile actual GL daily debit-credit. Keep global AR check and opening balances. |
| Latest `run_v268_financial_report_checks()`,20be:2067+,2676–2720 | Status and per-customer AR use same current E. Keep original payment fact/lineage detectors unchanged and account-reader wrapper composition. |
| `run_v263d_case_claim_read_integrity_checks()`:29673–29677 | Existing formulas remain valid after the view paid column becomes E. Preserve its Native definer caller capability. |
| Latest `get_owner_financial_snapshot_v2(date,date,date)`,20ba:1054+ | GL AR comes from account_daily_balances through book as-of, then CP7 report/note/account transforms. Do not patch superseded20aw owner snapshot. No extra fake revenue/cash event. |
| `sales/report.sql`, finance read/planning, period blockers | Actual stored signed journals on their economic/book axes. Add recognition/consumption/assignment detector; current scalar equality cannot prove dated GL/credit availability. Preserve preflight/V267/V268 critical blockers. |

Receivable reminder source delegates P11 header; it gets the same corrected
financial meaning. Direct payment and return documents and history events retain
their original stored amounts/status/date. No changes to their money fields are
needed to present E on invoices.

The Native inverse copies in note/return correction cannot remain raw cash:
`sales/correction.sql`:142–181, `return-correction.sql`:192–221 capture private
copies before their commands use them. Correct either their exact captured
composed bodies in the owning dependency order or explicitly block the new
feature from those flows. Chain reversal, payment correction/restatement,
return correction/replay and note replay must each carry incoming application,
all sibling/cohort dependencies and complete actual manifest. One generic
settlement context is not a guard bypass.

## Reproducible source counter scenarios

These expected values are contract/source projections, not deployed failures.

| Scenario | Required result | Incomplete reader result |
| --- | --- | --- |
| Sale1000, retained Native P1000, return200, retained I200 | E800, AR0, statusPAID; original payment still1000POSTED | Raw P produces AR-200/false V253/V268. |
| Same return corrected200→100; original recognition+200 and adjustment-100 | I100, E900, net900, AR0 | Initial-face I200 gives AR100; raw P gives AR-100. |
| Issue200, then refund200 or apply200 elsewhere | Source I remains200/E800; availability0 | Subtracting remaining credit makes source AR-200. Refund is not additional source payment. |
| Target invoice1000, own P600 plus incoming APPLY400 | Target E1000, AR0; signed restore-400 later returns E600/AR400 | Raw P ignores incoming U; counting advance-backed P as U doubles funding. |
| Note correction leaves original rootREVERSED and replacement leafactive | Leaf gets family I exactly once; old original keeps own Native fields/openNULL | Root-blind alias fabricates old invoice paid; source_sale-only grouping loses leaf I. |
| Register recognition plan/components before actual part journals | No current reader may count that planned I; closed-fact validator refuses unfinished materialization | Native guard passes using future recognition while GL has not posted. |
| Sale18, pay1000economic20, return200economic19 entered20 | At economic19 AR800/credit0, at20 AR0/credit200 (actual book facts separately) | Issuing current K200 entirely on return19 manufactures credit before funding. |
| Existing payment1000@18 inverse-1000@20; new return200@19, then attempted new800@18 | Full no-return temporal capacity refuses historical overfunding | CurrentP-only guard admits because currentP0/net800; fabricated family credit800@18 and1000@19 exceeds returnface. |

## Synthetic capability evidence

Run `node capability-proof.mjs`; `PGLITE_MODULE` overrides the local dependency.
`EXPECTED.json` was written before the first execution. First result was12/12
PASS and is preserved in `RESULT.json`; no first failure occurred. The driver
loads the exact extracted Native invoker-view definition and the exact proposed
visible/dispatcher/current-leaf functions. Its RLS/app actor and adjustment core
are deliberately synthetic. It proves ACL dispatch, NOBYPASS visibility gating,
no new app permission, private denial, no-actor caller separation, false-branch
short circuit and original view/ACL restoration mechanics only.

It does not prove installed Native RLS/grants, real Auth, the new materialized
ledger validator, a correction admission path, dated financial reconciliation,
race ordering, Native installation or restoration of a complete feature.
