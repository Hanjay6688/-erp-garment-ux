// Actual proposed table DDL, synthetic rows, isolated in-memory PGlite only.
// This proves structural constraints; it does NOT prove Native source facts,
// authority, lawful dates, an owning sealer/poster, or feature installation.
import {PGlite} from '/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';

const here=path.dirname(fileURLToPath(import.meta.url));
const file=path.join(here,'01_typed_context_and_preclaim.proposal.sql');
const source=fs.readFileSync(file,'utf8');
const actual=source.match(/create table cp7_credit\.return_native_scope\([\s\S]*?\n\);/g);
if(actual?.length!==1)throw Error('EXPECTED_ONE_ACTUAL_NATIVE_SCOPE_DDL');
const db=new PGlite();
const rows=[];
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const hex='1'.repeat(64);
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const prior=(state='PROVEN_ABSENT',floor=null)=>({
  contract_version:'ow04.prior-causal-book-proof.v1',scope:'PRIOR_CAUSAL_SALE_RETURN',
  state,causal_book_floor:floor,proof_sha256:hex,
});
const base=()=>({prior:prior(),manifest:{classification:'SYNTHETIC_SHAPE_ONLY_NO_FACTUAL_ATTESTATION'},
  effect:'NO_JOURNAL',book:null,recognition:false,choice:false});
const insert=async value=>db.query(`insert into cp7_credit.return_native_scope(
 backend_pid,transaction_id,actor,return_id,source_sale_id,customer_id,origin,
 source_lock_sha256,projection_sha256,prior_causal,prior_causal_manifest,journal_effect,
 planned_book_date,recognition_nonempty,explicit_choice)
 values(1,1,$1,$2,$3,$4,'ORDINARY',$5,$5,$6::jsonb,$7::jsonb,$8,$9::date,$10,$11)`,
 [id(1),id(2),id(3),id(4),hex,JSON.stringify(value.prior),JSON.stringify(value.manifest),
  value.effect,value.book,value.recognition,value.choice]);

async function test(name,value,accept){
  await db.exec('begin');
  let error=null;
  try{await insert(value);}catch(e){error={code:e.code,message:e.message};}
  await db.exec('rollback');
  const observed=error?'REJECT':'ACCEPT';
  const expected=accept?'ACCEPT':'REJECT';
  rows.push({id:name,expected,observed,...(error?{error}:{})});
  if(expected!==observed)throw Error('SHAPE_CONTROL_FAILED:'+name);
}

const receipt={classification:'ISOLATED_ACTUAL_CONTEXT_DDL_SYNTHETIC_ROWS_NOT_NATIVE',
 source_sha256:sha(source),extracted_DDL_sha256:sha(actual[0]),
 scope:'STRUCTURAL_PRIVATE_CONTEXT_ONLY_NOT_SOURCE_ATTESTATION',rows,
 Native_execution_proven:false,authority_proven:false,lawful_resolver_executed:false,
 actual_source_collector_executed:false,complete_feature_installation:false};
try{
  await db.exec('create schema cp7_credit');
  await db.exec(actual[0]);
  await test('PF01_ABSENT_PRIOR_NEW_NO_JOURNAL_SHAPE',base(),true);
  await test('PF02_ABSENT_PRIOR_NEW_HPP_JOURNAL_SHAPE',{
    ...base(),effect:'JOURNAL_EXPECTED',book:'2026-10-19'},true);
  await test('PF03_DATED_PRIOR_NEW_JOURNAL_SHAPE',{
    ...base(),prior:prior('DATED','2026-10-20'),effect:'JOURNAL_EXPECTED',book:'2026-10-20'},true);
  await test('PF04_DATED_PRIOR_NEW_NO_JOURNAL_SHAPE',{
    ...base(),prior:prior('DATED','2026-10-20')},true);
  await db.exec("set DateStyle='German,DMY'");
  await test('DATED_PRIOR_ISO_PROOF_WITH_OTHER_SESSION_DATESTYLE',{
    ...base(),prior:prior('DATED','2026-10-20')},true);
  await db.exec("set DateStyle='ISO,MDY'");
  await test('REJECT_NULL_PRIOR',{...base(),prior:null},false);
  await test('REJECT_MISSING_PRIOR_FIELDS',{...base(),prior:{}},false);
  const missing=prior();delete missing.scope;
  await test('REJECT_MISSING_SCOPE',{...base(),prior:missing},false);
  await test('REJECT_CALLER_EXCLUSION_KEY',{
    ...base(),prior:{...prior(),excluded_return_ids:[id(90)]}},false);
  await test('REJECT_WRONG_SCOPE',{...base(),prior:{...prior(),scope:'ALL_LEDGER_JOURNALS'}},false);
  await test('REJECT_COMPLETED_SOURCE_PROTOCOL',{
    ...base(),prior:{...prior(),contract_version:'ow04.actual-causal-book-info.v1'}},false);
  await test('REJECT_UNKNOWN_SOURCE_AS_READY',{...base(),prior:{...prior(),state:'UNKNOWN'}},false);
  await test('REJECT_DATED_WITH_NULL_FLOOR',{...base(),prior:prior('DATED',null)},false);
  await test('REJECT_ABSENT_WITH_FABRICATED_FLOOR',{
    ...base(),prior:prior('PROVEN_ABSENT','2026-10-19')},false);
  await test('REJECT_SHORT_PROOF_HASH',{...base(),prior:{...prior(),proof_sha256:'1'}},false);
  await test('REJECT_NULL_PROOF_HASH',{...base(),prior:{...prior(),proof_sha256:null}},false);
  await test('REJECT_MISSING_SERVER_MANIFEST',{...base(),manifest:null},false);
  await test('REJECT_SERVER_MANIFEST_ARRAY',{...base(),manifest:[]},false);
  await test('REJECT_DATED_INVALID_CALENDAR',{
    ...base(),prior:prior('DATED','2026-02-31')},false);
  await test('REJECT_JOURNAL_WITH_NULL_BOOK',{...base(),effect:'JOURNAL_EXPECTED'},false);
  await test('REJECT_NO_JOURNAL_WITH_NEW_BOOK',{...base(),book:'2026-10-19'},false);
  await test('REJECT_DATED_BOOK_BELOW_REAL_FLOOR',{
    ...base(),prior:prior('DATED','2026-10-20'),effect:'JOURNAL_EXPECTED',book:'2026-10-19'},false);
  await test('REJECT_ABSENCE_AS_RECOGNITION_ADMISSION',{...base(),recognition:true},false);
  await test('REJECT_ABSENCE_AS_EXPLICIT_CASH_OR_CREDIT_CHOICE',{...base(),choice:true},false);
  receipt.status='PASS';
}catch(error){receipt.status='FAIL';receipt.error=String(error);process.exitCode=1;}
finally{
  await db.close();
  fs.writeFileSync(path.join(here,'PRIOR_CAUSAL_SHAPE_RESULT.json'),JSON.stringify(receipt,null,2)+'\n');
  process.stdout.write(JSON.stringify({classification:receipt.classification,status:receipt.status,
    controls:rows.length,actual_DDL_sha256:receipt.extracted_DDL_sha256,
    Native_execution_proven:false,complete_feature_installation:false})+'\n');
}
