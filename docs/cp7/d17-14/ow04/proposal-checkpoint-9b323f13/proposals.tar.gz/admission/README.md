# OW04 typed RETURN admission and complete entry locks

The bounded typed-absence contract has been corrected after the root's
`CAUSAL_ABSENCE_COUNTER.json` and the independently pinned
`PRIOR_CAUSAL_EXPECTED.json`.01 now carries a typed prior causal proof instead
of a universal non-null date. It permits both a journal-free new return and
an HPP-only new journal with proved absent PRIOR causal SALE/RETURN history.
This is a private context contract, not an implemented factual sealer or poster.
`STATIC_RESULT_BEFORE_CAUSAL_ABSENCE_COUNTER.json` retains the earlier limited
result; no current whole-feature or installation clearance is claimed.
Explicit new-role/RLS-owner and Native-state adapter composition also remains
to be pinned before integration; do not infer postgres bypass rights.
The later recost counter withdraws any implication that prior causal
absence requires no unrelated financial journals or that the NEW return has
no journal: free SALE/no journal,
later recost, refund0/HPP-only RETURN journal is a valid candidate. Seal the
prior causal info at `native_return_enter` while the own return is DRAFT and
prove its existing ancestors. AH calls `post_return_journal` after marking the
return POSTED and freezing unit HPP but before the new journal exists; that
poster cannot call a completed-return collector expecting the journal already
to exist. It checks the sealed prior proof plus the exact Native projection.
The full actual journal-or-NO_JOURNAL fact is checked only at Native completion.
Prior absence is no arbitrary book-date permission: the new Native HPP-only
journal still uses its lawful resolver and no financial credit poster bypass.

Uninstalled proposal at `b7fc541ca2b0221865ed7982155e844e1a9bed80`. No active
repository edits or Native execution by this helper. SQL raises before DDL.
There is no public placeholder, financial stub, free paired-date poster, new
`require_internal` branch or client/GUC capability here. Root integrates only
the completed feature. `EXPECTED.json` records the independently locked design
and faults before peer exchange.

`01_typed_context_and_preclaim.proposal.sql` makes the private typed request/
scope and inner-request preclaim capability concrete. Financial source and
completion interfaces remain deliberately absent rather than return success.
`02_owning_wrapper.proposal.sql` supplies a private outer command and a fixed
RETURN execution bridge owned by the existing sales writer. It creates no
public facade and cannot install through its first-statement barrier. Its
source-sealing, completion and historical-receipt validators remain mandatory
missing interfaces, not passing stubs.
`03_native_admission_transform.py` derives seven exact source changes, checks
accepted predecessor/metadata supplied by the owning build, and produces raw
release-body anchor fingerprints. It performs no DB calls. Its static receipt
is not a capture of the installed current Native definitions.

## Owning wrapper and request order

Root's candidate public `erp_cp7_settle_sales_return_v1(payload,request,expected)`
uses the SALES browser recovery action `RETURN_SETTLEMENT`. It delegates to the
existing exact legacy `RETURN` command with the same UUID. It does not extend
the closed `cp7_sales.command` enum or change Native admission.

1. Validate authenticated current RETURN rights and, for REFUND, the accepted
   OWNER/ADMIN cash-out role plus `finance.cash.view`. Validate closed final wire:
   legacy draft fields plus `quote_sha256` and discriminated settlement choice.
   CREDIT has `mode,credit_account_id`; REFUND additionally requires explicit
   `cash_account_id,refund_physical_at,reference`. Cash time is independent of
   return physical time. No client K, journal, derived date pair, amount or map.
2. Lock the outer `(actor,request)` row. Compare complete raw payload, full
   expected version and quote SHA. Read current authority after the wait before
   returning a committed receipt. A receipt replay does no new Native work.
3. Mint the private `CLAIMED` scope, then call
   `cp7_sales.preclaim_credit_return(uuid,jsonb,text)` BEFORE FG. It validates the
   exact stripped legacy payload and reserves/locks the legacy request as its
   owner `cp7_sales_write`. It calls a narrow outer-pending verifier, which has
   no request DML grant. Only `cp7_credit_write` can execute this capability;
   grant that role no ERP or `cp7_sales.requests` DML. Scope/read permissions and
   object owner/ACL are explicit installer assertions.
4. Fresh outer requests refuse an already committed standalone legacy request
   with the UUID. They may not accept its cached response and assume the Native
   hooks ran. Once both requests are owned, take FG and the full ordered source/
   master locks, then period SHARE. Rebuild current quote and compare its FULL
   semantic source projection/account choice, not merely K. Recheck current
   authority after waits; seal the lock manifest and enter `LOCKED`.
5. Call `cp7_sales.execute_preclaimed_credit_return(uuid,jsonb,text)`, the fixed
   owner-bound RETURN bridge in02. Its security-definer owner is the existing
   `cp7_sales_write`; it validates the locked outer and still-pending inner
   before calling that owner's exact `command('RETURN',...)`. Grant the new
   writer neither general sales command/public facade EXEC nor request DML. The
   nested legacy command's request is already locked and pending, and creates
   its unchanged RETURN context. New credit scope does not admit Native writes.
6. Native hooks bind its newly generated draft RETURN ID once to the sealed
   semantic projection and inner pending request. Its random return-item and
   journal IDs were not falsely advertised as known to the client quote.
7. After Native completion, require the exact returned RETURN ID, complete
   context marker, projected-to-actual mapping proof, actual financial manifest
   SHA and both receipts. Check current authority/final cash/joint capacity and
   deferred closure, clear contexts, then persist the outer response atomically.

The final command payload always contains `settlement` and `quote_sha256`.
`settlement:null` is the all-return quote's genuinely empty signed target;
nonempty K0 still has the explicit CREDIT choice.02 checks the exact legacy
return parser, the full64-hex quote digest and the closed CREDIT/REFUND shape.
Actual liability/cash eligibility, signed targets and dated capacity are not
inferred from those structural checks. Quote readiness must prove a complete
typed prior proof even for a journal-free physical return. DATED preserves the
actual applicable SALE/RETURN ancestor floor, including HPP-only journals;
PROVEN_ABSENT has a null floor only on complete protected proof. A new
NO_JOURNAL member has a null planned book date even when its prior proof is
DATED. An HPP-only new journal may coexist with PROVEN_ABSENT prior history;
its planned date is the exact Native lawful resolver result under period SHARE.
No duplicate caller date or new loose floor is introduced.

The deadlock motivating step3 is concrete: legacy B owns inner request then
waits FG; outer A owns FG then waits that same inner request. Acquiring both
request rows first removes this inversion. Duplicate UUID/different payload
must refuse, including collisions with a standalone legacy request. No generic
request DML is granted to postgres executors or unrelated writers to solve it.

The complete R4-05 Native context manifest must be captured and verified with
`cp7_internal_guard_bundle.unpatched/contexts`. `derive_no_ambient_context`
generates a rejecting helper over exactly that list. Preclaim does not inspect
only four convenient sales contexts. Native entry separately permits only its
exact existing RETURN context or a separately bound correction admission;
unrelated current contexts must not win admission by precedence.

## Exact Native hooks

| Actual signature and accepted source | Hook position and retained behavior |
| --- | --- |
| `erp.post_sales_return(uuid)`,20ah205–438 | `native_return_enter` after existing FG236, before return/header/stock locks; guard callback before unchanged paid refusal313; existing ONE journal call415 routed through the ledger's bound RETURN poster; complete after the journal-or-no-journal branch417 and before final header status429; leave after HPP guards |
| `erp.post_sales_payment(uuid)`,20ap4961–5071 | FG + source entry after original require_internal4983, before payment FOR UPDATE4984; canonical E before original remaining-AR guards5027; source completion after actual POSTED/facts5066, before canonical E/header status; no payment fact/journal rewriting |
| `erp.reverse_sales_payment(uuid,text)`,20ap5167–5240 | FG + source entry after original require_owner_admin5186, before payment row5188; source completion after actual REVERSED5225 and before current E/remaining-AR/header decision; retain exact original/inverse payment facts |
| `erp.manage_initial_prepayment_v1(jsonb)`,latest20ba638–743 | FG/current owner recheck immediately after original require_owner_admin646, before payment662/header671/advance674; preserve BA dated floor734–739 |
| `erp.save_initial_import_action_v1(text,jsonb,uuid)`,latest20bb6202–6372 | PREPAYMENT FG before idempotency6225 and batch6259, and fresh access after idempotency wait before cached replay; retain Native WIP pocket lock and existing FG branches |
| `erp.reverse_sales_return(uuid,text)`,20ac | Source entry after existing FG, before Native return/header locks; actual source completion before net/E/header decision7554; actual E after old raw query7555 |
| `erp.reverse_sale(uuid,text)`,20ac | Source entry after existing FG7367, before header7370/early replay; retain active-payment/return guards; source completion after Native inverse/HPP/audit |

Native source callbacks must also recheck current owning authority on early
already-reversed returns; entry occurs before that early return. The actual
completion routine owns final authority and closed-scope validation. Early
replay must clean/check an entry scope without inventing a new event. This
detail must be incorporated when implementing those missing source adapters.
The derived Native text explicitly repeats its own original guard after FG,
source entry and source completion: `require_internal` for post RETURN/payment, and
`require_owner_admin` for inverse entries. No new context branch substitutes
for those guards. Typed source callbacks still prove the complete owning actor,
action and source authority after their waits and at completion.

The PREPAYMENT hooks conservatively take the existing FG lock for that whole
continuation, including non-customer branches. An unlocked party probe alone is
not a proof: an absent/uncommitted advance can become CUSTOMER while the outer
command waits for its batch, causing a late FG acquisition below the held batch.
If narrowing is later needed, use a typed pre-batch classification certificate
and refuse any classification change; never let the inner helper acquire FG
late. This proposal changes serialization, not a settlement/authority policy.

All owning source functions, CP7 return/payment/note/chain correction wrappers,
and admitted prepayment callers must obey the same real locks. FG does not
magically serialize an unmodified caller that acquired source rows first.
Required source order is FG → deterministic full source/header/cohort/master
set → period SHARE → Native CASH. Do not prelock CASH. Reentry after period
must verify already-held source locks and fail on a new source set, not acquire
an earlier-order lock while holding period or CASH.

## Guard and completion contracts

`native_return_enter(return_id)` admits every actual newly posted return,
including ordinary empty ones. It binds actual actor/customer/source sale,
draft fields/items, explicit settlement mode/accounts if present, source lock
manifest and typed prior causal proof. Under an outer scope it validates the
inner legacy pending row and context, then binds that actual ID exactly once.
For ordinary/direct Native calls it derives an ordinary server admission from
the actual draft and freshly authorized owning actor. At this point its own
actual return row must still be DRAFT. No authority is inferred
from the mere existence of a Native/credit/GUC context. Bare calls with no
current attributable actor require an explicitly approved owning Native route;
the prototype supplies no privileged-session waiver. Corrections require their
exact persisted lineage context, not ordinary new-family registration.

The private scope's `prior_causal` is the same closed summary sealed into
`return_projection.prior_causal` in the reviewed quote:

```
{contract_version:'ow04.prior-causal-book-proof.v1',
 scope:'PRIOR_CAUSAL_SALE_RETURN',state:'DATED'|'PROVEN_ABSENT',
 causal_book_floor:date|null,proof_sha256}
```

`prior_causal_manifest` retains the complete protected server proof separately;
its source codec, full proof digest, owning actual draft/items, current actor/
request/context, full source lock manifest and exact semantic projection must
all be checked by the missing owning adapter before it stores the scope. The
table's shape checks are not a source attestation. Missing or unsupported proof
refuses; no caller-provided exclusion, date, scope row or 64-hex string grants
admission. Only the own newly assigned draft/projection may be omitted from
PRIOR; every bound existing SALE/RETURN ancestor remains in it. Completed
`causal_book_info_v1`/`return_fact_v1` cannot implement that entry seal because
their preconditions require an already completed return.

The scope also retains `journal_effect` and the existing server-sealed
`planned_book_date`. JOURNAL_EXPECTED requires the Native lawful date (and the
real prior floor if DATED); NO_JOURNAL has no new book date. PROVEN_ABSENT is
qualified only with the complete actual zero gross/net/return/AR/P/U/I/E profile,
empty signed recognition target and no explicit settlement/cash refund; neither
current K0 nor AR0 proves that qualification. Its HPP-only journal uses the
ordinary lawful Native resolver, with exact Native cumulative HPP lines and all
original source/account/cent/period/current-authority guards. This grants no
COMPONENT, credit recognition, refund or arbitrary date poster capability.

The PF04 reverse recost case remains valid: old allocation/SALE movement HPP10,
actual dated SALE HPP journal, later current HPP0, new return item/movement HPP0
and no new journal. Its prior state is still DATED. Do not require the original
allocation HPP0 as a condition of a legitimate new NO_JOURNAL member.

`native_return_guard(return_id,R,net_after,rawP)` reads the complete locked
canonical before state, E=P+U−I, AR=N−E. Preserve advance-funded Native payments.
Reject corrupt negative/crossed before states, non-cent R and any mismatch
between Native's supplied net-after and the UNCLAMPED N−R. Source collector must
check gross-before-returns overflow and every family prefix over the joint grid.

For an ORDINARY call without explicit choice, if rawP>net_after, return rawP to
the unchanged Native exception branch. This preserves the old paid-return
negative control and its exact error text. If that old numerical guard passes
but the signed recognition target is nonempty (including current K0), refuse
for explicit choice before anything can commit. A truly empty target needs no
choice/account and continues through the same physical-family/floor path.

Only a validated reviewed admission may use canonical after E in the Native
guard. It must derive K from actual R and source state, enforce0<=K<=R and
0<=afterE<=net_after, and prove the exact signed target plan/assigned server
manifest. It does not zero paid, clamp corruption or skip the guard.

`native_return_complete(return_id,R,net_after)` runs after actual Native RETURN
status and its actual journal-or-no-journal decision. It verifies native R,
actual source accounts, real journal lines/dates/IDs and exact semantic
projection→actual mapping. The actual manifest digest is DISTINCT from the
quote/projection digest; source hashing does not pretend generated IDs were
known before posting. Register the family/member, including empty families,
then post complete exact recognition and optional explicit refund under the
owning compound scope. Return canonical actual E for Native's final status.
The source collector's full actual family and the ledger plan/journals must
reconcile before and after each pending multi-part post. First validate actual
raw completed Native journal-or-no-J facts; register the owned family/member
with those facts; then verify the completed causal/member proofs. Do not
require an already registered member before creating its factual registration.
For PROVEN_ABSENT prior + a new HPP journal, completed actual source becomes
DATED from that actual new pair. It must not be compared as if the prior state
had to remain ABSENT. Generated journal IDs bind after posting; their actual
manifest digest remains distinct from the semantic projection digest.

`native_source_enter/complete(action,id)` covers payment, payment inverse,
return inverse and sale inverse. It locks/rechecks all affected incoming credit
sources/targets, actual correction families and consumers. Source mutation may
not create historical gross overfunding or shift a family NET prefix positive.
An initially empty family first exposing credit requires explicit current
review/account choice; do not silently attribute the funding delta to it. Check
consumer capacity at every later joint cutoff. Named atomic correction may
include dependent undo only with exact bound lineage. Unsupported choice or
projection mapping aborts the whole Native transaction.

Canonical E changes here are only the Native guards/status portion. They do not
complete AR/report/history/reminder/integrity detector/prepayment-target source
integration. Preserve `sale_net_total` as gross-minus-returns and route every
reader/detector in SETTLEMENT_SOURCE_MAP through the shared actual source.
`current_effective_paid` must read only complete ACTUAL materialization:
P includes advance-funded payments once, U is actual incoming consumption and
I sums every retained signed component part with its actual journal. It may not
count a registered unposted plan to make an intermediate Native guard pass.
The owning source guard's sealed hypothetical profile is separate. Source
completion must finish all signed materialization before the final current E
and status calls. An incomplete profile refuses rather than filtering missing
parts away. The reader peer's proposed private actual core returns U-I and its
`assert_current_materialized_profile` deliberately refuses pending integration.

The source peer's `ow04_source_proposal.locked_source_family(uuid)` and
`return_causal_book_floor(uuid)` collect/lock actual base facts only, before
period SHARE or CASH. `BASE_COLLECTED` is not complete credit authority; an
existing registry still requires the owning immutable-proof verifier. The
adapters must normalize that complete source together with actual credit and
consumption facts, compare the entire quote, and seal the existing lock set.
After period, any newly discovered earlier-order source makes the transaction
abort; the volatile collector is not a post-CASH locking shortcut or a STABLE
current-reader implementation.

## Actual journal-free physical returns

CP7 `sales/returns.sql32` allows refund_amount0. Native table constraints permit
refund>=0 and HPP>=0.20ah317–321 adds no revenue/AR pair when refund0, and414–417
posts only if at least two lines exist. A positive-qty zero-HPP/zero-refund return
can legitimately have no journal. Register its family with a typed NO_JOURNAL
fact over actual POSTED document/items/FG movements, Native journal-absence and
typed prior causal proof. Never manufacture a zero journal or fabricated book
date. Absence concerns prior causal SALE/RETURN journals; real OPENING and HPP
source/sync journals still belong to current state/projection and are retained.
They neither create a fake SALE floor nor forbid a lawful HPP-only new return.
The finalized ledger prototype's family-member NOT NULL journal column requires
the separately reviewed representation change; it cannot be installed as-is.

## Composition and evidence limits

Compose Native canonical guards/source dependencies before deriving BOTH
`cp7_note` and `cp7_sales_return_correction` inverse families, or compose exact
same final source into those copies and their expected-definition verifiers.
Note replay must persist exact return-family mapping and retain original
settlement meaning; its old return-before-payment replay cannot mint fresh
refund cash. Private source-bound inverse date contracts remain required.
This proposal does NOT silently refresh10 private source hashes: all six
`cp7_note` copies (reverse_fg_movement, _cp3_r4_reverse_journal_internal,
reverse_journal, reverse_sale, reverse_sales_return, reverse_sales_payment)
and all four `cp7_sales_return_correction` copies (the same first three plus
reverse_sales_return) need their exact final composed bodies and verifier
expectations. They must retain owning require_context and actual inverse
source/date semantics, including the new source-entry/current-E hooks where
applicable. Copying a public generic-reversal refusal alone does not implement
the private bound owning inverse. Until those adapters and exact expected
definitions exist, integrated correction admission remains blocked.

02's absent source interfaces have closed responsibilities:

- `seal_return_settlement(uuid)` locks complete source/masters, then period,
  compares the full fresh quote/projection/current choice and authority, and
  updates only its own CLAIMED scope to LOCKED.
- `assert_sealed_return_source(uuid)` proves those same already-owned locks and
  fresh factual bindings without discovering a new source or adding a lock.
- `finish_return_settlement(uuid,jsonb)` verifies the actual Native return and
  exact completed inner receipt, source-to-actual mapping, family/parts/refund,
  current authority/capacity and financial closure; it leaves a complete outer
  marker and removes its temporary financial scopes.
- `assert_completed_return_receipt(uuid,jsonb,text,jsonb)` validates either the
  own pending COMPLETE marker or the immutable committed outer+inner receipts.
  Lost-reply lookup does not create another Native event or require an in-memory
  quote, and it still rechecks current owning authority after its request wait.

No missing interface is replaced by a void-success routine. A public facade is
added only by the completed owning installer, with exact owners/ACLs and all
underlying source/financial/admission functions present in the same transaction.

The Native RETURN journal callee replacement is the SAME one proposed by the
ledger module; apply it once, not both transforms blindly. Trusted installed
capture/metadata and composed target hashes must match. The source module's
`Approved` manifest must come from the owning accepted build, not a digest made
from the candidate itself. Known installed post/reverse payment hashes can be
found in20au/20av inventory; raw release file digests are a different codec.

No scalar compilation, source transform or typed DDL is Native money evidence.
Whole-feature cases still require actual row/advisory waits, revoke after every
request/source/master/period/CASH wait, both request replay paths, same-UUID
collision interleavings, zero-journal family, all dated/ordinal goldens, advance
funding, real correction/undo lineage, no generic reversal bypass and injected
last-journal rollback of stock/HPP/credit/cash/both receipts/private scopes.

`04_static_proof.py REPO` checks the seven release-body transforms, duplicate
anchor refusal, eight SYNTHETIC metadata-change refusals, four SYNTHETIC context
manifest refusals and private-wrapper textual order. It runs no SQL, auth,
cash, Native, browser or provider flow. `STATIC_RESULT.json` retains the earlier
limited source checks; `STATIC_RESULT_BEFORE_CAUSAL_ABSENCE_COUNTER.json` keeps
that earlier evidence separately. `PRIOR_CAUSAL_STATIC_RESULT.json` records the
current source checks and hashes, including the bounded typed-prior shape.
Whole-feature installation and private inverse composition remain blocked.
`FIRST_STATIC_FAILURE` retains the original terminal-anchor mistake.

`node 05_prior_causal_shape_check.mjs` extracts only the actual proposed private
scope table DDL into isolated in-memory PGlite and inserts SYNTHETIC shape
controls. The four prior/projected combinations, malformed/missing proof,
closed scope, real-floor preservation, no-J/date and explicit/nonempty credit
refusals are structural checks. `PRIOR_CAUSAL_SHAPE_RESULT.json` is not evidence
that any physical history, digest, account, lawful resolver or authority was
proved. No source, sealer, Native hook or financial poster is stubbed to make
those controls pass. `PRIOR_CAUSAL_RESULT.json` pins both limited receipts and
the unchanged Native transform; no new whole-feature acceptance is claimed.
