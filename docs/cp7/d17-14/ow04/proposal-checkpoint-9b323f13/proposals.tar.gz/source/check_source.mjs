import {PGlite} from '/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
import fs from 'node:fs';import crypto from 'node:crypto';
const dir='/workspace/scratch/9442228ed2dc/ow04-proposals/source';
const file=process.argv[2]||'source.sql';const out=process.argv[3]||'RESULT.json';
const source=fs.readFileSync(`${dir}/${file}`,'utf8');
const db=new PGlite();const results=[];
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const q=async(s,p=[])=>db.query(s,p);
const ex=async s=>db.exec(s);
const receipt={classification:'ISOLATED_ACTUAL_COLLECTOR_SQL_SYNTHETIC_ROWS_NOT_NATIVE',source_file:file,source_sha256:crypto.createHash('sha256').update(source).digest('hex'),results};
try{
 await ex("set TimeZone='UTC'");
 await ex(fs.readFileSync(`${dir}/ISOLATED_TABLES.sql`,'utf8'));
 await ex(source.replace(/do \$not_an_installer\$[\s\S]*?end \$not_an_installer\$;/,''));
 if(file!=='INITIAL_SOURCE.sql'){
  const member=fs.readFileSync(`${dir}/member-proof.sql`,'utf8');receipt.member_sha256=crypto.createHash('sha256').update(member).digest('hex');
  await ex(member.replace(/do \$not_an_installer\$[\s\S]*?end \$not_an_installer\$;/,''));
  const absence=fs.readFileSync(`${dir}/absence-proof.sql`,'utf8');receipt.absence_sha256=crypto.createHash('sha256').update(absence).digest('hex');
  await ex(absence.replace(/do \$not_an_installer\$[\s\S]*?end \$not_an_installer\$;/,''));
 }
 const account=async(n,name,type,normal)=>q('insert into erp.chart_accounts(id,account_code,account_name,account_type,report_group,normal_balance)values($1,$2,$2,$3,$2,$4)',[id(n),name,type,normal]);
 await account(1,'AR','ASSET','DEBIT');await account(2,'REVENUE','REVENUE','CREDIT');await account(3,'COGS','EXPENSE','DEBIT');await account(4,'FG','ASSET','DEBIT');await account(5,'CASH','ASSET','DEBIT');await account(6,'ADVANCE','LIABILITY','CREDIT');
 await q("insert into erp.accounting_account_mappings values('AR_CUSTOMER',$1,null)",[id(1)]);
 await q("insert into erp.customers(id,customer_code,customer_name)values($1,'TEST','Synthetic')",[id(10)]);
 const header=async(n,status='POSTED')=>q("insert into erp.sales_headers(id,sale_number,customer_id,sale_date,status)values($1,$2,$3,'2026-10-18 01:00Z',$4)",[id(n),`S${n}`,id(10),status]);
 await header(100);await q('insert into erp.sales_items(id,sale_id,product_id,qty_pcs,unit_price_snapshot)values($1,$2,$3,5,200)',[id(101),id(100),id(11)]);
 const journal=async(n,type,src,e='2026-10-18',b=e,status='POSTED',reversal=null)=>q("insert into erp.journal_entries(id,journal_number,transaction_date,economic_date,posting_at,description,source_type,source_id,status,reversal_of_id)values($1,$2,$3,$4,$3::date::timestamptz,'Synthetic only',$5,$6,$7,$8)",[id(n),`J${n}`,b,e,type,id(src),status,reversal===null?null:id(reversal)]);
 const line=async(n,j,a,debit,credit,product=null)=>q('insert into erp.journal_lines(id,journal_entry_id,account_id,debit,credit,customer_id,product_id)values($1,$2,$3,$4,$5,$6,$7)',[id(n),id(j),id(a),debit,credit,id(10),product===null?null:id(product)]);
 await journal(200,'SALE',100);await line(201,200,1,'1000','0');await line(202,200,2,'0','1000');await line(203,200,3,'50','0',11);await line(204,200,4,'0','50',11);
 const read=async()=> (await q('select ow04_source_proposal.locked_source_family($1) v',[id(100)])).rows[0].v;
 const test=async(name,fn)=>{await ex('begin');try{const v=await fn();results.push({id:name,observed:v});await ex('rollback');}catch(e){await ex('rollback');results.push({id:name,error:e.message,detail:e.detail,where:e.where});}};
 await test('BASE_SALE',read);
 await test('REVERSED_SALE_WITHOUT_INVERSE',async()=>{await q("update erp.sales_headers set status='REVERSED'where id=$1",[id(100)]);await q("update erp.journal_entries set status='REVERSED'where id=$1",[id(200)]);return read();});
 await test('EXTRA_AR_LINE',async()=>{await line(205,200,1,'100','0');await line(206,200,2,'0','100');return read();});
 await test('WRONG_ORIGINAL_DATE',async()=>{await q("update erp.journal_entries set economic_date='2026-10-19',transaction_date='2026-10-19' where id=$1",[id(200)]);return read();});
 // Root/member presence attack uses deliberately malformed synthetic registry.
 await test('WRONG_ROOT_MEMBER',async()=>{
  await ex('create schema cp7_credit;create table cp7_credit.return_families(id uuid,family_root_sale_id uuid,family_ordinal bigint);create table cp7_credit.return_family_members(family_id uuid,return_id uuid);');
  await q("insert into erp.sales_returns(id,return_number,sale_id,customer_id,physical_at,status)values($1,'R',$2,$3,'2026-10-19 01:00Z','POSTED')",[id(300),id(100),id(10)]);
  await q('insert into erp.sales_return_items(id,return_id,product_id,location_id,qty_pcs,refund_amount,sale_stock_allocation_id)values($1,$2,$3,$4,1,200,$5)',[id(301),id(300),id(11),id(12),id(13)]);
  await journal(400,'SALES_RETURN',300,'2026-10-19');await line(401,400,2,'200','0');await line(402,400,1,'0','200');
  await q('insert into cp7_credit.return_families values($1,$2,1)',[id(900),id(999)]);await q('insert into cp7_credit.return_family_members values($1,$2)',[id(900),id(300)]);return read();
 });
 if(file!=='INITIAL_SOURCE.sql'){
 const mkReturn=async({r=300,ri=301,amount='200',hpp='10',withJournal=true,sale=100,alloc=130,lot=14,book='2026-10-19',status='POSTED'}={})=>{
  await q('insert into erp.sale_stock_allocations(id,sale_item_id,lot_id,location_id,qty_pcs,unit_hpp_snapshot)values($1,$2,$3,$4,5,$5)on conflict do nothing',[id(alloc),id(sale+1),id(lot),id(12),hpp]);
  await q("insert into erp.sales_returns(id,return_number,sale_id,customer_id,physical_at,status)values($1,$2,$3,$4,'2026-10-19 01:00Z',$5)",[id(r),`R${r}`,id(sale),id(10),status]);
  await q('insert into erp.sales_return_items(id,return_id,product_id,lot_id,location_id,qty_pcs,unit_hpp_snapshot,refund_amount,sale_stock_allocation_id)values($1,$2,$3,$4,$5,1,$6,$7,$8)',[id(ri),id(r),id(11),id(lot),id(12),hpp,amount,id(alloc)]);
  await q("insert into erp.fg_stock_movements(id,product_id,lot_id,location_id,movement_type,qty_signed,unit_hpp_snapshot,customer_id,source_type,source_id,physical_at)values($1,$2,$3,$4,'SALE_RETURN',1,$5,$6,'SALES_RETURN_ITEM',$7,'2026-10-19 01:00Z')",[id(ri+1),id(11),id(lot),id(12),hpp,id(10),id(ri)]);
  if(withJournal){await journal(r+100,'SALES_RETURN',r,'2026-10-19',book,status==='REVERSED'?'REVERSED':'POSTED');if(amount!=='0'){await line(r+101,r+100,2,amount,'0');await line(r+102,r+100,1,'0',amount);}else{await line(r+101,r+100,4,'10','0',11);await line(r+102,r+100,3,'0','10',11);}}
  return id(r);
 };
 const mkPayment=async({p=500,amount='500',advance=false,status='POSTED'}={})=>{
  if(!advance)await q("insert into erp.cash_accounts(id,cash_account_code,cash_account_name,coa_account_id,account_kind)values($1,'TEST','Synthetic',$2,'BANK')on conflict do nothing",[id(50),id(5)]);
  await q("insert into erp.sales_payments(id,sale_id,payment_number,payment_date,amount,cash_account_id,payment_method,status)values($1,$2,$3,'2026-10-20 01:00Z',$4,$5,$6,$7)",[id(p),id(100),`P${p}`,amount,advance?null:id(50),advance?'OPENING_ADVANCE':'TRANSFER',status]);
  if(status==='DRAFT')return;
  await journal(p+100,'SALES_PAYMENT',p,'2026-10-20','2026-10-20',status==='REVERSED'?'REVERSED':'POSTED');await line(p+101,p+100,advance?6:5,amount,'0');await line(p+102,p+100,1,'0',amount);
  await q(`insert into erp.sales_payment_posting_facts(payment_id,sale_id,customer_id,payment_number,payment_date,amount,cash_account_id,original_journal_entry_id,journal_economic_date,journal_transaction_date,journal_posting_at,payment_snapshot,lineage_sha256)
   select p.id,p.sale_id,$2,p.payment_number,p.payment_date,p.amount,p.cash_account_id,j.id,j.economic_date,j.transaction_date,j.posting_at,to_jsonb(p)-'status',
    ow04_source_proposal.native_sha(jsonb_build_array(p.id,p.sale_id,$2::uuid,p.payment_number,p.payment_date,p.amount,p.cash_account_id,j.id,j.economic_date,j.transaction_date,j.posting_at,p.replaces_payment_id,null,to_jsonb(p)-'status'))
   from erp.sales_payments p join erp.journal_entries j on j.source_type='SALES_PAYMENT'and j.source_id=p.id where p.id=$1`,[id(p),id(10)]);
  if(advance){await q("insert into erp.initial_import_prepayments(id,batch_id,source_row_id,party_type,party_id,customer_id,coa_account_id,document_number,document_date,cutover_date,original_amount,settled_before_cutover,amount)values($1,$2,$3,'CUSTOMER',$4,$4,$5,'A','2026-10-17','2026-10-17',1000,0,1000)",[id(60),id(61),id(62),id(10),id(6)]);await q("insert into erp.initial_import_prepayment_payments(payment_id,advance_id,sales_payment_id,payment_snapshot)select id,$2,id,to_jsonb(p)-'status'from erp.sales_payments p where id=$1",[id(p),id(60)]);}
 };
 const inverse=async(orig,newid,e='2026-10-21',b=e)=>{
  await q("update erp.journal_entries set status='REVERSED'where id=$1",[id(orig)]);await journal(newid,'JOURNAL_REVERSAL',orig,e,b,'POSTED',orig);
  await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,vendor_id,contractor_id,po_id,product_id)select $2,account_id,credit,debit,customer_id,vendor_id,contractor_id,po_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(orig),id(newid)]);
 };
 const register=async({r=300,fam=800,ordinal='1',kind='ORIGINAL',pred=null,lineage=null,itemLineage={},newFamily=true}={})=>{
  await ex('create schema if not exists cp7_credit');
  if(!(await q("select to_regclass('cp7_credit.return_families')v")).rows[0].v)await ex(fs.readFileSync(`${dir}/ISOLATED_REGISTRY.sql`,'utf8').replace('create schema cp7_credit;',''));
  const fact=(await q('select ow04_source_proposal.return_fact_v1($1)v',[id(r)])).rows[0].v;
  if(newFamily){const assignment={contract_version:'ow04.return-family-assignment.v1',family_id:id(fam),family_root_sale_id:id(100),family_ordinal:ordinal,first_return_id:id(r),previous_family_id:ordinal==='1'?null:id(fam-1),actor:id(90),request_id:id(91)};
   await q("insert into cp7_credit.return_families(id,family_root_sale_id,family_ordinal,first_return_id,assignment_kind,assignment_proof,source_sha256,actor,request_id)values($1,$2,$3,$4,'NEW_POST',$5,ow04_source_proposal.sha($5::jsonb),$6,$7)",[id(fam),id(100),ordinal,id(r),JSON.stringify(assignment),id(90),id(91)]);}
  const snap={contract_version:'ow04.actual-return-family-member.v1',family_id:id(fam),family_root_sale_id:id(100),return_id:id(r),sale_id:fact.sale_id,member_kind:kind,predecessor_return_id:pred===null?null:id(pred),native_lineage_id:lineage===null?null:id(lineage),return_item_lineage:itemLineage,financial_state:fact.financial_state,source_journal_id:fact.source_journal_id,financial_source_sha256:fact.financial_source_sha256,no_journal_proof:fact.no_journal_proof};
  await q('insert into cp7_credit.return_family_members(family_id,return_id,member_kind,source_journal_id,source_sha256,actual_lineage_snapshot,actor,request_id,financial_state,financial_source_proof)values($1,$2,$3,$4,ow04_source_proposal.sha($5::jsonb),$5,$6,$7,$8,$9)',[id(fam),id(r),kind,fact.source_journal_id,JSON.stringify(snap),id(90),id(91),fact.financial_state,JSON.stringify(fact.no_journal_proof)]);
  return snap;
 };
 await test('LEGAL_RETURN_PAYMENT500_MISSING_REGISTRY',async()=>{await mkReturn();await mkPayment();return read();});
 await test('ADVANCE_NATIVE_PAYMENT_ONCE',async()=>{await mkPayment({advance:true});return read();});
 await test('STABLE_REGISTERED_ORIGINAL',async()=>{await mkReturn();await register();return {source:await read(),proof:(await q('select ow04_source_proposal.verify_return_member_v1($1)v',[id(300)])).rows[0].v};});
 await test('MEMBER_WRONG_FINANCIAL_HASH',async()=>{await mkReturn();await register();await q("update cp7_credit.return_family_members set actual_lineage_snapshot=jsonb_set(actual_lineage_snapshot,'{financial_source_sha256}',to_jsonb(repeat('f',64)))where return_id=$1",[id(300)]);return read();});
 await test('MEMBER_WRONG_JOURNAL',async()=>{await mkReturn();await register();await q('update cp7_credit.return_family_members set source_journal_id=$2 where return_id=$1',[id(300),id(200)]);return read();});
 await test('MEMBER_WRONG_ASSIGNMENT',async()=>{await mkReturn();await register();await q("update cp7_credit.return_families set assignment_proof=jsonb_set(assignment_proof,'{family_ordinal}','\"2\"')");return read();});
 await test('UNQUALIFIED_HISTORICAL_BACKFILL',async()=>{await mkReturn();await register();await q("update cp7_credit.return_families set assignment_kind='QUALIFIED_BACKFILL'");return read();});
 await test('NO_JOURNAL_ZERO_HISTORICAL_PROOF',async()=>{await mkReturn({amount:'0',hpp:'0',withJournal:false});await register();const v=await read();return {source:v,floor:(await q('select ow04_source_proposal.return_causal_book_floor($1)v',[id(300)])).rows[0].v};});
 await test('NO_JOURNAL_MISSING_STOCK_INVERSE',async()=>{await mkReturn({amount:'0',hpp:'0',withJournal:false,status:'REVERSED'});return read();});
 await test('NO_JOURNAL_POSTED_ALREADY_INVERTED',async()=>{await mkReturn({amount:'0',hpp:'0',withJournal:false});await q("insert into erp.fg_stock_movements(id,product_id,lot_id,location_id,movement_type,qty_signed,unit_hpp_snapshot,customer_id,source_type,source_id,physical_at,reversal_of_id)select $2,product_id,lot_id,location_id,'REVERSAL',-qty_signed,unit_hpp_snapshot,customer_id,'FG_MOVEMENT_REVERSAL',id,'2026-10-20',id from erp.fg_stock_movements where id=$1",[id(302),id(303)]);return read();});
 await test('ZERO_RETURN_HPP_ONLY_REAL_JOURNAL',async()=>{await mkReturn({amount:'0',hpp:'10'});return read();});
 await test('HPP_CURRENT_STATE_HASH_SEPARATE',async()=>{await mkReturn();await mkPayment();const a=await read();await q("update erp.sales_return_items set unit_hpp_snapshot=11 where id=$1",[id(301)]);await q("update erp.customers set customer_name='Other current label'where id=$1",[id(10)]);const b=await read();return {events_same:JSON.stringify(a.events)===JSON.stringify(b.events),state_changed:a.state_sha256!==b.state_sha256};});
 await test('PAYMENT_INVERSE_AND_DRAFT_NULL',async()=>{await mkPayment({status:'REVERSED'});await inverse(600,610);await q(`insert into erp.sales_payment_reversal_facts(payment_id,original_journal_entry_id,reversal_journal_entry_id,reversal_economic_date,reversal_transaction_date,reversal_posting_at,lineage_sha256)
   select $1,$2,j.id,j.economic_date,j.transaction_date,j.posting_at,ow04_source_proposal.native_sha(jsonb_build_array($1::uuid,$2::uuid,j.id,j.economic_date,j.transaction_date,j.posting_at))from erp.journal_entries j where j.id=$3`,[id(500),id(600),id(610)]);await mkPayment({p:501,status:'DRAFT'});const v=await read();return {source:v,draft_reversal:v.documents.find(d=>d.id===id(501)).current_reversal_fact};});
 await test('SALE_INVERSE_NEUTRAL_EFFECTIVE_ACTUAL_PAIRS',async()=>{
  await q("update erp.sales_headers set status='REVERSED'where id=$1",[id(100)]);await inverse(200,700,'2026-10-20','2026-10-20');
  await header(110);await q('insert into erp.sales_items(id,sale_id,product_id,qty_pcs,unit_price_snapshot)values($1,$2,$3,5,200)',[id(111),id(110),id(11)]);await journal(210,'SALE',110,'2026-10-18','2026-10-20');await line(211,210,1,'1000','0');await line(212,210,2,'0','1000');
  await q("insert into cp7_note.revisions(id,root_sale_id,previous_sale_id,replacement_sale_id,revision,actor,request_id,reason,effective_at)values($1,$2,$2,$3,1,$4,$5,'Synthetic source correction','2026-10-18')",[id(800),id(100),id(110),id(90),id(91)]);
  await journal(710,'NOTE_REVERSAL_TIME_NEUTRAL',700,'2026-10-20','2026-10-20');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,credit,debit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(700),id(710)]);
  await journal(720,'NOTE_REVERSAL_EFFECTIVE',700,'2026-10-18','2026-10-20');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,debit,credit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(700),id(720)]);
  await q("insert into cp7_note.journal_restatements values($1,$2,$3,$4,$5,'2026-10-20','2026-10-18',now())",[id(700),id(200),id(100),id(710),id(720)]);return read();
 });
 const reverseStock=async(orig,newid)=>q("insert into erp.fg_stock_movements(id,product_id,lot_id,location_id,quality_grade,movement_type,qty_signed,unit_hpp_snapshot,customer_id,source_type,source_id,physical_at,reversal_of_id)select $2,product_id,lot_id,location_id,quality_grade,'REVERSAL',-qty_signed,unit_hpp_snapshot,customer_id,'FG_MOVEMENT_REVERSAL',id,'2026-10-23',id from erp.fg_stock_movements where id=$1",[id(orig),id(newid)]);
 const correctionCase=async(book)=>{
  await mkReturn({book:'2026-10-22'});await register();await inverse(400,450,'2026-10-23','2026-10-23');await q("update erp.sales_returns set status='REVERSED'where id=$1",[id(300)]);await reverseStock(302,303);
  await journal(460,'RETURN_CORRECTION_TIME_NEUTRAL',450,'2026-10-23','2026-10-23');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,credit,debit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(450),id(460)]);
  await journal(470,'RETURN_CORRECTION_EFFECTIVE',450,'2026-10-19','2026-10-23');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,debit,credit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(450),id(470)]);
  await q("insert into cp7_sales_return_correction.journal_restatements values($1,$2,$3,$4,$5,'2026-10-23','2026-10-19',now())",[id(400),id(450),id(300),id(460),id(470)]);
  await mkReturn({r:310,ri:311,book});
  await q("insert into cp7_sales_return_correction.links(id,original_id,replacement_id,sale_id,actor,request_id,reason)values($1,$2,$3,$4,$5,$6,'Synthetic actual correction')",[id(850),id(300),id(310),id(100),id(90),id(91)]);
  await register({r:310,kind:'RETURN_CORRECTION',pred:300,lineage:850,newFamily:false});
  return {source:await read(),floor:(await q('select ow04_source_proposal.return_causal_book_floor($1)v',[id(310)])).rows[0].v};
 };
 await test('RETURN_CORRECTION_ACTUAL_LINK_AND_ROOT_BOOK',()=>correctionCase('2026-10-23'));
 await test('RETURN_CORRECTION_MISSING_REQUIRED_RESTATEMENT',async()=>{await correctionCase('2026-10-23');await ex('delete from cp7_sales_return_correction.journal_restatements');await q('delete from erp.journal_lines where journal_entry_id in($1,$2)',[id(460),id(470)]);await q('delete from erp.journal_entries where id in($1,$2)',[id(460),id(470)]);return read();});
 await test('RETURN_CORRECTION_REOPENED_BELOW_ROOT_FLOOR',()=>correctionCase('2026-10-19'));
 await test('NOTE_REPLAY_PERSISTED_HEADER_ITEM_LINK',async()=>{
  await mkReturn();await register();await inverse(200,700,'2026-10-20','2026-10-20');await inverse(400,450,'2026-10-20','2026-10-20');await q("update erp.sales_headers set status='REVERSED'where id=$1",[id(100)]);await q("update erp.sales_returns set status='REVERSED'where id=$1",[id(300)]);await reverseStock(302,303);
  await header(110);await q('insert into erp.sales_items(id,sale_id,product_id,qty_pcs,unit_price_snapshot)values($1,$2,$3,5,200)',[id(111),id(110),id(11)]);await journal(210,'SALE',110,'2026-10-18','2026-10-20');await line(211,210,1,'1000','0');await line(212,210,2,'0','1000');
  await q("insert into cp7_note.revisions(id,root_sale_id,previous_sale_id,replacement_sale_id,revision,actor,request_id,reason,effective_at)values($1,$2,$2,$3,1,$4,$5,'Synthetic exact source correction','2026-10-18')",[id(850),id(100),id(110),id(90),id(91)]);
  await q('insert into cp7_note.item_lineage values($1,$2,$3,1)',[id(111),id(101),id(850)]);
  for(const [orig,inv,neutral,effective]of[[200,700,710,720],[400,450,460,470]]){
   await journal(neutral,'NOTE_REVERSAL_TIME_NEUTRAL',inv,'2026-10-20','2026-10-20');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,credit,debit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(inv),id(neutral)]);
   const day=orig===200?'2026-10-18':'2026-10-19';await journal(effective,'NOTE_REVERSAL_EFFECTIVE',inv,day,'2026-10-20');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,debit,credit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(inv),id(effective)]);
   await q('insert into cp7_note.journal_restatements values($1,$2,$3,$4,$5,$6,$7,now())',[id(inv),id(orig),id(100),id(neutral),id(effective),'2026-10-20',day]);
  }
  await mkReturn({r:310,ri:311,sale:110,alloc:131,book:'2026-10-20'});await register({r:310,kind:'NOTE_REPLAY',pred:300,lineage:850,itemLineage:{[id(311)]:id(301)},newFamily:false});
  return {source:await read(),floor:(await q('select ow04_source_proposal.return_causal_book_floor($1)v',[id(310)])).rows[0].v};
 });
 await test('CANONICAL_NUMERIC_PROOF_HASH',async()=> (await q(`select ow04_source_proposal.sha('{"a":[0,1.0,{"hpp":0.000000}]}')=ow04_source_proposal.sha('{"a":[0.00,1,{"hpp":0}]}')as normalized,
  ow04_source_proposal.native_sha('[0]')<>ow04_source_proposal.native_sha('[0.00]')as native_codec_unchanged`)).rows[0]);

 const zeroSale=async()=>{
  await q('delete from erp.journal_lines where journal_entry_id=$1',[id(200)]);await q('delete from erp.journal_entries where id=$1',[id(200)]);
  await q('update erp.sales_items set unit_price_snapshot=0 where sale_id=$1',[id(100)]);
  await q('insert into erp.sale_stock_allocations(id,sale_item_id,lot_id,location_id,qty_pcs,unit_hpp_snapshot)values($1,$2,$3,$4,5,0)',[id(130),id(101),id(14),id(12)]);
  await q("insert into erp.fg_stock_movements(id,product_id,lot_id,location_id,movement_type,qty_signed,unit_hpp_snapshot,customer_id,source_type,source_id,physical_at)values($1,$2,$3,$4,'SALE',-5,0,$5,'SALE_ITEM',$6,'2026-10-18 01:00Z')",[id(103),id(11),id(14),id(12),id(10),id(101)]);
 };
 await test('RETURN_NOJ_AFTER_COST_DOWN_ORIGINAL_ALLOCATION_NONZERO',async()=>{await mkReturn({amount:'0',hpp:'0',withJournal:false});await q('update erp.sale_stock_allocations set unit_hpp_snapshot=10 where id=$1',[id(130)]);await register();return read();});
 await test('FREE_SALE_AND_RETURN_PROVEN_ABSENT',async()=>{await zeroSale();await mkReturn({amount:'0',hpp:'0',withJournal:false});await register();return {source:await read(),causal:(await q('select ow04_source_proposal.causal_book_info_v1($1)v',[id(300)])).rows[0].v};});
 await test('FREE_SALE_MISSING_PHYSICAL_PROOF',async()=>{await zeroSale();await q('delete from erp.fg_stock_movements where id=$1',[id(103)]);return read();});
 await test('FREE_SALE_HPP_JOURNAL_DATED',async()=>{await q('update erp.sales_items set unit_price_snapshot=0 where sale_id=$1',[id(100)]);await q('delete from erp.journal_lines where id in($1,$2)',[id(201),id(202)]);await mkReturn({amount:'0',hpp:'0',withJournal:false});await register();return {source:await read(),causal:(await q('select ow04_source_proposal.causal_book_info_v1($1)v',[id(300)])).rows[0].v};});

 }

 receipt.compiled=true;
}catch(e){receipt.setup_error={message:e.message,detail:e.detail,where:e.where,position:e.position,internalPosition:e.internalPosition,internalQuery:e.internalQuery};}
if(file!=='INITIAL_SOURCE.sql'&&receipt.compiled){
 const rows=new Map(results.map(r=>[r.id,r]));
 const source=x=>x?.observed?.source||x?.observed;
 const ev=x=>source(x)?.events;
 const errors={RETURN_CORRECTION_MISSING_REQUIRED_RESTATEMENT:'OW04_MEMBER_REQUIRED_RESTATEMENT_MISSING_OR_UNEXPECTED',REVERSED_SALE_WITHOUT_INVERSE:'OW04_SOURCE_JOURNAL_REVERSAL_HISTORY_INCOMPLETE',EXTRA_AR_LINE:'OW04_SOURCE_BASE_AR_TOTAL_MISMATCH',WRONG_ORIGINAL_DATE:'OW04_SOURCE_ORIGINAL_DOCUMENT_DATE_MISMATCH',WRONG_ROOT_MEMBER:'OW04_SOURCE_RETURN_MEMBER_WRONG_ROOT',MEMBER_WRONG_FINANCIAL_HASH:'OW04_MEMBER_IMMUTABLE_SOURCE_BINDING_CHANGED',MEMBER_WRONG_JOURNAL:'OW04_SOURCE_RETURN_MEMBER_FINANCIAL_SOURCE_MISMATCH',MEMBER_WRONG_ASSIGNMENT:'OW04_MEMBER_ASSIGNMENT_PROOF_CHANGED',UNQUALIFIED_HISTORICAL_BACKFILL:'OW04_MEMBER_HISTORICAL_ORDER_NOT_QUALIFIED',NO_JOURNAL_MISSING_STOCK_INVERSE:'OW04_SOURCE_NO_JOURNAL_STOCK_REVERSAL_INCOMPLETE',NO_JOURNAL_POSTED_ALREADY_INVERTED:'OW04_SOURCE_NO_JOURNAL_STOCK_REVERSAL_INCOMPLETE',RETURN_CORRECTION_REOPENED_BELOW_ROOT_FLOOR:'OW04_MEMBER_RETURN_PRECEDES_CAUSAL_BOOK_FLOOR',FREE_SALE_MISSING_PHYSICAL_PROOF:'OW04_ABSENT_SALE_ITEMS_OR_QUANTITIES_INVALID'};
 const good={
 RETURN_NOJ_AFTER_COST_DOWN_ORIGINAL_ALLOCATION_NONZERO:r=>source(r).source_status==='BASE_COLLECTED'&&source(r).documents.find(d=>d.kind==='RETURN').financial_state==='NO_JOURNAL',
 BASE_SALE:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===1&&ev(r)[0].amount==='1000.00',
 LEGAL_RETURN_PAYMENT500_MISSING_REGISTRY:r=>source(r).source_status==='BLOCKED'&&JSON.stringify(ev(r).map(e=>e.amount))==='["1000.00","-200.00","500.00"]'&&source(r).blockers[0].code==='IMMUTABLE_RETURN_FAMILY_OR_ORDER_MISSING',
 ADVANCE_NATIVE_PAYMENT_ONCE:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).filter(e=>e.kind==='FUNDING').length===1&&ev(r)[1].amount==='500.00'&&source(r).documents.find(d=>d.kind==='PAYMENT').source.funding_channel==='ADVANCE_NATIVE_PAYMENT',
 STABLE_REGISTERED_ORIGINAL:r=>source(r).source_status==='BASE_COLLECTED'&&r.observed.proof.family_ordinal==='1'&&r.observed.proof.financial_state==='JOURNAL',
 NO_JOURNAL_ZERO_HISTORICAL_PROOF:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===1&&source(r).documents.find(d=>d.kind==='RETURN').original_journal_id===null&&new Date(r.observed.floor).toISOString().startsWith('2026-10-18'),
 ZERO_RETURN_HPP_ONLY_REAL_JOURNAL:r=>source(r).source_status==='BLOCKED'&&ev(r).length===2&&ev(r)[1].amount==='0.00'&&source(r).documents.find(d=>d.kind==='RETURN').financial_state==='JOURNAL',
 HPP_CURRENT_STATE_HASH_SEPARATE:r=>r.observed.events_same===true&&r.observed.state_changed===true,
 PAYMENT_INVERSE_AND_DRAFT_NULL:r=>r.observed.draft_reversal===null&&JSON.stringify(ev(r).map(e=>e.amount))==='["1000.00","500.00","-500.00"]',
 SALE_INVERSE_NEUTRAL_EFFECTIVE_ACTUAL_PAIRS:r=>source(r).source_status==='BASE_COLLECTED'&&JSON.stringify(ev(r).map(e=>[e.amount,e.economic_date,e.transaction_date]))===JSON.stringify([['1000.00','2026-10-18','2026-10-18'],['1000.00','2026-10-18','2026-10-20'],['-1000.00','2026-10-20','2026-10-20'],['1000.00','2026-10-20','2026-10-20'],['-1000.00','2026-10-18','2026-10-20']]),
 RETURN_CORRECTION_ACTUAL_LINK_AND_ROOT_BOOK:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===6&&ev(r).reduce((s,e)=>s+BigInt(e.amount.replace('.','')),0n)===80000n&&new Date(r.observed.floor).toISOString().startsWith('2026-10-23')&&source(r).lineage.verified_members.length===2,
 NOTE_REPLAY_PERSISTED_HEADER_ITEM_LINK:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===10&&ev(r).reduce((s,e)=>s+BigInt(e.amount.replace('.','')),0n)===80000n&&new Date(r.observed.floor).toISOString().startsWith('2026-10-20')&&source(r).lineage.verified_members.some(m=>m.member_kind==='NOTE_REPLAY'),
 CANONICAL_NUMERIC_PROOF_HASH:r=>r.observed.normalized===true&&r.observed.native_codec_unchanged===true,
 FREE_SALE_AND_RETURN_PROVEN_ABSENT:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===0&&source(r).documents.every(d=>d.financial_state==='NO_JOURNAL')&&r.observed.causal.state==='PROVEN_ABSENT'&&r.observed.causal.causal_book_floor===null&&/^[0-9a-f]{64}$/.test(r.observed.causal.proof_sha256),
 FREE_SALE_HPP_JOURNAL_DATED:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===1&&ev(r)[0].amount==='0.00'&&r.observed.causal.state==='DATED'&&r.observed.causal.causal_book_floor.startsWith('2026-10-18')&&/^[0-9a-f]{64}$/.test(r.observed.causal.proof_sha256)
 };
 receipt.checks=[...Object.entries(errors).map(([name,want])=>({id:name,expected_error:want,pass:rows.get(name)?.error===want})),...Object.entries(good).map(([name,pred])=>{let pass=false;try{pass=!!pred(rows.get(name));}catch{}return{id:name,pass};})];
 receipt.passed=receipt.checks.filter(c=>c.pass).length;receipt.failed=receipt.checks.filter(c=>!c.pass).length;
}

await db.close();fs.writeFileSync(`${dir}/${out}`,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({classification:receipt.classification,compiled:receipt.compiled||false,setup_error:receipt.setup_error,source_sha256:receipt.source_sha256,member_sha256:receipt.member_sha256,absence_sha256:receipt.absence_sha256,observations:results.length,passed:receipt.passed,failed:receipt.failed,failed_checks:receipt.checks?.filter(c=>!c.pass)},null,2));
if(receipt.setup_error||receipt.failed)process.exitCode=1;
