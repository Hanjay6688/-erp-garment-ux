 const reverseStock=async(orig,newid)=>q("insert into erp.fg_stock_movements(id,product_id,lot_id,location_id,quality_grade,movement_type,qty_signed,unit_hpp_snapshot,customer_id,source_type,source_id,physical_at,reversal_of_id)select $2,product_id,lot_id,location_id,quality_grade,'REVERSAL',-qty_signed,unit_hpp_snapshot,customer_id,'FG_MOVEMENT_REVERSAL',id,'2026-10-23',id from erp.fg_stock_movements where id=$1",[id(orig),id(newid)]);
 const correctionCase=async(book)=>{
  await mkReturn({book:'2026-10-22'});await register();await inverse(400,450,'2026-10-23','2026-10-23');await q("update erp.sales_returns set status='REVERSED'where id=$1",[id(300)]);await reverseStock(302,303);
  await mkReturn({r:310,ri:311,book});
  await q("insert into cp7_sales_return_correction.links(id,original_id,replacement_id,sale_id,actor,request_id,reason)values($1,$2,$3,$4,$5,$6,'Synthetic actual correction')",[id(850),id(300),id(310),id(100),id(90),id(91)]);
  await register({r:310,kind:'RETURN_CORRECTION',pred:300,lineage:850,newFamily:false});
  return {source:await read(),floor:(await q('select ow04_source_proposal.return_causal_book_floor($1)v',[id(310)])).rows[0].v};
 };
 await test('RETURN_CORRECTION_ACTUAL_LINK_AND_ROOT_BOOK',()=>correctionCase('2026-10-22'));
 await test('RETURN_CORRECTION_REOPENED_BELOW_ROOT_FLOOR',()=>correctionCase('2026-10-19'));
 await test('NOTE_REPLAY_PERSISTED_HEADER_ITEM_LINK',async()=>{
  await mkReturn();await register();await inverse(200,700,'2026-10-20','2026-10-20');await inverse(400,450,'2026-10-20','2026-10-20');await q("update erp.sales_headers set status='REVERSED'where id=$1",[id(100)]);await q("update erp.sales_returns set status='REVERSED'where id=$1",[id(300)]);await reverseStock(302,303);
  await header(110);await q('insert into erp.sales_items(id,sale_id,product_id,qty_pcs,unit_price_snapshot)values($1,$2,$3,5,200)',[id(111),id(110),id(11)]);await journal(210,'SALE',110,'2026-10-18','2026-10-20');await line(211,210,1,'1000','0');await line(212,210,2,'0','1000');
  await q("insert into cp7_note.revisions(id,root_sale_id,previous_sale_id,replacement_sale_id,revision,actor,request_id,reason,effective_at)values($1,$2,$2,$3,1,$4,$5,'Synthetic exact source correction','2026-10-18')",[id(850),id(100),id(110),id(90),id(91)]);
  await q('insert into cp7_note.item_lineage values($1,$2,$3,1)',[id(111),id(101),id(850)]);
  for(const [orig,inv,neutral,effective]of[[200,700,710,720],[400,450,460,470]]){
   await journal(neutral,'NOTE_REVERSAL_TIME_NEUTRAL',inv,'2026-10-20','2026-10-20');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,credit,debit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(inv),id(neutral)]);
   const day=orig===200?'2026-10-18':'2026-10-19';await journal(effective,'NOTE_REVERSAL_EFFECTIVE',inv,day,'2026-10-20');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,debit,credit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(inv),id(effective)]);
   await q('insert into cp7_note.journal_restatements values($1,$2,$3,$4,$5,$6,$7,now())',[id(inv),id(orig),id(100),id(neutral),id(effective),'2026-10-20',day]);
  }
  await mkReturn({r:310,ri:311,sale:110,alloc:131,book:'2026-10-20'});await register({r:310,kind:'NOTE_REPLAY',pred:300,lineage:850,itemLineage:{[id(311)]:id(301)},newFamily:false});
  return {source:await read(),floor:(await q('select ow04_source_proposal.return_causal_book_floor($1)v',[id(310)])).rows[0].v};
 });
 await test('CANONICAL_NUMERIC_PROOF_HASH',async()=> (await q(`select ow04_source_proposal.sha('{"a":[0,1.0,{"hpp":0.000000}]}')=ow04_source_proposal.sha('{"a":[0.00,1,{"hpp":0}]}')as normalized,
  ow04_source_proposal.native_sha('[0]')<>ow04_source_proposal.native_sha('[0.00]')as native_codec_unchanged`)).rows[0]);
