create schema cp7_credit;
create table cp7_credit.return_families(
 id uuid primary key,
 family_root_sale_id uuid not null,
 family_ordinal bigint not null check(family_ordinal>0),
 first_return_id uuid not null unique,
 assignment_kind text not null check(assignment_kind in('NEW_POST','QUALIFIED_BACKFILL')),
 assignment_proof jsonb not null check(jsonb_typeof(assignment_proof)='object'),
 source_sha256 text not null check(source_sha256~'^[0-9a-f]{64}$'),
 actor uuid not null,request_id uuid not null,
 recorded_at timestamptz not null default statement_timestamp(),
 unique(family_root_sale_id,family_ordinal)
);
create table cp7_credit.return_family_members(
 family_id uuid not null,
 return_id uuid primary key,
 member_kind text not null check(member_kind in('ORIGINAL','RETURN_CORRECTION','NOTE_REPLAY')),
 source_journal_id uuid not null unique,
 source_sha256 text not null check(source_sha256~'^[0-9a-f]{64}$'),
 actual_lineage_snapshot jsonb not null check(jsonb_typeof(actual_lineage_snapshot)='object'),
 actor uuid not null,request_id uuid not null,
 recorded_at timestamptz not null default statement_timestamp(),
 unique(family_id,return_id)
);
alter table cp7_credit.return_family_members
 add column financial_state text not null default 'JOURNAL',
 add column financial_source_proof jsonb,
 alter column source_journal_id drop not null;
alter table cp7_credit.return_family_members
 alter column financial_state drop default,
 add constraint return_member_financial_state check(
  financial_state in('JOURNAL','NO_JOURNAL')and
  ((financial_state='JOURNAL'and source_journal_id is not null)
   or(financial_state='NO_JOURNAL'and source_journal_id is null))),
 add constraint return_member_no_journal_proof check(
  financial_state<>'NO_JOURNAL'or coalesce((
   financial_source_proof is not null and
   jsonb_typeof(financial_source_proof)='object'and
   financial_source_proof->>'contract_version'='ow04.native-no-return-journal-proof.v1'and
   financial_source_proof->>'return_id'=return_id::text and
   jsonb_typeof(financial_source_proof->'document')='object'and
   jsonb_typeof(financial_source_proof->'items')='array'and
   jsonb_array_length(financial_source_proof->'items')>0 and
   jsonb_typeof(financial_source_proof->'actual_original_fg_movements')='array'and
   jsonb_typeof(financial_source_proof->'actual_allocations')='array'and
   financial_source_proof->>'financial_event'='ABSENT'),false));

-- The CHECK validates shape only. The owning writer and factual closure must
-- recompute exactly the supplied full proof from actual rows under FG/source
-- locks and compare its digest with the immutable source_sha256 contract:
--  * actual POSTED/REVERSED non-draft return, nonempty positive-quantity items;
--  * every refund_amount=0 AND actual frozen unit_hpp_snapshot=0;
--  * exact Native allocation/item/lot/product/location/grade/quantity lineage;
--  * exactly one original SALE_RETURN movement per actual item, customer and
--    physical_at equal the document, no duplicate/unbound original movements;
--  * actual originals and source-bound inverse movement facts are retained;
--  * no SALES_RETURN original journal exists for this return at all;
--  * no economic/book event, invented UUID, zero journal or surrogate book date.
-- Nonzero HPP/cumulative-target cases without an original journal need their
-- own exact Native target proof; the narrow zero-HPP proof must refuse them.
-- Changed Native document status or appended inverse rows are separate state
-- bindings; they do not rewrite an original immutable source digest.

