 if(file!=='INITIAL_SOURCE.sql'){
 const mkReturn=async({r=300,ri=301,amount='200',hpp='10',withJournal=true,sale=100,alloc=130,lot=14,book='2026-10-19',status='POSTED'}={})=>{
  await q('insert into erp.sale_stock_allocations(id,sale_item_id,lot_id,location_id,qty_pcs,unit_hpp_snapshot)values($1,$2,$3,$4,5,$5)on conflict do nothing',[id(alloc),id(sale+1),id(lot),id(12),hpp]);
  await q("insert into erp.sales_returns(id,return_number,sale_id,customer_id,physical_at,status)values($1,$2,$3,$4,'2026-10-19 01:00Z',$5)",[id(r),`R${r}`,id(sale),id(10),status]);
  await q('insert into erp.sales_return_items(id,return_id,product_id,lot_id,location_id,qty_pcs,unit_hpp_snapshot,refund_amount,sale_stock_allocation_id)values($1,$2,$3,$4,$5,1,$6,$7,$8)',[id(ri),id(r),id(11),id(lot),id(12),hpp,amount,id(alloc)]);
  await q("insert into erp.fg_stock_movements(id,product_id,lot_id,location_id,movement_type,qty_signed,unit_hpp_snapshot,customer_id,source_type,source_id,physical_at)values($1,$2,$3,$4,'SALE_RETURN',1,$5,$6,'SALES_RETURN_ITEM',$7,'2026-10-19 01:00Z')",[id(ri+1),id(11),id(lot),id(12),hpp,id(10),id(ri)]);
  if(withJournal){await journal(r+100,'SALES_RETURN',r,'2026-10-19',book,status==='REVERSED'?'REVERSED':'POSTED');if(amount!=='0'){await line(r+101,r+100,2,amount,'0');await line(r+102,r+100,1,'0',amount);}else{await line(r+101,r+100,4,'10','0',11);await line(r+102,r+100,3,'0','10',11);}}
  return id(r);
 };
 const mkPayment=async({p=500,amount='500',advance=false,status='POSTED'}={})=>{
  if(!advance)await q("insert into erp.cash_accounts(id,cash_account_code,cash_account_name,coa_account_id,account_kind)values($1,'TEST','Synthetic',$2,'BANK')on conflict do nothing",[id(50),id(5)]);
  await q("insert into erp.sales_payments(id,sale_id,payment_number,payment_date,amount,cash_account_id,payment_method,status)values($1,$2,$3,'2026-10-20 01:00Z',$4,$5,$6,$7)",[id(p),id(100),`P${p}`,amount,advance?null:id(50),advance?'OPENING_ADVANCE':'TRANSFER',status]);
  if(status==='DRAFT')return;
  await journal(p+100,'SALES_PAYMENT',p,'2026-10-20','2026-10-20',status==='REVERSED'?'REVERSED':'POSTED');await line(p+101,p+100,advance?6:5,amount,'0');await line(p+102,p+100,1,'0',amount);
  await q(`insert into erp.sales_payment_posting_facts(payment_id,sale_id,customer_id,payment_number,payment_date,amount,cash_account_id,original_journal_entry_id,journal_economic_date,journal_transaction_date,journal_posting_at,payment_snapshot,lineage_sha256)
   select p.id,p.sale_id,$2,p.payment_number,p.payment_date,p.amount,p.cash_account_id,j.id,j.economic_date,j.transaction_date,j.posting_at,to_jsonb(p)-'status',
    ow04_source_proposal.sha(jsonb_build_array(p.id,p.sale_id,$2::uuid,p.payment_number,p.payment_date,p.amount,p.cash_account_id,j.id,j.economic_date,j.transaction_date,j.posting_at,p.replaces_payment_id,null,to_jsonb(p)-'status'))
   from erp.sales_payments p join erp.journal_entries j on j.source_type='SALES_PAYMENT'and j.source_id=p.id where p.id=$1`,[id(p),id(10)]);
  if(advance){await q("insert into erp.initial_import_prepayments(id,batch_id,source_row_id,party_type,party_id,customer_id,coa_account_id,document_number,document_date,cutover_date,original_amount,settled_before_cutover,amount)values($1,$2,$3,'CUSTOMER',$4,$4,$5,'A','2026-10-17','2026-10-17',1000,0,1000)",[id(60),id(61),id(62),id(10),id(6)]);await q("insert into erp.initial_import_prepayment_payments(payment_id,advance_id,sales_payment_id,payment_snapshot)select id,$2,id,to_jsonb(p)-'status'from erp.sales_payments p where id=$1",[id(p),id(60)]);}
 };
 const inverse=async(orig,newid,e='2026-10-21',b=e)=>{
  await q("update erp.journal_entries set status='REVERSED'where id=$1",[id(orig)]);await journal(newid,'JOURNAL_REVERSAL',orig,e,b,'POSTED',orig);
  await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,vendor_id,contractor_id,po_id,product_id)select $2,account_id,credit,debit,customer_id,vendor_id,contractor_id,po_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(orig),id(newid)]);
 };
 const register=async({r=300,fam=800,ordinal='1',kind='ORIGINAL',pred=null,lineage=null,itemLineage={},newFamily=true}={})=>{
  await ex('create schema if not exists cp7_credit');
  if(!(await q("select to_regclass('cp7_credit.return_families')v")).rows[0].v)await ex(fs.readFileSync(`${dir}/ISOLATED_REGISTRY.sql`,'utf8').replace('create schema cp7_credit;',''));
  const fact=(await q('select ow04_source_proposal.return_fact_v1($1)v',[id(r)])).rows[0].v;
  if(newFamily){const assignment={contract_version:'ow04.return-family-assignment.v1',family_id:id(fam),family_root_sale_id:id(100),family_ordinal:ordinal,first_return_id:id(r),previous_family_id:ordinal==='1'?null:id(fam-1),actor:id(90),request_id:id(91)};
   await q("insert into cp7_credit.return_families(id,family_root_sale_id,family_ordinal,first_return_id,assignment_kind,assignment_proof,source_sha256,actor,request_id)values($1,$2,$3,$4,'NEW_POST',$5,ow04_source_proposal.sha($5::jsonb),$6,$7)",[id(fam),id(100),ordinal,id(r),JSON.stringify(assignment),id(90),id(91)]);}
  const snap={contract_version:'ow04.actual-return-family-member.v1',family_id:id(fam),family_root_sale_id:id(100),return_id:id(r),sale_id:fact.sale_id,member_kind:kind,predecessor_return_id:pred===null?null:id(pred),native_lineage_id:lineage===null?null:id(lineage),return_item_lineage:itemLineage,financial_state:fact.financial_state,source_journal_id:fact.source_journal_id,financial_source_sha256:fact.financial_source_sha256,no_journal_proof:fact.no_journal_proof};
  await q('insert into cp7_credit.return_family_members(family_id,return_id,member_kind,source_journal_id,source_sha256,actual_lineage_snapshot,actor,request_id,financial_state,financial_source_proof)values($1,$2,$3,$4,ow04_source_proposal.sha($5::jsonb),$5,$6,$7,$8,$9)',[id(fam),id(r),kind,fact.source_journal_id,JSON.stringify(snap),id(90),id(91),fact.financial_state,JSON.stringify(fact.no_journal_proof)]);
  return snap;
 };
 await test('LEGAL_RETURN_PAYMENT500_MISSING_REGISTRY',async()=>{await mkReturn();await mkPayment();return read();});
 await test('ADVANCE_NATIVE_PAYMENT_ONCE',async()=>{await mkPayment({advance:true});return read();});
 await test('STABLE_REGISTERED_ORIGINAL',async()=>{await mkReturn();await register();return {source:await read(),proof:(await q('select ow04_source_proposal.verify_return_member_v1($1)v',[id(300)])).rows[0].v};});
 await test('MEMBER_WRONG_FINANCIAL_HASH',async()=>{await mkReturn();await register();await q("update cp7_credit.return_family_members set actual_lineage_snapshot=jsonb_set(actual_lineage_snapshot,'{financial_source_sha256}',to_jsonb(repeat('f',64)))where return_id=$1",[id(300)]);return read();});
 await test('MEMBER_WRONG_JOURNAL',async()=>{await mkReturn();await register();await q('update cp7_credit.return_family_members set source_journal_id=$2 where return_id=$1',[id(300),id(200)]);return read();});
 await test('MEMBER_WRONG_ASSIGNMENT',async()=>{await mkReturn();await register();await q("update cp7_credit.return_families set assignment_proof=jsonb_set(assignment_proof,'{family_ordinal}','\"2\"')");return read();});
 await test('UNQUALIFIED_HISTORICAL_BACKFILL',async()=>{await mkReturn();await register();await q("update cp7_credit.return_families set assignment_kind='QUALIFIED_BACKFILL'");return read();});
 await test('NO_JOURNAL_ZERO_HISTORICAL_PROOF',async()=>{await mkReturn({amount:'0',hpp:'0',withJournal:false});await register();const v=await read();return {source:v,floor:(await q('select ow04_source_proposal.return_causal_book_floor($1)v',[id(300)])).rows[0].v};});
 await test('NO_JOURNAL_MISSING_STOCK_INVERSE',async()=>{await mkReturn({amount:'0',hpp:'0',withJournal:false,status:'REVERSED'});return read();});
 await test('NO_JOURNAL_POSTED_ALREADY_INVERTED',async()=>{await mkReturn({amount:'0',hpp:'0',withJournal:false});await q("insert into erp.fg_stock_movements(id,product_id,lot_id,location_id,movement_type,qty_signed,unit_hpp_snapshot,customer_id,source_type,source_id,physical_at,reversal_of_id)select $2,product_id,lot_id,location_id,'REVERSAL',-qty_signed,unit_hpp_snapshot,customer_id,'FG_MOVEMENT_REVERSAL',id,'2026-10-20',id from erp.fg_stock_movements where id=$1",[id(302),id(303)]);return read();});
 await test('ZERO_RETURN_HPP_ONLY_REAL_JOURNAL',async()=>{await mkReturn({amount:'0',hpp:'10'});return read();});
 await test('HPP_CURRENT_STATE_HASH_SEPARATE',async()=>{await mkReturn();await mkPayment();const a=await read();await q("update erp.sales_return_items set unit_hpp_snapshot=11 where id=$1",[id(301)]);await q("update erp.customers set customer_name='Other current label'where id=$1",[id(10)]);const b=await read();return {events_same:JSON.stringify(a.events)===JSON.stringify(b.events),state_changed:a.state_sha256!==b.state_sha256};});
 await test('PAYMENT_INVERSE_AND_DRAFT_NULL',async()=>{await mkPayment({status:'REVERSED'});await inverse(600,610);await q(`insert into erp.sales_payment_reversal_facts(payment_id,original_journal_entry_id,reversal_journal_entry_id,reversal_economic_date,reversal_transaction_date,reversal_posting_at,lineage_sha256)
   select $1,$2,j.id,j.economic_date,j.transaction_date,j.posting_at,ow04_source_proposal.sha(jsonb_build_array($1::uuid,$2::uuid,j.id,j.economic_date,j.transaction_date,j.posting_at))from erp.journal_entries j where j.id=$3`,[id(500),id(600),id(610)]);await mkPayment({p:501,status:'DRAFT'});const v=await read();return {source:v,draft_reversal:v.documents.find(d=>d.id===id(501)).current_reversal_fact};});
 await test('SALE_INVERSE_NEUTRAL_EFFECTIVE_ACTUAL_PAIRS',async()=>{
  await q("update erp.sales_headers set status='REVERSED'where id=$1",[id(100)]);await inverse(200,700,'2026-10-20','2026-10-20');
  await header(110);await q('insert into erp.sales_items(id,sale_id,product_id,qty_pcs,unit_price_snapshot)values($1,$2,$3,5,200)',[id(111),id(110),id(11)]);await journal(210,'SALE',110,'2026-10-18','2026-10-20');await line(211,210,1,'1000','0');await line(212,210,2,'0','1000');
  await q("insert into cp7_note.revisions(id,root_sale_id,previous_sale_id,replacement_sale_id,revision,actor,request_id,reason,effective_at)values($1,$2,$2,$3,1,$4,$5,'Synthetic source correction','2026-10-18')",[id(800),id(100),id(110),id(90),id(91)]);
  await journal(710,'NOTE_REVERSAL_TIME_NEUTRAL',700,'2026-10-20','2026-10-20');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,credit,debit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(700),id(710)]);
  await journal(720,'NOTE_REVERSAL_EFFECTIVE',700,'2026-10-18','2026-10-20');await q('insert into erp.journal_lines(journal_entry_id,account_id,debit,credit,customer_id,product_id)select $2,account_id,debit,credit,customer_id,product_id from erp.journal_lines where journal_entry_id=$1',[id(700),id(720)]);
  await q("insert into cp7_note.journal_restatements values($1,$2,$3,$4,$5,'2026-10-20','2026-10-18',now())",[id(700),id(200),id(100),id(710),id(720)]);return read();
 });
 }
