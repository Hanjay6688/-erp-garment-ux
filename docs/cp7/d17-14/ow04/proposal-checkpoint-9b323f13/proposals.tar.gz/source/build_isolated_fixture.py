"""Selected actual table DDL; synthetic rows only, never a Native installer."""
from pathlib import Path
import gzip,re,hashlib,json
BASE=Path('/workspace/scratch/9442228ed2dc'); REPO=BASE/'erp-d1714'; OUT=BASE/'ow04-proposals/source'
raw=gzip.open(REPO/'supabase/tests/fixtures/erp_enteng_cp45a_catalog_bootstrap.sql.gz','rt').read()
ap=(REPO/'supabase/release/cp6-t3/20260922135615_erp_v2_6_20ap_cp6_connected_import_materials.sql').read_text()
pf=(REPO/'supabase/migrations/20260910170556_erp_v2_6_20j_cp6_payment_fact_closure.sql').read_text()
chunks=["create schema erp;create schema cp7_note;create schema cp7_sales_return_correction;create schema cp7_payment_correction;create sequence erp.fg_stock_book_order_seq;"]
chunks+=[f'create role {r};'for r in ['anon','authenticated','service_role','cp7_capture','cp7_sales_read','cp7_sales_write']]
receipt=[]
def table(src,schema,name):
 m=re.search(r'create table (?:"'+schema+r'"|'+schema+r')\.(?:"'+name+r'"|'+name+r')\s*\([\s\S]*?\n\);',src,re.I)
 if not m: raise ValueError(name)
 sql=m[0]; receipt.append({'table':schema+'.'+name,'exact_source_ddl_sha256':hashlib.sha256(sql.encode()).hexdigest()})
 # Only FK dependencies removed in isolation. Columns, generated values,
 # declared precision, NOT NULL and local checks remain actual source DDL.
 sql=re.sub(r'\s+references\s+[\w.]+(?:\([^)]*\))?(?:\s+on delete restrict)?(?:\s*deferrable initially deferred)?','',sql,flags=re.I)
 chunks.append(sql)
for n in ['customers','chart_accounts','accounting_account_mappings','sales_headers','sales_items','sales_returns','sales_return_items','sales_payments','sale_stock_allocations','fg_stock_movements','journal_entries','journal_lines','cash_accounts']:table(raw,'erp',n)
chunks.extend('alter table erp.'+n+' add primary key(id);'for n in ['customers','chart_accounts','sales_headers','sales_items','sales_returns','sales_return_items','sales_payments','sale_stock_allocations','fg_stock_movements','journal_entries','journal_lines','cash_accounts'])
chunks.append('alter table erp.accounting_account_mappings add primary key(mapping_key);')
chunks.append('alter table erp.sales_payments add column replaces_payment_id uuid;')
for n in ['sales_payment_posting_facts','sales_payment_reversal_facts']:table(pf,'erp',n)
chunks.append('alter table erp.sales_payment_posting_facts alter column cash_account_id drop not null;')
for n in ['initial_import_prepayments','initial_import_prepayment_payments']:table(ap,'erp',n)
for path,sch,names in [('sales/correction.sql','cp7_note',['revisions','payment_replays','journal_restatements']),('sales/return-correction.sql','cp7_sales_return_correction',['links','context','journal_restatements']),('sales/payment-correction.sql','cp7_payment_correction',['links'])]:
 txt=(REPO/'scripts/cp7-src'/path).read_text()
 for name in names:table(txt,sch,name)
table((REPO/'scripts/cp7-src/sales/correction-lines.sql').read_text(),'cp7_note','item_lineage')
(OUT/'ISOLATED_TABLES.sql').write_text('\n'.join(chunks)+'\n')
(OUT/'ISOLATED_TABLES_RECEIPT.json').write_text(json.dumps({'classification':'SELECTED_ACTUAL_DDL_SYNTHETIC_ONLY_FK_DEPENDENCIES_REMOVED','tables':receipt},indent=2)+'\n')

ledger=(OUT.parent/'ledger/01_immutable_facts.proposal.sql').read_text()
reg=[]
for name in ['return_families','return_family_members']:
 m=re.search(r'create table cp7_credit\.'+name+r'\([\s\S]*?\n\);',ledger,re.I)
 sql=re.sub(r'\s+references\s+[\w.]+(?:\([^)]*\))?(?:\s*deferrable initially deferred)?','',m[0],flags=re.I)
 reg.append(sql)
delta=(OUT/'NO_JOURNAL_SCHEMA_DIFF.proposal.sql').read_text()
delta=delta[delta.index('alter table cp7_credit.return_family_members'):delta.index('-- A financial cohort')]
(OUT/'ISOLATED_REGISTRY.sql').write_text('create schema cp7_credit;\n'+'\n'.join(reg)+'\n'+delta)
