# OW04 actual base source and immutable member proof proposal

This directory is outside the active repository. The SQL deliberately refuses installation. Source basis: repository candidate b7fc541, accepted catalogue bootstrap plus subsequent CP6 migrations/releases and current CP7 owning writers. Nothing here was run against Native or installed in the product. There is no settlement authority API, new account policy, fake import batch, default credit account, or completed paid-return feature.

`RESULT.json` records **28/28 isolated checks** of the actual proposed SQL against selected actual Native table definitions and explicitly synthetic rows. The fixture removes external foreign-key dependencies; it retains columns, precision, generated values, local checks, and restores actual base primary keys. It does not reproduce Native writers, RLS, triggers, current HPP targets, concurrency, or the complete product database. Initial bad acceptances remain in `INITIAL_SOURCE.sql` and `INITIAL_RESULT.json`; intermediate failure receipts are retained.

| Function | Nature | Contract |
|---|---|---|
| `locked_source_family(uuid)` | VOLATILE, private postgres definer | FG first, source locks, complete actual base journal history and separate current-state manifest |
| `verify_return_member_v1(uuid)` | STABLE, private postgres definer | Exact protected member/assignment snapshots against actual Native source and correction lineage; no authority/current-I/profile/lock callback |
| `return_fact_v1(uuid)` | STABLE read | Completed Native RETURN monetary identity and actual JOURNAL or typed NO_JOURNAL facts |
| `family_read_v1(uuid)` | STABLE read | Real contiguous root-to-leaf note revision chain, same customer |
| `sale_absence_fact_v1(uuid)` | STABLE read | Actual net-zero SALE, frozen zero HPP allocation/SALE movement proof, exact quantities, actual journal absence |
| `return_causal_book_floor(uuid)` | Private completed-source read | Maximum actual original SALE books and proven logical RETURN-family books; refuses unknown/absent dated source |
| `causal_book_info_v1(uuid)` | Private completed-source read | `DATED` with real floor, or independently proven causal base-history `PROVEN_ABSENT` with null floor |

All functions are revoked from public, anon, authenticated, service_role and CP7 low roles. The eventual whole installer must grant only the exact internal caller capabilities needed; these files provide no broad grant.

## Actual source events

Each event is exactly `{id,kind,amount,economic_date,transaction_date,source_sha256}`. `id` is `journal:<actual UUID>`, never a projected UUID. `amount` is finite unbounded canonical exact-cent text, including signed zero-normalized `0.00`. NET is the actual AR debit minus credit for SALE/RETURN; FUNDING is the inverse AR effect for Native SALES_PAYMENT. Native payments funded by imported advances already have SALES_PAYMENT AR journals and count once as P. This reader emits no duplicate U for an advance.

The collector includes original journals even when REVERSED, every actual standard inverse descendant, and both exact recorded neutral/effective legs of note, return, and payment corrections. It verifies Native payment posting/reversal facts with their original raw JSONB SHA codec. Known correction ownership requires its Native restatement metadata when the inverse economic date moved; missing legs cannot be silently ignored. Note payment replays must preserve actual funding channel, cash identity or advance-wallet identity, amount and physical payment timestamp.

Actual base AR is derived from the Native original monetary line and required document amount, not every line bearing customer_id. Revenue and HPP lines also carry that customer. The total and number of base AR lines must match the document exactly. Mixed historic AR accounts or a changed current mapping is not silently reclassified. Source customer/account/cash/current mapping rows are separately captured.

The collector does **not** emit new customer-credit APPLY or recognition events. The integrated authoritative builder must add actual materialized signed incoming APPLY/restores as U and keep recognition I out of raw funding. Current paid/status readers remain a separate capability: an inactive original invoice must never inherit the latest leaf's paid amount through root aliasing.

`BASE_COLLECTED` proves this factual base scope. It is not write authorization, full financial admission, a completed settlement operation, or proof that a pending Native operation has finished. Missing immutable return registration remains `BLOCKED`. Unproved historical order, customer/account changes, malformed journals, wrong-root members and missing correction legs refuse or block explicitly. No physical/created clock or UUID order becomes a financial family ordinal.

## Hashes and retained facts

Financial event identity contains actual journal/source UUIDs and both dates/posting timestamp, exact AR lines, and the source document's monetary/time/item identities. Mutable header status, HPP/current cost projections and current masters belong to `state_sha256`, not immutable financial identity. The full actual original journal remains in that state manifest. A later source inverse is a new signed event; it does not rewrite the old event's digest.

`sha(jsonb)` recursively normalizes JSON numeric display scales before canonical JSONB-text SHA256: 0 and 0.000000 hash equally. Source financial cents are exact strings. `native_sha(jsonb)` deliberately retains Native's raw JSONB-text codec for payment facts; changing that digest would be incorrect. Proofs and snapshots must be generated inside SQL. Clients send review/projection hashes, not float-roundtripped source snapshots. Native original/source fact text can be retained raw for inspection.

The actual advance wallet has immutable document/amount columns and no mutable current balance/status column (20ap203–216 and immutable triggers6603–6605). Even so, only its immutable link plus Native posting fact/actual funding account enters the payment's financial identity; the full wallet is current-state context.

## Exact protected registration protocol

`NO_JOURNAL_SCHEMA_DIFF.proposal.sql` changes the old pinned ledger schema by adding typed `financial_state`, nullable actual journal iff NO_JOURNAL, and full `financial_source_proof`; cohort source-return provenance gets the same typed representation. It preserves existing history fields. Shape CHECKs are not a substitute for the factual verifier.

A NEW_POST family's `assignment_proof` is the exact JSON object:

```
{contract_version:'ow04.return-family-assignment.v1', family_id,
 family_root_sale_id, family_ordinal:<canonical positive integer text>,
 first_return_id, previous_family_id:<uuid|null>, actor, request_id}
```

The immutable family `source_sha256` is `sha(assignment_proof)`. Ordinals are contiguous and predecessor family IDs must agree. **Only a protected owning writer can attest NEW_POST order under FG and bind the assignment to its immutable owning-operation receipt.** Pure SQL checks cannot prove old posting order retroactively. `QUALIFIED_BACKFILL` refuses here until an explicit qualified protocol is integrated. The accepted possible LEGACY_BASE epoch direction is not implemented: it needs a frozen complete base manifest, no historical I/consumers and nonpositive family NET/zero baseline F at every joint cut. Unregistered older returns remain a blocker; no convenience fallback exists.

A member's `actual_lineage_snapshot` is exactly:

```
{contract_version:'ow04.actual-return-family-member.v1', family_id,
 family_root_sale_id, return_id, sale_id, member_kind,
 predecessor_return_id:<uuid|null>, native_lineage_id:<uuid|null>,
 return_item_lineage:<object>, financial_state:'JOURNAL'|'NO_JOURNAL',
 source_journal_id:<actual uuid|null>, financial_source_sha256,
 no_journal_proof:<full typed proof|null>}
```

`source_sha256=sha(actual_lineage_snapshot)`. ORIGINAL matches the family's first return/actor/request, with null predecessor/Native lineage and empty item map. RETURN_CORRECTION binds the actual immutable `cp7_sales_return_correction.links.id`, original/replacement headers, actor/request and same-family predecessor. NOTE_REPLAY binds the actual `cp7_note.revisions.id`, prior/new sale headers, same physical return instant, and a complete bijective new-return-item→old-return-item map. It verifies quantity/refund/product/lot/destination/grade and the actual `cp7_note.item_lineage` allocation ownership. This persisted member snapshot supplies the missing Native note-return header link; the existing local `return_lineage` variable alone is not persisted financial proof. Cycles, gaps and forks refuse.

`verify_return_member_v1` returns the version `ow04.verified-return-member.v1`, family/root/ordinal/return/sale/kind/predecessor/Native lineage, financial state and actual journal identity, financial-source/member/registration digests, plus nullable `causal_book_floor`. Every relevant member must be verified; verification of one current leaf does not silently qualify its siblings.

The helper reads facts only. It does not authorize a recorded actor, inspect a JWT/context at COMMIT, call the current paid reader, or call the volatile collector. This permits the materialized-profile inspector to use it without a dependency cycle. Final closure still needs complete actual source-plan semantics, all signed recognition/consumption history, immutable owning-operation completion and final receipt/status facts. Live permission/post-wait/replay checks remain the owning command's responsibility before completion.

## Genuine journal absence and dates

A physical RETURN can have no journal: AH414–417 only calls post_journal when at least two lines exist. The narrow verified zero-HPP proof requires nonempty positive quantities, refund0, actual frozen return-item/movement HPP0, exact original allocation/item/product/lot/quantity lineage, destination/grade/customer/physical time, no duplicate original movement, and actual journal absence. A reversed source requires its exact actual inverse stock movement; a posted source cannot already be inverted. Original allocation cost may be nonzero after an accepted recost10→0; it is not forced to0. Frozen proof is separate from current lot HPP.

The typed no-return-journal proof version is `ow04.native-no-return-journal-proof.v1`, containing return_id, status-free document, full frozen items/allocations/original FG movements (excluding mutable book_order) and `financial_event:'ABSENT'`. It has no journal UUID or surrogate economic/book event. The corresponding sale proof version is `ow04.native-no-sale-journal-proof.v1`. Price0 or a full discount is allowed by existing Native draft input; zero-money/zero-HPP SALE may also have no journal. A real HPP-only journal is retained as a dated actual NET0 event, never turned into absence by its AR amount0.

`causal_book_info_v1` emits:

```
{contract_version:'ow04.actual-causal-book-info.v1',
 state:'DATED'|'PROVEN_ABSENT', causal_book_floor:<date|null>,
 return_id, proof_manifest, proof_sha256}
```

Unknown facts raise; they never become PROVEN_ABSENT. No funding, inverse or unrelated HPP-sync book is maximized into the source floor. For a given completed member, ancestral SALE books stop at its actual sale revision; prior RETURN family books remain causal. The completed-family floor for a new operation retains the actual root SALE/return-family floors after reopening. A private financial cohort poster cannot accept an unverified null floor.

These are **completed actual source** readers, not pre-post authorization. AH sets RETURN POSTED and HPP snapshots before its journal call. Calling completed `return_fact_v1` there can see an in-flight missing journal. The owning `native_return_enter` must seal a separate PRIOR causal source manifest while its new row is DRAFT: real SALE ancestors and bound existing family ancestors only. Its own projection may be excluded solely through the protected typed scope/projection binding, never a caller-selected excluded UUID/date. The completed reader runs after the actual J/verified no-J decision. Projected and actual journal manifests have distinct hashes; Native allocates random journal UUIDs.

Prior causal absence and a projected return's journal expectation are separate. Genuine OPENING0→free SALE(noJ)→accepted recost10→zero-refund RETURN can post an HPP-only RETURN journal despite no prior SALE/RETURN date. Source/sync HPP journals do not create a causal SALE book. Current Native cumulative HPP projection and lawful resolver must still be applied; historical allocation0 alone cannot promise a new no-J return. The whole coordinator/paired-poster contract must handle this qualified non-credit branch without inventing a date. The scalar financial-floor refusal is intentionally retained until that sealed-prior integration is complete.

## Execution and remaining integration

Reproduce isolated checks:

```
python ow04-proposals/source/build_isolated_fixture.py
node ow04-proposals/source/check_source.mjs source.sql RESULT.json
```

`native_probe.py` can be imported by an already approved closed Native harness. `legal_ordinary_source_case(cur,today,fixture)` uses only retained Native writers for SALE1000→unpaid RETURN200→PAY500, then expects actual NET1000/NET−200/FUNDING500 and missing immutable registration BLOCKED. Import never connects/starts/installs anything; this Native probe has not been executed. Paid-return guard bypass or seeded Native POSTED paid-return facts are not permitted substitutes.

The owning whole integration remains required: sealed pre/post projection and actual binding; NEW_POST assignment/NOTE replay persistence; complete incoming U facts; current AR/E nonnegative/admission checks; joint F(noReturns)=0 and family NET prefix constraints; per-cohort target-minus-all-retained-signed-I reconciliation and future joint capacity; all actual mechanical posting parts; account/cash/period/close invariants; pending midpost versus completed plan/materialization validation; immutable operation/receipt closure; and Native/source/runtime verification. Source globals use FG→ordered Native payment/return/header and source/master locks→Native period SHARE→CASH; a post-period recheck may not discover/acquire earlier-order new source locks. No paid return implementation is claimed.
