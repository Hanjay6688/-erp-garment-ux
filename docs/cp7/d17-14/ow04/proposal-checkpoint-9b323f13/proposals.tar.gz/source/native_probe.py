"""Callable source-only probe for an existing closed Native harness.

Import never connects, starts a DB, installs SQL, creates a registry, or calls a
new settlement API. The caller supplies its already approved cursor and existing
Native fixture module. This file itself has NOT been run against Native.
"""
from decimal import Decimal
import hashlib
import json
import uuid


def inspect_existing(cur, sale_id):
    # Private SQL is callable only by the existing administrative/business
    # executor; do not add client grants or substitute a service role.
    raw = cur.execute(
        'select ow04_source_proposal.locked_source_family(%s)::text',
        (sale_id,),
    ).fetchone()[0]
    data = json.loads(raw, parse_float=Decimal)
    assert data['contract_version'] == 'ow04.actual-base-source-family.v1'
    assert data['scope'] == 'ACTUAL_EXISTING_BASE_JOURNALS_ONLY_NO_PROJECTION_AUTHORITY_OR_COHORT_RECONCILIATION'
    assert len({e['id'] for e in data['events']}) == len(data['events'])
    for event in data['events']:
        assert event['id'].startswith('journal:')
        assert event['economic_date'] <= event['transaction_date']
        # The actual event digest is computed by SQL, never a float roundtrip.
        assert len(event['source_sha256']) == 64
    return {'classification': 'ACTUAL_NATIVE_SOURCE_READ_IF_CALLED_NOT_SETTLEMENT_PROOF',
            'raw_json': raw, 'raw_sha256': hashlib.sha256(raw.encode()).hexdigest(),
            'document': data}


def legal_ordinary_source_case(cur, today, fixture):
    """Use existing Native writers: SALE1000 -> unpaid RETURN200 -> PAY500.

    fixture is the source-only module cp7_ow04_native_source_fixture already
    loaded by the owning closed harness; it exposes the retained fixture helpers.
    No Native paid-return guard is bypassed and no family/ordinal row is faked.
    Expected: actual NET1000, NET-200, FUNDING500 plus missing-registry BLOCKED.
    """
    f = fixture.note.stock(cur, today, 10)
    fixture.note.posted(cur, f, '5', '200')
    f['destination'] = fixture.returns.location(cur)
    f['bank'] = str(fixture.source.bc.bank_account(cur, 'OW04-SOURCE-'+uuid.uuid4().hex[:10]))
    f['allocations'] = fixture.returns.read(cur, f)['page']['rows']
    fixture.returns.returned(cur, f, qty='1', refund='200')
    payload, version = fixture.payments.payment_payload(cur, f, '500')
    fixture.cmd.command(cur, 'PAYMENT', payload, version)
    before = fixture.source_manifest(cur, {'f': f, 'fixture_id': 'OW04_SOURCE_COLLECTOR_LEGAL_UNPAID_RETURN'})
    result = inspect_existing(cur, f['sale'])
    after = fixture.source_manifest(cur, {'f': f, 'fixture_id': 'OW04_SOURCE_COLLECTOR_LEGAL_UNPAID_RETURN'})
    assert before == after, 'SOURCE_READER_CHANGED_NATIVE_FACTS'
    data = result['document']
    assert sorted((e['kind'], e['amount']) for e in data['events']) == [
        ('FUNDING', '500.00'), ('NET', '-200.00'), ('NET', '1000.00')]
    assert data['source_status'] == 'BLOCKED'
    assert any(b['code'] == 'IMMUTABLE_RETURN_FAMILY_OR_ORDER_MISSING'
               for b in data['blockers'])
    return result
