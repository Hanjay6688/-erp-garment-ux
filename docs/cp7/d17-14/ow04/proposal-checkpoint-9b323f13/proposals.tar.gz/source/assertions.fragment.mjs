if(file!=='INITIAL_SOURCE.sql'&&receipt.compiled){
 const rows=new Map(results.map(r=>[r.id,r]));
 const source=x=>x?.observed?.source||x?.observed;
 const ev=x=>source(x)?.events;
 const errors={REVERSED_SALE_WITHOUT_INVERSE:'OW04_SOURCE_JOURNAL_REVERSAL_HISTORY_INCOMPLETE',EXTRA_AR_LINE:'OW04_SOURCE_BASE_AR_TOTAL_MISMATCH',WRONG_ORIGINAL_DATE:'OW04_SOURCE_ORIGINAL_DOCUMENT_DATE_MISMATCH',WRONG_ROOT_MEMBER:'OW04_SOURCE_RETURN_MEMBER_WRONG_ROOT',MEMBER_WRONG_FINANCIAL_HASH:'OW04_MEMBER_IMMUTABLE_SOURCE_BINDING_CHANGED',MEMBER_WRONG_JOURNAL:'OW04_SOURCE_RETURN_MEMBER_FINANCIAL_SOURCE_MISMATCH',MEMBER_WRONG_ASSIGNMENT:'OW04_MEMBER_ASSIGNMENT_PROOF_CHANGED',UNQUALIFIED_HISTORICAL_BACKFILL:'OW04_MEMBER_HISTORICAL_ORDER_NOT_QUALIFIED',NO_JOURNAL_MISSING_STOCK_INVERSE:'OW04_SOURCE_NO_JOURNAL_STOCK_REVERSAL_INCOMPLETE',NO_JOURNAL_POSTED_ALREADY_INVERTED:'OW04_SOURCE_NO_JOURNAL_STOCK_REVERSAL_INCOMPLETE',RETURN_CORRECTION_REOPENED_BELOW_ROOT_FLOOR:'OW04_MEMBER_RETURN_PRECEDES_CAUSAL_BOOK_FLOOR',FREE_SALE_MISSING_PHYSICAL_PROOF:'OW04_ABSENT_SALE_ITEMS_OR_QUANTITIES_INVALID'};
 const good={
 BASE_SALE:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===1&&ev(r)[0].amount==='1000.00',
 LEGAL_RETURN_PAYMENT500_MISSING_REGISTRY:r=>source(r).source_status==='BLOCKED'&&JSON.stringify(ev(r).map(e=>e.amount))==='["1000.00","-200.00","500.00"]'&&source(r).blockers[0].code==='IMMUTABLE_RETURN_FAMILY_OR_ORDER_MISSING',
 ADVANCE_NATIVE_PAYMENT_ONCE:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).filter(e=>e.kind==='FUNDING').length===1&&ev(r)[1].amount==='500.00'&&source(r).documents.find(d=>d.kind==='PAYMENT').source.funding_channel==='ADVANCE_NATIVE_PAYMENT',
 STABLE_REGISTERED_ORIGINAL:r=>source(r).source_status==='BASE_COLLECTED'&&r.observed.proof.family_ordinal==='1'&&r.observed.proof.financial_state==='JOURNAL',
 NO_JOURNAL_ZERO_HISTORICAL_PROOF:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===1&&source(r).documents.find(d=>d.kind==='RETURN').original_journal_id===null&&r.observed.floor.startsWith('2026-10-18'),
 ZERO_RETURN_HPP_ONLY_REAL_JOURNAL:r=>source(r).source_status==='BLOCKED'&&ev(r).length===2&&ev(r)[1].amount==='0.00'&&source(r).documents.find(d=>d.kind==='RETURN').financial_state==='JOURNAL',
 HPP_CURRENT_STATE_HASH_SEPARATE:r=>r.observed.events_same===true&&r.observed.state_changed===true,
 PAYMENT_INVERSE_AND_DRAFT_NULL:r=>r.observed.draft_reversal===null&&JSON.stringify(ev(r).map(e=>e.amount))==='["1000.00","500.00","-500.00"]',
 SALE_INVERSE_NEUTRAL_EFFECTIVE_ACTUAL_PAIRS:r=>source(r).source_status==='BASE_COLLECTED'&&JSON.stringify(ev(r).map(e=>[e.amount,e.economic_date,e.transaction_date]))===JSON.stringify([['1000.00','2026-10-18','2026-10-18'],['1000.00','2026-10-18','2026-10-20'],['-1000.00','2026-10-20','2026-10-20'],['1000.00','2026-10-20','2026-10-20'],['-1000.00','2026-10-18','2026-10-20']]),
 RETURN_CORRECTION_ACTUAL_LINK_AND_ROOT_BOOK:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===6&&ev(r).reduce((s,e)=>s+Number(e.amount),0)===800&&r.observed.floor.startsWith('2026-10-23')&&source(r).lineage.verified_members.length===2,
 NOTE_REPLAY_PERSISTED_HEADER_ITEM_LINK:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===10&&ev(r).reduce((s,e)=>s+Number(e.amount),0)===800&&r.observed.floor.startsWith('2026-10-20')&&source(r).lineage.verified_members.some(m=>m.member_kind==='NOTE_REPLAY'),
 CANONICAL_NUMERIC_PROOF_HASH:r=>r.observed.normalized===true&&r.observed.native_codec_unchanged===true,
 FREE_SALE_AND_RETURN_PROVEN_ABSENT:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===0&&source(r).documents.every(d=>d.financial_state==='NO_JOURNAL')&&r.observed.causal.state==='PROVEN_ABSENT'&&r.observed.causal.causal_book_floor===null&&/^[0-9a-f]{64}$/.test(r.observed.causal.proof_sha256),
 FREE_SALE_HPP_JOURNAL_DATED:r=>source(r).source_status==='BASE_COLLECTED'&&ev(r).length===1&&ev(r)[0].amount==='0.00'&&r.observed.causal.state==='DATED'&&r.observed.causal.causal_book_floor.startsWith('2026-10-18')&&/^[0-9a-f]{64}$/.test(r.observed.causal.proof_sha256)
 };
 receipt.checks=[...Object.entries(errors).map(([name,want])=>({id:name,expected_error:want,pass:rows.get(name)?.error===want})),...Object.entries(good).map(([name,pred])=>{let pass=false;try{pass=!!pred(rows.get(name));}catch{}return{id:name,pass};})];
 receipt.passed=receipt.checks.filter(c=>c.pass).length;receipt.failed=receipt.checks.filter(c=>!c.pass).length;
}
