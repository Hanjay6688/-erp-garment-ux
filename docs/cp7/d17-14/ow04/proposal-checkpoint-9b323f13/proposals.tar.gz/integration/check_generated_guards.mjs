// Actual builder-generated guard/ACL SQL on synthetic PGlite functions only.
// No Native writer, ERP fixture, Auth, admission callback, or feature install.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {PGlite} from '/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
const here=path.dirname(new URL(import.meta.url).pathname),repo=path.resolve(process.argv[2]);
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const py=`import json,sys,importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
p=Path(sys.argv[1])/'check_derive_plan.py'
s=importlib.util.spec_from_file_location('ow04_guard_controls',p);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
x=json.load(sys.stdin)
if x['action']=='inventory':
 print(json.dumps({'query':c.m.CAPTURE_QUERY,'facts':{k:[{'native_signature':n,'native_definition_sha256':'a'*64}for n in sorted(v)]for k,v in [('cp7_note',c.m.NOTE_NATIVE),('cp7_sales_return_correction',c.m.RETURN_NATIVE)]}}))
elif x['action']=='guard':print(c.m._guard_sql(x['rows'],x['facts'],x.get('absent',[])))
elif x['action']=='acl':
 a,b,_=c.fixtures(Path(sys.argv[2]));q=c.m.render_install_sql(c.m.derive_plan(a,b),b)
 start=q.index('do $ow04_new_acl$');end=q.index('grant execute on function ',start)
 end=q.index(';',end)+1
 print(q[start:end])
`;
function python(input){const p=spawnSync('python',['-c',py,here,repo],{input:JSON.stringify(input),encoding:'utf8',env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'}});if(p.status!==0)throw Error(p.stderr);return p.stdout;}
const inv=JSON.parse(python({action:'inventory'})),db=new PGlite(),results=[];
const ex=s=>db.exec(s),q=(s,p=[])=>db.query(s,p);
const capture=async identity=>{const r=(await q(inv.query.replace('%s','$1'),[identity])).rows[0];
 // Select expressions have duplicate generic names; use unique SQL aliases.
 const a=(await q(`select pg_get_functiondef(p.oid)definition,p.prosrc body,pg_get_userbyid(p.proowner)owner,
 case when p.proacl is null then null else array(select x::text from unnest(p.proacl)x order by x::text collate "C")end acl,
 p.prosecdef security_definer,p.provolatile::text volatility,p.proconfig config from pg_proc p where oid=to_regprocedure($1)`,[identity])).rows[0];
 if(!r||!a)throw Error('synthetic capture unavailable');return {identity,...a};};
const identity='erp.integration_probe(text)',bound='cp7_credit._post_journal_bound(text,uuid,date,text,jsonb)';
const guard=(rows,absent=[])=>python({action:'guard',rows,facts:inv.facts,absent});
async function test(id,sql,accept,mutate=''){
 await ex('begin');let error=null;
 try{if(mutate)await ex(mutate);await ex(sql);}catch(e){error={message:e.message,code:e.code};}
 await ex('rollback');const pass=accept?!error:!!error;
 results.push({id,pass,expected:accept?'ACCEPT':'REJECT',observed:error?'REJECT':'ACCEPT',...(error?{error}:{})});
 if(!pass)throw Error('guard control failed: '+id);
}
try{
 await ex(`create schema erp;create schema cp7_note;create schema cp7_sales_return_correction;create schema cp7_credit;
 create role integration_other;create role integration_default;
 create table cp7_note.helper_sources(native_signature text,native_definition_sha256 text);
 create table cp7_sales_return_correction.helper_sources(native_signature text,native_definition_sha256 text);
 create function erp.integration_probe(p_text text)returns text language plpgsql security definer set search_path=''as $probe$
 begin return p_text||E'\\\\path, quote '' and newline\\n';end $probe$;`);
 for(const [schema,rows]of Object.entries(inv.facts))for(const r of rows)await q(`insert into ${schema}.helper_sources values($1,$2)`,[r.native_signature,r.native_definition_sha256]);
 const original=await capture(identity),sql=guard([original],[bound]);
 await test('EXACT_SYNTHETIC_FUNCTION_AND_BASELINES',sql,true);
 await test('E_LITERAL_RETAINS_BACKSLASHES_WITH_STANDARD_STRINGS_OFF',sql,true,'set local standard_conforming_strings=off;');
 await test('CHANGED_OWNER',sql,false,`alter function ${identity}owner to integration_other;`);
 await test('CHANGED_ACL',sql,false,`revoke execute on function ${identity}from public;`);
 await test('CHANGED_CONFIG',sql,false,`alter function ${identity}set search_path=public;`);
 await test('CHANGED_DEFINER',sql,false,`alter function ${identity}security invoker;`);
 await test('CHANGED_VOLATILITY',sql,false,`alter function ${identity}stable;`);
 await test('CHANGED_BODY',sql,false,`create or replace function erp.integration_probe(p_text text)returns text language plpgsql security definer set search_path=''as $probe$begin return p_text||'changed';end $probe$;`);
 await test('MISSING_FUNCTION',sql,false,`drop function ${identity};`);
 await test('CHANGED_IMMUTABLE_BASELINE',sql,false,`update cp7_note.helper_sources set native_definition_sha256=repeat('b',64);`);
 await test('EXTRA_IMMUTABLE_BASELINE',sql,false,`insert into cp7_sales_return_correction.helper_sources values('erp.unapproved(uuid)',repeat('a',64));`);
 await test('NEW_POSTER_PREEXISTS',sql,false,`create function ${bound.replace('text,uuid,date,text,jsonb','text,uuid,date,text,jsonb')}returns uuid language sql as $f$select null::uuid$f$;`);
 const wrong={...original,acl:[]};await test('NULL_ACL_DIFFERS_FROM_EMPTY_ARRAY',guard([wrong]),false);
 await ex(`alter default privileges grant execute on functions to integration_default;
 create function cp7_credit._post_journal_bound(text,uuid,date,text,jsonb)returns uuid language sql as $f$select null::uuid$f$;`);
 const before=(await capture(bound)).acl;
 if(!before.some(x=>x.startsWith('integration_default=')))throw Error('default ACL fixture did not exist');
 await ex(python({action:'acl'}));
 const after=await capture(bound);
 if(JSON.stringify(after.acl)!==JSON.stringify(['postgres=X/postgres']))throw Error('new ACL is not exact postgres-only');
 results.push({id:'ACTUAL_GENERATED_NEW_POSTER_ACL_STRIPS_PUBLIC_AND_NONSTANDARD_DEFAULT_ROLE',pass:true,before,after:after.acl});
 const output={classification:'ACTUAL_GENERATED_GUARD_ACL_SQL_SYNTHETIC_PGLITE_NOT_NATIVE',status:'PASS',results,count:results.length,
 native_execution_proven:false,feature_installed:false,authority_proven:false,builder_sha256:sha(fs.readFileSync(path.join(here,'derive_plan.py')))};
 fs.writeFileSync(path.join(here,'GENERATED_GUARD_RESULT.json'),JSON.stringify(output,null,2)+'\n');
 console.log(JSON.stringify({status:output.status,controls:output.count,classification:output.classification}));
}finally{await db.close();}
