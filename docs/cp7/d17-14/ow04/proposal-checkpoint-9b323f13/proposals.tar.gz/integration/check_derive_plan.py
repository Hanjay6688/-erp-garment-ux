"""Static actual-release/declared-copy + synthetic metadata controls, NOT Native.

No database driver, connection, SQL execution, or installation. Two physical FG
primitive bodies below are explicitly synthetic transport controls: this checks
their exact preservation, not their Native implementation. The financial bodies
come from actual release source and the retained baseline journal source.
"""
from copy import deepcopy
from hashlib import sha256
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('ow04_derive_control', HERE / 'derive_plan.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def _reject(label, call, out):
    try: call()
    except (ValueError, AssertionError) as e:
        out.append({'id': label, 'status': 'EXPECTED_REFUSAL', 'reason': str(e)[:200]})
    else: raise AssertionError('CONTROL_ACCEPTED: ' + label)


def _row(identity, definition, body, private=False):
    return dict(identity=identity, definition=definition, body=body, owner='postgres',
                acl=['postgres=X/postgres'] if private else ['postgres=X/postgres','service_role=X/postgres'],
                security_definer=True, volatility='v', config=['search_path=erp, public, pg_temp'])


def fixtures(repo):
    release = repo / 'supabase/release/cp6-t3'
    rows, evidence = {}, []
    for identity, file, name, transform in m.admission.SPECS:
        source = (release / file).read_text()
        pattern = rf'CREATE OR REPLACE FUNCTION erp\.{re.escape(name)}\([^$]*?\$function\$(.*?)\$function\$'
        matches = list(re.finditer(pattern, source, re.S)); assert len(matches) == 1
        definition, body = matches[0].group(0), matches[0].group(1)
        rows[identity] = _row(identity, definition, body)
        evidence.append({'identity': identity, 'source': str(release / file), 'source_sha256': m.digest(source),
                         'classification': 'ACTUAL_RELEASE_STATIC_FOOTPRINT_NOT_INSTALLED_CAPTURE'})
    for identity, file, name in (
        (m.POSTER,'20260915031500_erp_v2_6_20ac_cp6_temporal_surface_closure.sql','post_journal'),
        (m.REVERSE,'20260922135615_erp_v2_6_20ap_cp6_connected_import_materials.sql','reverse_journal')):
        source = (release / file).read_text()
        definition, body = m.ledger.extract_release_definition(source, name)
        rows[identity] = _row(identity, definition, body)
        evidence.append({'identity': identity, 'source': str(release / file), 'source_sha256': m.digest(source),
                         'classification': 'ACTUAL_RELEASE_STATIC_FOOTPRINT_NOT_INSTALLED_CAPTURE'})
    path = repo / 'docs/cp7/d17-14/ow04/ordinal-sql-counter/BASELINE_PRIVATE_REVERSE.source.txt'
    text = path.read_text(); definition = text[text.index('CREATE OR REPLACE'):].strip()
    body = definition.split('$function$')[1]
    rows[m.NOTE_NATIVE[1]] = _row(m.NOTE_NATIVE[1], definition, body)
    fgbody = "\ndeclare m record;begin\n perform erp.require_internal();\n perform clock_timestamp();\nend;\n"
    fgdef = 'CREATE OR REPLACE FUNCTION erp.reverse_fg_movement(p_movement_id uuid,p_reason text) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER AS $function$' + fgbody + '$function$;'
    rows[m.NOTE_NATIVE[0]] = _row(m.NOTE_NATIVE[0], fgdef, fgbody)
    # Independently mirror the actual SQL copier's declared operations. The
    # current Python return-correction derivation supplies a cross-check below.
    def copied(native, schema):
        definition, body = native['definition'], native['body']
        name = native['identity'].split('.')[1].split('(')[0]
        changed = re.sub(r'\bbegin\b', 'begin\n perform ' + schema + '.require_context();', body, count=1, flags=re.I)
        for helper in ('reverse_fg_movement','reverse_journal','_cp3_r4_reverse_journal_internal'):
            changed = changed.replace('erp.' + helper + '(', schema + '.' + helper + '(')
        if name == 'reverse_fg_movement': changed = changed.replace('clock_timestamp()', 'm.physical_at')
        elif name == '_cp3_r4_reverse_journal_internal':
            changed = changed.replace('RETURN v_new_id;', 'PERFORM ' + schema + '.restate_reversal(p_journal_entry_id,v_new_id,p_reason); RETURN v_new_id;')
        elif name in ('reverse_sale','reverse_sales_return'):
            field = 'h.sale_date' if name == 'reverse_sale' else 'h.physical_at'
            changed = changed.replace("((statement_timestamp() AT TIME ZONE 'Asia/Jakarta'::text))::date", "(("+field+" AT TIME ZONE 'Asia/Jakarta'::text))::date")
        newdef = definition.replace(body, changed).replace('FUNCTION erp.' + name + '(', 'FUNCTION ' + schema + '.' + name + '(')
        return _row(native['identity'].replace('erp.',schema+'.',1), newdef, changed, True)
    return_bundle = m._load('ow04_static_real_return_copier', repo / m.LEGACY_FILES[1])
    for schema, natives in (('cp7_note',m.NOTE_NATIVE), ('cp7_sales_return_correction',m.RETURN_NATIVE)):
        for identity in natives:
            row = copied(rows[identity], schema)
            if schema == 'cp7_sales_return_correction':
                name = identity.split('.')[1].split('(')[0]
                assert row['definition'] == return_bundle.derived(rows[identity]['definition'], name)
            rows[row['identity']] = row
    facts = {schema: sorted([{'native_signature': n, 'native_definition_sha256': m.digest(rows[n]['definition'])}
                            for n in names], key=lambda r:r['native_signature'])
             for schema,names in (('cp7_note',m.NOTE_NATIVE), ('cp7_sales_return_correction',m.RETURN_NATIVE))}
    pins = {file:m.digest((repo/file).read_text()) for file in m.LEGACY_FILES}
    # ONLY this labelled synthetic control constructs an approval from fixtures.
    # The production builder has no approve-current-candidate entry point.
    approval = dict(contract_version='ow04.native-approved.v1',
        baseline_verification={'phase':'VERIFIED_PREDECESSOR','verifiers':['probe.verify','p09.functions'],
                               'receipt_sha256':m.digest('SYNTHETIC CONTROL RECEIPT, NOT A VERIFIED NATIVE PREDECESSOR')},
        functions=[m._fingerprint(rows[s]) for s in m.REQUIRED], helper_sources=facts,
        legacy_verifier_sources=pins, absent_targets=[m.BOUND])
    captures = dict(contract_version='ow04.native-captures.v1',
        baseline_receipt={'phase':'BEFORE_CAPTURE','external_receipt_sha256':approval['baseline_verification']['receipt_sha256'],
                          'legacy_verifier_sources':pins}, functions=[rows[s] for s in m.REQUIRED],
        helper_sources=facts, absent_targets=[m.BOUND])
    return captures, approval, evidence


class Result:
    def __init__(self, rows): self.rows = rows
    def fetchone(self): return self.rows[0] if self.rows else None
    def fetchall(self): return self.rows


class ReadOnlyModel:
    def __init__(self, plan):
        self.rows = {e['target_identity']:e['new'] for e in plan['entries']}
        self.rows[m.POSTER] = next(e['old'] for e in plan['entries'] if e['source_identity']==m.POSTER)
        self.facts = plan['immutable_helper_sources']; self.passed = []
    def execute(self, sql, params=None):
        if sql == m.CAPTURE_QUERY:
            r = self.rows.get(params[0])
            return Result([] if r is None else [(r['definition'],r['body'],r['owner'],r['acl'],r['security_definer'],r['volatility'],r['config'])])
        for schema, rows in self.facts.items():
            if sql == 'select native_signature,native_definition_sha256 from '+schema+'.helper_sources order by native_signature collate "C"':
                return Result([(r['native_signature'],r['native_definition_sha256'])for r in rows])
            if sql == 'select native_signature,native_definition_sha256 from '+schema+'.helper_sources':
                return Result([(r['native_signature'],r['native_definition_sha256'])for r in rows])
        if sql == m.DEFINITION_READ and params[0] in self.rows:
            return Result([(self.rows[params[0]]['definition'],)])
        if sql == 'select prosecdef,proconfig from pg_proc where oid=%s::regprocedure':
            r = self.rows[params[0]]
            if 'security_definer' not in r:
                r = self.rows[params[0].replace('erp.','cp7_note.',1)]
            return Result([(r['security_definer'],r['config'])])
        if sql == 'select pg_get_userbyid(proowner),prosecdef,proconfig,prosrc from pg_proc where oid=%s::regprocedure':
            r = self.rows[params[0]]
            return Result([(r['owner'],r['security_definer'],r['config'],r['body'])])
        if sql == 'select native_definition_sha256 from cp7_sales_return_correction.helper_sources where native_signature=%s':
            return Result([(next(r['native_definition_sha256']for r in self.facts['cp7_sales_return_correction']if r['native_signature']==params[0]),)])
        if sql == 'select p.oid::regprocedure::text,p.proname,pg_get_userbyid(p.proowner),p.prosecdef,p.provolatile::text,p.proconfig from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname=%s':
            return Result(self.return_inventory)
        self.passed.append((sql,params)); return Result([('ACTUAL_UNRELATED_READ',)])


def main(repo):
    captures, approval, evidence = fixtures(repo)
    plan = m.derive_plan(captures, approval); controls = []
    assert len(plan['entries']) == 19 and tuple(e['target_identity']for e in plan['entries']) == m.TARGETS
    assert [e['source_identity']for e in plan['entries']if e['action']=='UNCHANGED'] == ['cp7_note.reverse_fg_movement(uuid,text)','cp7_sales_return_correction.reverse_fg_movement(uuid,text)']
    for e in plan['entries']:
        if e['source_identity'] in m.PRIVATE:
            schema = e['source_identity'].split('.')[0]
            assert e['new']['body'].count('perform '+schema+'.require_context();') == 1
        for guard in ('perform erp.require_internal();','perform erp.require_owner_admin();'):
            assert e['new']['body'].count(guard)>=e['old']['body'].count(guard)
    sql = m.render_install_sql(plan, approval)
    assert re.search(r'\bCOMMIT\b',sql) is None and 'update cp7_note.helper_sources' not in sql and 'update cp7_sales_return_correction.helper_sources' not in sql
    assert sql.count('do $ow04_exact_guard$') == 2
    controls.append({'id':'ACTUAL_SOURCE_19_ENTRIES_EXACT_CONTEXT_GUARDS_AND_SQL', 'status':'PASS'})
    mutations = {
        'MISSING_FUNCTION':lambda x:x['functions'].pop(),
        'EXTRA_FUNCTION':lambda x:x['functions'].append(dict(x['functions'][0],identity='erp.unapproved(uuid)')),
        'DUPLICATE_FUNCTION':lambda x:x['functions'].append(deepcopy(x['functions'][0])),
        'CHANGED_OWNER':lambda x:x['functions'][0].update(owner='service_role'),
        'CHANGED_ACL':lambda x:x['functions'][0].update(acl=['authenticated=X/postgres','postgres=X/postgres']),
        'NULL_ACL_IS_NOT_EMPTY':lambda x:x['functions'][0].update(acl=None),
        'EMPTY_ACL_IS_NOT_NULL':lambda x:x['functions'][0].update(acl=[]),
        'CHANGED_CONFIG':lambda x:x['functions'][0].update(config=['search_path=public']),
        'NULL_CONFIG':lambda x:x['functions'][0].update(config=None),
        'CHANGED_DEFINER':lambda x:x['functions'][0].update(security_definer=False),
        'CHANGED_VOLATILITY':lambda x:x['functions'][0].update(volatility='s'),
        'CHANGED_BODY':lambda x:x['functions'][0].update(body=x['functions'][0]['body']+' '),
        'CHANGED_DEFINITION':lambda x:x['functions'][0].update(definition=x['functions'][0]['definition']+' '),
        'EXTRA_CAPTURE_FIELD':lambda x:x['functions'][0].update(skip_metadata=True),
        'MISSING_BASELINE_RECEIPT':lambda x:x.update(baseline_receipt={}),
        'BOUND_ALREADY_EXISTS':lambda x:x.update(absent_targets=[]),
        'IMMUTABLE_BASELINE_CHANGED':lambda x:x['helper_sources']['cp7_note'][0].update(native_definition_sha256='0'*64),
        'IMMUTABLE_BASELINE_DUPLICATE':lambda x:x['helper_sources']['cp7_note'].append(deepcopy(x['helper_sources']['cp7_note'][0])),
    }
    for label, mutate in mutations.items():
        x = deepcopy(captures); mutate(x)
        _reject(label,lambda x=x:m.derive_plan(x,approval),controls)
    for key,value in (('owner','authenticated'),('config',['search_path=public']),('definition_sha256','0'*64),('body_sha256','1'*64)):
        x = deepcopy(approval); x['functions'][0][key]=value
        _reject('APPROVAL_MISMATCH_'+key,lambda x=x:m.derive_plan(captures,x),controls)
    forged = deepcopy(plan); forged['entries'][0]['new']['body'] += '\n-- changed'
    _reject('FORGED_TARGET_PLAN',lambda:m.render_install_sql(forged,approval),controls)
    live = ReadOnlyModel(plan)
    proof = m.verify_installed(live,plan,approval)
    view = m._LegacyDefinitionView(live,plan,approval,proof)
    identity = m.REVERSE
    expected_old = next(e['old']['definition']for e in plan['entries']if e['source_identity']==identity)
    assert view.execute(m.DEFINITION_READ,(identity,)).fetchone() == (expected_old,)
    assert view.execute('select 42',(123,)).fetchone() == ('ACTUAL_UNRELATED_READ',)
    report = 'erp.get_owner_financial_snapshot_v2(date,date,date)'
    assert view.execute(m.DEFINITION_READ,(report,)).fetchone() == ('ACTUAL_UNRELATED_READ',)
    controls.append({'id':'LEGACY_ONLY_EXACT_DEFINITION_PROJECTED_UNRELATED_SQL_UNCHANGED','status':'PASS'})
    for label,query,params in (
        ('WRONG_SQL',m.DEFINITION_READ+' -- extra',(identity,)),
        ('WRONG_PARAMS_LIST',m.DEFINITION_READ,[identity]),
        ('WRONG_PARAMS_EXTRA',m.DEFINITION_READ,(identity,identity)),
        ('WRONG_FUNCTION',m.DEFINITION_READ,('erp.unrelated(uuid)',)),
        ('LITERAL_SIGNATURE','select pg_get_functiondef(\''+identity+'\'::regprocedure)',None)):
        _reject('LEGACY_'+label,lambda q=query,p=params:view._project_definition(q,p),controls)
    badproof=dict(proof,plan_sha256='0'*64)
    _reject('LEGACY_WRONG_FAMILY_SIGNATURE_AT_EXECUTE',lambda:view.execute(m.DEFINITION_READ,('erp.reverse_journal(uuid)',)),controls)
    _reject('LEGACY_WRONG_PROOF_HASH',lambda:m._LegacyDefinitionView(live,plan,approval,badproof),controls)
    _reject('LEGACY_WRONG_PLAN_HASH',lambda:m._LegacyDefinitionView(live,forged,approval,proof),controls)
    for key,val in (('definition','bad'),('acl',['authenticated=X/postgres','postgres=X/postgres']),('config',None)):
        changed = ReadOnlyModel(plan); changed.rows[identity] = dict(changed.rows[identity],**{key:val})
        _reject('LIVE_TARGET_CHANGED_'+key,lambda c=changed:m.verify_installed(c,plan,approval),controls)
    changed = ReadOnlyModel(plan); changed.facts=deepcopy(changed.facts)
    changed.facts['cp7_note'][0]['native_definition_sha256']='0'*64
    _reject('LIVE_BASELINE_CHANGED',lambda:m.verify_installed(changed,plan,approval),controls)
    # Preserve the first direct legacy failure using the ACTUAL verify source.
    path = repo / m.LEGACY_FILES[0]; tree = ast.parse(path.read_text())
    node = next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='verify')
    src = ast.get_source_segment(path.read_text(),node)
    scope={'hashlib':hashlib,'SIGNATURES':m.NOTE_NATIVE}
    exec(compile(src,str(path),'exec'),scope)
    for signature in m.NOTE_NATIVE:
        if signature not in live.rows:
            fact=next(r for r in captures['helper_sources']['cp7_note']if r['native_signature']==signature)
            # Actual early non-transformed checks need their baseline bodies;
            # they are retained in private copies only. Supply fixture originals.
            # Hash matching is explicit, never suppress an original assertion.
            original = fixtures_originals(repo,captures,signature)
            assert m.digest(original)==fact['native_definition_sha256']
            live.rows[signature]={'definition':original}
    try: scope['verify'](live)
    except AssertionError as error:
        assert error.args == (('NOTE_NATIVE_DEFINITION_CHANGED',m.REVERSE),),error.args
        direct={'classification':'ACTUAL_LEGACY_VERIFY_STATIC_MODEL_FIRST_FAILURE_NOT_NATIVE','args':repr(error.args)}
    else: raise AssertionError('DIRECT_LEGACY_DID_NOT_FAIL')
    rp=repo/m.LEGACY_FILES[1];rtree=ast.parse(rp.read_text())
    rnode=next(n for n in rtree.body if isinstance(n,ast.FunctionDef)and n.name=='verify')
    expectednode=next(n.value for n in rnode.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='expected'for t in n.targets))
    expected=ast.literal_eval(expectednode)
    schema='cp7_sales_return_correction'
    names=tuple(s.split('.')[1].split('(')[0]for s in m.RETURN_NATIVE)
    live.return_inventory=[]
    ordered=[s for s in m.PRIVATE if s.startswith(schema+'.')]
    ordered.sort(key=lambda s:0 if '._cp3_r4_'in s else 1)
    for identity in ordered:
        row=live.rows[identity];name=identity.split('.')[1].split('(')[0]
        live.return_inventory.append((identity,name,row['owner'],row['security_definer'],row['volatility'],row['config']))
    for name,(sec,vol,utc)in expected.items():
        live.return_inventory.append((schema+'.'+name+'()',name,'postgres',sec,vol,['search_path=""']+(['TimeZone=UTC']if utc else[])))
    copier=m._load('ow04_control_return_bundle',rp)
    rscope={'hashlib':hashlib,'SCHEMA':schema,'HELPERS':names,'TABLES':copier.TABLES,'derived':copier.derived}
    exec(compile(ast.get_source_segment(rp.read_text(),rnode),str(rp),'exec'),rscope)
    try:rscope['verify'](live)
    except AssertionError as error:
        assert error.args==((schema+'._cp3_r4_reverse_journal_internal(uuid,text)','Undeclared private Native delta'),),error.args
        return_direct={'classification':'ACTUAL_RETURN_LEGACY_VERIFY_STATIC_MODEL_FIRST_FAILURE_NOT_NATIVE','args':repr(error.args)}
    else:raise AssertionError('DIRECT_RETURN_LEGACY_DID_NOT_FAIL')
    firstpath=HERE/'FIRST_LEGACY_FAILURE.json'
    first={'classification':'RETAINED_ACTUAL_LEGACY_ASSERTIONS_SYNTHETIC_MODEL_NOT_NATIVE','note':direct,'return_correction':return_direct}
    if firstpath.exists():assert json.loads(firstpath.read_text())==first
    else:firstpath.write_text(json.dumps(first,indent=2)+'\n')
    output={'classification':'STATIC_ACTUAL_SOURCE_AND_SYNTHETIC_METADATA_CONTROLS_NOT_NATIVE','status':'PASS',
        'controls':controls,'count':len(controls),'Native_execution_proven':False,'database_calls':0,
        'builder_sha256':m.digest((HERE/'derive_plan.py').read_text()),'source_evidence':evidence,
        'plan_sha256':m.digest(m.canonical(plan)),'direct_legacy_first_failure':direct,'return_correction_direct_legacy_first_failure':return_direct,
        'limitations':['No installed pg_get_functiondef capture obtained','No Native/Postgres/Auth execution',
          'Physical FG primitive control body is synthetic; exact transfer only',
          'Full actual composed legacy verify remains required in CI transaction']}
    return output


def fixtures_originals(repo,captures,signature):
    if signature==m.NOTE_NATIVE[1]:
        text=(repo/'docs/cp7/d17-14/ow04/ordinal-sql-counter/BASELINE_PRIVATE_REVERSE.source.txt').read_text()
        return text[text.index('CREATE OR REPLACE'):].strip()
    fgbody="\ndeclare m record;begin\n perform erp.require_internal();\n perform clock_timestamp();\nend;\n"
    return 'CREATE OR REPLACE FUNCTION erp.reverse_fg_movement(p_movement_id uuid,p_reason text) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER AS $function$'+fgbody+'$function$;'


if __name__=='__main__':
    repo=Path(sys.argv[1]).resolve()
    result=main(repo)
    (HERE/'STATIC_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'controls':result['count'],'classification':result['classification']}))
