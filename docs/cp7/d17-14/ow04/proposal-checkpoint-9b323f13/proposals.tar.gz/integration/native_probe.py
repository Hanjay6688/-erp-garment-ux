"""OW04 first integrated Native qualification, on disposable CP6 copies only.

Predeclared: 12 explicit CREDIT/REFUND cases, all 11 unchanged P11 return
controls, all 8 unchanged P11 read/Native source controls, and E01 (32 Native).
This does not claim browser, race, complete OW04, or production acceptance.
"""
import hashlib
import json
from pathlib import Path
import sys
import traceback

import psycopg
import cp7_f05_analysis_probe as predecessor
import cp7_restore_state as restore_state
import cp7_sales_return_cases as retained_returns
import cp7_sales_cases as retained_reads
import cp7_f03_e01_cases as retained_e01
from cp7_catalog_state import exact_public_catalog
from cp6_t3_aligned_install import advisors, advisor_delta

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / 'erp-d1714'
sys.path[:0] = [str(HERE.parent / 'initial-settlement'), str(HERE.parent / 'native')]
import cp7_ow04_initial_settlement_cases as initial
import owning_bundle as credit

p09 = predecessor.p09
package = predecessor.package
native = predecessor.native
OUT = p09.bundle.ROOT / 'cp6-proof/t3/CP7_OW04_INITIAL.json'
RETURN_IDS = tuple('P11_RETURN_' + x for x in ('LIFECYCLE','SPLIT_GRADES','ALLOCATION_CAP','FIELDS',
    'PAID_REFUSAL','DATE_LOCATION','REPLAY','SOURCE_CHANGE','PERMISSIONS','PAGES','CONSUMED'))
READ_IDS = tuple('P11_READ_'+x for x in ('DRAFT_CANCEL','NATIVE_LIFECYCLE','EXACT_CENTS',
    'FINANCIAL_REDACTION','PRIVATE_READ_ONLY','COMPLETE_PAGES','QUERY_REFUSAL','EMPTY_MISSING'))
IDS = tuple(initial.NATIVE_IDS) + RETURN_IDS + READ_IDS + ('F03_E01_NATIVE_60_TO_CASH_RETURN',)
assert len(IDS) == len(set(IDS)) == 32
STATE = None


def cases(cur, today):
    selected = initial.cases(cur, today) + retained_returns.cases(cur, today) + retained_reads.cases(cur, today) + retained_e01.cases(cur, today)
    assert tuple(name for name, _ in selected) == IDS, 'OW04_PREDECLARED_CASE_SET_CHANGED'
    return selected


def verify(cur):
    if STATE is None:
        raise RuntimeError('OW04_NO_VERIFIED_INTEGRATED_CANDIDATE')
    exact = credit.verify(cur, STATE)
    # All predecessor checks remain, with the two declared SALES capabilities
    # and exact independent private-inverse composition checked above.
    predecessor.bundle.verify(cur)
    predecessor.payroll.verify(cur, True, True, True, True, True)
    predecessor.finance.verify(cur, customer_credit=True)
    predecessor.f03.journal.verify(cur)
    predecessor.f03.misc.verify(cur)
    predecessor.f03.installment.verify(cur)
    predecessor.f03.transaction_source.verify(cur)
    predecessor.f03.misc_correction.verify(cur)
    predecessor.payment_correction_ownership.verify(cur)
    predecessor.sales_chain_ownership.verify(cur)
    predecessor.f03.cutting_correction.verify(cur)
    return exact


def install_predecessor(cur, report):
    originals, installation = p09.install(cur)
    report['predecessor_installation'] = installation
    before = p09.functions(cur)
    internal = cur.execute("select pg_get_functiondef('erp.require_internal()'::regprocedure)").fetchone()[0]
    originals['erp.require_owner_admin()'] = cur.execute("select pg_get_functiondef('erp.require_owner_admin()'::regprocedure)").fetchone()[0]
    f03 = predecessor.f03
    f03.note_report.capture(cur, originals)
    sql = '\n'.join((f03.extension(), predecessor.planning.extension(), predecessor.baseline.extension(),
        predecessor.supply.extension(), predecessor.schedule.extension(),
        predecessor.bundle.predecessor.extension(), predecessor.bundle.extension()))
    cur.execute(sql, prepare=False)
    after = p09.functions(cur)
    path = cur.execute('show search_path').fetchone()[0]
    cur.execute("select set_config('search_path','',true)")
    grants = {}
    for principal, signatures in predecessor.bundle.GRANTS.items():
        for sig in signatures:
            key = str(cur.execute('select %s::regprocedure::text',(sig,)).fetchone()[0])
            grants.setdefault(key,set()).add((principal,'EXECUTE',False))
    cur.execute("select set_config('search_path',%s,true)",(path,))
    expected = f03.note_report.expected_definitions(internal,originals,f03.patched_internal,f03.settlement.patched_owner)
    for sig, old in before.items():
        new = after[sig]
        definition = hashlib.md5(expected[sig].encode()).hexdigest() if sig in expected else old['definition']
        assert new['definition'] == definition and new['owner'] == old['owner'], ('OW04_PREDECESSOR_UNDECLARED_CHANGE',sig)
        assert {tuple(x) for x in new['acl'] or []} == {tuple(x) for x in old['acl'] or []} | grants.get(sig,set()), ('OW04_PREDECESSOR_ACL_CHANGE',sig)
    for sig, definition in expected.items():
        assert cur.execute('select pg_get_functiondef(%s::regprocedure)',(sig,)).fetchone()[0] == definition
    p09.INSTALLED_FUNCTIONS = after
    report['predecessor_raw_verification'] = predecessor.verify(cur)
    return originals


def run():
    global STATE
    report = dict(label='CP7_OW04_INITIAL',status='INCOMPLETE',expected_case_count=32,
        required_case_ids=list(IDS),production_go=False,independent_acceptance=False,
        feature_complete=False,browser_proven=False,races_proven=False,
        scope='EXPLICIT_INITIAL_NATIVE_SETTLEMENT_AND_UNCHANGED_P11_RETURN_E01_REGRESSIONS',
        source_sha256=credit.source_files())
    installed = False
    originals = {}
    try:
        with psycopg.connect(package.boundary.ADMIN) as conn, conn.cursor() as cur:
            p09.wip.policy.bf.verified(cur)
            restore_before = restore_state.capture(cur,package.boundary.snapshot,predecessor.public_state,p09.functions)
            conn.rollback()
            originals = install_predecessor(cur, report)
            STATE = credit.install(cur,predecessor.verify,p09.functions)
            # The exact target/reader/private/native proof precedes updating
            # the original harness's complete installed-function inventory.
            p09.INSTALLED_FUNCTIONS = p09.functions(cur)
            report['integrated_installation'] = {key:STATE[key] for key in
                ('approval','context_proof','refund_proof','source_sha256')}
            report['integrated_source_verification'] = verify(cur)
            conn.commit()
            installed = True
            conn.rollback()
        report['advisors_with_cp7'] = advisors(package.boundary.PG)
        with exact_public_catalog(native,retain_raw=True) as catalog:
            report['native'] = native.strict_group('CP7_OW04_INITIAL',cases,verify)
        report['native_public_catalog_comparison'] = catalog
    except Exception as error:
        report.update(error=str(error),traceback=traceback.format_exc())
    finally:
        if installed:
            try:
                with psycopg.connect(package.boundary.ADMIN) as conn,conn.cursor() as cur:
                    credit.uninstall(cur,STATE)
                    for definition in originals.values(): cur.execute(definition,prepare=False)
                    for role in predecessor.bundle.ROLES:
                        cur.execute('drop owned by '+role+' cascade;drop role '+role,prepare=False)
                    conn.commit()
                    report['cp6_restored'] = restore_state.prove(cur,restore_before,
                        package.boundary.snapshot,predecessor.public_state,p09.functions,report)
                    conn.rollback()
                    p09.wip.policy.bf.verified(cur)
                    conn.rollback()
                report['advisor_delta'] = advisor_delta(advisors(package.boundary.PG),report['advisors_with_cp7'])
                report['advisor_gate'] = report['advisor_delta']['status'] == 'NO_NEW_FINDINGS'
            except Exception as error:
                report.update(restore_error=str(error),restore_traceback=traceback.format_exc(),cp6_restored=False,advisor_gate=False)
        group = report.get('native',{})
        report['observed_case_count'] = sum(group.get('counts',{}).values())
        report['required_case_ids_pass'] = set(group.get('cases',{})) == set(IDS)
        if not report.get('error') and report.get('cp6_restored') and report.get('advisor_gate') \
                and group.get('counts') == {'PASS':32} and report['required_case_ids_pass'] \
                and group.get('database_remaining',0) == 0:
            report['status'] = 'PASS'
        OUT.parent.mkdir(parents=True,exist_ok=True)
        OUT.write_text(json.dumps(report,indent=2,default=str)+'\n')
        print(json.dumps({key:report.get(key) for key in ('label','status','expected_case_count',
            'observed_case_count','cp6_restored','advisor_gate','error','traceback','restore_error')},default=str),flush=True)
    return dict(status=report['status'],production_go=False,independent_acceptance=False,feature_complete=False)


if __name__ == '__main__':
    package._writer_runtime = lambda browser_mode=False:run()
    package.run('install')
