# Executable Native assembler proposal

`derive_plan.py` is a pure builder plus read-only verification. It never opens a
connection, executes installation SQL, commits, changes `helper_sources`, or
installs a public API. The caller owns one isolated F05 installation transaction.

```python
# First: the caller installs and verifies the exact F05 predecessor with the
# real probe.verify and p09.functions. ONLY THEN approve its baseline captures.
# trusted_approved_manifest must come from that verified predecessor phase.
captures = builder.capture_verified(cur, trusted_approved_manifest, repo)
plan = builder.derive_plan(captures, trusted_approved_manifest)
# Compose the concrete source/kernel/ledger/context/coordinator/refund SQL in
# the owning transaction. No absent callbacks or authority stubs are supplied.
sql = builder.render_install_sql(plan, trusted_approved_manifest)
cur.execute(sql)  # actual CI composer, not this builder
builder.verify_installed(cur, plan, trusted_approved_manifest)
receipt = builder.verify_legacy_composed(
    cur, plan, trusted_approved_manifest, repo)
```

The closed approval JSON has these exact fields:

```json
{
  "contract_version": "ow04.native-approved.v1",
  "baseline_verification": {
    "phase": "VERIFIED_PREDECESSOR",
    "verifiers": ["probe.verify", "p09.functions"],
    "receipt_sha256": "64 lowercase hex characters from that real receipt"
  },
  "functions": [
    {
      "identity": "one exact identity from builder.REQUIRED",
      "definition_sha256": "SHA256 of exact installed pg_get_functiondef",
      "body_sha256": "SHA256 of exact installed pg_proc.prosrc",
      "owner": "postgres",
      "acl": ["exact sorted aclitem text; null stays null"],
      "security_definer": true,
      "volatility": "v",
      "config": ["exact ordered proconfig; null stays null"]
    }
  ],
  "helper_sources": {
    "cp7_note": [
      {"native_signature": "exact Native signature", "native_definition_sha256": "immutable predecessor SHA256"}
    ],
    "cp7_sales_return_correction": [
      {"native_signature": "exact Native signature", "native_definition_sha256": "immutable predecessor SHA256"}
    ]
  },
  "legacy_verifier_sources": {
    "scripts/cp7_note_correction_verify.py": "exact source SHA256",
    "scripts/cp7_sales_return_correction_bundle.py": "exact source SHA256"
  },
  "absent_targets": ["cp7_credit._post_journal_bound(text,uuid,date,text,jsonb)"]
}
```

There must be exactly 19 function approvals. Helper rows are sorted by Native
signature and contain exactly six note plus four return-correction members.
Do not build this approval from a candidate that did not pass the raw baseline
verifiers. The builder intentionally has no approve-current-candidate API.

Outputs contain exact old/new definitions, bodies, all captured metadata and
SHA256s: seven Native replacements, ten private helper entries, one new bound
poster and the generic journal inverse. Both physical FG primitives are exact
unchanged entries. Actual private sale/return/payment inverses receive the same
source enter/complete hooks as their Native parents; both private generic and
internal journal paths receive protected-credit-journal guards. Existing private
context, Native authority, HPP, stock and date behavior remains in the bodies.

The new bound poster is copied from the approved Native poster; the original
poster stays exact. Its ACL is reduced to postgres only, including removal of
nonstandard default-granted roles. Generated SQL checks every definition/body,
owner, ACL, definer, volatility and configuration before/after DDL, and both
immutable helper baseline tables. `verify_installed` repeats the actual checks.
No commit is emitted.

Legacy composition first independently verifies all 19 actual targets and the
unchanged original poster/baselines. It retains the direct old-verifier failure.
The original pinned verifiers then run through a closed cursor view that serves
only the exact `select pg_get_functiondef(%s::regprocedure)` + one exact helper
signature from the approved predecessor. Every other query reads the actual
database. Source collectors and Native operations never receive this view.
The receipt says `COMPOSED_LEGACY_VERIFICATION_NOT_RAW_LEGACY_PASS`; no verifier
assertion is removed and no baseline table is rewritten.

Current coordinator source IDs agree with these hooks: actual return UUID for
`SALES_RETURN`; actual payment/return/sale UUID for source mutations; actual
component part UUID for recognition. Refund separately uses the protected
coordinator-minted operation UUID as `CP7_CUSTOMER_CREDIT_REFUND.source_id` and
the independent refund poster transform in `refund/02_native_refund_transform.py`.
That auxiliary refund copy is not silently added to this fixed 19-entry census.
Keep `cp7_credit`, `ow04_pure_kernel`, `ow04_source_proposal`, and
`ow04_ordinal_wrapper` names consistent when composing the SQL files.

Checks:

```sh
PYTHONDONTWRITEBYTECODE=1 python check_derive_plan.py /path/to/erp-d1714
node check_generated_guards.mjs /path/to/erp-d1714
```

The first checks exercise actual release financial bodies, declared private
copies, and synthetic metadata. The two physical FG primitive fixture bodies are
explicitly synthetic preservation controls. The second checks execute actual
generated guard/ACL SQL only against synthetic PGlite functions. Neither proves
an installed Native predecessor, full legacy composition, authority, posting,
or feature completion. Real isolated CI must capture, derive, install and verify
the composed stack; all concrete SQL dependencies remain mandatory.
