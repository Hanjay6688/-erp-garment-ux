import { defineConfig } from '/workspace/scratch/9442228ed2dc/erp-d1714/node_modules/vitest/dist/config.js'
export default defineConfig({ root: '/workspace/scratch/9442228ed2dc/ow04-proposals/ui', cacheDir: '/workspace/scratch/9442228ed2dc/ow04-proposals/ui/cache', test: { include: ['salesReturnSettlementProposal.test.ts'], cache: false, fileParallelism: false, maxWorkers: 1 } })
