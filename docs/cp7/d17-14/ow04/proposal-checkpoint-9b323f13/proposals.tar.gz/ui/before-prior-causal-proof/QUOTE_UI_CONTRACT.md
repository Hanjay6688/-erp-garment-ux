# OW04 UI and wire proposal — not installed

Source pin: b7fc541ca2b0221865ed7982155e844e1a9bed80; paid-return product
source remains 754f387a04a6b81a8b750db24184444a41bec9df. The executable closed
shape is `salesReturnSettlementProposal.ts`; `EXPECTED.json` predates its tests.
`EXPECTED_COUNTER_REVIEW.json` freezes the subsequent causal-floor counter and
clarifies receipt checking before its two red-first regression cases.
`EXPECTED_NUMERIC_COUNTER.json` precedes the later large-value regressions.
`EXPECTED_DATE_PAIR_COUNTER.json` precedes the date-pair and explicit WIB
physical-date regressions; their first malformed-wire failures are retained.
This is a design and local synthetic parser/state evidence, not a working ERP
screen, public RPC, financial source collector, posting or Native proof.

D17-14 already authorizes per-return credit/refund, original history and clear
dependent-document correction steps. No new owner decision is required for
these modes. No expiry, global liability-account default, initial partial split,
automatic second refund, or amount derived in the browser is introduced here.

## Proposed calls and exact boundaries

Names below are proposals, not existing endpoints.

1. `public.erp_cp7_get_sales_return_settlement_quote_v1(p_query jsonb)` accepts
   `QuoteInput`. `expected_version` is the existing positive **string** version;
   `review_token` remains the existing 32-character source review token. Every
   return supplies its complete normalized draft, including zero money returns.
   Amounts are canonical cent strings; quantities remain positive integer
   strings. `settlement` is the incomplete draft choice with all fields present,
   initially null. The RPC may calculate a plan before mode/account selection.
   The existing Native bound applies to each user-entered return line amount.
   Server totals, current K, signed recognition atoms and capacity use canonical
   arbitrary-length cent strings and exact BigInt wire-consistency checks. A
   component is a financial fact, distinct from bounded Native journal storage
   parts; the proposal's ledger may split it deterministically without a new UI
   cap or rounding through Number.
2. The same read RPC can accept `AccountOptionsQuery`, distinguished by
   `kind: ACCOUNT_OPTIONS`, for 25-row credit/cash account search. It returns no
   commit token. This branch is optional API organization; a separate typed
   reader is equivalent if the writer prefers. The browser never selects the
   first option. Liability eligibility is the approved per-document active,
   postable LIABILITY/CREDIT predicate, extended with reconciled Native lineage.
   Existing BB/unexplained balances, cash/mapping/prepayment use cannot be
   silently adopted. Cash choices must satisfy actual cash/COA eligibility.
3. `public.erp_cp7_settle_sales_return_v1(p_payload jsonb,p_request uuid,
   p_expected text)` accepts `CommitDocument`. It receives the **flat existing
   return fields**, `settlement`, and `quote_sha256`. CREDIT contains only mode
   and selected liability account. REFUND additionally contains the independently
   entered physical cash time, selected cash account and optional reference.
   Initial refund amount is the full server K; no amount, economic/book pair,
   manifest, source journal ID, arbitrary line or account map is accepted from
   the client. Empty plans send `settlement: null`.
4. Client action `RETURN_SETTLEMENT` uses the existing SALES recovery domain and
   exact existing envelope `{document,expected_version}`. Add that action to the
   **frontend** SALES allowlist and route it like RETURN_CORRECT. Do not add it
   blindly to every legacy SQL action/context enum. The owning typed wrapper may
   call the existing RETURN command with a stripped payload and the same UUID
   under its own atomic request/context. That nested call is not sufficient by
   itself: the source guards, poster, ledger facts and complete closure must all
   be admitted together. Legacy public RETURN with a missing required choice
   continues to refuse; retain P11_RETURN_PAID_REFUSAL.

## Server facts versus projections

`QUOTE` is allowed only for a complete proved source family. It carries distinct
immutable-source and current-state hashes: immutable facts do not change their
identity when a payment/return is reversed, while status, real inverse/restatement
links and active consumers affect the current-state manifest. Root/leaf return
identity and ordinal must be proved; the old note replay's discarded local
return-lineage JSON is not evidence. Unsupported, ambiguous, incomplete,
unreconciled or oversized families return closed `UNAVAILABLE` with **no K,
components or commit token**. They never become an empty plan or NO_JOURNAL.

The server seals draft/choice, actual existing source UUIDs/hashes, actual AR
provenance, proposed amount/date/account semantics, current permissions,
period/settings and dependency facts in the full `quote_sha256`. The browser
checks exact input echo plus source version/review and full SHA syntax. Its local
`inputIdentity` only fences old reads; it is not a cryptographic JSON protocol or
an authority token. A quote does not reserve a return family ordinal or hold
database locks while the operator reads it.

New Native return/journal UUIDs do not exist at read-only quote time. Components
therefore use semantic SHA keys/support hashes, not fictional journal UUIDs.
After locked recollection and posting, the owning server checks a proved mapping
from projected semantics to the actual Native return/journal/line/date/account
facts. The receipt separately seals `actual_manifest_sha256` and
`projection_actual_proof_sha256`; neither must equal the pre-post projection
hash. Any failure rolls back stock, HPP, return, credit, refund, journals and
request result together.

`has_recognition_effect` means the complete signed component vector is nonempty.
It is independent of current K. `+200@19/19 -200@20/20` is nonempty with K0:
explicit mode/account and immutable recognition history are required, while
safe cash refund is zero. Negative components are labelled recognition
adjustments, not cash refunds. Only a genuinely empty vector can use the
ordinary no-choice path; its physical return family/ordinal is still registered.

The return's own economic/book floor is also checked when the credit vector is
empty. Every READY return requires an independently proved causal floor from
actual dated source-family journals; absence of that proof prevents readiness.
A genuine R0/HPP0 return has `NO_JOURNAL`, null planned journal book date and no
monetary kernel event. The real document/items/FG dependency proof is separate.
The causal floor is disclosed independently; no book-date surrogate, zero
journal or zero refund is invented.

Each component's book date must be on/after that component's own economic date.
The new return's planned book date must meet both its own economic date and its
proved causal floor; a refund's book date must meet its own economic date. The
new-return economic date matches the explicitly entered physical instant in
`Asia/Jakarta`, and a refund uses its independently entered physical instant in
the same business timezone. The parser checks those wire relationships using
an explicit IANA timezone, never the device timezone or the UTC calendar day.
It does not move recognition components to the new return date: historical
19/19 components remain valid when the new return itself occurs on day20.
Correction/inverse/replay dates require their separate owning projection
contracts and are not cast to this new-return input.

## Form mapping

Keep existing `SalesReturnPanel` allocation, grade, receiver, quantity, amount and
physical time controls. Its physical time already starts blank. Remove its
instruction to reverse the original payment merely to avoid overpayment.

| UI control/state | Proposed behavior |
| --- | --- |
| New form | Mode, liability account, cash account and refund time all blank. Preserve explicit user choices across ordinary editing; retire their eligibility proof and quote. |
| Complete draft | `Periksa penyelesaian retur` requests a quote. Incomplete inputs cannot quote or submit. All complete returns quote, including unpaid/zero-money returns. |
| Nonempty vector | Select `Penyelesaian nilai retur`: blank / `Simpan sebagai saldo kredit` / `Kembalikan uang`. Choose `Akun saldo kredit pelanggan` explicitly. |
| Current K0/nonempty | Show `Ada pengakuan kredit pada tanggal sebelumnya; hak kredit saat ini Rp0`. CREDIT/account can be reviewed; REFUND cannot create a zero cash event. |
| REFUND | `Rekening pengembalian uang` and independent `Waktu pengembalian uang WIB` start blank. Display server K as read-only `Nominal pengembalian uang`. Re-quote after any choice/time edit. |
| Signed components | Table `Tanggal pengakuan kredit retur`: economic date, book date, exact signed amount. Positive `Pengakuan kredit`; negative `Penyesuaian pengakuan kredit`. No editable book dates or journal lines. |
| Empty vector | Explain that the return reduces AR without creating customer credit. Settlement stays null. If an earlier draft had a now-unneeded choice, clear only those unused fields and re-quote the normalized empty choice; never reuse the previous token. |
| Totals | Separately show original payments P, credit used U, net recognition I, effective settlement E and AR. Refund consumption reduces credit liability, not I again. |
| CHOICE_REQUIRED | Show specific missing mode/account/time issue; no final commit token. |
| BLOCKED | Show current permission, account, capacity, period or dependency reason with actual source links. No final commit token. |
| UNAVAILABLE | Explain that the source family cannot currently be proved; no numeric zero or ordinary-return fallback. |
| READY | Require the existing `Retur pelanggan sudah diperiksa` checkbox after the final quote. The label includes chosen settlement, accounts and dates. Submit only while parent source/read fence, local generation and authority scope still match. |
| Any input/source/authority change | Retire quote and review synchronously; disable submit, hide retired financial facts. A late older quote cannot restore them. Rechecked account snapshots may retain the typed ID but cannot retain old eligibility. |
| 401/403 or refused source read | Retire row/quote/account/analysis facts through `onInvalid`, clear read proof; do not leave a stale quote beside an authorization error. |
| Lost or malformed success reply | Keep the original global SALES envelope and UUID; no edit, re-quote or new request can replace that uncertain intent. |

The actual hook already compares actor/session, source read ticket and global
recovery signature, takes the Web Lock, persists the exact envelope before
sending, and retains uncertain/replay refusals. Reuse it. The proposal's small
state functions are selectors/fences, not a replacement recovery engine.

After reload, receipt validation uses only the frozen envelope's request/action,
sale and full quote digest. The server digest binds projection semantics; the
receipt's projection, actual-manifest and mapping-proof fields still require
full SHA syntax. No in-memory quote or extra envelope metadata is required.
Retire all forms on successful commit before clearing the envelope; a failed
authoritative reload keeps writers locked. A replay permission refusal does
not prove the original request never committed.

## Native customer credit workspace and real navigation

Add a Native workspace on the existing **sales-returns** page, scoped to the
selected invoice/customer, with a paged customer-credit list and per-credit
detail/history. It may be a new `NativeSalesCreditsPanel` component; no such
component exists today. It is not `InitialImportContinuations.CustomerCreditsPanel`:
that panel owns imported BB credits and APPLY_OPENING_AR, and must not receive a
fabricated migration batch/old return to represent new Native credits.

Each credit shows its source invoice/return, actual family ordinal, net recognized
I, applied amount, refunded amount, remaining liability, selected liability
account and dated signed history. Current remaining is distinct from capacity
at a selected physical event time. A new positive restatement needs a fresh
recognition/account review; original REFUND intent never authorizes another
automatic cash refund.

Later partial apply/refund is a separate operator action, with positive amount
and physical time blank initially. Apply selects a posted/open target invoice
of the **same customer**, and binds both source and target current version/review
plus full credit/dependency/action-quote digests. Refund selects a real cash
account and explicit physical cash time. A server action quote validates every
future joint economic/book prefix, historical uses/inverses and final dated
cash balances; current remaining alone cannot approve it. Reversal selects the
actual active event and reverses its linked source facts atomically, preserving
both dates/history. Proposed consumer action payloads, pending API choice:

```ts
CREDIT_APPLY: { credit_id, credit_review_sha256, target_sale_id,
  target_expected_version, target_review_token, amount, physical_at,
  action_quote_sha256, dependency_sha256, change_reason }
CREDIT_REFUND: { credit_id, credit_review_sha256, amount, cash_account_id,
  physical_at, reference, action_quote_sha256, dependency_sha256, change_reason }
CREDIT_EVENT_REVERSE: { credit_id, event_id, credit_review_sha256,
  action_quote_sha256, dependency_sha256, change_reason }
```

These are not existing commands and this draft does not claim their reader or
writer is implemented. They need the same SALES envelope/fresh source ownership
and typed server admission. No generic journal reversal or unrelated cash/misc
context may stand in for the owning consumer inverse.

| Link | Real route and required integration |
| --- | --- |
| Origin invoice / target invoice | Existing `TransactionSourceLink sourceType="SALE" sourceId=<sale UUID>` resolves to **sales-invoice**. |
| Origin return / return edit | Existing `SALES_RETURN` link resolves to **sales-returns**, `SALES_RETURN` focus. Existing buttons are `Lihat perubahan retur`, `Edit retur`, `Koreksi retur`. |
| Source payment / correction | Existing `SALES_PAYMENT` link resolves to **sales-payments**. Existing buttons are `Lihat perubahan pembayaran`, `Edit pembayaran`, `Koreksi pembayaran`. |
| Native credit | Propose source type/focus `SALES_CREDIT` on **sales-returns**, document.id=source sale, focus `{kind,id:<credit>,parent_id:<root return>,page_offset}`. |
| Apply/refund/inverse event | Propose source type/focus `SALES_CREDIT_EVENT` on **sales-returns**, focus `{kind,id:<event>,parent_id:<credit>,page_offset}`. The Native workspace loads that exact event page and highlights the event. |

The last two links are explicit resolver/parser/component additions, not working
capabilities in the current source. Update the SQL source resolver, the strict
`transactionSource.ts` domain/focus mappings and `ConnectedSalesPage` focus opener
together. A UUID must never become a guessed URL or an unhandled button.

## Correction/dependency UI that must ship with the feature

Show a server-authored complete, current dependency graph with a full SHA token,
document IDs/numbers, owning source type, active/reversed state and actionable
resolver links. Pagination may show a subset but must not call it the whole
graph. The server guard owns eligibility. Required step order:

1. Undo active downstream credit applications/refunds, including applications
   incoming to a target invoice. Open the exact Native credit event; show the
   target invoice and refund cash document when applicable.
2. Show dependent sibling/later return families and transitive consumers. A
   prior return can support a later family's recognition even when its own
   current credit is zero. Retained reversed events remain historical evidence,
   not active blockers. Stock already consumed can independently block return
   reversal and must link to the actual consuming document.
3. Reverse the source credit/recognition and its owning return atomically through
   a typed return inverse/correction writer. Then correct/reverse source funding
   and the invoice as allowed by the remaining graph. Do not tell the operator
   to start with the original payment.

Return replacement and note/payment correction are also source-changing writers:
they need a fresh projection of the proposed full family result, preserve the
root ordinal, show signed restatements and require explicit new recognition
choices when needed. The new-return quote type in this folder does **not** claim
to implement that correction projection API. Add a discriminated correction
query bound to actual return/root/token/replacement before enabling that path;
never cast an old return correction payload to this new-return query.

## Files and companion contracts

| Current owner | Required change |
| --- | --- |
| `src/SalesReturnPanel.tsx` | Quote sequence/fences, blank explicit choices, dated summary, truthful status and own pending action. Extend typed onSave action. |
| `src/ConnectedSalesPage.tsx` | Separate typed RPC dispatch/outcome, fresh receipt retirement, Native credit panel/focus and source read refresh. |
| `src/productionRecovery.ts:69` | Add frontend SALES actions deliberately; keep old envelopes readable and preserve uncertain request behavior. |
| `src/salesReadContract.ts`, `sales/read.sql` | Version the closed financial response and keep P/U/I/E distinct. Existing parser assumes AR=net-paid_total; silently repurposing `paid_total` would mislabel payments. |
| `src/ConnectedCustomerHistoryPage.tsx`, `customerHistoryContract.ts`, `sales/customer-history.sql` | Version closed history, add issued/recognition-adjustment/application/refund/inverse events and links. Display AR and unused liability separately; avoid treating a negative AR number as the complete credit ledger. |
| `src/SalesInvoiceDependencies.tsx`, `SalesChainReversalPanel.tsx`, `salesChainContract.ts` | Replace old payment→return→invoice list with proved dependency order, both invoice sides and named consumer links. |
| `src/SalesReturnCorrectionPanel.tsx`, `SalesPaymentCorrectionPanel.tsx`, note correction | Quote/review complete signed family changes; preserve ordinal/history; never bypass consumers by opening a generic correction context. |
| `sales/read.sql:21`, `return-correction.sql:130`, `chain-reversal.sql:61` | Extend owning review/return/chain tokens with immutable family/source support, current consumers/inverses and current protected facts. |
| Transaction source SQL + `src/transactionSource.ts` | Real new credit/event resolution with current permissions, exact ownership and page offset. |

Source-bound authority remains a server obligation after every blocking request,
source, account/master, period and CASH wait, before cached replay and before
returning the receipt. Refund needs actual cash-out authority: current
OWNER/ADMIN plus finance.cash.view/finance.journal.view as admitted by the real
cash writer; return AR permissions alone do not establish it. No new permission
name is invented by this proposal's capability booleans.

Before product integration require the existing paid-return omitted-choice
negative, explicit CREDIT/REFUND positives across OPEN/CLOSED/REOPENED, K0 signed
history and true NO_JOURNAL cases, source ambiguity refusals, partial consumer
and undo histories, permission/replay races, lost replies/two tabs, and both
financial date bases. The local wire tests in this folder prove none of those
Native effects. OW04 remains unfinished.
