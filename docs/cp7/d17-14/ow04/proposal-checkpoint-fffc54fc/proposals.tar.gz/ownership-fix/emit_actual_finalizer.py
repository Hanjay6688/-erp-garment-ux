import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1])/'scripts'))
from cp7_customer_credit.integration import owning_bundle as b
class Cursor:
 def __init__(self):self.statements=[];self.rows=[]
 def execute(self,q,args=None):
  if q.startswith("select n.nspname||'.'||c.relname,c.relrowsecurity"):
   self.rows=[('cp7_credit.return_requests',True),('cp7_credit.return_command_scope',True),('cp7_credit.test_fact',True)]
  elif q.startswith('select exists(select 1 from pg_policy'):self.rows=[(False,)]
  elif q.startswith('select p.oid::regprocedure::text'):
   self.rows=[(x,)for x in [*b.PRIVATE_FUNCTION_OWNERS,'cp7_credit.current_leaf_assignment(uuid)',
    'ow04_source_proposal.family_read_v1(uuid)','ow04_pure_kernel.probe()','ow04_ordinal_wrapper.probe()']]
  else:self.statements.append(dict(sql=q,args=args));self.rows=[]
  return self
 def fetchall(self):return self.rows
 def fetchone(self):return self.rows[0]
c=Cursor();b._finalize_private_owners(c)
print(json.dumps(c.statements))
