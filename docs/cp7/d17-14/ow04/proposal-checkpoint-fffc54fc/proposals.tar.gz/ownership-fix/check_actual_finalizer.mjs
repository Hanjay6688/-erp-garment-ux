// Actual writer finalizer SQL, isolated capability fixtures, no Native proof.
import fs from 'node:fs/promises';
import {execFileSync}from'node:child_process';
import assert from'node:assert/strict';
import{PGlite}from'/workspace/scratch/9442228ed2dc/sql-dev/node_modules/@electric-sql/pglite/dist/index.js';
const repo='/workspace/scratch/9442228ed2dc/erp-d1714';
const here='/workspace/scratch/9442228ed2dc/ow04-proposals/ownership-fix';
const sql=JSON.parse(execFileSync('python',['-B',here+'/emit_actual_finalizer.py',repo],{encoding:'utf8'}));
const db=new PGlite();const cases=[];
const pass=name=>cases.push({name,status:'PASS'});
const refuse=async(name,q)=>{await db.exec('savepoint refusal');let e;try{await db.exec(q)}catch(x){e=x}
 await db.exec('rollback to savepoint refusal;release savepoint refusal');assert(e,name);pass(name);};
try{
await db.exec(`create role ow04_test_installer superuser;create role cp7_credit_write nologin noinherit;
create role cp7_plan_writer nologin noinherit bypassrls;create role authenticated;
set session authorization ow04_test_installer;create role ow04_business nologin noinherit nosuperuser bypassrls;
create schema cp7_credit authorization ow04_business;create schema ow04_source_proposal authorization ow04_business;
create schema ow04_pure_kernel authorization ow04_test_installer;create schema ow04_ordinal_wrapper authorization ow04_test_installer;
create domain cp7_credit.cent_amount as numeric check(value*100=trunc(value*100));
create table cp7_credit.return_requests(payload jsonb);alter table cp7_credit.return_requests owner to cp7_credit_write;
create table cp7_credit.return_command_scope(stage text,source_lock_sha256 text,projection_sha256 text,
 credit_account_snapshot jsonb,cash_account_snapshot jsonb,return_id uuid,family_id uuid,family_ordinal bigint,
 actual_manifest_sha256 text,payload jsonb);alter table cp7_credit.return_command_scope owner to cp7_credit_write;
create table cp7_credit.test_fact(amount numeric);alter table cp7_credit.test_fact enable row level security;
alter table cp7_credit.return_requests enable row level security;alter table cp7_credit.return_command_scope enable row level security;
insert into cp7_credit.return_requests values('{}');insert into cp7_credit.return_command_scope(stage,payload)values('CLAIMED','{}');
create function cp7_credit.current_leaf_assignment(uuid)returns integer language sql stable as $$select 1$$;
create function ow04_source_proposal.family_read_v1(uuid)returns integer language sql stable as $$select 1$$;
create function ow04_pure_kernel.probe()returns integer language sql immutable as $$select 1$$;
create function ow04_ordinal_wrapper.probe()returns integer language sql immutable as $$select 1$$;
create function cp7_credit.return_settlement_command(jsonb,uuid,text)returns jsonb language sql as $$select '{}'::jsonb$$;
create function cp7_credit._has_ambient_plan_apply_scope()returns boolean language sql stable security definer as $$select false$$;
alter function cp7_credit.return_settlement_command(jsonb,uuid,text)owner to cp7_credit_write;
alter function cp7_credit._has_ambient_plan_apply_scope()owner to cp7_plan_writer;
revoke all on all functions in schema cp7_credit,ow04_source_proposal,ow04_pure_kernel,ow04_ordinal_wrapper from public;
commit;begin;set local role ow04_business;`);
await refuse('FIRST_RED_REAL_CURRENT_LEAF_PERMISSION',"select cp7_credit.current_leaf_assignment(null)");
await refuse('FIRST_RED_OUTER_TABLE_SELECT',"select *from cp7_credit.return_requests");
await db.exec('rollback');
for(const x of sql)await db.query(x.sql.replace(/\bpostgres\b/g,'ow04_business'),x.args??[]);
await db.exec('begin;set local role ow04_business');
for(const q of ['select cp7_credit.current_leaf_assignment(null)','select ow04_source_proposal.family_read_v1(null)',
 'select ow04_pure_kernel.probe()','select ow04_ordinal_wrapper.probe()',
 'select *from cp7_credit.return_requests','select *from cp7_credit.return_command_scope',
 "update cp7_credit.return_command_scope set stage='LOCKED',family_ordinal=1"]){await db.exec(q);pass('POSTGRES_ALLOWED_'+q);}
await refuse('POSTGRES_CANNOT_EDIT_OUTER_PAYLOAD',"update cp7_credit.return_command_scope set payload='{}'");
await refuse('POSTGRES_CANNOT_INSERT_OUTER_REQUEST',"insert into cp7_credit.return_requests values('{}')");
await db.exec('rollback');
const ownerRows=(await db.query("select nspname,pg_get_userbyid(nspowner)owner from pg_namespace where nspname in('cp7_credit','ow04_source_proposal','ow04_pure_kernel','ow04_ordinal_wrapper')")).rows;
assert(ownerRows.every(x=>x.owner==='ow04_business'));pass('FOUR_PRIVATE_SCHEMA_OWNERS');
assert.equal((await db.query("select pg_get_userbyid(typowner)owner from pg_type where oid='cp7_credit.cent_amount'::regtype")).rows[0].owner,'ow04_business');pass('DOMAIN_OWNER');
for(const[n,owner]of[['return_settlement_command','cp7_credit_write'],['_has_ambient_plan_apply_scope','cp7_plan_writer']]){
 assert.equal((await db.query('select pg_get_userbyid(proowner)owner from pg_proc where proname=$1',[n])).rows[0].owner,owner);pass('PRESERVED_OWNER_'+n);}
assert.equal((await db.query("select count(*)::integer n from pg_policy where polname='ow04_deny_direct'and pg_get_expr(polqual,polrelid)='false'and pg_get_expr(polwithcheck,polrelid)='false'")).rows[0].n,3);pass('EXPLICIT_DEFAULT_DENIAL');
const result={classification:'ACTUAL_FINALIZER_SQL_ON_SYNTHETIC_PERMISSION_FIXTURES',status:'PASS',count:cases.length,cases,
 non_superuser_role:'ow04_business',role_name_substitution_only:'postgres is the immutable PGlite bootstrap superuser; emitted DDL targets renamed only for this fixture',native_executed:false,financial_results_proven:false};
await fs.writeFile(here+'/RESULT.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:'PASS',count:cases.length,native_executed:false}));
}catch(e){await fs.writeFile(here+'/FIRST_FAILURE.json',JSON.stringify({status:'FAIL',error:e.message,cases},null,2)+'\n');console.error(e.message);process.exitCode=1}
finally{await db.close()}
