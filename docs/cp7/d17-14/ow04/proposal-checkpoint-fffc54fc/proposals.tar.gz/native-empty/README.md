# Direct Native empty-return registration proposal

Concrete SQL is ready for root's bounded source review. It is outside the
product, retains installer barriers, and has not executed a Native posting or
proved a Native authority path. Frozen coordinator01–09 are unchanged.

01 adds a technical Native operation, truthful principal observation and pure
member/provenance checks. Shared family/member/materialization rows retain their
existing JSON column shape. Native rows use the actual nullable auth UID and
`request_id=NULL`; their protected operation and distinct assignment contract
own those rows. No human, CP7 request, client idempotency envelope or CP7 context
is fabricated. The real session/JWT values are observations, never alternate
posting authority. Native's original guards remain in the original writers.

02 seals a genuinely first-post DRAFT after Native's existing FG lock and the
complete source lock pass. It preserves the original raw-payment guard. A
currentK0 plan with nonzero signed dated components refuses. After the actual
Native journal or verified NO_JOURNAL branch, it appends the next real family
ordinal and creates only FAMILY/MEMBER materialization facts. No credit cohort,
plan, liability account, payment edit, refund or incoming application is added.
Both the historical target and the complete ordinal profile must be empty at
every joint economic/book cutoff. Unknown old return ordering refuses.

An actual HPP-only journal is retained as JOURNAL with its real pair. An actual
zero-refund/zero-HPP journal-free return retains a null journal and no invented
book event. The separate prior causal proof comes only from the actual SALE
ancestor, or its complete typed absence proof. The existing hash-pinned Native
bound copy receives one protected actual-SALES_RETURN branch: exact own return,
Native-generated lines, and book=max(lawful resolver, actual causal SALE floor).
It accepts no caller-selected book date or amount. All source locks precede
period SHARE; post-wait checks acquire no earlier-order source locks. Native's
period, balancing, cash trigger and daily-balance logic remain in that copy.

Direct Native source changes on an otherwise empty registered root use a
separate truthful technical scope, preserving the original Native inverse
lifecycle without requiring a CP7 envelope or nonnull human. Complete actual
after-facts must still have an empty joint profile. Retained credit, U, source
corrections, multi-cohort adjustments and other unsupported routes remain
explicit refusals. This does not implement any of those routes.

03 reproducibly derives04 from exact frozen helper files. Fourteen overlays
check installed prosrc, owner, volatility, security, UTC/search-path and private
EXEC metadata first. They add the technical branches, pure Native provenance
dispatch and context-free deferred closure, and disable the old unregistered
Native no-op. They alter no Native body, account policy or original guard.
Root must compose01/02/04 after the frozen feature helpers and the already
approved Native capture/transforms, within the same installation transaction.
The complete accepted ambient-context capability and exact bound Native poster
must exist; this directory supplies no successful substitute.

`EXPECTED.json` was saved before implementation/checks. `RESULT.json` records
22/22 isolated checks using actual proposed SQL, selected Native table DDL and
explicitly synthetic Native-shaped fact rows. The driver directly inserts
those synthetic source/registry facts to test the pure member, current-reader
and deferred-closure SQL. It does not call a successful Native writer or the
new sealing/posting callbacks, and creates no passing permission/context/poster
stub. Its Native-entry negative verifies the original permission capability is
actually absent. Therefore the22 checks do not prove first-post authority,
service admission, real FG/HPP posting, rollback, replay, inverse execution or
concurrent ordering. All Native expectations N01–N12 remain unexecuted here.

The exact overlay output is reproducible; duplicate capture and missing outer
block refusals pass in `STATIC_RESULT.json`. The existing PL/pgSQL alias checker
reported no clashes in01/02. Function DDL compiled in PGlite against the selected
real table definitions; no local Native database was started.

`FIRST_FAILURE.json` retains a fixture error: JavaScript null became SQL NULL
where the actual callback stores JSON null for JOURNAL financial_source_proof.
The driver now reproduces the actual SQL codec. The ensuing aborted-transaction
messages are cascades. `SECOND_FIXTURE_FK_FAILURE.json` retains the next fixture
error: deleting a referenced original journal was blocked by the existing FK
before the intended verifier ran. The repaired malformed-source control alters
the synthetic journal's source type and preserves the same required refusal.

Final integration remains blocked pending root's actual Native execution,
service/unprivileged authority, first/second registration, original inverse,
failure atomicity, replay and concurrency qualification. Nonzero fractional
HPP cases with no actual journal remain outside the existing exact zero-HPP
absence proof and fail closed. Historical order is never guessed. This proposal
does not change the remaining whole-OW04 limitations or default product
installer.
