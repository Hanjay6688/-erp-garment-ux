"""Pure source/SQL validator bridge for the isolated PGlite control only."""
import importlib.util
import json
from pathlib import Path
import sys

spec = importlib.util.spec_from_file_location('typed_context_proposal', Path(__file__).with_name('typed_context_inventory.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
repo = Path(sys.argv[1])
value = json.load(sys.stdin)
manifest = m.source_manifest(repo, m.DISPATCH)
try:
    if value['action'] == 'emit':
        result = dict(manifest=manifest, census_sql=m.CENSUS_SQL, plan_reader_sql=m.plan_reader_sql(),
            dispatch=m.DISPATCH, exclusions=m.NEW_SCHEMAS)
    elif value['action'] == 'validate':
        m.validate_census(value['rows'], manifest)
        result = dict(status='ACCEPT')
    elif value['action'] == 'render':
        rows = value['rows']
        m.validate_census(rows, manifest)
        receipt = dict(manifest=manifest, manifest_sha256=m.digest(m.canonical(manifest)),
            catalog=rows, catalog_sha256=m.digest(m.canonical(rows)))
        result = dict(guards=m.render_guards(receipt),receipt=receipt)
    else:
        raise ValueError('UNKNOWN_CONTROL_ACTION')
    print(json.dumps(result))
except ValueError as e:
    print(json.dumps(dict(status='REFUSE',error=str(e))))
