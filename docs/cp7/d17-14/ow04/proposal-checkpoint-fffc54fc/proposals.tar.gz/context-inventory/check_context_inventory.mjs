// Isolated typed census + actual generated refusal SQL. No Native or money.
import fs from'node:fs/promises';import path from'node:path';
import{fileURLToPath}from'node:url';import{execFileSync}from'node:child_process';
import{createHash}from'node:crypto';import assert from'node:assert/strict';
const dir=path.dirname(fileURLToPath(import.meta.url));
const workspace=path.resolve(dir,'../..'),repo=process.env.OW04_REPO??path.join(workspace,'erp-d1714');
const{PGlite}=await import(process.env.PGLITE_MODULE??path.join(workspace,'sql-dev/node_modules/@electric-sql/pglite/dist/index.js'));
const sha=s=>createHash('sha256').update(s).digest('hex');
const expectedText=await fs.readFile(path.join(dir,'EXPECTED.json'),'utf8'),expected=JSON.parse(expectedText);
const bridge=v=>JSON.parse(execFileSync(process.env.PYTHON??'python',['-B',path.join(dir,'control_bridge.py'),repo],{input:JSON.stringify(v),encoding:'utf8'}));
const source=bridge({action:'emit'});assert.equal(source.manifest.length,expected.source_count);
const db=new PGlite(),cases=[];const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const pass=(name,observed)=>cases.push({name,status:'PASS',...(observed===undefined?{}:{observed})});
const refusal=async(name,fn,code)=>{await db.exec('savepoint expected_refusal');let e;try{await fn();}catch(x){e=x;}await db.exec('rollback to savepoint expected_refusal;release savepoint expected_refusal');assert(e,name+': accepted');assert(e.message.includes(code),e.message);pass(name,code);};
let stage='SCAFFOLD';
try{
 await db.exec(`create role anon;create role authenticated;create role service_role;create role cp7_capture;
create role cp7_sales_read;create role cp7_sales_write nologin noinherit;create schema auth;
create function auth.uid()returns uuid language sql stable as $$select '00000000-0000-0000-0000-000000000100'::uuid$$;`);
 const owners=[...new Set(source.manifest.map(x=>x.owner))].filter(x=>!['postgres','cp7_sales_write'].includes(x));
 for(const owner of owners)await db.exec(`create role ${owner} nologin noinherit nosuperuser nocreatedb nocreaterole noreplication ${owner==='cp7_plan_writer'?'bypassrls':'nobypassrls'}`);
 for(const schema of new Set(source.manifest.map(x=>x.name.split('.')[0])))await db.exec(`create schema ${schema}${schema==='cp7_plan_native'?' authorization cp7_plan_writer':''}`);
 for(const spec of source.manifest){
  const parts=[];if(spec.backend)parts.push('backend_pid integer not null');
  parts.push(`${spec.transaction_column} ${spec.transaction_type_oid===5069?'xid8':'bigint'} not null`);
  if(spec.name==='cp7_sales.command_context')parts.push('actor uuid not null','action text not null','sale_id uuid');
  if(spec.name==='cp7_guard.compound_scope')parts.push('depth integer not null default 0');
  await db.exec(`create table ${spec.name}(${parts.join(',')});alter table ${spec.name} owner to ${spec.owner};${spec.rls?`alter table ${spec.name} enable row level security;`:''}`);
  if(spec.owner!=='postgres')await db.exec(`grant usage on schema ${spec.name.split('.')[0]} to ${spec.owner}`);
 }
 const censusSql=source.census_sql.replace('%s','$1');
 const census=async(excluded=[])=> (await db.query(censusSql,[excluded])).rows.map(x=>Object.values(x)[0]);
 const before=await census();assert.equal(bridge({action:'validate',rows:before}).status,'ACCEPT');pass('ALL30_ACTUAL_CATALOG_ROWS_ACCEPT');
 for(const[name,change,code]of[
  ['MISSING',r=>r.pop(),'OW04_CONTEXT_CENSUS_CHANGED'],
  ['DUPLICATE',r=>r.push(structuredClone(r[0])),'OW04_CONTEXT_CENSUS_CHANGED'],
  ['WRONG_TYPE',r=>r[0].columns.find(x=>x.name==='transaction_id'||x.name==='txid').type=25,'OW04_CONTEXT_CATALOG_SHAPE_CHANGED'],
  ['NULLABLE',r=>r[0].columns.find(x=>x.name==='transaction_id'||x.name==='txid').notnull=false,'OW04_CONTEXT_CATALOG_SHAPE_CHANGED'],
  ['WRONG_OWNER',r=>r[0].owner='authenticated','OW04_CONTEXT_CATALOG_METADATA_CHANGED'],
  ['RLS_CHANGED',r=>r[0].rls=!r[0].rls,'OW04_CONTEXT_CATALOG_METADATA_CHANGED'],
  ['ROW_VISIBILITY',r=>r.find(x=>x.name==='cp7_note.context').reader_row_security_active=true,'OW04_CONTEXT_READER_CANNOT_SEE_ALL_ROWS'],
  ['SELECT_MISSING',r=>r.find(x=>x.name==='cp7_note.context').reader_select=false,'OW04_CONTEXT_READER_CANNOT_SEE_ALL_ROWS'],
  ['CLIENT_GRANT',r=>r[0].outsider_rights.authenticated=true,'OW04_CONTEXT_OUTSIDER_PRIVILEGE'],
  ['PLAN_OWNER_BYPASS_MISSING',r=>r.find(x=>x.name==='cp7_plan_native.apply_own_drafts').owner_role.bypassrls=false,'OW04_PLAN_CONTEXT_OWNER_VISIBILITY_CHANGED']]){
  const rows=structuredClone(before);change(rows);const got=bridge({action:'validate',rows});assert.equal(got.status,'REFUSE');assert(got.error.startsWith(code));pass('CATALOG_'+name,got.error);
 }
 await db.exec('create schema independent_unknown;create table independent_unknown.private_scope(transaction_id bigint not null)');
 assert(bridge({action:'validate',rows:await census()}).error.startsWith('OW04_CONTEXT_CENSUS_CHANGED'));pass('UNKNOWN_ALL_NAMESPACE_REFUSED');
 await db.exec('drop schema independent_unknown cascade');
 const rendered=bridge({action:'render',rows:before});assert(rendered.guards);
 for(const schema of source.exclusions)await db.exec(`create schema ${schema}`);
 await db.exec(source.plan_reader_sql);
 await db.exec(rendered.guards.no_ambient+rendered.guards.only_own_return);
 assert.deepEqual(await census(source.exclusions),before);pass('EXACT4_NEW_SCHEMA_EXCLUSION_AND_BASELINE_UNCHANGED');
 await db.exec('create table cp7_credit.execution_context(transaction_id bigint not null)');
 assert(bridge({action:'validate',rows:await census()}).error.startsWith('OW04_CONTEXT_CENSUS_CHANGED'));
 assert.equal(bridge({action:'validate',rows:await census(source.exclusions)}).status,'ACCEPT');pass('NEW_SCHEMAS_NOT_SILENTLY_SKIPPED_BEFORE_EXACT_EXCLUSION');
 await db.query('select cp7_credit.assert_no_ambient_native_context()');pass('EMPTY_NO_AMBIENT_ACCEPT');
 await db.exec('begin');
 await refusal('EMPTY_ONLY_OWN_REFUSES',()=>db.query('select cp7_credit.assert_only_own_return_native_context($1)',[id(101)]),'CP7_CREDIT_ONLY_OWN_RETURN_CONTEXT_REQUIRED');
 await db.exec('rollback');
 for(const spec of source.manifest){
  stage='GUARD_'+spec.name;await db.exec('begin');
  const names=[],values=[];
  if(spec.backend){names.push('backend_pid');values.push('pg_backend_pid()');}
  names.push(spec.transaction_column);values.push(spec.transaction_type_oid===5069?'pg_current_xact_id()':'txid_current()');
  if(spec.name==='cp7_sales.command_context'){names.push('actor','action','sale_id');values.push(`'${id(100)}'::uuid`,`'RETURN'`,`'${id(101)}'::uuid`);}
  await db.exec(`insert into ${spec.name}(${names.join(',')})values(${values.join(',')})`);
  await refusal('NO_AMBIENT_'+spec.name,()=>db.query('select cp7_credit.assert_no_ambient_native_context()'),'CP7_CREDIT_AMBIENT_CONTEXT_REFUSED');
  if(spec.name==='cp7_sales.command_context'){
   await db.query('select cp7_credit.assert_only_own_return_native_context($1)',[id(101)]);pass('ONLY_EXACT_OWN_SALES_ACCEPT');
   await refusal('WRONG_OWN_SALE',()=>db.query('select cp7_credit.assert_only_own_return_native_context($1)',[id(102)]),'CP7_CREDIT_ONLY_OWN_RETURN_CONTEXT_REQUIRED');
  }else await refusal('ONLY_OWN_BLOCKS_'+spec.name,()=>db.query('select cp7_credit.assert_only_own_return_native_context($1)',[id(101)]),'CP7_CREDIT_ONLY_OWN_RETURN_CONTEXT_REQUIRED');
  await db.exec('rollback');
 }
 for(const[table,columns,values]of[
  ['cp7_note.context','backend_pid,transaction_id','pg_backend_pid()+100,txid_current()'],
  ['erp.invoice_recost_execution_context','transaction_id','txid_current()+100'],
  ['cp7_plan_native.apply_own_drafts','txid',"(pg_current_xact_id()::text::bigint+100)::text::xid8"]]){
  await db.exec('begin');await db.exec(`insert into ${table}(${columns})values(${values})`);await db.query('select cp7_credit.assert_no_ambient_native_context()');await db.exec('rollback');pass('OTHER_IDENTITY_IGNORED_'+table);
 }
 const proc=(await db.query("select pg_get_userbyid(proowner)owner,prosecdef,provolatile::text,proconfig,prosrc,prorettype::regtype::text as return_type,pronargs from pg_proc where oid='cp7_credit._has_ambient_plan_apply_scope()'::regprocedure")).rows[0];
 assert.equal(proc.owner,'cp7_plan_writer');assert.equal(proc.prosecdef,true);assert.equal(proc.provolatile,'s');assert.equal(proc.return_type,'boolean');assert.equal(proc.pronargs,0);assert.deepEqual(proc.proconfig,['search_path=""','TimeZone=UTC']);
 assert.equal(proc.prosrc,'select exists(select 1 from cp7_plan_native.apply_own_drafts where txid=pg_catalog.pg_current_xact_id());');
 assert.equal((await db.query("select has_schema_privilege('cp7_plan_writer','cp7_credit','USAGE,CREATE')v")).rows[0].v,false);pass('EXACT_PRIVATE_PLAN_READER_METADATA');
 for(const sig of['cp7_credit._has_ambient_plan_apply_scope()','cp7_credit.assert_no_ambient_native_context()','cp7_credit.assert_only_own_return_native_context(uuid)'])for(const role of['anon','authenticated','service_role','cp7_capture','cp7_sales_read','cp7_sales_write'])assert.equal((await db.query("select has_function_privilege($1,$2,'EXECUTE')v",[role,sig])).rows[0].v,false);pass('NO_APP_GUARD_OR_PLAN_READER_EXEC');
 const result={scope:expected.scope,status:'PASS',count:cases.length,cases,expected_sha256:sha(expectedText),
  helper_sha256:sha(await fs.readFile(path.join(dir,'typed_context_inventory.py'),'utf8')),
  driver_sha256:sha(await fs.readFile(fileURLToPath(import.meta.url),'utf8')),
  source_manifest:source.manifest,Native_executed:false,real_auth_or_Native_permission_proven:false,
  synthetic_auth_uid:true,synthetic_table_roles:true,limits:expected.limits};
 await fs.writeFile(path.join(dir,'RESULT.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({scope:result.scope,status:result.status,count:result.count,Native_executed:false}));
}catch(e){const result={scope:expected.scope,status:'FAIL',stage,message:e.message,cases,Native_executed:false};
 try{await fs.writeFile(path.join(dir,'FIRST_FAILURE.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});}catch(x){if(x.code!=='EEXIST')throw x;}
 console.error(JSON.stringify(result));process.exitCode=1;
}finally{await db.close();}
