-- Development family bundle. Install only in the isolated CP7 runner.
-- Public API wrappers are owned by a NOLOGIN principal with no business writes.
create role cp7_capture nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_private authorization cp7_capture;
revoke all on schema cp7_private from public,anon,authenticated,service_role;
grant usage on schema erp,auth,extensions to cp7_capture;
grant select on erp.products,erp.bf_sku_members_v1,erp.bf_sku_versions_v1,
 erp.bf_skus_v1,erp.production_orders,erp.cutting_groups,erp.cutting_group_size_slots,
 erp.cutting_group_rolls,erp.cutting_roll_yields,erp.fg_stock_movements,
 erp.sales_headers,erp.sales_items,erp.fg_lots,erp.hpp_versions to cp7_capture;
grant execute on function erp.get_my_access_v1(),erp.has_permission(text),
 erp.bd_lot_laundry_unknown_v1(uuid),erp.get_hpp_completeness(uuid) to cp7_capture;
grant execute on function auth.uid(),auth.jwt(),extensions.digest(bytea,text) to cp7_capture;

create table cp7_private.analysis_runs(
 id uuid primary key default gen_random_uuid(),
 actor uuid not null,
 request_id uuid not null,
 root_id uuid not null,
 financial_captured boolean not null,
 captured_at timestamptz not null,
 access_at_capture jsonb not null,
 payload jsonb not null check(payload->>'status'='COMPLETE'),
 dependencies jsonb not null,
 unique(actor,request_id)
);
alter table cp7_private.analysis_runs enable row level security;
revoke all on cp7_private.analysis_runs from public,anon,authenticated,service_role;
grant select,insert on cp7_private.analysis_runs to cp7_capture;

create function cp7_private.immutable_run() returns trigger
language plpgsql set search_path='' as $$
begin raise exception using errcode='55000',message='CP7_RUN_IMMUTABLE'; end $$;
create trigger cp7_immutable_run before update or delete on cp7_private.analysis_runs
for each row execute function cp7_private.immutable_run();

create function cp7_private.access_now() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb; k text;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then
  raise exception using errcode='42501',message='CP7_ACCESS_DENIED';
 end if;
 a:=erp.get_my_access_v1();
 if (a->>'allowed')::boolean is distinct from true then
  raise exception using errcode='42501',message='CP7_ACCESS_DENIED';
 end if;
 foreach k in array array['master.product.view','production.wip.view','warehouse.stock.view','sales.invoice.view'] loop
  if not erp.has_permission(k) then
   raise exception using errcode='42501',message='CP7_ACCESS_DENIED';
  end if;
 end loop;
 return jsonb_build_object('actor',auth.uid(),'profile',a->'profile',
  'permissions',a->'permissions','financial',erp.has_permission('finance.hpp.view'));
end $$;

create function cp7_private.project(p jsonb, money boolean) returns jsonb
language sql immutable security invoker set search_path='' as $$
 with v as (select case when money then p->'sources' else (p->'sources')-'lot_cost' end s,
                   case when money then p->'counts' else (p->'counts')-'lot_cost' end c)
 select (p-'sources'-'counts'-'snapshot_hash'-'snapshot')||jsonb_build_object('sources',s,'counts',c,
  'snapshot',(p->'snapshot')||jsonb_build_object('completeness_proven_only_for',
    case when money then 'SOURCE_CAPTURE_SIX_DOMAINS' else 'SOURCE_CAPTURE_FIVE_OPERATIONAL_DOMAINS' end),
  'snapshot_hash',encode(extensions.digest(convert_to(s::text,'UTF8'),'sha256'),'hex')) from v
$$;

create function cp7_private.dependencies(p jsonb) returns jsonb
language sql immutable security invoker set search_path='' as $$
 select jsonb_build_object('semantics','cp7.source-probe.v1','scope','CAPTURED_DOMAINS_ONLY',
  'domains',jsonb_object_agg(key,encode(extensions.digest(convert_to(value::text,'UTF8'),'sha256'),'hex')))
 from jsonb_each(p->'sources')
$$;

-- Scoped source facts for immutable runs; monetary facts read only when authorized.
create function cp7_private.capture_sources(p_root uuid,p_financial boolean) returns jsonb
language sql stable security invoker set search_path='' set timezone='Asia/Jakarta' as $cp7source$
with clock as materialized (
  -- The request may have waited before this INSERT/SELECT acquired its snapshot.
  -- Materialize the capture-time clock once, after the request lock is acquired.
  select p_root as root_id, clock_timestamp() as at
),
physical as materialized (
  select p.id,coalesce(p.identity_root_id,p.id) root_id,p.size_id,p.model_id,p.brand_id,
         p.effective_from,p.effective_to
  from erp.products p cross join clock c
  where coalesce(p.identity_root_id,p.id)=c.root_id
    and p.effective_from<=c.at and (p.effective_to is null or p.effective_to>c.at)
  order by p.effective_from desc,p.id limit 2
),
scope as materialized (select * from physical limit 1),
memberships as materialized (
  select v.id version_id,v.revision,s.id sku_id,s.sku
  from erp.bf_sku_members_v1 m join erp.bf_sku_versions_v1 v on v.id=m.version_id
  join erp.bf_skus_v1 s on s.id=v.sku_id cross join clock c
  where m.product_root=c.root_id and v.effective_from<=c.at
    and (v.effective_to is null or v.effective_to>c.at)
  order by v.effective_from desc,v.id limit 2
),
cutting_page as materialized (
  select y.id yield_id,g.id cutting_group_id,g.po_id,slot.id slot_id,
         slot.size_id,g.pattern_id,g.pattern_revision_snapshot,
         g.row_version,y.qty_pcs,g.cut_at
  from scope p join erp.production_orders po on po.model_id=p.model_id
  join erp.cutting_groups g on g.po_id=po.id
  join erp.cutting_group_size_slots slot on slot.cutting_group_id=g.id and slot.size_id=p.size_id
  join erp.cutting_group_rolls roll on roll.cutting_group_id=g.id
  join erp.cutting_roll_yields y on y.cutting_group_roll_id=roll.id and y.size_slot_id=slot.id
  cross join clock c
  where g.cut_at<=c.at
  order by g.cut_at,g.id,slot.id,y.id limit 501
),
stock_page as materialized (
  select m.id,m.product_id,m.lot_id,m.location_id,m.quality_grade,m.qty_signed,
         m.physical_at,m.system_created_at,m.reversal_of_id
  from erp.fg_stock_movements m cross join clock c
  join erp.products p on p.id=m.product_id
  where coalesce(p.identity_root_id,p.id)=c.root_id and m.physical_at<=c.at
    and m.system_created_at<=c.at
  order by m.physical_at,m.book_order,m.id limit 501
),
sales_page as materialized (
  select i.id,h.id sale_id,i.product_id,h.status,h.row_version,h.sale_date,
         h.created_at,i.qty_pcs
  from erp.sales_items i join erp.sales_headers h on h.id=i.sale_id
  join erp.products p on p.id=i.product_id cross join clock c
  where coalesce(p.identity_root_id,p.id)=c.root_id
    and h.created_at<=c.at and h.sale_date<=c.at
  order by h.created_at,h.id,i.id limit 501
),
cost_page as materialized (
  select l.id lot_id,l.product_id,l.produced_at,h.id hpp_version_id,
         h.version_no,h.cost_state,h.total_cost,h.calculated_at,
         (h.id is null or h.cost_state='ESTIMATED'
          or erp.bd_lot_laundry_unknown_v1(l.id)
          or (l.po_id is not null and not exists(
            select 1 from erp.get_hpp_completeness(l.po_id) z where z.pending_reason_count=0))) pending
  from erp.fg_lots l join erp.products p on p.id=l.product_id
  left join erp.hpp_versions h on h.lot_id=l.id and h.is_current
    and h.calculated_at<=(select at from clock)
  cross join clock c
  where p_financial and coalesce(p.identity_root_id,p.id)=c.root_id and l.produced_at<=c.at
  order by l.produced_at,l.id,h.version_no limit 501
),
observed as (
  select jsonb_build_object(
    'physical',coalesce((select jsonb_agg(jsonb_build_object(
      'product_id',id,'root_id',root_id,'size_id',size_id,'model_id',model_id,
      'brand_id',brand_id,'effective_from',effective_from) order by effective_from,id)
      from physical),'[]'::jsonb),
    'commercial',coalesce((select jsonb_agg(jsonb_build_object(
      'sku_id',sku_id,'version_id',version_id,'revision',revision::text,'sku',sku)
      order by version_id) from memberships),'[]'::jsonb),
    'cutting_candidates',coalesce((select jsonb_agg(jsonb_build_object(
      'source_key','CUTTING_YIELD:'||yield_id::text,'yield_id',yield_id,
      'cutting_group_id',cutting_group_id,'po_id',po_id,'slot_id',slot_id,
      'size_id',size_id,'pattern_id',pattern_id,
      'pattern_revision',pattern_revision_snapshot,'group_revision',row_version::text,
      'cut_at',cut_at,'cut_qty_pcs',qty_pcs::text,'match','UNBOUND_CANDIDATE')
      order by cut_at,cutting_group_id,slot_id,yield_id) from cutting_page),'[]'::jsonb),
    'stock_movements',coalesce((select jsonb_agg(jsonb_build_object(
      'source_key','FG_MOVEMENT:'||id::text,'product_id',product_id,'lot_id',lot_id,
      'location_id',location_id,'quality_grade',quality_grade,
      'qty_signed_pcs',qty_signed::text,'physical_at',physical_at,
      'system_created_at',system_created_at,'reversal_of_id',reversal_of_id)
      order by physical_at,id) from stock_page),'[]'::jsonb),
    'sales_lines',coalesce((select jsonb_agg(jsonb_build_object(
      'source_key','SALE_LINE:'||id::text,'sale_id',sale_id,'product_id',product_id,
      'status',status,'header_revision',row_version::text,
      'sale_date',sale_date,'created_at',created_at,'qty_pcs',qty_pcs::text)
      order by created_at,sale_id,id) from sales_page),'[]'::jsonb),
    'lot_cost',coalesce((select jsonb_agg(jsonb_build_object(
      'source_key','LOT_COST:'||lot_id::text,'lot_id',lot_id,'product_id',product_id,
      'produced_at',produced_at,'hpp_version_id',hpp_version_id,
      'hpp_revision',version_no::text,'calculated_at',calculated_at,
      'cost_state',cost_state,'valuation',case when pending then
        jsonb_build_object('state','UNKNOWN','reason','PENDING_COST_OR_NO_HPP')
        else jsonb_build_object('state','KNOWN','value',total_cost::text,'unit','IDR') end)
      order by produced_at,lot_id,hpp_version_id) from cost_page),'[]'::jsonb)
  ) as sources,
  jsonb_build_object('physical',(select count(*) from physical),
    'commercial',(select count(*) from memberships),
    'cutting_candidates',(select count(*) from cutting_page),
    'stock_movements',(select count(*) from stock_page),
    'sales_lines',(select count(*) from sales_page),
    'lot_cost',(select count(*) from cost_page)) as counts
),
result as (
  select jsonb_build_object(
    'contract_version','cp7.source-probe.v1',
    'status',case when (counts->>'physical')::int=1
                  and (counts->>'commercial')::int<=1
                  and (counts->>'cutting_candidates')::int<=500
                  and (counts->>'stock_movements')::int<=500
                  and (counts->>'sales_lines')::int<=500
                  and (counts->>'lot_cost')::int<=500
                  and (select count(distinct lot_id) from cost_page)
                    =(counts->>'lot_cost')::int
      then 'COMPLETE' else 'INCOMPLETE' end,
    'scope',jsonb_build_object('root_id',(select root_id from clock),
      'exact_size_id',(select size_id from scope),
      'commercial_status',case when (counts->>'commercial')::int=0
        then 'LEGACY_UNMAPPED' else 'BOUND' end),
    'snapshot',jsonb_build_object('effective_as_of',(select at from clock),
      'known_as_of',(select at from clock),'generated_at',(select at from clock),
      'knowledge_mode','CURRENT','time_zone','Asia/Jakarta',
      'completeness_proven_only_for','SOURCE_PROBE_SIX_DOMAINS'),
    'counts',counts,'sources',sources) payload
  from observed
)
select payload||jsonb_build_object('snapshot_hash',
  encode(extensions.digest(convert_to((payload->'sources')::text,'UTF8'),'sha256'),'hex'))
from result

$cp7source$;

create function cp7_private.serve(p_run uuid,p_domain text,p_cursor text,p_limit integer) returns jsonb
language plpgsql volatile security invoker set search_path='' set timezone='Asia/Jakarta' as $$
declare a jsonb; r cp7_private.analysis_runs%rowtype; p jsonb; live jsonb;
 money boolean; n integer; pos integer:=0; page jsonb; answer jsonb; prefix text;
begin
 if current_setting('transaction_isolation')<>'read committed' then
  raise exception using errcode='25001',message='CP7_FRESH_ACCESS_TRANSACTION_REQUIRED';
 end if;
 a:=cp7_private.access_now();
 if p_domain is null or p_domain not in ('physical','commercial','cutting_candidates','stock_movements','sales_lines','lot_cost')
    or p_limit is null or p_limit not between 1 and 100 then
  raise exception using errcode='22023',message='CP7_PAGE_INVALID';
 end if;
 if p_domain='lot_cost' and not (a->>'financial')::boolean then
  raise exception using errcode='42501',message='CP7_FINANCIAL_ACCESS_DENIED';
 end if;
 select * into r from cp7_private.analysis_runs where id=p_run and actor=auth.uid();
 if not found then raise exception using errcode='42501',message='CP7_RUN_UNAVAILABLE'; end if;
 money:=r.financial_captured and (a->>'financial')::boolean;
 if p_domain='lot_cost' and not money then
  raise exception using errcode='22023',message='CP7_FINANCIAL_NOT_CAPTURED';
 end if;
 p:=cp7_private.project(r.payload,money);
 n:=(p->'counts'->>p_domain)::integer;
 if p_cursor is not null then
  prefix:=p_run::text||':'||p_domain||':';
  if left(p_cursor,length(prefix))<>prefix or substr(p_cursor,length(prefix)+1)!~'^(0|[1-9][0-9]{0,3})$' then
   raise exception using errcode='22023',message='CP7_CURSOR_INVALID';
  end if;
  pos:=substr(p_cursor,length(prefix)+1)::integer;
  if pos>n then raise exception using errcode='22023',message='CP7_CURSOR_INVALID'; end if;
 end if;
 select coalesce(jsonb_agg(value order by ordinality),'[]') into page
 from jsonb_array_elements(p->'sources'->p_domain) with ordinality
 where ordinality>pos and ordinality<=pos+p_limit;
 live:=cp7_private.project(cp7_private.capture_sources(r.root_id,money),money);
 answer:=jsonb_build_object('contract_version','cp7.snapshot-page.v1','run_id',r.id,
  'scope',p->'scope','snapshot',p->'snapshot','financial_captured',money,
  'counts',p->'counts','projection_hash',p->'snapshot_hash',
  'source_state',case when live->>'status'<>'COMPLETE' then 'SOURCE_UNAVAILABLE'
    when live->>'snapshot_hash'<>p->>'snapshot_hash' then 'ARCHIVED_STALE' else 'CURRENT' end,
  'page',jsonb_build_object('domain',p_domain,'total',n,'rows',page,
    'next_cursor',case when pos+p_limit<n then p_run::text||':'||p_domain||':'||(pos+p_limit)::text else null end));
 -- A revocation committed while sources were being read refuses the response.
 if cp7_private.access_now()<>a then
  raise exception using errcode='42501',message='CP7_ACCESS_CHANGED';
 end if;
 return answer;
end $$;

create function cp7_private.capture_run(p_root uuid,p_request uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' set timezone='Asia/Jakarta' as $$
declare a jsonb; r cp7_private.analysis_runs%rowtype; money boolean;
begin
 if current_setting('transaction_isolation')<>'read committed' then
  raise exception using errcode='25001',message='CP7_FRESH_ACCESS_TRANSACTION_REQUIRED';
 end if;
 a:=cp7_private.access_now();
 if p_root is null or p_request is null then raise exception using errcode='22023',message='CP7_REQUEST_INVALID'; end if;
 perform pg_advisory_xact_lock(hashtextextended('CP7_CAPTURE:'||auth.uid()::text||':'||p_request::text,0));
 select * into r from cp7_private.analysis_runs where actor=auth.uid() and request_id=p_request;
 if found then
  if r.root_id<>p_root then raise exception using errcode='22023',message='CP7_REQUEST_REUSED'; end if;
 else
  money:=(a->>'financial')::boolean;
  -- Facts, domain hashes and manifest are persisted by this one statement.
  with facts as materialized (
   select cp7_private.project(cp7_private.capture_sources(p_root,money),money) p
  ) insert into cp7_private.analysis_runs(actor,request_id,root_id,financial_captured,captured_at,access_at_capture,payload,dependencies)
   select auth.uid(),p_request,p_root,money,(p->'snapshot'->>'generated_at')::timestamptz,a,p,cp7_private.dependencies(p)
   from facts where p->>'status'='COMPLETE'
   returning * into r;
  if not found then raise exception using errcode='22023',message='CP7_SOURCE_INCOMPLETE'; end if;
 end if;
 if cp7_private.access_now()<>a then raise exception using errcode='42501',message='CP7_ACCESS_CHANGED'; end if;
 return cp7_private.serve(r.id,'physical',null,100);
end $$;

create function public.erp_cp7_capture_snapshot_v1(p_root uuid,p_request uuid) returns jsonb
language sql volatile security definer set search_path='' as $$
 select cp7_private.capture_run(p_root,p_request)
$$;
create function public.erp_cp7_read_snapshot_v1(p_run uuid,p_domain text default 'physical',p_cursor text default null,p_limit integer default 100) returns jsonb
language sql volatile security definer set search_path='' as $$
 select cp7_private.serve(p_run,p_domain,p_cursor,p_limit)
$$;

grant create on schema public to cp7_capture;
alter function public.erp_cp7_capture_snapshot_v1(uuid,uuid) owner to cp7_capture;
alter function public.erp_cp7_read_snapshot_v1(uuid,text,text,integer) owner to cp7_capture;
revoke create on schema public from cp7_capture;
revoke all on all functions in schema cp7_private from public,anon,authenticated,service_role;
grant execute on all functions in schema cp7_private to cp7_capture;
revoke all on function public.erp_cp7_capture_snapshot_v1(uuid,uuid),public.erp_cp7_read_snapshot_v1(uuid,text,text,integer) from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_capture_snapshot_v1(uuid,uuid),public.erp_cp7_read_snapshot_v1(uuid,text,text,integer) to authenticated;

-- Isolated CP7 policy authority. Existing ERP operational tables remain read-only.
create role cp7_policy nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_identity authorization cp7_policy;
revoke all on schema cp7_identity from public,anon,authenticated,service_role;
grant usage on schema cp7_identity to cp7_capture;
grant usage on schema erp,auth,extensions,public to cp7_policy;
grant select on erp.bf_skus_v1,erp.bf_sku_versions_v1,erp.bf_sku_members_v1,erp.products to cp7_policy;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_policy;
grant execute on function extensions.digest(bytea,text) to cp7_policy;

create table cp7_identity.production_policy (
 id uuid primary key default gen_random_uuid(),
 sku_id uuid not null references erp.bf_skus_v1(id),
 revision bigint not null check(revision>0),
 state text not null check(state in ('ACTIVE','PAUSED','STOPPED')),
 reason text not null check(length(btrim(reason)) between 1 and 1000),
 review_at timestamptz,
 actor uuid not null,
 request_id uuid not null,
 reviewed_commercial_version uuid not null,
 reviewed_commercial_revision bigint not null,
 reviewed_members uuid[] not null check(cardinality(reviewed_members)>0),
 recorded_at timestamptz not null default clock_timestamp(),
 unique(sku_id,revision),unique(actor,request_id,sku_id)
);
create table cp7_identity.commands (
 actor uuid not null,request_id uuid not null,payload_hash text not null,
 result jsonb not null,recorded_at timestamptz not null default clock_timestamp(),
 primary key(actor,request_id)
);
alter table cp7_identity.production_policy enable row level security;
alter table cp7_identity.commands enable row level security;
revoke all on all tables in schema cp7_identity from public,anon,authenticated,service_role;
grant select,insert on cp7_identity.production_policy,cp7_identity.commands to cp7_policy;
grant select on cp7_identity.production_policy to cp7_capture;

create function cp7_identity.immutable_row() returns trigger
language plpgsql security invoker set search_path='' as $$
begin raise exception using errcode='55000',message='CP7_POLICY_HISTORY_IMMUTABLE'; end $$;
create trigger immutable_policy before update or delete on cp7_identity.production_policy
 for each row execute function cp7_identity.immutable_row();
create trigger immutable_command before update or delete on cp7_identity.commands
 for each row execute function cp7_identity.immutable_row();

create function cp7_identity.access_now(writing boolean) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then
  raise exception using errcode='42501',message='CP7_POLICY_ACCESS_DENIED';
 end if;
 a:=erp.get_my_access_v1();
 if not coalesce((a->>'allowed')::boolean,false)
    or not erp.has_permission('master.product.view') or not erp.has_permission('production.wip.view')
    or (writing and not erp.has_permission('master.product.manage')) then
  raise exception using errcode='42501',message='CP7_POLICY_ACCESS_DENIED';
 end if;
 return a;
end $$;

-- Price-only revisions do not invalidate an already reviewed member set.
create function cp7_identity.membership(p_sku uuid,p_at timestamptz) returns jsonb
language sql stable security invoker set search_path='' as $$
 with version as materialized (
  select s.id,s.sku,s.brand_id,s.revision,v.id version_id
  from erp.bf_skus_v1 s join erp.bf_sku_versions_v1 v on v.sku_id=s.id
  where s.id=p_sku and v.effective_from<=p_at and (v.effective_to is null or v.effective_to>p_at)
 ), members as materialized (
  select m.product_root from erp.bf_sku_members_v1 m join version v on v.version_id=m.version_id
 )
 select case when (select count(*) from version)=1 and (select count(*) from members)>0 then
  jsonb_build_object('sku_id',id,'sku',sku,'brand_id',brand_id,'commercial_version_id',version_id,
    'commercial_revision',revision::text,'members',(select jsonb_agg(product_root order by product_root) from members))
  else null end from version limit 1
$$;

create function cp7_identity.workspace_data(p_skus uuid[],p_at timestamptz) returns jsonb
language sql stable security invoker set search_path='' as $$
 with scope as materialized (
  select id,cp7_identity.membership(id,p_at) member from unnest(p_skus) id
 ), facts as (
  select s.id scope_id,s.member,p.*,
   coalesce(p.reviewed_members=(select array_agg(value::uuid order by value::uuid)
     from jsonb_array_elements_text(s.member->'members')),false) members_current
  from scope s left join lateral (
   select x.* from cp7_identity.production_policy x where x.sku_id=s.id order by x.revision desc limit 1
  ) p on true
 )
 select jsonb_build_object('contract_version','cp7.production-policy.v1','knowledge_mode','CURRENT',
  'generated_at',p_at,'rows',coalesce(jsonb_agg(case when member is null then
   jsonb_build_object('sku_id',scope_id,'status','UNAVAILABLE') else member||jsonb_build_object(
    'status','AVAILABLE','policy_revision',coalesce(revision,0)::text,
    'policy',jsonb_build_object('quality',case when revision is null then 'UNREVIEWED'
      when not members_current then 'MEMBERSHIP_CHANGED' else 'KNOWN' end,
     'state',case when members_current then state else null end,
     'last_reviewed_state',state,'reason',reason,'review_at',review_at,
     'review_due',coalesce(review_at<=p_at,false),'recorded_at',recorded_at)) end order by scope_id),'[]'))
 from facts
$$;

create function cp7_identity.workspace(p_skus uuid[]) returns jsonb
language plpgsql volatile security invoker set search_path='' set timezone='Asia/Jakarta' as $$
declare a jsonb; result jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed' then
  raise exception using errcode='25001',message='CP7_FRESH_ACCESS_TRANSACTION_REQUIRED';
 end if;
 a:=cp7_identity.access_now(false);
 if p_skus is null or array_ndims(p_skus)<>1 or cardinality(p_skus) not between 1 and 200
    or (select count(distinct id) from unnest(p_skus) id)<>cardinality(p_skus) then
  raise exception using errcode='22023',message='CP7_POLICY_SCOPE_INVALID';
 end if;
 select cp7_identity.workspace_data(p_skus,clock_timestamp()) into result;
 if cp7_identity.access_now(false)<>a then
  raise exception using errcode='42501',message='CP7_POLICY_ACCESS_CHANGED';
 end if;
 return result;
end $$;

-- Frozen identity is read from the captured run. Current regrouping is separate.
create function cp7_identity.source_identity(p_run uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' set timezone='Asia/Jakarta' as $$
declare a jsonb; r cp7_private.analysis_runs%rowtype; at timestamptz; current_members jsonb; result jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed' then
  raise exception using errcode='25001',message='CP7_FRESH_ACCESS_TRANSACTION_REQUIRED';
 end if;
 a:=cp7_private.access_now();
 select * into r from cp7_private.analysis_runs where id=p_run and actor=auth.uid();
 if not found then raise exception using errcode='42501',message='CP7_RUN_UNAVAILABLE';end if;
 with capture_clock as materialized (select clock_timestamp() captured_at)
 select c.captured_at,coalesce((
  select jsonb_agg(jsonb_build_object('sku_id',s.id,'sku',s.sku,'version_id',v.id,'revision',v.revision::text) order by v.id)
  from erp.bf_sku_members_v1 m join erp.bf_sku_versions_v1 v on v.id=m.version_id
  join erp.bf_skus_v1 s on s.id=v.sku_id
  where m.product_root=r.root_id and v.effective_from<=c.captured_at and (v.effective_to is null or v.effective_to>c.captured_at)
 ),'[]'::jsonb) into at,current_members from capture_clock c;
 if jsonb_array_length(current_members)>1 then
  raise exception using errcode='22023',message='CP7_IDENTITY_CONFLICT';
 end if;
 result:=jsonb_build_object('contract_version','cp7.source-identity.v1','run_id',r.id,'root_id',r.root_id,
  'physical_at_capture',r.payload->'sources'->'physical',
  'original',jsonb_build_object('basis','AT_CAPTURE','effective_as_of',r.payload->'snapshot'->'effective_as_of',
    'known_as_of',r.payload->'snapshot'->'known_as_of','commercial',r.payload->'sources'->'commercial'),
  'current_restatement',jsonb_build_object('basis','CURRENT_RESTATED','generated_at',at,'commercial',current_members),
  'commercial_version_changed',current_members is distinct from r.payload->'sources'->'commercial',
  'group_changed',(current_members->0->'sku_id') is distinct from (r.payload->'sources'->'commercial'->0->'sku_id'));
 if cp7_private.access_now()<>a then raise exception using errcode='42501',message='CP7_ACCESS_CHANGED';end if;
 return result;
end $$;

create function cp7_identity.apply_policy(p_changes jsonb,p_request uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' set timezone='Asia/Jakarta' as $$
declare a jsonb; v_actor uuid; hash text; old cp7_identity.commands%rowtype;
 change jsonb; member jsonb; at timestamptz; sid uuid; members uuid[]; expected bigint;
 current_revision bigint; state text; reason text; review timestamptz; applied jsonb:='[]';
 row cp7_identity.production_policy%rowtype; result jsonb; seen uuid[]:='{}';
begin
 if current_setting('transaction_isolation')<>'read committed' then
  raise exception using errcode='25001',message='CP7_FRESH_ACCESS_TRANSACTION_REQUIRED';
 end if;
 a:=cp7_identity.access_now(true);v_actor:=auth.uid();
 if p_request is null or p_changes is null or jsonb_typeof(p_changes)<>'array' then
  raise exception using errcode='22023',message='CP7_POLICY_REQUEST_INVALID';
 end if;
 if jsonb_array_length(p_changes) not between 1 and 100 then
  raise exception using errcode='22023',message='CP7_POLICY_REQUEST_INVALID';
 end if;
 hash:=encode(extensions.digest(convert_to(p_changes::text,'UTF8'),'sha256'),'hex');
 perform pg_advisory_xact_lock(hashtextextended('CP7_POLICY_REQUEST:'||v_actor::text||':'||p_request::text,0));
 -- Recheck before a cached outcome and again after the commercial lock.
 if cp7_identity.access_now(true)<>a then
  raise exception using errcode='42501',message='CP7_POLICY_ACCESS_CHANGED';
 end if;
 select * into old from cp7_identity.commands where commands.actor=v_actor and request_id=p_request;
 if found then
  if old.payload_hash<>hash then raise exception using errcode='22023',message='CP7_POLICY_REQUEST_REUSED';end if;
  if cp7_identity.access_now(true)<>a then
   raise exception using errcode='42501',message='CP7_POLICY_ACCESS_CHANGED';
  end if;
  return old.result||jsonb_build_object('replayed',true);
 end if;
 perform pg_advisory_xact_lock(hashtextextended('BF:COMMERCIAL_SKUS',0));
 if cp7_identity.access_now(true)<>a then
  raise exception using errcode='42501',message='CP7_POLICY_ACCESS_CHANGED';
 end if;
 at:=clock_timestamp();
 for change in select value from jsonb_array_elements(p_changes) loop
  if jsonb_typeof(change)<>'object' or (select array_agg(k order by k) from jsonb_object_keys(change) k)
   is distinct from array['commercial_revision','commercial_version_id','members','policy_revision','reason','review_at','sku_id','state']::text[] then
   raise exception using errcode='22023',message='CP7_POLICY_FIELDS_INVALID';
  end if;
  if exists(select 1 from unnest(array['sku_id','commercial_version_id','commercial_revision','policy_revision','state','reason']) k
   where jsonb_typeof(change->k) is distinct from 'string')
   or jsonb_typeof(change->'review_at') not in ('null','string') then
   raise exception using errcode='22023',message='CP7_POLICY_FIELDS_INVALID';
  end if;
  sid:=(change->>'sku_id')::uuid;
  if sid is null or sid=any(seen) then raise exception using errcode='22023',message='CP7_POLICY_DUPLICATE_SCOPE';end if;
  seen:=array_append(seen,sid);
  if jsonb_typeof(change->'members')<>'array' or jsonb_array_length(change->'members') not between 1 and 500 then
   raise exception using errcode='22023',message='CP7_POLICY_MEMBERS_INVALID';
  end if;
  select array_agg(value::uuid order by value::uuid) into members from jsonb_array_elements_text(change->'members');
  if (select count(distinct m) from unnest(members) m)<>cardinality(members) then
   raise exception using errcode='22023',message='CP7_POLICY_MEMBERS_INVALID';
  end if;
  if coalesce(change->>'commercial_revision','')!~'^(0|[1-9][0-9]*)$'
     or coalesce(change->>'policy_revision','')!~'^(0|[1-9][0-9]*)$' then
   raise exception using errcode='22023',message='CP7_POLICY_REVISION_INVALID';
  end if;
  member:=cp7_identity.membership(sid,at);
  if member is null or member->>'commercial_version_id' is distinct from change->>'commercial_version_id'
     or member->>'commercial_revision' is distinct from change->>'commercial_revision'
     or member->'members' is distinct from to_jsonb(members) then
   raise exception using errcode='40001',message='CP7_POLICY_MEMBERSHIP_STALE';
  end if;
  expected:=(change->>'policy_revision')::bigint;
  select coalesce(max(revision),0) into current_revision from cp7_identity.production_policy where sku_id=sid;
  if current_revision<>expected then raise exception using errcode='40001',message='CP7_POLICY_VERSION_STALE';end if;
  state:=change->>'state';reason:=btrim(change->>'reason');review:=(change->>'review_at')::timestamptz;
  if (review is not null and not isfinite(review)) or state is null or state not in ('ACTIVE','PAUSED','STOPPED') or reason is null or length(reason) not between 1 and 1000 then
   raise exception using errcode='22023',message='CP7_POLICY_VALUE_INVALID';
  end if;
  insert into cp7_identity.production_policy(sku_id,revision,state,reason,review_at,actor,request_id,
   reviewed_commercial_version,reviewed_commercial_revision,reviewed_members,recorded_at)
  values(sid,current_revision+1,state,reason,review,v_actor,p_request,
   (member->>'commercial_version_id')::uuid,(member->>'commercial_revision')::bigint,members,at) returning * into row;
  applied:=applied||jsonb_build_array(jsonb_build_object('sku_id',sid,'revision',row.revision::text,'state',row.state,'policy_id',row.id));
 end loop;
 if cp7_identity.access_now(true)<>a then
  raise exception using errcode='42501',message='CP7_POLICY_ACCESS_CHANGED';
 end if;
 result:=jsonb_build_object('contract_version','cp7.production-policy-outcome.v1','kind','COMMITTED_OUTCOME',
  'request_id',p_request,'recorded_at',at,'applied',applied,'replayed',false);
 insert into cp7_identity.commands(actor,request_id,payload_hash,result) values(v_actor,p_request,hash,result);
 return result;
end $$;

create function public.erp_cp7_get_production_policy_v1(p_skus uuid[]) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_identity.workspace(p_skus)$$;
create function public.erp_cp7_get_source_identity_v1(p_run uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_identity.source_identity(p_run)$$;
create function public.erp_cp7_set_production_policy_v1(p_changes jsonb,p_request uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_identity.apply_policy(p_changes,p_request)$$;
grant create on schema public to cp7_capture,cp7_policy;
alter function public.erp_cp7_get_production_policy_v1(uuid[]) owner to cp7_capture;
alter function public.erp_cp7_get_source_identity_v1(uuid) owner to cp7_capture;
alter function public.erp_cp7_set_production_policy_v1(jsonb,uuid) owner to cp7_policy;
revoke create on schema public from cp7_capture,cp7_policy;
revoke all on all functions in schema cp7_identity from public,anon,authenticated,service_role,cp7_capture,cp7_policy;
grant execute on function cp7_identity.access_now(boolean),cp7_identity.membership(uuid,timestamptz),
 cp7_identity.workspace_data(uuid[],timestamptz),cp7_identity.workspace(uuid[]),cp7_identity.source_identity(uuid) to cp7_capture;
grant execute on function cp7_identity.access_now(boolean),cp7_identity.membership(uuid,timestamptz),
 cp7_identity.apply_policy(jsonb,uuid) to cp7_policy;
revoke all on function public.erp_cp7_get_production_policy_v1(uuid[]),public.erp_cp7_get_source_identity_v1(uuid),public.erp_cp7_set_production_policy_v1(jsonb,uuid)
 from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_production_policy_v1(uuid[]),public.erp_cp7_get_source_identity_v1(uuid),public.erp_cp7_set_production_policy_v1(jsonb,uuid) to authenticated;

-- Private PostgreSQL kernels. No operational writes or public execution.
create schema cp7_wip authorization cp7_capture;
revoke all on schema cp7_wip from public,anon,authenticated,service_role;

create function cp7_wip.fields(v jsonb, names text[]) returns void
language plpgsql immutable security invoker set search_path='' as $$
begin
 if jsonb_typeof(v) is distinct from 'object'
    or (select count(*) from jsonb_object_keys(v))<>cardinality(names)
    or not v ?& names then
  raise exception using errcode='22023',message='CP7_WIP_FIELDS';
 end if;
end $$;
create function cp7_wip.key(v jsonb) returns text
language plpgsql immutable security invoker set search_path='' as $$
begin
 if jsonb_typeof(v) is distinct from 'string' or length(v#>>'{}') not between 1 and 200
    or btrim(v#>>'{}')<>(v#>>'{}') then
  raise exception using errcode='22023',message='CP7_WIP_KEY';
 end if;
 return v#>>'{}';
end $$;
create function cp7_wip.pcs(v jsonb) returns numeric
language plpgsql immutable security invoker set search_path='' as $$
begin
 if jsonb_typeof(v) is distinct from 'string' or (v#>>'{}') !~ '^(0|[1-9][0-9]{0,29})$' then
  raise exception using errcode='22023',message='CP7_WIP_PCS';
 end if;
 return (v#>>'{}')::numeric;
end $$;
create function cp7_wip.refs(v jsonb) returns void
language plpgsql immutable security invoker set search_path='' as $$
declare r jsonb;
begin
 if jsonb_typeof(v) is distinct from 'array' or jsonb_array_length(v) not between 1 and 1000 then
  raise exception using errcode='22023',message='CP7_WIP_REFS';
 end if;
 for r in select value from jsonb_array_elements(v) loop
  perform cp7_wip.fields(r,array['kind','id','revision']);
  perform cp7_wip.key(r->'kind');perform cp7_wip.key(r->'id');perform cp7_wip.key(r->'revision');
 end loop;
 if (select count(*) from jsonb_array_elements(v))<>(select count(distinct value) from jsonb_array_elements(v)) then
  raise exception using errcode='22023',message='CP7_WIP_DUPLICATE_REF';
 end if;
end $$;

-- A conserved pool is original company/customer input of one exact size.
-- Nodes are positions of that same input, never additional supplies.
-- This kernel accepts normalized facts, not untrusted operational commands.
create function cp7_wip.reconcile(g jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare
 p jsonb; n jsonb; e jsonb; old jsonb; node jsonb; dest jsonb;
 pools jsonb:='{}'; nodes jsonb:='{}'; events jsonb:='{}'; outputs jsonb[]:='{}'; totals jsonb[]:='{}';
 k text; pool text; src text; dst text; ord numeric; last_ord numeric:=-1;
 qty numeric; val numeric; total numeric; wip numeric; fg numeric; bs numeric; withheld numeric; exited numeric;
 stages constant text[]:=array['CUT_UNASSIGNED','SEWING_ACTIVE','SEWING_UNRESOLVED',
  'LAUNDRY_OUTSTANDING','AWAIT_QC','FG','BS','MISSING','STUCK','HOLD','REWORK','REWASH','EXIT'];
 wip_stages constant text[]:=array['CUT_UNASSIGNED','SEWING_ACTIVE','SEWING_UNRESOLVED',
  'LAUNDRY_OUTSTANDING','AWAIT_QC','REWORK','REWASH'];
 i integer; j integer; repeated boolean[]; reversed boolean[]; at_pool jsonb; at_node jsonb;
 inputs numeric[]; balances numeric[]; ordered jsonb[]; o integer:=1;
begin
 perform cp7_wip.fields(g,array['contract_version','snapshot_id','complete','pools','nodes','events']);
 perform cp7_wip.key(g->'snapshot_id');
 if g->>'contract_version'<>'cp7.wip-graph.v1' or jsonb_typeof(g->'complete') is distinct from 'boolean'
   or jsonb_typeof(g->'pools') is distinct from 'array' or jsonb_typeof(g->'nodes') is distinct from 'array'
   or jsonb_typeof(g->'events') is distinct from 'array' then
  raise exception using errcode='22023',message='CP7_WIP_SHAPE';
 end if;
 if not (g->>'complete')::boolean then
  return jsonb_build_object('status','UNKNOWN','reason','SOURCE_CAPTURE_INCOMPLETE','snapshot_id',g->'snapshot_id');
 end if;
 if jsonb_array_length(g->'pools')>1000 or jsonb_array_length(g->'nodes')>10000 or jsonb_array_length(g->'events')>20000 then
  raise exception using errcode='54000',message='CP7_WIP_LIMIT';
 end if;
 -- Linear form: every key seen at an earlier element is flagged by position
 -- (an earlier element either passed or already raised), and the pool, node
 -- and event maps are built once after the loop that proved their keys unique.
 -- Balances live in arrays indexed by element position.
 select coalesce(array_agg(f.r order by f.o),'{}') into repeated from(select ordinality o,
  row_number()over(partition by value->>'key' order by ordinality)>1 r from jsonb_array_elements(g->'pools') with ordinality)f;
 i:=0;
 for p in select value from jsonb_array_elements(g->'pools') loop
  i:=i+1;
  perform cp7_wip.fields(p,array['key','size_id','input_pcs','origin','ownership','refs']);
  k:=cp7_wip.key(p->'key');perform cp7_wip.key(p->'size_id');perform cp7_wip.refs(p->'refs');
  qty:=cp7_wip.pcs(p->'input_pcs');
  if repeated[i] or p->>'origin' not in ('CUTTING','OPENING','NON_PO') or p->>'ownership' not in ('COMPANY','CUSTOMER')
    or p->>'origin' is null or p->>'ownership' is null then
   raise exception using errcode='22023',message='CP7_WIP_POOL';
  end if;
 end loop;
 select coalesce(jsonb_object_agg(value->>'key',value),'{}'),coalesce(jsonb_object_agg(value->>'key',ordinality),'{}')
  into pools,at_pool from jsonb_array_elements(g->'pools') with ordinality;
 inputs:=array_fill(0::numeric,array[i]);
 select coalesce(array_agg(f.r order by f.o),'{}') into repeated from(select ordinality o,
  row_number()over(partition by value->>'key' order by ordinality)>1 r from jsonb_array_elements(g->'nodes') with ordinality)f;
 i:=0;
 for n in select value from jsonb_array_elements(g->'nodes') loop
  i:=i+1;
  perform cp7_wip.fields(n,array['key','pool_key','stage','refs']);
  k:=cp7_wip.key(n->'key');pool:=cp7_wip.key(n->'pool_key');perform cp7_wip.refs(n->'refs');
  if repeated[i] or not pools ? pool or n->>'stage' is null or not (n->>'stage'=any(stages)) then
   raise exception using errcode='22023',message='CP7_WIP_NODE';
  end if;
 end loop;
 select coalesce(jsonb_object_agg(value->>'key',value),'{}'),coalesce(jsonb_object_agg(value->>'key',ordinality),'{}')
  into nodes,at_node from jsonb_array_elements(g->'nodes') with ordinality;
 balances:=array_fill(0::numeric,array[i]);
 -- An event may reverse only an event seen before it; a reversed key is
 -- reversed at most once, by the first later event that names it.
 select coalesce(array_agg(f.r order by f.o),'{}'),coalesce(array_agg(f.v order by f.o),'{}') into repeated,reversed from(select ordinality o,
  row_number()over(partition by value->>'key' order by ordinality)>1 r,
  value->>'reverses_key' is not null and row_number()over(partition by value->>'reverses_key' order by ordinality)>1 v
  from jsonb_array_elements(g->'events') with ordinality)f;
 select coalesce(jsonb_object_agg(f.k,jsonb_build_array(f.o,f.value)),'{}') into events from(select distinct on(value->>'key')value->>'key' k,ordinality o,value
  from jsonb_array_elements(g->'events') with ordinality where value->>'key' is not null order by value->>'key',ordinality)f;
 i:=0;
 -- Ordinal is explicit normalized dependency order, not a guessed wall-clock order.
 for e in select value from jsonb_array_elements(g->'events') loop
  i:=i+1;
  perform cp7_wip.fields(e,array['key','pool_key','from_node','to_node','qty_pcs','ordinal','reverses_key','refs']);
  k:=cp7_wip.key(e->'key');pool:=cp7_wip.key(e->'pool_key');dst:=cp7_wip.key(e->'to_node');
  perform cp7_wip.refs(e->'refs');qty:=cp7_wip.pcs(e->'qty_pcs');ord:=cp7_wip.pcs(e->'ordinal');
  if repeated[i] or not pools ? pool or qty=0 or ord<=last_ord then
   raise exception using errcode='22023',message='CP7_WIP_EVENT';
  end if;
  last_ord:=ord;src:=null;
  if e->'from_node'<>'null'::jsonb then src:=cp7_wip.key(e->'from_node');end if;
  dest:=nodes->dst;
  if dest is null or dest->>'pool_key'<>pool or src=dst then
   raise exception using errcode='22023',message='CP7_WIP_LINEAGE';
  end if;
  if e->'reverses_key'<>'null'::jsonb then
   old:=events->cp7_wip.key(e->'reverses_key');
   old:=case when (old->>0)::integer<i then old->1 end;
   if old is null or reversed[i] or old->'reverses_key'<>'null'::jsonb
     or old->'from_node'='null'::jsonb or old->>'pool_key'<>pool or old->>'from_node'<>dst
     or old->>'to_node' is distinct from src or cp7_wip.pcs(old->'qty_pcs')<>qty then
    raise exception using errcode='22023',message='CP7_WIP_REVERSAL';
   end if;
  end if;
  if src is null then
   if e->'reverses_key'<>'null'::jsonb then raise exception 'CP7_WIP_REVERSAL';end if;
   j:=(at_pool->>pool)::integer;val:=inputs[j]+qty;
   if val>cp7_wip.pcs(pools->pool->'input_pcs') then
    return jsonb_build_object('status','CONFLICT','reason','INPUT_EXCEEDS_ORIGIN','pool_key',pool,'event_key',k,'snapshot_id',g->'snapshot_id');
   end if;
   inputs[j]:=val;
  else
   node:=nodes->src;
   if node is null or node->>'pool_key'<>pool then raise exception 'CP7_WIP_LINEAGE';end if;
   j:=(at_node->>src)::integer;val:=balances[j]-qty;
   if val<0 then
    return jsonb_build_object('status','CONFLICT','reason','NEGATIVE_PREFIX','pool_key',pool,'event_key',k,'snapshot_id',g->'snapshot_id');
   end if;
   balances[j]:=val;
  end if;
  j:=(at_node->>dst)::integer;val:=balances[j]+qty;balances[j]:=val;
 end loop;
 -- Pools in key order, each with its own nodes in key order: one sort of the
 -- nodes by (pool key, node key) walked alongside the sorted pools.
 select coalesce(array_agg(value order by value->>'pool_key',value->>'key'),'{}') into ordered from jsonb_array_elements(g->'nodes');
 for p in select value from jsonb_array_elements(g->'pools') order by value->>'key' loop
  pool:=p->>'key';total:=0;wip:=0;fg:=0;bs:=0;withheld:=0;exited:=0;
  if inputs[(at_pool->>pool)::integer]<>cp7_wip.pcs(p->'input_pcs') then
   return jsonb_build_object('status','UNKNOWN','reason','ORIGIN_NOT_FULLY_ACCOUNTED','pool_key',pool,'snapshot_id',g->'snapshot_id');
  end if;
  while o<=cardinality(ordered) and ordered[o]->>'pool_key'=pool loop
   n:=ordered[o];o:=o+1;
   k:=n->>'key';qty:=balances[(at_node->>k)::integer];total:=total+qty;
   if n->>'stage'=any(wip_stages) then wip:=wip+qty;
   elsif n->>'stage'='FG' then fg:=fg+qty;
   elsif n->>'stage'='BS' then bs:=bs+qty;
   elsif n->>'stage'='EXIT' then exited:=exited+qty;
   else withheld:=withheld+qty;end if;
   -- Zero positions are retained as explicit evidence, never new supply.
   outputs:=array_append(outputs,n||jsonb_build_object('size_id',p->'size_id',
    'ownership',p->'ownership','remaining_pcs',qty::text,
    'quantity_quality','KNOWN','eligible_company_wip',p->>'ownership'='COMPANY' and n->>'stage'=any(wip_stages)));
  end loop;
  if total<>cp7_wip.pcs(p->'input_pcs') then raise exception 'CP7_WIP_CONSERVATION';end if;
  totals:=array_append(totals,jsonb_build_object('pool_key',pool,'size_id',p->'size_id',
   'ownership',p->'ownership','input_pcs',p->'input_pcs','wip_pcs',wip::text,'fg_pcs',fg::text,
   'bs_pcs',bs::text,'withheld_pcs',withheld::text,'exited_pcs',exited::text,'refs',p->'refs'));
 end loop;
 return jsonb_build_object('contract_version','cp7.wip-position.v1','status','COMPLETE',
  'snapshot_id',g->'snapshot_id','positions',to_jsonb(outputs),'totals',to_jsonb(totals),
  'scope','NORMALIZED_LINEAGE_ONLY','production_go',false);
end $$;

-- Constraints describe explicit source facts/requirements. Optional empty metadata
-- does not reject all WIP. A tariff/history hint never confirms a destination.
create function cp7_wip.match_target(s jsonb,t jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare c jsonb; d jsonb; side jsonb; k text; constraints jsonb; seen jsonb;
 required boolean; missing text[]:='{}'; conflicts text[]:='{}';
 allowed constant text[]:=array['pattern_revision','material','finish','color','brand'];
begin
 perform cp7_wip.fields(s,array['key','quality','size_id','confirmed_target','constraints','refs']);
 perform cp7_wip.fields(t,array['key','size_id','constraints','refs']);
 perform cp7_wip.key(s->'key');perform cp7_wip.key(t->'key');
 perform cp7_wip.key(s->'size_id');perform cp7_wip.key(t->'size_id');
 perform cp7_wip.refs(s->'refs');perform cp7_wip.refs(t->'refs');
 if s->>'quality' is null or s->>'quality' not in ('COMPLETE','PARTIAL','CONFLICT','UNKNOWN') then raise exception 'CP7_WIP_QUALITY';end if;
 if s->'confirmed_target'<>'null'::jsonb then perform cp7_wip.key(s->'confirmed_target');end if;
 foreach side in array array[s,t] loop
  constraints:=side->'constraints';seen:='{}';
  if jsonb_typeof(constraints) is distinct from 'array' or jsonb_array_length(constraints)>5 then raise exception 'CP7_WIP_CONSTRAINTS';end if;
  for c in select value from jsonb_array_elements(constraints) loop
   perform cp7_wip.fields(c,array['field','value','required','basis']);k:=cp7_wip.key(c->'field');
   if not k=any(allowed) or seen ? k or jsonb_typeof(c->'required') is distinct from 'boolean'
     or c->>'basis' is null or c->>'basis' not in ('FACT','HINT','UNKNOWN') then raise exception 'CP7_WIP_CONSTRAINT';end if;
   if c->'value'<>'null'::jsonb then perform cp7_wip.key(c->'value');end if;
   if c->>'basis'='UNKNOWN' and c->'value'<>'null'::jsonb then raise exception 'CP7_WIP_CONSTRAINT';end if;
   seen:=seen||jsonb_build_object(k,true);
  end loop;
 end loop;
 if s->>'quality'<>'COMPLETE' then return jsonb_build_object('match','UNKNOWN','reasons',jsonb_build_array('SOURCE_'||(s->>'quality')));end if;
 if s->>'size_id'<>t->>'size_id' then conflicts:=array_append(conflicts,'SIZE_MISMATCH');end if;
 if s->'confirmed_target'<>'null'::jsonb and s->>'confirmed_target'<>t->>'key' then
  conflicts:=array_append(conflicts,'CONFIRMED_OTHER_TARGET');
 end if;
 foreach k in array allowed loop
  select value into c from jsonb_array_elements(s->'constraints') where value->>'field'=k;
  select value into d from jsonb_array_elements(t->'constraints') where value->>'field'=k;
  required:=coalesce((c->>'required')::boolean,false) or coalesce((d->>'required')::boolean,false);
  if c->>'basis'='FACT' and d->>'basis'='FACT' and c->'value'<>'null'::jsonb and d->'value'<>'null'::jsonb then
   if c->>'value'<>d->>'value' then conflicts:=array_append(conflicts,upper(k)||'_MISMATCH');end if;
  elsif required then missing:=array_append(missing,upper(k)||'_NEEDS_PROOF');end if;
 end loop;
 if cardinality(conflicts)>0 then return jsonb_build_object('match','INCOMPATIBLE','reasons',to_jsonb(conflicts));end if;
 if cardinality(missing)>0 then return jsonb_build_object('match','NEEDS_CHECK','reasons',to_jsonb(missing));end if;
 return jsonb_build_object('match',case when s->>'confirmed_target'=t->>'key' then 'CONFIRMED_TARGET' else 'CANDIDATE_MATCH' end,
  'reasons',jsonb_build_array(case when s->>'confirmed_target'=t->>'key' then 'EXPLICIT_DESTINATION' else 'KNOWN_CONSTRAINTS_COMPATIBLE' end));
end $$;

-- One complete allocation scope and one scenario per call. Presentation filters
-- do not enter this function. Both original pool and remaining-position caps apply.
-- The private caller supplies current captured source/target facts, not a trusted
-- match label. Source snapshot and reviewed version refs bind the computation.
-- P06 must obtain these facts server-side; this pure kernel is not a public API.
create function cp7_wip.check_allocations(positions jsonb, a jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare e jsonb; n jsonb; p jsonb; projection jsonb;used jsonb:='{}';good_used jsonb:='{}';pool_used jsonb:='{}'; seen jsonb:='{}';
 qty numeric;good numeric;cap numeric;k text;pk text; deficits jsonb:='[]';
 matching jsonb;source_facts jsonb;target_facts jsonb;computed jsonb;side jsonb;entry jsonb;repeated bigint;i bigint;
begin
 perform cp7_wip.fields(a,case when a ? 'matching' then array['scenario_id','scope_id','complete_scope','edges','matching']
  else array['scenario_id','scope_id','complete_scope','edges'] end);
 perform cp7_wip.key(a->'scenario_id');perform cp7_wip.key(a->'scope_id');
 if jsonb_typeof(a->'complete_scope') is distinct from 'boolean' or jsonb_typeof(a->'edges') is distinct from 'array' then raise exception 'CP7_WIP_ALLOCATION_SHAPE';end if;
 if positions->>'contract_version' is distinct from 'cp7.wip-position.v1' or positions->>'status' is distinct from 'COMPLETE'
   or not (a->>'complete_scope')::boolean then
  return jsonb_build_object('status','UNKNOWN','reason','ALLOCATION_SCOPE_INCOMPLETE');
 end if;
 if positions->'allocation_review_required'='true'::jsonb then
  return jsonb_build_object('status','UNKNOWN','reason','SOURCE_REVIEW_REQUIRED');end if;
 if not a ? 'matching' then
  return jsonb_build_object('status','UNKNOWN','reason','MATCHING_FACTS_REQUIRED');end if;
 matching:=a->'matching';
 perform cp7_wip.fields(matching,array['snapshot_id','sources','targets']);
 perform cp7_wip.key(matching->'snapshot_id');
 if matching->>'snapshot_id' is distinct from positions->>'snapshot_id' then raise exception 'CP7_WIP_MATCH_SNAPSHOT';end if;
 foreach side in array array[matching->'sources',matching->'targets'] loop
  if jsonb_typeof(side) is distinct from 'array' or jsonb_array_length(side)>10000 then raise exception 'CP7_WIP_MATCH_FACTS';end if;
  -- P19: the first repeated key is one window flag (a growing object was
  -- copied per entry: quadratic at 5000 targets). Each entry's key is still
  -- validated before the repeat check at that entry, so the first refusal
  -- (invalid key or duplicate) is the same entry and code as before.
  select min(f.o) into repeated from(select x.o,row_number()over(partition by x.value->>'key' order by x.o)n
   from jsonb_array_elements(side)with ordinality x(value,o) where x.value->>'key' is not null)f where f.n>1;
  i:=0;
  for entry in select value from jsonb_array_elements(side) loop
   i:=i+1;k:=cp7_wip.key(entry->'key');
   if i=repeated then raise exception 'CP7_WIP_MATCH_DUPLICATE';end if;
  end loop;
 end loop;
 if jsonb_array_length(a->'edges')>10000 then raise exception 'CP7_WIP_LIMIT';end if;
 for e in select value from jsonb_array_elements(a->'edges') loop
  perform cp7_wip.fields(e,array['key','position_key','target_key','size_id','input_pcs','projected_good_pcs','match','refs']);
  k:=cp7_wip.key(e->'key');perform cp7_wip.key(e->'target_key');perform cp7_wip.key(e->'size_id');perform cp7_wip.refs(e->'refs');
  if seen ? k then raise exception 'CP7_WIP_DUPLICATE_ALLOCATION';end if;seen:=seen||jsonb_build_object(k,true);
  select value into n from jsonb_array_elements(positions->'positions') where value->>'key'=cp7_wip.key(e->'position_key');
  qty:=cp7_wip.pcs(e->'input_pcs');good:=cp7_wip.pcs(e->'projected_good_pcs');
  if n is null or n->>'size_id'<>e->>'size_id' or n->'eligible_company_wip'<>'true'::jsonb
    or e->>'match' is null or e->>'match' not in ('CONFIRMED_TARGET','CANDIDATE_MATCH')
    or good>qty then raise exception 'CP7_WIP_INELIGIBLE_ALLOCATION';end if;
  select value into source_facts from jsonb_array_elements(matching->'sources') where value->>'key'=n->>'key';
  select value into target_facts from jsonb_array_elements(matching->'targets') where value->>'key'=e->>'target_key';
  if source_facts is null or target_facts is null then raise exception 'CP7_WIP_MATCH_FACTS';end if;
  if source_facts->>'size_id' is distinct from n->>'size_id' or target_facts->>'size_id' is distinct from e->>'size_id'
    or not ((source_facts->'refs') @> (n->'refs'))
    or not ((e->'refs') @> (source_facts->'refs')) or not ((e->'refs') @> (target_facts->'refs')) then
   raise exception 'CP7_WIP_MATCH_BINDING';end if;
  computed:=cp7_wip.match_target(source_facts,target_facts);
  if computed->>'match' not in ('CONFIRMED_TARGET','CANDIDATE_MATCH') then
   raise exception 'CP7_WIP_INELIGIBLE_ALLOCATION';end if;
  if e->>'match' is distinct from computed->>'match' then raise exception 'CP7_WIP_MATCH_STALE';end if;
  k:=n->>'key';pk:=n->>'pool_key';
  projection:=n->'projection';
  if qty>0 and (projection->>'quality' is distinct from 'SCENARIO') then
   return jsonb_build_object('status','UNKNOWN','reason','YIELD_NOT_SELECTED','position_key',k);end if;
  if qty>0 then
   cap:=div(qty*cp7_wip.pcs(projection->'numerator'),cp7_wip.pcs(projection->'denominator'));
   if good>cap then deficits:=deficits||jsonb_build_array(jsonb_build_object('kind','EDGE_YIELD','key',e->'key','excess_pcs',(good-cap)::text));end if;
  end if;
  used:=used||jsonb_build_object(k,coalesce((used->>k)::numeric,0)+qty);
  good_used:=good_used||jsonb_build_object(k,coalesce((good_used->>k)::numeric,0)+good);
  pool_used:=pool_used||jsonb_build_object(pk,coalesce((pool_used->>pk)::numeric,0)+qty);
 end loop;
 for n in select value from jsonb_array_elements(positions->'positions') loop
  k:=n->>'key';qty:=coalesce((used->>k)::numeric,0);
  if qty>cp7_wip.pcs(n->'remaining_pcs') then deficits:=deficits||jsonb_build_array(jsonb_build_object('kind','POSITION','key',k,'excess_pcs',(qty-cp7_wip.pcs(n->'remaining_pcs'))::text));end if;
  if qty>0 and n->'projection'->>'quality'='SCENARIO' then
   if qty>cp7_wip.pcs(n->'projection'->'eligible_input_pcs') then deficits:=deficits||jsonb_build_array(jsonb_build_object('kind','ELIGIBLE_INPUT','key',k,'excess_pcs',(qty-cp7_wip.pcs(n->'projection'->'eligible_input_pcs'))::text));end if;
   if (good_used->>k)::numeric>cp7_wip.pcs(n->'projection'->'projected_good_pcs') then deficits:=deficits||jsonb_build_array(jsonb_build_object('kind','PROJECTED_GOOD','key',k,'excess_pcs',((good_used->>k)::numeric-cp7_wip.pcs(n->'projection'->'projected_good_pcs'))::text));end if;
  end if;
 end loop;
 for p in select value from jsonb_array_elements(positions->'totals') loop
  pk:=p->>'pool_key';qty:=coalesce((pool_used->>pk)::numeric,0);
  if qty>cp7_wip.pcs(p->'wip_pcs') then deficits:=deficits||jsonb_build_array(jsonb_build_object('kind','POOL','key',pk,'excess_pcs',(qty-cp7_wip.pcs(p->'wip_pcs'))::text));end if;
 end loop;
 return jsonb_build_object('status',case when jsonb_array_length(deficits)=0 then 'FEASIBLE' else 'INFEASIBLE' end,
  'scenario_id',a->'scenario_id','scope_id',a->'scope_id','violations',deficits,
  'edges',coalesce((select jsonb_agg(value order by value->>'key') from jsonb_array_elements(a->'edges')),'[]'::jsonb),
  'matching',matching,'matching_basis','RECOMPUTED_FROM_SAME_SNAPSHOT_FACTS',
  'basis','SIMULATION_NOT_RESERVATION');
end $$;

-- Yield is an explicit versioned scenario input, never an invented production
-- default. Physical input, eligible input and projected GOOD remain separate.
create function cp7_wip.project_yield(positions jsonb,policies jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare policy jsonb;n jsonb;projection jsonb;rows jsonb[]:='{}';k text;
 qty numeric;num numeric;den numeric;
 o bigint;repeated boolean[];by_key jsonb;by_policy jsonb;
begin
 if positions->>'contract_version' is distinct from 'cp7.wip-position.v1' or positions->>'status' is distinct from 'COMPLETE' then
  return jsonb_build_object('status','UNKNOWN','reason','YIELD_SOURCE_INCOMPLETE');end if;
 if jsonb_typeof(policies) is distinct from 'array' or jsonb_array_length(policies)>10000 then raise exception 'CP7_WIP_YIELD_SHAPE';end if;
 -- Linear form of the per-policy scans: a key repeated at an earlier valid
 -- policy is flagged by position, and each policy still sees the first
 -- position with its key. The position map is built where the first lookup
 -- used to scan, so the same input fails at the same point.
 select array_agg(f.r order by f.o)into repeated from(select ordinality o,case when jsonb_typeof(value->'position_key')='string'
   then row_number()over(partition by value->>'position_key' order by ordinality)>1 else false end r
  from jsonb_array_elements(policies)with ordinality)f;
 o:=0;
 for policy in select value from jsonb_array_elements(policies) loop
  o:=o+1;
  perform cp7_wip.fields(policy,array['position_key','eligible_input_pcs','numerator','denominator','basis','assumption_id','refs']);
  k:=cp7_wip.key(policy->'position_key');perform cp7_wip.refs(policy->'refs');
  if repeated[o] then raise exception 'CP7_WIP_YIELD_DUPLICATE';end if;
  if by_key is null then
   select coalesce(jsonb_object_agg(f.k,f.value),'{}')into by_key from(select distinct on(value->>'key')value->>'key' k,value
    from jsonb_array_elements(positions->'positions')with ordinality where value->>'key'is not null order by value->>'key',ordinality)f;
  end if;
  n:=by_key->k;
  qty:=cp7_wip.pcs(policy->'eligible_input_pcs');num:=cp7_wip.pcs(policy->'numerator');den:=cp7_wip.pcs(policy->'denominator');
  if n is null or n->'eligible_company_wip'<>'true'::jsonb or qty>cp7_wip.pcs(n->'remaining_pcs') or den=0 or num>den
    or policy->>'basis' is null or policy->>'basis' not in ('CONFIRMED_PLAN','HISTORY','ASSUMED') then raise exception 'CP7_WIP_YIELD_POLICY';end if;
  if policy->>'basis'='ASSUMED' then perform cp7_wip.key(policy->'assumption_id');
  elsif policy->'assumption_id'<>'null'::jsonb then raise exception 'CP7_WIP_YIELD_ASSUMPTION';end if;
 end loop;
 select coalesce(jsonb_object_agg(value->>'position_key',value),'{}')into by_policy from jsonb_array_elements(policies);
 for n in select value from jsonb_array_elements(positions->'positions') loop
  policy:=by_policy->(n->>'key');
  projection:=jsonb_build_object('quality','UNKNOWN','reason','YIELD_NOT_SELECTED');
  if policy is not null then
   qty:=cp7_wip.pcs(policy->'eligible_input_pcs');num:=cp7_wip.pcs(policy->'numerator');den:=cp7_wip.pcs(policy->'denominator');
   projection:=policy||jsonb_build_object('quality','SCENARIO','projected_good_pcs',div(qty*num,den)::text,
    'expected_loss_pcs',(qty-div(qty*num,den))::text,'not_actual_bs',true);
  end if;
  rows:=array_append(rows,n||jsonb_build_object('projection',projection));
 end loop;
 return jsonb_set(positions,'{positions}',to_jsonb(rows));
end $$;

-- Explicit remaining work and working intervals only. Missing timing stays unknown.
-- This computes one source's earliest working-calendar finish, not a capacity promise.
create function cp7_wip.remaining_eta(p_ready timestamptz, p_deadline timestamptz, work jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' set timezone='UTC' as $$
declare st jsonb; slot jsonb; ready timestamptz:=p_ready; starts timestamptz; ends timestamptz;
 last_end timestamptz; minutes numeric; available numeric; used numeric; assumptions jsonb:='[]';
 stages jsonb:='[]'; seen jsonb:='{}'; k text; uncertain boolean:=false;
begin
 if p_ready is null or not isfinite(p_ready) or p_deadline is null or not isfinite(p_deadline)
  or jsonb_typeof(work) is distinct from 'array' or jsonb_array_length(work)>20 then raise exception 'CP7_WIP_TIMING_SHAPE';end if;
 for st in select value from jsonb_array_elements(work) loop
  perform cp7_wip.fields(st,array['stage','remaining_minutes','basis','assumption_id','calendar_version','windows','refs']);
  k:=cp7_wip.key(st->'stage');perform cp7_wip.refs(st->'refs');
  if seen ? k or st->>'basis' is null or st->>'basis' not in ('CONFIRMED_PLAN','HISTORY','ASSUMED','UNKNOWN') then raise exception 'CP7_WIP_TIMING_STAGE';end if;
  seen:=seen||jsonb_build_object(k,true);
  if st->>'basis'='UNKNOWN' or st->'remaining_minutes'='null'::jsonb or st->'calendar_version'='null'::jsonb or st->'windows'='null'::jsonb then
   return jsonb_build_object('status','UNKNOWN','eta',null,'on_time',null,'reason','REMAINING_STAGE_OR_CALENDAR_UNKNOWN','stage',k);
  end if;
  perform cp7_wip.key(st->'calendar_version');minutes:=cp7_wip.pcs(st->'remaining_minutes');
  if st->>'basis'='ASSUMED' then
   perform cp7_wip.key(st->'assumption_id');assumptions:=assumptions||jsonb_build_array(st->'assumption_id');
  elsif st->'assumption_id'<>'null'::jsonb then raise exception 'CP7_WIP_TIMING_ASSUMPTION';end if;
  uncertain:=uncertain or st->>'basis'<>'CONFIRMED_PLAN';
  if jsonb_typeof(st->'windows') is distinct from 'array' or jsonb_array_length(st->'windows')>1000 then raise exception 'CP7_WIP_TIMING_WINDOWS';end if;
  last_end:=null;
  for slot in select value from jsonb_array_elements(st->'windows') loop
   perform cp7_wip.fields(slot,array['start','end']);
   if jsonb_typeof(slot->'start') is distinct from 'string' or jsonb_typeof(slot->'end') is distinct from 'string'
     or (slot->>'start') !~ '(Z|[+-][0-9]{2}:[0-9]{2})$' or (slot->>'end') !~ '(Z|[+-][0-9]{2}:[0-9]{2})$' then raise exception 'CP7_WIP_TIMING_ZONE';end if;
   starts:=(slot->>'start')::timestamptz;ends:=(slot->>'end')::timestamptz;
   if not isfinite(starts) or not isfinite(ends) or starts>=ends or (last_end is not null and starts<last_end) then raise exception 'CP7_WIP_TIMING_OVERLAP';end if;
   last_end:=ends;
   if minutes>0 and ends>ready then
    starts:=greatest(starts,ready);available:=extract(epoch from ends-starts)/60;
    used:=least(available,minutes);ready:=starts+(used::text||' minutes')::interval;minutes:=minutes-used;
   end if;
  end loop;
  if minutes>0 then return jsonb_build_object('status','UNKNOWN','eta',null,'on_time',null,'reason','CALENDAR_HORIZON_EXHAUSTED','stage',k);end if;
  stages:=stages||jsonb_build_array(jsonb_build_object('stage',k,'eta',ready,'calendar_version',st->'calendar_version','basis',st->'basis','refs',st->'refs'));
 end loop;
 return jsonb_build_object('status',case when uncertain then 'CONDITIONAL' else 'KNOWN' end,'eta',ready,
  'on_time',ready<=p_deadline,'assumption_ids',assumptions,'remaining_stages',stages,
  'basis','WORKING_CALENDAR_ONLY_CAPACITY_CHECK_REQUIRED');
end $$;

-- Current scoped cutting source. All dependent rows share this statement's MVCC
-- snapshot. Explicit non-financial projections; no table-row JSON expansion.
grant select on erp.cutting_pickups,erp.cutting_distribution_batches,erp.cutting_distribution_allocations,
 erp.laundry_deliveries,erp.laundry_delivery_lines,erp.laundry_delivery_batch_size_lines,
 erp.laundry_receipts,erp.laundry_receipt_lines,erp.laundry_receipt_batch_size_lines,
 erp.qc_inspections,erp.qc_inspection_items,erp.bs_cases,erp.rework_orders,
 erp.laundry_failed_wash_attempts,erp.laundry_failed_wash_batch_size_lines,erp.laundry_redispatch_participant_events,erp.bs_resolutions,
 erp.sewing_terminal_events,erp.laundry_claims,erp.bs_case_hold_events,erp.fg_unsourced_receipts_v1,erp.wip_control_flags to cp7_capture;
create function cp7_wip.capture_cutting_sources(p_groups uuid[],p_at timestamptz) returns jsonb
language sql stable security invoker set search_path='' set timezone='Asia/Jakarta' as $$
with clock as materialized(select p_at at),
groups as materialized(
 select g.id,g.po_id,g.row_version::text revision,g.status,g.pattern_id,g.pattern_revision_snapshot,
 g.cut_at,g.picked_up_at,g.material_issue_posted,po.model_id
 from erp.cutting_groups g join erp.production_orders po on po.id=g.po_id cross join clock c
 where g.id=any(p_groups) and g.cut_at<=c.at order by g.id limit 51
),
yields as materialized(
 select y.id,g.id group_id,s.size_id,y.qty_pcs::text qty_pcs,g.revision
 from groups g join erp.cutting_group_rolls r on r.cutting_group_id=g.id
 join erp.cutting_roll_yields y on y.cutting_group_roll_id=r.id
 join erp.cutting_group_size_slots s on s.id=y.size_slot_id
 order by g.id,s.size_id,y.id limit 2001
),
batches as materialized(
 select a.id,b.id batch_id,p.id pickup_id,p.cutting_group_id group_id,p.status,
 p.picked_up_at,p.row_version::text revision,a.cutting_roll_yield_id yield_id,a.qty_pcs::text qty_pcs
 from groups g join erp.cutting_pickups p on p.cutting_group_id=g.id
 join erp.cutting_distribution_batches b on b.pickup_id=p.id
 join erp.cutting_distribution_allocations a on a.batch_id=b.id cross join clock c
 where p.picked_up_at<=c.at order by p.id,b.id,a.id limit 2001
),
deliveries as materialized(
 select l.id,l.cutting_group_id group_id,d.id delivery_id,d.status,d.physical_at,
 d.row_version::text revision,l.qty_sent_pcs::text qty_pcs,
 d.target_wash_process_id,d.target_dyeing_color
 from erp.laundry_delivery_lines l join groups g on g.id=l.cutting_group_id
 join erp.laundry_deliveries d on d.id=l.delivery_id cross join clock c
 where d.physical_at<=c.at order by d.physical_at,d.id,l.id limit 2001
),
delivery_sizes as materialized(
 select s.id,s.delivery_line_id,s.distribution_batch_id batch_id,s.size_id,s.qty_sent_pcs::text qty_pcs,d.group_id
 from erp.laundry_delivery_batch_size_lines s join deliveries d on d.id=s.delivery_line_id
 order by s.id limit 2001
),
receipts as materialized(
 select l.id,l.delivery_line_id,r.id receipt_id,r.status,r.physical_at,r.row_version::text revision,
 l.qty_good_received::text good_pcs,l.qty_bs_laundry::text bs_pcs,l.qty_missing::text missing_pcs,l.qty_stuck::text stuck_pcs,d.group_id
 from deliveries d join erp.laundry_receipt_lines l on l.delivery_line_id=d.id
 join erp.laundry_receipts r on r.id=l.receipt_id cross join clock c
 where r.physical_at<=c.at order by r.physical_at,r.id,l.id limit 2001
),
receipt_sizes as materialized(
 select s.id,s.receipt_line_id,s.delivery_batch_size_line_id delivery_size_id,s.size_id,
 s.qty_good_received::text good_pcs,s.qty_bs_laundry::text bs_pcs,r.group_id
 from erp.laundry_receipt_batch_size_lines s join receipts r on r.id=s.receipt_line_id order by s.id limit 2001
),
qc as materialized(
 select i.id,i.cutting_group_id group_id,q.id inspection_id,q.status,q.physical_at,q.row_version::text revision,
 i.source_laundry_receipt_line_id receipt_line_id,i.source_laundry_receipt_batch_size_line_id receipt_size_id,
 i.final_product_id,p.size_id,coalesce(p.identity_root_id,p.id) product_root,
 i.qty_good_pcs::text good_pcs,i.qty_bs_pcs::text bs_pcs
 from erp.qc_inspection_items i join groups g on g.id=i.cutting_group_id
 join erp.qc_inspections q on q.id=i.inspection_id join erp.products p on p.id=i.final_product_id cross join clock c
 where q.physical_at<=c.at order by q.physical_at,q.id,i.id limit 2001
),
bs as materialized(
 select b.id,b.cutting_group_id group_id,b.qc_item_id,b.product_id,p.size_id,b.source_laundry_receipt_line_id receipt_line_id,
 b.source_laundry_bs_allocation_id receipt_size_id,b.qty_pcs::text qty_pcs,b.status,b.detected_at_stage,b.physical_at,b.row_version::text revision
 from erp.bs_cases b join groups g on g.id=b.cutting_group_id left join erp.products p on p.id=b.product_id cross join clock c
 where b.physical_at<=c.at order by b.physical_at,b.id limit 2001
),
reworks as materialized(
 select r.id,r.bs_case_id,r.qty_sent::text sent_pcs,r.qty_good_returned::text good_pcs,r.qty_bs_returned::text bs_pcs,
 r.physical_sent_at,r.completed_at,r.status,r.row_version::text revision,r.good_fg_lot_id,r.cost_posted completion_posted
 from erp.rework_orders r join bs b on b.id=r.bs_case_id cross join clock c
 where r.physical_sent_at<=c.at order by r.physical_sent_at,r.id limit 2001
),
resolutions as materialized(
 select r.id,r.bs_case_id,r.resolution_type,r.qty_pcs::text qty_pcs,r.source_rework_order_id,r.physical_at
 from erp.bs_resolutions r join bs b on b.id=r.bs_case_id cross join clock c
 where r.physical_at<=c.at order by r.physical_at,r.id limit 2001
),
holds as materialized(
 select h.id,h.bs_case_id,h.action,h.resulting_status,h.physical_at,h.created_at
 from erp.bs_case_hold_events h join bs b on b.id=h.bs_case_id cross join clock c
 where h.physical_at<=c.at order by h.id limit 2001
),
bs_fg as materialized(
 select x.id,x.bs_case_id,x.bs_resolution_id,x.qty_pcs::text qty_pcs,x.status,x.lot_id,x.quality_grade,x.physical_at
 from erp.fg_unsourced_receipts_v1 x join bs b on b.id=x.bs_case_id cross join clock c
 where x.physical_at<=c.at order by x.id limit 2001
),
failed as materialized(
 select a.id,a.receipt_line_id,a.delivery_id,a.custody_outcome,a.qty_attempted_pcs::text qty_pcs
 from erp.laundry_failed_wash_attempts a join receipts r on r.id=a.receipt_line_id order by a.id limit 2001
),
failed_sizes as materialized(
 select x.id,x.attempt_id,x.delivery_batch_size_line_id delivery_size_id,x.size_id,x.qty_attempted_pcs::text qty_pcs
 from erp.laundry_failed_wash_batch_size_lines x join failed a on a.id=x.attempt_id order by x.id limit 2001
),
redispatch as materialized(
 select e.id,e.event_type,e.source_delivery_batch_size_line_id source_id,e.successor_delivery_batch_size_line_id successor_id,
 e.qty_pcs::text qty_pcs,e.source_offset_pcs,e.successor_offset_pcs,e.releases_allocation_event_id,e.released_delivery_id
 from erp.laundry_redispatch_participant_events e where e.source_delivery_batch_size_line_id in (select id from delivery_sizes)
  or e.successor_delivery_batch_size_line_id in (select id from delivery_sizes) order by e.created_at,e.id limit 2001
),
claims as materialized(
 select x.id,x.delivery_id,x.receipt_line_id,x.claim_type,x.qty_claimed::text qty_pcs,x.status,
 x.opened_at,x.resolved_at,x.row_version::text revision,
 (select count(*) from erp.laundry_delivery_lines claim_line where claim_line.delivery_id=x.delivery_id) delivery_line_count
 from erp.laundry_claims x cross join clock c where x.delivery_id in (select delivery_id from deliveries) and x.opened_at<=c.at order by x.id limit 2001
),
sewing as materialized(
 select e.id,e.cutting_group_id group_id,e.qty_signed::text qty_signed,e.event_kind,e.reversal_of_id,e.physical_at,e.row_version::text revision
 from erp.sewing_terminal_events e join groups g on g.id=e.cutting_group_id cross join clock c where e.physical_at<=c.at order by e.physical_at,e.id limit 2001
),
flags as materialized(
 select x.id,x.cutting_group_id group_id,x.flag_type,x.status,x.row_version::text revision,x.created_at,x.resolved_at
 from erp.wip_control_flags x join groups g on g.id=x.cutting_group_id cross join clock c
 where x.created_at<=c.at order by x.id limit 2001
),
source as (select jsonb_build_object(
 'groups',coalesce((select jsonb_agg(to_jsonb(x) order by id) from groups x),'[]'::jsonb),
 'yields',coalesce((select jsonb_agg(to_jsonb(x) order by id) from yields x),'[]'::jsonb),
 'batches',coalesce((select jsonb_agg(to_jsonb(x) order by id) from batches x),'[]'::jsonb),
 'deliveries',coalesce((select jsonb_agg(to_jsonb(x) order by id) from deliveries x),'[]'::jsonb),
 'delivery_sizes',coalesce((select jsonb_agg(to_jsonb(x) order by id) from delivery_sizes x),'[]'::jsonb),
 'receipts',coalesce((select jsonb_agg(to_jsonb(x) order by id) from receipts x),'[]'::jsonb),
 'receipt_sizes',coalesce((select jsonb_agg(to_jsonb(x) order by id) from receipt_sizes x),'[]'::jsonb),
 'qc',coalesce((select jsonb_agg(to_jsonb(x) order by id) from qc x),'[]'::jsonb),
 'bs',coalesce((select jsonb_agg(to_jsonb(x) order by id) from bs x),'[]'::jsonb),
 'reworks',coalesce((select jsonb_agg(to_jsonb(x) order by id) from reworks x),'[]'::jsonb),
 'resolutions',coalesce((select jsonb_agg(to_jsonb(x) order by id) from resolutions x),'[]'::jsonb),
 'holds',coalesce((select jsonb_agg(to_jsonb(x) order by id) from holds x),'[]'::jsonb),
 'bs_fg',coalesce((select jsonb_agg(to_jsonb(x) order by id) from bs_fg x),'[]'::jsonb),
 'failed',coalesce((select jsonb_agg(to_jsonb(x) order by id) from failed x),'[]'::jsonb),
 'failed_sizes',coalesce((select jsonb_agg(to_jsonb(x) order by id) from failed_sizes x),'[]'::jsonb),
 'redispatch',coalesce((select jsonb_agg(to_jsonb(x) order by id) from redispatch x),'[]'::jsonb),
 'claims',coalesce((select jsonb_agg(to_jsonb(x) order by id) from claims x),'[]'::jsonb),
 'sewing',coalesce((select jsonb_agg(to_jsonb(x) order by id) from sewing x),'[]'::jsonb),
 'flags',coalesce((select jsonb_agg(to_jsonb(x) order by id) from flags x),'[]'::jsonb)) facts)
select jsonb_build_object('contract_version','cp7.cutting-facts.v1','knowledge_mode','CURRENT',
 'captured_at',(select at from clock),'scope',to_jsonb(p_groups),'facts',facts,
 'status',case when jsonb_array_length(facts->'groups')=cardinality(p_groups)
  and not exists(select 1 from jsonb_each(facts) where key<>'groups' and jsonb_array_length(value)>2000) then 'COMPLETE' else 'INCOMPLETE' end)
from source
$$;
create function cp7_wip.capture_cutting_sources(p_groups uuid[]) returns jsonb
language sql stable security invoker set search_path='' as $$
 select cp7_wip.capture_cutting_sources(p_groups,clock_timestamp())
$$;

-- Range records prove reuse of the same input. They never add a new pool.
create function cp7_wip.redispatch_valid(f jsonb) returns boolean
language sql immutable security invoker set search_path='' as $$
with events as(select * from jsonb_to_recordset(f->'redispatch') as x(id uuid,event_type text,source_id uuid,successor_id uuid,
 qty_pcs numeric,source_offset_pcs bigint,successor_offset_pcs bigint,releases_allocation_event_id uuid)),
active as(select * from events e where e.event_type='ALLOCATE' and not exists(select 1 from events z where z.event_type='RELEASE' and z.releases_allocation_event_id=e.id)),
sizes as(select * from jsonb_to_recordset(f->'delivery_sizes') as x(id uuid,delivery_line_id uuid,batch_id uuid,size_id uuid,qty_pcs numeric,group_id uuid)),
deliveries as(select * from jsonb_to_recordset(f->'deliveries') as x(id uuid,delivery_id uuid,status text)),
failed as(select * from jsonb_to_recordset(f->'failed') as x(id uuid,receipt_line_id uuid,custody_outcome text)),
failed_sizes as(select * from jsonb_to_recordset(f->'failed_sizes') as x(attempt_id uuid,delivery_size_id uuid,qty_pcs numeric)),
receipts as(select * from jsonb_to_recordset(f->'receipts') as x(id uuid,status text)),
invalid as(
 select e.id from active e left join sizes s on s.id=e.source_id left join sizes d on d.id=e.successor_id
 left join deliveries sd on sd.id=s.delivery_line_id left join deliveries dd on dd.id=d.delivery_line_id
 where s.id is null or d.id is null or s.batch_id is distinct from d.batch_id or s.size_id is distinct from d.size_id
  or s.group_id is distinct from d.group_id or sd.status is distinct from 'REVERSED' or dd.status is null or dd.status in ('DRAFT','REVERSED')
  or e.qty_pcs is null or e.source_offset_pcs is null or e.successor_offset_pcs is null
  or e.qty_pcs<=0 or e.source_offset_pcs<0 or e.successor_offset_pcs<0
  or e.source_offset_pcs+e.qty_pcs>s.qty_pcs or e.successor_offset_pcs+e.qty_pcs>d.qty_pcs
  or not exists(select 1 from failed_sizes fs join failed fa on fa.id=fs.attempt_id join receipts r on r.id=fa.receipt_line_id
    where fs.delivery_size_id=s.id and fs.qty_pcs=s.qty_pcs and fa.custody_outcome='RETURN_UNPROCESSED' and r.status='POSTED')
),overlap as(
 select e.id from active e join active other on other.id>e.id
 where (e.source_id=other.source_id and numrange(e.source_offset_pcs,e.source_offset_pcs+e.qty_pcs,'[)') && numrange(other.source_offset_pcs,other.source_offset_pcs+other.qty_pcs,'[)'))
  or (e.successor_id=other.successor_id and numrange(e.successor_offset_pcs,e.successor_offset_pcs+e.qty_pcs,'[)') && numrange(other.successor_offset_pcs,other.successor_offset_pcs+other.qty_pcs,'[)'))
)
select not exists(select 1 from invalid) and not exists(select 1 from overlap)
$$;

-- Graph construction from the explicit current-cutting capture. Group + exact
-- size is the shared pool while sewing lacks child/size completion attribution.
-- Batch IDs remain provenance, not independent copies of that pool's balance.
create function cp7_wip.transition(g jsonb,pool text,src text,dst text,stage text,qty numeric,ref jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare n jsonb;ev jsonb;key text;
begin
 if qty=0 then return g;end if;
 if qty<0 or trunc(qty)<>qty then raise exception 'CP7_WIP_TRANSITION_QUANTITY';end if;
 perform cp7_wip.refs(jsonb_build_array(ref));
 select value into n from jsonb_array_elements(g->'nodes') where value->>'key'=dst;
 if n is null then
  g:=jsonb_set(g,'{nodes}',g->'nodes'||jsonb_build_array(jsonb_build_object('key',dst,'pool_key',pool,'stage',stage,'refs',jsonb_build_array(ref))));
 elsif n->>'pool_key'<>pool or n->>'stage'<>stage then raise exception 'CP7_WIP_TRANSITION_NODE';end if;
 key:='T:'||jsonb_array_length(g->'events')::text;
 ev:=jsonb_build_object('key',key,'pool_key',pool,'from_node',src,'to_node',dst,'qty_pcs',qty::text,
  'ordinal',(jsonb_array_length(g->'events')+1)::text,'reverses_key',null,'refs',jsonb_build_array(ref));
 return jsonb_set(g,'{events}',g->'events'||jsonb_build_array(ev));
end $$;
create function cp7_wip.ref(kind text,id text,revision text) returns jsonb
language sql immutable security invoker set search_path='' as $$
 select jsonb_build_object('kind',kind,'id',id,'revision',revision)
$$;
create function cp7_wip.normalize_cutting(capture jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare f jsonb:=capture->'facts';g jsonb;grp jsonb;y record;d jsonb;s jsonb;r jsonb;q jsonb;b jsonb;rw jsonb;
 pool text;sz text;src text;dst text;ref jsonb;claim jsonb;line_id text;qty numeric;amt numeric;cnt integer;result jsonb;
 bsnodes jsonb:='{}';scope_at timestamptz:=(capture->>'captured_at')::timestamptz;
 pools jsonb[]:='{}';nodes jsonb[]:='{}';events jsonb[]:='{}';ne integer:=0;n jsonb;t jsonb;k text;h integer;here jsonb;
 nm jsonb[]:=array_fill('{}'::jsonb,array[1024]);dl jsonb[]:=array_fill('{}'::jsonb,array[1024]);rl jsonb[]:=array_fill('{}'::jsonb,array[1024]);
 fresh jsonb[];sizes jsonb;cases jsonb[]:='{}';by_group jsonb;by_yield_group jsonb;by_line jsonb;lineage jsonb;failed_lines jsonb;
 by_receipt jsonb;by_delivery jsonb;reversed_qc jsonb;reversed_receipts jsonb;
begin
 -- Linear form. The graph is built in arrays with a hashed node map and every
 -- move still goes through cp7_wip.transition on a graph that holds only the
 -- destination node, so each move checks and fails exactly as before. Derived
 -- delivery/receipt rows are kept per source line in hashed buckets, in their
 -- original order. Fact lookups use maps built where the first scan used to
 -- run; each map keeps the rows the scan matched, in source order, so the same
 -- rows are cast, summed and sorted and the same input fails at the same point.
 if capture->>'contract_version' is distinct from 'cp7.cutting-facts.v1' or capture->>'status' is distinct from 'COMPLETE' then
  return jsonb_build_object('status','UNKNOWN','reason','SOURCE_CAPTURE_INCOMPLETE');
 end if;
 if exists(select 1 from jsonb_array_elements(f->'groups') where value->'material_issue_posted'<>'true'::jsonb) then
  return jsonb_build_object('status','UNKNOWN','reason','CUTTING_NOT_POSTED');
 end if;
 if not cp7_wip.redispatch_valid(f) then
  return jsonb_build_object('status','CONFLICT','reason','REDISPATCH_RANGE_LINEAGE_CONFLICT');
 end if;
 for y in select value->>'group_id' group_id,value->>'size_id' size_id,sum((value->>'qty_pcs')::numeric) qty
  from jsonb_array_elements(f->'yields') group by 1,2 order by 1,2 loop
  if by_group is null then
   select coalesce(jsonb_object_agg(z.k,z.value),'{}') into by_group from(select distinct on(value->>'id')value->>'id' k,value
    from jsonb_array_elements(f->'groups') with ordinality where value->>'id' is not null order by value->>'id',ordinality)z;
  end if;
  grp:=by_group->y.group_id;
  pool:='CUT:'||y.group_id||':'||y.size_id;ref:=cp7_wip.ref('erp.cutting_groups',y.group_id,grp->>'revision');
  pools:=array_append(pools,jsonb_build_object('key',pool,'size_id',y.size_id,'input_pcs',y.qty::text,
   'origin','CUTTING','ownership','COMPANY','refs',jsonb_build_array(ref)));
  k:=pool||':PRE';n:=nm[(hashtext(k)&1023)+1]->k;
  t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,null,k,case when grp->'picked_up_at'='null'::jsonb then 'CUT_UNASSIGNED' else 'SEWING_UNRESOLVED' end,y.qty,ref);
  if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
   if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
  if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
 end loop;
 if exists(select 1 from jsonb_array_elements(f->'groups') x where not exists(select 1 from jsonb_array_elements(f->'yields') z where z->>'group_id'=x->>'id')) then
  return jsonb_build_object('status','UNKNOWN','reason','CUTTING_YIELDS_MISSING');
 end if;
 -- Normalize each active delivery's exact sizes. Legacy parent-only records
 -- resolve only when the entire group has one exact size, never by proportion.
 for d in select value from jsonb_array_elements(f->'deliveries') where value->>'status' not in ('DRAFT','REVERSED') order by value->>'physical_at',value->>'id' loop
  if by_line is null then
   select coalesce(jsonb_object_agg(z.k,z.v),'{}') into by_line from(select value->>'delivery_line_id' k,jsonb_agg(value order by ordinality) v
    from jsonb_array_elements(f->'delivery_sizes') with ordinality where value->>'delivery_line_id' is not null group by 1)z;
  end if;
  sizes:=coalesce(by_line->(d->>'id'),'[]'::jsonb);fresh:='{}';
  select count(*),coalesce(sum((value->>'qty_pcs')::numeric),0) into cnt,qty from jsonb_array_elements(sizes);
  if cnt=0 then
   if by_yield_group is null then
    select coalesce(jsonb_object_agg(z.k,jsonb_build_array(z.c,z.m)),'{}') into by_yield_group from(select value->>'group_id' k,
     count(distinct value->>'size_id') c,min(value->>'size_id') m from jsonb_array_elements(f->'yields') where value->>'group_id' is not null group by 1)z;
   end if;
   cnt:=coalesce((by_yield_group->(d->>'group_id')->>0)::integer,0);sz:=by_yield_group->(d->>'group_id')->>1;
   if cnt<>1 then return jsonb_build_object('status','UNKNOWN','reason','DELIVERY_EXACT_SIZE_UNPROVEN','source_id',d->'id');end if;
   fresh:=array_append(fresh,jsonb_build_object('id',d->>'id','line',d->>'id','size',sz,'group',d->>'group_id','qty',d->>'qty_pcs'));
  else
   if qty<>(d->>'qty_pcs')::numeric then return jsonb_build_object('status','CONFLICT','reason','DELIVERY_SIZE_TOTAL_MISMATCH','source_id',d->'id');end if;
   for s in select value from jsonb_array_elements(sizes) order by value->>'id' loop
    -- An explicit batch reference must point to posted distribution of that size.
    if lineage is null then
     select coalesce(jsonb_object_agg(z.k,true),'{}') into lineage from(select distinct jsonb_build_array(batch_entry->>'batch_id',batch_entry->>'group_id',yield_entry->>'size_id')::text k
      from jsonb_array_elements(f->'batches') batch_entry join jsonb_array_elements(f->'yields') yield_entry on yield_entry->>'id'=batch_entry->>'yield_id'
      where batch_entry->>'status'='POSTED' and batch_entry->>'batch_id' is not null and batch_entry->>'group_id' is not null and yield_entry->>'size_id' is not null)z;
    end if;
    if not coalesce(lineage ? jsonb_build_array(s->>'batch_id',d->>'group_id',s->>'size_id')::text and s->>'batch_id' is not null
      and d->>'group_id' is not null and s->>'size_id' is not null,false) then
     return jsonb_build_object('status','CONFLICT','reason','DELIVERY_BATCH_LINEAGE_UNPROVEN','source_id',s->'id');end if;
    fresh:=array_append(fresh,jsonb_build_object('id',s->>'id','line',d->>'id','size',s->>'size_id','group',d->>'group_id','qty',s->>'qty_pcs'));
   end loop;
  end if;
  if d->>'id' is not null and cardinality(fresh)>0 then
   h:=(hashtext(d->>'id')&1023)+1;here:=dl[h]||jsonb_build_object(d->>'id',coalesce(dl[h]->(d->>'id'),'[]'::jsonb)||to_jsonb(fresh));dl[h]:=here;
  end if;
  for s in select value from jsonb_array_elements(coalesce(dl[(hashtext(d->>'id')&1023)+1]->(d->>'id'),'[]'::jsonb)) order by value->>'id' loop
   sz:=s->>'size';pool:='CUT:'||(d->>'group_id')||':'||sz;ref:=cp7_wip.ref('erp.laundry_delivery_lines',d->>'id',d->>'revision');
   k:='D:'||(d->>'id')||':'||sz;n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,pool||':PRE',k,'LAUNDRY_OUTSTANDING',(s->>'qty')::numeric,ref);
   if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
    if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
   if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
  end loop;
 end loop;
 for r in select value from jsonb_array_elements(f->'receipts') where value->>'status'='POSTED' order by value->>'physical_at',value->>'id' loop
  if failed_lines is null then
   select coalesce(jsonb_object_agg(z.k,true),'{}') into failed_lines from(select distinct value->>'receipt_line_id' k
    from jsonb_array_elements(f->'failed') where value->>'receipt_line_id' is not null)z;
  end if;
  if coalesce(failed_lines ? (r->>'id'),false) then
   if (r->>'good_pcs')::numeric+(r->>'bs_pcs')::numeric+(r->>'missing_pcs')::numeric+(r->>'stuck_pcs')::numeric<>0 then
    return jsonb_build_object('status','CONFLICT','reason','FAILED_ATTEMPT_IS_NOT_PHYSICAL_RECEIPT','source_id',r->'id');end if;
   -- Retry remains in the existing delivery. Full unprocessed returns have a
   -- REVERSED delivery, so the original resource remains in the shared PRE pool.
   -- Multiple failed invoices and redispatches never manufacture extra input.
   continue;
  end if;
  if by_receipt is null then
   select coalesce(jsonb_object_agg(z.k,z.v),'{}') into by_receipt from(select value->>'receipt_line_id' k,jsonb_agg(value order by ordinality) v
    from jsonb_array_elements(f->'receipt_sizes') with ordinality where value->>'receipt_line_id' is not null group by 1)z;
  end if;
  sizes:=coalesce(by_receipt->(r->>'id'),'[]'::jsonb);fresh:='{}';
  select count(*),coalesce(sum((value->>'good_pcs')::numeric+(value->>'bs_pcs')::numeric),0) into cnt,qty
   from jsonb_array_elements(sizes);
  if cnt=0 then
   select count(distinct value->>'size'),min(value->>'size') into cnt,sz from jsonb_array_elements(coalesce(dl[(hashtext(r->>'delivery_line_id')&1023)+1]->(r->>'delivery_line_id'),'[]'::jsonb));
   if cnt<>1 then return jsonb_build_object('status','UNKNOWN','reason','RECEIPT_EXACT_SIZE_UNPROVEN','source_id',r->'id');end if;
   fresh:=array_append(fresh,jsonb_build_object('id',r->>'id','line',r->>'id','size',sz,'group',r->>'group_id','good',r->>'good_pcs','bs',r->>'bs_pcs'));
  else
   if qty<>(r->>'good_pcs')::numeric+(r->>'bs_pcs')::numeric
     or (select coalesce(sum((value->>'good_pcs')::numeric),0) from jsonb_array_elements(sizes))<>(r->>'good_pcs')::numeric
     or (select coalesce(sum((value->>'bs_pcs')::numeric),0) from jsonb_array_elements(sizes))<>(r->>'bs_pcs')::numeric then return jsonb_build_object('status','CONFLICT','reason','RECEIPT_SIZE_TOTAL_MISMATCH','source_id',r->'id');end if;
   for s in select value from jsonb_array_elements(sizes) order by value->>'id' loop
    if not exists(select 1 from jsonb_array_elements(coalesce(dl[(hashtext(r->>'delivery_line_id')&1023)+1]->(r->>'delivery_line_id'),'[]'::jsonb)) delivery_entry where delivery_entry->>'id'=s->>'delivery_size_id' and delivery_entry->>'line'=r->>'delivery_line_id' and delivery_entry->>'size'=s->>'size_id') then
     return jsonb_build_object('status','CONFLICT','reason','RECEIPT_DELIVERY_LINEAGE_MISMATCH','source_id',s->'id');end if;
    fresh:=array_append(fresh,jsonb_build_object('id',s->>'id','line',r->>'id','size',s->>'size_id','group',r->>'group_id','good',s->>'good_pcs','bs',s->>'bs_pcs'));
   end loop;
  end if;
  if r->>'id' is not null and cardinality(fresh)>0 then
   h:=(hashtext(r->>'id')&1023)+1;here:=rl[h]||jsonb_build_object(r->>'id',coalesce(rl[h]->(r->>'id'),'[]'::jsonb)||to_jsonb(fresh));rl[h]:=here;
  end if;
  for s in select value from jsonb_array_elements(coalesce(rl[(hashtext(r->>'id')&1023)+1]->(r->>'id'),'[]'::jsonb)) order by value->>'id' loop
   sz:=s->>'size';pool:='CUT:'||(r->>'group_id')||':'||sz;src:='D:'||(r->>'delivery_line_id')||':'||sz;
   ref:=cp7_wip.ref('erp.laundry_receipt_lines',r->>'id',r->>'revision');
   k:='R:'||(r->>'id')||':'||sz;n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'AWAIT_QC',(s->>'good')::numeric,ref);
   if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
    if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
   if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
   k:='LBS:'||(r->>'id')||':'||sz;n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'BS',(s->>'bs')::numeric,ref);
   if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
    if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
   if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
  end loop;
  if (r->>'missing_pcs')::numeric+(r->>'stuck_pcs')::numeric>0 then
   return jsonb_build_object('status','UNKNOWN','reason','LEGACY_RECEIPT_CUSTODY_REQUIRES_RECONCILIATION','source_id',r->'id');
  end if;
 end loop;
 -- Missing/stuck claims consume unreturned input once. A financial settlement
 -- does not recreate the lost/held goods. Rejected claims cease to reserve it.
 for claim in select value from jsonb_array_elements(f->'claims') where value->>'claim_type' in ('MISSING','STUCK')
  and value->>'status'<>'REJECTED' order by value->>'opened_at',value->>'id' loop
  line_id:=null;
  if claim->'receipt_line_id'<>'null'::jsonb then
   return jsonb_build_object('status','CONFLICT','reason','MISSING_STUCK_CLAIM_REQUIRES_DELIVERY_SOURCE','source_id',claim->'id');
  end if;
  if by_delivery is null then
   select coalesce(jsonb_object_agg(z.k,jsonb_build_array(z.c,z.m)),'{}') into by_delivery from(select value->>'delivery_id' k,count(*) c,min(value->>'id') m
    from jsonb_array_elements(f->'deliveries') where value->>'delivery_id' is not null group by 1)z;
  end if;
  cnt:=coalesce((by_delivery->(claim->>'delivery_id')->>0)::integer,0);line_id:=by_delivery->(claim->>'delivery_id')->>1;
  if cnt<>1 or (claim->>'delivery_line_count')::int<>1 then line_id:=null;end if;
  select count(distinct value->>'size'),min(value->>'size'),min(value->>'group') into cnt,sz,pool
   from jsonb_array_elements(coalesce(dl[(hashtext(line_id)&1023)+1]->(line_id),'[]'::jsonb));
  if line_id is null or cnt<>1 then return jsonb_build_object('status','UNKNOWN','reason','CLAIM_EXACT_SIZE_OR_SOURCE_UNPROVEN','source_id',claim->'id');end if;
  pool:='CUT:'||pool||':'||sz;src:='D:'||line_id||':'||sz;
  k:='CLAIM:'||(claim->>'id');n:=nm[(hashtext(k)&1023)+1]->k;
  t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,claim->>'claim_type',(claim->>'qty_pcs')::numeric,cp7_wip.ref('erp.laundry_claims',claim->>'id',claim->>'revision'));
  if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
   if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
  if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
 end loop;
 for q in select value from jsonb_array_elements(f->'qc') where value->>'status'='POSTED' order by value->>'physical_at',value->>'id' loop
  sz:=q->>'size_id';pool:='CUT:'||(q->>'group_id')||':'||sz;src:=pool||':PRE';
  if q->'receipt_line_id'<>'null'::jsonb then
   if not exists(select 1 from jsonb_array_elements(coalesce(rl[(hashtext(q->>'receipt_line_id')&1023)+1]->(q->>'receipt_line_id'),'[]'::jsonb)) receipt_entry where receipt_entry->>'line'=q->>'receipt_line_id' and receipt_entry->>'size'=sz
     and (q->'receipt_size_id'='null'::jsonb or receipt_entry->>'id'=q->>'receipt_size_id')) then
    return jsonb_build_object('status','CONFLICT','reason','QC_RECEIPT_LINEAGE_MISMATCH','source_id',q->'id');end if;
   src:='R:'||(q->>'receipt_line_id')||':'||sz;
  elsif q->'receipt_size_id'<>'null'::jsonb then return jsonb_build_object('status','CONFLICT','reason','QC_RECEIPT_PARENT_MISSING','source_id',q->'id');end if;
  ref:=cp7_wip.ref('erp.qc_inspection_items',q->>'id',q->>'revision');
  k:='FGQC:'||(q->>'id');n:=nm[(hashtext(k)&1023)+1]->k;
  t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'FG',(q->>'good_pcs')::numeric,ref);
  if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
   if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
  if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
  k:='BSQC:'||(q->>'id');n:=nm[(hashtext(k)&1023)+1]->k;
  t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'BS',(q->>'bs_pcs')::numeric,ref);
  if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
   if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
  if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
 end loop;
 -- Cases identify original BS; resolutions/rework returns do not add cut input.
 for b in select value from jsonb_array_elements(f->'bs') order by value->>'physical_at',value->>'id' loop
  -- Ordinary source reversal retains the cancelled case as history. Keep it
  -- in the captured dependency set, but do not recreate its physical slice.
  -- A cancellation may only suppress a linked source that was also reversed.
  if b->>'status'='CANCELLED' then
   if b->'qc_item_id'<>'null'::jsonb then
    if reversed_qc is null then
     select coalesce(jsonb_object_agg(z.k,true),'{}') into reversed_qc from(select distinct jsonb_build_array(value->>'id',value->>'group_id')::text k
      from jsonb_array_elements(f->'qc') where value->>'status'='REVERSED' and value->>'id' is not null and value->>'group_id' is not null)z;
    end if;
    if not coalesce(reversed_qc ? jsonb_build_array(b->>'qc_item_id',b->>'group_id')::text and b->>'qc_item_id' is not null and b->>'group_id' is not null,false) then
     return jsonb_build_object('status','CONFLICT','reason','CANCELLED_BS_SOURCE_UNPROVEN','source_id',b->'id');end if;
   elsif b->'receipt_line_id'<>'null'::jsonb then
    if reversed_receipts is null then
     select coalesce(jsonb_object_agg(z.k,true),'{}') into reversed_receipts from(select distinct jsonb_build_array(value->>'id',value->>'group_id')::text k
      from jsonb_array_elements(f->'receipts') where value->>'status'='REVERSED' and value->>'id' is not null and value->>'group_id' is not null)z;
    end if;
    if not coalesce(reversed_receipts ? jsonb_build_array(b->>'receipt_line_id',b->>'group_id')::text and b->>'receipt_line_id' is not null and b->>'group_id' is not null,false) then
     return jsonb_build_object('status','CONFLICT','reason','CANCELLED_BS_SOURCE_UNPROVEN','source_id',b->'id');end if;
   else return jsonb_build_object('status','UNKNOWN','reason','CANCELLED_BS_SOURCE_UNPROVEN','source_id',b->'id');end if;
   continue;
  end if;
  sz:=b->>'size_id';
  if sz is null then
   if by_yield_group is null then
    select coalesce(jsonb_object_agg(z.k,jsonb_build_array(z.c,z.m)),'{}') into by_yield_group from(select value->>'group_id' k,
     count(distinct value->>'size_id') c,min(value->>'size_id') m from jsonb_array_elements(f->'yields') where value->>'group_id' is not null group by 1)z;
   end if;
   cnt:=coalesce((by_yield_group->(b->>'group_id')->>0)::integer,0);sz:=by_yield_group->(b->>'group_id')->>1;
   if cnt<>1 then return jsonb_build_object('status','UNKNOWN','reason','BS_EXACT_SIZE_UNPROVEN','source_id',b->'id');end if;end if;
  pool:='CUT:'||(b->>'group_id')||':'||sz;
  if b->'qc_item_id'<>'null'::jsonb then src:='BSQC:'||(b->>'qc_item_id');
  elsif b->'receipt_line_id'<>'null'::jsonb then src:='LBS:'||(b->>'receipt_line_id')||':'||sz;
  else
   src:='BSMANUAL:'||(b->>'id');
   k:=src;n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,pool||':PRE',k,'BS',(b->>'qty_pcs')::numeric,cp7_wip.ref('erp.bs_cases',b->>'id',b->>'revision'));
   if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
    if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
   if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
  end if;
  if not coalesce((nm[(hashtext(src)&1023)+1]->src)->>'pool_key'=pool,false) then
   return jsonb_build_object('status','CONFLICT','reason','BS_SOURCE_LINEAGE_MISMATCH','source_id',b->'id');end if;
  -- Several laundry cases may share a size-level receipt node. Give each case
  -- its own slice before HOLD/rework; never hold the whole shared receipt twice.
  dst:='BSCASE:'||(b->>'id');
  k:=dst;n:=nm[(hashtext(k)&1023)+1]->k;
  t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'BS',(b->>'qty_pcs')::numeric,cp7_wip.ref('erp.bs_cases',b->>'id',b->>'revision'));
  if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
   if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
  if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
  cases:=array_append(cases,jsonb_build_object(b->>'id',jsonb_build_object('pool',pool,'node',dst)));
 end loop;
 -- The last case with an id names its node, as successive merges did.
 select coalesce(jsonb_object_agg(z.key,z.value),'{}') into bsnodes from(select distinct on(e.key)e.key,e.value
  from unnest(cases) with ordinality c(item,o) cross join jsonb_each(c.item) e order by e.key,c.o desc)z;
 g:=jsonb_build_object('contract_version','cp7.wip-graph.v1','snapshot_id',capture->>'captured_at','complete',true,
  'pools',to_jsonb(pools),'nodes',to_jsonb(nodes),'events',to_jsonb(events));
 g:=cp7_wip.settle_bs(g,f,bsnodes,scope_at);
 if g ? 'status' then return g;end if;
 result:=cp7_wip.reconcile(g);
 return result||jsonb_build_object('graph',g,'source_basis','CUTTING_GROUP_EXACT_SIZE_SHARED_POOL',
  'fg_basis','PRODUCTION_DISPOSITION_NOT_CURRENT_ON_HAND','sewing_detail','SUBSTAGE_NOT_ALLOCATABLE_FROM_GROUP_EVENTS',
  'scope','SELECTED_CUTTING_GROUPS_ONLY_NO_OPENING_OR_NON_PO',
  'partial_rework_basis','REPORTED_RETURN_REMAINS_WIP_UNTIL_COMPLETION_POSTED',
  'allocation_review_required',exists(select 1 from jsonb_array_elements(f->'flags') where value->>'status'='OPEN' and value->>'flag_type' in ('PENDING_CORRECTION','PENDING_REVERSAL')),
  'attention',coalesce((select jsonb_agg(value order by value->>'id') from jsonb_array_elements(f->'flags') where value->>'status'='OPEN'),'[]'::jsonb),
  'rewash_review_required',exists(select 1 from jsonb_array_elements(f->'failed') attempt_entry join jsonb_array_elements(f->'receipts') receipt_entry on receipt_entry->>'id'=attempt_entry->>'receipt_line_id' where receipt_entry->>'status'='POSTED'),
  'rewash_basis','RETRY_REMAINS_IN_DELIVERY_RETURN_UNPROCESSED_REUSES_ORIGINAL_POOL');
end $$;
-- Apply each case's existing BS resource through rework, disposition and HOLD.
-- Resolution rows for rework GOOD are provenance, not a second FG movement.
-- Linear form: the graph's nodes and events are held as arrays with a hashed
-- node map, and every move still goes through cp7_wip.transition on a graph
-- that holds only the destination node, so each move checks and fails exactly
-- as before. Source rows are looked up in maps built where the first scan ran.
create function cp7_wip.settle_bs(g jsonb,f jsonb,bsnodes jsonb,scope_at timestamptz) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare rw jsonb;b jsonb;d jsonb;x jsonb;held jsonb;positions jsonb;ref jsonb;
 pool text;src text;dst text;qty numeric;cnt integer;
 nodes jsonb[];events jsonb[];nm jsonb[];n jsonb;t jsonb;k text;h integer;here jsonb;ne integer;
 reworks_by_id jsonb;fg_by_resolution jsonb;holds_by_case jsonb;remaining jsonb;
begin
 select coalesce(array_agg(value order by ordinality),'{}') into nodes from jsonb_array_elements(g->'nodes') with ordinality;
 select coalesce(array_agg(value order by ordinality),'{}') into events from jsonb_array_elements(g->'events') with ordinality;
 ne:=cardinality(events);
 select array_agg(coalesce(m.v,'{}'::jsonb) order by s.h) into nm from generate_series(1,1024) s(h) left join(
  select (hashtext(z.k)&1023)+1 h,jsonb_object_agg(z.k,z.value) v from(select distinct on(value->>'key')value->>'key' k,value
   from jsonb_array_elements(g->'nodes') with ordinality where value->>'key' is not null order by value->>'key',ordinality)z group by 1)m on m.h=s.h;
 for rw in select value from jsonb_array_elements(f->'reworks') where value->>'status'<>'CANCELLED' order by value->>'physical_sent_at',value->>'id' loop
  b:=bsnodes->(rw->>'bs_case_id');
  if b is null then return jsonb_build_object('status','UNKNOWN','reason','REWORK_BS_SOURCE_UNPROVEN','source_id',rw->'id');end if;
  pool:=b->>'pool';src:=b->>'node';dst:='REWORK:'||(rw->>'id');ref:=cp7_wip.ref('erp.rework_orders',rw->>'id',rw->>'revision');
  k:=dst;n:=nm[(hashtext(k)&1023)+1]->k;
  t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'REWORK',(rw->>'sent_pcs')::numeric,ref);
  if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
   if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
  if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
  if rw->>'status'='COMPLETED' and rw->'completion_posted'<>'true'::jsonb then
   return jsonb_build_object('status','UNKNOWN','reason','REWORK_COMPLETION_NOT_POSTED','source_id',rw->'id');end if;
  if rw->>'status'='COMPLETED' and (rw->>'completed_at')::timestamptz<=scope_at then
   if (rw->>'good_pcs')::numeric+(rw->>'bs_pcs')::numeric<>(rw->>'sent_pcs')::numeric then return jsonb_build_object('status','CONFLICT','reason','REWORK_COMPLETION_MISMATCH','source_id',rw->'id');end if;
   k:='FGREWORK:'||(rw->>'id');n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,dst,k,'FG',(rw->>'good_pcs')::numeric,ref);
   if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
    if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
   if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
   k:=src;n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,dst,k,'BS',(rw->>'bs_pcs')::numeric,ref);
   if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
    if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
   if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
  end if;
 end loop;
 for d in select value from jsonb_array_elements(f->'resolutions') order by value->>'physical_at',value->>'id' loop
  b:=bsnodes->(d->>'bs_case_id');
  if b is null then return jsonb_build_object('status','CONFLICT','reason','DISPOSITION_BS_SOURCE_UNPROVEN','source_id',d->'id');end if;
  if d->'source_rework_order_id'<>'null'::jsonb then
   -- Same predicate over the reworks that carry this id, in source order.
   if reworks_by_id is null then
    select coalesce(jsonb_object_agg(z.k,z.v),'{}') into reworks_by_id from(select value->>'id' k,jsonb_agg(value order by ordinality) v
     from jsonb_array_elements(f->'reworks') with ordinality where value->>'id' is not null group by 1)z;
   end if;
   if not exists(select 1 from jsonb_array_elements(coalesce(reworks_by_id->(d->>'source_rework_order_id'),'[]'::jsonb)) rework_entry
     where rework_entry->>'id'=d->>'source_rework_order_id' and rework_entry->>'bs_case_id'=d->>'bs_case_id'
      and rework_entry->>'status'='COMPLETED' and rework_entry->'completion_posted'='true'::jsonb
      and (rework_entry->>'good_pcs')::numeric=(d->>'qty_pcs')::numeric
      and d->>'resolution_type' in ('REWORK_SEWING','REWORK_LAUNDRY')) then
    return jsonb_build_object('status','CONFLICT','reason','REWORK_RESOLUTION_LINEAGE_MISMATCH','source_id',d->'id');end if;
   continue;
  end if;
  if d->>'resolution_type' not in ('CASH_COMPENSATION','SCRAP','WRITE_OFF','OTHER') then
   return jsonb_build_object('status','UNKNOWN','reason','DISPOSITION_TYPE_UNPROVEN','source_id',d->'id');end if;
  pool:=b->>'pool';src:=b->>'node';ref:=cp7_wip.ref('erp.bs_resolutions',d->>'id',d->>'physical_at');
  if fg_by_resolution is null then
   select coalesce(jsonb_object_agg(z.k,z.v),'{}') into fg_by_resolution from(select value->>'bs_resolution_id' k,jsonb_agg(value order by ordinality) v
    from jsonb_array_elements(f->'bs_fg') with ordinality where value->>'bs_resolution_id' is not null and value->>'status'='POSTED' group by 1)z;
  end if;
  x:=coalesce(fg_by_resolution->(d->>'id'),'[]'::jsonb);cnt:=jsonb_array_length(x);
  if cnt>1 then return jsonb_build_object('status','CONFLICT','reason','DUPLICATE_BS_FG_DISPOSITION','source_id',d->'id');end if;
  if cnt=1 then
   x:=x->0;
   if x->>'bs_case_id'<>d->>'bs_case_id' or (x->>'qty_pcs')::numeric<>(d->>'qty_pcs')::numeric then
    return jsonb_build_object('status','CONFLICT','reason','BS_FG_DISPOSITION_MISMATCH','source_id',d->'id');end if;
   k:='FGDISPOSITION:'||(d->>'id');n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'FG',(d->>'qty_pcs')::numeric,ref);
  else
   k:='DISPOSITION:'||(d->>'id');n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'EXIT',(d->>'qty_pcs')::numeric,ref);
  end if;
  if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
   if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
  if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
 end loop;
 g:=g||jsonb_build_object('nodes',to_jsonb(nodes),'events',to_jsonb(events));
 positions:=cp7_wip.reconcile(g);
 if positions->>'status'<>'COMPLETE' then return positions;end if;
 -- A source reversal retires the case, including its historical hold state.
 -- Active children above still require an active physical case node.
 for b in select value from jsonb_array_elements(f->'bs') where value->>'status'<>'CANCELLED' loop
  if holds_by_case is null then
   select coalesce(jsonb_object_agg(z.k,z.v),'{}') into holds_by_case from(select value->>'bs_case_id' k,jsonb_agg(value order by ordinality) v
    from jsonb_array_elements(f->'holds') with ordinality where value->>'bs_case_id' is not null group by 1)z;
  end if;
  select value into held from jsonb_array_elements(coalesce(holds_by_case->(b->>'id'),'[]'::jsonb)) where value->>'bs_case_id'=b->>'id'
   order by (value->>'physical_at')::timestamptz desc,(value->>'created_at')::timestamptz desc,value->>'id' desc limit 1;
  if (b->>'status'='ON_HOLD') is distinct from coalesce(held->>'action'='HOLD',false) then
   return jsonb_build_object('status','UNKNOWN','reason','BS_HOLD_STATE_UNPROVEN','source_id',b->'id');end if;
  if b->>'status'='ON_HOLD' then
   x:=bsnodes->(b->>'id');src:=x->>'node';pool:=x->>'pool';
   if remaining is null then
    select coalesce(jsonb_object_agg(z.k,z.v),'{}') into remaining from(select distinct on(value->>'key')value->>'key' k,value->'remaining_pcs' v
     from jsonb_array_elements(positions->'positions') with ordinality where value->>'key' is not null order by value->>'key',ordinality)z;
   end if;
   qty:=(remaining->>src)::numeric;
   if qty is null or qty<=0 then return jsonb_build_object('status','CONFLICT','reason','BS_HOLD_QUANTITY_UNPROVEN','source_id',b->'id');end if;
   k:='HOLD:'||(b->>'id');n:=nm[(hashtext(k)&1023)+1]->k;
   t:=cp7_wip.transition(jsonb_build_object('nodes',case when n is null then '[]'::jsonb else jsonb_build_array(n) end,'events','[]'::jsonb),pool,src,k,'HOLD',qty,cp7_wip.ref('erp.bs_case_hold_events',held->>'id',held->>'created_at'));
   if n is null and jsonb_array_length(t->'nodes')=1 then n:=t->'nodes'->0;nodes:=array_append(nodes,n);
    if k is not null then h:=(hashtext(k)&1023)+1;here:=nm[h]||jsonb_build_object(k,n);nm[h]:=here;end if;end if;
   if jsonb_array_length(t->'events')=1 then here:=(t->'events'->0)||jsonb_build_object('key','T:'||ne,'ordinal',(ne+1)::text);events:=array_append(events,here);ne:=ne+1;end if;
  end if;
 end loop;
 return g||jsonb_build_object('nodes',to_jsonb(nodes),'events',to_jsonb(events));
end $$;

create table cp7_wip.runs(
 id uuid primary key default gen_random_uuid(),actor uuid not null,request_id uuid not null,
 groups uuid[] not null,captured_at timestamptz not null,facts jsonb not null,
 result jsonb not null,dependency_hash text not null,unique(actor,request_id)
);
alter table cp7_wip.runs owner to cp7_capture;
alter table cp7_wip.runs enable row level security;
revoke all on cp7_wip.runs from public,anon,authenticated,service_role;
create trigger cp7_wip_immutable before update or delete on cp7_wip.runs for each row execute function cp7_private.immutable_run();

create function cp7_wip.serve(p_run uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;r cp7_wip.runs%rowtype;live jsonb;hash text;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_private.access_now();
 select * into r from cp7_wip.runs where id=p_run and actor=(a->>'actor')::uuid;
 if r.id is null then raise exception using errcode='42501',message='CP7_WIP_RUN_UNAVAILABLE';end if;
 live:=cp7_wip.capture_cutting_sources(r.groups);
 hash:=encode(extensions.digest(convert_to((live->'facts')::text,'UTF8'),'sha256'),'hex');
 perform cp7_private.access_now();
 return jsonb_build_object('contract_version','cp7.cutting-wip-run.v1','run_id',r.id,'request_id',r.request_id,
  'captured_at',r.captured_at,'knowledge_mode','CURRENT_AT_CAPTURE','capture_complete',true,
  'source_state',case when live->>'status'='COMPLETE' and hash=r.dependency_hash then 'UNCHANGED' else 'ARCHIVED_STALE' end,
  'scope',jsonb_build_object('cutting_group_ids',to_jsonb(r.groups),'includes_opening_non_po',false),
  'result',r.result,'production_go',false);
end $$;
create function cp7_wip.capture(p_groups uuid[],p_request uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;groups uuid[];r cp7_wip.runs%rowtype;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_private.access_now();
 if p_request is null or p_groups is null or cardinality(p_groups) not between 1 and 50 or array_position(p_groups,null) is not null then raise exception 'CP7_WIP_SCOPE';end if;
 select array_agg(distinct x order by x) into groups from unnest(p_groups) x;
 if cardinality(groups)<>cardinality(p_groups) then raise exception 'CP7_WIP_SCOPE';end if;
 perform pg_advisory_xact_lock(hashtextextended('CP7:WIP:'||(a->>'actor')||':'||p_request::text,0));
 perform cp7_private.access_now();
 select * into r from cp7_wip.runs where actor=(a->>'actor')::uuid and request_id=p_request;
 if r.id is not null then
  if r.groups<>groups then raise exception 'CP7_WIP_REQUEST_REUSED';end if;
  return cp7_wip.serve(r.id);
 end if;
 with source as materialized(select cp7_wip.capture_cutting_sources(groups) facts),
 normalized as materialized(select facts,cp7_wip.normalize_cutting(facts) result from source where facts->>'status'='COMPLETE')
 insert into cp7_wip.runs(actor,request_id,groups,captured_at,facts,result,dependency_hash)
 select (a->>'actor')::uuid,p_request,groups,(facts->>'captured_at')::timestamptz,facts,result,
  encode(extensions.digest(convert_to((facts->'facts')::text,'UTF8'),'sha256'),'hex') from normalized returning * into r;
 if r.id is null then raise exception 'CP7_WIP_SOURCE_INCOMPLETE';end if;
 perform cp7_private.access_now();
 return cp7_wip.serve(r.id);
end $$;
create function public.erp_cp7_capture_cutting_wip_v1(p_groups uuid[],p_request uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_wip.capture(p_groups,p_request)$$;
create function public.erp_cp7_read_cutting_wip_v1(p_run uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_wip.serve(p_run)$$;

-- Opening WIP/BS and explicitly unsourced BS. No stock movement is inferred
-- from a display reader or financial total. All columns here are operational.
grant select on erp.initial_import_production_sources,erp.opening_balance_items,
 erp.opening_balance_headers,erp.migration_batches,erp.initial_import_wip_outputs,
 erp.initial_import_wip_output_reversals,erp.bb_wip_pickups_v1,erp.bb_wip_bs_splits_v1,
 erp.bd_opening_laundry_claims_v1,erp.bd_opening_laundry_claim_events_v1 to cp7_capture;
create function cp7_wip.capture_other_sources(p_items uuid[],p_cases uuid[],p_at timestamptz) returns jsonb
language sql stable security invoker set search_path='' set timezone='Asia/Jakarta' as $$
with origins as materialized(
 select s.opening_item_id id,s.source_row_id,s.batch_id,s.po_id,s.size_id,s.stage,s.qty_pcs::text qty_pcs,s.bs_case_id,
 i.balance_type,i.qty::text opening_qty_pcs,i.product_id,i.model_id,i.customer_id,i.vendor_id,i.contractor_id,h.opening_date,h.status header_status,m.status batch_status
 from erp.initial_import_production_sources s join erp.opening_balance_items i on i.id=s.opening_item_id
 join erp.opening_balance_headers h on h.id=i.opening_id join erp.migration_batches m on m.id=s.batch_id
 where s.opening_item_id=any(p_items) and h.opening_date<=(p_at at time zone 'Asia/Jakarta')::date order by s.opening_item_id limit 51
),
pickups as materialized(
 select x.id,x.opening_item_id,x.physical_at,x.reversed_at
 from erp.bb_wip_pickups_v1 x join origins o on o.id=x.opening_item_id where x.physical_at<=p_at order by x.id limit 2001
),
outputs as materialized(
 select x.id,x.opening_item_id,x.lot_id,x.qty_pcs::text qty_pcs,x.physical_at,r.physical_at reversed_at,p.size_id
 from erp.initial_import_wip_outputs x join origins o on o.id=x.opening_item_id
 join erp.fg_lots l on l.id=x.lot_id join erp.products p on p.id=l.product_id
 left join erp.initial_import_wip_output_reversals r on r.output_id=x.id
 where x.physical_at<=p_at order by x.id limit 2001
),
splits as materialized(
 select x.id,x.opening_item_id,x.bs_case_id,x.product_id,p.size_id,x.qty_pcs::text qty_pcs,x.physical_at,x.reversed_at
 from erp.bb_wip_bs_splits_v1 x join origins o on o.id=x.opening_item_id join erp.products p on p.id=x.product_id
 where x.physical_at<=p_at order by x.id limit 2001
),
claims as materialized(
 select x.id,x.opening_item_id,x.claim_type,x.qty_claimed::text qty_pcs,x.claim_date,x.cancelled_at,x.row_version::text revision
 from erp.bd_opening_laundry_claims_v1 x join origins o on o.id=x.opening_item_id
 where x.claim_date<=(p_at at time zone 'Asia/Jakarta')::date order by x.id limit 2001
),
claim_events as materialized(
 select x.id,x.claim_id,x.event_kind,x.qty::text qty_pcs,x.resolution,x.event_date,x.reversed_at
 from erp.bd_opening_laundry_claim_events_v1 x join claims c on c.id=x.claim_id
 where x.event_date<=(p_at at time zone 'Asia/Jakarta')::date order by x.id limit 2001
),
non_po as materialized(
 select b.id,b.qty_pcs::text qty_pcs,p.size_id,b.row_version::text revision,b.untracked_type,b.physical_at
 from erp.bs_cases b left join erp.products p on p.id=b.product_id
 where b.id=any(p_cases) and b.cutting_group_id is null and b.qc_item_id is null and b.source_laundry_receipt_line_id is null
  and b.po_id is null and b.untracked_type in ('OUT_OF_NOWHERE','LEGACY') and b.physical_at<=p_at
  and not exists(select 1 from erp.initial_import_production_sources z where z.bs_case_id=b.id)
  and not exists(select 1 from erp.bb_wip_bs_splits_v1 z where z.bs_case_id=b.id)
 order by b.id limit 51
),
bs as materialized(
 select b.id,b.product_id,p.size_id,b.qty_pcs::text qty_pcs,b.status,b.physical_at,b.row_version::text revision
 from erp.bs_cases b left join erp.products p on p.id=b.product_id
 where b.id in (select bs_case_id from origins union select bs_case_id from splits where reversed_at is null or reversed_at>p_at union select id from non_po)
 and b.physical_at<=p_at order by b.id limit 2001
),
reworks as materialized(
 select r.id,r.bs_case_id,r.qty_sent::text sent_pcs,r.qty_good_returned::text good_pcs,r.qty_bs_returned::text bs_pcs,
 r.physical_sent_at,r.completed_at,r.status,r.row_version::text revision,r.good_fg_lot_id,r.cost_posted completion_posted
 from erp.rework_orders r join bs b on b.id=r.bs_case_id where r.physical_sent_at<=p_at order by r.id limit 2001
),
resolutions as materialized(
 select r.id,r.bs_case_id,r.resolution_type,r.qty_pcs::text qty_pcs,r.source_rework_order_id,r.physical_at
 from erp.bs_resolutions r join bs b on b.id=r.bs_case_id where r.physical_at<=p_at order by r.id limit 2001
),
holds as materialized(
 select h.id,h.bs_case_id,h.action,h.resulting_status,h.physical_at,h.created_at
 from erp.bs_case_hold_events h join bs b on b.id=h.bs_case_id where h.physical_at<=p_at order by h.id limit 2001
),
bs_fg as materialized(
 select x.id,x.bs_case_id,x.bs_resolution_id,x.qty_pcs::text qty_pcs,x.status,x.lot_id,x.quality_grade,x.physical_at
 from erp.fg_unsourced_receipts_v1 x join bs b on b.id=x.bs_case_id where x.physical_at<=p_at order by x.id limit 2001
),
source as (select jsonb_build_object(
 'origins',coalesce((select jsonb_agg(to_jsonb(x) order by id) from origins x),'[]'::jsonb),
 'pickups',coalesce((select jsonb_agg(to_jsonb(x) order by id) from pickups x),'[]'::jsonb),
 'outputs',coalesce((select jsonb_agg(to_jsonb(x) order by id) from outputs x),'[]'::jsonb),
 'splits',coalesce((select jsonb_agg(to_jsonb(x) order by id) from splits x),'[]'::jsonb),
 'claims',coalesce((select jsonb_agg(to_jsonb(x) order by id) from claims x),'[]'::jsonb),
 'claim_events',coalesce((select jsonb_agg(to_jsonb(x) order by id) from claim_events x),'[]'::jsonb),
 'non_po',coalesce((select jsonb_agg(to_jsonb(x) order by id) from non_po x),'[]'::jsonb),
 'bs',coalesce((select jsonb_agg(to_jsonb(x) order by id) from bs x),'[]'::jsonb),
 'reworks',coalesce((select jsonb_agg(to_jsonb(x) order by id) from reworks x),'[]'::jsonb),
 'resolutions',coalesce((select jsonb_agg(to_jsonb(x) order by id) from resolutions x),'[]'::jsonb),
 'holds',coalesce((select jsonb_agg(to_jsonb(x) order by id) from holds x),'[]'::jsonb),
 'bs_fg',coalesce((select jsonb_agg(to_jsonb(x) order by id) from bs_fg x),'[]'::jsonb)) facts)
select jsonb_build_object('contract_version','cp7.other-wip-facts.v1','captured_at',p_at,'facts',facts,
 'status',case when jsonb_array_length(facts->'origins')=cardinality(p_items) and jsonb_array_length(facts->'non_po')=cardinality(p_cases)
 and not exists(select 1 from jsonb_each(facts) where jsonb_array_length(value)>2000) then 'COMPLETE' else 'INCOMPLETE' end) from source
$$;

create function cp7_wip.normalize_other(capture jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare f jsonb:=capture->'facts';g jsonb;origin jsonb;x jsonb;c jsonb;b jsonb;ref jsonb;result jsonb;bsnodes jsonb:='{}';
 at_time timestamptz:=(capture->>'captured_at')::timestamptz;pool text;src text;stage text;qty numeric;recovered numeric;cnt integer;
begin
 if capture->>'contract_version' is distinct from 'cp7.other-wip-facts.v1' or capture->>'status' is distinct from 'COMPLETE' then
  return jsonb_build_object('status','UNKNOWN','reason','OTHER_SOURCE_CAPTURE_INCOMPLETE');end if;
 g:=jsonb_build_object('contract_version','cp7.wip-graph.v1','snapshot_id',capture->>'captured_at','complete',true,'pools','[]'::jsonb,'nodes','[]'::jsonb,'events','[]'::jsonb);
 for origin in select value from jsonb_array_elements(f->'origins') order by value->>'id' loop
  stage:=null;
  if origin->>'header_status'<>'POSTED' or origin->>'batch_status'<>'POSTED' then return jsonb_build_object('status','UNKNOWN','reason','OPENING_NOT_POSTED','source_id',origin->'id');end if;
  if origin->>'size_id' is null then return jsonb_build_object('status','UNKNOWN','reason','OPENING_SIZE_UNPROVEN','source_id',origin->'id');end if;
  if (origin->>'opening_qty_pcs')::numeric is distinct from cp7_wip.pcs(origin->'qty_pcs') then
   return jsonb_build_object('status','CONFLICT','reason','OPENING_ORIGIN_QUANTITY_MISMATCH','source_id',origin->'id');end if;
  pool:='OPEN:'||(origin->>'id');src:=pool||':PRE';ref:=cp7_wip.ref('erp.initial_import_production_sources',origin->>'id',origin->>'batch_id');
  g:=jsonb_set(g,'{pools}',g->'pools'||jsonb_build_array(jsonb_build_object('key',pool,'size_id',origin->'size_id','input_pcs',origin->'qty_pcs',
   'origin','OPENING','ownership',case when origin->>'customer_id' is null then 'COMPANY' else 'CUSTOMER' end,'refs',jsonb_build_array(ref))));
  if origin->>'balance_type'='BS' and origin->>'bs_case_id' is not null then
   stage:='BS';bsnodes:=bsnodes||jsonb_build_object(origin->>'bs_case_id',jsonb_build_object('pool',pool,'node',src));
  elsif origin->>'balance_type'='WIP' and origin->>'bs_case_id' is null then
   stage:=case origin->>'stage' when 'CUTTING' then 'CUT_UNASSIGNED' when 'SEWING' then 'SEWING_UNRESOLVED' when 'LAUNDRY' then 'LAUNDRY_OUTSTANDING' when 'QC' then 'AWAIT_QC' end;
   if stage='CUT_UNASSIGNED' then
    select count(*) into cnt from jsonb_array_elements(f->'pickups') where value->>'opening_item_id'=origin->>'id'
      and (value->>'reversed_at' is null or (value->>'reversed_at')::timestamptz>at_time);
    if cnt>1 then return jsonb_build_object('status','CONFLICT','reason','OPENING_MULTIPLE_ACTIVE_PICKUPS','source_id',origin->'id');end if;
    if cnt=1 then stage:='SEWING_UNRESOLVED';end if;
   end if;
  end if;
  if stage is null then return jsonb_build_object('status','UNKNOWN','reason','OPENING_STAGE_UNPROVEN','source_id',origin->'id');end if;
  g:=cp7_wip.transition(g,pool,null,src,stage,cp7_wip.pcs(origin->'qty_pcs'),ref);
  for x in select value from jsonb_array_elements(f->'outputs') where value->>'opening_item_id'=origin->>'id'
    and (value->>'reversed_at' is null or (value->>'reversed_at')::timestamptz>at_time) order by value->>'physical_at',value->>'id' loop
   if x->>'size_id' is distinct from origin->>'size_id' then return jsonb_build_object('status','CONFLICT','reason','OPENING_OUTPUT_SIZE_MISMATCH','source_id',x->'id');end if;
   g:=cp7_wip.transition(g,pool,src,'FGOPEN:'||(x->>'id'),'FG',cp7_wip.pcs(x->'qty_pcs'),cp7_wip.ref('erp.initial_import_wip_outputs',x->>'id',x->>'physical_at'));
  end loop;
  for x in select value from jsonb_array_elements(f->'splits') where value->>'opening_item_id'=origin->>'id'
    and (value->>'reversed_at' is null or (value->>'reversed_at')::timestamptz>at_time) order by value->>'physical_at',value->>'id' loop
   if x->>'size_id' is distinct from origin->>'size_id' or bsnodes ? (x->>'bs_case_id') then return jsonb_build_object('status','CONFLICT','reason','OPENING_SPLIT_LINEAGE_MISMATCH','source_id',x->'id');end if;
   g:=cp7_wip.transition(g,pool,src,'BSOPEN:'||(x->>'id'),'BS',cp7_wip.pcs(x->'qty_pcs'),cp7_wip.ref('erp.bb_wip_bs_splits_v1',x->>'id',x->>'physical_at'));
   bsnodes:=bsnodes||jsonb_build_object(x->>'bs_case_id',jsonb_build_object('pool',pool,'node','BSOPEN:'||(x->>'id')));
  end loop;
  for c in select value from jsonb_array_elements(f->'claims') where value->>'opening_item_id'=origin->>'id'
    and (value->>'cancelled_at' is null or (value->>'cancelled_at')::timestamptz>at_time) order by value->>'id' loop
   select coalesce(sum((value->>'qty_pcs')::numeric),0) into recovered from jsonb_array_elements(f->'claim_events')
    where value->>'claim_id'=c->>'id' and value->>'event_kind'='RECOVER'
    and (value->>'reversed_at' is null or (value->>'reversed_at')::timestamptz>at_time);
   qty:=cp7_wip.pcs(c->'qty_pcs')-recovered;
   if qty<0 or c->>'claim_type' not in ('MISSING','STUCK') then return jsonb_build_object('status','CONFLICT','reason','OPENING_CLAIM_RECONCILIATION','source_id',c->'id');end if;
   -- Settlement changes the monetary right, never makes these pieces GOOD.
   g:=cp7_wip.transition(g,pool,src,'OPENCLAIM:'||(c->>'id'),c->>'claim_type',qty,cp7_wip.ref('erp.bd_opening_laundry_claims_v1',c->>'id',c->>'revision'));
  end loop;
 end loop;
 for origin in select value from jsonb_array_elements(f->'non_po') order by value->>'id' loop
  if origin->>'size_id' is null then return jsonb_build_object('status','UNKNOWN','reason','UNSOURCED_BS_SIZE_UNPROVEN','source_id',origin->'id');end if;
  pool:='NONPO:'||(origin->>'id');src:=pool||':BS';ref:=cp7_wip.ref('erp.bs_cases',origin->>'id',origin->>'revision');
  g:=jsonb_set(g,'{pools}',g->'pools'||jsonb_build_array(jsonb_build_object('key',pool,'size_id',origin->'size_id','input_pcs',origin->'qty_pcs',
   'origin','NON_PO','ownership','COMPANY','refs',jsonb_build_array(ref))));
  g:=cp7_wip.transition(g,pool,null,src,'BS',cp7_wip.pcs(origin->'qty_pcs'),ref);
  bsnodes:=bsnodes||jsonb_build_object(origin->>'id',jsonb_build_object('pool',pool,'node',src));
 end loop;
 for b in select value from jsonb_array_elements(f->'bs') loop
  if not bsnodes ? (b->>'id') then return jsonb_build_object('status','CONFLICT','reason','OTHER_BS_ORIGIN_UNPROVEN','source_id',b->'id');end if;
 end loop;
 if (select count(*) from jsonb_each(bsnodes))<>jsonb_array_length(f->'bs') then return jsonb_build_object('status','CONFLICT','reason','OTHER_BS_CASE_MISSING');end if;
 g:=cp7_wip.settle_bs(g,f,bsnodes,at_time);
 if g ? 'status' then return g;end if;
 result:=cp7_wip.reconcile(g);
 return result||jsonb_build_object('graph',g,'source_basis','EXPLICIT_OPENING_OR_UNSOURCED_ORIGIN',
  'fg_basis','PRODUCTION_DISPOSITION_NOT_CURRENT_ON_HAND');
end $$;

-- One declared scope, one capture clock and one statement snapshot across the
-- three origin types. This is not a sum of separately captured runs.
create function cp7_wip.production_scope(s jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare k text;a uuid[];result jsonb:='{}';n integer:=0;
begin
 perform cp7_wip.fields(s,array['cutting_groups','opening_items','unsourced_bs']);
 foreach k in array array['cutting_groups','opening_items','unsourced_bs'] loop
  if jsonb_typeof(s->k) is distinct from 'array' or jsonb_array_length(s->k)>50
   or exists(select 1 from jsonb_array_elements(s->k) where jsonb_typeof(value)<>'string') then raise exception 'CP7_WIP_SCOPE';end if;
  select coalesce(array_agg(distinct value::uuid order by value::uuid),'{}'::uuid[]) into a from jsonb_array_elements_text(s->k);
  if cardinality(a)<>jsonb_array_length(s->k) then raise exception 'CP7_WIP_SCOPE';end if;
  n:=n+cardinality(a);result:=result||jsonb_build_object(k,to_jsonb(a));
 end loop;
 if n not between 1 and 50 then raise exception 'CP7_WIP_SCOPE';end if;
 return result;
end $$;
create function cp7_wip.capture_production_sources(s jsonb) returns jsonb
language sql stable security invoker set search_path='' as $$
with clock as materialized(select clock_timestamp() at),
cutting as materialized(select cp7_wip.capture_cutting_sources(array(select value::uuid from jsonb_array_elements_text(s->'cutting_groups')),at) data from clock),
other as materialized(select cp7_wip.capture_other_sources(array(select value::uuid from jsonb_array_elements_text(s->'opening_items')),
 array(select value::uuid from jsonb_array_elements_text(s->'unsourced_bs')),at) data from clock)
select jsonb_build_object('contract_version','cp7.production-facts.v1','captured_at',clock.at,
 'status',case when cutting.data->>'status'='COMPLETE' and other.data->>'status'='COMPLETE' then 'COMPLETE' else 'INCOMPLETE' end,
 'facts',jsonb_build_object('cutting',cutting.data->'facts','other',other.data->'facts')) from clock,cutting,other
$$;
create function cp7_wip.normalize_production(capture jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare cut jsonb;other jsonb;g jsonb;graph jsonb;e jsonb;prefix text;result jsonb;events jsonb[]:='{}';ne integer:=0;
begin
 if capture->>'contract_version' is distinct from 'cp7.production-facts.v1' or capture->>'status' is distinct from 'COMPLETE' then
  return jsonb_build_object('status','UNKNOWN','reason','PRODUCTION_CAPTURE_INCOMPLETE');end if;
 cut:=cp7_wip.normalize_cutting(jsonb_build_object('contract_version','cp7.cutting-facts.v1','status','COMPLETE','captured_at',capture->'captured_at','facts',capture->'facts'->'cutting'));
 other:=cp7_wip.normalize_other(jsonb_build_object('contract_version','cp7.other-wip-facts.v1','status','COMPLETE','captured_at',capture->'captured_at','facts',capture->'facts'->'other'));
 if cut->>'status'<>'COMPLETE' then return cut||jsonb_build_object('component','CUTTING');end if;
 if other->>'status'<>'COMPLETE' then return other||jsonb_build_object('component','OPENING_UNSOURCED');end if;
 g:=jsonb_build_object('contract_version','cp7.wip-graph.v1','snapshot_id',capture->>'captured_at','complete',true,'pools','[]'::jsonb,'nodes','[]'::jsonb,'events','[]'::jsonb);
 foreach prefix in array array['cutting','other'] loop
  graph:=case when prefix='cutting' then cut->'graph' else other->'graph' end;
  g:=jsonb_set(g,'{pools}',(g->'pools')||(graph->'pools'));g:=jsonb_set(g,'{nodes}',(g->'nodes')||(graph->'nodes'));
  -- Events are appended to an array and placed once (linear, same bytes).
  for e in select value from jsonb_array_elements(graph->'events') loop
   e:=e||jsonb_build_object('key',prefix||':'||(e->>'key'),'ordinal',(ne+1)::text,
    'reverses_key',case when e->>'reverses_key' is null then null else prefix||':'||(e->>'reverses_key') end);
   events:=array_append(events,e);ne:=ne+1;
  end loop;
 end loop;
 g:=jsonb_set(g,'{events}',to_jsonb(events));
 result:=cp7_wip.reconcile(g);
 return result||jsonb_build_object('graph',g,'source_basis','ONE_CAPTURE_EXPLICIT_PRODUCTION_ORIGINS',
  'scope','SELECTED_ORIGINS_ONLY','fg_basis','PRODUCTION_DISPOSITION_NOT_CURRENT_ON_HAND',
  'allocation_review_required',cut->'allocation_review_required','attention',cut->'attention',
  'sewing_detail','SUBSTAGE_NOT_ALLOCATABLE_FROM_GROUP_EVENTS','rewash_review_required',cut->'rewash_review_required',
  'timing',jsonb_build_object('quality','UNKNOWN','reason','NO_CALENDAR_OR_REMAINING_WORK_SELECTED','eta',null,'on_time',null));
end $$;

create table cp7_wip.production_runs(
 id uuid primary key default gen_random_uuid(),actor uuid not null,request_id uuid not null,
 scope jsonb not null,captured_at timestamptz not null,facts jsonb not null,
 result jsonb not null,dependency_hash text not null,unique(actor,request_id)
);
alter table cp7_wip.production_runs owner to cp7_capture;
alter table cp7_wip.production_runs enable row level security;
revoke all on cp7_wip.production_runs from public,anon,authenticated,service_role;
create trigger cp7_production_immutable before update or delete on cp7_wip.production_runs for each row execute function cp7_private.immutable_run();
create function cp7_wip.serve_production(p_run uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;r cp7_wip.production_runs%rowtype;live jsonb;hash text;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_private.access_now();
 select * into r from cp7_wip.production_runs where id=p_run and actor=(a->>'actor')::uuid;
 if r.id is null then raise exception using errcode='42501',message='CP7_WIP_RUN_UNAVAILABLE';end if;
 live:=cp7_wip.capture_production_sources(r.scope);
 hash:=encode(extensions.digest(convert_to((live->'facts')::text,'UTF8'),'sha256'),'hex');
 perform cp7_private.access_now();
 return jsonb_build_object('contract_version','cp7.production-wip-run.v1','run_id',r.id,'request_id',r.request_id,
  'captured_at',r.captured_at,'knowledge_mode','CURRENT_AT_CAPTURE','capture_complete',true,
  'source_state',case when live->>'status'='COMPLETE' and hash=r.dependency_hash then 'UNCHANGED' else 'ARCHIVED_STALE' end,
  'scope',r.scope,'result',r.result,'production_go',false);
end $$;
create function cp7_wip.capture_production(p_scope jsonb,p_request uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;s jsonb;r cp7_wip.production_runs%rowtype;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_private.access_now();s:=cp7_wip.production_scope(p_scope);
 if p_request is null then raise exception 'CP7_WIP_SCOPE';end if;
 perform pg_advisory_xact_lock(hashtextextended('CP7:PRODUCTION:'||(a->>'actor')||':'||p_request::text,0));
 perform cp7_private.access_now();
 select * into r from cp7_wip.production_runs where actor=(a->>'actor')::uuid and request_id=p_request;
 if r.id is not null then
  if r.scope<>s then raise exception 'CP7_WIP_REQUEST_REUSED';end if;
  return cp7_wip.serve_production(r.id);
 end if;
 with source as materialized(select cp7_wip.capture_production_sources(s) facts),
 normalized as materialized(select facts,cp7_wip.normalize_production(facts) result from source where facts->>'status'='COMPLETE')
 insert into cp7_wip.production_runs(actor,request_id,scope,captured_at,facts,result,dependency_hash)
 select (a->>'actor')::uuid,p_request,s,(facts->>'captured_at')::timestamptz,facts,result,
  encode(extensions.digest(convert_to((facts->'facts')::text,'UTF8'),'sha256'),'hex') from normalized returning * into r;
 if r.id is null then raise exception 'CP7_WIP_SOURCE_INCOMPLETE';end if;
 perform cp7_private.access_now();
 return cp7_wip.serve_production(r.id);
end $$;
create function public.erp_cp7_capture_production_wip_v1(p_scope jsonb,p_request uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_wip.capture_production(p_scope,p_request)$$;
create function public.erp_cp7_read_production_wip_v1(p_run uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_wip.serve_production(p_run)$$;

alter function cp7_wip.fields(jsonb,text[]) owner to cp7_capture;
alter function cp7_wip.key(jsonb) owner to cp7_capture;
alter function cp7_wip.pcs(jsonb) owner to cp7_capture;
alter function cp7_wip.refs(jsonb) owner to cp7_capture;
alter function cp7_wip.reconcile(jsonb) owner to cp7_capture;
alter function cp7_wip.match_target(jsonb,jsonb) owner to cp7_capture;
alter function cp7_wip.check_allocations(jsonb,jsonb) owner to cp7_capture;
alter function cp7_wip.project_yield(jsonb,jsonb) owner to cp7_capture;
alter function cp7_wip.remaining_eta(timestamptz,timestamptz,jsonb) owner to cp7_capture;
revoke all on all functions in schema cp7_wip from public,anon,authenticated,service_role;
alter function cp7_wip.capture_cutting_sources(uuid[]) owner to cp7_capture;
alter function cp7_wip.capture_cutting_sources(uuid[],timestamptz) owner to cp7_capture;
alter function cp7_wip.transition(jsonb,text,text,text,text,numeric,jsonb) owner to cp7_capture;
alter function cp7_wip.ref(text,text,text) owner to cp7_capture;
alter function cp7_wip.redispatch_valid(jsonb) owner to cp7_capture;
alter function cp7_wip.normalize_cutting(jsonb) owner to cp7_capture;
alter function cp7_wip.settle_bs(jsonb,jsonb,jsonb,timestamptz) owner to cp7_capture;
alter function cp7_wip.serve(uuid) owner to cp7_capture;
alter function cp7_wip.capture(uuid[],uuid) owner to cp7_capture;
alter function cp7_wip.capture_other_sources(uuid[],uuid[],timestamptz) owner to cp7_capture;
alter function cp7_wip.normalize_other(jsonb) owner to cp7_capture;
alter function cp7_wip.production_scope(jsonb) owner to cp7_capture;
alter function cp7_wip.capture_production_sources(jsonb) owner to cp7_capture;
alter function cp7_wip.normalize_production(jsonb) owner to cp7_capture;
alter function cp7_wip.capture_production(jsonb,uuid) owner to cp7_capture;
alter function cp7_wip.serve_production(uuid) owner to cp7_capture;
alter function public.erp_cp7_capture_production_wip_v1(jsonb,uuid) owner to cp7_capture;
alter function public.erp_cp7_read_production_wip_v1(uuid) owner to cp7_capture;
alter function public.erp_cp7_capture_cutting_wip_v1(uuid[],uuid) owner to cp7_capture;
alter function public.erp_cp7_read_cutting_wip_v1(uuid) owner to cp7_capture;
revoke all on all functions in schema cp7_wip from public,anon,authenticated,service_role;
revoke all on function public.erp_cp7_capture_cutting_wip_v1(uuid[],uuid),public.erp_cp7_read_cutting_wip_v1(uuid) from public,anon,service_role;
grant execute on function public.erp_cp7_capture_cutting_wip_v1(uuid[],uuid),public.erp_cp7_read_cutting_wip_v1(uuid) to authenticated;
revoke all on function public.erp_cp7_capture_production_wip_v1(jsonb,uuid),public.erp_cp7_read_production_wip_v1(uuid) from public,anon,service_role;
grant execute on function public.erp_cp7_capture_production_wip_v1(jsonb,uuid),public.erp_cp7_read_production_wip_v1(uuid) to authenticated;

-- P09 development bridge. Reads and commands use separate principals; analysis
-- roles never acquire access to purchase/stock writers.
create role cp7_procure_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create role cp7_procure_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_procurement authorization cp7_procure_read;
revoke all on schema cp7_procurement from public,anon,authenticated,service_role;
grant usage,create on schema cp7_procurement to cp7_procure_write;
grant usage on schema erp,auth to cp7_procure_read,cp7_procure_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_procure_read,cp7_procure_write;
grant select on erp.material_purchase_headers,erp.material_purchase_items,erp.material_rolls,
 erp.materials,erp.suppliers,erp.locations,erp.material_stock_movements,erp.bc_accessory_zones_v1 to cp7_procure_read;
grant execute on function erp.save_material_purchase_draft_v2(jsonb,uuid,bigint),
 erp.post_material_purchase_v2(uuid,uuid,bigint,text) to cp7_procure_write;
create table cp7_procurement.execution_context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 action text not null check(action in ('SAVE_DRAFT','POST')),
 permission_key text not null,primary key(backend_pid,transaction_id),
 check((action='SAVE_DRAFT' and permission_key='warehouse.procurement.create')
    or(action='POST' and permission_key='warehouse.procurement.post'))
);
alter table cp7_procurement.execution_context owner to cp7_procure_write;
alter table cp7_procurement.execution_context enable row level security;
revoke all on cp7_procurement.execution_context from public,anon,authenticated,service_role,cp7_capture,cp7_procure_read;

create function cp7_procurement.access_now() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then
  raise exception using errcode='42501',message='CP7_PROCUREMENT_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if (a->>'allowed')::boolean is distinct from true or not erp.has_permission('warehouse.procurement.view') then
  raise exception using errcode='42501',message='CP7_PROCUREMENT_ACCESS_DENIED';end if;
 return jsonb_build_object('actor',auth.uid(),'profile',a->'profile','permissions',a->'permissions',
  'can_value',erp.has_permission('finance.ap.view'),'can_create',erp.has_permission('warehouse.procurement.create'),
  'can_post',erp.has_permission('warehouse.procurement.post'),'can_reverse',erp.has_permission('warehouse.procurement.reverse'));
end $$;
create function cp7_procurement.fields(v jsonb,allowed text[],required text[]) returns void
language plpgsql immutable security invoker set search_path='' as $$
begin
 if jsonb_typeof(v) is distinct from 'object' or not v ?& required or exists(select 1 from jsonb_object_keys(v) k where not k=any(allowed)) then
  raise exception using errcode='22023',message='CP7_PROCUREMENT_FIELDS';end if;
end $$;
create function cp7_procurement.decimal(v jsonb,positive boolean) returns text
language plpgsql immutable security invoker set search_path='' as $$
begin
 if jsonb_typeof(v) is distinct from 'string' or (v#>>'{}') !~ '^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$'
  or (positive and (v#>>'{}')::numeric<=0) then raise exception 'CP7_PROCUREMENT_EXACT_DECIMAL';end if;
 return v#>>'{}';
end $$;

-- P09 live material/roll bridge; no cached draft quantities are stock.
create role cp7_material_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create role cp7_material_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_material authorization cp7_material_read;
revoke all on schema cp7_material from public,anon,authenticated,service_role;
grant usage,create on schema cp7_material to cp7_material_write;
grant usage on schema erp,auth to cp7_material_read,cp7_material_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_material_read,cp7_material_write;
grant select on erp.materials,erp.material_rolls,erp.material_stock_movements,erp.locations,
 erp.bc_accessory_zones_v1,erp.material_purchase_headers,erp.material_purchase_items,erp.material_transfers,erp.material_transfer_items to cp7_material_read;
grant execute on function erp.save_material_transfer_draft_v2(jsonb,uuid,bigint),erp.post_material_transfer_v2(uuid,uuid,bigint,text),
 erp.reverse_material_transfer_v2(uuid,text,uuid,bigint) to cp7_material_write;
create table cp7_material.execution_context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 action text not null check(action in('SAVE_TRANSFER','POST_TRANSFER','REVERSE_TRANSFER','SAVE_COUNT','POST_COUNT','DELETE_COUNT','REVERSE_COUNT')),
 permission_key text not null check(permission_key='warehouse.stock.adjust'),primary key(backend_pid,transaction_id)
);
alter table cp7_material.execution_context owner to cp7_material_write;
alter table cp7_material.execution_context enable row level security;
revoke all on cp7_material.execution_context from public,anon,authenticated,service_role,cp7_capture,cp7_material_read;
create table cp7_material.requests(
 actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text,response jsonb,primary key(actor,request_id)
);
alter table cp7_material.requests owner to cp7_material_write;
alter table cp7_material.requests enable row level security;
revoke all on cp7_material.requests from public,anon,authenticated,service_role,cp7_capture,cp7_material_read;

create function cp7_material.access_now() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;adjust boolean;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_MATERIAL_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if (a->>'allowed')::boolean is distinct from true or not erp.has_permission('warehouse.material.view') then
  raise exception using errcode='42501',message='CP7_MATERIAL_ACCESS_DENIED';end if;
 adjust:=erp.has_permission('warehouse.stock.adjust');
 return jsonb_build_object('actor',auth.uid(),'profile',a->'profile','permissions',a->'permissions',
  'can_value',erp.has_permission('finance.hpp.view'),'can_adjust',adjust,
  'can_reverse',adjust and a->'profile'->>'role_code' in('OWNER','ADMIN'));
end $$;

create function cp7_material.validate_transfer_scope(p_source uuid,p_destination uuid,p_transfer uuid default null) returns void
language plpgsql stable security definer set search_path='' as $$
begin
 perform cp7_material.access_now();
 if p_transfer is not null then
  select from_location_id,to_location_id into p_source,p_destination from erp.material_transfers where id=p_transfer;
  if not found then raise exception 'CP7_MATERIAL_TRANSFER_NOT_FOUND';end if;
 end if;
 if p_source is null or p_destination is null or p_source=p_destination then raise exception 'CP7_MATERIAL_DIFFERENT_LOCATIONS_REQUIRED';end if;
 if exists(select 1 from erp.bc_accessory_zones_v1 where location_id in(p_source,p_destination)) then raise exception 'CP7_MATERIAL_SERVICE_ZONE_WORKFLOW_REQUIRED';end if;
 if (select count(*) from erp.locations where id in(p_source,p_destination) and is_active and location_type='RAW_MATERIAL_WAREHOUSE')<>2 then raise exception 'CP7_MATERIAL_ACTIVE_WAREHOUSES_REQUIRED';end if;
end $$;

create function cp7_material.validate_lines(p_lines jsonb) returns void
language plpgsql stable security definer set search_path='' as $$
declare line jsonb;
begin
 -- Narrow read authority, not a BYPASSRLS writer. Only the private command
 -- principal can execute this validator; recheck the caller's view grant.
 perform cp7_material.access_now();
 if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100 then raise exception 'CP7_MATERIAL_LINES';end if;
 for line in select value from jsonb_array_elements(p_lines) loop
  if jsonb_typeof(line) is distinct from 'object' or not line ?& array['material_id','roll_id','qty']
   or exists(select 1 from jsonb_each(line) e where e.key not in('material_id','roll_id','qty','notes') or jsonb_typeof(e.value) not in('string','null'))
   or line->>'qty' is null or line->>'qty'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$' or (line->>'qty')::numeric<=0 then raise exception 'CP7_MATERIAL_EXACT_LINE';end if;
  if not exists(select 1 from erp.materials m where m.id=(line->>'material_id')::uuid
   and ((m.material_type='FABRIC' and exists(select 1 from erp.material_rolls r where r.id=(line->>'roll_id')::uuid and r.material_id=m.id))
    or (m.material_type<>'FABRIC' and line->'roll_id'='null'::jsonb))) then raise exception 'CP7_MATERIAL_LINEAGE_REQUIRED';end if;
 end loop;
end $$;

-- P09 source-linked physical supplier returns. Price/AP/GRNI stay in the
-- accepted return writers; the browser may never supply a credit valuation.
create role cp7_return_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create role cp7_return_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_supplier_return authorization cp7_return_read;
revoke all on schema cp7_supplier_return from public,anon,authenticated,service_role;
grant usage,create on schema cp7_supplier_return to cp7_return_write;
grant usage on schema erp,auth to cp7_return_read,cp7_return_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_return_read,cp7_return_write;
grant select on erp.material_purchase_headers,erp.material_purchase_items,erp.material_rolls,erp.materials,erp.locations,
 erp.bc_accessory_zones_v1,erp.material_stock_movements,erp.material_supplier_returns,erp.material_supplier_return_items,erp.suppliers to cp7_return_read;
grant execute on function erp.save_material_supplier_return_draft_v2(jsonb,uuid,bigint),erp.post_material_supplier_return_v2(uuid,uuid,bigint,text),
 erp.reverse_material_supplier_return_v2(uuid,text,uuid,bigint) to cp7_return_write;
create table cp7_supplier_return.execution_context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 action text not null check(action in('SAVE','POST','REVERSE')),
 permission_key text not null check(permission_key in('warehouse.procurement.create','warehouse.procurement.reverse')),
 primary key(backend_pid,transaction_id)
);
alter table cp7_supplier_return.execution_context owner to cp7_return_write;
alter table cp7_supplier_return.execution_context enable row level security;
revoke all on cp7_supplier_return.execution_context from public,anon,authenticated,service_role,cp7_capture,cp7_return_read;
-- Bind the complete outer intent before inspecting mutable receipt/draft
-- membership. Replaying a known SAVE after later correction returns its original
-- outcome, then the caller separately reloads current business state.
create table cp7_supplier_return.requests(
 actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,
 expected_version text,response jsonb,primary key(actor,request_id)
);
alter table cp7_supplier_return.requests owner to cp7_return_write;
alter table cp7_supplier_return.requests enable row level security;
revoke all on cp7_supplier_return.requests from public,anon,authenticated,service_role,cp7_capture,cp7_return_read;
create function cp7_supplier_return.access_now() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_RETURN_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if (a->>'allowed')::boolean is distinct from true or not erp.has_permission('warehouse.procurement.view') then raise exception using errcode='42501',message='CP7_RETURN_ACCESS_DENIED';end if;
 return jsonb_build_object('actor',auth.uid(),'profile',a->'profile','permissions',a->'permissions','view_value',erp.has_permission('finance.ap.view'),
  'create',erp.has_permission('warehouse.procurement.create'),'post',erp.has_permission('warehouse.procurement.reverse'),
  'reverse',erp.has_permission('warehouse.procurement.reverse') and a->'profile'->>'role_code' in('OWNER','ADMIN'));
end $$;

create function cp7_supplier_return.validate_source(p_purchase uuid,p_payload jsonb) returns void
language plpgsql stable security definer set search_path='' as $$
declare l jsonb;
begin
 perform cp7_supplier_return.access_now();
 if not exists(select 1 from erp.material_purchase_headers where id=p_purchase and status='POSTED' and supplier_id=(p_payload->>'supplier_id')::uuid) then raise exception 'CP7_RETURN_POSTED_SOURCE_REQUIRED';end if;
 if jsonb_typeof(p_payload->'items') is distinct from 'array' or jsonb_array_length(p_payload->'items') not between 1 and 100 then raise exception 'CP7_RETURN_LINES';end if;
 for l in select value from jsonb_array_elements(p_payload->'items') loop
  if jsonb_typeof(l) is distinct from 'object' or not l ?& array['purchase_item_id','material_id','roll_id','qty'] or exists(select 1 from jsonb_each(l) e
   where e.key not in('purchase_item_id','material_id','roll_id','qty','notes') or jsonb_typeof(e.value) not in('string','null')) then raise exception 'CP7_RETURN_LINE_FIELDS';end if;
  if l->>'qty' is null or l->>'qty'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$' or (l->>'qty')::numeric<=0 then raise exception 'CP7_RETURN_EXACT_QUANTITY';end if;
  if not exists(select 1 from erp.material_purchase_items i join erp.materials m on m.id=i.material_id where i.id=(l->>'purchase_item_id')::uuid and i.purchase_id=p_purchase and i.material_id=(l->>'material_id')::uuid
    and ((m.material_type='FABRIC' and exists(select 1 from erp.material_rolls r where r.id=(l->>'roll_id')::uuid and r.material_id=i.material_id and r.purchase_item_id=i.id)) or (m.material_type<>'FABRIC' and l->>'roll_id' is null))) then raise exception 'CP7_RETURN_SOURCE_LINEAGE';end if;
 end loop;
end $$;
create function cp7_supplier_return.assert_document(p_purchase uuid,p_return uuid) returns void
language plpgsql stable security definer set search_path='' as $$
begin
 perform cp7_supplier_return.access_now();
 if not exists(select 1 from erp.material_supplier_return_items r join erp.material_purchase_items i on i.id=r.purchase_item_id where r.return_id=p_return and i.purchase_id=p_purchase)
  or exists(select 1 from erp.material_supplier_return_items r left join erp.material_purchase_items i on i.id=r.purchase_item_id where r.return_id=p_return and i.purchase_id is distinct from p_purchase) then raise exception 'CP7_RETURN_COMPLETE_SOURCE_DOCUMENT_REQUIRED';end if;
end $$;
-- Validate the physical source at both sides of the accepted POST's waits.
-- Reversal deliberately remains possible after a master is deactivated.
create function cp7_supplier_return.validate_post(p_purchase uuid,p_return uuid) returns void
language plpgsql stable security definer set search_path='' as $$
begin
 perform cp7_supplier_return.access_now();
 perform cp7_supplier_return.assert_document(p_purchase,p_return);
 if not exists(select 1 from erp.material_supplier_returns h join erp.locations l on l.id=h.location_id where h.id=p_return and l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE'
  and not exists(select 1 from erp.bc_accessory_zones_v1 z where z.location_id=l.id)) then raise exception 'CP7_RETURN_ACTIVE_WAREHOUSE_REQUIRED';end if;
 if exists(select 1 from erp.material_supplier_return_items r join erp.materials m on m.id=r.material_id where r.return_id=p_return and not m.is_active) then raise exception 'CP7_RETURN_ACTIVE_MATERIAL_REQUIRED';end if;
 if (select count(*) from erp.material_supplier_return_items where return_id=p_return)>100 then raise exception 'CP7_RETURN_COMPLETE_DOCUMENT_REQUIRED';end if;
end $$;

-- Declared CP7 deltas against exact accepted function definitions. Original CP6
-- release files stay immutable; restoration must put back these exact two defs.
do $$begin
 if encode(extensions.digest(pg_get_functiondef('erp.require_internal()'::regprocedure),'sha256'),'hex')<>'5dffcd53c0a5de609ae41482ca246d2afc806b9d92241253d680cf5c7fe1612e'
  or encode(extensions.digest(pg_get_functiondef('erp.bc_guard_zone_location_v1()'::regprocedure),'sha256'),'hex')<>'95ff4304ba90c3214a4fb718278d06f716bf3213170fa0f1cb3ab8a5375e4c26' then
  raise exception 'CP7_PROCUREMENT_PREDECESSOR_CHANGED';end if;
end $$;

create or replace function erp.require_internal() returns void
language plpgsql security definer set search_path='' as $function$
declare v_app_role text;v_jwt_role text;
begin
 if session_user in('postgres','supabase_admin') then return;end if;
 begin v_jwt_role:=coalesce(auth.jwt()->>'role','');exception when others then v_jwt_role:='';end;
 if v_jwt_role='service_role' then return;end if;
 -- Keep indexable identity filters, and evaluate live scope permissions only
 -- for that exact candidate. SQL AND does not fix predicate evaluation order.
 -- Matched scope checks and the existing legacy fallback remain unchanged.
 if exists(select 1 from erp.cutting_bridge_execution_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor_key=erp._idempotency_actor_key() and c.action='POST_CUTTING'
   and c.permission_key='production.cutting.post' then erp.has_permission(c.permission_key) else false end) then return;end if;
 if exists(select 1 from erp.bs_resolution_execution_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor_key=erp._idempotency_actor_key()
   and c.permission_key in('production.bs_rework.create','production.bs_rework.post','production.bs_rework.reverse')
   then erp.has_permission(c.permission_key) else false end) then return;end if;
 if exists(select 1 from erp.cp6_laundry_qc_execution_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor_key=erp._idempotency_actor_key()
   and ((c.action in('POST_DELIVERY','POST_RECEIPT','POST_FAILED_WASH') and c.permission_key='production.laundry.post')
    or(c.action='POST_FINAL_SKU' and c.permission_key='production.final_sku.post')
    or(c.action in('REVERSE_DELIVERY','REVERSE_RECEIPT') and c.permission_key='production.laundry.reverse')
    or(c.action='REVERSE_FINAL_SKU' and c.permission_key='production.final_sku.reverse'))
   then erp.has_permission(c.permission_key) else false end) then return;end if;
 -- Only a private, transaction/actor-bound public-command context extends the
 -- legacy internal-role guard. Caller-controlled GUCs cannot grant this path.
 if exists(select 1 from cp7_procurement.execution_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
   and ((c.action='SAVE_DRAFT' and c.permission_key='warehouse.procurement.create')
    or(c.action='POST' and c.permission_key='warehouse.procurement.post'))
   then erp.has_permission('warehouse.procurement.view') and erp.has_permission(c.permission_key) else false end) then return;end if;
 if exists(select 1 from cp7_material.execution_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
   and c.action in('SAVE_TRANSFER','POST_TRANSFER','REVERSE_TRANSFER','SAVE_COUNT','POST_COUNT','DELETE_COUNT','REVERSE_COUNT') and c.permission_key='warehouse.stock.adjust'
   then erp.has_permission('warehouse.material.view') and erp.has_permission(c.permission_key) else false end) then return;end if;
 if exists(select 1 from cp7_supplier_return.execution_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
   and ((c.action='SAVE' and c.permission_key='warehouse.procurement.create')
    or(c.action in('POST','REVERSE') and c.permission_key='warehouse.procurement.reverse'))
   then erp.has_permission('warehouse.procurement.view') and erp.has_permission(c.permission_key) else false end) then return;end if;
 v_app_role:=erp.current_app_role();
 if coalesce(v_app_role,'') not in('OWNER','ADMIN','STAFF') then raise exception 'Internal ERP access required';end if;
end $function$;

create or replace function erp.bc_guard_zone_location_v1() returns trigger
language plpgsql security definer set search_path='' as $function$
begin
 if tg_table_name='bc_accessory_zones_v1' then
  if tg_op='DELETE' or new.location_id<>old.location_id or new.zone_kind<>old.zone_kind then
   raise exception 'BC_ZONE_IMMUTABLE: jenis zona tetap; buat zona baru bila perlu';end if;
  return new;
 end if;
 -- This branch is a locations trigger: its identity is OLD.id. OLD.location_id
 -- exists only on the separate zone relation handled above.
 if exists(select 1 from erp.bc_accessory_zones_v1 where location_id=old.id) and
  (new.location_type is distinct from old.location_type or
   (old.is_active and not new.is_active and exists(select 1 from erp.material_stock_movements m
    where m.location_id=old.id group by m.material_id having sum(m.qty_signed)<>0))) then
  raise exception 'BC_ZONE_IMMUTABLE: zona tetap gudang bahan dan tidak dinonaktifkan selama masih ada stok';end if;
 return new;
end $function$;

-- Operational reads deliberately expose no financial metadata to a reader
-- without finance.ap.view. These are live, paged workspaces, not planner captures.
create function cp7_procurement.header(h erp.material_purchase_headers,can_value boolean) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',h.id,'purchase_number',h.purchase_number,'supplier_id',h.supplier_id,
  'supplier_name',(select s.supplier_name from erp.suppliers s where s.id=h.supplier_id),
  'location_id',h.location_id,'location_name',(select l.location_name from erp.locations l where l.id=h.location_id),
  'physical_at',h.physical_at,'status',h.status,'row_version',h.row_version::text,
  'notes',h.notes,'line_count',(select count(*) from erp.material_purchase_items i where i.purchase_id=h.id))
 || case when can_value then jsonb_build_object('finance',jsonb_build_object(
  'supplier_invoice_number',h.supplier_invoice_number,'due_date',h.due_date,'payment_status',h.payment_status,
  'receipt_value',(select coalesce(sum(i.line_total),0)::text from erp.material_purchase_items i where i.purchase_id=h.id),
  'basis','RECEIPT_PRICE_NOT_CURRENT_PAYABLE')) else '{}'::jsonb end
$$;

create function cp7_procurement.workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;outrows jsonb;items jsonb;detail jsonb:='null'::jsonb;h erp.material_purchase_headers;
 q text;st text;n integer;off integer;pid uuid;total bigint;rolled integer;
begin
 a:=cp7_procurement.access_now();
 perform cp7_procurement.fields(p_query,array['q','status','limit','offset','purchase_id'],array[]::text[]);
 if exists(select 1 from jsonb_each(p_query) e where e.key in ('q','status','purchase_id') and jsonb_typeof(e.value) not in ('string','null')) then raise exception 'CP7_PROCUREMENT_QUERY';end if;
 if (p_query ? 'limit' and (jsonb_typeof(p_query->'limit')<>'number' or (p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query ? 'offset' and (jsonb_typeof(p_query->'offset')<>'number' or (p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_PROCUREMENT_PAGE';end if;
 q:=btrim(coalesce(p_query->>'q',''));st:=coalesce(p_query->>'status','ALL');n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);
 pid:=nullif(p_query->>'purchase_id','')::uuid;
 if length(q)>120 or st not in ('ALL','DRAFT','POSTED','REVERSED') or n not between 1 and 100 or off not between 0 and 1000000 then raise exception 'CP7_PROCUREMENT_QUERY';end if;
 select count(*) into total from erp.material_purchase_headers x left join erp.suppliers s on s.id=x.supplier_id
 where (st='ALL' or x.status=st) and (q='' or strpos(lower(x.purchase_number||' '||coalesce(s.supplier_name,'')),lower(q))>0);
 select coalesce(jsonb_agg(cp7_procurement.header(x::erp.material_purchase_headers,(a->>'can_value')::boolean) order by x.physical_at desc,x.id),'[]'::jsonb) into outrows
 from (select x.* from erp.material_purchase_headers x left join erp.suppliers s on s.id=x.supplier_id
  where (st='ALL' or x.status=st) and (q='' or strpos(lower(x.purchase_number||' '||coalesce(s.supplier_name,'')),lower(q))>0)
  order by x.physical_at desc,x.id limit n offset off) x;
 if pid is not null then
  select * into h from erp.material_purchase_headers where id=pid;
  if not found then raise exception 'CP7_PROCUREMENT_NOT_FOUND';end if;
  if (select count(*) from erp.material_purchase_items where purchase_id=pid)>100 then raise exception 'CP7_PROCUREMENT_DOCUMENT_TOO_LARGE';end if;
  select count(*) into rolled from erp.material_rolls r join erp.material_purchase_items i on i.id=r.purchase_item_id where i.purchase_id=pid;
  if rolled>2000 then raise exception 'CP7_PROCUREMENT_DOCUMENT_TOO_LARGE';end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'material_id',i.material_id,'material_sku',m.material_sku,
   'material_name',m.material_name,'material_type',m.material_type,'unit_code',m.unit_code,'qty',i.qty::text,
   'purchase_qty_entered',i.purchase_qty_entered::text,'purchase_uom_code',i.purchase_uom_code,'purchase_uom_factor',i.purchase_uom_factor_snapshot::text,
   'lot_number',i.lot_number,'notes',i.notes,
   'rolls',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'roll_number',r.roll_number,
     'receipt_qty',r.original_qty::text,'notes',r.notes) order by r.roll_number,r.id)
    from erp.material_rolls r where r.purchase_item_id=i.id),'[]'::jsonb))
   ||case when (a->>'can_value')::boolean then jsonb_build_object('finance',jsonb_build_object(
    'unit_price',i.unit_price::text,'line_total',i.line_total::text,'price_state',i.price_state,'price_source',i.price_source,
    'invoice_match_state',i.invoice_match_state,'benchmark_price_version_id',i.benchmark_price_version_id,'purchase_price_per_uom',i.purchase_price_per_uom_snapshot::text)) else '{}'::jsonb end order by i.id),'[]'::jsonb)
   into items from erp.material_purchase_items i join erp.materials m on m.id=i.material_id where i.purchase_id=pid;
  detail:=cp7_procurement.header(h,(a->>'can_value')::boolean)||jsonb_build_object('items',items,
   'stock_effect',case when h.status='DRAFT' then 'NOT_POSTED' when h.status='POSTED' then 'POSTED_RECEIPT' else 'REVERSED_RECEIPT' end,
   'quantity_basis','RECEIPT_DOCUMENT_NOT_CURRENT_ON_HAND');
 end if;
 return jsonb_build_object('contract_version','cp7.procurement-workspace.v1','kind','LIVE_WORKSPACE','read_at',statement_timestamp(),
  'capabilities',jsonb_build_object('create',a->'can_create','post',a->'can_post','reverse',(a->>'can_reverse')::boolean and a->'profile'->>'role_code' in('OWNER','ADMIN'),'view_value',a->'can_value'),
  'page',jsonb_build_object('rows',outrows,'total',total::text,'offset',off,'limit',n,
   'next_offset',case when off+jsonb_array_length(outrows)<total then off+jsonb_array_length(outrows) else null end),
  'detail',detail);
end $$;

create function cp7_procurement.options(p_kind text,p_q text,p_offset integer,p_limit integer) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;rows jsonb;total bigint;q text:=lower(btrim(coalesce(p_q,'')));
begin
 a:=cp7_procurement.access_now();
 if p_kind is null or p_kind not in ('MATERIAL','SUPPLIER','LOCATION') or length(q)>120
  or p_offset is null or p_offset not between 0 and 1000000 or p_limit is null or p_limit not between 1 and 100 then raise exception 'CP7_PROCUREMENT_OPTIONS';end if;
 if p_kind='MATERIAL' then
  select count(*) into total from erp.materials m where m.is_active and (q='' or strpos(lower(m.material_sku||' '||m.material_name),q)>0);
  select coalesce(jsonb_agg(jsonb_build_object('id',m.id,'code',m.material_sku,'name',m.material_name,'material_type',m.material_type,
   'unit_code',m.unit_code) order by m.material_sku,m.id),'[]'::jsonb) into rows
  from (select * from erp.materials m where m.is_active and (q='' or strpos(lower(m.material_sku||' '||m.material_name),q)>0)
   order by m.material_sku,m.id limit p_limit offset p_offset) m;
 elsif p_kind='SUPPLIER' then
  select count(*) into total from erp.suppliers s where s.is_active and (q='' or strpos(lower(s.supplier_code||' '||s.supplier_name),q)>0);
  select coalesce(jsonb_agg(jsonb_build_object('id',s.id,'code',s.supplier_code,'name',s.supplier_name) order by s.supplier_code,s.id),'[]'::jsonb) into rows
  from (select * from erp.suppliers s where s.is_active and (q='' or strpos(lower(s.supplier_code||' '||s.supplier_name),q)>0)
   order by s.supplier_code,s.id limit p_limit offset p_offset) s;
 else
  select count(*) into total from erp.locations l where l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE' and not exists(select 1 from erp.bc_accessory_zones_v1 z where z.location_id=l.id) and (q='' or strpos(lower(l.location_code||' '||l.location_name),q)>0);
  select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'code',l.location_code,'name',l.location_name) order by l.location_code,l.id),'[]'::jsonb) into rows
  from (select * from erp.locations l where l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE' and not exists(select 1 from erp.bc_accessory_zones_v1 z where z.location_id=l.id) and (q='' or strpos(lower(l.location_code||' '||l.location_name),q)>0)
   order by l.location_code,l.id limit p_limit offset p_offset) l;
 end if;
 return jsonb_build_object('contract_version','cp7.procurement-options.v1','kind',p_kind,'rows',rows,'total',total::text,
  'offset',p_offset,'limit',p_limit,'next_offset',case when p_offset+jsonb_array_length(rows)<total then p_offset+jsonb_array_length(rows) else null end);
end $$;

-- The predecessor reverse writer has no version/idempotency entrypoint. This
-- private adapter adds only locking/version admission and outcome identity;
-- all reversal dependencies, physical inverses and journals stay in that writer.
-- Its postgres ownership is necessary to lock the receipt without granting any
-- business SELECT/UPDATE privilege to the public command principal.
create table cp7_procurement.reversals(
 actor uuid not null,request_id uuid not null,payload jsonb not null,expected_version text not null,
 response jsonb,primary key(actor,request_id)
);
alter table cp7_procurement.reversals owner to cp7_procure_write;
alter table cp7_procurement.reversals enable row level security;
revoke all on cp7_procurement.reversals from public,anon,authenticated,service_role,cp7_capture,cp7_procure_read;
create function cp7_procurement.reverse_receipt_locked(p_purchase uuid,p_version bigint,p_reason text) returns jsonb
language plpgsql volatile security definer set search_path='' as $$
declare a jsonb;h erp.material_purchase_headers;
begin
 a:=cp7_procurement.access_now();
 if a->'can_reverse' is distinct from 'true'::jsonb or (a->'profile'->>'role_code' in('OWNER','ADMIN')) is distinct from true then raise exception using errcode='42501',message='CP7_PROCUREMENT_REVERSE_DENIED';end if;
 if p_version is null or p_purchase is null or nullif(btrim(p_reason),'') is null then raise exception 'CP7_PROCUREMENT_REVERSE_FIELDS';end if;
 select * into h from erp.material_purchase_headers where id=p_purchase for update;
 if not found then raise exception 'CP7_PROCUREMENT_NOT_FOUND';end if;
 if h.row_version<>p_version then raise exception 'STALE_VERSION expected %, current %',p_version,h.row_version;end if;
 if h.status<>'POSTED' then raise exception 'CP7_PROCUREMENT_POSTED_RECEIPT_REQUIRED';end if;
 if cp7_procurement.access_now()<>a then raise exception using errcode='42501',message='CP7_PROCUREMENT_ACCESS_CHANGED';end if;
 perform erp.reverse_material_purchase(p_purchase,p_reason);
 select * into h from erp.material_purchase_headers where id=p_purchase;
 if cp7_procurement.access_now()<>a then raise exception using errcode='42501',message='CP7_PROCUREMENT_ACCESS_CHANGED';end if;
 return jsonb_build_object('purchase_id',h.id,'status',h.status,'row_version',h.row_version::text);
end $$;
alter function cp7_procurement.reverse_receipt_locked(uuid,bigint,text) owner to postgres;
create function cp7_procurement.reverse_request(p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_procurement.reversals;r jsonb;
begin
 a:=cp7_procurement.access_now();
 if a->'can_reverse' is distinct from 'true'::jsonb or (a->'profile'->>'role_code' in('OWNER','ADMIN')) is distinct from true then raise exception using errcode='42501',message='CP7_PROCUREMENT_REVERSE_DENIED';end if;
 perform cp7_procurement.fields(p_payload,array['purchase_id','change_reason'],array['purchase_id','change_reason']);
 if p_expected is null or p_request is null or exists(select 1 from jsonb_each(p_payload) e where jsonb_typeof(e.value)<>'string' or nullif(btrim(e.value#>>'{}'),'') is null) then raise exception 'CP7_PROCUREMENT_REVERSE_FIELDS';end if;
 insert into cp7_procurement.reversals(actor,request_id,payload,expected_version) values(auth.uid(),p_request,p_payload,p_expected) on conflict do nothing;
 select * into old from cp7_procurement.reversals where actor=auth.uid() and request_id=p_request for update;
 if old.payload<>p_payload or old.expected_version<>p_expected then raise exception 'CP7_PROCUREMENT_REVERSE_REQUEST_CHANGED';end if;
 if cp7_procurement.access_now()<>a then raise exception using errcode='42501',message='CP7_PROCUREMENT_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 r:=cp7_procurement.reverse_receipt_locked((p_payload->>'purchase_id')::uuid,p_expected::bigint,p_payload->>'change_reason');
 r:=jsonb_build_object('contract_version','cp7.procurement-outcome.v1','kind','COMMITTED_OUTCOME','action','REVERSE','request_id',p_request,
  'purchase_id',r->'purchase_id','status',r->>'status','row_version',r->>'row_version');
 update cp7_procurement.reversals set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;

-- Purchase-unit selection is a dated master read. Native accessory triggers
-- remain the only conversion/price calculation authority.
grant select on erp.accessory_categories,erp.accessory_category_uom_conversions,erp.uom_definitions to cp7_procure_read;
create function cp7_procurement.uom_options(p_material uuid,p_at timestamptz) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;m erp.materials;cat erp.accessory_categories;rows jsonb;
begin
 a:=cp7_procurement.access_now();
 if p_at is null or p_material is null then raise exception 'CP7_PROCUREMENT_UOM_TIME_MATERIAL';end if;
 select * into m from erp.materials where id=p_material and is_active;
 if not found or m.material_type<>'ACCESSORY' then raise exception 'CP7_PROCUREMENT_ACCESSORY_REQUIRED';end if;
 select * into cat from erp.accessory_categories where id=m.accessory_category_id and is_active;
 if not found or cat.base_uom_code<>m.unit_code then raise exception 'CP7_PROCUREMENT_ACCESSORY_CATEGORY';end if;
 if not exists(select 1 from erp.uom_definitions where unit_code=m.unit_code and is_active) then raise exception 'CP7_PROCUREMENT_ACTIVE_BASE_UOM_REQUIRED';end if;
 select coalesce(jsonb_agg(jsonb_build_object('code',upper(x.unit_code),'name',x.unit_name,'factor',x.factor::text,'dimension',x.dimension) order by x.base_first,x.unit_code),'[]'::jsonb) into rows
 from (
  select u.unit_code,u.unit_name,u.dimension,1::numeric factor,0 base_first from erp.uom_definitions u where u.unit_code=m.unit_code and u.is_active
  union all
  select u.unit_code,u.unit_name,u.dimension,c.base_qty_per_uom,1 from erp.accessory_category_uom_conversions c join erp.uom_definitions u on upper(u.unit_code)=upper(c.uom_code)
   where c.category_id=cat.id and u.is_active and upper(c.uom_code)<>upper(m.unit_code) and c.effective_from<=p_at and (c.effective_to is null or c.effective_to>p_at)
 ) x;
 if jsonb_array_length(rows) not between 1 and 100 then raise exception 'CP7_PROCUREMENT_UOM_COMPLETE_REQUIRED';end if;
 return jsonb_build_object('contract_version','cp7.procurement-uom.v1','material_id',m.id,'physical_at',p_at,'base_unit',m.unit_code,'rows',rows);
end $$;

-- Validation occurs only on the first intent. A later master change cannot
-- make a previously committed response unrecoverable.
create function cp7_procurement.validate_uom_lines(p_payload jsonb) returns void
language plpgsql stable security definer set search_path='' as $$
declare line jsonb;m erp.materials;
begin
 perform cp7_procurement.access_now();
 for line in select value from jsonb_array_elements(p_payload->'lines') loop
  if line ? 'purchase_uom_code' then
   select * into m from erp.materials where id=(line->>'material_id')::uuid;
   if not found or m.material_type<>'ACCESSORY' then raise exception 'CP7_PROCUREMENT_ACCESSORY_REQUIRED';end if;
   if not exists(select 1 from erp.uom_definitions where upper(unit_code)=upper(line->>'purchase_uom_code') and is_active) then raise exception 'CP7_PROCUREMENT_ACTIVE_UOM_REQUIRED';end if;
  end if;
 end loop;
end $$;
create table cp7_procurement.draft_requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,expected_version text,response jsonb,primary key(actor,request_id)
);
alter table cp7_procurement.draft_requests owner to cp7_procure_write;
alter table cp7_procurement.draft_requests enable row level security;
revoke all on cp7_procurement.draft_requests from public,anon,authenticated,service_role,cp7_capture,cp7_procure_read;
create function cp7_procurement.save_draft_request(p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare old cp7_procurement.draft_requests;r jsonb;
begin
 insert into cp7_procurement.draft_requests(actor,request_id,payload,expected_version) values(auth.uid(),p_request,p_payload,p_expected) on conflict do nothing;
 select * into old from cp7_procurement.draft_requests where actor=auth.uid() and request_id=p_request for update;
 if old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_PROCUREMENT_DRAFT_REQUEST_CHANGED: different payload or version';end if;
 if old.response is not null then return old.response;end if;
 perform cp7_procurement.validate_uom_lines(p_payload);
 r:=erp.save_material_purchase_draft_v2(p_payload,p_request,p_expected::bigint);
 r:=jsonb_build_object('purchase_id',r->'purchase_id','status',r->'status','row_version',r->>'row_version');
 update cp7_procurement.draft_requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;

-- Draft/post and locked receipt inverse route through accepted CP6 writers.
create function cp7_procurement.command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;z jsonb;r jsonb;line jsonb;roll jsonb;expected bigint;price boolean:=false;roll_count integer:=0;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_procurement.access_now();
 if p_request is null or p_action not in ('SAVE_DRAFT','POST','REVERSE') or p_action is null then raise exception 'CP7_PROCUREMENT_ACTION';end if;
 if p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_PROCUREMENT_VERSION';end if;
 expected:=p_expected::bigint;
 if p_action='REVERSE' then return cp7_procurement.reverse_request(p_payload,p_request,p_expected);end if;
 if p_action='SAVE_DRAFT' then
  if a->'can_create'<>'true'::jsonb then raise exception using errcode='42501',message='CP7_PROCUREMENT_CREATE_DENIED';end if;
  perform cp7_procurement.fields(p_payload,array['id','purchase_number','supplier_id','location_id','physical_at','change_reason','notes','supplier_invoice_number','due_date','lines'],
   array['purchase_number','supplier_id','location_id','physical_at','change_reason','lines']);
  if exists(select 1 from jsonb_each(p_payload) e where e.key<>'lines' and jsonb_typeof(e.value) not in ('string','null')) then raise exception 'CP7_PROCUREMENT_FIELDS';end if;
  if (p_payload ? 'supplier_invoice_number' or p_payload ? 'due_date') and a->'can_value'<>'true'::jsonb then raise exception using errcode='42501',message='CP7_PROCUREMENT_VALUE_DENIED';end if;
  if nullif(p_payload->>'id','') is not null and a->'can_value'<>'true'::jsonb then raise exception using errcode='42501',message='CP7_PROCUREMENT_VALUE_REQUIRED_FOR_EDIT';end if;
  if jsonb_typeof(p_payload->'lines') is distinct from 'array' or jsonb_array_length(p_payload->'lines') not between 1 and 100 then raise exception 'CP7_PROCUREMENT_LINES';end if;
  for line in select value from jsonb_array_elements(p_payload->'lines') loop
   perform cp7_procurement.fields(line,array['material_id','qty','unit_price','price_state','price_source','rolls','lot_number','notes','purchase_qty_entered','purchase_uom_code','purchase_price_per_uom_snapshot'],array['material_id','price_state','price_source','rolls']);
   if exists(select 1 from jsonb_each(line) e where e.key<>'rolls' and jsonb_typeof(e.value) not in ('string','null')) then raise exception 'CP7_PROCUREMENT_FIELDS';end if;
   if line ?| array['purchase_qty_entered','purchase_uom_code','purchase_price_per_uom_snapshot'] then
    if not line ?& array['purchase_qty_entered','purchase_uom_code','purchase_price_per_uom_snapshot'] or line ?| array['qty','unit_price']
     or jsonb_typeof(line->'purchase_uom_code') is distinct from 'string' or length(btrim(line->>'purchase_uom_code')) not between 1 and 20
     or line->>'price_source'='BENCHMARK' or line->'rolls'<>'[]'::jsonb then raise exception 'CP7_PROCUREMENT_UOM_FIELDS';end if;
    perform cp7_procurement.decimal(line->'purchase_qty_entered',true);
    perform cp7_procurement.decimal(line->'purchase_price_per_uom_snapshot',false);price:=true;
   else
    perform cp7_procurement.decimal(line->'qty',true);
   if line ? 'unit_price' and line->'unit_price'<>'null'::jsonb then
    perform cp7_procurement.decimal(line->'unit_price',false);price:=true;
   elsif line->>'price_source' is distinct from 'BENCHMARK' or line->>'price_state' is distinct from 'ESTIMATED' then
    raise exception 'CP7_PROCUREMENT_PRICE_REQUIRED_OR_BENCHMARK';end if;
   end if;
   if line->>'price_source'='MIGRATION' then raise exception 'CP7_PROCUREMENT_USE_IMPORT_WORKFLOW';end if;
   if jsonb_typeof(line->'rolls') is distinct from 'array' or jsonb_array_length(line->'rolls')>500 then raise exception 'CP7_PROCUREMENT_ROLLS';end if;
   roll_count:=roll_count+jsonb_array_length(line->'rolls');
   if roll_count>2000 then raise exception 'CP7_PROCUREMENT_DOCUMENT_TOO_LARGE';end if;
   for roll in select value from jsonb_array_elements(line->'rolls') loop
    perform cp7_procurement.fields(roll,array['roll_number','qty','notes'],array['roll_number','qty']);
    if exists(select 1 from jsonb_each(roll) e where jsonb_typeof(e.value) not in ('string','null')) then raise exception 'CP7_PROCUREMENT_FIELDS';end if;
    perform cp7_procurement.decimal(roll->'qty',true);
   end loop;
  end loop;
  if price and a->'can_value'<>'true'::jsonb then raise exception using errcode='42501',message='CP7_PROCUREMENT_VALUE_DENIED';end if;
  insert into cp7_procurement.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),p_action,'warehouse.procurement.create');
  r:=cp7_procurement.save_draft_request(p_payload,p_request,p_expected);
 else
  if a->'can_post'<>'true'::jsonb then raise exception using errcode='42501',message='CP7_PROCUREMENT_POST_DENIED';end if;
  perform cp7_procurement.fields(p_payload,array['purchase_id','change_reason'],array['purchase_id','change_reason']);
  if exists(select 1 from jsonb_each(p_payload) e where jsonb_typeof(e.value)<>'string') then raise exception 'CP7_PROCUREMENT_FIELDS';end if;
  if expected is null then raise exception 'CP7_PROCUREMENT_VERSION';end if;
  insert into cp7_procurement.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),p_action,'warehouse.procurement.post');
  r:=erp.post_material_purchase_v2((p_payload->>'purchase_id')::uuid,p_request,expected,p_payload->>'change_reason');
 end if;
 -- A revocation while an existing business writer waited rolls back the entire
 -- call. A cached outcome is checked against current access as well.
 z:=cp7_procurement.access_now();
 if z<>a then raise exception using errcode='42501',message='CP7_PROCUREMENT_ACCESS_CHANGED';end if;
 delete from cp7_procurement.execution_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
 return jsonb_build_object('contract_version','cp7.procurement-outcome.v1','kind','COMMITTED_OUTCOME',
  'action',p_action,'request_id',p_request,'purchase_id',r->'purchase_id','status',r->'status','row_version',r->>'row_version');
end $$;

-- The only exposed calls. Read and command owners are deliberately separate.
create function public.erp_cp7_get_procurement_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_procurement.workspace(p_query)$$;
create function public.erp_cp7_get_procurement_options_v1(p_kind text,p_q text,p_offset integer,p_limit integer) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_procurement.options(p_kind,p_q,p_offset,p_limit)$$;
create function public.erp_cp7_get_procurement_uom_v1(p_material uuid,p_at timestamptz) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_procurement.uom_options(p_material,p_at)$$;
create function public.erp_cp7_save_procurement_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_procurement.command(p_action,p_payload,p_request,p_expected)$$;
grant create on schema public,cp7_procurement to cp7_procure_read,cp7_procure_write;
alter function cp7_procurement.access_now() owner to cp7_procure_read;
alter function cp7_procurement.fields(jsonb,text[],text[]) owner to cp7_procure_read;
alter function cp7_procurement.decimal(jsonb,boolean) owner to cp7_procure_read;
alter function cp7_procurement.header(erp.material_purchase_headers,boolean) owner to cp7_procure_read;
alter function cp7_procurement.workspace(jsonb) owner to cp7_procure_read;
alter function cp7_procurement.options(text,text,integer,integer) owner to cp7_procure_read;
alter function cp7_procurement.uom_options(uuid,timestamptz) owner to cp7_procure_read;
alter function cp7_procurement.validate_uom_lines(jsonb) owner to cp7_procure_read;
alter function cp7_procurement.save_draft_request(jsonb,uuid,text) owner to cp7_procure_write;
alter function cp7_procurement.reverse_request(jsonb,uuid,text) owner to cp7_procure_write;
alter function cp7_procurement.command(text,jsonb,uuid,text) owner to cp7_procure_write;
alter function public.erp_cp7_get_procurement_v1(jsonb) owner to cp7_procure_read;
alter function public.erp_cp7_get_procurement_options_v1(text,text,integer,integer) owner to cp7_procure_read;
alter function public.erp_cp7_get_procurement_uom_v1(uuid,timestamptz) owner to cp7_procure_read;
alter function public.erp_cp7_save_procurement_v1(text,jsonb,uuid,text) owner to cp7_procure_write;
revoke create on schema public,cp7_procurement from cp7_procure_read,cp7_procure_write;
revoke all on all functions in schema cp7_procurement from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_procurement.reverse_receipt_locked(uuid,bigint,text) to cp7_procure_write;
-- Supabase's postgres owner is not assumed to be a superuser. The private
-- locked adapter needs this one helper explicitly, without any public grant.
grant execute on function cp7_procurement.access_now() to postgres;
grant execute on function cp7_procurement.validate_uom_lines(jsonb) to cp7_procure_write;
grant execute on function cp7_procurement.access_now(),cp7_procurement.fields(jsonb,text[],text[]),cp7_procurement.decimal(jsonb,boolean) to cp7_procure_write;
revoke all on function public.erp_cp7_get_procurement_v1(jsonb),public.erp_cp7_get_procurement_options_v1(text,text,integer,integer),public.erp_cp7_save_procurement_v1(text,jsonb,uuid,text)
 from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_procurement_v1(jsonb),public.erp_cp7_get_procurement_options_v1(text,text,integer,integer),public.erp_cp7_save_procurement_v1(text,jsonb,uuid,text) to authenticated;
revoke all on function public.erp_cp7_get_procurement_uom_v1(uuid,timestamptz) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_procurement_uom_v1(uuid,timestamptz) to authenticated;

create function cp7_material.balances(p_q text,p_location uuid,p_material uuid,p_zero boolean)
returns table(material_id uuid,material_sku text,material_name text,unit_code text,material_active boolean,
 roll_id uuid,roll_number text,location_id uuid,location_name text,location_active boolean,location_type text,
 zone_kind text,qty numeric,current_ma numeric,last_movement_at timestamptz,material_type text,roll_valid boolean)
language sql stable security invoker set search_path='' as $$
 with physical as (
  select sm.material_id,sm.roll_id,sm.location_id,sum(sm.qty_signed) qty,max(sm.physical_at) last_at
  from erp.material_stock_movements sm join erp.materials m on m.id=sm.material_id
  where (p_location is null or sm.location_id=p_location) and (p_material is null or sm.material_id=p_material)
   and sm.physical_at<=statement_timestamp()
  group by sm.material_id,sm.roll_id,sm.location_id
 )
 select m.id,m.material_sku::text,m.material_name::text,m.unit_code::text,m.is_active,
  x.roll_id,r.roll_number::text,l.id,l.location_name::text,l.is_active,l.location_type::text,z.zone_kind,x.qty,m.moving_average_cost,x.last_at,m.material_type::text,
  ((m.material_type='FABRIC' and r.id is not null and r.material_id=m.id) or (m.material_type<>'FABRIC' and x.roll_id is null))
 from physical x join erp.materials m on m.id=x.material_id join erp.locations l on l.id=x.location_id
 left join erp.material_rolls r on r.id=x.roll_id left join erp.bc_accessory_zones_v1 z on z.location_id=l.id
 where (p_zero or x.qty<>0) and (p_q='' or strpos(lower(m.material_sku||' '||m.material_name||' '||coalesce(r.roll_number,'')||' '||l.location_name),lower(p_q))>0)
$$;

create function cp7_material.workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;rows jsonb;totals jsonb;total bigint;q text;loc uuid;mat uuid;zero boolean;n integer;off integer;
begin
 a:=cp7_material.access_now();
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in ('q','location_id','material_id','show_zero','limit','offset')) then raise exception 'CP7_MATERIAL_QUERY';end if;
 if exists(select 1 from jsonb_each(p_query) e where e.key in ('q','location_id','material_id') and jsonb_typeof(e.value) not in ('string','null'))
  or(p_query ? 'show_zero' and jsonb_typeof(p_query->'show_zero')<>'boolean')
  or(p_query ? 'limit' and (jsonb_typeof(p_query->'limit')<>'number' or (p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query ? 'offset' and (jsonb_typeof(p_query->'offset')<>'number' or (p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_MATERIAL_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));loc:=nullif(p_query->>'location_id','')::uuid;mat:=nullif(p_query->>'material_id','')::uuid;
 zero:=coalesce((p_query->>'show_zero')::boolean,false);n:=coalesce((p_query->>'limit')::integer,50);off:=coalesce((p_query->>'offset')::integer,0);
 if length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000 then raise exception 'CP7_MATERIAL_QUERY';end if;
 select count(*) into total from cp7_material.balances(q,loc,mat,zero);
 select coalesce(jsonb_agg(jsonb_build_object('material_id',x.material_id,'material_sku',x.material_sku,'material_name',x.material_name,'material_type',x.material_type,'unit_code',x.unit_code,
  'roll_id',x.roll_id,'roll_number',x.roll_number,'location_id',x.location_id,'location_name',x.location_name,
  'qty',x.qty::text,'last_movement_at',x.last_movement_at,'quality',case when x.qty<0 or not x.roll_valid then 'CONFLICT' else 'KNOWN' end,
  'availability',case when x.qty<0 or not x.roll_valid then 'REVIEW_REQUIRED' when not x.material_active then 'MATERIAL_INACTIVE'
   when not x.location_active then 'LOCATION_INACTIVE' when x.zone_kind is not null then 'SPECIAL_ZONE' when x.location_type<>'RAW_MATERIAL_WAREHOUSE' then 'LOCATION_REVIEW'
   when x.qty=0 then 'EMPTY' else 'ON_HAND' end)
  ||case when (a->>'can_value')::boolean then jsonb_build_object('valuation',jsonb_build_object(
   'state',case when x.current_ma is null then 'UNKNOWN' else 'KNOWN' end,'unit_cost',x.current_ma::text,'value',round(x.qty*x.current_ma,6)::text,'basis','CURRENT_MATERIAL_MOVING_AVERAGE')) else '{}'::jsonb end
  order by x.material_sku,x.roll_number nulls first,x.material_id,x.roll_id nulls first,x.location_id),'[]'::jsonb)
 into rows from (select * from cp7_material.balances(q,loc,mat,zero) order by material_sku,roll_number nulls first,material_id,roll_id nulls first,location_id limit n offset off) x;
 select coalesce(jsonb_agg(jsonb_build_object('unit_code',x.unit_code,'qty',x.qty::text,'quality',case when x.conflicts then 'CONFLICT' else 'KNOWN' end) order by x.unit_code),'[]'::jsonb)
 into totals from (select unit_code,sum(qty) qty,bool_or(qty<0 or not roll_valid) conflicts from cp7_material.balances(q,loc,mat,zero) group by unit_code) x;
 return jsonb_build_object('contract_version','cp7.material-workspace.v1','kind','LIVE_MATERIAL_LEDGER','read_at',statement_timestamp(),
  'capabilities',jsonb_build_object('transfer',a->'can_adjust','reverse_transfer',a->'can_reverse'),'quantity_basis','POSTED_PHYSICAL_LEDGER_CURRENT_KNOWLEDGE','financial_captured',a->'can_value','totals_by_unit',totals,
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;

create function cp7_material.ledger(p_material uuid,p_roll uuid,p_location uuid,p_offset integer,p_limit integer) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;rows jsonb;total bigint;
begin
 a:=cp7_material.access_now();
 if p_material is null or p_location is null or p_offset is null or p_offset not between 0 and 1000000
  or p_limit is null or p_limit not between 1 and 100 then raise exception 'CP7_MATERIAL_LEDGER_SCOPE';end if;
 if not exists(select 1 from erp.materials m where m.id=p_material and ((m.material_type='FABRIC' and exists(select 1 from erp.material_rolls r where r.id=p_roll and r.material_id=m.id)) or (m.material_type<>'FABRIC' and p_roll is null)))
  or not exists(select 1 from erp.locations where id=p_location) then raise exception 'CP7_MATERIAL_LEDGER_SCOPE';end if;
 select count(*) into total from erp.material_stock_movements where material_id=p_material and roll_id is not distinct from p_roll and location_id=p_location and physical_at<=statement_timestamp();
 with prefix as (
  select sm.*,sum(sm.qty_signed) over(order by sm.physical_at,sm.system_created_at,sm.id rows unbounded preceding) running_qty
  from erp.material_stock_movements sm where sm.material_id=p_material and sm.roll_id is not distinct from p_roll and sm.location_id=p_location and sm.physical_at<=statement_timestamp()
 ), paged as (select * from prefix order by physical_at desc,system_created_at desc,id desc limit p_limit offset p_offset)
 select coalesce(jsonb_agg(jsonb_build_object('movement_id',x.id,'physical_at',x.physical_at,'recorded_at',x.system_created_at,
  'movement_type',x.movement_type,'qty_signed',x.qty_signed::text,'running_qty',x.running_qty::text,
  'source_type',x.source_type,'source_id',x.source_id,'reversal_of_id',x.reversal_of_id,'note',x.note)
  ||case when (a->>'can_value')::boolean then jsonb_build_object('valuation',jsonb_build_object('state',case when x.unit_cost_snapshot is null then 'UNKNOWN' else 'KNOWN' end,'unit_cost',x.unit_cost_snapshot::text,
   'movement_value',round(x.qty_signed*x.unit_cost_snapshot,6)::text,'basis','CURRENT_RESTATED_MOVEMENT_COST')) else '{}'::jsonb end
  order by x.physical_at desc,x.system_created_at desc,x.id desc),'[]'::jsonb) into rows from paged x;
 return jsonb_build_object('contract_version','cp7.material-ledger.v1','material_id',p_material,'roll_id',p_roll,'location_id',p_location,
  'read_at',statement_timestamp(),'financial_captured',a->'can_value','history_basis','CURRENT_RESTATED_NOT_AS_KNOWN',
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',p_offset,'limit',p_limit,'next_offset',case when p_offset+jsonb_array_length(rows)<total then p_offset+jsonb_array_length(rows) else null end));
end $$;

create function public.erp_cp7_get_materials_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_material.workspace(p_query)$$;
create function public.erp_cp7_get_material_ledger_v1(p_material uuid,p_roll uuid,p_location uuid,p_offset integer,p_limit integer) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_material.ledger(p_material,p_roll,p_location,p_offset,p_limit)$$;

create function cp7_material.transfer_header(h erp.material_transfers) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',h.id,'number',h.transfer_number,'from_location_id',h.from_location_id,'to_location_id',h.to_location_id,
  'from_location_name',(select location_name from erp.locations where id=h.from_location_id),
  'to_location_name',(select location_name from erp.locations where id=h.to_location_id),
  'physical_at',h.physical_at,'status',h.status,'row_version',h.row_version::text,'notes',h.notes,
  'line_count',(select count(*)::text from erp.material_transfer_items where transfer_id=h.id))
$$;
create function cp7_material.transfers(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;q text;s text;n integer;off integer;chosen uuid;total bigint;rows jsonb;detail jsonb:=null;h erp.material_transfers;items jsonb;
begin
 a:=cp7_material.access_now();
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','status','limit','offset','transfer_id'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','status','transfer_id') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query ? 'limit' and (jsonb_typeof(p_query->'limit')<>'number' or (p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query ? 'offset' and (jsonb_typeof(p_query->'offset')<>'number' or (p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_MATERIAL_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));s:=coalesce(p_query->>'status','ALL');n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);chosen:=nullif(p_query->>'transfer_id','')::uuid;
 if length(q)>120 or s not in('ALL','DRAFT','POSTED','REVERSED') or n not between 1 and 100 or off not between 0 and 1000000 then raise exception 'CP7_MATERIAL_QUERY';end if;
 select count(*) into total from erp.material_transfers t where (s='ALL' or t.status::text=s) and (q='' or strpos(lower(t.transfer_number),lower(q))>0);
 select coalesce(jsonb_agg(cp7_material.transfer_header(x) order by x.physical_at desc,x.id),'[]'::jsonb)
 into rows from (select t.* from erp.material_transfers t where (s='ALL' or t.status::text=s) and (q='' or strpos(lower(t.transfer_number),lower(q))>0)
  order by t.physical_at desc,t.id limit n offset off) x;
 if chosen is not null then
  select * into h from erp.material_transfers where id=chosen;
  if not found then raise exception 'CP7_MATERIAL_TRANSFER_NOT_FOUND';end if;
  if (select count(*) from erp.material_transfer_items where transfer_id=chosen)>100 then raise exception 'CP7_MATERIAL_DOCUMENT_TOO_LARGE';end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'material_id',i.material_id,'material_sku',m.material_sku,'material_name',m.material_name,
   'unit_code',m.unit_code,'roll_id',i.roll_id,'roll_number',r.roll_number,'qty',i.qty::text,'notes',i.notes) order by i.id),'[]'::jsonb)
  into items from erp.material_transfer_items i join erp.materials m on m.id=i.material_id left join erp.material_rolls r on r.id=i.roll_id where i.transfer_id=chosen;
  detail:=cp7_material.transfer_header(h)||jsonb_build_object('items',items);
 end if;
 return jsonb_build_object('contract_version','cp7.material-transfers.v1','read_at',statement_timestamp(),
  'capabilities',jsonb_build_object('transfer',a->'can_adjust','reverse_transfer',a->'can_reverse'),
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end),'detail',detail);
end $$;
create function public.erp_cp7_get_material_transfers_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_material.transfers(p_query)$$;

create function cp7_material.locations(p_q text,p_offset integer,p_limit integer) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare total bigint;rows jsonb;
begin
 perform cp7_material.access_now();
 if p_q is null or length(p_q)>120 or p_offset is null or p_offset not between 0 and 1000000 or p_limit is null or p_limit not between 1 and 100 then raise exception 'CP7_MATERIAL_QUERY';end if;
 select count(*) into total from erp.locations l where l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE'
  and not exists(select 1 from erp.bc_accessory_zones_v1 z where z.location_id=l.id) and (p_q='' or strpos(lower(l.location_code||' '||l.location_name),lower(p_q))>0);
 select coalesce(jsonb_agg(jsonb_build_object('id',x.id,'code',x.location_code,'name',x.location_name) order by x.location_name,x.id),'[]'::jsonb)
 into rows from (select l.* from erp.locations l where l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE'
  and not exists(select 1 from erp.bc_accessory_zones_v1 z where z.location_id=l.id) and (p_q='' or strpos(lower(l.location_code||' '||l.location_name),lower(p_q))>0)
  order by l.location_name,l.id limit p_limit offset p_offset) x;
 return jsonb_build_object('contract_version','cp7.material-locations.v1','rows',rows,'total',total::text,'offset',p_offset,'limit',p_limit,
  'next_offset',case when p_offset+jsonb_array_length(rows)<total then p_offset+jsonb_array_length(rows) else null end);
end $$;
create function public.erp_cp7_get_material_locations_v1(p_q text,p_offset integer,p_limit integer) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_material.locations(p_q,p_offset,p_limit)$$;

-- Physical-count intent is a private companion to the accepted adjustment.
-- Only native SAVE/POST/REVERSE writers change ERP stock or accounting.
create table cp7_material.count_documents(
 adjustment_id uuid primary key,input jsonb not null,source_signature jsonb not null,captured_at timestamptz not null default statement_timestamp()
);
alter table cp7_material.count_documents owner to cp7_material_write;
alter table cp7_material.count_documents enable row level security;
revoke all on cp7_material.count_documents from public,anon,authenticated,service_role,cp7_capture;
grant select on cp7_material.count_documents to cp7_material_read;
grant select on erp.material_adjustments,erp.material_adjustment_items to cp7_material_read;
grant execute on function erp.save_material_adjustment_draft_v2(jsonb,uuid,bigint),
 erp.post_material_adjustment_v2(uuid,uuid,bigint,text),erp.reverse_material_adjustment_v2(uuid,text,uuid,bigint) to cp7_material_write;

create function cp7_material.count_lines(p_location uuid,p_at timestamptz,p_lines jsonb,p_check boolean,p_exclude uuid default null) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare a jsonb;line jsonb;m erp.materials;roll uuid;quantity numeric;counted numeric;delta numeric;basis text;rows jsonb:='[]';seen text[]:='{}';key text;
begin
 a:=cp7_material.access_now();
 if p_location is null or p_at is null or p_at>statement_timestamp() then raise exception 'CP7_COUNT_TIME_LOCATION';end if;
 if not exists(select 1 from erp.locations where id=p_location and is_active and location_type='RAW_MATERIAL_WAREHOUSE')
  or exists(select 1 from erp.bc_accessory_zones_v1 where location_id=p_location) then raise exception 'CP7_COUNT_ORDINARY_WAREHOUSE_REQUIRED';end if;
 if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100 then raise exception 'CP7_COUNT_LINES';end if;
 for line in select value from jsonb_array_elements(p_lines) loop
  if jsonb_typeof(line) is distinct from 'object' or not line ?& array['material_id','roll_id','physical_qty']
   or exists(select 1 from jsonb_each(line) e where e.key not in('material_id','roll_id','physical_qty','basis_token','input_unit_cost','notes') or jsonb_typeof(e.value) not in('string','null'))
   or line->>'physical_qty' is null or line->>'physical_qty'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$' then raise exception 'CP7_COUNT_EXACT_PHYSICAL_QTY';end if;
  select * into m from erp.materials where id=(line->>'material_id')::uuid and is_active;
  roll:=(line->>'roll_id')::uuid;
  if not found or (m.material_type='FABRIC' and (roll is null or not exists(select 1 from erp.material_rolls where id=roll and material_id=m.id)))
   or (m.material_type<>'FABRIC' and roll is not null) then raise exception 'CP7_COUNT_MATERIAL_LINEAGE';end if;
  key:=m.id::text||'/'||coalesce(roll::text,'NO_ROLL');
  if key=any(seen) then raise exception 'CP7_COUNT_DUPLICATE_LINE';end if;seen:=array_append(seen,key);
  select coalesce(sum(s.qty_signed),0),md5(coalesce(string_agg(jsonb_build_array(s.id,extract(epoch from s.physical_at),s.qty_signed)::text,',' order by s.id),''))
   into quantity,basis from erp.material_stock_movements s
   where s.material_id=m.id and s.roll_id is not distinct from roll and s.location_id=p_location and s.physical_at<=p_at
    and not(p_exclude is not null and s.source_type='MATERIAL_ADJUSTMENT_ITEM' and exists(select 1 from erp.material_adjustment_items i where i.adjustment_id=p_exclude and i.id=s.source_id));
  if quantity<0 then raise exception 'CP7_COUNT_SOURCE_CONFLICT';end if;
  if p_check and line->>'basis_token' is distinct from basis then raise exception 'CP7_COUNT_STOCK_CHANGED_REVIEW_AGAIN';end if;
  counted:=(line->>'physical_qty')::numeric;delta:=counted-quantity;
  if line->>'input_unit_cost' is not null then
   if a->'can_value' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_COUNT_COST_DENIED';end if;
   if line->>'input_unit_cost'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$' or delta<=0 then raise exception 'CP7_COUNT_POSITIVE_COST_ONLY';end if;
  end if;
  if p_check and delta>0 and line->>'input_unit_cost' is null then raise exception 'CP7_COUNT_POSITIVE_COST_REQUIRED';end if;
  rows:=rows||jsonb_build_array(jsonb_build_object('material_id',m.id,'material_sku',m.material_sku,'material_name',m.material_name,'unit_code',m.unit_code,
   'roll_id',roll,'roll_number',(select roll_number from erp.material_rolls where id=roll),'system_qty',quantity::text,'physical_qty',counted::text,'qty_signed',delta::text,'basis_token',basis));
 end loop;
 return rows;
end $$;

create function cp7_material.count_preview(p_scope jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare rows jsonb;a jsonb;
begin
 a:=cp7_material.access_now();
 if jsonb_typeof(p_scope) is distinct from 'object' or not p_scope ?& array['location_id','physical_at','items']
  or exists(select 1 from jsonb_object_keys(p_scope) k where k not in('location_id','physical_at','items')) then raise exception 'CP7_COUNT_SCOPE';end if;
 rows:=cp7_material.count_lines((p_scope->>'location_id')::uuid,(p_scope->>'physical_at')::timestamptz,p_scope->'items',false);
 return jsonb_build_object('contract_version','cp7.material-count-preview.v1','read_at',statement_timestamp(),
  'location_id',p_scope->'location_id','physical_at',(p_scope->>'physical_at')::timestamptz,'basis','POSTED_PHYSICAL_AT_COUNT_CURRENT_KNOWLEDGE','items',rows);
end $$;
create function public.erp_cp7_preview_material_count_v1(p_scope jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_material.count_preview(p_scope)$$;

create function cp7_material.count_signature(p_id uuid) returns jsonb
language sql stable security definer set search_path='' as $$
 select jsonb_build_object('number',h.adjustment_number,'location',h.location_id,'at_epoch',extract(epoch from h.physical_at),'reason',h.reason_code,'notes',h.notes,
  'items',(select jsonb_agg(jsonb_build_array(i.material_id,i.roll_id,i.qty_signed,i.input_unit_cost,i.notes) order by i.material_id,i.roll_id nulls first,i.id)
   from erp.material_adjustment_items i where i.adjustment_id=h.id)) from erp.material_adjustments h where h.id=p_id
$$;

create function cp7_material.count_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;r jsonb;old cp7_material.requests;proof cp7_material.count_documents;rows jsonb;items jsonb;line jsonb;x jsonb;payload jsonb;ident uuid;expected bigint;signature jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_material.access_now();
 if a->'can_adjust' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_MATERIAL_ADJUST_DENIED';end if;
 if p_action is null or p_action not in('SAVE','POST','DELETE','REVERSE') or p_request is null then raise exception 'CP7_COUNT_ACTION';end if;
 if p_action='REVERSE' and a->'can_reverse' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_MATERIAL_REVERSE_DENIED';end if;
 if p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_MATERIAL_VERSION';end if;expected:=p_expected::bigint;
 if jsonb_typeof(p_payload) is distinct from 'object' then raise exception 'CP7_COUNT_FIELDS';end if;
 insert into cp7_material.requests(actor,request_id,action,payload,expected_version) values(auth.uid(),p_request,p_action||'_COUNT',p_payload,p_expected) on conflict do nothing;
 select * into old from cp7_material.requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>(p_action||'_COUNT') or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_COUNT_REQUEST_CHANGED';end if;
 if cp7_material.access_now()<>a then raise exception using errcode='42501',message='CP7_MATERIAL_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 if p_action='SAVE' then
  if not p_payload ?& array['adjustment_number','location_id','physical_at','reason_code','change_reason','items']
   or exists(select 1 from jsonb_each(p_payload) e where e.key not in('id','adjustment_number','location_id','physical_at','reason_code','change_reason','items','notes') or (e.key<>'items' and jsonb_typeof(e.value) not in('string','null')))
   or p_payload->>'reason_code' not in('LOSS','DAMAGE','COUNT_CORRECTION') then raise exception 'CP7_COUNT_FIELDS';end if;
  ident:=(p_payload->>'id')::uuid;
  if ident is not null then
   perform 1 from cp7_material.count_documents where adjustment_id=ident for update;
   if not found then raise exception 'CP7_COUNT_SOURCE_WORKFLOW_REQUIRED';end if;
  end if;
  rows:=cp7_material.count_lines((p_payload->>'location_id')::uuid,(p_payload->>'physical_at')::timestamptz,p_payload->'items',true);
  items:='[]';
  for x in select value from jsonb_array_elements(rows) loop
   if (x->>'qty_signed')::numeric=0 then continue;end if;
   select value into line from jsonb_array_elements(p_payload->'items') where (value->>'material_id')::uuid=(x->>'material_id')::uuid and (value->>'roll_id')::uuid is not distinct from (x->>'roll_id')::uuid;
   items:=items||jsonb_build_array(jsonb_build_object('material_id',x->'material_id','roll_id',x->'roll_id','qty_signed',x->'qty_signed','input_unit_cost',line->'input_unit_cost','notes',line->'notes'));
  end loop;
  if jsonb_array_length(items)=0 then raise exception 'CP7_COUNT_NO_DIFFERENCE';end if;
  payload:=p_payload||jsonb_build_object('items',items);
  insert into cp7_material.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),'SAVE_COUNT','warehouse.stock.adjust');
  r:=erp.save_material_adjustment_draft_v2(payload,p_request,expected);ident:=(r->>'material_adjustment_id')::uuid;
  signature:=cp7_material.count_signature(ident);
  insert into cp7_material.count_documents(adjustment_id,input,source_signature) values(ident,p_payload,signature)
   on conflict(adjustment_id) do update set input=excluded.input,source_signature=excluded.source_signature,captured_at=statement_timestamp();
 else
  if expected is null or not p_payload ?& array['adjustment_id','change_reason'] or exists(select 1 from jsonb_each(p_payload) e where e.key not in('adjustment_id','change_reason') or jsonb_typeof(e.value)<>'string') then raise exception 'CP7_COUNT_FIELDS';end if;
  ident:=(p_payload->>'adjustment_id')::uuid;
  select * into proof from cp7_material.count_documents where adjustment_id=ident for update;
  if not found then raise exception 'CP7_COUNT_SOURCE_WORKFLOW_REQUIRED';end if;
  insert into cp7_material.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),p_action||'_COUNT','warehouse.stock.adjust');
  if p_action='POST' then
   if cp7_material.count_signature(ident) is distinct from proof.source_signature then raise exception 'CP7_COUNT_DRAFT_CHANGED_REVIEW_AGAIN';end if;
   perform cp7_material.count_lines((proof.input->>'location_id')::uuid,(proof.input->>'physical_at')::timestamptz,proof.input->'items',true);
   r:=erp.post_material_adjustment_v2(ident,p_request,expected,p_payload->>'change_reason');
   -- Native movement triggers hold each material row through commit. This new
   -- statement rechecks the latest committed prefix after all real row waits.
   perform cp7_material.count_lines((proof.input->>'location_id')::uuid,(proof.input->>'physical_at')::timestamptz,proof.input->'items',true,ident);
   if cp7_material.count_signature(ident) is distinct from proof.source_signature then raise exception 'CP7_COUNT_DRAFT_CHANGED_REVIEW_AGAIN';end if;
  elsif p_action='DELETE' then
   r:=erp.save_material_adjustment_draft_v2(jsonb_build_object('id',ident,'action','DELETE','change_reason',p_payload->'change_reason'),p_request,expected);
   delete from cp7_material.count_documents where adjustment_id=ident;
  else r:=erp.reverse_material_adjustment_v2(ident,p_payload->>'change_reason',p_request,expected);
  end if;
 end if;
 if cp7_material.access_now()<>a then raise exception using errcode='42501',message='CP7_MATERIAL_ACCESS_CHANGED';end if;
 delete from cp7_material.execution_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
 r:=jsonb_build_object('contract_version','cp7.material-count-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'adjustment_id',ident,'status',r->'status','row_version',r->>'row_version');
 update cp7_material.requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;
create function public.erp_cp7_save_material_count_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_material.count_command(p_action,p_payload,p_request,p_expected)$$;

create function cp7_material.count_header(h erp.material_adjustments) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',h.id,'number',h.adjustment_number,'location_id',h.location_id,'location_name',(select location_name from erp.locations where id=h.location_id),
  'physical_at',h.physical_at,'reason_code',h.reason_code,'status',h.status,'row_version',h.row_version::text,'notes',h.notes,
  'managed_count',exists(select 1 from cp7_material.count_documents where adjustment_id=h.id),
  'line_count',(select count(*)::text from erp.material_adjustment_items where adjustment_id=h.id))
$$;
create function cp7_material.count_workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;q text;n integer;off integer;chosen uuid;total bigint;rows jsonb;detail jsonb:=null;h erp.material_adjustments;items jsonb;proof jsonb;editable jsonb:=null;
begin
 a:=cp7_material.access_now();
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','limit','offset','adjustment_id'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','adjustment_id') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query ? 'limit' and (jsonb_typeof(p_query->'limit')<>'number' or (p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query ? 'offset' and (jsonb_typeof(p_query->'offset')<>'number' or (p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_COUNT_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);chosen:=(p_query->>'adjustment_id')::uuid;
 if length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000 then raise exception 'CP7_COUNT_QUERY';end if;
 select count(*) into total from erp.material_adjustments doc where q='' or strpos(lower(doc.adjustment_number),lower(q))>0;
 select coalesce(jsonb_agg(cp7_material.count_header(x) order by x.physical_at desc,x.id),'[]') into rows
 from (select * from erp.material_adjustments doc where q='' or strpos(lower(doc.adjustment_number),lower(q))>0 order by physical_at desc,id limit n offset off) x;
 if chosen is not null then
  select * into h from erp.material_adjustments where id=chosen;
  if not found then raise exception 'CP7_COUNT_NOT_FOUND';end if;
  if (select count(*) from erp.material_adjustment_items where adjustment_id=chosen)>100 then raise exception 'CP7_COUNT_DOCUMENT_TOO_LARGE';end if;
  select input into proof from cp7_material.count_documents where adjustment_id=chosen;
  select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'material_id',i.material_id,'material_sku',m.material_sku,'material_name',m.material_name,'unit_code',m.unit_code,
   'roll_id',i.roll_id,'roll_number',r.roll_number,'qty_signed',i.qty_signed::text,'notes',i.notes,
   'physical_qty',(select e->>'physical_qty' from jsonb_array_elements(proof->'items') e where (e->>'material_id')::uuid=i.material_id and (e->>'roll_id')::uuid is not distinct from i.roll_id))
   ||case when a->'can_value'='true'::jsonb then jsonb_build_object('valuation',jsonb_build_object('input_unit_cost',i.input_unit_cost::text,
     'restated_value',(select round(sum(s.qty_signed*s.unit_cost_snapshot),6)::text from erp.material_stock_movements s where s.source_type='MATERIAL_ADJUSTMENT_ITEM' and s.source_id=i.id and s.reversal_of_id is null),
     'basis','CURRENT_RESTATED_DOCUMENT_NOT_STOCK')) else '{}'::jsonb end order by i.id),'[]')
   into items from erp.material_adjustment_items i join erp.materials m on m.id=i.material_id left join erp.material_rolls r on r.id=i.roll_id where i.adjustment_id=chosen;
  -- Edit the complete original input, including zero differences omitted by the
  -- native adjustment. A user without value access cannot edit priced inputs.
  if h.status='DRAFT' and jsonb_array_length(proof->'items') between 1 and 100
   and (a->'can_value'='true'::jsonb or not exists(select 1 from jsonb_array_elements(proof->'items') e where e->>'input_unit_cost' is not null))
   and cp7_material.count_signature(chosen)=(select source_signature from cp7_material.count_documents where adjustment_id=chosen) then
   if jsonb_array_length(proof->'items')=1 and jsonb_array_length(items)=1 then
    editable:=jsonb_build_object('physical_qty',proof->'items'->0->>'physical_qty')
     ||case when a->'can_value'='true'::jsonb then jsonb_build_object('input_unit_cost',proof->'items'->0->>'input_unit_cost') else '{}'::jsonb end;
   else
    select jsonb_build_object('items',jsonb_agg(jsonb_build_object(
      'material_id',m.id,'material_sku',m.material_sku,'material_name',m.material_name,'unit_code',m.unit_code,
      'roll_id',r.id,'roll_number',r.roll_number,'physical_qty',e.value->>'physical_qty','notes',e.value->>'notes')
      ||case when a->'can_value'='true'::jsonb then jsonb_build_object('input_unit_cost',e.value->>'input_unit_cost') else '{}'::jsonb end
      order by e.ordinality)) into editable
    from jsonb_array_elements(proof->'items') with ordinality e
    join erp.materials m on m.id=(e.value->>'material_id')::uuid
    left join erp.material_rolls r on r.id=(e.value->>'roll_id')::uuid;
    if jsonb_array_length(editable->'items') is distinct from jsonb_array_length(proof->'items') then editable:=null;end if;
   end if;
  end if;
  detail:=cp7_material.count_header(h)||jsonb_build_object('items',items,'edit',editable);
 end if;
 return jsonb_build_object('contract_version','cp7.material-counts.v1','read_at',statement_timestamp(),'financial_captured',a->'can_value',
  'capabilities',jsonb_build_object('adjust',a->'can_adjust','reverse',a->'can_reverse'),
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end),'detail',detail);
end $$;
create function public.erp_cp7_get_material_counts_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_material.count_workspace(p_query)$$;

-- Registered identities for a physical count, including no prior movement at
-- this warehouse. This projection is not stock and supplies no invented cost.
create function cp7_material.count_options(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;loc uuid;loc_name text;q text;off integer;n integer;total bigint;rows jsonb;
begin
 a:=cp7_material.access_now();
 if a->'can_adjust' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_MATERIAL_ADJUST_DENIED';end if;
 if jsonb_typeof(p_query) is distinct from 'object' or not p_query ? 'location_id'
  or exists(select 1 from jsonb_object_keys(p_query) k where k not in('location_id','q','offset','limit'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','location_id') and jsonb_typeof(e.value)<>'string')
  or exists(select 1 from jsonb_each(p_query) e where e.key in('offset','limit') and(jsonb_typeof(e.value)<>'number' or e.value::text!~'^[0-9]{1,7}$')) then raise exception 'CP7_COUNT_OPTIONS_QUERY';end if;
 loc:=(p_query->>'location_id')::uuid;q:=btrim(coalesce(p_query->>'q',''));off:=coalesce((p_query->>'offset')::integer,0);n:=coalesce((p_query->>'limit')::integer,25);
 if loc is null or length(q)>120 or off not between 0 and 1000000 or n not between 1 and 100 then raise exception 'CP7_COUNT_OPTIONS_QUERY';end if;
 select l.location_name into loc_name from erp.locations l where l.id=loc and l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE'
  and not exists(select 1 from erp.bc_accessory_zones_v1 z where z.location_id=l.id);
 if not found then raise exception 'CP7_COUNT_ORDINARY_WAREHOUSE_REQUIRED';end if;
 with choices as materialized(
  select m.id material_id,m.material_sku,m.material_name,m.material_type,m.unit_code,r.id roll_id,r.roll_number
  from erp.materials m left join erp.material_rolls r on m.material_type='FABRIC' and r.material_id=m.id
  where m.is_active and(m.material_type<>'FABRIC' or r.id is not null)
   and(q='' or strpos(lower(m.material_sku||' '||m.material_name||' '||coalesce(r.roll_number,'')),lower(q))>0)
 ) select(select count(*) from choices),
  (select coalesce(jsonb_agg(to_jsonb(c) order by c.material_sku,c.material_id,c.roll_number nulls first,c.roll_id nulls first),'[]')
   from(select * from choices order by material_sku,material_id,roll_number nulls first,roll_id nulls first limit n offset off)c)
 into total,rows;
 return jsonb_build_object('contract_version','cp7.material-count-options.v1','selection_basis','REGISTERED_IDENTITY_NOT_STOCK','read_at',statement_timestamp(),
  'location_id',loc,'location_name',loc_name,'query',q,'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;
create function public.erp_cp7_get_material_count_options_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_material.count_options(p_query)$$;

-- Existing stock-adjust authority is conservative for transfers. Reversal also
-- retains the accepted OWNER/ADMIN guard. No new default permission is created.
create function cp7_material.command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;z jsonb;r jsonb;expected bigint;old cp7_material.requests;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_material.access_now();
 if a->'can_adjust'<>'true'::jsonb then raise exception using errcode='42501',message='CP7_MATERIAL_ADJUST_DENIED';end if;
 if p_request is null or p_action is null or p_action not in('SAVE_TRANSFER','POST_TRANSFER','REVERSE_TRANSFER') then raise exception 'CP7_MATERIAL_ACTION';end if;
 if p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_MATERIAL_VERSION';end if;
 expected:=p_expected::bigint;
 if jsonb_typeof(p_payload) is distinct from 'object' then raise exception 'CP7_MATERIAL_FIELDS';end if;
 if p_action='REVERSE_TRANSFER' and a->'can_reverse' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_MATERIAL_REVERSE_DENIED';end if;
 insert into cp7_material.requests(actor,request_id,action,payload,expected_version) values(auth.uid(),p_request,p_action,p_payload,p_expected) on conflict do nothing;
 select * into old from cp7_material.requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_MATERIAL_REQUEST_CHANGED: different payload or version';end if;
 if cp7_material.access_now()<>a then raise exception using errcode='42501',message='CP7_MATERIAL_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 if p_action='SAVE_TRANSFER' then
  if not p_payload ?& array['transfer_number','from_location_id','to_location_id','physical_at','change_reason','items']
   or exists(select 1 from jsonb_each(p_payload) e where e.key not in('id','transfer_number','from_location_id','to_location_id','physical_at','change_reason','items','notes')
    or(e.key<>'items' and jsonb_typeof(e.value) not in('string','null'))) then raise exception 'CP7_MATERIAL_FIELDS';end if;
  if nullif(p_payload->>'from_location_id','') is null or nullif(p_payload->>'to_location_id','') is null
   or p_payload->>'from_location_id'=p_payload->>'to_location_id' then raise exception 'CP7_MATERIAL_DIFFERENT_LOCATIONS_REQUIRED';end if;
  perform cp7_material.validate_lines(p_payload->'items');
  perform cp7_material.validate_transfer_scope((p_payload->>'from_location_id')::uuid,(p_payload->>'to_location_id')::uuid);
  insert into cp7_material.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),p_action,'warehouse.stock.adjust');
  r:=erp.save_material_transfer_draft_v2(p_payload,p_request,expected);
 else
  if expected is null then raise exception 'CP7_MATERIAL_VERSION';end if;
  if not p_payload ?& array['transfer_id','change_reason'] or exists(select 1 from jsonb_each(p_payload) e
   where e.key not in('transfer_id','change_reason') or jsonb_typeof(e.value)<>'string') then raise exception 'CP7_MATERIAL_FIELDS';end if;
  insert into cp7_material.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),p_action,'warehouse.stock.adjust');
  if p_action='POST_TRANSFER' then
   perform cp7_material.validate_transfer_scope(null,null,(p_payload->>'transfer_id')::uuid);
   r:=erp.post_material_transfer_v2((p_payload->>'transfer_id')::uuid,p_request,expected,p_payload->>'change_reason');
   perform cp7_material.validate_transfer_scope(null,null,(p_payload->>'transfer_id')::uuid);
  else
   if a->'can_reverse' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_MATERIAL_REVERSE_DENIED';end if;
   r:=erp.reverse_material_transfer_v2((p_payload->>'transfer_id')::uuid,p_payload->>'change_reason',p_request,expected);
  end if;
 end if;
 z:=cp7_material.access_now();
 if z<>a then raise exception using errcode='42501',message='CP7_MATERIAL_ACCESS_CHANGED';end if;
 delete from cp7_material.execution_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
 r:=jsonb_build_object('contract_version','cp7.material-outcome.v1','kind','COMMITTED_OUTCOME',
  'action',p_action,'request_id',p_request,'transfer_id',r->'material_transfer_id','status',r->'status','row_version',r->>'row_version');
 update cp7_material.requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;

create function public.erp_cp7_save_materials_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_material.command(p_action,p_payload,p_request,p_expected)$$;

grant create on schema public,cp7_material to cp7_material_read,cp7_material_write;
alter function cp7_material.access_now() owner to cp7_material_read;
alter function cp7_material.validate_lines(jsonb) owner to cp7_material_read;
alter function cp7_material.validate_transfer_scope(uuid,uuid,uuid) owner to cp7_material_read;
alter function cp7_material.balances(text,uuid,uuid,boolean) owner to cp7_material_read;
alter function cp7_material.workspace(jsonb) owner to cp7_material_read;
alter function cp7_material.ledger(uuid,uuid,uuid,integer,integer) owner to cp7_material_read;
alter function cp7_material.transfer_header(erp.material_transfers) owner to cp7_material_read;
alter function cp7_material.transfers(jsonb) owner to cp7_material_read;
alter function cp7_material.locations(text,integer,integer) owner to cp7_material_read;
alter function cp7_material.command(text,jsonb,uuid,text) owner to cp7_material_write;
alter function public.erp_cp7_get_materials_v1(jsonb) owner to cp7_material_read;
alter function public.erp_cp7_get_material_ledger_v1(uuid,uuid,uuid,integer,integer) owner to cp7_material_read;
alter function public.erp_cp7_get_material_transfers_v1(jsonb) owner to cp7_material_read;
alter function public.erp_cp7_get_material_locations_v1(text,integer,integer) owner to cp7_material_read;
alter function public.erp_cp7_save_materials_v1(text,jsonb,uuid,text) owner to cp7_material_write;
alter function cp7_material.count_lines(uuid,timestamptz,jsonb,boolean,uuid) owner to cp7_material_read;
alter function cp7_material.count_preview(jsonb) owner to cp7_material_read;
alter function cp7_material.count_signature(uuid) owner to cp7_material_read;
alter function cp7_material.count_header(erp.material_adjustments) owner to cp7_material_read;
alter function cp7_material.count_workspace(jsonb) owner to cp7_material_read;
alter function cp7_material.count_options(jsonb) owner to cp7_material_read;
alter function cp7_material.count_command(text,jsonb,uuid,text) owner to cp7_material_write;
alter function public.erp_cp7_preview_material_count_v1(jsonb) owner to cp7_material_read;
alter function public.erp_cp7_get_material_counts_v1(jsonb) owner to cp7_material_read;
alter function public.erp_cp7_get_material_count_options_v1(jsonb) owner to cp7_material_read;
alter function public.erp_cp7_save_material_count_v1(text,jsonb,uuid,text) owner to cp7_material_write;
revoke create on schema public,cp7_material from cp7_material_read,cp7_material_write;
revoke all on all functions in schema cp7_material from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_material.access_now(),cp7_material.validate_lines(jsonb) to cp7_material_write;
grant execute on function cp7_material.validate_transfer_scope(uuid,uuid,uuid) to cp7_material_write;
revoke all on function public.erp_cp7_get_materials_v1(jsonb),public.erp_cp7_get_material_ledger_v1(uuid,uuid,uuid,integer,integer),
 public.erp_cp7_get_material_transfers_v1(jsonb),public.erp_cp7_get_material_locations_v1(text,integer,integer),public.erp_cp7_save_materials_v1(text,jsonb,uuid,text)
 from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_materials_v1(jsonb),public.erp_cp7_get_material_ledger_v1(uuid,uuid,uuid,integer,integer),
 public.erp_cp7_get_material_transfers_v1(jsonb),public.erp_cp7_get_material_locations_v1(text,integer,integer),public.erp_cp7_save_materials_v1(text,jsonb,uuid,text) to authenticated;

grant execute on function cp7_material.count_lines(uuid,timestamptz,jsonb,boolean,uuid),cp7_material.count_signature(uuid) to cp7_material_write;
revoke all on function public.erp_cp7_preview_material_count_v1(jsonb),public.erp_cp7_get_material_counts_v1(jsonb),public.erp_cp7_save_material_count_v1(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_preview_material_count_v1(jsonb),public.erp_cp7_get_material_counts_v1(jsonb),public.erp_cp7_save_material_count_v1(text,jsonb,uuid,text) to authenticated;
revoke all on function public.erp_cp7_get_material_count_options_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_material_count_options_v1(jsonb) to authenticated;

-- P09/P13 purchase invoice bridge. Payment/credit allocation stays in its own
-- accepted supplier settlement boundary. These APIs never invent outstanding AP.
create role cp7_invoice_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create role cp7_invoice_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_invoice authorization cp7_invoice_read;
revoke all on schema cp7_invoice from public,anon,authenticated,service_role;
grant usage,create on schema cp7_invoice to cp7_invoice_write;
grant usage on schema erp,auth to cp7_invoice_read,cp7_invoice_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_invoice_read,cp7_invoice_write;
grant select on erp.material_purchase_headers,erp.material_purchase_items,erp.materials,erp.material_supplier_invoices,
 erp.material_supplier_invoice_lines,erp.suppliers to cp7_invoice_read;
grant execute on function erp.material_purchase_invoice_capacity(uuid),erp.material_purchase_posted_invoice_qty(uuid) to cp7_invoice_read;
grant execute on function erp.finalize_material_purchase_invoice_v2(jsonb,uuid,bigint),erp.reverse_material_supplier_invoice_v2(uuid,text,uuid,bigint) to cp7_invoice_write;

create function cp7_invoice.access_now() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;legacy boolean;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_INVOICE_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if (a->>'allowed')::boolean is distinct from true or not erp.has_permission('warehouse.procurement.view') or not erp.has_permission('finance.ap.view') then
  raise exception using errcode='42501',message='CP7_INVOICE_ACCESS_DENIED';end if;
 legacy:=a->'profile'->>'role_code' in('OWNER','ADMIN');
 return jsonb_build_object('actor',auth.uid(),'profile',a->'profile','permissions',a->'permissions',
  'finalize',legacy and erp.has_permission('warehouse.procurement.post'),'reverse',legacy and erp.has_permission('warehouse.procurement.reverse'));
end $$;

create function cp7_invoice.assert_single_receipt(p_invoice uuid,p_purchase uuid) returns void
language plpgsql stable security definer set search_path='' as $$
begin
 perform cp7_invoice.access_now();
 if not exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=p_invoice and i.purchase_id=p_purchase)
  or exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=p_invoice and i.purchase_id<>p_purchase) then
  raise exception 'CP7_INVOICE_COMPLETE_DOCUMENT_REQUIRED';end if;
end $$;

create function cp7_invoice.workspace(p_purchase uuid,p_offset integer,p_limit integer) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;h erp.material_purchase_headers;lines jsonb;docs jsonb;total bigint;
begin
 a:=cp7_invoice.access_now();
 if p_purchase is null or p_offset is null or p_offset not between 0 and 1000000 or p_limit is null or p_limit not between 1 and 25 then raise exception 'CP7_INVOICE_QUERY';end if;
 select * into h from erp.material_purchase_headers where id=p_purchase;
 if not found then raise exception 'CP7_INVOICE_RECEIPT_NOT_FOUND';end if;
 if (select count(*) from erp.material_purchase_items where purchase_id=p_purchase)>100 then raise exception 'CP7_INVOICE_COMPLETE_DOCUMENT_REQUIRED';end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'material_id',i.material_id,'material_name',m.material_name,'unit_code',m.unit_code,
  'receipt_qty',i.qty::text,'estimate_unit_price',i.unit_price::text,'price_state',i.price_state,'invoice_match_state',i.invoice_match_state,
  'capacity',erp.material_purchase_invoice_capacity(i.id)::text,'invoiced_qty',erp.material_purchase_posted_invoice_qty(i.id)::text,
  'remaining_qty',case when i.invoice_match_state='DIRECT_FINAL' then '0' else (erp.material_purchase_invoice_capacity(i.id)-erp.material_purchase_posted_invoice_qty(i.id))::text end)
  order by i.id),'[]'::jsonb) into lines from erp.material_purchase_items i join erp.materials m on m.id=i.material_id where i.purchase_id=p_purchase;
 select count(*) into total from erp.material_supplier_invoices ih where exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=ih.id and i.purchase_id=p_purchase);
 -- Every returned invoice is complete, including lines from other receipts.
 -- Such a legacy multi-receipt document is readable, but the bounded single-
 -- receipt reverse command refuses it instead of undoing unseen allocations.
 if exists(select 1 from (select ih.id from erp.material_supplier_invoices ih where exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=ih.id and i.purchase_id=p_purchase)
  order by ih.received_at desc,ih.id limit p_limit offset p_offset) selected where (select count(*) from erp.material_supplier_invoice_lines where invoice_id=selected.id)>100) then raise exception 'CP7_INVOICE_COMPLETE_DOCUMENT_REQUIRED';end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',ih.id,'number',ih.invoice_number,'invoice_date',ih.invoice_date,'received_at',ih.received_at,'due_date',ih.due_date,
  'status',ih.status,'row_version',ih.row_version::text,'notes',ih.notes,'line_count',(select count(*)::text from erp.material_supplier_invoice_lines where invoice_id=ih.id),
  'document_net_amount',(select sum(net_amount)::text from erp.material_supplier_invoice_lines where invoice_id=ih.id),
  'single_receipt',not exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=ih.id and i.purchase_id<>p_purchase),
  'lines',coalesce((select jsonb_agg(jsonb_build_object('id',l.id,'purchase_item_id',l.purchase_item_id,'purchase_id',i.purchase_id,'purchase_number',ph.purchase_number,
    'material_name',m.material_name,'unit_code',m.unit_code,'qty',l.qty_invoiced::text,'unit_price',l.unit_price::text,'discount',l.discount_amount::text,'net_amount',l.net_amount::text,'notes',l.notes) order by l.id)
    from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id join erp.material_purchase_headers ph on ph.id=i.purchase_id join erp.materials m on m.id=i.material_id where l.invoice_id=ih.id),'[]'::jsonb)) order by ih.received_at desc,ih.id),'[]'::jsonb)
 into docs from (select x.* from erp.material_supplier_invoices x where exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=x.id and i.purchase_id=p_purchase)
  order by x.received_at desc,x.id limit p_limit offset p_offset) ih;
 return jsonb_build_object('contract_version','cp7.purchase-invoices.v1','read_at',statement_timestamp(),'purchase_id',p_purchase,'purchase_number',h.purchase_number,'purchase_status',h.status,
  'purchase_version',h.row_version::text,'supplier_id',h.supplier_id,'capabilities',jsonb_build_object('finalize',a->'finalize','reverse',a->'reverse'),
  'basis','INVOICE_DOCUMENTS_NOT_PAYMENT_OUTSTANDING','receipt_line_count',jsonb_array_length(lines)::text,'receipt_lines',lines,
  'page',jsonb_build_object('rows',docs,'total',total::text,'offset',p_offset,'limit',p_limit,'next_offset',case when p_offset+jsonb_array_length(docs)<total then p_offset+jsonb_array_length(docs) else null end));
end $$;
create function public.erp_cp7_get_purchase_invoices_v1(p_purchase uuid,p_offset integer,p_limit integer) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_invoice.workspace(p_purchase,p_offset,p_limit)$$;

-- Complete supplier invoice documents may span several posted receipts.
-- Native draft/post/inverse writers retain all quantity and money authority.
create table cp7_invoice.requests(
 actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,
 expected_version text,response jsonb,primary key(actor,request_id)
);
alter table cp7_invoice.requests owner to cp7_invoice_write;
alter table cp7_invoice.requests enable row level security;
revoke all on cp7_invoice.requests from public,anon,authenticated,service_role,cp7_capture;
grant execute on function erp.save_material_supplier_invoice_draft_v2(jsonb,uuid,bigint),
 erp.post_material_supplier_invoice_v2(uuid,uuid,bigint,text) to cp7_invoice_write;

create function cp7_invoice.source_lines(p_purchase uuid) returns jsonb
language sql stable security invoker set search_path='' as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'material_id',i.material_id,'material_name',m.material_name,'unit_code',m.unit_code,
  'receipt_qty',i.qty::text,'estimate_unit_price',i.unit_price::text,'price_state',i.price_state,'invoice_match_state',i.invoice_match_state,
  'capacity',erp.material_purchase_invoice_capacity(i.id)::text,'invoiced_qty',erp.material_purchase_posted_invoice_qty(i.id)::text,
  'remaining_qty',case when i.invoice_match_state='DIRECT_FINAL' then '0' else (erp.material_purchase_invoice_capacity(i.id)-erp.material_purchase_posted_invoice_qty(i.id))::text end)
  order by i.id),'[]'::jsonb) from erp.material_purchase_items i join erp.materials m on m.id=i.material_id where i.purchase_id=p_purchase
$$;

create function cp7_invoice.sources(p_purchase uuid,p_q text,p_offset integer,p_limit integer) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare h erp.material_purchase_headers;total bigint;rows jsonb;term text;
begin
 perform cp7_invoice.access_now();term:=btrim(coalesce(p_q,''));
 if p_purchase is null or length(term)>120 or p_offset is null or p_offset not between 0 and 1000000 or p_limit is null or p_limit not between 1 and 25 then raise exception 'CP7_INVOICE_QUERY';end if;
 select * into h from erp.material_purchase_headers where id=p_purchase;
 if not found or h.supplier_id is null then raise exception 'CP7_INVOICE_RECEIPT_NOT_FOUND';end if;
 select count(*) into total from erp.material_purchase_headers ph where ph.supplier_id=h.supplier_id and ph.status='POSTED' and (term='' or strpos(lower(ph.purchase_number),lower(term))>0);
 if exists(select 1 from (select ph.id from erp.material_purchase_headers ph where ph.supplier_id=h.supplier_id and ph.status='POSTED' and (term='' or strpos(lower(ph.purchase_number),lower(term))>0)
  order by ph.physical_at desc,ph.id limit p_limit offset p_offset) chosen where (select count(*) from erp.material_purchase_items where purchase_id=chosen.id)>100) then raise exception 'CP7_INVOICE_COMPLETE_DOCUMENT_REQUIRED';end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',ph.id,'number',ph.purchase_number,'physical_at',ph.physical_at,'row_version',ph.row_version::text,
  'lines',cp7_invoice.source_lines(ph.id),'line_count',(select count(*)::text from erp.material_purchase_items where purchase_id=ph.id)) order by ph.physical_at desc,ph.id),'[]') into rows
 from (select x.* from erp.material_purchase_headers x where x.supplier_id=h.supplier_id and x.status='POSTED' and (term='' or strpos(lower(x.purchase_number),lower(term))>0)
  order by x.physical_at desc,x.id limit p_limit offset p_offset) ph;
 return jsonb_build_object('contract_version','cp7.invoice-sources.v1','read_at',statement_timestamp(),'purchase_id',p_purchase,'supplier_id',h.supplier_id,
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',p_offset,'limit',p_limit,'next_offset',case when p_offset+jsonb_array_length(rows)<total then p_offset+jsonb_array_length(rows) else null end));
end $$;
create function public.erp_cp7_get_invoice_sources_v1(p_purchase uuid,p_q text,p_offset integer,p_limit integer) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_invoice.sources(p_purchase,p_q,p_offset,p_limit)$$;

create function cp7_invoice.validate_sources(p_purchase uuid,p_supplier uuid,p_lines jsonb) returns void
language plpgsql stable security definer set search_path='' as $$
declare count_lines integer;matched integer;anchored boolean;
begin
 perform cp7_invoice.access_now();count_lines:=jsonb_array_length(p_lines);
 select count(*),bool_or(ph.id=p_purchase) into matched,anchored from jsonb_array_elements(p_lines) line
 join erp.material_purchase_items i on i.id=(line->>'purchase_item_id')::uuid join erp.material_purchase_headers ph on ph.id=i.purchase_id
 where ph.supplier_id=p_supplier and ph.status='POSTED';
 if matched<>count_lines or anchored is distinct from true then raise exception 'CP7_INVOICE_SAME_SUPPLIER_POSTED_RECEIPTS_REQUIRED';end if;
 if (select count(distinct line->>'purchase_item_id') from jsonb_array_elements(p_lines) line)<>count_lines then raise exception 'CP7_INVOICE_DUPLICATE_LINE';end if;
end $$;

create function cp7_invoice.assert_document(p_invoice uuid,p_purchase uuid,p_reviewed jsonb) returns void
language plpgsql stable security definer set search_path='' as $$
declare ids jsonb;n integer;
begin
 perform cp7_invoice.access_now();
 if jsonb_typeof(p_reviewed) is distinct from 'array' or jsonb_array_length(p_reviewed) not between 1 and 100
  or exists(select 1 from jsonb_array_elements(p_reviewed) x where jsonb_typeof(x)<>'string') then raise exception 'CP7_INVOICE_COMPLETE_DOCUMENT_REQUIRED';end if;
 select count(*),jsonb_agg(distinct i.purchase_id::text order by i.purchase_id::text) into n,ids
 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=p_invoice;
 if n not between 1 and 100 or ids is null or not ids ? p_purchase::text
  or ids is distinct from (select jsonb_agg(x order by x) from jsonb_array_elements(p_reviewed) x)
  or exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id
   join erp.material_purchase_headers ph on ph.id=i.purchase_id join erp.material_supplier_invoices ih on ih.id=l.invoice_id
   where ih.id=p_invoice and ph.supplier_id is distinct from ih.supplier_id) then raise exception 'CP7_INVOICE_COMPLETE_DOCUMENT_REQUIRED';end if;
end $$;

create function cp7_invoice.document_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;r jsonb;old cp7_invoice.requests;l jsonb;expected bigint;pid uuid;ident uuid;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_invoice.access_now();
 if p_action is null or p_action not in('SAVE_DOCUMENT','POST_DOCUMENT','DELETE_DOCUMENT','REVERSE_DOCUMENT') or p_request is null then raise exception 'CP7_INVOICE_ACTION';end if;
 if a->(case when p_action='REVERSE_DOCUMENT' then 'reverse' else 'finalize' end) is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_INVOICE_DOCUMENT_ACTION_DENIED';end if;
 if p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_INVOICE_VERSION';end if;expected:=p_expected::bigint;
 if jsonb_typeof(p_payload) is distinct from 'object' then raise exception 'CP7_INVOICE_FIELDS';end if;
 insert into cp7_invoice.requests values(auth.uid(),p_request,p_action,p_payload,p_expected,null) on conflict do nothing;
 select * into old from cp7_invoice.requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_INVOICE_REQUEST_CHANGED';end if;
 if cp7_invoice.access_now()<>a then raise exception using errcode='42501',message='CP7_INVOICE_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 pid:=(p_payload->>'purchase_id')::uuid;
 if p_action='SAVE_DOCUMENT' then
  if not p_payload ?& array['purchase_id','invoice_number','supplier_id','invoice_date','received_at','change_reason','lines'] or exists(select 1 from jsonb_each(p_payload) e
   where e.key not in('purchase_id','id','invoice_number','supplier_id','invoice_date','received_at','change_reason','lines','due_date','notes') or(e.key<>'lines' and jsonb_typeof(e.value) not in('string','null'))) then raise exception 'CP7_INVOICE_FIELDS';end if;
  if exists(select 1 from unnest(array['purchase_id','invoice_number','supplier_id','invoice_date','received_at','change_reason']) k
   where jsonb_typeof(p_payload->k) is distinct from 'string' or nullif(btrim(p_payload->>k),'') is null) then raise exception 'CP7_INVOICE_FIELDS';end if;
  if ((p_payload->>'id') is null and expected is not null) or ((p_payload->>'id') is not null and expected is null) then raise exception 'CP7_INVOICE_VERSION';end if;
  if jsonb_typeof(p_payload->'lines') is distinct from 'array' or jsonb_array_length(p_payload->'lines') not between 1 and 100 then raise exception 'CP7_INVOICE_LINES';end if;
  for l in select value from jsonb_array_elements(p_payload->'lines') loop
   if jsonb_typeof(l) is distinct from 'object' or not l ?& array['purchase_item_id','qty_invoiced','unit_price']
    or exists(select 1 from jsonb_each(l) e where e.key not in('purchase_item_id','qty_invoiced','unit_price','discount_amount','notes') or jsonb_typeof(e.value) not in('string','null')) then raise exception 'CP7_INVOICE_LINE';end if;
   if l->>'qty_invoiced' is null or l->>'qty_invoiced'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$' or (l->>'qty_invoiced')::numeric<=0
    or l->>'unit_price' is null or l->>'unit_price'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$'
    or(l ? 'discount_amount' and (l->>'discount_amount' is null or l->>'discount_amount'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$')) then raise exception 'CP7_INVOICE_EXACT_DECIMAL';end if;
  end loop;
  perform cp7_invoice.validate_sources(pid,(p_payload->>'supplier_id')::uuid,p_payload->'lines');
  r:=erp.save_material_supplier_invoice_draft_v2(p_payload-'purchase_id',p_request,expected);
  perform cp7_invoice.validate_sources(pid,(p_payload->>'supplier_id')::uuid,p_payload->'lines');
 else
  if expected is null or not p_payload ?& array['purchase_id','invoice_id','reason','reviewed_purchase_ids'] or exists(select 1 from jsonb_each(p_payload) e
   where e.key not in('purchase_id','invoice_id','reason','reviewed_purchase_ids') or(e.key<>'reviewed_purchase_ids' and jsonb_typeof(e.value)<>'string')) then raise exception 'CP7_INVOICE_FIELDS';end if;
  ident:=(p_payload->>'invoice_id')::uuid;
  perform cp7_invoice.assert_document(ident,pid,p_payload->'reviewed_purchase_ids');
  if p_action='POST_DOCUMENT' then r:=erp.post_material_supplier_invoice_v2(ident,p_request,expected,p_payload->>'reason');
  elsif p_action='DELETE_DOCUMENT' then r:=erp.save_material_supplier_invoice_draft_v2(jsonb_build_object('id',ident,'action','DELETE','change_reason',p_payload->>'reason'),p_request,expected);
  else r:=erp.reverse_material_supplier_invoice_v2(ident,p_payload->>'reason',p_request,expected);end if;
  if p_action<>'DELETE_DOCUMENT' then perform cp7_invoice.assert_document(ident,pid,p_payload->'reviewed_purchase_ids');end if;
 end if;
 if cp7_invoice.access_now()<>a then raise exception using errcode='42501',message='CP7_INVOICE_ACCESS_CHANGED';end if;
 r:=jsonb_build_object('contract_version','cp7.purchase-invoice-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,
  'purchase_id',pid,'invoice_id',r->'supplier_invoice_id','version_subject','INVOICE','row_version',r->>'row_version',
  'status',case when p_action='DELETE_DOCUMENT' then 'DELETED' else r->>'status' end);
 update cp7_invoice.requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;

-- Owning supplier-payment history and reviewed inverse. No alternate AP formula
-- or payment writer: amounts come from the accepted supplier-credit reader and
-- every financial inverse comes from erp.reverse_supplier_payment.
grant select on erp.supplier_payments,erp.cash_accounts,erp.journal_entries,erp.journal_lines to cp7_invoice_read;
grant execute on function public.erp_get_supplier_credit_v1(jsonb) to cp7_invoice_read;
create table cp7_invoice.payment_requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,response jsonb,
 primary key(actor,request_id)
);
alter table cp7_invoice.payment_requests owner to cp7_invoice_write;
alter table cp7_invoice.payment_requests enable row level security;
revoke all on cp7_invoice.payment_requests from public,anon,authenticated,service_role,cp7_capture,cp7_invoice_read;

create function cp7_invoice.payment_access() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 a:=cp7_invoice.access_now();
 return a||jsonb_build_object('reverse_payment',
  a->'profile'->>'role_code' in('OWNER','ADMIN') and erp.has_permission('finance.ap.pay'));
end $$;

create function cp7_invoice.payment_ap(p_purchase uuid) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare h erp.material_purchase_headers;r jsonb;answer jsonb;
begin
 perform cp7_invoice.payment_access();
 select * into h from erp.material_purchase_headers where id=p_purchase;
 if not found or h.supplier_id is null then raise exception 'CP7_SUPPLIER_PAYMENT_RECEIPT_NOT_FOUND';end if;
 r:=public.erp_get_supplier_credit_v1(jsonb_build_object('supplier_id',h.supplier_id,'page',1));
 select value into answer from jsonb_array_elements(r->'purchases') where value->>'id'=h.id::text;
 if h.status='POSTED' and answer is null then raise exception 'CP7_SUPPLIER_PAYMENT_AP_UNAVAILABLE';end if;
 return answer;
end $$;

create function cp7_invoice.payment_detail(p_payment uuid,p_ap jsonb) returns jsonb
language plpgsql volatile security definer set search_path='' as $$
declare p erp.supplier_payments;h erp.material_purchase_headers;c erp.cash_accounts;
 j erp.journal_entries;inverse erp.journal_entries;n bigint;state jsonb;r jsonb;
 previous_zone text:=current_setting('TimeZone');
begin
 perform cp7_invoice.payment_access();
 -- Hash the full original rows in one stable timezone, restoring the caller's
 -- zone before any Native inverse. No timestamp or dependency is dropped.
 perform set_config('TimeZone','UTC',true);
 select * into p from erp.supplier_payments where id=p_payment;
 if not found then raise exception 'CP7_SUPPLIER_PAYMENT_NOT_FOUND';end if;
 select * into h from erp.material_purchase_headers where id=p.purchase_id;
 if h.id is null or(p_ap is not null and p_ap->>'id' is distinct from h.id::text)
  or(h.status='POSTED' and p_ap is null) then raise exception 'CP7_SUPPLIER_PAYMENT_AP_UNAVAILABLE';end if;
 select * into c from erp.cash_accounts where id=p.cash_account_id;
 select count(*) into n from erp.journal_entries where source_type='SUPPLIER_PAYMENT' and source_id=p.id and reversal_of_id is null;
 if n>1 then raise exception 'CP7_SUPPLIER_PAYMENT_COMPLETE_JOURNAL_REQUIRED';end if;
 select * into j from erp.journal_entries where source_type='SUPPLIER_PAYMENT' and source_id=p.id and reversal_of_id is null;
 if j.id is not null then
  select count(*) into n from erp.journal_entries where reversal_of_id=j.id;
  if n>1 then raise exception 'CP7_SUPPLIER_PAYMENT_COMPLETE_JOURNAL_REQUIRED';end if;
  select * into inverse from erp.journal_entries where reversal_of_id=j.id;
 end if;
 if p.amount<=0 or p.amount<>round(p.amount,2) or p.status not in('DRAFT','POSTED','REVERSED')
  or(p.status='DRAFT' and j.id is not null)
  or(p.status='POSTED' and(j.id is null or j.status<>'POSTED' or inverse.id is not null))
  or(p.status='REVERSED' and(j.id is null or j.status<>'REVERSED' or inverse.id is null or inverse.status<>'POSTED')) then
  raise exception 'CP7_SUPPLIER_PAYMENT_COMPLETE_JOURNAL_REQUIRED';end if;
 state:=jsonb_build_object('payment',to_jsonb(p),'purchase',to_jsonb(h),'cash',to_jsonb(c),'Native_AP',p_ap,
  'journal',to_jsonb(j),'inverse',to_jsonb(inverse),'lines',
  (select coalesce(jsonb_agg(to_jsonb(l)order by l.id),'[]')from erp.journal_lines l where l.journal_entry_id in(j.id,inverse.id)));
 r:=jsonb_build_object('id',p.id,'number',p.payment_number,'status',p.status,'payment_date',p.payment_date,
  'amount',p.amount::numeric(20,2)::text,'cash_account_id',p.cash_account_id,'cash_code',c.cash_account_code,'cash_name',c.cash_account_name,
  'journal',case when j.id is null then null else jsonb_build_object('id',j.id,'number',j.journal_number,'status',j.status,
   'economic_date',j.economic_date,'accounting_date',j.transaction_date,'posting_at',j.posting_at,'period_shifted',j.period_shifted)end,
  'inverse',case when inverse.id is null then null else jsonb_build_object('id',inverse.id,'number',inverse.journal_number,'status',inverse.status,
   'economic_date',inverse.economic_date,'accounting_date',inverse.transaction_date,'posting_at',inverse.posting_at,'period_shifted',inverse.period_shifted)end,
  'review_token',md5(state::text));
 perform set_config('TimeZone',previous_zone,true);return r;
exception when others then perform set_config('TimeZone',previous_zone,true);raise;
end $$;

create function cp7_invoice.payment_workspace(p_purchase uuid,p_q text,p_offset integer,p_payment uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;h erp.material_purchase_headers;s erp.suppliers;ap jsonb;rows jsonb;total bigint;q text;
begin
 a:=cp7_invoice.payment_access();q:=btrim(coalesce(p_q,''));
 if p_purchase is null or length(q)>120 or p_offset is null or p_offset not between 0 and 1000000 then raise exception 'CP7_SUPPLIER_PAYMENT_QUERY';end if;
 select * into h from erp.material_purchase_headers where id=p_purchase;
 if not found or h.supplier_id is null then raise exception 'CP7_SUPPLIER_PAYMENT_RECEIPT_NOT_FOUND';end if;
 select * into s from erp.suppliers where id=h.supplier_id;ap:=cp7_invoice.payment_ap(h.id);
 if p_payment is not null then
  if q<>'' then raise exception 'CP7_SUPPLIER_PAYMENT_EXACT_QUERY';end if;
  select ((n-1)/25)*25 into p_offset from(select id,row_number()over(order by payment_date,created_at,id)n from erp.supplier_payments where purchase_id=h.id)x where id=p_payment;
  if p_offset is null or p_offset>1000000 then raise exception 'CP7_SUPPLIER_PAYMENT_NOT_FOUND';end if;
 end if;
 select count(*) into total from erp.supplier_payments where purchase_id=h.id and(q='' or strpos(lower(payment_number),lower(q))>0);
 select coalesce(jsonb_agg(cp7_invoice.payment_detail(p.id,ap)order by p.payment_date,p.created_at,p.id),'[]')into rows
  from(select * from erp.supplier_payments where purchase_id=h.id and(q='' or strpos(lower(payment_number),lower(q))>0)
   order by payment_date,created_at,id limit 25 offset p_offset)p;
 if cp7_invoice.payment_access()<>a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.supplier-payment-read.v1','captured_at',statement_timestamp(),'query',q,'selected_payment_id',p_payment,
  'purchase',jsonb_build_object('id',h.id,'number',h.purchase_number,'status',h.status,'supplier_id',s.id,'supplier_name',s.supplier_name),
  'Native_AP',ap,'capabilities',jsonb_build_object('reverse',a->'reverse_payment'),
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',p_offset,'limit',25,
   'next_offset',case when p_offset+jsonb_array_length(rows)<total then p_offset+jsonb_array_length(rows)else null end));
end $$;

-- Like the receipt inverse adapter, this narrow postgres helper locks Native
-- sources without granting ERP UPDATE/INSERT/DELETE to either CP7 principal.
create function cp7_invoice.reverse_payment_locked(p_payload jsonb) returns uuid
language plpgsql volatile security definer set search_path='' as $$
declare a jsonb;p erp.supplier_payments;h erp.material_purchase_headers;d jsonb;journal uuid;inverse uuid;
begin
 a:=cp7_invoice.payment_access();
 if a->'reverse_payment' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_REVERSE_DENIED';end if;
 select * into p from erp.supplier_payments where id=(p_payload->>'payment_id')::uuid for update;
 if p.id is null or p.purchase_id is distinct from(p_payload->>'purchase_id')::uuid then raise exception 'CP7_SUPPLIER_PAYMENT_NOT_FOUND';end if;
 select * into h from erp.material_purchase_headers where id=p.purchase_id for update;
 perform 1 from erp.initial_import_prepayments x join erp.initial_import_prepayment_payments l on l.advance_id=x.id where l.payment_id=p.id for update of x;
 perform 1 from erp.journal_entries x where x.source_type='SUPPLIER_PAYMENT'and x.source_id=p.id order by x.id for update;
 perform 1 from erp.journal_lines l join erp.journal_entries x on x.id=l.journal_entry_id where x.source_type='SUPPLIER_PAYMENT'and x.source_id=p.id order by l.id for update of l;
 if cp7_invoice.payment_access()<>a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 if p.status<>'POSTED' or h.status<>'POSTED' then raise exception 'CP7_SUPPLIER_PAYMENT_POSTED_REQUIRED';end if;
 d:=cp7_invoice.payment_detail(p.id,cp7_invoice.payment_ap(h.id));
 if d->>'review_token' is distinct from p_payload->>'review_token' then raise exception 'CP7_SUPPLIER_PAYMENT_STALE_REVIEW';end if;
 journal:=(d->'journal'->>'id')::uuid;
 perform erp.reverse_supplier_payment(p.id,p_payload->>'reason');
 if cp7_invoice.payment_access()<>a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 select id into inverse from erp.journal_entries where reversal_of_id=journal and status='POSTED';
 if inverse is null or not exists(select 1 from erp.supplier_payments where id=p.id and status='REVERSED')then raise exception 'CP7_SUPPLIER_PAYMENT_INVERSE_INCOMPLETE';end if;
 return inverse;
end $$;
alter function cp7_invoice.reverse_payment_locked(jsonb)owner to postgres;

create function cp7_invoice.reverse_payment_request(p_payload jsonb,p_request uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_invoice.payment_requests;r jsonb;inverse uuid;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_invoice.payment_access();
 if a->'reverse_payment' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_REVERSE_DENIED';end if;
 if p_request is null or jsonb_typeof(p_payload)is distinct from'object' or not p_payload?&array['purchase_id','payment_id','review_token','reason']
  or exists(select 1 from jsonb_each(p_payload)e where e.key not in('purchase_id','payment_id','review_token','reason')or jsonb_typeof(e.value)<>'string' or nullif(btrim(e.value#>>'{}'),'')is null)
  or length(p_payload->>'reason')>1000 or p_payload->>'review_token'!~'^[a-f0-9]{32}$' then raise exception 'CP7_SUPPLIER_PAYMENT_FIELDS';end if;
 insert into cp7_invoice.payment_requests values(auth.uid(),p_request,p_payload,null)on conflict do nothing;
 select * into old from cp7_invoice.payment_requests where actor=auth.uid()and request_id=p_request for update;
 if old.payload<>p_payload then raise exception 'CP7_SUPPLIER_PAYMENT_REQUEST_CHANGED';end if;
 if cp7_invoice.payment_access()<>a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 inverse:=cp7_invoice.reverse_payment_locked(p_payload);
 r:=jsonb_build_object('contract_version','cp7.supplier-payment-outcome.v1','kind','COMMITTED_OUTCOME','action','REVERSE',
  'request_id',p_request,'request_payload',p_payload,'purchase_id',p_payload->>'purchase_id','payment_id',p_payload->>'payment_id',
  'status','REVERSED','inverse_journal_id',inverse);
 update cp7_invoice.payment_requests set response=r where actor=auth.uid()and request_id=p_request;return r;
end $$;

create function public.erp_cp7_get_supplier_payments_v1(p_purchase uuid,p_q text,p_offset integer,p_payment uuid default null) returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_invoice.payment_workspace(p_purchase,p_q,p_offset,p_payment)$$;
create function public.erp_cp7_reverse_supplier_payment_v1(p_payload jsonb,p_request uuid) returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_invoice.reverse_payment_request(p_payload,p_request)$$;

create function cp7_invoice.command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;z jsonb;r jsonb;l jsonb;expected bigint;pid uuid;
begin
 if p_action in('SAVE_DOCUMENT','POST_DOCUMENT','DELETE_DOCUMENT','REVERSE_DOCUMENT') then
  return cp7_invoice.document_command(p_action,p_payload,p_request,p_expected);
 end if;
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_invoice.access_now();
 if p_action is null or p_action not in('FINALIZE','REVERSE') or p_request is null then raise exception 'CP7_INVOICE_ACTION';end if;
 if p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_INVOICE_VERSION';end if;
 expected:=p_expected::bigint;
 if jsonb_typeof(p_payload) is distinct from 'object' then raise exception 'CP7_INVOICE_FIELDS';end if;
 if p_action='FINALIZE' then
  if a->'finalize' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_INVOICE_FINALIZE_DENIED';end if;
  if not p_payload ?& array['purchase_id','supplier_invoice_number','invoice_date','received_at','reason','lines'] or exists(select 1 from jsonb_each(p_payload) e
   where e.key not in('purchase_id','supplier_invoice_number','invoice_date','received_at','reason','lines','due_date','notes') or(e.key<>'lines' and jsonb_typeof(e.value) not in('string','null'))) then raise exception 'CP7_INVOICE_FIELDS';end if;
  if exists(select 1 from unnest(array['purchase_id','supplier_invoice_number','invoice_date','received_at','reason']) k
   where jsonb_typeof(p_payload->k) is distinct from 'string' or nullif(btrim(p_payload->>k),'') is null) then raise exception 'CP7_INVOICE_FIELDS';end if;
  if jsonb_typeof(p_payload->'lines') is distinct from 'array' or jsonb_array_length(p_payload->'lines') not between 1 and 100 then raise exception 'CP7_INVOICE_LINES';end if;
  for l in select value from jsonb_array_elements(p_payload->'lines') loop
   if jsonb_typeof(l) is distinct from 'object' or not l ?& array['purchase_item_id','qty_invoiced','final_unit_price']
    or exists(select 1 from jsonb_each(l) e where e.key not in('purchase_item_id','qty_invoiced','final_unit_price','discount_amount','notes') or jsonb_typeof(e.value) not in('string','null')) then raise exception 'CP7_INVOICE_LINE';end if;
   if l->>'qty_invoiced' is null or l->>'qty_invoiced'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$' or (l->>'qty_invoiced')::numeric<=0
    or l->>'final_unit_price' is null or l->>'final_unit_price'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$'
    or(l ? 'discount_amount' and (l->>'discount_amount' is null or l->>'discount_amount'!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$')) then raise exception 'CP7_INVOICE_EXACT_DECIMAL';end if;
  end loop;
  pid:=(p_payload->>'purchase_id')::uuid;
  r:=erp.finalize_material_purchase_invoice_v2(p_payload,p_request,expected);
 else
  if a->'reverse' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_INVOICE_REVERSE_DENIED';end if;
  if not p_payload ?& array['purchase_id','invoice_id','reason'] or exists(select 1 from jsonb_each(p_payload) e where e.key not in('purchase_id','invoice_id','reason') or jsonb_typeof(e.value)<>'string') then raise exception 'CP7_INVOICE_FIELDS';end if;
  pid:=(p_payload->>'purchase_id')::uuid;
  perform cp7_invoice.assert_single_receipt((p_payload->>'invoice_id')::uuid,pid);
  r:=erp.reverse_material_supplier_invoice_v2((p_payload->>'invoice_id')::uuid,p_payload->>'reason',p_request,expected);
 end if;
 z:=cp7_invoice.access_now();if z<>a then raise exception using errcode='42501',message='CP7_INVOICE_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.purchase-invoice-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,
  'purchase_id',pid,'invoice_id',r->'supplier_invoice_id','version_subject',case when p_action='FINALIZE' then 'RECEIPT' else 'INVOICE' end,
  'row_version',r->>'row_version','status',case when p_action='FINALIZE' then 'POSTED' else r->>'status' end);
end $$;
create function public.erp_cp7_save_purchase_invoice_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_invoice.command(p_action,p_payload,p_request,p_expected)$$;

grant create on schema public,cp7_invoice to cp7_invoice_read,cp7_invoice_write;
alter function cp7_invoice.access_now() owner to cp7_invoice_read;
alter function cp7_invoice.assert_single_receipt(uuid,uuid) owner to cp7_invoice_read;
alter function cp7_invoice.workspace(uuid,integer,integer) owner to cp7_invoice_read;
alter function cp7_invoice.command(text,jsonb,uuid,text) owner to cp7_invoice_write;
alter function cp7_invoice.document_command(text,jsonb,uuid,text) owner to cp7_invoice_write;
alter function cp7_invoice.source_lines(uuid) owner to cp7_invoice_read;
alter function cp7_invoice.sources(uuid,text,integer,integer) owner to cp7_invoice_read;
alter function cp7_invoice.validate_sources(uuid,uuid,jsonb) owner to cp7_invoice_read;
alter function cp7_invoice.assert_document(uuid,uuid,jsonb) owner to cp7_invoice_read;
alter function cp7_invoice.payment_access() owner to cp7_invoice_read;
alter function cp7_invoice.payment_ap(uuid) owner to cp7_invoice_read;
alter function cp7_invoice.payment_detail(uuid,jsonb) owner to cp7_invoice_read;
alter function cp7_invoice.payment_workspace(uuid,text,integer,uuid) owner to cp7_invoice_read;
alter function cp7_invoice.reverse_payment_request(jsonb,uuid) owner to cp7_invoice_write;
alter function public.erp_cp7_get_supplier_payments_v1(uuid,text,integer,uuid) owner to cp7_invoice_read;
alter function public.erp_cp7_reverse_supplier_payment_v1(jsonb,uuid) owner to cp7_invoice_write;
alter function public.erp_cp7_get_invoice_sources_v1(uuid,text,integer,integer) owner to cp7_invoice_read;
alter function public.erp_cp7_get_purchase_invoices_v1(uuid,integer,integer) owner to cp7_invoice_read;
alter function public.erp_cp7_save_purchase_invoice_v1(text,jsonb,uuid,text) owner to cp7_invoice_write;
revoke create on schema public,cp7_invoice from cp7_invoice_read,cp7_invoice_write;
revoke all on all functions in schema cp7_invoice from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_invoice.access_now(),cp7_invoice.assert_single_receipt(uuid,uuid) to cp7_invoice_write;
grant execute on function cp7_invoice.validate_sources(uuid,uuid,jsonb),cp7_invoice.assert_document(uuid,uuid,jsonb) to cp7_invoice_write;
grant execute on function cp7_invoice.payment_access(),cp7_invoice.reverse_payment_locked(jsonb) to cp7_invoice_write;
-- The accepted runtime's postgres role is deliberately not a superuser. The
-- narrow locking helper needs these exact private readers, including the
-- invoker access check's dependency; no ERP DML or App execution is added.
grant execute on function cp7_invoice.access_now(),cp7_invoice.payment_access(),
 cp7_invoice.payment_ap(uuid),cp7_invoice.payment_detail(uuid,jsonb) to postgres;
revoke all on function public.erp_cp7_get_supplier_payments_v1(uuid,text,integer,uuid),public.erp_cp7_reverse_supplier_payment_v1(jsonb,uuid) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_supplier_payments_v1(uuid,text,integer,uuid),public.erp_cp7_reverse_supplier_payment_v1(jsonb,uuid) to authenticated;
revoke all on function public.erp_cp7_get_invoice_sources_v1(uuid,text,integer,integer) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_invoice_sources_v1(uuid,text,integer,integer) to authenticated;
revoke all on function public.erp_cp7_get_purchase_invoices_v1(uuid,integer,integer),public.erp_cp7_save_purchase_invoice_v1(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_purchase_invoices_v1(uuid,integer,integer),public.erp_cp7_save_purchase_invoice_v1(text,jsonb,uuid,text) to authenticated;

-- Correct one ordinary supplier payment in one transaction. Preserve the
-- Native original, create a new Native draft/post, and retain immutable links.
-- Imported advances keep their separate allocation/reconciliation meaning.
create schema cp7_supplier_payment_correction authorization cp7_invoice_read;
revoke all on schema cp7_supplier_payment_correction from public,anon,authenticated,service_role,cp7_capture;
grant usage,create on schema cp7_supplier_payment_correction to cp7_invoice_write;
grant usage on schema cp7_supplier_payment_correction to postgres;
create table cp7_supplier_payment_correction.requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,response jsonb,primary key(actor,request_id)
);
create table cp7_supplier_payment_correction.context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 request_id uuid not null,payload jsonb not null,primary key(backend_pid,transaction_id)
);
create table cp7_supplier_payment_correction.links(
 original_id uuid primary key references erp.supplier_payments(id),
 replacement_id uuid not null unique references erp.supplier_payments(id),
 purchase_id uuid not null references erp.material_purchase_headers(id),actor uuid not null,
 request_id uuid not null,reason text not null,
 time_neutral_id uuid references erp.journal_entries(id),effective_inverse_id uuid references erp.journal_entries(id),
 recorded_at timestamptz not null default statement_timestamp(),
 check(original_id<>replacement_id),check(length(btrim(reason))between 5 and 1000),
 check((time_neutral_id is null)=(effective_inverse_id is null)),unique(actor,request_id)
);
alter table cp7_supplier_payment_correction.requests owner to cp7_invoice_write;
alter table cp7_supplier_payment_correction.context owner to cp7_invoice_write;
alter table cp7_supplier_payment_correction.links owner to cp7_invoice_write;
alter table cp7_supplier_payment_correction.requests enable row level security;
alter table cp7_supplier_payment_correction.context enable row level security;
alter table cp7_supplier_payment_correction.links enable row level security;
create policy supplier_payment_correction_requests_deny on cp7_supplier_payment_correction.requests for all to public using(false)with check(false);
create policy supplier_payment_correction_context_deny on cp7_supplier_payment_correction.context for all to public using(false)with check(false);
create policy supplier_payment_correction_links_deny on cp7_supplier_payment_correction.links for all to public using(false)with check(false);
revoke all on all tables in schema cp7_supplier_payment_correction from public,anon,authenticated,service_role,cp7_capture;
grant select on cp7_supplier_payment_correction.context,cp7_supplier_payment_correction.links to postgres;

create function cp7_supplier_payment_correction.access_now()returns jsonb
language plpgsql stable security invoker set search_path=''as $$
declare a jsonb;
begin
 a:=cp7_invoice.payment_access();
 if a->'reverse_payment'is distinct from'true'::jsonb then
  raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_CORRECTION_DENIED';end if;
 return a;
end $$;

create function cp7_supplier_payment_correction.validate(p jsonb)returns void
language plpgsql immutable security invoker set search_path=''as $$
begin
 if jsonb_typeof(p)is distinct from'object'or not(p?&array['purchase_id','payment_id','review_token','replacement','change_reason'])
  or(select count(*)from jsonb_object_keys(p))<>5
  or jsonb_typeof(p->'purchase_id')is distinct from'string'or coalesce(p->>'purchase_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or jsonb_typeof(p->'payment_id')is distinct from'string'or coalesce(p->>'payment_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or jsonb_typeof(p->'review_token')is distinct from'string'or coalesce(p->>'review_token','')!~'^[a-f0-9]{32}$'
  or jsonb_typeof(p->'change_reason')is distinct from'string'or length(btrim(p->>'change_reason'))not between 5 and 1000 then
  raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_FIELDS';end if;
 if jsonb_typeof(p->'replacement')is distinct from'object'
  or not(p->'replacement'?&array['amount','cash_account_id','payment_date'])
  or(select count(*)from jsonb_object_keys(p->'replacement'))<>3
  or exists(select 1 from jsonb_each(p->'replacement')where jsonb_typeof(value)<>'string')
  or coalesce(p->'replacement'->>'amount','')!~'^(0|[1-9][0-9]{0,17})\.[0-9]{2}$'
  or(p->'replacement'->>'amount')::numeric<=0
  or coalesce(p->'replacement'->>'cash_account_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p->'replacement'->>'payment_date','')!~'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.[0-9]{1,6})?(Z|[+-]\d{2}:\d{2})$'then
  raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_FIELDS';end if;
 perform(p->'replacement'->>'payment_date')::timestamptz;
end $$;

create function cp7_supplier_payment_correction.link_value(p cp7_supplier_payment_correction.links)returns jsonb
language sql stable security definer set search_path=''set TimeZone='UTC'as $$
 select jsonb_build_object('original_id',p.original_id,'replacement_id',p.replacement_id,
  'purchase_id',p.purchase_id,'actor_scope_id',p.actor,'request_id',p.request_id,'reason',p.reason,'recorded_at',p.recorded_at,
  'time_restatement',case when p.time_neutral_id is null then null else(
   select jsonb_build_object('neutral_journal_id',n.id,'neutral_number',n.journal_number,
    'neutral_economic_date',n.economic_date,'neutral_transaction_date',n.transaction_date,
    'effective_journal_id',e.id,'effective_number',e.journal_number,
    'effective_economic_date',e.economic_date,'effective_transaction_date',e.transaction_date)
   from erp.journal_entries n join erp.journal_entries e on e.id=p.effective_inverse_id where n.id=p.time_neutral_id)end)
$$;

create function cp7_supplier_payment_correction.workspace(p_query jsonb)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;original erp.supplier_payments;h erp.material_purchase_headers;ap jsonb;d jsonb;
 prev cp7_supplier_payment_correction.links;nxt cp7_supplier_payment_correction.links;
 previous jsonb:='null';following jsonb:='null';q text;off integer;rows jsonb;total bigint;
begin
 a:=cp7_invoice.payment_access();
 if jsonb_typeof(p_query)is distinct from'object'or not(p_query?&array['purchase_id','payment_id'])
  or exists(select 1 from jsonb_object_keys(p_query)x where x not in('purchase_id','payment_id','bank_q','bank_offset'))
  or jsonb_typeof(p_query->'purchase_id')is distinct from'string'or coalesce(p_query->>'purchase_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or jsonb_typeof(p_query->'payment_id')is distinct from'string'or coalesce(p_query->>'payment_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or(p_query?'bank_q'and jsonb_typeof(p_query->'bank_q')is distinct from'string')
  or(p_query?'bank_offset'and(jsonb_typeof(p_query->'bank_offset')is distinct from'number'or coalesce(p_query->>'bank_offset','')!~'^(0|[1-9][0-9]{0,6})$'))then
  raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_QUERY';end if;
 q:=btrim(coalesce(p_query->>'bank_q',''));off:=coalesce((p_query->>'bank_offset')::integer,0);
 if length(q)>120 or off>1000000 then raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_QUERY';end if;
 select *into original from erp.supplier_payments where id=(p_query->>'payment_id')::uuid and purchase_id=(p_query->>'purchase_id')::uuid;
 if original.id is null then raise exception 'CP7_SUPPLIER_PAYMENT_NOT_FOUND';end if;
 select *into strict h from erp.material_purchase_headers where id=original.purchase_id;
 ap:=cp7_invoice.payment_ap(h.id);d:=cp7_invoice.payment_detail(original.id,ap);
 select *into prev from cp7_supplier_payment_correction.links where replacement_id=original.id and purchase_id=h.id;
 select *into nxt from cp7_supplier_payment_correction.links where original_id=original.id and purchase_id=h.id;
 if prev.original_id is not null then previous:=jsonb_build_object('link',cp7_supplier_payment_correction.link_value(prev),'document',cp7_invoice.payment_detail(prev.original_id,ap));end if;
 if nxt.original_id is not null then following:=jsonb_build_object('link',cp7_supplier_payment_correction.link_value(nxt),'document',cp7_invoice.payment_detail(nxt.replacement_id,ap));end if;
 select count(*)into total from erp.cash_accounts c join erp.chart_accounts ca on ca.id=c.coa_account_id
  where c.is_active and ca.is_active and ca.is_postable and(q=''or strpos(lower(c.cash_account_code||' '||c.cash_account_name),lower(q))>0);
 select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'code',c.cash_account_code,'name',c.cash_account_name,'kind',c.account_kind)order by c.cash_account_code,c.id),'[]')into rows
  from(select c.*from erp.cash_accounts c join erp.chart_accounts ca on ca.id=c.coa_account_id
   where c.is_active and ca.is_active and ca.is_postable and(q=''or strpos(lower(c.cash_account_code||' '||c.cash_account_name),lower(q))>0)
   order by c.cash_account_code,c.id limit 25 offset off)c;
 if cp7_invoice.payment_access()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.supplier-payment-correction-workspace.v1','captured_at',statement_timestamp(),
  'purchase_id',h.id,'Native_AP',ap,'document',d,'can_correct',a->'reverse_payment',
  'eligible',original.status='POSTED'and h.status='POSTED'and original.cash_account_id is not null
   and not exists(select 1 from erp.initial_import_prepayment_payments where payment_id=original.id)
   and not exists(select 1 from cp7_supplier_payment_correction.links where original_id=original.id),
  'previous',previous,'next',following,'cash_accounts',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',25,
   'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows)else null end));
end $$;

create function cp7_supplier_payment_correction.protect_link()returns trigger
language plpgsql volatile security definer set search_path=''as $$
begin
 if tg_op<>'INSERT'then raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_LINK_IMMUTABLE';end if;
 if not exists(select 1 from cp7_supplier_payment_correction.context c where c.backend_pid=pg_backend_pid()and c.transaction_id=txid_current()
  and c.actor=auth.uid()and c.actor=new.actor and c.request_id=new.request_id and c.payload->>'purchase_id'=new.purchase_id::text
  and c.payload->>'payment_id'=new.original_id::text and btrim(c.payload->>'change_reason')=new.reason)
  or not exists(select 1 from erp.supplier_payments where id=new.original_id and purchase_id=new.purchase_id and status='REVERSED')
  or not exists(select 1 from erp.supplier_payments where id=new.replacement_id and purchase_id=new.purchase_id and status='POSTED')then
  raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_CORRECTION_PRIVATE_CONTEXT_REQUIRED';end if;
 if new.time_neutral_id is not null and(not exists(select 1 from erp.journal_entries where id=new.time_neutral_id and source_type='SUPPLIER_PAYMENT_CORRECTION_TIME_NEUTRAL'and source_id=new.original_id and status='POSTED')
  or not exists(select 1 from erp.journal_entries where id=new.effective_inverse_id and source_type='SUPPLIER_PAYMENT_CORRECTION_EFFECTIVE'and source_id=new.original_id and status='POSTED'))then
  raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_JOURNAL_SOURCE_CHANGED';end if;
 return new;
end $$;
create trigger supplier_payment_correction_link_immutable before insert or update or delete on cp7_supplier_payment_correction.links for each row execute function cp7_supplier_payment_correction.protect_link();
create trigger supplier_payment_correction_link_no_truncate before truncate on cp7_supplier_payment_correction.links for each statement execute function cp7_supplier_payment_correction.protect_link();

create function cp7_supplier_payment_correction.apply(p jsonb,p_request uuid)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;original erp.supplier_payments;h erp.material_purchase_headers;ap jsonb;d jsonb;
 o erp.journal_entries;inv erp.journal_entries;lines jsonb;neutral uuid;effective uuid;replacement uuid;link cp7_supplier_payment_correction.links;
begin
 a:=cp7_supplier_payment_correction.access_now();perform cp7_supplier_payment_correction.validate(p);
 if not exists(select 1 from cp7_supplier_payment_correction.context where backend_pid=pg_backend_pid()and transaction_id=txid_current()
  and actor=auth.uid()and request_id=p_request and payload=p)then
  raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_CORRECTION_PRIVATE_CONTEXT_REQUIRED';end if;
 perform pg_advisory_xact_lock(hashtextextended('FG_HPP_SALES_V2620C',0));
 perform 1 from erp.supplier_payments where purchase_id=(p->>'purchase_id')::uuid order by id for update;
 select *into h from erp.material_purchase_headers where id=(p->>'purchase_id')::uuid for update;
 select *into original from erp.supplier_payments where id=(p->>'payment_id')::uuid;
 if h.id is null or original.id is null or original.purchase_id<>h.id then raise exception 'CP7_SUPPLIER_PAYMENT_NOT_FOUND';end if;
 if cp7_supplier_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 if original.status<>'POSTED'or h.status<>'POSTED'or original.cash_account_id is null
  or exists(select 1 from erp.initial_import_prepayment_payments where payment_id=original.id)
  or exists(select 1 from cp7_supplier_payment_correction.links where original_id=original.id)then raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_ORDINARY_ONLY';end if;
 ap:=cp7_invoice.payment_ap(h.id);d:=cp7_invoice.payment_detail(original.id,ap);
 if d->>'review_token'is distinct from p->>'review_token'then raise exception 'CP7_SUPPLIER_PAYMENT_STALE_REVIEW';end if;
 lock table erp.accounting_account_mappings in share mode;
 perform 1 from erp.cash_accounts where id in(original.cash_account_id,(p->'replacement'->>'cash_account_id')::uuid)order by id for share;
 perform 1 from erp.chart_accounts where id in(select coa_account_id from erp.cash_accounts where id in(original.cash_account_id,(p->'replacement'->>'cash_account_id')::uuid)
  union select account_id from erp.accounting_account_mappings where mapping_key='AP_SUPPLIER')order by id for share;
 if cp7_supplier_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 -- A cash/master lock may itself have waited after the first source review.
 -- Rebind the full Native source/AP/journal token to the now-locked rows.
 ap:=cp7_invoice.payment_ap(h.id);d:=cp7_invoice.payment_detail(original.id,ap);
 if d->>'review_token'is distinct from p->>'review_token'then raise exception 'CP7_SUPPLIER_PAYMENT_STALE_REVIEW';end if;
 -- The create path's dating rules: never in the future, and a changed time never
 -- before the goods arrived (money paid earlier is an advance, another document).
 if(p->'replacement'->>'payment_date')::timestamptz>statement_timestamp()then raise exception 'CP7_SUPPLIER_PAYMENT_DATE_FUTURE';end if;
 if(p->'replacement'->>'payment_date')::timestamptz<>original.payment_date and(p->'replacement'->>'payment_date')::timestamptz<h.physical_at then raise exception 'CP7_SUPPLIER_PAYMENT_BEFORE_RECEIPT';end if;
 if(p->'replacement'->>'amount')::numeric=original.amount and(p->'replacement'->>'payment_date')::timestamptz=original.payment_date
  and(p->'replacement'->>'cash_account_id')::uuid=original.cash_account_id then raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_UNCHANGED';end if;
 perform erp.reverse_supplier_payment(original.id,btrim(p->>'change_reason'));
 select *into strict o from erp.journal_entries where source_type='SUPPLIER_PAYMENT'and source_id=original.id and reversal_of_id is null;
 select *into strict inv from erp.journal_entries where reversal_of_id=o.id and source_type='JOURNAL_REVERSAL'and source_id=o.id;
 if o.status<>'REVERSED'or inv.status<>'POSTED'then raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_JOURNAL_SOURCE_CHANGED';end if;
 if o.economic_date<>inv.economic_date then
  select jsonb_agg(jsonb_build_object('account_id',l.account_id,'debit',l.credit,'credit',l.debit,'description',l.description,
   'customer_id',l.customer_id,'vendor_id',l.vendor_id,'contractor_id',l.contractor_id,'po_id',l.po_id,'product_id',l.product_id)order by l.id)into lines from erp.journal_lines l where l.journal_entry_id=inv.id;
  neutral:=erp.post_journal('SUPPLIER_PAYMENT_CORRECTION_TIME_NEUTRAL',original.id,inv.economic_date,'Koreksi pembayaran supplier: pindahkan waktu pembalikan | '||btrim(p->>'change_reason'),lines);
  select jsonb_agg(jsonb_build_object('account_id',l.account_id,'debit',l.debit,'credit',l.credit,'description',l.description,
   'customer_id',l.customer_id,'vendor_id',l.vendor_id,'contractor_id',l.contractor_id,'po_id',l.po_id,'product_id',l.product_id)order by l.id)into lines from erp.journal_lines l where l.journal_entry_id=inv.id;
  effective:=erp.post_journal('SUPPLIER_PAYMENT_CORRECTION_EFFECTIVE',original.id,o.economic_date,'Koreksi pembayaran supplier: waktu ekonomi asal | '||btrim(p->>'change_reason'),lines);
 end if;
 -- The new row is only a Native DRAFT; Native posting decides AP capacity,
 -- account eligibility, canonical business date and closed-period treatment.
 insert into erp.supplier_payments(purchase_id,payment_number,payment_date,amount,cash_account_id)
  values(h.id,'K-'||replace(p_request::text,'-',''),(p->'replacement'->>'payment_date')::timestamptz,
   (p->'replacement'->>'amount')::numeric,(p->'replacement'->>'cash_account_id')::uuid)returning id into replacement;
 perform erp.post_supplier_payment(replacement);
 if not exists(select 1 from erp.supplier_payments where id=replacement and purchase_id=h.id and status='POSTED')then raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_POST_INCOMPLETE';end if;
 if cp7_supplier_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 insert into cp7_supplier_payment_correction.links(original_id,replacement_id,purchase_id,actor,request_id,reason,time_neutral_id,effective_inverse_id)
  values(original.id,replacement,h.id,auth.uid(),p_request,btrim(p->>'change_reason'),neutral,effective)returning *into link;
 return jsonb_build_object('contract_version','cp7.supplier-payment-correction.v1','kind','COMMITTED_OUTCOME','action','CORRECT',
  'request_id',p_request,'request_payload',p,'purchase_id',h.id,'original_payment_id',original.id,'payment_id',replacement,
  'original_status','REVERSED','status','POSTED','link',cp7_supplier_payment_correction.link_value(link));
end $$;

create function cp7_supplier_payment_correction.command(p jsonb,p_request uuid)returns jsonb
language plpgsql volatile security invoker set search_path=''as $$
declare a jsonb;saved cp7_supplier_payment_correction.requests;r jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_supplier_payment_correction.access_now();perform cp7_supplier_payment_correction.validate(p);
 if p_request is null then raise exception 'CP7_SUPPLIER_PAYMENT_CORRECTION_FIELDS';end if;
 insert into cp7_supplier_payment_correction.requests values(auth.uid(),p_request,p,null)on conflict do nothing;
 select *into saved from cp7_supplier_payment_correction.requests where actor=auth.uid()and request_id=p_request for update;
 if cp7_supplier_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 if saved.payload is distinct from p then raise exception 'CP7_SUPPLIER_PAYMENT_REQUEST_CHANGED';end if;
 if saved.response is not null then return saved.response;end if;
 insert into cp7_supplier_payment_correction.context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,p);
 r:=cp7_supplier_payment_correction.apply(p,p_request);
 delete from cp7_supplier_payment_correction.context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_supplier_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 update cp7_supplier_payment_correction.requests set response=r where actor=auth.uid()and request_id=p_request;return r;
end $$;

alter function cp7_supplier_payment_correction.access_now()owner to cp7_invoice_read;
alter function cp7_supplier_payment_correction.validate(jsonb)owner to cp7_invoice_read;
alter function cp7_supplier_payment_correction.link_value(cp7_supplier_payment_correction.links)owner to postgres;
alter function cp7_supplier_payment_correction.workspace(jsonb)owner to postgres;
alter function cp7_supplier_payment_correction.protect_link()owner to postgres;
alter function cp7_supplier_payment_correction.apply(jsonb,uuid)owner to postgres;
alter function cp7_supplier_payment_correction.command(jsonb,uuid)owner to cp7_invoice_write;
revoke all on all functions in schema cp7_supplier_payment_correction from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_supplier_payment_correction.access_now(),cp7_supplier_payment_correction.validate(jsonb),cp7_supplier_payment_correction.apply(jsonb,uuid)to cp7_invoice_write;
grant execute on function cp7_supplier_payment_correction.access_now(),cp7_supplier_payment_correction.validate(jsonb),cp7_supplier_payment_correction.link_value(cp7_supplier_payment_correction.links)to postgres;
grant execute on function cp7_supplier_payment_correction.workspace(jsonb)to cp7_invoice_read;
grant insert on cp7_supplier_payment_correction.links to postgres;
revoke create on schema cp7_supplier_payment_correction from cp7_invoice_write;
grant create on schema public to cp7_invoice_write,cp7_invoice_read;
create function public.erp_cp7_correct_supplier_payment_v1(p_payload jsonb,p_request uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_supplier_payment_correction.command(p_payload,p_request)$$;
create function public.erp_cp7_get_supplier_payment_correction_v1(p_query jsonb)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_supplier_payment_correction.workspace(p_query)$$;
alter function public.erp_cp7_correct_supplier_payment_v1(jsonb,uuid)owner to cp7_invoice_write;
alter function public.erp_cp7_get_supplier_payment_correction_v1(jsonb)owner to cp7_invoice_read;
revoke create on schema public from cp7_invoice_write,cp7_invoice_read;
revoke all on function public.erp_cp7_correct_supplier_payment_v1(jsonb,uuid),public.erp_cp7_get_supplier_payment_correction_v1(jsonb)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_correct_supplier_payment_v1(jsonb,uuid),public.erp_cp7_get_supplier_payment_correction_v1(jsonb)to authenticated;

-- Record one new cash/bank payment of a posted material receipt's supplier AP.
-- CP7 already reads, corrects and reverses supplier payments; without this
-- entry the operator could not settle supplier AP in the application at all.
-- The new row is only a Native DRAFT: Native erp.post_supplier_payment stays
-- the single AP-capacity, account and journal authority. No ERP DML grant is
-- given to an App principal; the definer is the narrow postgres helper.
create schema cp7_supplier_payment_create authorization cp7_invoice_read;
revoke all on schema cp7_supplier_payment_create from public,anon,authenticated,service_role,cp7_capture;
grant usage,create on schema cp7_supplier_payment_create to cp7_invoice_write;
grant usage on schema cp7_supplier_payment_create to postgres;
create table cp7_supplier_payment_create.requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,response jsonb,primary key(actor,request_id)
);
create table cp7_supplier_payment_create.context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 request_id uuid not null,payload jsonb not null,primary key(backend_pid,transaction_id)
);
alter table cp7_supplier_payment_create.requests owner to cp7_invoice_write;
alter table cp7_supplier_payment_create.context owner to cp7_invoice_write;
alter table cp7_supplier_payment_create.requests enable row level security;
alter table cp7_supplier_payment_create.context enable row level security;
create policy supplier_payment_create_requests_deny on cp7_supplier_payment_create.requests for all to public using(false)with check(false);
create policy supplier_payment_create_context_deny on cp7_supplier_payment_create.context for all to public using(false)with check(false);
revoke all on all tables in schema cp7_supplier_payment_create from public,anon,authenticated,service_role,cp7_capture;
grant select on cp7_supplier_payment_create.context to postgres;

-- Paying money uses the same current authority as correcting or reversing it:
-- OWNER/ADMIN with finance.ap.pay on top of procurement and AP view.
create function cp7_supplier_payment_create.access_now()returns jsonb
language plpgsql stable security invoker set search_path=''as $$
declare a jsonb;
begin
 a:=cp7_invoice.payment_access();
 if a->'reverse_payment'is distinct from'true'::jsonb then
  raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_CREATE_DENIED';end if;
 return a;
end $$;

create function cp7_supplier_payment_create.validate(p jsonb)returns void
language plpgsql immutable security invoker set search_path=''as $$
begin
 if jsonb_typeof(p)is distinct from'object'
  or not(p?&array['purchase_id','review_token','amount','cash_account_id','payment_date','note'])
  or(select count(*)from jsonb_object_keys(p))<>6
  or exists(select 1 from jsonb_each(p)where jsonb_typeof(value)<>'string')
  or coalesce(p->>'purchase_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p->>'review_token','')!~'^[a-f0-9]{32}$'
  or coalesce(p->>'amount','')!~'^(0|[1-9][0-9]{0,17})\.[0-9]{2}$'or(p->>'amount')::numeric<=0
  or coalesce(p->>'cash_account_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p->>'payment_date','')!~'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.[0-9]{1,6})?(Z|[+-]\d{2}:\d{2})$'
  or length(btrim(p->>'note'))not between 5 and 500 then
  raise exception 'CP7_SUPPLIER_PAYMENT_CREATE_FIELDS';end if;
 perform(p->>'payment_date')::timestamptz;
end $$;

-- One token over the complete Native receipt, its AP answer and every payment
-- row of that receipt, hashed in UTC. Any payment, reversal, credit or receipt
-- change in between retires the reviewed amount instead of paying twice.
create function cp7_supplier_payment_create.review(p_purchase uuid)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare h erp.material_purchase_headers;s erp.suppliers;ap jsonb;payments jsonb;
begin
 perform cp7_invoice.payment_access();
 select *into h from erp.material_purchase_headers where id=p_purchase;
 if h.id is null or h.supplier_id is null then raise exception 'CP7_SUPPLIER_PAYMENT_RECEIPT_NOT_FOUND';end if;
 select *into s from erp.suppliers where id=h.supplier_id;
 ap:=cp7_invoice.payment_ap(h.id);
 select coalesce(jsonb_agg(to_jsonb(p)order by p.id),'[]')into payments from erp.supplier_payments p where p.purchase_id=h.id;
 return jsonb_build_object('purchase',jsonb_build_object('id',h.id,'number',h.purchase_number,'status',h.status,'physical_at',h.physical_at,
   'supplier_id',s.id,'supplier_name',s.supplier_name),'Native_AP',ap,
  'eligible',h.status='POSTED'and ap is not null and coalesce((ap->>'remaining')::numeric,0)>0,
  'review_token',md5(jsonb_build_object('purchase',to_jsonb(h),'ap',ap,'payments',payments)::text));
end $$;

create function cp7_supplier_payment_create.workspace(p_query jsonb)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;r jsonb;q text;off integer;rows jsonb;total bigint;
begin
 a:=cp7_invoice.payment_access();
 if jsonb_typeof(p_query)is distinct from'object'or not(p_query?'purchase_id')
  or exists(select 1 from jsonb_object_keys(p_query)x where x not in('purchase_id','bank_q','bank_offset'))
  or jsonb_typeof(p_query->'purchase_id')is distinct from'string'or coalesce(p_query->>'purchase_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or(p_query?'bank_q'and jsonb_typeof(p_query->'bank_q')is distinct from'string')
  or(p_query?'bank_offset'and(jsonb_typeof(p_query->'bank_offset')is distinct from'number'or coalesce(p_query->>'bank_offset','')!~'^(0|[1-9][0-9]{0,6})$'))then
  raise exception 'CP7_SUPPLIER_PAYMENT_CREATE_QUERY';end if;
 q:=btrim(coalesce(p_query->>'bank_q',''));off:=coalesce((p_query->>'bank_offset')::integer,0);
 if length(q)>120 or off>1000000 then raise exception 'CP7_SUPPLIER_PAYMENT_CREATE_QUERY';end if;
 r:=cp7_supplier_payment_create.review((p_query->>'purchase_id')::uuid);
 select count(*)into total from erp.cash_accounts c join erp.chart_accounts ca on ca.id=c.coa_account_id
  where c.is_active and ca.is_active and ca.is_postable and(q=''or strpos(lower(c.cash_account_code||' '||c.cash_account_name),lower(q))>0);
 select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'code',c.cash_account_code,'name',c.cash_account_name,'kind',c.account_kind)order by c.cash_account_code,c.id),'[]')into rows
  from(select c.*from erp.cash_accounts c join erp.chart_accounts ca on ca.id=c.coa_account_id
   where c.is_active and ca.is_active and ca.is_postable and(q=''or strpos(lower(c.cash_account_code||' '||c.cash_account_name),lower(q))>0)
   order by c.cash_account_code,c.id limit 25 offset off)c;
 if cp7_invoice.payment_access()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 return r||jsonb_build_object('contract_version','cp7.supplier-payment-create-workspace.v1','captured_at',statement_timestamp(),
  'can_create',a->'reverse_payment','cash_accounts',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',25,
   'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows)else null end));
end $$;

create function cp7_supplier_payment_create.apply(p jsonb,p_request uuid)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;h erp.material_purchase_headers;r jsonb;payment uuid;after jsonb;at timestamptz;
begin
 a:=cp7_supplier_payment_create.access_now();perform cp7_supplier_payment_create.validate(p);
 if not exists(select 1 from cp7_supplier_payment_create.context where backend_pid=pg_backend_pid()and transaction_id=txid_current()
  and actor=auth.uid()and request_id=p_request and payload=p)then
  raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_CREATE_PRIVATE_CONTEXT_REQUIRED';end if;
 -- Same order as Native posting and the correction: payments, then receipt.
 perform 1 from erp.supplier_payments where purchase_id=(p->>'purchase_id')::uuid order by id for update;
 select *into h from erp.material_purchase_headers where id=(p->>'purchase_id')::uuid for update;
 if h.id is null then raise exception 'CP7_SUPPLIER_PAYMENT_RECEIPT_NOT_FOUND';end if;
 lock table erp.accounting_account_mappings in share mode;
 perform 1 from erp.cash_accounts where id=(p->>'cash_account_id')::uuid for share;
 perform 1 from erp.chart_accounts where id in(select coa_account_id from erp.cash_accounts where id=(p->>'cash_account_id')::uuid
  union select account_id from erp.accounting_account_mappings where mapping_key='AP_SUPPLIER')order by id for share;
 -- Locks may have waited: authority and the reviewed Native state are read again now.
 if cp7_supplier_payment_create.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 r:=cp7_supplier_payment_create.review(h.id);
 if r->>'review_token'is distinct from p->>'review_token'then raise exception 'CP7_SUPPLIER_PAYMENT_STALE_REVIEW';end if;
 if h.status<>'POSTED'or not(r->'eligible')::boolean then raise exception 'CP7_SUPPLIER_PAYMENT_NOTHING_PAYABLE';end if;
 if(p->>'amount')::numeric>(r->'Native_AP'->>'remaining')::numeric then raise exception 'CP7_SUPPLIER_PAYMENT_EXCEEDS_REMAINING';end if;
 if not exists(select 1 from erp.cash_accounts c join erp.chart_accounts ca on ca.id=c.coa_account_id
  where c.id=(p->>'cash_account_id')::uuid and c.is_active and ca.is_active and ca.is_postable)then raise exception 'CP7_SUPPLIER_PAYMENT_CASH_ACCOUNT_INACTIVE';end if;
 at:=(p->>'payment_date')::timestamptz;
 if at>statement_timestamp()then raise exception 'CP7_SUPPLIER_PAYMENT_DATE_FUTURE';end if;
 -- Money paid before the goods arrived is an advance, a different document.
 if at<h.physical_at then raise exception 'CP7_SUPPLIER_PAYMENT_BEFORE_RECEIPT';end if;
 insert into erp.supplier_payments(purchase_id,payment_number,payment_date,amount,cash_account_id,notes,status,created_by)
  values(h.id,'B-'||replace(p_request::text,'-',''),at,(p->>'amount')::numeric,(p->>'cash_account_id')::uuid,btrim(p->>'note'),'DRAFT',erp.current_app_user_id())
  returning id into payment;
 perform erp.post_supplier_payment(payment);
 if not exists(select 1 from erp.supplier_payments where id=payment and purchase_id=h.id and status='POSTED')
  or not exists(select 1 from erp.journal_entries where source_type='SUPPLIER_PAYMENT'and source_id=payment and status='POSTED')then
  raise exception 'CP7_SUPPLIER_PAYMENT_CREATE_POST_INCOMPLETE';end if;
 if cp7_supplier_payment_create.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 after:=cp7_invoice.payment_ap(h.id);
 return jsonb_build_object('contract_version','cp7.supplier-payment-create.v1','kind','COMMITTED_OUTCOME','action','CREATE',
  'request_id',p_request,'request_payload',p,'purchase_id',h.id,'payment_id',payment,'status','POSTED',
  'amount',(p->>'amount')::numeric(20,2)::text,'remaining_after',(after->>'remaining')::numeric(20,2)::text);
end $$;

create function cp7_supplier_payment_create.command(p jsonb,p_request uuid)returns jsonb
language plpgsql volatile security invoker set search_path=''as $$
declare a jsonb;saved cp7_supplier_payment_create.requests;r jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_supplier_payment_create.access_now();perform cp7_supplier_payment_create.validate(p);
 if p_request is null then raise exception 'CP7_SUPPLIER_PAYMENT_CREATE_FIELDS';end if;
 insert into cp7_supplier_payment_create.requests values(auth.uid(),p_request,p,null)on conflict do nothing;
 select *into saved from cp7_supplier_payment_create.requests where actor=auth.uid()and request_id=p_request for update;
 if cp7_supplier_payment_create.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 if saved.payload is distinct from p then raise exception 'CP7_SUPPLIER_PAYMENT_REQUEST_CHANGED';end if;
 if saved.response is not null then return saved.response;end if;
 insert into cp7_supplier_payment_create.context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,p);
 r:=cp7_supplier_payment_create.apply(p,p_request);
 delete from cp7_supplier_payment_create.context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_supplier_payment_create.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SUPPLIER_PAYMENT_ACCESS_CHANGED';end if;
 update cp7_supplier_payment_create.requests set response=r where actor=auth.uid()and request_id=p_request;return r;
end $$;

alter function cp7_supplier_payment_create.access_now()owner to cp7_invoice_read;
alter function cp7_supplier_payment_create.validate(jsonb)owner to cp7_invoice_read;
alter function cp7_supplier_payment_create.review(uuid)owner to postgres;
alter function cp7_supplier_payment_create.workspace(jsonb)owner to postgres;
alter function cp7_supplier_payment_create.apply(jsonb,uuid)owner to postgres;
alter function cp7_supplier_payment_create.command(jsonb,uuid)owner to cp7_invoice_write;
revoke all on all functions in schema cp7_supplier_payment_create from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_supplier_payment_create.access_now(),cp7_supplier_payment_create.validate(jsonb),cp7_supplier_payment_create.apply(jsonb,uuid)to cp7_invoice_write;
grant execute on function cp7_supplier_payment_create.access_now(),cp7_supplier_payment_create.validate(jsonb)to postgres;
grant execute on function cp7_supplier_payment_create.workspace(jsonb)to cp7_invoice_read;
revoke create on schema cp7_supplier_payment_create from cp7_invoice_write;
grant create on schema public to cp7_invoice_write,cp7_invoice_read;
create function public.erp_cp7_create_supplier_payment_v1(p_payload jsonb,p_request uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_supplier_payment_create.command(p_payload,p_request)$$;
create function public.erp_cp7_get_supplier_payment_create_v1(p_query jsonb)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_supplier_payment_create.workspace(p_query)$$;
alter function public.erp_cp7_create_supplier_payment_v1(jsonb,uuid)owner to cp7_invoice_write;
alter function public.erp_cp7_get_supplier_payment_create_v1(jsonb)owner to cp7_invoice_read;
revoke create on schema public from cp7_invoice_write,cp7_invoice_read;
revoke all on function public.erp_cp7_create_supplier_payment_v1(jsonb,uuid),public.erp_cp7_get_supplier_payment_create_v1(jsonb)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_create_supplier_payment_v1(jsonb,uuid),public.erp_cp7_get_supplier_payment_create_v1(jsonb)to authenticated;

create function cp7_supplier_return.location_qty(p_material uuid,p_roll uuid,p_location uuid) returns numeric
language sql stable security invoker set search_path='' as $$
 select case when p_location is null then null else coalesce(sum(qty_signed),0) end
 from erp.material_stock_movements where material_id=p_material and roll_id is not distinct from p_roll
 and location_id=p_location and physical_at<=statement_timestamp()
$$;
create function cp7_supplier_return.document(p_id uuid,p_purchase uuid,p_value boolean) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',h.id,'number',h.return_number,'supplier_id',h.supplier_id,'location_id',h.location_id,
  'location_name',loc.location_name,'physical_at',h.physical_at,'status',h.status,'row_version',h.row_version::text,'reason',h.reason,
  'line_count',(select count(*)::text from erp.material_supplier_return_items where return_id=h.id),
  'single_receipt',not exists(select 1 from erp.material_supplier_return_items r left join erp.material_purchase_items i on i.id=r.purchase_item_id where r.return_id=h.id and i.purchase_id is distinct from p_purchase),
  'lines',(select coalesce(jsonb_agg(jsonb_build_object('id',r.id,'purchase_item_id',r.purchase_item_id,'purchase_id',i.purchase_id,'purchase_number',ph.purchase_number,
   'material_id',r.material_id,'material_name',m.material_name,'unit_code',m.unit_code,'roll_id',r.roll_id,'roll_number',mr.roll_number,'qty',r.qty::text,'notes',r.notes)
   ||case when p_value then jsonb_build_object('finance',jsonb_build_object('credit_unit_price',r.supplier_credit_unit_price::text,
    'ap_relief_qty',r.ap_relief_qty_snapshot::text,'grni_relief_qty',r.grni_relief_qty_snapshot::text,
    'ap_relief_amount',r.ap_relief_amount_snapshot::text,'grni_relief_amount',r.grni_relief_amount_snapshot::text)) else '{}'::jsonb end order by r.id),'[]'::jsonb)
   from erp.material_supplier_return_items r left join erp.material_purchase_items i on i.id=r.purchase_item_id
   left join erp.material_purchase_headers ph on ph.id=i.purchase_id join erp.materials m on m.id=r.material_id left join erp.material_rolls mr on mr.id=r.roll_id where r.return_id=h.id))
  ||case when p_value then jsonb_build_object('finance',jsonb_build_object('basis','SOURCE_VALUATION_SNAPSHOTS_NOT_AVAILABLE_CREDIT',
   'ap_relief_amount',(select case when bool_and(ap_relief_amount_snapshot is not null) then sum(ap_relief_amount_snapshot)::text end from erp.material_supplier_return_items where return_id=h.id),
   'grni_relief_amount',(select case when bool_and(grni_relief_amount_snapshot is not null) then sum(grni_relief_amount_snapshot)::text end from erp.material_supplier_return_items where return_id=h.id))) else '{}'::jsonb end
 from erp.material_supplier_returns h left join erp.locations loc on loc.id=h.location_id where h.id=p_id
$$;
create function cp7_supplier_return.workspace(p_purchase uuid,p_location uuid,p_offset integer,p_limit integer) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;h erp.material_purchase_headers;items jsonb;docs jsonb;total bigint;selected_location jsonb;
begin
 a:=cp7_supplier_return.access_now();
 if p_purchase is null or p_offset is null or p_offset not between 0 and 1000000 or p_limit is null or p_limit not between 1 and 25 then raise exception 'CP7_RETURN_QUERY';end if;
 select * into h from erp.material_purchase_headers where id=p_purchase;if not found then raise exception 'CP7_RETURN_RECEIPT_NOT_FOUND';end if;
 p_location:=coalesce(p_location,h.location_id);
 if p_location is not null then
  select jsonb_build_object('id',l.id,'name',l.location_name,'available',l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE' and not exists(select 1 from erp.bc_accessory_zones_v1 z where z.location_id=l.id)) into selected_location from erp.locations l where l.id=p_location;
  if selected_location is null then raise exception 'CP7_RETURN_LOCATION_NOT_FOUND';end if;
 end if;
 if (select count(*) from erp.material_purchase_items where purchase_id=p_purchase)>100 or
  (select count(*) from erp.material_rolls r join erp.material_purchase_items i on i.id=r.purchase_item_id where i.purchase_id=p_purchase)>2000 then raise exception 'CP7_RETURN_COMPLETE_SOURCE_REQUIRED';end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'material_id',i.material_id,'material_name',m.material_name,'material_type',m.material_type,'material_active',m.is_active,'unit_code',m.unit_code,
  'receipt_qty',i.qty::text,'posted_return_qty',coalesce(q.qty,0)::text,'unreturned_qty',(i.qty-coalesce(q.qty,0))::text,
  'location_qty',case when m.material_type<>'FABRIC' then cp7_supplier_return.location_qty(i.material_id,null,p_location)::text end,
  'rolls',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'number',r.roll_number,'receipt_qty',r.original_qty::text,
    'location_qty',cp7_supplier_return.location_qty(i.material_id,r.id,p_location)::text) order by r.roll_number,r.id) from erp.material_rolls r where r.purchase_item_id=i.id),'[]'::jsonb)) order by i.id),'[]'::jsonb)
 into items from erp.material_purchase_items i join erp.materials m on m.id=i.material_id
 left join lateral(select sum(ri.qty) qty from erp.material_supplier_return_items ri join erp.material_supplier_returns rh on rh.id=ri.return_id where ri.purchase_item_id=i.id and rh.status='POSTED') q on true
 where i.purchase_id=p_purchase;
 select count(*) into total from erp.material_supplier_returns rh where exists(select 1 from erp.material_supplier_return_items r join erp.material_purchase_items i on i.id=r.purchase_item_id where r.return_id=rh.id and i.purchase_id=p_purchase);
 if exists(select 1 from (select rh.id from erp.material_supplier_returns rh where exists(select 1 from erp.material_supplier_return_items r join erp.material_purchase_items i on i.id=r.purchase_item_id where r.return_id=rh.id and i.purchase_id=p_purchase) order by rh.physical_at desc,rh.id limit p_limit offset p_offset) selected
  where (select count(*) from erp.material_supplier_return_items where return_id=selected.id)>100) then raise exception 'CP7_RETURN_COMPLETE_DOCUMENT_REQUIRED';end if;
 select coalesce(jsonb_agg(cp7_supplier_return.document(rh.id,p_purchase,(a->>'view_value')::boolean) order by rh.physical_at desc,rh.id),'[]'::jsonb) into docs
 from (select rh.* from erp.material_supplier_returns rh where exists(select 1 from erp.material_supplier_return_items r join erp.material_purchase_items i on i.id=r.purchase_item_id where r.return_id=rh.id and i.purchase_id=p_purchase) order by rh.physical_at desc,rh.id limit p_limit offset p_offset) rh;
 return jsonb_build_object('contract_version','cp7.supplier-returns.v1','read_at',statement_timestamp(),'purchase_id',p_purchase,'purchase_number',h.purchase_number,'purchase_status',h.status,'purchase_version',h.row_version::text,
  'supplier_id',h.supplier_id,'receipt_location_id',h.location_id,'selected_location',selected_location,'basis','CURRENT_POSTED_STOCK_AND_SOURCE_RETURN_DOCUMENTS',
  'financial_captured',a->'view_value','capabilities',jsonb_build_object('create',a->'create','post',a->'post','reverse',a->'reverse'),
  'source_line_count',jsonb_array_length(items)::text,'source_lines',items,
  'page',jsonb_build_object('rows',docs,'total',total::text,'offset',p_offset,'limit',p_limit,'next_offset',case when p_offset+jsonb_array_length(docs)<total then p_offset+jsonb_array_length(docs) else null end));
end $$;
create function public.erp_cp7_get_supplier_returns_v1(p_purchase uuid,p_location uuid,p_offset integer,p_limit integer) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_supplier_return.workspace(p_purchase,p_location,p_offset,p_limit)$$;

-- Complete same-supplier return documents. Native source valuation, stock
-- capacity, payment dependency and credit allocation remain authoritative.
create function cp7_supplier_return.sources(p_purchase uuid,p_q text,p_offset integer,p_limit integer) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare h erp.material_purchase_headers;term text;total bigint;rows jsonb;
begin
 perform cp7_supplier_return.access_now();term:=btrim(coalesce(p_q,''));
 if p_purchase is null or length(term)>120 or p_offset is null or p_offset not between 0 and 1000000 or p_limit is null or p_limit not between 1 and 25 then raise exception 'CP7_RETURN_QUERY';end if;
 select * into h from erp.material_purchase_headers where id=p_purchase;
 if not found or h.supplier_id is null then raise exception 'CP7_RETURN_RECEIPT_NOT_FOUND';end if;
 select count(*) into total from erp.material_purchase_headers ph where ph.supplier_id=h.supplier_id and ph.status='POSTED' and (term='' or strpos(lower(ph.purchase_number),lower(term))>0);
 select coalesce(jsonb_agg(jsonb_build_object('id',ph.id,'number',ph.purchase_number,'physical_at',ph.physical_at,'row_version',ph.row_version::text) order by ph.physical_at desc,ph.id),'[]'::jsonb) into rows
 from(select x.* from erp.material_purchase_headers x where x.supplier_id=h.supplier_id and x.status='POSTED' and (term='' or strpos(lower(x.purchase_number),lower(term))>0) order by x.physical_at desc,x.id limit p_limit offset p_offset) ph;
 return jsonb_build_object('contract_version','cp7.return-sources.v1','read_at',statement_timestamp(),'purchase_id',p_purchase,'supplier_id',h.supplier_id,
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',p_offset,'limit',p_limit,'next_offset',case when p_offset+jsonb_array_length(rows)<total then p_offset+jsonb_array_length(rows) else null end));
end $$;
create function public.erp_cp7_get_supplier_return_sources_v1(p_purchase uuid,p_q text,p_offset integer,p_limit integer) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_supplier_return.sources(p_purchase,p_q,p_offset,p_limit)$$;

create function cp7_supplier_return.validate_sources(p_purchase uuid,p_payload jsonb) returns void
language plpgsql stable security definer set search_path='' as $$
declare matched integer;anchored boolean;g record;
begin
 perform cp7_supplier_return.access_now();
 if jsonb_typeof(p_payload->'items') is distinct from 'array' or jsonb_array_length(p_payload->'items') not between 1 and 100 then raise exception 'CP7_RETURN_LINES';end if;
 select count(*),bool_or(ph.id=p_purchase) into matched,anchored from jsonb_array_elements(p_payload->'items') l
 join erp.material_purchase_items i on i.id=(l->>'purchase_item_id')::uuid join erp.material_purchase_headers ph on ph.id=i.purchase_id
 where ph.status='POSTED' and ph.supplier_id=(p_payload->>'supplier_id')::uuid;
 if matched<>jsonb_array_length(p_payload->'items') or anchored is distinct from true then raise exception 'CP7_RETURN_SAME_SUPPLIER_POSTED_RECEIPTS_REQUIRED';end if;
 -- Reuse the complete exact quantity/material/roll contract for each source.
 for g in select i.purchase_id,jsonb_agg(l order by n) items from jsonb_array_elements(p_payload->'items') with ordinality x(l,n)
  join erp.material_purchase_items i on i.id=(l->>'purchase_item_id')::uuid group by i.purchase_id order by i.purchase_id loop
  perform cp7_supplier_return.validate_source(g.purchase_id,p_payload||jsonb_build_object('items',g.items));
 end loop;
end $$;

create function cp7_supplier_return.assert_complete_document(p_purchase uuid,p_return uuid,p_reviewed jsonb) returns void
language plpgsql stable security definer set search_path='' as $$
declare ids jsonb;n integer;
begin
 perform cp7_supplier_return.access_now();
 if jsonb_typeof(p_reviewed) is distinct from 'array' or jsonb_array_length(p_reviewed) not between 1 and 100
  or exists(select 1 from jsonb_array_elements(p_reviewed) x where jsonb_typeof(x)<>'string') then raise exception 'CP7_RETURN_COMPLETE_DOCUMENT_REQUIRED';end if;
 select count(*),jsonb_agg(distinct i.purchase_id::text order by i.purchase_id::text) into n,ids
 from erp.material_supplier_return_items l left join erp.material_purchase_items i on i.id=l.purchase_item_id where l.return_id=p_return;
 if n not between 1 and 100 or ids is null or not ids ? p_purchase::text
  or ids is distinct from(select jsonb_agg(x order by x) from jsonb_array_elements(p_reviewed) x)
  or exists(select 1 from erp.material_supplier_return_items l left join erp.material_purchase_items i on i.id=l.purchase_item_id
   left join erp.material_purchase_headers ph on ph.id=i.purchase_id join erp.material_supplier_returns rh on rh.id=l.return_id
   where rh.id=p_return and (i.id is null or ph.supplier_id is distinct from rh.supplier_id)) then raise exception 'CP7_RETURN_COMPLETE_DOCUMENT_REQUIRED';end if;
end $$;

create function cp7_supplier_return.validate_document_post(p_return uuid) returns void
language plpgsql stable security definer set search_path='' as $$
begin
 perform cp7_supplier_return.access_now();
 if not exists(select 1 from erp.material_supplier_returns h join erp.locations l on l.id=h.location_id where h.id=p_return and l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE'
  and not exists(select 1 from erp.bc_accessory_zones_v1 z where z.location_id=l.id)) then raise exception 'CP7_RETURN_ACTIVE_WAREHOUSE_REQUIRED';end if;
 if exists(select 1 from erp.material_supplier_return_items r join erp.materials m on m.id=r.material_id where r.return_id=p_return and not m.is_active) then raise exception 'CP7_RETURN_ACTIVE_MATERIAL_REQUIRED';end if;
end $$;

create function cp7_supplier_return.document_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;r jsonb;pid uuid;ident uuid;expected bigint;kind text;permission_key text;old cp7_supplier_return.requests;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_supplier_return.access_now();
 if p_action is null or p_action not in('SAVE_DOCUMENT','POST_DOCUMENT','REVERSE_DOCUMENT') or p_request is null then raise exception 'CP7_RETURN_ACTION';end if;
 kind:=replace(p_action,'_DOCUMENT','');
 if a->(case kind when 'SAVE' then 'create' when 'POST' then 'post' else 'reverse' end) is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_RETURN_ACTION_DENIED';end if;
 if p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_RETURN_VERSION';end if;expected:=p_expected::bigint;
 if jsonb_typeof(p_payload) is distinct from 'object' or jsonb_typeof(p_payload->'purchase_id') is distinct from 'string' then raise exception 'CP7_RETURN_FIELDS';end if;
 insert into cp7_supplier_return.requests values(auth.uid(),p_request,p_action,p_payload,p_expected,null) on conflict do nothing;
 select * into old from cp7_supplier_return.requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_RETURN_REQUEST_PAYLOAD_CHANGED';end if;
 if cp7_supplier_return.access_now()<>a then raise exception using errcode='42501',message='CP7_RETURN_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 pid:=(p_payload->>'purchase_id')::uuid;
 if kind='SAVE' then
  if not p_payload ?& array['purchase_id','return_number','supplier_id','location_id','physical_at','change_reason','items'] or exists(select 1 from jsonb_each(p_payload) e
   where e.key not in('purchase_id','id','return_number','supplier_id','location_id','physical_at','change_reason','reason','items') or(e.key<>'items' and jsonb_typeof(e.value) not in('string','null'))) then raise exception 'CP7_RETURN_FIELDS';end if;
  if exists(select 1 from unnest(array['purchase_id','return_number','supplier_id','location_id','physical_at','change_reason']) k where jsonb_typeof(p_payload->k) is distinct from 'string' or nullif(btrim(p_payload->>k),'') is null) then raise exception 'CP7_RETURN_FIELDS';end if;
  if (p_payload->>'id' is null and expected is not null) or (p_payload->>'id' is not null and expected is null) then raise exception 'CP7_RETURN_VERSION';end if;
  perform cp7_supplier_return.validate_sources(pid,p_payload);
 else
  if expected is null or not p_payload ?& array['purchase_id','return_id','change_reason','reviewed_purchase_ids'] or exists(select 1 from jsonb_each(p_payload) e
   where e.key not in('purchase_id','return_id','change_reason','reviewed_purchase_ids') or(e.key<>'reviewed_purchase_ids' and jsonb_typeof(e.value)<>'string')) then raise exception 'CP7_RETURN_FIELDS';end if;
  ident:=(p_payload->>'return_id')::uuid;
  perform cp7_supplier_return.assert_complete_document(pid,ident,p_payload->'reviewed_purchase_ids');
  if kind='POST' then perform cp7_supplier_return.validate_document_post(ident);end if;
 end if;
 permission_key:=case kind when 'SAVE' then 'warehouse.procurement.create' else 'warehouse.procurement.reverse' end;
 insert into cp7_supplier_return.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),kind,permission_key);
 if kind='SAVE' then
  r:=erp.save_material_supplier_return_draft_v2(p_payload-'purchase_id',p_request,expected);
  perform cp7_supplier_return.validate_sources(pid,p_payload);
 elsif kind='POST' then r:=erp.post_material_supplier_return_v2(ident,p_request,expected,p_payload->>'change_reason');
 else r:=erp.reverse_material_supplier_return_v2(ident,p_payload->>'change_reason',p_request,expected);end if;
 if cp7_supplier_return.access_now()<>a then raise exception using errcode='42501',message='CP7_RETURN_ACCESS_CHANGED';end if;
 if kind<>'SAVE' then perform cp7_supplier_return.assert_complete_document(pid,ident,p_payload->'reviewed_purchase_ids');end if;
 if kind='POST' then perform cp7_supplier_return.validate_document_post(ident);end if;
 delete from cp7_supplier_return.execution_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
 r:=jsonb_build_object('contract_version','cp7.supplier-return-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'purchase_id',pid,
  'return_id',r->'material_supplier_return_id','row_version',r->>'row_version','status',r->>'status');
 update cp7_supplier_return.requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;

create function cp7_supplier_return.command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;z jsonb;r jsonb;pid uuid;expected bigint;permission_key text;capability text;cached cp7_supplier_return.requests;
begin
 if p_action in('SAVE_DOCUMENT','POST_DOCUMENT','REVERSE_DOCUMENT') then return cp7_supplier_return.document_command(p_action,p_payload,p_request,p_expected);end if;
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_supplier_return.access_now();
 if p_action is null or p_action not in('SAVE','POST','REVERSE') or p_request is null then raise exception 'CP7_RETURN_ACTION';end if;
 if jsonb_typeof(p_payload) is distinct from 'object' or jsonb_typeof(p_payload->'purchase_id') is distinct from 'string' then raise exception 'CP7_RETURN_FIELDS';end if;
 pid:=(p_payload->>'purchase_id')::uuid;
 if p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_RETURN_VERSION';end if;expected:=p_expected::bigint;
 capability:=case p_action when 'SAVE' then 'create' when 'POST' then 'post' else 'reverse' end;
 permission_key:=case p_action when 'SAVE' then 'warehouse.procurement.create' else 'warehouse.procurement.reverse' end;
 if a->capability is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_RETURN_ACTION_DENIED';end if;
 insert into cp7_supplier_return.requests(actor,request_id,action,payload,expected_version) values(auth.uid(),p_request,p_action,p_payload,p_expected) on conflict do nothing;
 select * into cached from cp7_supplier_return.requests where actor=auth.uid() and request_id=p_request for update;
 if cached.action<>p_action or cached.payload<>p_payload or cached.expected_version is distinct from p_expected then raise exception 'CP7_RETURN_REQUEST_PAYLOAD_CHANGED';end if;
 z:=cp7_supplier_return.access_now();if z<>a then raise exception using errcode='42501',message='CP7_RETURN_ACCESS_CHANGED';end if;
 if cached.response is not null then return cached.response;end if;
 if p_action='SAVE' then
  if not p_payload ?& array['purchase_id','return_number','supplier_id','location_id','physical_at','change_reason','items'] or exists(select 1 from jsonb_each(p_payload) e where e.key not in('purchase_id','id','return_number','supplier_id','location_id','physical_at','change_reason','reason','items') or (e.key<>'items' and jsonb_typeof(e.value) not in('string','null'))) then raise exception 'CP7_RETURN_FIELDS';end if;
  if exists(select 1 from unnest(array['purchase_id','return_number','supplier_id','location_id','physical_at','change_reason']) k where jsonb_typeof(p_payload->k) is distinct from 'string' or nullif(btrim(p_payload->>k),'') is null) then raise exception 'CP7_RETURN_FIELDS';end if;
  if p_payload->>'id' is not null then perform cp7_supplier_return.assert_document(pid,(p_payload->>'id')::uuid);end if;
  perform cp7_supplier_return.validate_source(pid,p_payload);
 else
  if p_expected is null or not p_payload ?& array['purchase_id','return_id','change_reason'] or exists(select 1 from jsonb_each(p_payload) e where e.key not in('purchase_id','return_id','change_reason') or jsonb_typeof(e.value)<>'string') then raise exception 'CP7_RETURN_FIELDS';end if;
  perform cp7_supplier_return.assert_document(pid,(p_payload->>'return_id')::uuid);
  if p_action='POST' then perform cp7_supplier_return.validate_post(pid,(p_payload->>'return_id')::uuid);end if;
 end if;
 insert into cp7_supplier_return.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),p_action,permission_key);
 if p_action='SAVE' then r:=erp.save_material_supplier_return_draft_v2(p_payload-'purchase_id',p_request,expected);
 elsif p_action='POST' then r:=erp.post_material_supplier_return_v2((p_payload->>'return_id')::uuid,p_request,expected,p_payload->>'change_reason');
 else r:=erp.reverse_material_supplier_return_v2((p_payload->>'return_id')::uuid,p_payload->>'change_reason',p_request,expected);end if;
 z:=cp7_supplier_return.access_now();if z<>a then raise exception using errcode='42501',message='CP7_RETURN_ACCESS_CHANGED';end if;
 if p_action='POST' then perform cp7_supplier_return.validate_post(pid,(p_payload->>'return_id')::uuid);end if;
 delete from cp7_supplier_return.execution_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
 r:=jsonb_build_object('contract_version','cp7.supplier-return-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'purchase_id',pid,
  'return_id',r->'material_supplier_return_id','row_version',r->>'row_version','status',r->>'status');
 update cp7_supplier_return.requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;
create function public.erp_cp7_save_supplier_return_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_supplier_return.command(p_action,p_payload,p_request,p_expected)$$;

grant create on schema public,cp7_supplier_return to cp7_return_read,cp7_return_write;
alter function cp7_supplier_return.access_now() owner to cp7_return_read;
alter function cp7_supplier_return.validate_source(uuid,jsonb) owner to cp7_return_read;
alter function cp7_supplier_return.assert_document(uuid,uuid) owner to cp7_return_read;
alter function cp7_supplier_return.validate_post(uuid,uuid) owner to cp7_return_read;
alter function cp7_supplier_return.location_qty(uuid,uuid,uuid) owner to cp7_return_read;
alter function cp7_supplier_return.document(uuid,uuid,boolean) owner to cp7_return_read;
alter function cp7_supplier_return.workspace(uuid,uuid,integer,integer) owner to cp7_return_read;
alter function cp7_supplier_return.sources(uuid,text,integer,integer) owner to cp7_return_read;
alter function cp7_supplier_return.validate_sources(uuid,jsonb) owner to cp7_return_read;
alter function cp7_supplier_return.assert_complete_document(uuid,uuid,jsonb) owner to cp7_return_read;
alter function cp7_supplier_return.validate_document_post(uuid) owner to cp7_return_read;
alter function cp7_supplier_return.document_command(text,jsonb,uuid,text) owner to cp7_return_write;
alter function cp7_supplier_return.command(text,jsonb,uuid,text) owner to cp7_return_write;
alter function public.erp_cp7_get_supplier_return_sources_v1(uuid,text,integer,integer) owner to cp7_return_read;
alter function public.erp_cp7_get_supplier_returns_v1(uuid,uuid,integer,integer) owner to cp7_return_read;
alter function public.erp_cp7_save_supplier_return_v1(text,jsonb,uuid,text) owner to cp7_return_write;
revoke create on schema public,cp7_supplier_return from cp7_return_read,cp7_return_write;
revoke all on all functions in schema cp7_supplier_return from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_supplier_return.access_now(),cp7_supplier_return.validate_source(uuid,jsonb),cp7_supplier_return.assert_document(uuid,uuid),cp7_supplier_return.validate_post(uuid,uuid) to cp7_return_write;
grant execute on function cp7_supplier_return.validate_sources(uuid,jsonb),cp7_supplier_return.assert_complete_document(uuid,uuid,jsonb),cp7_supplier_return.validate_document_post(uuid) to cp7_return_write;
revoke all on function public.erp_cp7_get_supplier_return_sources_v1(uuid,text,integer,integer) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_supplier_return_sources_v1(uuid,text,integer,integer) to authenticated;
revoke all on function public.erp_cp7_get_supplier_returns_v1(uuid,uuid,integer,integer),public.erp_cp7_save_supplier_return_v1(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_supplier_returns_v1(uuid,uuid,integer,integer),public.erp_cp7_save_supplier_return_v1(text,jsonb,uuid,text) to authenticated;

-- CP7 current-authority admission only. The accepted release files retain
-- their bytes; Native balances, credit moves, journals, stock, HPP, actors,
-- UUID replay payloads, owners and ACLs retain their original rules.
-- Recheck after request/source/target waits and after all Native writes so a
-- later accounting lock cannot commit under a permission revoked meanwhile.
do $credit_guard$ begin
 if encode(extensions.digest(pg_get_functiondef('public.erp_save_supplier_credit_v1(jsonb,uuid)'::regprocedure),'sha256'),'hex')<>'26d6a5024fe1caf7b50a5f9b516d454baeaf94353ee84f90f454d7bcd6a4624c' then raise exception 'CP7_SUPPLIER_CREDIT_PREDECESSOR_CHANGED';end if;
 if encode(extensions.digest(pg_get_functiondef('erp.bf_supplier_credit_allocate_v1(jsonb,uuid)'::regprocedure),'sha256'),'hex')<>'9f3e2c02b022f2288d4ffcf8c21a1da07783e82cf11c6da5484189282daa8db0' then raise exception 'CP7_SUPPLIER_CREDIT_PREDECESSOR_CHANGED';end if;
end $credit_guard$;

CREATE OR REPLACE FUNCTION public.erp_save_supplier_credit_v1(p_payload jsonb, p_client_request_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare prior erp.bf_requests_v1%rowtype;result jsonb;actor uuid;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception using errcode='25000',message='CP7_SUPPLIER_CREDIT_READ_COMMITTED_REQUIRED';end if;
 perform erp.require_owner_admin();perform erp.require_permission('finance.ap.pay');actor:=erp.current_app_user_id();
 if p_client_request_id is null then raise exception 'CLIENT_REQUEST_ID_REQUIRED';end if;
 perform pg_advisory_xact_lock(hashtextextended('BF:REQUEST:'||p_client_request_id,0));
 perform erp.require_owner_admin();perform erp.require_permission('finance.ap.pay');
 select * into prior from erp.bf_requests_v1 where request_id=p_client_request_id;
 if found then
   if prior.action<>'SUPPLIER_CREDIT_ALLOCATE' or prior.actor is distinct from actor or prior.payload is distinct from p_payload then
     raise exception 'CLIENT_REQUEST_ID_CONFLICT';end if;
   return prior.response||jsonb_build_object('replayed',true);
 end if;
 result:=erp.bf_supplier_credit_allocate_v1(p_payload,p_client_request_id)||jsonb_build_object('request_id',p_client_request_id,'replayed',false);
 insert into erp.bf_requests_v1 values(p_client_request_id,actor,'SUPPLIER_CREDIT_ALLOCATE',p_payload,result);
 perform erp.require_owner_admin();perform erp.require_permission('finance.ap.pay');
 return result;
end;$function$
;

CREATE OR REPLACE FUNCTION erp.bf_supplier_credit_allocate_v1(p_payload jsonb, p_request uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare h erp.material_supplier_returns%rowtype; src uuid; reason text; today date:=erp.bb_business_today_v1();
 targets uuid[]; affected uuid[]; item jsonb; target uuid; amount numeric; total numeric:=0; credit numeric;
 row_move erp.bf_supplier_credit_moves_v1%rowtype; event_id uuid; journal uuid; amount_paid numeric; payable numeric;
begin
 perform erp._cp3_assert_closed_json_object(p_payload,array['return_id','source_purchase_id','expected_version','allocations','reason'],
   array['return_id','source_purchase_id','expected_version','allocations','reason'],'supplier credit allocation');
 src:=erp.bd_uuid_v1(p_payload,'source_purchase_id',true);reason:=erp.bc_text_v1(p_payload,'reason',true,1000);
 select * into h from erp.material_supplier_returns where id=erp.bd_uuid_v1(p_payload,'return_id',true) for update;
 perform erp.require_owner_admin();perform erp.require_permission('finance.ap.pay');
 if h.id is null or h.status<>'POSTED' then raise exception 'BF_CREDIT_RETURN_NOT_POSTED';end if;
 if erp._cp3_business_date(h.physical_at)>today then raise exception 'BF_CREDIT_NOT_YET_AVAILABLE';end if;
 if p_payload->>'expected_version' is distinct from erp.bf_supplier_credit_revision_v1(h.id) then raise exception 'STALE_VERSION';end if;
 if jsonb_typeof(p_payload->'allocations') is distinct from 'array' or jsonb_array_length(p_payload->'allocations')>100 then
   raise exception 'BF_CREDIT_ALLOCATIONS_INVALID';end if;
 targets:=array[src];
 for item in select value from jsonb_array_elements(p_payload->'allocations') loop
   perform erp._cp3_assert_closed_json_object(item,array['purchase_id','amount'],array['purchase_id','amount'],'credit target');
   target:=erp.bd_uuid_v1(item,'purchase_id',true);amount:=erp.bd_amount_v1(item->'amount','amount',false);
   if amount<=0 or amount<>round(amount,2) or target=any(targets) then raise exception 'BF_CREDIT_TARGET_INVALID';end if;
   total:=total+amount;targets:=targets||target;
 end loop;
 select array_agg(distinct x order by x) into affected from(
   select unnest(targets) x union select e.target_purchase_id from erp.bf_supplier_credit_moves_v1 e
     where e.return_id=h.id and e.source_purchase_id=src
     group by e.target_purchase_id having sum(e.amount)<>0) ids;
 perform 1 from erp.material_purchase_headers where id=any(affected) order by id for update;
 perform erp.require_owner_admin();perform erp.require_permission('finance.ap.pay');
 if (select count(*) from erp.material_purchase_headers where id=any(affected) and supplier_id=h.supplier_id
     and status='POSTED' and erp._cp3_business_date(physical_at)<=today)<>cardinality(affected) then
   raise exception 'BF_CREDIT_SAME_SUPPLIER_REQUIRED';end if;
 credit:=erp.bf_supplier_credit_source_v1(h.id,src);
 if credit is null or credit<=0 or total>credit then raise exception 'BF_CREDIT_EXCEEDS_RETURN';end if;
 -- Append inverses first; the following desired allocation is one transaction.
 for row_move in select e.* from erp.bf_supplier_credit_moves_v1 e where e.return_id=h.id and e.source_purchase_id=src and e.amount>0
   and not exists(select 1 from erp.bf_supplier_credit_moves_v1 undo where undo.reversal_of=e.id) order by e.id loop
   event_id:=gen_random_uuid();
   journal:=erp.post_journal('BF_SUPPLIER_CREDIT_MOVE',event_id,today,reason,
     jsonb_build_array(jsonb_build_object('mapping_key','AP_SUPPLIER','debit',row_move.amount,'credit',0),
       jsonb_build_object('mapping_key','AP_SUPPLIER','debit',0,'credit',row_move.amount)));
   insert into erp.bf_supplier_credit_moves_v1(id,return_id,source_purchase_id,target_purchase_id,amount,effective_date,reversal_of,reason,actor,request_id,journal_id)
     values(event_id,h.id,src,row_move.target_purchase_id,-row_move.amount,today,row_move.id,reason,erp.current_app_user_id(),p_request,journal);
 end loop;
 for item in select value from jsonb_array_elements(p_payload->'allocations') loop
   target:=(item->>'purchase_id')::uuid;amount:=(item->>'amount')::numeric;event_id:=gen_random_uuid();
   journal:=erp.post_journal('BF_SUPPLIER_CREDIT_MOVE',event_id,today,reason,
     jsonb_build_array(jsonb_build_object('mapping_key','AP_SUPPLIER','debit',amount,'credit',0),
       jsonb_build_object('mapping_key','AP_SUPPLIER','debit',0,'credit',amount)));
   insert into erp.bf_supplier_credit_moves_v1(id,return_id,source_purchase_id,target_purchase_id,amount,effective_date,reason,actor,request_id,journal_id)
     values(event_id,h.id,src,target,amount,today,reason,erp.current_app_user_id(),p_request,journal);
 end loop;
 foreach target in array affected loop
   select round(erp.material_purchase_final_ap_total(target),2),coalesce((select sum(p.amount) from erp.supplier_payments p
     where p.purchase_id=target and p.status='POSTED'),0) into payable,amount_paid;
   if payable<amount_paid then raise exception 'BF_CREDIT_TARGET_ALREADY_PAID: alokasi melewati sisa utang atau kredit sudah dipakai pembayaran';end if;
   update erp.material_purchase_headers set payment_status=case when amount_paid=payable then 'PAID' when amount_paid>0 then 'PARTIAL' else 'UNPAID' end where id=target;
 end loop;
 return jsonb_build_object('return_id',h.id,'source_purchase_id',src,'version',erp.bf_supplier_credit_revision_v1(h.id),
   'credit',credit::numeric(20,2)::text,'original_purchase_credit',(credit-total)::numeric(20,2)::text,'allocated_elsewhere',total::numeric(20,2)::text,'effective_date',today);
end;$function$
;

-- Owning correction of a posted material receipt ("Benerin penerimaan").
-- The posted receipt, its lines, rolls and stock/journal facts stay immutable
-- history: the receipt is reversed at its own physical time and an exact
-- replacement document takes its place at that same time. Rolls of the same
-- material keep their identity (cutting, transfers and cards keep pointing at
-- the same physical roll); a roll recorded under the wrong material moves its
-- cutting use, at each use's own time, to a roll of the right material.
-- Every stock, cost, HPP and journal effect uses accepted Native writers in
-- this one transaction. No Native definition, owner or ACL is changed.
create schema cp7_receipt_fix authorization cp7_procure_write;
revoke all on schema cp7_receipt_fix from public,anon,authenticated,service_role,cp7_capture;
create table cp7_receipt_fix.requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,expected_version text not null,
 response jsonb,primary key(actor,request_id)
);
create table cp7_receipt_fix.revisions(
 id uuid primary key default gen_random_uuid(),
 root_purchase_id uuid not null references erp.material_purchase_headers,
 previous_purchase_id uuid not null unique references erp.material_purchase_headers,
 replacement_purchase_id uuid not null unique references erp.material_purchase_headers,
 revision bigint not null,actor uuid not null,request_id uuid not null,reason text not null,
 effective_at timestamptz not null,recorded_at timestamptz not null default clock_timestamp(),
 previous_document jsonb not null,corrected_document jsonb not null,
 unique(root_purchase_id,revision),unique(actor,request_id)
);
-- Physical roll lineage. REPARENTED keeps the roll id; MATERIAL_MOVED links the
-- wrong-material roll to its right-material successor; REMOVED/ADDED close and
-- open rolls that the corrected document does (not) contain.
create table cp7_receipt_fix.roll_lineage(
 correction_id uuid not null references cp7_receipt_fix.revisions(id) deferrable initially deferred,
 kind text not null check(kind in('REPARENTED','MATERIAL_MOVED','REMOVED','ADDED')),
 old_roll_id uuid references erp.material_rolls,new_roll_id uuid references erp.material_rolls,
 old_material_id uuid references erp.materials,new_material_id uuid references erp.materials,
 old_purchase_item_id uuid references erp.material_purchase_items,new_purchase_item_id uuid references erp.material_purchase_items,
 old_qty numeric(18,6),new_qty numeric(18,6),roll_number text not null,previous_roll_number text,
 recorded_at timestamptz not null default clock_timestamp(),
 check((kind='ADDED')=(old_roll_id is null)),check((kind='REMOVED')=(new_roll_id is null))
);
create index receipt_fix_roll_old on cp7_receipt_fix.roll_lineage(old_roll_id);
create index receipt_fix_roll_new on cp7_receipt_fix.roll_lineage(new_roll_id);
-- A cutting use recorded against a wrong-material roll keeps its single row,
-- quantity, physical/recorded time, cost basis and cutting source. Only its
-- material/roll attribute follows the corrected roll; the prior attribute is
-- kept here. (A reverse-and-reissue pair would be counted twice by the frozen
-- per-PO WIP conservation check, or dropped by the frozen HPP rebuild.)
create table cp7_receipt_fix.movement_lineage(
 movement_id uuid not null references erp.material_stock_movements,
 correction_id uuid not null references cp7_receipt_fix.revisions(id) deferrable initially deferred,
 old_material_id uuid not null references erp.materials,old_roll_id uuid not null references erp.material_rolls,
 new_material_id uuid not null references erp.materials,new_roll_id uuid not null references erp.material_rolls,
 qty_signed numeric(18,6) not null,physical_at timestamptz not null,source_type text not null,source_id uuid not null,
 recorded_at timestamptz not null default clock_timestamp(),primary key(movement_id,correction_id)
);
create table cp7_receipt_fix.journal_restatements(
 inverse_journal_id uuid primary key references erp.journal_entries,
 source_journal_id uuid not null unique references erp.journal_entries,
 previous_purchase_id uuid not null references erp.material_purchase_headers,
 neutral_journal_id uuid not null unique references erp.journal_entries,
 effective_journal_id uuid not null unique references erp.journal_entries,
 native_economic_date date not null,corrected_economic_date date not null,
 recorded_at timestamptz not null default clock_timestamp()
);
-- Every real supplier payment is replayed at its own date, cash account and
-- amount. A payment larger than the corrected payable is split: the corrected
-- receipt first, the excess as supplier credit on other receipts of the same
-- supplier chosen by the owner (owner decision 2 Oct 2026: "retur bayangan",
-- goods never received; the credit is cut from any next nota).
create table cp7_receipt_fix.payment_replays(
 replacement_payment_id uuid primary key references erp.supplier_payments,
 previous_payment_id uuid not null references erp.supplier_payments,
 correction_id uuid not null references cp7_receipt_fix.revisions(id) deferrable initially deferred,
 target_purchase_id uuid not null references erp.material_purchase_headers,
 kind text not null check(kind in('CORRECTED_RECEIPT','CREDIT_TO_OTHER_RECEIPT','SHARED_INVOICE_RECEIPT')),
 amount numeric(20,2) not null check(amount>0),
 recorded_at timestamptz not null default clock_timestamp()
);
create index receipt_fix_payment_previous on cp7_receipt_fix.payment_replays(previous_payment_id);
-- Main material card grouping: each compensating receipt movement is shown
-- under the original receipt row it corrects (effective quantity), while the
-- raw immutable rows stay available as audit members.
create table cp7_receipt_fix.ledger_links(
 member_id uuid primary key references erp.material_stock_movements,
 origin_id uuid not null references erp.material_stock_movements,
 correction_id uuid not null references cp7_receipt_fix.revisions(id) deferrable initially deferred,
 recorded_at timestamptz not null default clock_timestamp()
);
create index receipt_fix_ledger_origin on cp7_receipt_fix.ledger_links(origin_id);
-- A supplier invoice of the corrected receipt is reversed by the Native writer
-- and posted again, with the corrected lines, at its own invoice/book date.
create table cp7_receipt_fix.invoice_replays(
 previous_invoice_id uuid primary key references erp.material_supplier_invoices,
 replacement_invoice_id uuid not null unique references erp.material_supplier_invoices,
 correction_id uuid not null references cp7_receipt_fix.revisions(id) deferrable initially deferred,
 previous_lines jsonb not null,corrected_lines jsonb not null,
 recorded_at timestamptz not null default clock_timestamp()
);
-- The Native invoice reversal is dated today. Its exact effect is moved, per
-- account/dimension, to the dates the same invoice posts on at its own book
-- date under the current facts (measured by a rolled-back Native dry run).
create table cp7_receipt_fix.invoice_restatements(
 journal_id uuid primary key references erp.journal_entries,
 invoice_id uuid not null references erp.material_supplier_invoices,
 correction_id uuid not null references cp7_receipt_fix.revisions(id) deferrable initially deferred,
 economic_date date not null,native_journal_ids uuid[] not null,
 recorded_at timestamptz not null default clock_timestamp()
);
create table cp7_receipt_fix.context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 source_purchase_id uuid not null,related_purchase_ids uuid[] not null default '{}',primary key(backend_pid,transaction_id)
);
do $own$
declare t text;
begin
 foreach t in array array['requests','revisions','roll_lineage','movement_lineage','journal_restatements','payment_replays','ledger_links','invoice_replays','invoice_restatements','context']loop
  execute format('alter table cp7_receipt_fix.%I owner to postgres',t);
  execute format('alter table cp7_receipt_fix.%I enable row level security',t);
  execute format('create policy private_%s on cp7_receipt_fix.%I for all using(false)with check(false)',t,t);
 end loop;
end $own$;
revoke all on all tables in schema cp7_receipt_fix from public,anon,authenticated,service_role,cp7_capture;

create function cp7_receipt_fix.immutable()returns trigger
language plpgsql security invoker set search_path=''as $$
begin raise exception 'CP7_RECEIPT_FIX_HISTORY_IMMUTABLE';end $$;
create trigger immutable_revision before update or delete on cp7_receipt_fix.revisions for each row execute function cp7_receipt_fix.immutable();
create trigger immutable_roll_lineage before update or delete on cp7_receipt_fix.roll_lineage for each row execute function cp7_receipt_fix.immutable();
create trigger immutable_movement_lineage before update or delete on cp7_receipt_fix.movement_lineage for each row execute function cp7_receipt_fix.immutable();
create trigger immutable_journal_restatement before update or delete on cp7_receipt_fix.journal_restatements for each row execute function cp7_receipt_fix.immutable();
create trigger immutable_payment_replay before update or delete on cp7_receipt_fix.payment_replays for each row execute function cp7_receipt_fix.immutable();
create trigger immutable_ledger_link before update or delete on cp7_receipt_fix.ledger_links for each row execute function cp7_receipt_fix.immutable();
create trigger immutable_invoice_replay before update or delete on cp7_receipt_fix.invoice_replays for each row execute function cp7_receipt_fix.immutable();
create trigger immutable_invoice_restatement before update or delete on cp7_receipt_fix.invoice_restatements for each row execute function cp7_receipt_fix.immutable();

create function cp7_receipt_fix.access_now()returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;k text;
begin
 if auth.uid()is null or coalesce(auth.jwt()->>'role','')<>'authenticated'
  then raise exception using errcode='42501',message='CP7_RECEIPT_FIX_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed'is distinct from'true'::jsonb or erp.has_permission('warehouse.procurement.view')is distinct from true then
  raise exception using errcode='42501',message='CP7_RECEIPT_FIX_ACCESS_DENIED';end if;
 if coalesce(a->'profile'->>'role_code','')not in('OWNER','ADMIN')then
  raise exception using errcode='42501',message='CP7_RECEIPT_FIX_OWNER_ADMIN_REQUIRED';end if;
 foreach k in array array['warehouse.procurement.create','warehouse.procurement.post','warehouse.procurement.reverse','finance.ap.view']loop
  if erp.has_permission(k)is distinct from true then raise exception using errcode='42501',message='CP7_RECEIPT_FIX_ACCESS_DENIED';end if;
 end loop;
 return a;
end $$;

-- Native writers admit an authenticated caller only inside a declared,
-- transaction/actor-bound procurement context. This command owns that context
-- for its own duration and switches it per writer (draft save vs posting).
create function cp7_receipt_fix.admit(p_action text)returns void
language plpgsql volatile security definer set search_path=''as $$
begin
 if not exists(select 1 from cp7_receipt_fix.context where backend_pid=pg_backend_pid()
  and transaction_id=txid_current()and actor=auth.uid())then
  raise exception using errcode='42501',message='CP7_RECEIPT_FIX_PRIVATE_CONTEXT_REQUIRED';end if;
 delete from cp7_procurement.execution_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if p_action is not null then
  insert into cp7_procurement.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),p_action,
   case p_action when 'SAVE_DRAFT' then 'warehouse.procurement.create' else 'warehouse.procurement.post' end);
 end if;
end $$;

-- Exact receipt state the reviewer saw: header, lines, rolls, every stock
-- movement on its rolls/lines, cutting use, payments and dependent documents.
create function cp7_receipt_fix.review_token(p_purchase uuid)returns text
language sql stable security definer set search_path='' set "TimeZone"='UTC' as $$
 with items as(select*from erp.material_purchase_items where purchase_id=p_purchase),
 rolls as(select r.*from erp.material_rolls r join items i on i.id=r.purchase_item_id),
 moves as(select m.*from erp.material_stock_movements m where m.roll_id in(select id from rolls)
  or(m.source_type='MATERIAL_PURCHASE_ITEM'and m.source_id in(select id from items)))
 select md5(jsonb_build_object(
  'h',(select jsonb_build_array(h.row_version,h.status,h.payment_status,h.physical_at,h.supplier_id,h.location_id)from erp.material_purchase_headers h where h.id=p_purchase),
  'i',(select coalesce(jsonb_agg(jsonb_build_array(i.id,i.material_id,i.qty,i.unit_price,i.price_state,i.price_source,i.invoice_match_state)order by i.id),'[]')from items i),
  'r',(select coalesce(jsonb_agg(jsonb_build_array(r.id,r.material_id,r.roll_number,r.original_qty,r.status)order by r.id),'[]')from rolls r),
  'm',(select coalesce(jsonb_agg(jsonb_build_array(m.id,m.material_id,m.roll_id,m.qty_signed,m.physical_at,m.reversal_of_id)order by m.id),'[]')from moves m),
  'c',(select coalesce(jsonb_agg(jsonb_build_array(c.id,c.cutting_group_id,c.roll_id,c.qty_issued,c.qty_consumed,c.qty_physically_returned)order by c.id),'[]')
   from erp.cutting_group_rolls c where c.roll_id in(select id from rolls)),
  'p',(select coalesce(jsonb_agg(jsonb_build_array(p.id,p.status,p.amount,p.payment_date)order by p.id),'[]')from erp.supplier_payments p where p.purchase_id=p_purchase),
  'v',(select coalesce(jsonb_agg(jsonb_build_array(l.id,v.id,v.status)order by l.id),'[]')from erp.material_supplier_invoice_lines l
   join erp.material_supplier_invoices v on v.id=l.invoice_id where l.purchase_item_id in(select id from items)),
  'x',(select coalesce(jsonb_agg(jsonb_build_array(x.id,s.id,s.status)order by x.id),'[]')from erp.material_supplier_return_items x
   join erp.material_supplier_returns s on s.id=x.return_id where x.purchase_item_id in(select id from items)),
  'k',(select coalesce(jsonb_agg(jsonb_build_array(k.id,k.status)order by k.id),'[]')from erp.material_purchase_cost_corrections k where k.purchase_id=p_purchase),
  'b',(select coalesce(jsonb_agg(jsonb_build_array(b.id)order by b.id),'[]')from erp.bf_supplier_credit_moves_v1 b where p_purchase in(b.source_purchase_id,b.target_purchase_id)),
  'o',(select coalesce(jsonb_agg(jsonb_build_array(o.usage_id,o.purchase_item_id)order by o.usage_id,o.purchase_item_id),'[]')from erp.be_pocket_receipt_origins_v1 o where o.purchase_item_id in(select id from items))
 )::text)$$;

-- Physical use of one roll at the receipt location, after its own receipt:
-- every active non-receipt movement and the deepest running use. A corrected
-- quantity below that use would contradict the physical history.
create function cp7_receipt_fix.roll_use(p_roll uuid,p_location uuid)returns jsonb
language sql stable security definer set search_path=''as $$
 with active as(
  select m.*from erp.material_stock_movements m where m.roll_id=p_roll and m.reversal_of_id is null
   and m.source_type not in('MATERIAL_PURCHASE_ROLL','MATERIAL_PURCHASE_ITEM')
   and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=m.id)
 ),here as(
  select sum(qty_signed)over(order by physical_at,system_created_at,id rows unbounded preceding)prefix from active where location_id=p_location
 )
 select jsonb_build_object(
  'used_qty',coalesce((select -sum(qty_signed)from active where location_id=p_location),0)::text,
  'min_qty',greatest(0,-coalesce((select min(prefix)from here),0))::text,
  'uses',coalesce((select jsonb_agg(jsonb_build_object('source_type',source_type,'movement_type',movement_type,'count',n)order by source_type,movement_type)
   from(select source_type,movement_type,count(*)n from active group by 1,2)u),'[]'),
  'movable',not exists(select 1 from active where source_type not in('CUTTING_GROUP','CUTTING_GROUP_RETURN')))$$;

-- Lowest running balance of a non-roll material at one location from the
-- receipt time on. A receipt line reduced by more than this would make the
-- location history negative after the stock already left (transfer, issue).
create function cp7_receipt_fix.location_floor(p_material uuid,p_location uuid,p_from timestamptz)returns numeric
language sql stable security definer set search_path=''as $$
 select coalesce(min(x.prefix)filter(where x.physical_at>=p_from),0)from(
  select m.physical_at,sum(m.qty_signed)over(order by m.physical_at,m.system_created_at,m.id rows unbounded preceding)prefix
  from erp.material_stock_movements m where m.material_id=p_material and m.location_id=p_location and m.roll_id is null)x$$;

-- Lowest balance of a non-roll material at one location when this receipt's
-- own rows are taken out and the corrected quantity comes in at the corrected
-- time (and location): never negative, else stock would have left before it came.
create function cp7_receipt_fix.shifted_floor(p_material uuid,p_location uuid,p_purchase uuid,p_from timestamptz,p_new_at timestamptz,p_new_qty numeric)returns numeric
language sql stable security definer set search_path=''as $$
 select coalesce(min(x.prefix+case when x.physical_at>=p_new_at then p_new_qty else 0 end)filter(where x.physical_at>=p_from),0)from(
  select m.physical_at,sum(m.qty_signed)over(order by m.physical_at,m.system_created_at,m.id rows unbounded preceding)prefix
  from erp.material_stock_movements m where m.material_id=p_material and m.location_id=p_location and m.roll_id is null
   and not(m.source_type='MATERIAL_PURCHASE_ITEM'and m.source_id in(select id from erp.material_purchase_items where purchase_id=p_purchase)))x$$;

create function cp7_receipt_fix.blockers(p_purchase uuid)returns jsonb
language sql stable security definer set search_path=''as $$
 -- Each blocker names its documents (type and number), so the page can say
 -- exactly what to finish or cancel first. count keeps the blocking rows.
 select coalesce(jsonb_agg(jsonb_build_object('code',code,'count',n,'documents',docs)order by code),'[]')from(
  select code,count(*)::integer n,jsonb_agg(distinct jsonb_build_object('type',kind,'number',number))docs from(
   -- A supplier invoice that also covers other receipts is corrected whole; only
   -- an AP-backed return on another receipt of that invoice blocks the Native reversal.
   select 'CP7_RECEIPT_FIX_SHARED_INVOICE_RETURN_ACTIVE'code,'SUPPLIER_RETURN'kind,rh.return_number::text number from erp.material_supplier_return_items ri
    join erp.material_supplier_returns rh on rh.id=ri.return_id join erp.material_supplier_invoice_lines l on l.purchase_item_id=ri.purchase_item_id
    join erp.material_supplier_invoices v on v.id=l.invoice_id join erp.material_purchase_items i on i.id=ri.purchase_item_id
    where rh.status='POSTED'and coalesce(ri.ap_relief_qty_snapshot,0)>0 and v.status='POSTED'and i.purchase_id<>p_purchase
     and v.id in(select l2.invoice_id from erp.material_supplier_invoice_lines l2 join erp.material_purchase_items i2 on i2.id=l2.purchase_item_id where i2.purchase_id=p_purchase)
   union all select 'CP7_RECEIPT_FIX_PENDING_CHILD_REVIEW_REQUIRED','SUPPLIER_INVOICE',v.invoice_number from erp.material_supplier_invoice_lines l
    join erp.material_supplier_invoices v on v.id=l.invoice_id join erp.material_purchase_items i on i.id=l.purchase_item_id where i.purchase_id=p_purchase and v.status='DRAFT'
   union all select 'CP7_RECEIPT_FIX_PENDING_CHILD_REVIEW_REQUIRED','SUPPLIER_RETURN',s.return_number from erp.material_supplier_return_items x
    join erp.material_supplier_returns s on s.id=x.return_id join erp.material_purchase_items i on i.id=x.purchase_item_id where i.purchase_id=p_purchase and s.status='DRAFT'
   union all select 'CP7_RECEIPT_FIX_PENDING_CHILD_REVIEW_REQUIRED','SUPPLIER_PAYMENT',p.payment_number from erp.supplier_payments p where p.purchase_id=p_purchase and p.status='DRAFT'
   union all select 'CP7_RECEIPT_FIX_PENDING_CHILD_REVIEW_REQUIRED','COST_CORRECTION',k.correction_number from erp.material_purchase_cost_corrections k
    where k.purchase_id=p_purchase and k.status='DRAFT'
   -- An unposted cutting group (Native keeps status CUT with material_issue_posted
   -- false until POST) or draft transfer already binds a roll of this receipt;
   -- GPT's cutting inputs pin that roll too.
   union all select 'CP7_RECEIPT_FIX_DRAFT_ROLL_USE','CUTTING_GROUP',g.group_number from erp.cutting_group_rolls cr
    join erp.cutting_groups g on g.id=cr.cutting_group_id join erp.material_rolls r on r.id=cr.roll_id
    join erp.material_purchase_items i on i.id=r.purchase_item_id where i.purchase_id=p_purchase and not g.material_issue_posted
   union all select 'CP7_RECEIPT_FIX_DRAFT_ROLL_USE','MATERIAL_TRANSFER',t.transfer_number from erp.material_transfer_items ti
    join erp.material_transfers t on t.id=ti.transfer_id join erp.material_rolls r on r.id=ti.roll_id
    join erp.material_purchase_items i on i.id=r.purchase_item_id where i.purchase_id=p_purchase and t.status='DRAFT'
   union all select 'CP7_RECEIPT_FIX_RETURN_ACTIVE','SUPPLIER_RETURN',s.return_number from erp.material_supplier_return_items x
    join erp.material_supplier_returns s on s.id=x.return_id join erp.material_purchase_items i on i.id=x.purchase_item_id
    where i.purchase_id=p_purchase and s.status='POSTED'
   union all select 'CP7_RECEIPT_FIX_COST_CORRECTION_ACTIVE','COST_CORRECTION',k.correction_number from erp.material_purchase_cost_corrections k
    where k.purchase_id=p_purchase and k.status='POSTED'
   -- Moves are append-only: a restored move adds its negative row, so only a
   -- non-zero net per return and receipt pair is still an active credit.
   union all select 'CP7_RECEIPT_FIX_SUPPLIER_CREDIT_ACTIVE','MATERIAL_PURCHASE',o.purchase_number from(select m.source_purchase_id,m.target_purchase_id
     from erp.bf_supplier_credit_moves_v1 m where p_purchase in(m.source_purchase_id,m.target_purchase_id)
     group by m.return_id,m.source_purchase_id,m.target_purchase_id having sum(m.amount)<>0)b
    join erp.material_purchase_headers o on o.id=case when b.source_purchase_id=p_purchase then b.target_purchase_id else b.source_purchase_id end
   union all select 'CP7_RECEIPT_FIX_POCKET_ORIGIN_ACTIVE','POCKET_USE',coalesce(u.document_number,o.usage_id::text)from erp.be_pocket_receipt_origins_v1 o
    join erp.material_purchase_items i on i.id=o.purchase_item_id left join erp.be_pocket_usage_v1 u on u.id=o.usage_id where i.purchase_id=p_purchase
   union all select 'CP7_RECEIPT_FIX_OPENING_IMPORT_USE_IMPORT_WORKFLOW','OPENING_IMPORT',h.receipt_number from erp.initial_import_receipt_headers h
    where h.purchase_id=p_purchase
  )x group by code
 )y$$;

create function cp7_receipt_fix.workspace(p_purchase uuid)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;root uuid;leaf uuid;h erp.material_purchase_headers%rowtype;history jsonb;lines jsonb;pays jsonb;blocks jsonb;invoices jsonb;targets jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_receipt_fix.access_now();
 if p_purchase is null then raise exception 'CP7_RECEIPT_FIX_SOURCE_REQUIRED';end if;
 select root_purchase_id into root from cp7_receipt_fix.revisions where replacement_purchase_id=p_purchase or previous_purchase_id=p_purchase order by revision desc limit 1;
 root:=coalesce(root,p_purchase);
 select replacement_purchase_id into leaf from cp7_receipt_fix.revisions where root_purchase_id=root order by revision desc limit 1;
 leaf:=coalesce(leaf,root);
 select*into h from erp.material_purchase_headers where id=leaf;
 if h.id is null then raise exception 'CP7_RECEIPT_FIX_NOT_FOUND';end if;
 select coalesce(jsonb_agg(jsonb_build_object('revision_id',r.id,'revision',r.revision::text,'previous_purchase_id',r.previous_purchase_id,
  'previous_purchase_number',(select purchase_number from erp.material_purchase_headers where id=r.previous_purchase_id),
  'replacement_purchase_id',r.replacement_purchase_id,'replacement_purchase_number',(select purchase_number from erp.material_purchase_headers where id=r.replacement_purchase_id),
  'effective_at',r.effective_at,'recorded_at',r.recorded_at,'reason',r.reason,
  -- Immutable actor UUID; the current profile name is presentation only
  -- (same contract as cp7_note.workspace_with_actors).
  'actor_id',r.actor,'actor_display_name',(select nullif(btrim(u.full_name),'')from erp.app_users u where u.auth_user_id=r.actor),'actor_name_basis','CURRENT_PROFILE',
  'previous_document',r.previous_document,'corrected_document',r.corrected_document)order by r.revision),'[]')into history
 from cp7_receipt_fix.revisions r where r.root_purchase_id=root;
 select coalesce(jsonb_agg(jsonb_build_object('item_id',i.id,'material_id',i.material_id,'material_sku',m.material_sku,'material_name',m.material_name,
  'material_type',m.material_type,'unit_code',m.unit_code,'qty',i.qty::text,'unit_price',i.unit_price::text,'line_total',i.line_total::text,
  -- An invoice-matched line is a receipt estimate; its final price lives on the supplier invoice (Native match state).
  'price_state',case when i.invoice_match_state in('PARTIAL','MATCHED')then 'ESTIMATED'else i.price_state end,
  'price_source',case when i.invoice_match_state in('PARTIAL','MATCHED')then i.receipt_price_source_snapshot else i.price_source end,
  'invoice_match_state',i.invoice_match_state,'lot_number',i.lot_number,'notes',i.notes,
  'min_qty',case when m.material_type='FABRIC'then '0'else greatest(0,i.qty-cp7_receipt_fix.location_floor(i.material_id,h.location_id,h.physical_at))::text end,
  'rolls',(select coalesce(jsonb_agg(jsonb_build_object('roll_id',r.id,'roll_number',r.roll_number,'qty',r.original_qty::text,
    'cached_qty',r.cached_qty::text,'status',r.status)||cp7_receipt_fix.roll_use(r.id,h.location_id)order by r.roll_number,r.id),'[]')
   from erp.material_rolls r where r.purchase_item_id=i.id))order by i.id),'[]')into lines
 from erp.material_purchase_items i join erp.materials m on m.id=i.material_id where i.purchase_id=leaf;
 select coalesce(jsonb_agg(jsonb_build_object('payment_id',p.id,'payment_number',p.payment_number,'payment_date',p.payment_date,
  'amount',p.amount::text,'status',p.status)order by p.payment_date,p.id),'[]')into pays
 from erp.supplier_payments p where p.purchase_id=leaf and p.status in('POSTED','DRAFT');
 select coalesce(jsonb_agg(jsonb_build_object('invoice_id',v.id,'invoice_number',v.invoice_number,'invoice_date',v.invoice_date,
  'received_at',v.received_at,'due_date',v.due_date,'row_version',v.row_version::text,'notes',v.notes,
  'lines',(select jsonb_agg(jsonb_build_object('invoice_line_id',l.id,'purchase_item_id',l.purchase_item_id,'qty_invoiced',l.qty_invoiced::text,
   'unit_price',l.unit_price::text,'discount_amount',l.discount_amount::text,'net_amount',l.net_amount::text,'notes',l.notes)order by l.id)
   from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=v.id and i.purchase_id=leaf),
  'other_receipts',(select coalesce(jsonb_agg(jsonb_build_object('purchase_id',o.id,'purchase_number',o.purchase_number)order by o.purchase_number,o.id),'[]')
   from erp.material_purchase_headers o where o.id<>leaf and o.id in(select i.purchase_id from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=v.id)))order by v.invoice_date,v.posted_at,v.id),'[]')into invoices
 from erp.material_supplier_invoices v where v.status='POSTED'and v.id in(select l.invoice_id from erp.material_supplier_invoice_lines l
  join erp.material_purchase_items i on i.id=l.purchase_item_id where i.purchase_id=leaf);
 -- Receipts of the same supplier that still owe money: where an overpayment
 -- becomes credit (retur bayangan) when the corrected total is lower.
 select coalesce(jsonb_agg(jsonb_build_object('purchase_id',t.id,'purchase_number',t.purchase_number,'physical_at',t.physical_at,
   'remaining',t.remaining::text)order by t.physical_at desc,t.id),'[]')into targets
 from(select t0.*from(select x.id,x.purchase_number,x.physical_at,(round(erp.material_purchase_payable_total(x.id),2)
   -coalesce((select sum(p.amount)from erp.supplier_payments p where p.purchase_id=x.id and p.status='POSTED'),0))::numeric(20,2)remaining
  from erp.material_purchase_headers x where x.supplier_id=h.supplier_id and x.status='POSTED'and x.id<>leaf)t0
 where t0.remaining>0 order by t0.physical_at desc,t0.id limit 50)t;
 blocks:=case when h.status<>'POSTED'then jsonb_build_array(jsonb_build_object('code','CP7_RECEIPT_FIX_ACTIVE_POSTED_ONLY','count',1))
  else cp7_receipt_fix.blockers(leaf)end;
 if cp7_receipt_fix.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_RECEIPT_FIX_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.receipt-correction-workspace.v1','read_at',clock_timestamp(),
  'root_purchase_id',root,'current_purchase_id',leaf,
  'original_purchase_number',(select purchase_number from erp.material_purchase_headers where id=root),
  'purchase',jsonb_build_object('purchase_id',h.id,'purchase_number',h.purchase_number,'status',h.status,'row_version',h.row_version::text,
   'supplier_id',h.supplier_id,'supplier_name',(select supplier_name from erp.suppliers where id=h.supplier_id),
   'location_id',h.location_id,'location_name',(select location_name from erp.locations where id=h.location_id),
   'physical_at',h.physical_at,'payment_status',h.payment_status,'supplier_invoice_number',h.supplier_invoice_number,'due_date',h.due_date,'notes',h.notes),
  'lines',lines,'invoices',invoices,'payments',pays,'credit_targets',targets,'paid_total',(select coalesce(sum(amount),0)::text from erp.supplier_payments where purchase_id=leaf and status='POSTED'),
  'blockers',blocks,'can_correct',jsonb_array_length(blocks)=0,'review_token',cp7_receipt_fix.review_token(leaf),
  'history',history,'production_go',false);
end $$;

-- Moves the exact economic effect of a today-dated generic inverse to the
-- original economic date through a source-owned neutral/effective pair. The
-- Native inverse line set, its posting fact and closed-period rule are kept.
create function cp7_receipt_fix.restate(p_inverse uuid,p_reason text)returns void
language plpgsql volatile security definer set search_path=''as $$
declare original erp.journal_entries%rowtype;inverse erp.journal_entries%rowtype;src uuid;related uuid[];lines jsonb;neutral uuid;effective uuid;
begin
 select source_purchase_id,related_purchase_ids into strict src,related from cp7_receipt_fix.context
  where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid();
 select*into strict inverse from erp.journal_entries where id=p_inverse;
 select*into strict original from erp.journal_entries where id=inverse.reversal_of_id;
 if original.status<>'REVERSED'or inverse.status<>'POSTED'or inverse.source_type<>'JOURNAL_REVERSAL'or inverse.source_id<>original.id
  or not(original.source_type in('MATERIAL_PURCHASE','MATERIAL_PURCHASE_GRNI_RECLASS')and original.source_id=src
   or original.source_type='SUPPLIER_PAYMENT'and exists(select 1 from erp.supplier_payments where id=original.source_id and(purchase_id=src or purchase_id=any(related))))then
  raise exception 'CP7_RECEIPT_FIX_JOURNAL_SOURCE_CHANGED';end if;
 if original.economic_date=inverse.economic_date then return;end if;
 select jsonb_agg(jsonb_build_object('account_id',j.account_id,'debit',j.credit,'credit',j.debit,'description',j.description,
  'customer_id',j.customer_id,'vendor_id',j.vendor_id,'contractor_id',j.contractor_id,'po_id',j.po_id,'product_id',j.product_id)order by j.id)
 into lines from erp.journal_lines j where j.journal_entry_id=inverse.id;
 neutral:=erp.post_journal('RECEIPT_FIX_REVERSAL_TIME_NEUTRAL',inverse.id,inverse.economic_date,
  'Benerin penerimaan: pindahkan waktu ekonomi pembalikan | '||p_reason,lines);
 select jsonb_agg(jsonb_build_object('account_id',j.account_id,'debit',j.debit,'credit',j.credit,'description',j.description,
  'customer_id',j.customer_id,'vendor_id',j.vendor_id,'contractor_id',j.contractor_id,'po_id',j.po_id,'product_id',j.product_id)order by j.id)
 into lines from erp.journal_lines j where j.journal_entry_id=inverse.id;
 effective:=erp.post_journal('RECEIPT_FIX_REVERSAL_EFFECTIVE',inverse.id,original.economic_date,
  'Benerin penerimaan: waktu ekonomi kejadian asal | '||p_reason,lines);
 insert into cp7_receipt_fix.journal_restatements values(inverse.id,original.id,src,neutral,effective,inverse.economic_date,original.economic_date,clock_timestamp());
end $$;

create function cp7_receipt_fix.restate_all(p_reason text)returns void
language plpgsql volatile security definer set search_path=''as $$
declare src uuid;related uuid[];j uuid;
begin
 select source_purchase_id,related_purchase_ids into strict src,related from cp7_receipt_fix.context
  where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid();
 for j in select v.id from erp.journal_entries v join erp.journal_entries o on o.id=v.reversal_of_id
  where v.source_type='JOURNAL_REVERSAL'and v.status='POSTED'
   and(o.source_type in('MATERIAL_PURCHASE','MATERIAL_PURCHASE_GRNI_RECLASS')and o.source_id=src
    or o.source_type='SUPPLIER_PAYMENT'and exists(select 1 from erp.supplier_payments p where p.id=o.source_id and(p.purchase_id=src or p.purchase_id=any(related))))
   and not exists(select 1 from cp7_receipt_fix.journal_restatements r where r.inverse_journal_id=v.id)
   -- Only inverses posted by this command. Earlier payment cancellations or
   -- payment corrections keep the dates their own commands gave them.
   and v.created_at=statement_timestamp()
  order by v.id loop
  perform cp7_receipt_fix.restate(j,p_reason);
 end loop;
end $$;

-- Net journal effect per economic date, account and dimension.
create function cp7_receipt_fix.journal_net(p_ids uuid[])returns jsonb
language sql volatile security definer set search_path=''as $$
 select coalesce(jsonb_agg(jsonb_build_object('d',d,'account_id',account_id,'customer_id',customer_id,'vendor_id',vendor_id,
  'contractor_id',contractor_id,'po_id',po_id,'product_id',product_id,'amount',amount::text)
  order by d,account_id::text,customer_id::text,vendor_id::text,contractor_id::text,po_id::text,product_id::text),'[]')
 from(select j.economic_date d,l.account_id,l.customer_id,l.vendor_id,l.contractor_id,l.po_id,l.product_id,sum(l.debit-l.credit)amount
  from erp.journal_lines l join erp.journal_entries j on j.id=l.journal_entry_id where j.id=any(p_ids)
  group by 1,2,3,4,5,6,7 having sum(l.debit-l.credit)<>0)x$$;

-- Native reversal of one posted supplier invoice of the receipt, its effect
-- restated to the invoice's own economic dates. The dry run re-posts the same
-- invoice at its own book date right after the Native reversal and is rolled
-- back; its journals are the exact opposite of the reversal (checked per
-- account and dimension, else refused) and carry the dates of the goods.
create function cp7_receipt_fix.reverse_invoice(p_invoice uuid,p_reason text,p_fix uuid)returns void
language plpgsql volatile security definer set search_path=''as $$
declare v erp.material_supplier_invoices%rowtype;before uuid[];mid uuid[];native_ids uuid[];dry uuid;mirror jsonb;native jsonb;d date;lines jsonb;j uuid;
begin
 perform 1 from cp7_receipt_fix.context where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid();
 if not found then raise exception using errcode='42501',message='CP7_RECEIPT_FIX_PRIVATE_CONTEXT_REQUIRED';end if;
 select*into strict v from erp.material_supplier_invoices where id=p_invoice for update;
 if v.status<>'POSTED'then raise exception 'CP7_RECEIPT_FIX_INVOICE_SET';end if;
 select coalesce(array_agg(id),'{}')into before from erp.journal_entries where created_at=statement_timestamp();
 begin
  perform erp.reverse_material_supplier_invoice(v.id,p_reason);
  select coalesce(array_agg(id),'{}')into mid from erp.journal_entries where created_at=statement_timestamp();
  dry:=(erp.save_material_supplier_invoice_draft_v2(jsonb_build_object('invoice_number',left(v.invoice_number,80)||' · CP7-DRY',
   'supplier_id',v.supplier_id,'invoice_date',v.invoice_date,'received_at',v.received_at,'due_date',v.due_date,'change_reason',p_reason,
   'lines',(select jsonb_agg(jsonb_build_object('purchase_item_id',l.purchase_item_id,'qty_invoiced',l.qty_invoiced,'unit_price',l.unit_price,
     'discount_amount',l.discount_amount)order by l.id)from erp.material_supplier_invoice_lines l where l.invoice_id=v.id)),gen_random_uuid(),null)
   ->>'supplier_invoice_id')::uuid;
  perform erp.post_material_supplier_invoice(dry);
  mirror:=cp7_receipt_fix.journal_net(array(select id from erp.journal_entries where created_at=statement_timestamp()and not(id=any(mid))));
  raise exception using errcode='P0001',message='CP7_RECEIPT_FIX_DRY_RUN_COMPLETE';
 exception when others then
  if sqlerrm<>'CP7_RECEIPT_FIX_DRY_RUN_COMPLETE'then raise;end if;
 end;
 if mirror is null then raise exception 'CP7_RECEIPT_FIX_INVOICE_DRY_RUN_MISSING';end if;
 perform erp.reverse_material_supplier_invoice(v.id,p_reason);
 native_ids:=array(select id from erp.journal_entries where created_at=statement_timestamp()and not(id=any(before))order by id);
 native:=cp7_receipt_fix.journal_net(native_ids);
 if exists(select 1 from(select x->>'account_id'a,x->>'customer_id'c,x->>'vendor_id'w,x->>'contractor_id'k,x->>'po_id'p,x->>'product_id'r,(x->>'amount')::numeric n
   from jsonb_array_elements(mirror||native)x)u group by a,c,w,k,p,r having sum(n)<>0)then
  raise exception 'CP7_RECEIPT_FIX_INVOICE_RESTATEMENT_MISMATCH %',v.invoice_number;end if;
 for d in select distinct(x->>'d')::date from jsonb_array_elements(mirror||native)x order by 1 loop
  select coalesce(jsonb_agg(jsonb_build_object('account_id',a,'customer_id',c,'vendor_id',w,'contractor_id',k,'po_id',p,'product_id',r,
    'debit',greatest(n,0),'credit',greatest(-n,0),'description','Pembalikan invoice '||v.invoice_number)order by a,c,w,k,p,r),'[]')into lines
  from(select(x->>'account_id')::uuid a,(x->>'customer_id')::uuid c,(x->>'vendor_id')::uuid w,(x->>'contractor_id')::uuid k,(x->>'po_id')::uuid p,
    (x->>'product_id')::uuid r,-sum((x->>'amount')::numeric)n
   from jsonb_array_elements(mirror||native)x where(x->>'d')::date=d group by 1,2,3,4,5,6 having sum((x->>'amount')::numeric)<>0)z;
  if jsonb_array_length(lines)=0 then continue;end if;
  j:=erp.post_journal('RECEIPT_FIX_INVOICE_REVERSAL_DATE',md5(p_fix::text||':'||v.id::text||':'||d::text)::uuid,d,
   'Benerin penerimaan: pembalikan invoice '||v.invoice_number||' pada tanggal ekonomi asal | '||p_reason,lines);
  insert into cp7_receipt_fix.invoice_restatements(journal_id,invoice_id,correction_id,economic_date,native_journal_ids)values(j,v.id,p_fix,d,native_ids);
 end loop;
end $$;

-- Snapshot the Native opening-advance funding validation compares (UTC text).
create function cp7_receipt_fix.payment_snapshot(p_payment uuid)returns jsonb
language sql stable security definer set search_path='' set "TimeZone"='UTC' as $$
 select to_jsonb(p)-'status'from erp.supplier_payments p where p.id=p_payment$$;

-- One replayed supplier payment through the Native writer: same date, method,
-- cash account and reference. A payment funded from a supplier opening advance
-- (uang muka saldo awal) is funded from the same advance again; the Native
-- funding validation checks its remaining amount, party and dates.
create function cp7_receipt_fix.replay_payment(p_target uuid,p_payment jsonb,p_amount numeric,p_number text,p_notes text)returns uuid
language plpgsql volatile security definer set search_path=''as $$
declare new_payment uuid;
begin
 perform 1 from cp7_receipt_fix.context where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid();
 if not found then raise exception using errcode='42501',message='CP7_RECEIPT_FIX_PRIVATE_CONTEXT_REQUIRED';end if;
 insert into erp.supplier_payments(purchase_id,payment_number,payment_date,amount,cash_account_id,payment_method,reference_number,notes,status,created_by)
 values(p_target,p_number,(p_payment->>'payment_date')::timestamptz,p_amount,(p_payment->>'cash_account_id')::uuid,p_payment->>'payment_method',
  p_payment->>'reference_number',p_notes,'DRAFT',erp.current_app_user_id())returning id into new_payment;
 if p_payment->>'advance_id'is not null then
  insert into erp.initial_import_prepayment_payments(payment_id,advance_id,supplier_payment_id,payment_snapshot)
  values(new_payment,(p_payment->>'advance_id')::uuid,new_payment,cp7_receipt_fix.payment_snapshot(new_payment));
 end if;
 perform erp.post_supplier_payment(new_payment);
 return new_payment;
end $$;

create function cp7_receipt_fix.command(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;old cp7_receipt_fix.requests%rowtype;h erp.material_purchase_headers%rowtype;root uuid;rev_no bigint;
 line jsonb;roll jsonb;item record;mat record;mv record;draft jsonb;result jsonb;replaced uuid;item_ids uuid[];
 lineage jsonb:='[]';old_rolls uuid[];old_items uuid[];seen_rolls uuid[]:='{}';seen_items uuid[]:='{}';mat_ids uuid[];
 old_roll erp.material_rolls%rowtype;use jsonb;new_roll uuid;new_item uuid;line_no integer:=0;roll_no integer;
 paid jsonb;payment record;new_payment uuid;corrected_total numeric:=0;why text;fix_id uuid:=gen_random_uuid();
 rev_id uuid;tmp text;previous_doc jsonb;corrected_doc jsonb;pending jsonb:='[]';
 inv_ids uuid[];inv jsonb;il jsonb;old_new jsonb:='{}';inv_lines jsonb;new_inv uuid;invoiced jsonb:='{}';
 paid_total numeric:=0;excess numeric:=0;credits jsonb:='[]';credit jsonb;target erp.material_purchase_headers%rowtype;
 left_on_receipt numeric;part numeric;piece integer:=0;queue jsonb;related uuid[]:='{}';other_paid jsonb:='[]';pay jsonb;base text;inv_base text;
 new_at timestamptz;new_loc uuid;new_sup uuid;moved boolean;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_receipt_fix.access_now();
 if jsonb_typeof(p_payload)is distinct from'object'or not p_payload?&array['purchase_id','review_token','change_reason','lines']
  or exists(select 1 from jsonb_object_keys(p_payload)k where k not in('purchase_id','review_token','change_reason','lines','invoices','credit_allocations','notes','purchase_number','physical_at','location_id','supplier_id'))
  or nullif(p_payload->>'location_id','')!~'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
  or nullif(p_payload->>'supplier_id','')!~'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
  or p_payload?'credit_allocations'and(jsonb_typeof(p_payload->'credit_allocations')is distinct from'array'or jsonb_array_length(p_payload->'credit_allocations')>20)
  or jsonb_typeof(p_payload->'lines')is distinct from'array'or jsonb_array_length(p_payload->'lines')not between 1 and 100
  or p_payload?'invoices'and(jsonb_typeof(p_payload->'invoices')is distinct from'array'or jsonb_array_length(p_payload->'invoices')>20)
  or exists(select 1 from jsonb_each(p_payload)e where e.key not in('lines','invoices','credit_allocations')and jsonb_typeof(e.value)not in('string','null'))
  or nullif(btrim(p_payload->>'change_reason'),'')is null or length(p_payload->>'change_reason')>500
 then raise exception using errcode='22023',message='CP7_RECEIPT_FIX_FIELDS';end if;
 if p_request is null or p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'then raise exception 'CP7_RECEIPT_FIX_REQUEST_REQUIRED';end if;
 why:=btrim(p_payload->>'change_reason');
 insert into cp7_receipt_fix.requests values(auth.uid(),p_request,p_payload,p_expected,null)on conflict do nothing;
 select*into strict old from cp7_receipt_fix.requests where actor=auth.uid()and request_id=p_request for update;
 if old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_RECEIPT_FIX_REQUEST_CHANGED';end if;
 if cp7_receipt_fix.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_RECEIPT_FIX_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;

 -- Same lock order as Native receipt/recost writers: period, mat_ids, receipt.
 perform 1 from erp.accounting_period_control where singleton_id=1 for share;
 select array_agg(distinct mats.id order by mats.id)into mat_ids from(
  select i.material_id id from erp.material_purchase_items i where i.purchase_id=(p_payload->>'purchase_id')::uuid
  union select(l->>'material_id')::uuid from jsonb_array_elements(p_payload->'lines')l where l->>'material_id'~'^[0-9a-fA-F-]{36}$')mats;
 -- Materials of other receipts on a shared supplier invoice are locked in the
 -- same order: the invoice reversal/re-post refreshes their cost too.
 perform 1 from erp.materials where id=any(coalesce(mat_ids,'{}'))or id in(select i2.material_id from erp.material_supplier_invoice_lines l2
  join erp.material_purchase_items i2 on i2.id=l2.purchase_item_id join erp.material_supplier_invoices v2 on v2.id=l2.invoice_id
  where v2.status='POSTED'and v2.id in(select l.invoice_id from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id
   where i.purchase_id=(p_payload->>'purchase_id')::uuid))order by id for update;
 select*into h from erp.material_purchase_headers where id=(p_payload->>'purchase_id')::uuid for update;
 if h.id is null then raise exception 'CP7_RECEIPT_FIX_NOT_FOUND';end if;
 if h.status<>'POSTED'then raise exception 'CP7_RECEIPT_FIX_ACTIVE_POSTED_ONLY';end if;
 if h.row_version::text<>p_expected or cp7_receipt_fix.review_token(h.id)<>p_payload->>'review_token'then raise exception 'CP7_RECEIPT_FIX_REVIEW_CHANGED';end if;
 if exists(select 1 from cp7_receipt_fix.revisions where previous_purchase_id=h.id)then raise exception 'CP7_RECEIPT_FIX_SOURCE_SUPERSEDED';end if;
 if jsonb_array_length(cp7_receipt_fix.blockers(h.id))>0 then
  raise exception 'CP7_RECEIPT_FIX_DEPENDENCY %',(select string_agg(b->>'code',',')from jsonb_array_elements(cp7_receipt_fix.blockers(h.id))b);end if;
 select root_purchase_id into root from cp7_receipt_fix.revisions where replacement_purchase_id=h.id;
 root:=coalesce(root,h.id);
 -- Time, warehouse and supplier as they really were. A changed time or
 -- warehouse moves the stock row; a changed supplier moves its debt.
 begin new_at:=coalesce(nullif(p_payload->>'physical_at','')::timestamptz,h.physical_at);
 exception when others then raise exception using errcode='22023',message='CP7_RECEIPT_FIX_FIELDS';end;
 new_loc:=coalesce(nullif(p_payload->>'location_id','')::uuid,h.location_id);
 new_sup:=coalesce(nullif(p_payload->>'supplier_id','')::uuid,h.supplier_id);
 if new_at>statement_timestamp()then raise exception 'CP7_RECEIPT_FIX_DATE_FUTURE';end if;
 moved:=new_at<>h.physical_at or new_loc<>h.location_id;
 select coalesce(max(v.revision),0)+1 into rev_no from cp7_receipt_fix.revisions v where v.root_purchase_id=root;
 select array_agg(id order by id)into old_items from erp.material_purchase_items where purchase_id=h.id;
 select array_agg(r2.id order by r2.id)into old_rolls from erp.material_rolls r2 join erp.material_purchase_items i on i.id=r2.purchase_item_id where i.purchase_id=h.id;
 select jsonb_build_object('purchase_number',h.purchase_number,'physical_at',h.physical_at,'location_id',h.location_id,'supplier_id',h.supplier_id,'supplier_invoice_number',h.supplier_invoice_number,'due_date',h.due_date,'notes',h.notes,'lines',coalesce(jsonb_agg(jsonb_build_object('item_id',i.id,'material_id',i.material_id,
  'qty',i.qty::text,'unit_price',i.unit_price::text,'price_state',i.price_state,'price_source',i.price_source,
  'rolls',(select coalesce(jsonb_agg(jsonb_build_object('roll_id',r3.id,'roll_number',r3.roll_number,'qty',r3.original_qty::text)order by r3.roll_number,r3.id),'[]')
   from erp.material_rolls r3 where r3.purchase_item_id=i.id))order by i.id),'[]'))into previous_doc
 from erp.material_purchase_items i where i.purchase_id=h.id;
 select coalesce(array_agg(v.id order by v.invoice_date,v.posted_at,v.id),'{}')into inv_ids from erp.material_supplier_invoices v
  where v.status='POSTED'and v.id in(select l.invoice_id from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where i.purchase_id=h.id);
 previous_doc:=previous_doc||jsonb_build_object('invoices',(select coalesce(jsonb_agg(jsonb_build_object('invoice_id',v.id,'invoice_number',v.invoice_number,
  'invoice_date',v.invoice_date,'lines',(select jsonb_agg(jsonb_build_object('invoice_line_id',l.id,'purchase_item_id',l.purchase_item_id,'qty_invoiced',l.qty_invoiced::text,
   'unit_price',l.unit_price::text,'discount_amount',l.discount_amount::text)order by l.id)from erp.material_supplier_invoice_lines l where l.invoice_id=v.id))
  order by v.invoice_date,v.posted_at,v.id),'[]')from erp.material_supplier_invoices v where v.id=any(inv_ids)));

 -- Validate the corrected document against the physical history it replaces.
 for line in select value from jsonb_array_elements(p_payload->'lines')loop
  line_no:=line_no+1;
  if jsonb_typeof(line)is distinct from'object'or not line?&array['material_id','unit_price','price_state','price_source','rolls']
   or exists(select 1 from jsonb_object_keys(line)k where k not in('replaces_item_id','material_id','qty','unit_price','price_state','price_source','rolls','lot_number','notes'))
   or exists(select 1 from jsonb_each(line)e where e.key<>'rolls'and jsonb_typeof(e.value)not in('string','null'))
   or jsonb_typeof(line->'rolls')is distinct from'array'or jsonb_array_length(line->'rolls')>500
  then raise exception using errcode='22023',message='CP7_RECEIPT_FIX_FIELDS';end if;
  perform cp7_procurement.decimal(line->'unit_price',false);
  select*into mat from erp.materials where id=(line->>'material_id')::uuid;
  if mat.id is null then raise exception 'CP7_RECEIPT_FIX_MATERIAL_NOT_FOUND';end if;
  if nullif(line->>'replaces_item_id','')is not null then
   if not((line->>'replaces_item_id')::uuid=any(old_items))or(line->>'replaces_item_id')::uuid=any(seen_items)then raise exception 'CP7_RECEIPT_FIX_ITEM_LINEAGE';end if;
   seen_items:=seen_items||(line->>'replaces_item_id')::uuid;
  end if;
  if mat.material_type='FABRIC'then
   if jsonb_array_length(line->'rolls')=0 or line?'qty'then raise exception 'CP7_RECEIPT_FIX_FABRIC_ROLLS_REQUIRED';end if;
   for roll in select value from jsonb_array_elements(line->'rolls')loop
    if jsonb_typeof(roll)is distinct from'object'or not roll?&array['roll_number','qty']
     or exists(select 1 from jsonb_object_keys(roll)k where k not in('replaces_roll_id','roll_number','qty','notes'))
     or exists(select 1 from jsonb_each(roll)e where jsonb_typeof(e.value)not in('string','null'))
     or nullif(btrim(roll->>'roll_number'),'')is null or length(roll->>'roll_number')>80
    then raise exception using errcode='22023',message='CP7_RECEIPT_FIX_FIELDS';end if;
    perform cp7_procurement.decimal(roll->'qty',true);
    if upper(coalesce(line->>'price_state',''))='FINAL'then corrected_total:=corrected_total+(roll->>'qty')::numeric*(line->>'unit_price')::numeric;end if;
    if nullif(roll->>'replaces_roll_id','')is not null then
     if not((roll->>'replaces_roll_id')::uuid=any(coalesce(old_rolls,'{}')))or(roll->>'replaces_roll_id')::uuid=any(seen_rolls)then raise exception 'CP7_RECEIPT_FIX_ROLL_LINEAGE';end if;
     seen_rolls:=seen_rolls||(roll->>'replaces_roll_id')::uuid;
     select*into old_roll from erp.material_rolls where id=(roll->>'replaces_roll_id')::uuid for update;
     if old_roll.status='RETURNED_SUPPLIER'then raise exception 'CP7_RECEIPT_FIX_RETURN_ACTIVE';end if;
     use:=cp7_receipt_fix.roll_use(old_roll.id,h.location_id);
     if old_roll.material_id=mat.id then
      if (roll->>'qty')::numeric<(use->>'min_qty')::numeric then
       raise exception 'CP7_RECEIPT_FIX_ROLL_BELOW_USE roll % corrected % used %',old_roll.roll_number,roll->>'qty',use->>'min_qty';end if;
     else
      if (select material_type from erp.materials where id=old_roll.material_id)<>mat.material_type
       or (select unit_code from erp.materials where id=old_roll.material_id)<>mat.unit_code then raise exception 'CP7_RECEIPT_FIX_MATERIAL_KIND_CHANGED';end if;
      if not mat.is_active then raise exception 'CP7_RECEIPT_FIX_MATERIAL_INACTIVE';end if;
      if (use->>'movable')::boolean is distinct from true then raise exception 'CP7_RECEIPT_FIX_ROLL_USE_UNSUPPORTED roll %',old_roll.roll_number;end if;
      if (roll->>'qty')::numeric<(use->>'min_qty')::numeric then
       raise exception 'CP7_RECEIPT_FIX_ROLL_BELOW_USE roll % corrected % used %',old_roll.roll_number,roll->>'qty',use->>'min_qty';end if;
      if exists(select 1 from erp.material_rolls where material_id=mat.id and roll_number=btrim(roll->>'roll_number'))then
       raise exception 'CP7_RECEIPT_FIX_ROLL_NUMBER_TAKEN %',btrim(roll->>'roll_number');end if;
     end if;
    end if;
   end loop;
  else
   if jsonb_array_length(line->'rolls')<>0 or not line?'qty'then raise exception 'CP7_RECEIPT_FIX_NON_ROLL_QTY_REQUIRED';end if;
   perform cp7_procurement.decimal(line->'qty',true);
   if upper(coalesce(line->>'price_state',''))='FINAL'then corrected_total:=corrected_total+(line->>'qty')::numeric*(line->>'unit_price')::numeric;end if;
  end if;
 end loop;
 -- Roll numbers per material after the correction: unique in the document
 -- and against every other roll of that material. A roll kept on its own
 -- material keeps its identity (id, use, history); only a typed number may
 -- change, so numbers can also be swapped between kept rolls. A new or moved
 -- roll is created before the kept rolls are renumbered, so it may not take
 -- any number that exists now.
 with r as(select(l->>'material_id')::uuid m,btrim(z->>'roll_number')n,nullif(z->>'replaces_roll_id','')::uuid rid
   from jsonb_array_elements(p_payload->'lines')l cross join jsonb_array_elements(l->'rolls')z),
  kept as(select r.rid from r join erp.material_rolls x on x.id=r.rid and x.material_id=r.m)
 select string_agg(distinct r.n,', ')into tmp from r
  where(select count(*)from r r2 where r2.m=r.m and r2.n=r.n)>1
   or exists(select 1 from erp.material_rolls x where x.material_id=r.m and x.roll_number=r.n
    and not(coalesce(r.rid in(select rid from kept),false)and x.id in(select rid from kept)));
 if tmp is not null then raise exception 'CP7_RECEIPT_FIX_ROLL_NUMBER_TAKEN %',tmp;end if;
 -- The receipt (delivery-note) number as typed: a typo is corrected on the
 -- replacement and every later revision. The number of another receipt is
 -- a different document, never taken over here.
 base:=regexp_replace(h.purchase_number,' · R[0-9]+-[0-9a-f]{8}$','');
 if p_payload?'purchase_number'then
  if length(btrim(p_payload->>'purchase_number'))not between 1 and 40 then raise exception using errcode='22023',message='CP7_RECEIPT_FIX_PURCHASE_NUMBER_LENGTH';end if;
  if btrim(p_payload->>'purchase_number')<>base then
   base:=btrim(p_payload->>'purchase_number');
   if exists(select 1 from erp.material_purchase_headers x where(x.purchase_number=base or regexp_replace(x.purchase_number,' · R[0-9]+-[0-9a-f]{8}$','')=base)
     and x.id<>root and x.id not in(select replacement_purchase_id from cp7_receipt_fix.revisions where root_purchase_id=root))then
    raise exception 'CP7_RECEIPT_FIX_PURCHASE_NUMBER_TAKEN %',base;end if;
  end if;
 end if;
 -- Rolls the corrected document no longer contains must never have been used.
 for old_roll in select*from erp.material_rolls where id=any(coalesce(old_rolls,'{}'))and not(id=any(seen_rolls))order by id loop
  if (cp7_receipt_fix.roll_use(old_roll.id,h.location_id)->>'min_qty')::numeric>0
   or exists(select 1 from erp.material_stock_movements mm where mm.roll_id=old_roll.id and mm.reversal_of_id is null
    and mm.source_type not in('MATERIAL_PURCHASE_ROLL','MATERIAL_PURCHASE_ITEM')
    and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=mm.id))then
   raise exception 'CP7_RECEIPT_FIX_REMOVED_ROLL_USED roll %',old_roll.roll_number;end if;
 end loop;
 -- A roll used or moved before the corrected time, or used at all when the
 -- warehouse changes, contradicts its own history: refused by roll number.
 if moved then
  select string_agg(distinct r.roll_number,', ')into tmp from erp.material_rolls r where r.id=any(seen_rolls)
   and exists(select 1 from erp.material_stock_movements m where m.roll_id=r.id and m.reversal_of_id is null
    and m.source_type not in('MATERIAL_PURCHASE_ROLL','MATERIAL_PURCHASE_ITEM')
    and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=m.id)
    and(new_loc<>h.location_id or m.physical_at<new_at));
  if tmp is not null and new_loc<>h.location_id then raise exception 'CP7_RECEIPT_FIX_LOCATION_USED %',tmp;end if;
  if tmp is not null then raise exception 'CP7_RECEIPT_FIX_DATE_AFTER_USE %',tmp;end if;
 end if;
 -- Non-roll lines: what already left the receipt location after the receipt
 -- (transfer, issue) stays covered by the corrected quantity of that material
 -- at the corrected time; with another warehouse nothing may have left here.
 for mat in select i.material_id id,max(m.material_sku)sku,sum(i.qty)old_qty from erp.material_purchase_items i join erp.materials m on m.id=i.material_id
  where i.purchase_id=h.id and m.material_type<>'FABRIC'group by i.material_id order by i.material_id loop
  part:=coalesce((select sum((l->>'qty')::numeric)from jsonb_array_elements(p_payload->'lines')l
   where(l->>'material_id')::uuid=mat.id and jsonb_array_length(l->'rolls')=0),0);
  if cp7_receipt_fix.shifted_floor(mat.id,h.location_id,h.id,least(h.physical_at,new_at),new_at,case when new_loc=h.location_id then part else 0 end)<0 then
   if new_loc<>h.location_id then raise exception 'CP7_RECEIPT_FIX_LOCATION_USED %',mat.sku;end if;
   if new_at<>h.physical_at and part>=mat.old_qty then raise exception 'CP7_RECEIPT_FIX_DATE_AFTER_USE %',mat.sku;end if;
   raise exception 'CP7_RECEIPT_FIX_LINE_BELOW_USE % corrected % used %',mat.sku,part,
    mat.old_qty-greatest(cp7_receipt_fix.location_floor(mat.id,h.location_id,h.physical_at),0);end if;
 end loop;
 -- Another supplier: the debt and its payments move with the receipt. A
 -- supplier invoice shared with other receipts, or a payment from the old
 -- supplier's opening advance, belongs to the old supplier and is refused.
 if new_sup<>h.supplier_id then
  if exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id
    join erp.material_supplier_invoices v on v.id=l.invoice_id where v.status='POSTED'and i.purchase_id<>h.id
     and v.id in(select l2.invoice_id from erp.material_supplier_invoice_lines l2 join erp.material_purchase_items i2 on i2.id=l2.purchase_item_id where i2.purchase_id=h.id))then
   raise exception 'CP7_RECEIPT_FIX_SUPPLIER_SHARED_INVOICE';end if;
  if exists(select 1 from erp.supplier_payments p join erp.initial_import_prepayment_payments l on l.supplier_payment_id=p.id where p.purchase_id=h.id and p.status='POSTED')then
   raise exception 'CP7_RECEIPT_FIX_SUPPLIER_ADVANCE_PAYMENT';end if;
 end if;
 -- Every posted supplier invoice of the receipt is corrected with it: each of
 -- its lines is restated on the corrected receipt line that replaces its line.
 if cardinality(inv_ids)>0 and not p_payload?'invoices'then raise exception 'CP7_RECEIPT_FIX_INVOICE_DECISION_REQUIRED';end if;
 if(select coalesce(array_agg(x order by x),'{}')from(select(z->>'replaces_invoice_id')::uuid x from jsonb_array_elements(coalesce(p_payload->'invoices','[]'))z)q)
   is distinct from(select coalesce(array_agg(x order by x),'{}')from unnest(inv_ids)x)
  or(select count(distinct z->>'replaces_invoice_id')from jsonb_array_elements(coalesce(p_payload->'invoices','[]'))z)<>cardinality(inv_ids)
 then raise exception 'CP7_RECEIPT_FIX_INVOICE_SET';end if;
 for inv in select value from jsonb_array_elements(coalesce(p_payload->'invoices','[]'))loop
  if jsonb_typeof(inv)is distinct from'object'or not inv?&array['replaces_invoice_id','lines']
   or exists(select 1 from jsonb_object_keys(inv)k where k not in('replaces_invoice_id','lines','notes','invoice_number','invoice_date','due_date'))
   or nullif(inv->>'invoice_date','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'or nullif(inv->>'due_date','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
   or inv?'invoice_number'and length(btrim(inv->>'invoice_number'))not between 1 and 90
   or jsonb_typeof(inv->'lines')is distinct from'array'or jsonb_array_length(inv->'lines')not between 1 and 100
   or exists(select 1 from jsonb_each(inv)e where e.key<>'lines'and jsonb_typeof(e.value)not in('string','null'))
  then raise exception using errcode='22023',message='CP7_RECEIPT_FIX_FIELDS';end if;
  if(select coalesce(array_agg(x order by x),'{}')from(select(z->>'replaces_invoice_line_id')::uuid x from jsonb_array_elements(inv->'lines')z)q)
    is distinct from(select array_agg(l.id order by l.id)from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id
     where l.invoice_id=(inv->>'replaces_invoice_id')::uuid and i.purchase_id=h.id)
  then raise exception 'CP7_RECEIPT_FIX_INVOICE_LINE_SET';end if;
  -- A typed supplier invoice number is corrected on the re-posted invoice; the
  -- number of another invoice of the supplier is never taken over.
  select coalesce(nullif(btrim(inv->>'invoice_number'),''),regexp_replace(v.invoice_number,' · R[0-9]+$',''))into inv_base
  from erp.material_supplier_invoices v where v.id=(inv->>'replaces_invoice_id')::uuid;
  if exists(with recursive chain(id)as(select(inv->>'replaces_invoice_id')::uuid union select r.previous_invoice_id from cp7_receipt_fix.invoice_replays r join chain c on r.replacement_invoice_id=c.id)
    select 1 from erp.material_supplier_invoices x where x.supplier_id=new_sup and regexp_replace(x.invoice_number,' · R[0-9]+$','')=inv_base and x.id not in(select id from chain))then
   raise exception 'CP7_RECEIPT_FIX_INVOICE_NUMBER_TAKEN %',inv_base;end if;
  if nullif(inv->>'invoice_date','')::date>erp._cp3_business_date(statement_timestamp())then raise exception 'CP7_RECEIPT_FIX_DATE_FUTURE';end if;
  for il in select value from jsonb_array_elements(inv->'lines')loop
   if jsonb_typeof(il)is distinct from'object'or not il?&array['replaces_invoice_line_id','qty_invoiced','unit_price']
    or exists(select 1 from jsonb_object_keys(il)k where k not in('replaces_invoice_line_id','qty_invoiced','unit_price','discount_amount','notes'))
    or exists(select 1 from jsonb_each(il)e where jsonb_typeof(e.value)not in('string','null'))
   then raise exception using errcode='22023',message='CP7_RECEIPT_FIX_FIELDS';end if;
   perform cp7_procurement.decimal(il->'qty_invoiced',true);perform cp7_procurement.decimal(il->'unit_price',false);
   if nullif(il->>'discount_amount','')is not null then perform cp7_procurement.decimal(il->'discount_amount',false);end if;
   if coalesce(nullif(il->>'discount_amount','')::numeric,0)>(il->>'qty_invoiced')::numeric*(il->>'unit_price')::numeric then
    raise exception 'CP7_RECEIPT_FIX_INVOICE_DISCOUNT';end if;
   select l.purchase_item_id::text into tmp from erp.material_supplier_invoice_lines l where l.id=(il->>'replaces_invoice_line_id')::uuid;
   select value into line from jsonb_array_elements(p_payload->'lines')where value->>'replaces_item_id'=tmp;
   if line is null then raise exception 'CP7_RECEIPT_FIX_INVOICE_LINE_ORPHAN';end if;
   if upper(coalesce(line->>'price_state',''))='FINAL'then raise exception 'CP7_RECEIPT_FIX_INVOICED_LINE_ESTIMATE_REQUIRED';end if;
   invoiced:=jsonb_set(invoiced,array[tmp],to_jsonb(coalesce((invoiced->>tmp)::numeric,0)+(il->>'qty_invoiced')::numeric));
   corrected_total:=corrected_total+(il->>'qty_invoiced')::numeric*(il->>'unit_price')::numeric-coalesce(nullif(il->>'discount_amount','')::numeric,0);
  end loop;
 end loop;
 for line in select value from jsonb_array_elements(p_payload->'lines')where value->>'replaces_item_id'in(select jsonb_object_keys(invoiced))loop
  if(invoiced->>(line->>'replaces_item_id'))::numeric>(case when jsonb_array_length(line->'rolls')=0 then(line->>'qty')::numeric
    else(select sum((z->>'qty')::numeric)from jsonb_array_elements(line->'rolls')z)end)then
   raise exception 'CP7_RECEIPT_FIX_INVOICE_EXCEEDS_RECEIPT';end if;
 end loop;
 select coalesce(jsonb_agg(to_jsonb(p)||jsonb_build_object('advance_id',l.advance_id)order by p.payment_date,p.id),'[]')into paid from erp.supplier_payments p
  left join erp.initial_import_prepayment_payments l on l.supplier_payment_id=p.id where p.purchase_id=h.id and p.status='POSTED';
 select coalesce(sum((v->>'amount')::numeric),0)into paid_total from jsonb_array_elements(paid)v;
 excess:=greatest(paid_total-round(corrected_total,2),0);
 -- Paid more than the corrected total: the excess becomes supplier credit cut
 -- from other receipts (nota) of the same supplier, never a refund invented here.
 for credit in select value from jsonb_array_elements(coalesce(p_payload->'credit_allocations','[]'))loop
  if jsonb_typeof(credit)is distinct from'object'or not credit?&array['purchase_id','amount']
   or exists(select 1 from jsonb_object_keys(credit)k where k not in('purchase_id','amount'))
   or exists(select 1 from jsonb_each(credit)e where jsonb_typeof(e.value)<>'string')
   or credit->>'purchase_id'!~'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
  then raise exception using errcode='22023',message='CP7_RECEIPT_FIX_FIELDS';end if;
  perform cp7_procurement.decimal(credit->'amount',true);
  if (credit->>'amount')::numeric<>round((credit->>'amount')::numeric,2)then raise exception 'CP7_RECEIPT_FIX_CREDIT_CENTS';end if;
  if (credit->>'purchase_id')::uuid=h.id or(credit->>'purchase_id')in(select x->>'purchase_id'from jsonb_array_elements(credits)x)then
   raise exception 'CP7_RECEIPT_FIX_CREDIT_TARGET_INVALID';end if;
  credits:=credits||credit;
 end loop;
 if excess>0 and jsonb_array_length(credits)=0 then
  raise exception 'CP7_RECEIPT_FIX_CREDIT_ALLOCATION_REQUIRED paid % corrected % credit %',paid_total,round(corrected_total,2),excess;end if;
 if (select coalesce(sum((x->>'amount')::numeric),0)from jsonb_array_elements(credits)x)<>excess then
  raise exception 'CP7_RECEIPT_FIX_CREDIT_ALLOCATION_MISMATCH credit % allocated %',excess,(select coalesce(sum((x->>'amount')::numeric),0)from jsonb_array_elements(credits)x);end if;
 for target in select t.*from erp.material_purchase_headers t where t.id in(select(x->>'purchase_id')::uuid from jsonb_array_elements(credits)x)order by t.id for update loop
  if target.status<>'POSTED'or target.supplier_id is distinct from new_sup then raise exception 'CP7_RECEIPT_FIX_CREDIT_TARGET_INVALID';end if;
  if round(erp.material_purchase_payable_total(target.id),2)-coalesce((select sum(amount)from erp.supplier_payments where purchase_id=target.id and status='POSTED'),0)
   <(select(x->>'amount')::numeric from jsonb_array_elements(credits)x where(x->>'purchase_id')::uuid=target.id)then
   raise exception 'CP7_RECEIPT_FIX_CREDIT_TARGET_EXCEEDS_REMAINING %',target.purchase_number;end if;
 end loop;
 if (select count(*)from erp.material_purchase_headers t where t.id in(select(x->>'purchase_id')::uuid from jsonb_array_elements(credits)x))<>jsonb_array_length(credits)then
  raise exception 'CP7_RECEIPT_FIX_CREDIT_TARGET_INVALID';end if;

 -- Other receipts on the same supplier invoices: their lines are carried
 -- unchanged and their real payments move out and back at their own dates.
 select coalesce(array_agg(distinct i.purchase_id order by i.purchase_id),'{}')into related from erp.material_supplier_invoice_lines l
  join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=any(inv_ids)and i.purchase_id<>h.id;
 perform 1 from erp.material_purchase_headers where id=any(related)order by id for update;
 if exists(select 1 from erp.material_purchase_headers where id=any(related)and status<>'POSTED')then raise exception 'CP7_RECEIPT_FIX_INVOICE_SET';end if;
 select coalesce(jsonb_agg(to_jsonb(p)||jsonb_build_object('advance_id',l.advance_id)order by p.purchase_id,p.payment_date,p.id),'[]')into other_paid from erp.supplier_payments p
  left join erp.initial_import_prepayment_payments l on l.supplier_payment_id=p.id where p.purchase_id=any(related)and p.status='POSTED';
 -- Execute. Effects run under the receipt's own business date as economic
 -- date (accepted invoice-recost dating rules for revaluation/HPP/GL).
 insert into cp7_receipt_fix.context values(pg_backend_pid(),txid_current(),auth.uid(),h.id,related);
 insert into erp.invoice_recost_execution_context(transaction_id,invoice_date,source_id)values(txid_current(),erp._cp3_business_date(least(h.physical_at,new_at)),h.id);
 perform set_config('app.change_reason',why,true);
 perform cp7_receipt_fix.admit('POST');
 for payment in select*from jsonb_to_recordset(paid||other_paid)as p(id uuid)loop
  perform erp.reverse_supplier_payment(payment.id,'Benerin penerimaan: '||why);
 end loop;
 -- Supplier invoices: Native reversal, restated to their own economic dates.
 -- The Native writer owns its recost date context for this step.
 if cardinality(inv_ids)>0 then
  delete from erp.invoice_recost_execution_context where transaction_id=txid_current();
  foreach new_inv in array inv_ids loop
   perform cp7_receipt_fix.reverse_invoice(new_inv,'Benerin penerimaan: '||why,fix_id);
  end loop;
  insert into erp.invoice_recost_execution_context(transaction_id,invoice_date,source_id)values(txid_current(),erp._cp3_business_date(least(h.physical_at,new_at)),h.id);
 end if;
 -- Source-time inverse of every receipt stock movement (Native writer), with
 -- the accepted replacement admission for a temporarily used roll.
 perform set_config('erp.allow_source_replacement_negative','on',true);
 perform erp._stage_reverse_material_purchase_stock_at_source_time(h.id,'Benerin penerimaan: '||why);
 perform set_config('erp.allow_source_replacement_negative','off',true);
 update erp.material_purchase_headers set status='REVERSED',payment_status='UNPAID',updated_at=statement_timestamp()where id=h.id;
 -- Cutting use of a wrong-material roll, collected before the replacement.
 for line in select value from jsonb_array_elements(p_payload->'lines')loop
  for roll in select value from jsonb_array_elements(line->'rolls')loop
   if nullif(roll->>'replaces_roll_id','')is null then continue;end if;
   select*into old_roll from erp.material_rolls where id=(roll->>'replaces_roll_id')::uuid;
   if old_roll.material_id=(line->>'material_id')::uuid then continue;end if;
   for mv in select mm.*from erp.material_stock_movements mm where mm.roll_id=old_roll.id and mm.reversal_of_id is null
    and mm.source_type in('CUTTING_GROUP','CUTTING_GROUP_RETURN')
    and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=mm.id)
    order by mm.physical_at,mm.system_created_at,mm.id for update loop
    pending:=pending||jsonb_build_object('movement',mv.id,'old_roll',old_roll.id,'old_material',old_roll.material_id,
     'roll_number',btrim(roll->>'roll_number'),'material',line->>'material_id');
   end loop;
  end loop;
 end loop;

 -- Replacement document through the accepted Native draft writer. Rolls of the
 -- same material are re-attached below; their placeholder draft rows exist only
 -- inside this transaction and never receive stock.
 -- Each replacement line gets its item id up front (one per payload position),
 -- so the line map below is exact.
 item_ids:=array(select gen_random_uuid()from jsonb_array_elements(p_payload->'lines'));
 draft:=jsonb_build_object('purchase_number',left(base,40)||' · R'||rev_no::text||'-'||left(p_request::text,8),
  'supplier_id',new_sup,'location_id',new_loc,'physical_at',new_at,
  'notes',coalesce(nullif(p_payload->>'notes',''),h.notes),
  'supplier_invoice_number',h.supplier_invoice_number,'due_date',h.due_date,
  'change_reason','Benerin penerimaan '||h.purchase_number||': '||why,
  'lines',(select jsonb_agg(jsonb_build_object('id',item_ids[o::integer],'material_id',l->>'material_id','unit_price',l->>'unit_price','price_state',l->>'price_state',
    'price_source',l->>'price_source',
    -- A line keeps its own lot and notes unless the payload states them.
    'lot_number',case when l?'lot_number'then l->>'lot_number'else(select x.lot_number from erp.material_purchase_items x where x.id=nullif(l->>'replaces_item_id','')::uuid)end,
    'notes',case when l?'notes'then l->>'notes'else(select x.notes from erp.material_purchase_items x where x.id=nullif(l->>'replaces_item_id','')::uuid)end)
   ||case when jsonb_array_length(l->'rolls')=0 then jsonb_build_object('qty',l->>'qty')
     else jsonb_build_object('qty',(select sum((z->>'qty')::numeric)::text from jsonb_array_elements(l->'rolls')z),
      'rolls',(select jsonb_agg(jsonb_build_object('roll_number',case when nullif(z->>'replaces_roll_id','')is not null
        and(select material_id from erp.material_rolls where id=(z->>'replaces_roll_id')::uuid)=(l->>'material_id')::uuid
       then '__CP7FIX-'||(z->>'replaces_roll_id')else btrim(z->>'roll_number')end,'qty',z->>'qty','notes',z->>'notes')order by o2)
       from jsonb_array_elements(l->'rolls')with ordinality q(z,o2)))end order by o)
   from jsonb_array_elements(p_payload->'lines')with ordinality t(l,o)));
 perform cp7_receipt_fix.admit('SAVE_DRAFT');
 result:=erp.save_material_purchase_draft_v2(draft,md5(auth.uid()::text||':RECEIPT_FIX:'||p_request::text)::uuid,null);
 replaced:=(result->>'purchase_id')::uuid;
 -- Map draft lines to payload lines exactly by the item id written for each
 -- payload position, so two lines with the same material, quantity and price
 -- keep their own lot and notes.
 line_no:=0;
 for line in select value from jsonb_array_elements(p_payload->'lines')loop
  line_no:=line_no+1;
  new_item:=item_ids[line_no];
  if not exists(select 1 from erp.material_purchase_items where id=new_item and purchase_id=replaced)then
   raise exception 'CP7_RECEIPT_FIX_DRAFT_LINE_MAPPING';end if;
  if nullif(line->>'replaces_item_id','')is not null then old_new:=old_new||jsonb_build_object(line->>'replaces_item_id',new_item);end if;
  for roll in select value from jsonb_array_elements(line->'rolls')loop
   if nullif(roll->>'replaces_roll_id','')is not null then
    select*into old_roll from erp.material_rolls where id=(roll->>'replaces_roll_id')::uuid;
    if old_roll.material_id=(line->>'material_id')::uuid then
     delete from erp.material_rolls where purchase_item_id=new_item and roll_number='__CP7FIX-'||old_roll.id::text;
     if not found then raise exception 'CP7_RECEIPT_FIX_DRAFT_ROLL_MAPPING';end if;
     -- A typed roll number moves through a private temporary number, so
     -- numbers can be swapped between rolls of this receipt.
     update erp.material_rolls set purchase_item_id=new_item,original_qty=(roll->>'qty')::numeric,
      roll_number=case when btrim(roll->>'roll_number')<>old_roll.roll_number then '__CP7FIX-RN-'||old_roll.id::text else roll_number end,
      supplier_id=new_sup,received_at=case when new_at<>h.physical_at then new_at else received_at end,
      notes=coalesce(nullif(roll->>'notes',''),notes),updated_at=statement_timestamp()where id=old_roll.id;
     lineage:=lineage||jsonb_build_object('kind','REPARENTED','old_roll_id',old_roll.id,'new_roll_id',old_roll.id,'old_material_id',old_roll.material_id,
      'new_material_id',old_roll.material_id,'old_purchase_item_id',old_roll.purchase_item_id,'new_purchase_item_id',new_item,
      'old_qty',old_roll.original_qty,'new_qty',(roll->>'qty')::numeric,'roll_number',btrim(roll->>'roll_number'),'previous_roll_number',old_roll.roll_number);
    else
     select id into new_roll from erp.material_rolls where purchase_item_id=new_item and roll_number=btrim(roll->>'roll_number');
     lineage:=lineage||jsonb_build_object('kind','MATERIAL_MOVED','old_roll_id',old_roll.id,'new_roll_id',new_roll,'old_material_id',old_roll.material_id,
      'new_material_id',(line->>'material_id')::uuid,'old_purchase_item_id',old_roll.purchase_item_id,'new_purchase_item_id',new_item,
      'old_qty',old_roll.original_qty,'new_qty',(roll->>'qty')::numeric,'roll_number',btrim(roll->>'roll_number'),'previous_roll_number',old_roll.roll_number);
    end if;
   else
    select id into new_roll from erp.material_rolls where purchase_item_id=new_item and roll_number=btrim(roll->>'roll_number');
    lineage:=lineage||jsonb_build_object('kind','ADDED','new_roll_id',new_roll,'new_material_id',(line->>'material_id')::uuid,
     'new_purchase_item_id',new_item,'new_qty',(roll->>'qty')::numeric,'roll_number',btrim(roll->>'roll_number'));
   end if;
  end loop;
 end loop;
 for old_roll in select*from erp.material_rolls where id=any(coalesce(old_rolls,'{}'))and not(id=any(seen_rolls))order by id loop
  lineage:=lineage||jsonb_build_object('kind','REMOVED','old_roll_id',old_roll.id,'old_material_id',old_roll.material_id,
   'old_purchase_item_id',old_roll.purchase_item_id,'old_qty',old_roll.original_qty,'roll_number',old_roll.roll_number);
 end loop;
 update erp.material_rolls r set roll_number=x.roll_number,updated_at=statement_timestamp()
 from jsonb_to_recordset(lineage)as x(kind text,old_roll_id uuid,roll_number text,previous_roll_number text)
 where x.kind='REPARENTED'and r.id=x.old_roll_id and x.roll_number<>x.previous_roll_number;
 -- Native posting of the replacement at the original physical time.
 perform cp7_receipt_fix.admit('POST');
 perform erp.post_material_purchase(replaced);
 -- The same cutting use, at its own time, now reads the right-material roll.
 for mv in select*from jsonb_to_recordset(pending)as p(movement uuid,old_roll uuid,old_material uuid,roll_number text,material uuid)loop
  select r4.id into new_roll from erp.material_rolls r4 join erp.material_purchase_items i on i.id=r4.purchase_item_id
   where i.purchase_id=replaced and r4.material_id=mv.material and r4.roll_number=mv.roll_number;
  if new_roll is null then raise exception 'CP7_RECEIPT_FIX_DRAFT_ROLL_MAPPING';end if;
  update erp.material_stock_movements set material_id=mv.material,roll_id=new_roll where id=mv.movement
   returning qty_signed,physical_at,source_type,source_id into mat;
  insert into cp7_receipt_fix.movement_lineage(movement_id,correction_id,old_material_id,old_roll_id,new_material_id,new_roll_id,qty_signed,physical_at,source_type,source_id)
  values(mv.movement,fix_id,mv.old_material,mv.old_roll,mv.material,new_roll,mat.qty_signed,mat.physical_at,mat.source_type,mat.source_id);
  if mat.source_type='CUTTING_GROUP'then
   update erp.cutting_group_rolls set roll_id=new_roll where cutting_group_id=mat.source_id and roll_id=mv.old_roll;
  end if;
 end loop;
 -- Group the source-time receipt inverse and the corrected receipt row of the
 -- same physical roll/line under the original card row (root of all revisions).
 insert into cp7_receipt_fix.ledger_links(member_id,origin_id,correction_id)
 select rv.id,coalesce(l.origin_id,o.id),fix_id from erp.material_stock_movements rv
  join erp.material_stock_movements o on o.id=rv.reversal_of_id
  left join cp7_receipt_fix.ledger_links l on l.member_id=o.id
 where rv.source_type='MATERIAL_PURCHASE_REVERSAL'and o.movement_type='PURCHASE'
  and(o.source_type='MATERIAL_PURCHASE_ROLL'and o.source_id=any(coalesce(old_rolls,'{}'))
   or o.source_type='MATERIAL_PURCHASE_ITEM'and o.source_id=any(coalesce(old_items,'{}')))
  and not exists(select 1 from cp7_receipt_fix.ledger_links z where z.member_id=rv.id);
 insert into cp7_receipt_fix.ledger_links(member_id,origin_id,correction_id)
 select p.id,(select coalesce(l.origin_id,o.id)from erp.material_stock_movements o left join cp7_receipt_fix.ledger_links l on l.member_id=o.id
   where o.movement_type='PURCHASE'and o.source_type='MATERIAL_PURCHASE_ROLL'and o.source_id=p.source_id and o.id<>p.id
   order by o.system_created_at,o.id limit 1),fix_id
 from erp.material_stock_movements p join erp.material_rolls r6 on r6.id=p.source_id
  join erp.material_purchase_items i6 on i6.id=r6.purchase_item_id
 where p.movement_type='PURCHASE'and p.source_type='MATERIAL_PURCHASE_ROLL'and i6.purchase_id=replaced
  and r6.id=any(seen_rolls)and r6.id=any(coalesce(old_rolls,'{}'))and not moved
  and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=p.id)
  and not exists(select 1 from cp7_receipt_fix.ledger_links z where z.member_id=p.id);
 for line in select value from jsonb_array_elements(p_payload->'lines')loop
  if moved or nullif(line->>'replaces_item_id','')is null or jsonb_array_length(line->'rolls')>0
   or(select material_id from erp.material_purchase_items where id=(line->>'replaces_item_id')::uuid)<>(line->>'material_id')::uuid then continue;end if;
  insert into cp7_receipt_fix.ledger_links(member_id,origin_id,correction_id)
  select p.id,(select coalesce(l.origin_id,o.id)from erp.material_stock_movements o left join cp7_receipt_fix.ledger_links l on l.member_id=o.id
    where o.movement_type='PURCHASE'and o.source_type='MATERIAL_PURCHASE_ITEM'and o.source_id=(line->>'replaces_item_id')::uuid limit 1),fix_id
  from erp.material_stock_movements p where p.movement_type='PURCHASE'and p.source_type='MATERIAL_PURCHASE_ITEM'
   and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=p.id)
   and p.source_id=(old_new->>(line->>'replaces_item_id'))::uuid;
 end loop;
 -- Chronological recost of every affected material from the receipt time. A
 -- material whose cutting use moved to the right material is rebuilt first and
 -- completely, so its derived history releases the moved rows before the right
 -- material replays them.
 for mat in select x.id from erp.materials x where x.id=any(mat_ids)
  order by(x.id in(select(z->>'old_material')::uuid from jsonb_array_elements(pending)z))desc,x.id loop
  if mat.id in(select(z->>'old_material')::uuid from jsonb_array_elements(pending)z)then
   perform erp._recalculate_material_cost_core(mat.id,least(h.physical_at,new_at),false);
  else
   perform erp.recalculate_material_cost(mat.id,least(h.physical_at,new_at));
  end if;
 end loop;
 delete from erp.invoice_recost_execution_context where transaction_id=txid_current();
 -- The original purchase journal inverse, restated to its original economic date.
 select id into rev_id from erp.journal_entries where source_type='MATERIAL_PURCHASE'and source_id=h.id and status='POSTED'order by posting_at desc,id desc limit 1;
 if rev_id is not null then perform erp.reverse_journal(rev_id,'Benerin penerimaan: '||why);end if;
 perform cp7_receipt_fix.restate_all(why);
 -- Corrected supplier invoices, posted by the Native writer at their own
 -- invoice/book date on the corrected receipt lines.
 for inv in select value from jsonb_array_elements(coalesce(p_payload->'invoices','[]'))
  order by(select array_position(inv_ids,(value->>'replaces_invoice_id')::uuid))loop
  select coalesce(jsonb_agg(jsonb_build_object('purchase_item_id',old_new->>l.purchase_item_id::text,'qty_invoiced',il2->>'qty_invoiced',
    'unit_price',il2->>'unit_price','discount_amount',coalesce(nullif(il2->>'discount_amount',''),'0'),'notes',coalesce(nullif(il2->>'notes',''),l.notes))order by l.id),'[]')
  into inv_lines from jsonb_array_elements(inv->'lines')il2 join erp.material_supplier_invoice_lines l on l.id=(il2->>'replaces_invoice_line_id')::uuid;
  inv_lines:=inv_lines||(select coalesce(jsonb_agg(jsonb_build_object('purchase_item_id',l.purchase_item_id,'qty_invoiced',l.qty_invoiced::text,'unit_price',l.unit_price::text,
    'discount_amount',l.discount_amount::text,'notes',l.notes)order by l.id),'[]')from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id
   where l.invoice_id=(inv->>'replaces_invoice_id')::uuid and i.purchase_id<>h.id);
  -- Supplier invoice numbers are unique per supplier, reversed ones included:
  -- the next free revision suffix of the same base number (a shared invoice
  -- can already carry one from another receipt's correction).
  select left(coalesce(nullif(btrim(inv->>'invoice_number'),''),regexp_replace(v.invoice_number,' · R[0-9]+$','')),90)into inv_base
  from erp.material_supplier_invoices v where v.id=(inv->>'replaces_invoice_id')::uuid;
  select jsonb_build_object('invoice_number',inv_base||' · R'||(select coalesce(max((regexp_match(x.invoice_number,' · R([0-9]+)$'))[1]::bigint),0)+1
    from erp.material_supplier_invoices x where x.supplier_id=new_sup and regexp_replace(x.invoice_number,' · R[0-9]+$','')=inv_base)::text,'supplier_id',new_sup,
    -- Invoice date and due date as typed on the supplier invoice; the Native
    -- writer posts the corrected invoice at its corrected book date.
    'invoice_date',coalesce(nullif(inv->>'invoice_date','')::date,v.invoice_date),'received_at',v.received_at,
    'due_date',case when inv?'due_date'then nullif(inv->>'due_date','')::date else v.due_date end,'notes',coalesce(nullif(inv->>'notes',''),v.notes),
    'change_reason','Benerin penerimaan '||h.purchase_number||': '||why,'lines',inv_lines)into draft
  from erp.material_supplier_invoices v where v.id=(inv->>'replaces_invoice_id')::uuid;
  result:=erp.save_material_supplier_invoice_draft_v2(draft,md5(auth.uid()::text||':RECEIPT_FIX_INVOICE:'||p_request::text||':'||(inv->>'replaces_invoice_id'))::uuid,null);
  new_inv:=(result->>'supplier_invoice_id')::uuid;
  perform erp.post_material_supplier_invoice_v2(new_inv,md5(auth.uid()::text||':RECEIPT_FIX_INVOICE_POST:'||p_request::text||':'||(inv->>'replaces_invoice_id'))::uuid,
   (result->>'row_version')::bigint,'Benerin penerimaan: '||why);
  insert into cp7_receipt_fix.invoice_replays(previous_invoice_id,replacement_invoice_id,correction_id,previous_lines,corrected_lines)
  values((inv->>'replaces_invoice_id')::uuid,new_inv,fix_id,
   (select jsonb_agg(jsonb_build_object('invoice_line_id',l.id,'purchase_item_id',l.purchase_item_id,'qty_invoiced',l.qty_invoiced::text,'unit_price',l.unit_price::text,
     'discount_amount',l.discount_amount::text)order by l.id)from erp.material_supplier_invoice_lines l where l.invoice_id=(inv->>'replaces_invoice_id')::uuid),
   (select jsonb_agg(jsonb_build_object('invoice_line_id',l.id,'purchase_item_id',l.purchase_item_id,'qty_invoiced',l.qty_invoiced::text,'unit_price',l.unit_price::text,
     'discount_amount',l.discount_amount::text)order by l.id)from erp.material_supplier_invoice_lines l where l.invoice_id=new_inv));
 end loop;
 left_on_receipt:=round(erp.material_purchase_payable_total(replaced),2);
 if greatest(paid_total-left_on_receipt,0)<>excess then
  raise exception 'CP7_RECEIPT_FIX_CREDIT_ALLOCATION_MISMATCH credit % allocated %',greatest(paid_total-left_on_receipt,0),excess;end if;
 -- Replay every real supplier payment at its own date, cash account and
 -- amount: on the corrected receipt up to its payable, the rest as credit on
 -- the chosen receipts of the same supplier.
 queue:=credits;
 for pay in select value from jsonb_array_elements(paid)loop
  part:=least((pay->>'amount')::numeric,left_on_receipt);
  if part>0 then
   piece:=piece+1;
   new_payment:=cp7_receipt_fix.replay_payment(replaced,pay,part,left(pay->>'payment_number',36)||' · K'||piece::text||'-'||left(p_request::text,8),pay->>'notes');
   insert into cp7_receipt_fix.payment_replays(replacement_payment_id,previous_payment_id,correction_id,target_purchase_id,kind,amount)
   values(new_payment,(pay->>'id')::uuid,fix_id,replaced,'CORRECTED_RECEIPT',part);
   left_on_receipt:=left_on_receipt-part;
  end if;
  part:=(pay->>'amount')::numeric-part;
  while part>0 loop
   credit:=queue->0;
   if credit is null then raise exception 'CP7_RECEIPT_FIX_CREDIT_ALLOCATION_MISMATCH';end if;
   piece:=piece+1;
   begin
    new_payment:=cp7_receipt_fix.replay_payment((credit->>'purchase_id')::uuid,pay,least(part,(credit->>'amount')::numeric),
     left(pay->>'payment_number',36)||' · K'||piece::text||'-'||left(p_request::text,8),
     left('Retur bayangan dari pembetulan penerimaan '||h.purchase_number||': barang tidak pernah diterima; kelebihan bayar dipotong ke nota ini. '||why,1000));
   exception when raise_exception then
    -- Native refusals of this piece, named for the chosen nota.
    if sqlerrm like 'Supplier payment exceeds remaining payable%'then
     raise exception 'CP7_RECEIPT_FIX_CREDIT_TARGET_EXCEEDS_REMAINING %',(select purchase_number from erp.material_purchase_headers where id=(credit->>'purchase_id')::uuid);end if;
    if sqlerrm like 'Tanggal pemakaian uang muka%'then
     raise exception 'CP7_RECEIPT_FIX_CREDIT_TARGET_AFTER_ADVANCE_USE %',(select purchase_number from erp.material_purchase_headers where id=(credit->>'purchase_id')::uuid);end if;
    raise;
   end;
   insert into cp7_receipt_fix.payment_replays(replacement_payment_id,previous_payment_id,correction_id,target_purchase_id,kind,amount)
   values(new_payment,(pay->>'id')::uuid,fix_id,(credit->>'purchase_id')::uuid,'CREDIT_TO_OTHER_RECEIPT',least(part,(credit->>'amount')::numeric));
   if part>=(credit->>'amount')::numeric then part:=part-(credit->>'amount')::numeric;queue:=queue-0;
   else queue:=jsonb_set(queue,'{0,amount}',to_jsonb(((credit->>'amount')::numeric-part)::text));part:=0;end if;
  end loop;
 end loop;
 if jsonb_array_length(queue)<>0 then raise exception 'CP7_RECEIPT_FIX_CREDIT_ALLOCATION_MISMATCH';end if;
 -- Payments of the other receipts of a shared invoice, back on the same receipt.
 for pay in select value from jsonb_array_elements(other_paid)loop
  piece:=piece+1;
  new_payment:=cp7_receipt_fix.replay_payment((pay->>'purchase_id')::uuid,pay,(pay->>'amount')::numeric,
   left(pay->>'payment_number',36)||' · K'||piece::text||'-'||left(p_request::text,8),pay->>'notes');
  insert into cp7_receipt_fix.payment_replays(replacement_payment_id,previous_payment_id,correction_id,target_purchase_id,kind,amount)
  values(new_payment,(pay->>'id')::uuid,fix_id,(pay->>'purchase_id')::uuid,'SHARED_INVOICE_RECEIPT',(pay->>'amount')::numeric);
 end loop;
 perform cp7_receipt_fix.admit(null);
 delete from erp.invoice_recost_execution_context where transaction_id=txid_current();
 if cp7_receipt_fix.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_RECEIPT_FIX_ACCESS_CHANGED';end if;
 select jsonb_build_object('purchase_number',(select purchase_number from erp.material_purchase_headers where id=replaced),
  'physical_at',new_at,'location_id',new_loc,'supplier_id',new_sup,
  'supplier_invoice_number',(select supplier_invoice_number from erp.material_purchase_headers where id=replaced),
  'due_date',(select due_date from erp.material_purchase_headers where id=replaced),'notes',(select notes from erp.material_purchase_headers where id=replaced),'lines',coalesce(jsonb_agg(jsonb_build_object('item_id',i.id,'material_id',i.material_id,
  'qty',i.qty::text,'unit_price',i.unit_price::text,'price_state',i.price_state,'price_source',i.price_source,
  'rolls',(select coalesce(jsonb_agg(jsonb_build_object('roll_id',r5.id,'roll_number',r5.roll_number,'qty',r5.original_qty::text)order by r5.roll_number,r5.id),'[]')
   from erp.material_rolls r5 where r5.purchase_item_id=i.id))order by i.id),'[]'))into corrected_doc
 from erp.material_purchase_items i where i.purchase_id=replaced;
 corrected_doc:=corrected_doc||jsonb_build_object('invoices',(select coalesce(jsonb_agg(jsonb_build_object('invoice_id',v.id,'invoice_number',v.invoice_number,
  'invoice_date',v.invoice_date,'replaces_invoice_id',x.previous_invoice_id,'lines',x.corrected_lines)order by v.invoice_date,v.posted_at,v.id),'[]')
  from cp7_receipt_fix.invoice_replays x join erp.material_supplier_invoices v on v.id=x.replacement_invoice_id where x.correction_id=fix_id));
 insert into cp7_receipt_fix.revisions(id,root_purchase_id,previous_purchase_id,replacement_purchase_id,revision,actor,request_id,reason,effective_at,previous_document,corrected_document)
 values(fix_id,root,h.id,replaced,rev_no,auth.uid(),p_request,why,new_at,previous_doc,corrected_doc);
 insert into cp7_receipt_fix.roll_lineage(correction_id,kind,old_roll_id,new_roll_id,old_material_id,new_material_id,old_purchase_item_id,new_purchase_item_id,old_qty,new_qty,roll_number,previous_roll_number)
 select fix_id,x.kind,x.old_roll_id,x.new_roll_id,x.old_material_id,x.new_material_id,x.old_purchase_item_id,x.new_purchase_item_id,x.old_qty,x.new_qty,x.roll_number,x.previous_roll_number
 from jsonb_to_recordset(lineage)as x(kind text,old_roll_id uuid,new_roll_id uuid,old_material_id uuid,new_material_id uuid,old_purchase_item_id uuid,
  new_purchase_item_id uuid,old_qty numeric,new_qty numeric,roll_number text,previous_roll_number text);
 insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)
 values('material_purchase_headers',h.id,'REVERSE',jsonb_build_object('receipt_correction_id',fix_id,'replacement_purchase_id',replaced),erp.current_app_user_id(),why);
 delete from cp7_receipt_fix.context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 result:=jsonb_build_object('contract_version','cp7.receipt-correction-outcome.v1','kind','COMMITTED_OUTCOME','action','CORRECT',
  'request_id',p_request,'root_purchase_id',root,'previous_purchase_id',h.id,'purchase_id',replaced,
  'revision_id',fix_id,'revision',rev_no::text,'effective_at',new_at,
  'row_version',(select row_version::text from erp.material_purchase_headers where id=replaced));
 update cp7_receipt_fix.requests set response=result where actor=auth.uid()and request_id=p_request;
 return result;
end $$;

do $own$
declare f text;
begin
 foreach f in array array['immutable()','access_now()','admit(text)','review_token(uuid)','roll_use(uuid,uuid)','blockers(uuid)','workspace(uuid)',
  'location_floor(uuid,uuid,timestamptz)','shifted_floor(uuid,uuid,uuid,timestamptz,timestamptz,numeric)','restate(uuid,text)','restate_all(text)','journal_net(uuid[])','reverse_invoice(uuid,text,uuid)','payment_snapshot(uuid)',
  'replay_payment(uuid,jsonb,numeric,text,text)','command(jsonb,uuid,text)']loop
  execute 'alter function cp7_receipt_fix.'||f||' owner to postgres';
 end loop;
end $own$;
-- Exact private composition: postgres owns this command's metadata and writes
-- the procurement admission row only for its own transaction.
grant usage on schema cp7_procurement to postgres;
grant execute on function cp7_procurement.decimal(jsonb,boolean)to postgres;
grant select,insert,delete on cp7_procurement.execution_context to postgres;
revoke all on all functions in schema cp7_receipt_fix from public,anon,authenticated,service_role,cp7_capture,cp7_procure_read,cp7_procure_write;
grant usage on schema cp7_receipt_fix to cp7_procure_write;
grant execute on function cp7_receipt_fix.workspace(uuid),cp7_receipt_fix.command(jsonb,uuid,text)to cp7_procure_write;
create function public.erp_cp7_get_receipt_correction_v1(p_purchase uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_receipt_fix.workspace(p_purchase)$$;
create function public.erp_cp7_correct_receipt_v1(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_receipt_fix.command(p_payload,p_request,p_expected)$$;
grant create on schema public to cp7_procure_write;
alter function public.erp_cp7_get_receipt_correction_v1(uuid)owner to cp7_procure_write;
alter function public.erp_cp7_correct_receipt_v1(jsonb,uuid,text)owner to cp7_procure_write;
revoke create on schema public from cp7_procure_write;
revoke all on function public.erp_cp7_get_receipt_correction_v1(uuid),public.erp_cp7_correct_receipt_v1(jsonb,uuid,text)from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_get_receipt_correction_v1(uuid),public.erp_cp7_correct_receipt_v1(jsonb,uuid,text)to authenticated;

-- Material card v2: the same scope, access and money projection as v1, with
-- corrected receipt rows grouped under their original card row. Running
-- quantity is the complete chronological prefix of effective rows computed
-- before paging; raw immutable members stay inspectable.
create function cp7_receipt_fix.ledger(p_material uuid,p_roll uuid,p_location uuid,p_offset integer,p_limit integer)returns jsonb
language plpgsql stable security invoker set search_path=''as $$
declare a jsonb;rows jsonb;total bigint;
begin
 a:=cp7_material.access_now();
 if p_material is null or p_location is null or p_offset is null or p_offset not between 0 and 1000000
  or p_limit is null or p_limit not between 1 and 100 then raise exception 'CP7_MATERIAL_LEDGER_SCOPE';end if;
 if not exists(select 1 from erp.materials m where m.id=p_material and((m.material_type='FABRIC'and exists(select 1 from erp.material_rolls r where r.id=p_roll and r.material_id=m.id))
   or(m.material_type<>'FABRIC'and p_roll is null)))
  or not exists(select 1 from erp.locations where id=p_location)then raise exception 'CP7_MATERIAL_LEDGER_SCOPE';end if;
 with base as(
  select sm.*,coalesce(l.origin_id,sm.id)origin from erp.material_stock_movements sm left join cp7_receipt_fix.ledger_links l on l.member_id=sm.id
  where sm.material_id=p_material and sm.roll_id is not distinct from p_roll and sm.location_id=p_location and sm.physical_at<=statement_timestamp()
 ),grouped as(
  select b.origin,sum(b.qty_signed)effective_qty,count(*)-1 correction_count,max(b.system_created_at)last_recorded_at,
   jsonb_agg(jsonb_build_object('movement_id',b.id,'qty_signed',b.qty_signed::text,'movement_type',b.movement_type,'recorded_at',b.system_created_at,
    'physical_at',b.physical_at,'source_type',b.source_type,'reversal_of_id',b.reversal_of_id,'note',b.note)order by b.system_created_at,b.id)members
  from base b group by b.origin
 ),effective as(
  select o.*,g.effective_qty,g.correction_count,g.last_recorded_at,g.members,
   (select x.unit_cost_snapshot from base x where x.origin=o.id and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=x.id)and x.reversal_of_id is null
     order by x.system_created_at desc,x.id desc limit 1)effective_unit_cost,
   sum(g.effective_qty)over(order by o.physical_at,o.system_created_at,o.id rows unbounded preceding)running_qty
  from grouped g join erp.material_stock_movements o on o.id=g.origin
 ),paged as(select*from effective order by physical_at desc,system_created_at desc,id desc limit p_limit offset p_offset)
 select(select count(*)from effective),coalesce(jsonb_agg(jsonb_build_object('movement_id',x.id,'physical_at',x.physical_at,'recorded_at',x.system_created_at,
  'movement_type',x.movement_type,'qty_signed',x.effective_qty::text,'original_qty_signed',x.qty_signed::text,'running_qty',x.running_qty::text,
  'correction_count',x.correction_count::text,'last_correction_recorded_at',case when x.correction_count>0 then x.last_recorded_at end,
  'corrections',case when x.correction_count>0 then x.members else '[]'::jsonb end,
  'source_type',x.source_type,'source_id',x.source_id,'reversal_of_id',x.reversal_of_id,'note',x.note)
  ||case when(a->>'can_value')::boolean then jsonb_build_object('valuation',jsonb_build_object('state',case when coalesce(x.effective_unit_cost,x.unit_cost_snapshot)is null then 'UNKNOWN'else 'KNOWN'end,
   'unit_cost',coalesce(x.effective_unit_cost,x.unit_cost_snapshot)::text,'movement_value',round(x.effective_qty*coalesce(x.effective_unit_cost,x.unit_cost_snapshot),6)::text,'basis','CURRENT_RESTATED_MOVEMENT_COST'))else '{}'::jsonb end
  order by x.physical_at desc,x.system_created_at desc,x.id desc),'[]'::jsonb)into total,rows from paged x;
 return jsonb_build_object('contract_version','cp7.material-ledger.v2','material_id',p_material,'roll_id',p_roll,'location_id',p_location,
  'read_at',statement_timestamp(),'financial_captured',a->'can_value','history_basis','CORRECTED_EFFECTIVE_ROWS_CURRENT_RESTATED',
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',p_offset,'limit',p_limit,'next_offset',case when p_offset+jsonb_array_length(rows)<total then p_offset+jsonb_array_length(rows)else null end));
end $$;
grant usage on schema cp7_receipt_fix to cp7_material_read;
grant select on cp7_receipt_fix.ledger_links to cp7_material_read;
grant create on schema cp7_receipt_fix,public to cp7_material_read;
alter function cp7_receipt_fix.ledger(uuid,uuid,uuid,integer,integer)owner to cp7_material_read;
create function public.erp_cp7_get_material_ledger_v2(p_material uuid,p_roll uuid,p_location uuid,p_offset integer,p_limit integer)returns jsonb
language sql stable security definer set search_path=''as $$select cp7_receipt_fix.ledger(p_material,p_roll,p_location,p_offset,p_limit)$$;
alter function public.erp_cp7_get_material_ledger_v2(uuid,uuid,uuid,integer,integer)owner to cp7_material_read;
revoke create on schema cp7_receipt_fix,public from cp7_material_read;
revoke all on function cp7_receipt_fix.ledger(uuid,uuid,uuid,integer,integer)from public,anon,authenticated,service_role,cp7_capture;
revoke all on function public.erp_cp7_get_material_ledger_v2(uuid,uuid,uuid,integer,integer)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_material_ledger_v2(uuid,uuid,uuid,integer,integer)to authenticated;

-- "Benerin nama bahan": a typo in a material's name or code (SKU) is fixed on
-- the same material. Only material_name/material_sku change; type, unit,
-- accessory category, active state, stock, cost and every roll/movement keep
-- their identity and history. A receipt recorded under a different material is not a typo: it is
-- corrected with "Benerin penerimaan" (wrong material A -> B).
create table cp7_receipt_fix.name_requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,expected_version text not null,
 response jsonb,primary key(actor,request_id)
);
create table cp7_receipt_fix.material_names(
 id uuid primary key default gen_random_uuid(),
 material_id uuid not null references erp.materials,
 previous_name text not null,corrected_name text not null,previous_sku text not null,corrected_sku text not null,reason text not null,
 actor uuid not null,request_id uuid not null,recorded_at timestamptz not null default clock_timestamp(),
 unique(actor,request_id)
);
create index receipt_fix_material_names on cp7_receipt_fix.material_names(material_id,recorded_at);
do $own$
declare t text;
begin
 foreach t in array array['name_requests','material_names']loop
  execute format('alter table cp7_receipt_fix.%I owner to postgres',t);
  execute format('alter table cp7_receipt_fix.%I enable row level security',t);
  execute format('create policy private_%s on cp7_receipt_fix.%I for all using(false)with check(false)',t,t);
 end loop;
end $own$;
revoke all on cp7_receipt_fix.name_requests,cp7_receipt_fix.material_names from public,anon,authenticated,service_role,cp7_capture;
create trigger immutable_material_name before update or delete on cp7_receipt_fix.material_names for each row execute function cp7_receipt_fix.immutable();

-- Current authority for one material: OWNER/ADMIN with the master permission
-- of the material's own kind.
create function cp7_receipt_fix.name_access(p_type text)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;
begin
 if auth.uid()is null or coalesce(auth.jwt()->>'role','')<>'authenticated'
  then raise exception using errcode='42501',message='CP7_MATERIAL_NAME_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed'is distinct from'true'::jsonb or erp.has_permission('warehouse.material.view')is distinct from true then
  raise exception using errcode='42501',message='CP7_MATERIAL_NAME_ACCESS_DENIED';end if;
 if coalesce(a->'profile'->>'role_code','')not in('OWNER','ADMIN')then
  raise exception using errcode='42501',message='CP7_MATERIAL_NAME_OWNER_ADMIN_REQUIRED';end if;
 if erp.has_permission(case when p_type='ACCESSORY'then 'master.accessory.manage'else 'master.fabric.manage'end)is distinct from true then
  raise exception using errcode='42501',message='CP7_MATERIAL_NAME_ACCESS_DENIED';end if;
 return a;
end $$;

create function cp7_receipt_fix.identity(p_material uuid)returns jsonb
language sql stable security definer set search_path=''as $$
 select jsonb_build_object('sku',m.material_sku,'type',m.material_type,'unit',m.unit_code,'category',m.accessory_category_id,'active',m.is_active,
  'cost',m.moving_average_cost::text,'stock',m.cached_stock_qty::text,
  'profile',(select to_jsonb(p)-array['updated_at','updated_by']from erp.fabric_master_profiles p where p.material_id=m.id),
  'rolls',(select count(*)from erp.material_rolls r where r.material_id=m.id),'movements',(select count(*)from erp.material_stock_movements s where s.material_id=m.id))
 from erp.materials m where m.id=p_material$$;

create function cp7_receipt_fix.name_workspace(p_material uuid)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare m erp.materials%rowtype;a jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 select*into m from erp.materials where id=p_material;
 if m.id is null then raise exception 'CP7_MATERIAL_NAME_NOT_FOUND';end if;
 a:=cp7_receipt_fix.name_access(m.material_type);
 return jsonb_build_object('contract_version','cp7.material-name-workspace.v1','read_at',clock_timestamp(),
  'material_id',m.id,'material_sku',m.material_sku,'material_name',m.material_name,'material_type',m.material_type,'unit_code',m.unit_code,
  'row_version',m.row_version::text,
  'history',(select coalesce(jsonb_agg(jsonb_build_object('id',h.id,'previous_name',h.previous_name,'corrected_name',h.corrected_name,
    'previous_sku',h.previous_sku,'corrected_sku',h.corrected_sku,'reason',h.reason,
    'recorded_at',h.recorded_at,'actor_id',h.actor,
    'actor_display_name',(select nullif(btrim(u.full_name),'')from erp.app_users u where u.auth_user_id=h.actor),'actor_name_basis','CURRENT_PROFILE')order by h.recorded_at,h.id),'[]')
   from cp7_receipt_fix.material_names h where h.material_id=m.id),
  'production_go',false);
end $$;

create function cp7_receipt_fix.rename(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;old cp7_receipt_fix.name_requests%rowtype;m erp.materials%rowtype;before jsonb;name text;sku text;why text;result jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 if jsonb_typeof(p_payload)is distinct from'object'or not p_payload?&array['material_id','material_name','change_reason']
  or exists(select 1 from jsonb_object_keys(p_payload)k where k not in('material_id','material_name','material_sku','change_reason'))
  or exists(select 1 from jsonb_each(p_payload)e where jsonb_typeof(e.value)<>'string')
  or p_payload->>'material_id'!~'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
 then raise exception using errcode='22023',message='CP7_MATERIAL_NAME_FIELDS';end if;
 if p_request is null or p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'then raise exception 'CP7_MATERIAL_NAME_REQUEST_REQUIRED';end if;
 name:=regexp_replace(btrim(p_payload->>'material_name'),'\s+',' ','g');why:=btrim(p_payload->>'change_reason');
 if length(name)not between 1 and 150 then raise exception using errcode='22023',message='CP7_MATERIAL_NAME_LENGTH';end if;
 if length(why)not between 5 and 500 then raise exception using errcode='22023',message='CP7_MATERIAL_NAME_REASON_REQUIRED';end if;
 if p_payload?'material_sku'and length(btrim(p_payload->>'material_sku'))not between 1 and 60 then raise exception using errcode='22023',message='CP7_MATERIAL_NAME_SKU_LENGTH';end if;
 select*into m from erp.materials where id=(p_payload->>'material_id')::uuid for update;
 if m.id is null then raise exception 'CP7_MATERIAL_NAME_NOT_FOUND';end if;
 a:=cp7_receipt_fix.name_access(m.material_type);
 insert into cp7_receipt_fix.name_requests values(auth.uid(),p_request,p_payload,p_expected,null)on conflict do nothing;
 select*into strict old from cp7_receipt_fix.name_requests where actor=auth.uid()and request_id=p_request for update;
 if old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_MATERIAL_NAME_REQUEST_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 if m.row_version::text<>p_expected then raise exception 'CP7_MATERIAL_NAME_REVIEW_CHANGED';end if;
 sku:=coalesce(btrim(p_payload->>'material_sku'),m.material_sku);
 if name=m.material_name and sku=m.material_sku then raise exception 'CP7_MATERIAL_NAME_UNCHANGED';end if;
 -- The same name or code on another material means two records of one
 -- material (identity), not a typo; it is never merged here.
 if name<>m.material_name and exists(select 1 from erp.materials x where x.id<>m.id and lower(x.material_name)=lower(name))then
  raise exception 'CP7_MATERIAL_NAME_TAKEN';end if;
 if sku<>m.material_sku and exists(select 1 from erp.materials x where x.id<>m.id and lower(x.material_sku)=lower(sku))then
  raise exception 'CP7_MATERIAL_NAME_SKU_TAKEN';end if;
 before:=cp7_receipt_fix.identity(m.id)-'sku';
 perform set_config('app.change_reason','Benerin nama bahan: '||why,true);
 update erp.materials set material_name=name,material_sku=sku where id=m.id;
 if cp7_receipt_fix.identity(m.id)-'sku'is distinct from before or cp7_receipt_fix.identity(m.id)->>'sku'is distinct from sku then
  raise exception 'CP7_MATERIAL_NAME_IDENTITY_CHANGED';end if;
 insert into cp7_receipt_fix.material_names(material_id,previous_name,corrected_name,previous_sku,corrected_sku,reason,actor,request_id)
 values(m.id,m.material_name,name,m.material_sku,sku,why,auth.uid(),p_request);
 if cp7_receipt_fix.name_access(m.material_type)is distinct from a then raise exception using errcode='42501',message='CP7_MATERIAL_NAME_ACCESS_CHANGED';end if;
 result:=jsonb_build_object('contract_version','cp7.material-name-outcome.v1','kind','COMMITTED_OUTCOME','action','RENAME','request_id',p_request,
  'material_id',m.id,'previous_name',m.material_name,'material_name',name,'previous_sku',m.material_sku,'material_sku',sku,'row_version',(select row_version::text from erp.materials where id=m.id));
 update cp7_receipt_fix.name_requests set response=result where actor=auth.uid()and request_id=p_request;
 return result;
end $$;

do $own$
declare f text;
begin
 foreach f in array array['name_access(text)','identity(uuid)','name_workspace(uuid)','rename(jsonb,uuid,text)']loop
  execute 'alter function cp7_receipt_fix.'||f||' owner to postgres';
 end loop;
end $own$;
revoke all on function cp7_receipt_fix.name_access(text),cp7_receipt_fix.identity(uuid),cp7_receipt_fix.name_workspace(uuid),cp7_receipt_fix.rename(jsonb,uuid,text)
 from public,anon,authenticated,service_role,cp7_capture,cp7_procure_read,cp7_procure_write;
grant execute on function cp7_receipt_fix.name_workspace(uuid),cp7_receipt_fix.rename(jsonb,uuid,text)to cp7_procure_write;
create function public.erp_cp7_get_material_name_v1(p_material uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_receipt_fix.name_workspace(p_material)$$;
create function public.erp_cp7_rename_material_v1(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_receipt_fix.rename(p_payload,p_request,p_expected)$$;
grant create on schema public to cp7_procure_write;
alter function public.erp_cp7_get_material_name_v1(uuid)owner to cp7_procure_write;
alter function public.erp_cp7_rename_material_v1(jsonb,uuid,text)owner to cp7_procure_write;
revoke create on schema public from cp7_procure_write;
revoke all on function public.erp_cp7_get_material_name_v1(uuid),public.erp_cp7_rename_material_v1(jsonb,uuid,text)from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_get_material_name_v1(uuid),public.erp_cp7_rename_material_v1(jsonb,uuid,text)to authenticated;

-- P10 current FG source reads. No business writer or cached browser stock.
create role cp7_fg_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_fg authorization cp7_fg_read;
revoke all on schema cp7_fg from public,anon,authenticated,service_role;
grant usage on schema erp,auth to cp7_fg_read;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text),
 erp.bf_commercial_sku_at_v1(uuid,timestamptz),erp.bd_lot_laundry_unknown_v1(uuid),erp.get_hpp_completeness(uuid) to cp7_fg_read;
grant select on erp.fg_stock_movements,erp.fg_lots,erp.products,erp.sizes,erp.brands,erp.locations,erp.customers,erp.hpp_versions to cp7_fg_read;

-- Presentation lineage only. Economic/stock effects come from Native writers.
create table cp7_fg.correction_movements(
 member_id uuid primary key references erp.fg_stock_movements(id),
 origin_id uuid not null references erp.fg_stock_movements(id),
 correction_id uuid not null,recorded_at timestamptz not null,
 check(member_id<>origin_id)
);
alter table cp7_fg.correction_movements owner to cp7_fg_read;
alter table cp7_fg.correction_movements enable row level security;
create policy private_correction_movements on cp7_fg.correction_movements for all using(false)with check(false);
revoke all on cp7_fg.correction_movements from public,anon,authenticated,service_role,cp7_capture;
create function cp7_fg.immutable_correction_movement()returns trigger
language plpgsql stable security invoker set search_path=''as $$
begin raise exception 'CP7_FG_CORRECTION_LINEAGE_IMMUTABLE';end $$;
alter function cp7_fg.immutable_correction_movement()owner to cp7_fg_read;
create trigger immutable_correction_movement before update or delete on cp7_fg.correction_movements
 for each row execute function cp7_fg.immutable_correction_movement();
create function cp7_fg.validate_correction_movement()returns trigger
language plpgsql stable security invoker set search_path=''as $$
begin
 if exists(select 1 from cp7_fg.correction_movements where member_id=new.origin_id)
  or not exists(select 1 from erp.fg_stock_movements m join erp.fg_stock_movements o on o.id=new.origin_id
    where m.id=new.member_id and m.product_id=o.product_id and m.location_id=o.location_id
     and m.quality_grade=o.quality_grade and m.physical_at=o.physical_at)then
  raise exception 'CP7_FG_CORRECTION_ORIGIN_CHANGED';end if;
 return new;
end $$;
alter function cp7_fg.validate_correction_movement()owner to cp7_fg_read;
create trigger validate_correction_movement before insert on cp7_fg.correction_movements
 for each row execute function cp7_fg.validate_correction_movement();

create function cp7_fg.access_now(p_purpose text) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;permission_key text;
begin
 permission_key:=case p_purpose when 'SUMMARY' then 'warehouse.fg.view' when 'CARD' then 'warehouse.stock.view' when 'MOVEMENTS' then 'warehouse.movement.view' end;
 if permission_key is null then raise exception 'CP7_FG_PURPOSE';end if;
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_FG_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission(permission_key) then raise exception using errcode='42501',message='CP7_FG_ACCESS_DENIED';end if;
 return jsonb_build_object('actor',auth.uid(),'profile',a->'profile','permissions',a->'permissions',
  'can_value',erp.has_permission('finance.hpp.view'),'can_card',erp.has_permission('warehouse.stock.view'));
end $$;

create function cp7_fg.lot_value(p_lot uuid,p_qty numeric) returns jsonb
language sql stable security invoker set search_path='' as $$
 with source as (
  select l.id,h.id hpp_id,h.version_no,h.hpp_per_pcs,h.cost_state,h.calculated_at,
   h.id is null or h.hpp_per_pcs is null or h.cost_state='ESTIMATED' or erp.bd_lot_laundry_unknown_v1(l.id)
    or(l.po_id is not null and not exists(select 1 from erp.get_hpp_completeness(l.po_id) z where z.pending_reason_count=0)) pending
  from erp.fg_lots l left join lateral(select x.* from erp.hpp_versions x where x.lot_id=l.id and x.is_current order by x.version_no desc limit 1) h on true where l.id=p_lot
 )
 select coalesce((select jsonb_build_object('state',case when pending then 'UNKNOWN' else 'KNOWN' end,'hpp_version_id',hpp_id,'hpp_version',version_no::text,
  'cost_state',cost_state,'calculated_at',calculated_at,'unit_cost',case when not pending then hpp_per_pcs::text end,
  'value',case when not pending then round(p_qty*hpp_per_pcs,6)::text end,'basis','CURRENT_RESTATED_LOT_VALUE') from source),
  jsonb_build_object('state','UNKNOWN','hpp_version_id',null,'hpp_version',null,'cost_state',null,'calculated_at',null,'unit_cost',null,'value',null,'basis','CURRENT_RESTATED_LOT_VALUE'))
$$;

-- The accepted sale lifecycle changes SALE_RESERVE to SALE at POST without
-- another stock deduction. Keep physical, reserved and available explicit.
create function cp7_fg.positions(p_q text,p_zero boolean) returns table(
 product_id uuid,product_sku text,commercial_sku text,product_name text,size_code text,brand_name text,lot_id uuid,lot_number text,
 location_id uuid,location_name text,quality_grade text,available_qty numeric,reserved_qty numeric,physical_qty numeric,last_at timestamptz,lineage_valid boolean
) language sql stable security invoker set search_path='' as $$
 with ledger as(
  select m.product_id,m.lot_id,m.location_id,m.quality_grade,sum(m.qty_signed)::numeric available_qty,
   coalesce(sum(abs(m.qty_signed)) filter(where m.movement_type='SALE_RESERVE' and not exists(select 1 from erp.fg_stock_movements rv where rv.reversal_of_id=m.id and rv.physical_at<=statement_timestamp())),0)::numeric reserved_qty,
   max(m.physical_at) last_at
  from erp.fg_stock_movements m where m.physical_at<=statement_timestamp() group by m.product_id,m.lot_id,m.location_id,m.quality_grade
 ), source as(
  select p.id,p.sku::text,erp.bf_commercial_sku_at_v1(p.id,statement_timestamp()) commercial_sku,p.product_name::text,s.size_code::text,b.brand_name::text,
   x.lot_id,l.lot_number::text,loc.id location_id,loc.location_name::text,x.quality_grade::text,x.available_qty,x.reserved_qty,x.available_qty+x.reserved_qty physical_qty,x.last_at,
   coalesce(l.id is not null and l.product_id=p.id,false) lineage_valid
  from ledger x join erp.products p on p.id=x.product_id join erp.sizes s on s.id=p.size_id join erp.brands b on b.id=p.brand_id
  join erp.locations loc on loc.id=x.location_id left join erp.fg_lots l on l.id=x.lot_id
 )
 select * from source x where (p_zero or x.physical_qty<>0 or x.available_qty<>0 or x.reserved_qty<>0)
  and(p_q='' or strpos(lower(concat_ws(' ',x.sku,x.commercial_sku,x.product_name,x.size_code,x.brand_name,x.lot_number,x.location_name)),lower(p_q))>0)
$$;

create function cp7_fg.workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;purpose text;q text;off integer;n integer;zero boolean;rows jsonb;total bigint;totals jsonb;
begin
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in('purpose','q','show_zero','offset','limit'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('purpose','q') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query ? 'show_zero' and jsonb_typeof(p_query->'show_zero')<>'boolean')
  or(p_query ? 'offset' and (jsonb_typeof(p_query->'offset')<>'number' or (p_query->>'offset')!~'^[0-9]{1,7}$'))
  or(p_query ? 'limit' and (jsonb_typeof(p_query->'limit')<>'number' or (p_query->>'limit')!~'^[0-9]{1,3}$')) then raise exception 'CP7_FG_QUERY';end if;
 purpose:=coalesce(p_query->>'purpose','SUMMARY');a:=cp7_fg.access_now(purpose);q:=btrim(coalesce(p_query->>'q',''));off:=coalesce((p_query->>'offset')::integer,0);n:=coalesce((p_query->>'limit')::integer,25);zero:=coalesce((p_query->>'show_zero')::boolean,false);
 if length(q)>120 or off not between 0 and 1000000 or n not between 1 and 100 then raise exception 'CP7_FG_QUERY';end if;
 select count(*) into total from cp7_fg.positions(q,zero);
 select coalesce(jsonb_agg(jsonb_build_object('product_id',x.product_id,'product_sku',x.product_sku,'commercial_sku',x.commercial_sku,'product_name',x.product_name,'size_code',x.size_code,'brand_name',x.brand_name,
  'lot_id',x.lot_id,'lot_number',x.lot_number,'location_id',x.location_id,'location_name',x.location_name,'quality_grade',x.quality_grade,
  'available_qty',x.available_qty::text,'reserved_qty',x.reserved_qty::text,'physical_qty',x.physical_qty::text,'last_movement_at',x.last_at,
  'quality',case when x.available_qty<0 or x.physical_qty<0 or not x.lineage_valid then 'CONFLICT' else 'KNOWN' end)
  ||case when a->'can_value'='true'::jsonb then jsonb_build_object('valuation',cp7_fg.lot_value(x.lot_id,x.physical_qty)) else '{}'::jsonb end
  order by x.commercial_sku,x.size_code,x.product_id,x.lot_id nulls first,x.location_id,x.quality_grade),'[]') into rows
 from(select * from cp7_fg.positions(q,zero) order by commercial_sku,size_code,product_id,lot_id nulls first,location_id,quality_grade limit n offset off)x;
 select jsonb_build_object('available_qty',coalesce(sum(available_qty),0)::text,'reserved_qty',coalesce(sum(reserved_qty),0)::text,'physical_qty',coalesce(sum(physical_qty),0)::text,
  'quality',case when bool_or(available_qty<0 or physical_qty<0 or not lineage_valid) then 'CONFLICT' else 'KNOWN' end) into totals from cp7_fg.positions(q,zero);
 return jsonb_build_object('contract_version','cp7.fg-workspace.v1','purpose',purpose,'read_at',statement_timestamp(),'knowledge','CURRENT','quantity_basis','PHYSICAL_EQUALS_AVAILABLE_PLUS_ACTIVE_RESERVATION',
  'financial_captured',a->'can_value','capabilities',jsonb_build_object('card',a->'can_card'),'unit_code','PCS','totals',totals,
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;
create function public.erp_cp7_get_fg_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_fg.workspace(p_query)$$;

-- Authoritative chronological prefix first; search/date/page are presentation
-- filters afterwards. A reservation moves availability, not physical custody.
create function cp7_fg.ledger_rows(p_product uuid,p_lot uuid,p_location uuid,p_grade text) returns table(
 id uuid,physical_at timestamptz,recorded_at timestamptz,movement_type text,source_type text,source_id uuid,
 reversal_of_id uuid,customer_name text,notes text,book_order text,commercial_sku text,
 qty_signed numeric,reservation_delta numeric,physical_delta numeric,
 available_balance numeric,reserved_balance numeric,physical_balance numeric,unit_hpp_snapshot numeric
) language sql stable security invoker set search_path='' as $$
 with movements as (
  select m.*,case when m.movement_type='SALE_RESERVE' or original.movement_type='SALE_RESERVE' then -m.qty_signed else 0 end::numeric reserved_delta
  from erp.fg_stock_movements m left join erp.fg_stock_movements original on original.id=m.reversal_of_id
  where m.product_id=p_product and m.lot_id is not distinct from p_lot and m.location_id=p_location and m.quality_grade=p_grade
   and m.physical_at<=statement_timestamp()
 ), prefix as (
  select m.*,sum(m.qty_signed) over w available_balance,sum(m.reserved_delta) over w reserved_balance
  from movements m window w as(order by m.physical_at,m.system_created_at,m.id rows between unbounded preceding and current row)
 )
 select m.id,m.physical_at,m.system_created_at,m.movement_type::text,m.source_type::text,m.source_id,m.reversal_of_id,
  c.customer_name::text,m.notes::text,m.book_order::text,erp.bf_commercial_sku_at_v1(m.product_id,m.physical_at),
  m.qty_signed::numeric,m.reserved_delta,(m.qty_signed+m.reserved_delta)::numeric,m.available_balance::numeric,m.reserved_balance::numeric,
  (m.available_balance+m.reserved_balance)::numeric,m.unit_hpp_snapshot
 from prefix m left join erp.customers c on c.id=m.customer_id
$$;

create function cp7_fg.ledger(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;purpose text;q text;off integer;n integer;pid uuid;lid uuid;location uuid;grade text;
 from_at timestamptz;to_at timestamptz;rows jsonb;total bigint;header jsonb;balances jsonb;cost jsonb;
begin
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in('purpose','product_id','lot_id','location_id','quality_grade','q','from','to','offset','limit'))
  or not p_query ?& array['product_id','lot_id','location_id','quality_grade']
  or exists(select 1 from jsonb_each(p_query) e where e.key not in('offset','limit') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query ? 'offset' and (jsonb_typeof(p_query->'offset')<>'number' or (p_query->>'offset')!~'^[0-9]{1,7}$'))
  or(p_query ? 'limit' and (jsonb_typeof(p_query->'limit')<>'number' or (p_query->>'limit')!~'^[0-9]{1,3}$')) then raise exception 'CP7_FG_QUERY';end if;
 purpose:=coalesce(p_query->>'purpose','CARD');if purpose not in('CARD','MOVEMENTS') then raise exception 'CP7_FG_PURPOSE';end if;
 a:=cp7_fg.access_now(purpose);pid:=(p_query->>'product_id')::uuid;lid:=(p_query->>'lot_id')::uuid;location:=(p_query->>'location_id')::uuid;grade:=p_query->>'quality_grade';
 q:=btrim(coalesce(p_query->>'q',''));off:=coalesce((p_query->>'offset')::integer,0);n:=coalesce((p_query->>'limit')::integer,25);
 from_at:=(p_query->>'from')::timestamptz;to_at:=(p_query->>'to')::timestamptz;
 if pid is null or location is null or grade is null or length(grade)>40 or length(q)>120 or off not between 0 and 1000000 or n not between 1 and 100
  or(from_at is not null and not isfinite(from_at)) or(to_at is not null and(not isfinite(to_at) or to_at>statement_timestamp()))
  or(from_at is not null and to_at is not null and from_at>=to_at) then raise exception 'CP7_FG_QUERY';end if;
 select jsonb_build_object('product_id',x.product_id,'product_sku',x.product_sku,'commercial_sku',x.commercial_sku,'product_name',x.product_name,'size_code',x.size_code,'brand_name',x.brand_name,
  'lot_id',x.lot_id,'lot_number',x.lot_number,'location_id',x.location_id,'location_name',x.location_name,'quality_grade',x.quality_grade)
 into header from cp7_fg.positions('',true) x where x.product_id=pid and x.lot_id is not distinct from lid and x.location_id=location and x.quality_grade=grade;
 if header is null then raise exception using errcode='P0002',message='CP7_FG_POSITION_UNAVAILABLE';end if;
 if a->'can_value'='true'::jsonb then cost:=cp7_fg.lot_value(lid,1);end if;
 select jsonb_build_object('available_qty',coalesce(sum(x.qty_signed),0)::text,'reserved_qty',coalesce(sum(x.reservation_delta),0)::text,'physical_qty',coalesce(sum(x.physical_delta),0)::text,
  'quality',case when bool_or(x.available_balance<0 or x.reserved_balance<0 or x.physical_balance<0) then 'CONFLICT' else 'KNOWN' end)
 into balances from cp7_fg.ledger_rows(pid,lid,location,grade) x where to_at is null or x.physical_at<to_at;
 select count(*) into total from cp7_fg.ledger_rows(pid,lid,location,grade) x
 where(from_at is null or x.physical_at>=from_at) and(to_at is null or x.physical_at<to_at)
  and(q='' or strpos(lower(concat_ws(' ',x.source_type,x.source_id,x.customer_name,x.notes,x.movement_type,x.commercial_sku)),lower(q))>0);
 select coalesce(jsonb_agg(jsonb_build_object('id',x.id,'physical_at',x.physical_at,'recorded_at',x.recorded_at,'movement_type',x.movement_type,
  'source_type',x.source_type,'source_id',x.source_id,'reversal_of_id',x.reversal_of_id,'customer_name',x.customer_name,'notes',x.notes,'book_order',x.book_order,
  'commercial_sku_at_transaction',x.commercial_sku,'qty_signed',x.qty_signed::text,'reservation_delta',x.reservation_delta::text,'physical_delta',x.physical_delta::text,
  'available_balance',x.available_balance::text,'reserved_balance',x.reserved_balance::text,'physical_balance',x.physical_balance::text)
  ||case when a->'can_value'='true'::jsonb then jsonb_build_object('valuation',jsonb_build_object('state',cost->'state',
   'unit_cost',case when cost->>'state'='KNOWN' then x.unit_hpp_snapshot::text end,'basis','CURRENT_RESTATED_MOVEMENT_SNAPSHOT')) else '{}'::jsonb end
  order by x.physical_at,x.recorded_at,x.id),'[]') into rows
 from(select * from cp7_fg.ledger_rows(pid,lid,location,grade) z
  where(from_at is null or z.physical_at>=from_at) and(to_at is null or z.physical_at<to_at)
   and(q='' or strpos(lower(concat_ws(' ',z.source_type,z.source_id,z.customer_name,z.notes,z.movement_type,z.commercial_sku)),lower(q))>0)
  order by z.physical_at,z.recorded_at,z.id limit n offset off)x;
 return jsonb_build_object('contract_version','cp7.fg-ledger.v1','purpose',purpose,'read_at',statement_timestamp(),'knowledge','CURRENT','financial_captured',a->'can_value',
  'position',header,'balances',balances,'balance_basis','COMPLETE_CHRONOLOGICAL_PREFIX_BEFORE_SEARCH_AND_PAGE',
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;
create function public.erp_cp7_get_fg_ledger_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_fg.ledger(p_query)$$;

-- Existing FG adjustment writers own quantities, HPP and inverse journals.
-- This bridge admits an exact reviewed signed correction, never a client HPP.
create role cp7_fg_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
grant usage on schema cp7_fg,erp,auth to cp7_fg_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text),
 erp.save_fg_adjustment_draft_v2(jsonb,uuid,bigint),erp.post_fg_adjustment_v2(uuid,uuid,bigint,text),erp.reverse_fg_adjustment_v2(uuid,text,uuid,bigint) to cp7_fg_write;
grant select on erp.fg_adjustments,erp.fg_adjustment_items to cp7_fg_read;
create table cp7_fg.requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text,response jsonb,primary key(actor,request_id));
alter table cp7_fg.requests owner to cp7_fg_write;
alter table cp7_fg.requests enable row level security;
create table cp7_fg.adjustment_documents(adjustment_id uuid primary key,source_signature jsonb not null);
alter table cp7_fg.adjustment_documents owner to cp7_fg_write;
alter table cp7_fg.adjustment_documents enable row level security;
revoke all on cp7_fg.requests,cp7_fg.adjustment_documents from public,anon,authenticated,service_role,cp7_capture,cp7_fg_read;
grant select on cp7_fg.adjustment_documents to cp7_fg_read;

create function cp7_fg.adjust_access() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;allowed boolean;
begin
 a:=cp7_fg.access_now('SUMMARY');
 allowed:=erp.has_permission('warehouse.stock.adjust') and a->'profile'->>'role_code' in('OWNER','ADMIN');
 return a||jsonb_build_object('can_adjust',allowed);
end $$;

create function cp7_fg.adjust_signature(p_id uuid) returns jsonb
language sql stable security definer set search_path='' as $$
 select jsonb_build_object('number',h.adjustment_number,'location',h.location_id,'at',extract(epoch from h.physical_at),'reason_code',h.reason_code,'reason',h.reason,'notes',h.notes,
  'items',(select jsonb_agg(jsonb_build_array(i.id,i.lot_id,i.product_id,i.quality_grade,i.qty_signed,i.notes) order by i.id) from erp.fg_adjustment_items i where i.adjustment_id=h.id))
 from erp.fg_adjustments h where h.id=p_id
$$;

create function cp7_fg.adjust_validate(p_payload jsonb,p_id uuid default null) returns void
language plpgsql stable security definer set search_path='' as $$
declare h erp.fg_adjustments;loc uuid;at_time timestamptz;items jsonb;line jsonb;seen text[]:='{}';key text;
begin
 perform cp7_fg.adjust_access();
 if p_id is not null then
  select * into h from erp.fg_adjustments where id=p_id;
  if not found then raise exception 'CP7_FG_ADJUST_NOT_FOUND';end if;
  loc:=h.location_id;at_time:=h.physical_at;
  select jsonb_agg(jsonb_build_object('lot_id',lot_id,'product_id',product_id,'quality_grade',quality_grade,'qty_signed',qty_signed::text,'notes',notes) order by id) into items from erp.fg_adjustment_items where adjustment_id=p_id;
 else
  loc:=(p_payload->>'location_id')::uuid;at_time:=(p_payload->>'physical_at')::timestamptz;items:=p_payload->'items';
 end if;
 if at_time is null or at_time>statement_timestamp() or loc is null or not exists(select 1 from erp.locations where id=loc and is_active and location_type='FG_WAREHOUSE') then raise exception 'CP7_FG_ADJUST_TIME_LOCATION';end if;
 if jsonb_typeof(items) is distinct from 'array' or jsonb_array_length(items) not between 1 and 100 then raise exception 'CP7_FG_ADJUST_LINES';end if;
 for line in select value from jsonb_array_elements(items) loop
  if jsonb_typeof(line) is distinct from 'object' or not line ?& array['lot_id','product_id','quality_grade','qty_signed']
   or exists(select 1 from jsonb_each(line) e where e.key not in('lot_id','product_id','quality_grade','qty_signed','notes') or jsonb_typeof(e.value) not in('string','null'))
   or line->>'qty_signed' is null or line->>'qty_signed'!~'^-?[1-9][0-9]{0,8}$'
   or coalesce(line->>'quality_grade','') not in('GRADE_A','GRADE_B') then raise exception 'CP7_FG_ADJUST_EXACT_LINE';end if;
  if not exists(select 1 from erp.fg_lots l join erp.products p on p.id=l.product_id where l.id=(line->>'lot_id')::uuid and l.product_id=(line->>'product_id')::uuid and l.lot_origin<>'VOIDED_PRODUCTION' and p.is_active) then raise exception 'CP7_FG_ADJUST_LINEAGE';end if;
  key:=(line->>'lot_id')||'/'||(line->>'quality_grade');
  if key=any(seen) then raise exception 'CP7_FG_ADJUST_DUPLICATE';end if;seen:=array_append(seen,key);
 end loop;
end $$;

create function cp7_fg.adjust_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_fg.requests;r jsonb;ident uuid;expected bigint;proof jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_fg.adjust_access();
 if a->'can_adjust' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_FG_ADJUST_DENIED';end if;
 if p_action is null or p_action not in('SAVE','DELETE','POST','REVERSE') or p_request is null or jsonb_typeof(p_payload) is distinct from 'object' then raise exception 'CP7_FG_ADJUST_FIELDS';end if;
 if p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_FG_ADJUST_VERSION';end if;expected:=p_expected::bigint;
 insert into cp7_fg.requests(actor,request_id,action,payload,expected_version) values(auth.uid(),p_request,p_action,p_payload,p_expected) on conflict do nothing;
 select * into old from cp7_fg.requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_FG_ADJUST_REQUEST_CHANGED';end if;
 if cp7_fg.adjust_access()<>a then raise exception using errcode='42501',message='CP7_FG_ADJUST_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 if p_action='SAVE' then
  if not p_payload ?& array['adjustment_number','location_id','physical_at','reason_code','reason','change_reason','items']
   or exists(select 1 from jsonb_each(p_payload) e where e.key not in('id','adjustment_number','location_id','physical_at','reason_code','reason','change_reason','items','notes') or (e.key<>'items' and jsonb_typeof(e.value) not in('string','null')))
   or coalesce(p_payload->>'reason_code','') not in('LOSS','DAMAGE','COUNT_CORRECTION') then raise exception 'CP7_FG_ADJUST_FIELDS';end if;
  ident:=(p_payload->>'id')::uuid;
  if ident is not null then
   perform 1 from cp7_fg.adjustment_documents where adjustment_id=ident for update;
   if not found then raise exception 'CP7_FG_ADJUST_SOURCE_WORKFLOW_REQUIRED';end if;
  end if;
  perform cp7_fg.adjust_validate(p_payload);
  r:=erp.save_fg_adjustment_draft_v2(p_payload,p_request,expected);ident:=(r->>'fg_adjustment_id')::uuid;
  perform cp7_fg.adjust_validate(null,ident);
  insert into cp7_fg.adjustment_documents values(ident,cp7_fg.adjust_signature(ident)) on conflict(adjustment_id) do update set source_signature=excluded.source_signature;
 else
  if expected is null or not p_payload ?& array['adjustment_id','change_reason'] or exists(select 1 from jsonb_each(p_payload) e where e.key not in('adjustment_id','change_reason') or jsonb_typeof(e.value)<>'string') then raise exception 'CP7_FG_ADJUST_FIELDS';end if;
  ident:=(p_payload->>'adjustment_id')::uuid;
  select source_signature into proof from cp7_fg.adjustment_documents where adjustment_id=ident for update;
  if not found then raise exception 'CP7_FG_ADJUST_SOURCE_WORKFLOW_REQUIRED';end if;
  if p_action='POST' then
   if cp7_fg.adjust_signature(ident) is distinct from proof then raise exception 'CP7_FG_ADJUST_DRAFT_CHANGED_REVIEW_AGAIN';end if;
   perform cp7_fg.adjust_validate(null,ident);
   r:=erp.post_fg_adjustment_v2(ident,p_request,expected,p_payload->>'change_reason');
   perform cp7_fg.adjust_validate(null,ident);
   if cp7_fg.adjust_signature(ident) is distinct from proof then raise exception 'CP7_FG_ADJUST_DRAFT_CHANGED_REVIEW_AGAIN';end if;
  elsif p_action='DELETE' then
   r:=erp.save_fg_adjustment_draft_v2(jsonb_build_object('id',ident,'action','DELETE','change_reason',p_payload->'change_reason'),p_request,expected);
   delete from cp7_fg.adjustment_documents where adjustment_id=ident;
  else r:=erp.reverse_fg_adjustment_v2(ident,p_payload->>'change_reason',p_request,expected);
  end if;
 end if;
 if cp7_fg.adjust_access()<>a then raise exception using errcode='42501',message='CP7_FG_ADJUST_ACCESS_CHANGED';end if;
 r:=jsonb_build_object('contract_version','cp7.fg-adjustment-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'adjustment_id',ident,'status',r->'status','row_version',r->>'row_version');
 update cp7_fg.requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;
create function public.erp_cp7_save_fg_adjustment_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_fg.adjust_command(p_action,p_payload,p_request,p_expected)$$;

create function cp7_fg.adjust_header(h erp.fg_adjustments) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',h.id,'number',h.adjustment_number,'location_id',h.location_id,'location_name',(select location_name from erp.locations where id=h.location_id),
  'physical_at',h.physical_at,'reason_code',h.reason_code,'reason',h.reason,'notes',h.notes,'status',h.status,'row_version',h.row_version::text,
  'managed',exists(select 1 from cp7_fg.adjustment_documents where adjustment_id=h.id),
  'line_count',(select count(*)::text from erp.fg_adjustment_items where adjustment_id=h.id))
$$;
create function cp7_fg.adjust_workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;q text;n integer;off integer;chosen uuid;total bigint;rows jsonb;detail jsonb:=null;h erp.fg_adjustments;items jsonb;editable boolean;
begin
 a:=cp7_fg.adjust_access();
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','limit','offset','adjustment_id'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','adjustment_id') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query ? 'limit' and (jsonb_typeof(p_query->'limit')<>'number' or (p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query ? 'offset' and (jsonb_typeof(p_query->'offset')<>'number' or (p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_FG_ADJUST_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);chosen:=(p_query->>'adjustment_id')::uuid;
 if length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000 then raise exception 'CP7_FG_ADJUST_QUERY';end if;
 select count(*) into total from erp.fg_adjustments doc where q='' or strpos(lower(doc.adjustment_number),lower(q))>0;
 select coalesce(jsonb_agg(cp7_fg.adjust_header(x) order by x.physical_at desc,x.id),'[]') into rows
 from(select * from erp.fg_adjustments doc where q='' or strpos(lower(doc.adjustment_number),lower(q))>0 order by physical_at desc,id limit n offset off)x;
 if chosen is not null then
  select * into h from erp.fg_adjustments where id=chosen;
  if not found then raise exception 'CP7_FG_ADJUST_NOT_FOUND';end if;
  if (select count(*) from erp.fg_adjustment_items where adjustment_id=chosen)>100 then raise exception 'CP7_FG_ADJUST_DOCUMENT_TOO_LARGE';end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'product_id',i.product_id,'product_sku',p.sku,'commercial_sku',erp.bf_commercial_sku_at_v1(p.id,h.physical_at),
   'size_code',s.size_code,'lot_id',i.lot_id,'lot_number',l.lot_number,'quality_grade',i.quality_grade,'qty_signed',i.qty_signed::text,'notes',i.notes)
   ||case when a->'can_value'='true'::jsonb then jsonb_build_object('valuation',cp7_fg.lot_value(l.id,i.qty_signed)) else '{}'::jsonb end order by i.id),'[]') into items
  from erp.fg_adjustment_items i join erp.fg_lots l on l.id=i.lot_id join erp.products p on p.id=i.product_id join erp.sizes s on s.id=p.size_id where i.adjustment_id=chosen;
  editable:=h.status='DRAFT' and a->'can_adjust'='true'::jsonb and exists(select 1 from cp7_fg.adjustment_documents where adjustment_id=chosen and source_signature=cp7_fg.adjust_signature(chosen));
  detail:=cp7_fg.adjust_header(h)||jsonb_build_object('items',items,'editable',editable);
 end if;
 return jsonb_build_object('contract_version','cp7.fg-adjustments.v1','read_at',statement_timestamp(),'financial_captured',a->'can_value','can_adjust',a->'can_adjust',
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end),'detail',detail);
end $$;
create function public.erp_cp7_get_fg_adjustments_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_fg.adjust_workspace(p_query)$$;

-- Global FG presentation book. Quantity prefixes precede all display filters.
-- Reordering is presentation-only; the private request records actor/intent/result.
create function cp7_fg.book_access() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 a:=cp7_fg.access_now('MOVEMENTS');
 return a||jsonb_build_object('can_order',erp.has_permission('warehouse.stock.adjust') and a->'profile'->>'role_code' in('OWNER','ADMIN'));
end $$;

create function cp7_fg.book_signature() returns text
language sql stable security definer set search_path='' as $$
 select md5(coalesce(string_agg(jsonb_build_array(id,book_order,qty_signed,movement_type,reversal_of_id,extract(epoch from physical_at))::text,',' order by id),'')) from erp.fg_stock_movements
$$;

create function cp7_fg.book_rows() returns table(
 id uuid,book_order text,physical_at timestamptz,recorded_at timestamptz,product_id uuid,brand_id uuid,brand_name text,commercial_sku text,product_name text,size_code text,
 lot_id uuid,lot_number text,location_id uuid,location_name text,quality_grade text,customer_id uuid,customer_name text,movement_type text,source_type text,source_id uuid,reversal_of_id uuid,notes text,
 physical_delta text,reservation_delta text,available_delta text,book_physical_before text,book_physical_after text,book_available_after text,book_reserved_after text,official_physical_after text,official_available_after text,official_reserved_after text
) language sql stable security invoker set search_path='' as $$
 with source as(
  select m.*,case when m.movement_type='SALE_RESERVE' or exists(select 1 from erp.fg_stock_movements o where o.id=m.reversal_of_id and o.movement_type='SALE_RESERVE') then -m.qty_signed else 0 end reservation_delta
  from erp.fg_stock_movements m where m.physical_at<=statement_timestamp()
 ), prefix as(
  select m.*,sum(qty_signed+reservation_delta) over book book_physical_after,sum(qty_signed) over book book_available_after,sum(reservation_delta) over book book_reserved_after,
   sum(qty_signed+reservation_delta) over official official_physical_after,sum(qty_signed) over official official_available_after,sum(reservation_delta) over official official_reserved_after
  from source m
  window book as(partition by product_id,location_id,quality_grade order by book_order,id rows between unbounded preceding and current row),
   official as(partition by product_id,location_id,quality_grade order by physical_at,system_created_at,id rows between unbounded preceding and current row)
 )
 select m.id,m.book_order::text,m.physical_at,m.system_created_at,m.product_id,b.id,b.brand_name::text,erp.bf_commercial_sku_at_v1(p.id,m.physical_at),p.product_name::text,s.size_code::text,
  m.lot_id,l.lot_number::text,m.location_id,loc.location_name::text,m.quality_grade::text,m.customer_id,c.customer_name::text,m.movement_type::text,m.source_type::text,m.source_id,m.reversal_of_id,m.notes,
  (m.qty_signed+m.reservation_delta)::text,m.reservation_delta::text,m.qty_signed::text,(m.book_physical_after-m.qty_signed-m.reservation_delta)::text,m.book_physical_after::text,m.book_available_after::text,m.book_reserved_after::text,
  m.official_physical_after::text,m.official_available_after::text,m.official_reserved_after::text
 from prefix m join erp.products p on p.id=m.product_id join erp.brands b on b.id=p.brand_id join erp.sizes s on s.id=p.size_id
 join erp.locations loc on loc.id=m.location_id left join erp.fg_lots l on l.id=m.lot_id left join erp.customers c on c.id=m.customer_id
$$;

-- One closed validator shared by both projections. It performs no ledger
-- read; the corrected projection must not build the complete legacy book too.
create function cp7_fg.book_query(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare q text;n integer;off integer;at_from timestamptz;at_to timestamptz;brands uuid[];customers uuid[];types text[];key text;
begin
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','limit','offset','from','to','brand_ids','customer_ids','movement_types'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','from','to') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query?'limit' and (jsonb_typeof(p_query->'limit')<>'number' or(p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query?'offset' and (jsonb_typeof(p_query->'offset')<>'number' or(p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_FG_BOOK_QUERY';end if;
 foreach key in array array['brand_ids','customer_ids','movement_types'] loop
  if p_query?key and (jsonb_typeof(p_query->key)<>'array' or jsonb_array_length(p_query->key)>100 or exists(select 1 from jsonb_array_elements(p_query->key) e where jsonb_typeof(e)<>'string')) then raise exception 'CP7_FG_BOOK_FILTER';end if;
 end loop;
 q:=btrim(coalesce(p_query->>'q',''));n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);at_from:=(p_query->>'from')::timestamptz;at_to:=(p_query->>'to')::timestamptz;
 if length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000 or at_from>=at_to then raise exception 'CP7_FG_BOOK_QUERY';end if;
 select array_agg(value::uuid) into brands from jsonb_array_elements_text(p_query->'brand_ids');
 select array_agg(value::uuid) into customers from jsonb_array_elements_text(p_query->'customer_ids');
 select array_agg(value) into types from jsonb_array_elements_text(p_query->'movement_types');
 return jsonb_build_object('q',q,'limit',n,'offset',off,'from',at_from,'to',at_to,
  'brand_ids',to_jsonb(coalesce(brands,'{}'::uuid[])),
  'customer_ids',to_jsonb(coalesce(customers,'{}'::uuid[])),
  'movement_types',to_jsonb(coalesce(types,'{}'::text[])));
end $$;

create function cp7_fg.book_workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;validated jsonb;q text;n integer;off integer;at_from timestamptz;at_to timestamptz;brands uuid[];customers uuid[];types text[];rows jsonb;total bigint;
begin
 a:=cp7_fg.book_access();validated:=cp7_fg.book_query(p_query);
 q:=validated->>'q';n:=(validated->>'limit')::integer;off:=(validated->>'offset')::integer;
 at_from:=(validated->>'from')::timestamptz;at_to:=(validated->>'to')::timestamptz;
 select array_agg(value::uuid)into brands from jsonb_array_elements_text(validated->'brand_ids');
 select array_agg(value::uuid)into customers from jsonb_array_elements_text(validated->'customer_ids');
 select array_agg(value)into types from jsonb_array_elements_text(validated->'movement_types');
 with filtered as materialized(
  select * from cp7_fg.book_rows() m where(at_from is null or m.physical_at>=at_from) and(at_to is null or m.physical_at<at_to)
   and(brands is null or m.brand_id=any(brands)) and(customers is null or m.customer_id=any(customers)) and(types is null or m.movement_type=any(types))
   and(q='' or strpos(lower(concat_ws(' ',m.brand_name,m.commercial_sku,m.product_name,m.size_code,m.lot_number,m.location_name,m.customer_name,m.source_type,m.source_id,m.notes)),lower(q))>0)
 ), page as(select * from filtered order by book_order::bigint,id limit n offset off)
 select(select count(*) from filtered),coalesce(jsonb_agg(to_jsonb(page) order by book_order::bigint,id),'[]') into total,rows from page;
 return jsonb_build_object('contract_version','cp7.fg-book.v1','read_at',statement_timestamp(),'knowledge','CURRENT','book_token',cp7_fg.book_signature(),
  'can_order',a->'can_order','quantity_scope','PHYSICAL_PRODUCT_LOCATION_GRADE','presentation_only',true,
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;

create function cp7_fg.book_anchor(p_source uuid,p_target uuid,p_placement text) returns integer
language plpgsql stable security definer set search_path='' as $$
declare source_pos integer;target_pos integer;
begin
 if p_source is null or p_target is null or p_source=p_target or coalesce(p_placement,'') not in('BEFORE','AFTER') then raise exception 'CP7_FG_BOOK_ANCHOR';end if;
 select max(pos) filter(where id=p_source),max(pos) filter(where id=p_target) into source_pos,target_pos
 from(select id,row_number() over(order by book_order,id)::integer pos from erp.fg_stock_movements)x;
 if source_pos is null or target_pos is null then raise exception 'CP7_FG_BOOK_SOURCE_MISSING';end if;
 -- Native target rank is in the final list after removing the dragged row.
 return target_pos-case when source_pos<target_pos then 1 else 0 end+case when p_placement='AFTER' then 1 else 0 end;
end $$;

create function cp7_fg.book_command(p_action text,p_payload jsonb,p_request uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_fg.requests;r jsonb;position integer;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_fg.book_access();
 if a->'can_order' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_FG_BOOK_ORDER_DENIED';end if;
 if p_action is null or p_action not in('MOVE','RESET') or p_request is null or jsonb_typeof(p_payload) is distinct from 'object'
  or not (p_payload?'book_token') or coalesce(p_payload->>'book_token','')!~'^[a-f0-9]{32}$'
  or exists(select 1 from jsonb_each(p_payload) e where e.key not in('book_token','source_id','target_id','placement') or jsonb_typeof(e.value)<>'string') then raise exception 'CP7_FG_BOOK_ACTION';end if;
 if p_action='RESET' and (p_payload-array['book_token'])<>'{}'::jsonb then raise exception 'CP7_FG_BOOK_ACTION';end if;
 insert into cp7_fg.requests(actor,request_id,action,payload,expected_version) values(auth.uid(),p_request,'BOOK_'||p_action,p_payload,null) on conflict do nothing;
 select * into old from cp7_fg.requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>('BOOK_'||p_action) or old.payload is distinct from p_payload or old.expected_version is not null then raise exception 'CP7_FG_BOOK_REQUEST_CHANGED';end if;
 if cp7_fg.book_access()<>a then raise exception using errcode='42501',message='CP7_FG_BOOK_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 perform pg_advisory_xact_lock(hashtextextended('FGBOOK|GLOBAL',0));
 if cp7_fg.book_access()<>a then raise exception using errcode='42501',message='CP7_FG_BOOK_ACCESS_CHANGED';end if;
 if cp7_fg.book_signature()<>p_payload->>'book_token' then raise exception 'CP7_FG_BOOK_STALE_RELOAD';end if;
 if p_action='MOVE' then
  position:=cp7_fg.book_anchor((p_payload->>'source_id')::uuid,(p_payload->>'target_id')::uuid,p_payload->>'placement');
  perform erp.move_fg_stock_card_row_to_position((p_payload->>'source_id')::uuid,position);
 else perform erp.reset_fg_stock_mutation_book_order();
 end if;
 if cp7_fg.book_access()<>a then raise exception using errcode='42501',message='CP7_FG_BOOK_ACCESS_CHANGED';end if;
 r:=jsonb_build_object('contract_version','cp7.fg-book-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'source_id',p_payload->'source_id','book_token',cp7_fg.book_signature(),'presentation_only',true);
 update cp7_fg.requests set response=r where actor=auth.uid() and request_id=p_request;return r;
end $$;
grant execute on function erp.move_fg_stock_card_row_to_position(uuid,integer),erp.reset_fg_stock_mutation_book_order() to cp7_fg_write;
create function public.erp_cp7_get_fg_book_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_fg.book_workspace(p_query)$$;
create function public.erp_cp7_save_fg_book_v1(p_action text,p_payload jsonb,p_request uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_fg.book_command(p_action,p_payload,p_request)$$;

create function cp7_fg.book_options(p_kind text,p_q text,p_offset integer,p_limit integer) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare q text:=btrim(coalesce(p_q,''));rows jsonb;total bigint;
begin
 perform cp7_fg.book_access();
 if p_kind is null or p_kind not in('BRAND','CUSTOMER','TYPE') or length(q)>120 or p_offset is null or p_offset not between 0 and 1000000 or p_limit is null or p_limit not between 1 and 100 then raise exception 'CP7_FG_BOOK_OPTIONS';end if;
 with source as materialized(
  select b.id::text id,b.brand_name::text label,b.brand_code::text code from erp.brands b where p_kind='BRAND'
  union all select c.id::text,c.customer_name::text,c.customer_code::text from erp.customers c where p_kind='CUSTOMER'
  union all select distinct m.movement_type::text,m.movement_type::text,m.movement_type::text from erp.fg_stock_movements m where p_kind='TYPE'
 ), filtered as materialized(select * from source where q='' or strpos(lower(concat_ws(' ',label,code)),lower(q))>0),
 page as(select * from filtered order by label,id limit p_limit offset p_offset)
 select(select count(*) from filtered),coalesce(jsonb_agg(to_jsonb(page) order by label,id),'[]') into total,rows from page;
 return jsonb_build_object('contract_version','cp7.fg-book-options.v1','kind',p_kind,'read_at',statement_timestamp(),'page',
  jsonb_build_object('rows',rows,'total',total::text,'offset',p_offset,'limit',p_limit,'next_offset',case when p_offset+jsonb_array_length(rows)<total then p_offset+jsonb_array_length(rows) else null end));
end $$;
create function public.erp_cp7_get_fg_book_options_v1(p_kind text,p_q text,p_offset integer,p_limit integer) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_fg.book_options(p_kind,p_q,p_offset,p_limit)$$;

alter function cp7_fg.access_now(text) owner to cp7_fg_read;
alter function cp7_fg.lot_value(uuid,numeric) owner to cp7_fg_read;
alter function cp7_fg.positions(text,boolean) owner to cp7_fg_read;
alter function cp7_fg.workspace(jsonb) owner to cp7_fg_read;
alter function cp7_fg.ledger_rows(uuid,uuid,uuid,text) owner to cp7_fg_read;
alter function cp7_fg.ledger(jsonb) owner to cp7_fg_read;
alter function public.erp_cp7_get_fg_v1(jsonb) owner to cp7_fg_read;
alter function public.erp_cp7_get_fg_ledger_v1(jsonb) owner to cp7_fg_read;
revoke all on all functions in schema cp7_fg from public,anon,authenticated,service_role;
revoke all on function public.erp_cp7_get_fg_v1(jsonb),public.erp_cp7_get_fg_ledger_v1(jsonb) from public,anon,service_role;
grant execute on function public.erp_cp7_get_fg_v1(jsonb),public.erp_cp7_get_fg_ledger_v1(jsonb) to authenticated;
grant create on schema public,cp7_fg to cp7_fg_read,cp7_fg_write;
alter function cp7_fg.adjust_access() owner to cp7_fg_read;
alter function cp7_fg.adjust_signature(uuid) owner to cp7_fg_read;
alter function cp7_fg.adjust_validate(jsonb,uuid) owner to cp7_fg_read;
alter function cp7_fg.adjust_header(erp.fg_adjustments) owner to cp7_fg_read;
alter function cp7_fg.adjust_workspace(jsonb) owner to cp7_fg_read;
alter function cp7_fg.adjust_command(text,jsonb,uuid,text) owner to cp7_fg_write;
alter function public.erp_cp7_get_fg_adjustments_v1(jsonb) owner to cp7_fg_read;
alter function public.erp_cp7_save_fg_adjustment_v1(text,jsonb,uuid,text) owner to cp7_fg_write;
revoke create on schema public,cp7_fg from cp7_fg_read,cp7_fg_write;
revoke all on all functions in schema cp7_fg from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_fg.access_now(text),cp7_fg.adjust_access(),cp7_fg.adjust_signature(uuid),cp7_fg.adjust_validate(jsonb,uuid) to cp7_fg_write;
revoke all on function public.erp_cp7_get_fg_adjustments_v1(jsonb),public.erp_cp7_save_fg_adjustment_v1(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_fg_adjustments_v1(jsonb),public.erp_cp7_save_fg_adjustment_v1(text,jsonb,uuid,text) to authenticated;

grant create on schema public,cp7_fg to cp7_fg_read,cp7_fg_write;
alter function cp7_fg.book_access() owner to cp7_fg_read;
alter function cp7_fg.book_signature() owner to cp7_fg_read;
alter function cp7_fg.book_rows() owner to cp7_fg_read;
alter function cp7_fg.book_query(jsonb) owner to cp7_fg_read;
alter function cp7_fg.book_workspace(jsonb) owner to cp7_fg_read;
alter function cp7_fg.book_anchor(uuid,uuid,text) owner to cp7_fg_read;
alter function cp7_fg.book_options(text,text,integer,integer) owner to cp7_fg_read;
alter function cp7_fg.book_command(text,jsonb,uuid) owner to cp7_fg_write;
alter function public.erp_cp7_get_fg_book_v1(jsonb) owner to cp7_fg_read;
alter function public.erp_cp7_get_fg_book_options_v1(text,text,integer,integer) owner to cp7_fg_read;
alter function public.erp_cp7_save_fg_book_v1(text,jsonb,uuid) owner to cp7_fg_write;
revoke create on schema public,cp7_fg from cp7_fg_read,cp7_fg_write;
revoke all on all functions in schema cp7_fg from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_fg.book_access(),cp7_fg.book_signature(),cp7_fg.book_anchor(uuid,uuid,text) to cp7_fg_write;
revoke all on function public.erp_cp7_get_fg_book_v1(jsonb),public.erp_cp7_get_fg_book_options_v1(text,text,integer,integer),public.erp_cp7_save_fg_book_v1(text,jsonb,uuid) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_fg_book_v1(jsonb),public.erp_cp7_get_fg_book_options_v1(text,text,integer,integer),public.erp_cp7_save_fg_book_v1(text,jsonb,uuid) to authenticated;

-- Effective original-source cards. Prefixes always include the complete scope
-- before display filters/paging; manual order of unrelated cards is preserved.
create function cp7_fg.corrected_book_rows()returns setof jsonb
language sql stable security invoker set search_path=''as $$
 with movements as materialized(
  select m.*,coalesce(l.origin_id,m.id)origin_id,l.correction_id,l.recorded_at correction_recorded_at,
   case when m.movement_type='SALE_RESERVE'or exists(select 1 from erp.fg_stock_movements o
    where o.id=m.reversal_of_id and o.movement_type='SALE_RESERVE')then-m.qty_signed else 0 end reservation_delta
  from erp.fg_stock_movements m left join cp7_fg.correction_movements l on l.member_id=m.id
  where m.physical_at<=statement_timestamp()
 ), effective as materialized(
  select origin_id,sum(qty_signed)qty_signed,sum(reservation_delta)reservation_delta,
   count(distinct correction_id)correction_count,max(correction_recorded_at)correction_recorded_at,
   jsonb_agg(jsonb_build_object('id',id,'physical_at',physical_at,'recorded_at',system_created_at,
    'lot_id',lot_id,'source_type',source_type,'source_id',source_id,'reversal_of_id',reversal_of_id,
    'available_delta',qty_signed::text,'reservation_delta',reservation_delta::text)
    order by system_created_at,id)audit_movements
  from movements group by origin_id
 ), source as materialized(
  select o.*,e.qty_signed effective_qty,e.reservation_delta,e.correction_count,e.correction_recorded_at,e.audit_movements
  from effective e join erp.fg_stock_movements o on o.id=e.origin_id
 ), prefix as(
  select m.*,sum(effective_qty+reservation_delta)over book book_physical_after,
   sum(effective_qty)over book book_available_after,sum(reservation_delta)over book book_reserved_after,
   sum(effective_qty+reservation_delta)over official official_physical_after,
   sum(effective_qty)over official official_available_after,sum(reservation_delta)over official official_reserved_after
  from source m
  window book as(partition by product_id,location_id,quality_grade order by book_order,id rows unbounded preceding),
   official as(partition by product_id,location_id,quality_grade order by physical_at,system_created_at,id rows unbounded preceding)
 )
 select jsonb_build_object('id',m.id,'book_order',m.book_order::text,'physical_at',m.physical_at,
  'recorded_at',m.system_created_at,'product_id',m.product_id,'brand_id',b.id,'brand_name',b.brand_name,
  'commercial_sku',erp.bf_commercial_sku_at_v1(p.id,m.physical_at),'product_name',p.product_name,'size_code',s.size_code,
  'lot_id',m.lot_id,'lot_number',l.lot_number,'location_id',m.location_id,'location_name',loc.location_name,
  'quality_grade',m.quality_grade,'customer_id',m.customer_id,'customer_name',c.customer_name,
  'movement_type',m.movement_type,'source_type',m.source_type,'source_id',m.source_id,'reversal_of_id',m.reversal_of_id,'notes',m.notes,
  'physical_delta',(m.effective_qty+m.reservation_delta)::text,'reservation_delta',m.reservation_delta::text,
  'available_delta',m.effective_qty::text,'book_physical_before',(m.book_physical_after-m.effective_qty-m.reservation_delta)::text,
  'book_physical_after',m.book_physical_after::text,'book_available_after',m.book_available_after::text,
  'book_reserved_after',m.book_reserved_after::text,'official_physical_after',m.official_physical_after::text,
  'official_available_after',m.official_available_after::text,'official_reserved_after',m.official_reserved_after::text,
  'original_physical_delta',(m.qty_signed+case when m.movement_type='SALE_RESERVE'or exists(select 1 from erp.fg_stock_movements o
    where o.id=m.reversal_of_id and o.movement_type='SALE_RESERVE')then-m.qty_signed else 0 end)::text,
  'correction_count',m.correction_count::text,'correction_recorded_at',m.correction_recorded_at,
  'audit_movements',m.audit_movements)
 from prefix m join erp.products p on p.id=m.product_id join erp.brands b on b.id=p.brand_id join erp.sizes s on s.id=p.size_id
 join erp.locations loc on loc.id=m.location_id left join erp.fg_lots l on l.id=m.lot_id left join erp.customers c on c.id=m.customer_id
$$;

create function cp7_fg.corrected_book_workspace(p_query jsonb)returns jsonb
language plpgsql stable security invoker set search_path=''as $$
declare a jsonb;validated jsonb;rows jsonb;total bigint;n integer;off integer;
begin
 a:=cp7_fg.book_access();
 -- Share exact validation, with canonical UUIDs. Do not compute a legacy
 -- complete book that this projection immediately discards.
 validated:=cp7_fg.book_query(p_query);n:=(validated->>'limit')::integer;off:=(validated->>'offset')::integer;
 with filtered as materialized(
  select value r from cp7_fg.corrected_book_rows()value where
   (validated->>'from'is null or(value->>'physical_at')::timestamptz>=(validated->>'from')::timestamptz)
   and(validated->>'to'is null or(value->>'physical_at')::timestamptz<(validated->>'to')::timestamptz)
   and(jsonb_array_length(validated->'brand_ids')=0 or validated->'brand_ids'@>jsonb_build_array(value->>'brand_id'))
   and(jsonb_array_length(validated->'customer_ids')=0 or validated->'customer_ids'@>jsonb_build_array(value->>'customer_id'))
   and(jsonb_array_length(validated->'movement_types')=0 or validated->'movement_types'@>jsonb_build_array(value->>'movement_type'))
   and(validated->>'q'=''or strpos(lower(concat_ws(' ',value->>'brand_name',value->>'commercial_sku',
    value->>'product_name',value->>'size_code',value->>'lot_number',value->>'location_name',value->>'customer_name',
    value->>'source_type',value->>'source_id',value->>'notes')),lower(validated->>'q'))>0)
 ),page as(select r from filtered order by(r->>'book_order')::bigint,r->>'id'limit n offset off)
 select(select count(*)from filtered),coalesce(jsonb_agg(r order by(r->>'book_order')::bigint,r->>'id'),'[]')into total,rows from page;
 return jsonb_build_object('contract_version','cp7.fg-book.v2','read_at',statement_timestamp(),'knowledge','CURRENT',
  'book_token',cp7_fg.book_signature(),'can_order',a->'can_order',
  'quantity_scope','PHYSICAL_PRODUCT_LOCATION_GRADE','presentation_only',true,
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,
  'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows)else null end));
end $$;
create function public.erp_cp7_get_fg_book_v2(p_query jsonb)returns jsonb
language sql stable security definer set search_path=''as $$select cp7_fg.corrected_book_workspace(p_query)$$;
grant create on schema public to cp7_fg_read;
alter function cp7_fg.corrected_book_rows()owner to cp7_fg_read;
alter function cp7_fg.corrected_book_workspace(jsonb)owner to cp7_fg_read;
alter function public.erp_cp7_get_fg_book_v2(jsonb)owner to cp7_fg_read;
revoke create on schema public from cp7_fg_read;
revoke all on function cp7_fg.corrected_book_rows(),cp7_fg.corrected_book_workspace(jsonb)from public,anon,authenticated,service_role,cp7_capture;
revoke all on function public.erp_cp7_get_fg_book_v2(jsonb)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_fg_book_v2(jsonb)to authenticated;

-- Correction presentation only. Every Native movement remains immutable.
-- Filter the physical lot BEFORE grouping: an allocation changing lots must
-- restore the old lot and debit the new lot on their separate cards.
create function cp7_fg.corrected_ledger_rows(p_product uuid,p_lot uuid,p_location uuid,p_grade text)returns setof jsonb
language sql stable security invoker set search_path=''as $$
 with members as materialized(
  select m.*,coalesce(link.origin_id,m.id)origin_id,link.correction_id,link.recorded_at correction_recorded_at,
   case when m.movement_type='SALE_RESERVE'or original.movement_type='SALE_RESERVE'then-m.qty_signed else 0 end reservation_delta
  from erp.fg_stock_movements m left join cp7_fg.correction_movements link on link.member_id=m.id
   left join erp.fg_stock_movements original on original.id=m.reversal_of_id
  where m.product_id=p_product and m.lot_id is not distinct from p_lot
   and m.location_id=p_location and m.quality_grade=p_grade and m.physical_at<=statement_timestamp()
 ),effective as materialized(
  select origin_id,sum(qty_signed)available_delta,sum(reservation_delta)reservation_delta,
   count(distinct correction_id)correction_count,max(correction_recorded_at)correction_recorded_at,
   jsonb_agg(jsonb_build_object('id',id,'physical_at',physical_at,'recorded_at',system_created_at,
    'lot_id',lot_id,'source_type',source_type,'source_id',source_id,'reversal_of_id',reversal_of_id,
    'available_delta',qty_signed::text,'reservation_delta',reservation_delta::text)
    order by system_created_at,id)audit_movements
  from members group by origin_id
 ),sources as materialized(
  select original.*,e.available_delta,e.reservation_delta,e.correction_count,e.correction_recorded_at,e.audit_movements,
   case when original.lot_id is not distinct from p_lot then original.qty_signed else 0 end original_available_delta,
   case when original.lot_id is not distinct from p_lot and(original.movement_type='SALE_RESERVE'or reversed.movement_type='SALE_RESERVE')
    then-original.qty_signed else 0 end original_reserved_delta
  from effective e join erp.fg_stock_movements original on original.id=e.origin_id
   left join erp.fg_stock_movements reversed on reversed.id=original.reversal_of_id
 ),prefix as(
  select s.*,sum(available_delta)over chronology available_balance,sum(reservation_delta)over chronology reserved_balance
  from sources s window chronology as(order by physical_at,system_created_at,id rows unbounded preceding)
 )
 select jsonb_build_object('id',p.id,'physical_at',p.physical_at,'recorded_at',p.system_created_at,
  'movement_type',p.movement_type,'source_type',p.source_type,'source_id',p.source_id,'reversal_of_id',p.reversal_of_id,
  'customer_name',c.customer_name,'notes',p.notes,'book_order',p.book_order::text,
  'commercial_sku_at_transaction',erp.bf_commercial_sku_at_v1(p.product_id,p.physical_at),
  'qty_signed',p.available_delta::text,'reservation_delta',p.reservation_delta::text,
  'physical_delta',(p.available_delta+p.reservation_delta)::text,'available_balance',p.available_balance::text,
  'reserved_balance',p.reserved_balance::text,'physical_balance',(p.available_balance+p.reserved_balance)::text,
  'original_physical_delta',(p.original_available_delta+p.original_reserved_delta)::text,
  'correction_count',p.correction_count::text,'correction_recorded_at',p.correction_recorded_at,
  'audit_movements',p.audit_movements)
 from prefix p left join erp.customers c on c.id=p.customer_id
$$;

create function cp7_fg.corrected_ledger(p_query jsonb)returns jsonb
language plpgsql stable security invoker set search_path=''as $$
declare a jsonb;purpose text;q text;off integer;n integer;pid uuid;lid uuid;location uuid;grade text;
 from_at timestamptz;to_at timestamptz;rows jsonb;total bigint;header jsonb;balances jsonb;cost jsonb;
begin
 if jsonb_typeof(p_query)is distinct from 'object'or exists(select 1 from jsonb_object_keys(p_query)k where k not in('purpose','product_id','lot_id','location_id','quality_grade','q','from','to','offset','limit'))
  or not p_query ?& array['product_id','lot_id','location_id','quality_grade']
  or exists(select 1 from jsonb_each(p_query)e where e.key not in('offset','limit')and jsonb_typeof(e.value)not in('string','null'))
  or(p_query ? 'offset'and(jsonb_typeof(p_query->'offset')<>'number'or(p_query->>'offset')!~'^[0-9]{1,7}$'))
  or(p_query ? 'limit'and(jsonb_typeof(p_query->'limit')<>'number'or(p_query->>'limit')!~'^[0-9]{1,3}$'))then raise exception 'CP7_FG_QUERY';end if;
 purpose:=coalesce(p_query->>'purpose','CARD');if purpose not in('CARD','MOVEMENTS')then raise exception 'CP7_FG_PURPOSE';end if;
 a:=cp7_fg.access_now(purpose);pid:=(p_query->>'product_id')::uuid;lid:=(p_query->>'lot_id')::uuid;location:=(p_query->>'location_id')::uuid;grade:=p_query->>'quality_grade';
 q:=btrim(coalesce(p_query->>'q',''));off:=coalesce((p_query->>'offset')::integer,0);n:=coalesce((p_query->>'limit')::integer,25);
 from_at:=(p_query->>'from')::timestamptz;to_at:=(p_query->>'to')::timestamptz;
 if pid is null or location is null or grade is null or length(grade)>40 or length(q)>120 or off not between 0 and 1000000 or n not between 1 and 100
  or(from_at is not null and not isfinite(from_at))or(to_at is not null and(not isfinite(to_at)or to_at>statement_timestamp()))
  or(from_at is not null and to_at is not null and from_at>=to_at)then raise exception 'CP7_FG_QUERY';end if;
 select jsonb_build_object('product_id',x.product_id,'product_sku',x.product_sku,'commercial_sku',x.commercial_sku,'product_name',x.product_name,'size_code',x.size_code,'brand_name',x.brand_name,
  'lot_id',x.lot_id,'lot_number',x.lot_number,'location_id',x.location_id,'location_name',x.location_name,'quality_grade',x.quality_grade)
 into header from cp7_fg.positions('',true)x where x.product_id=pid and x.lot_id is not distinct from lid and x.location_id=location and x.quality_grade=grade;
 if header is null then raise exception using errcode='P0002',message='CP7_FG_POSITION_UNAVAILABLE';end if;
 if a->'can_value'='true'::jsonb then cost:=cp7_fg.lot_value(lid,1);end if;
 with complete as materialized(select value r from cp7_fg.corrected_ledger_rows(pid,lid,location,grade)value),
 filtered as materialized(select r from complete where(from_at is null or(r->>'physical_at')::timestamptz>=from_at)
  and(to_at is null or(r->>'physical_at')::timestamptz<to_at)
  and(q=''or strpos(lower(concat_ws(' ',r->>'source_type',r->>'source_id',r->>'customer_name',r->>'notes',r->>'movement_type',r->>'commercial_sku_at_transaction')),lower(q))>0)),
 page as(select r from filtered order by(r->>'physical_at')::timestamptz,(r->>'recorded_at')::timestamptz,r->>'id'limit n offset off)
 select(select count(*)from filtered),
  coalesce(jsonb_agg(r||case when a->'can_value'='true'::jsonb then jsonb_build_object('valuation',jsonb_build_object('state',cost->'state',
   'unit_cost',case when cost->>'state'='KNOWN'then cost->>'unit_cost'end,'basis','CURRENT_RESTATED_MOVEMENT_SNAPSHOT'))else '{}'::jsonb end
   order by(r->>'physical_at')::timestamptz,(r->>'recorded_at')::timestamptz,r->>'id'),'[]'),
  (select jsonb_build_object('available_qty',coalesce(sum((r->>'qty_signed')::numeric),0)::text,
   'reserved_qty',coalesce(sum((r->>'reservation_delta')::numeric),0)::text,'physical_qty',coalesce(sum((r->>'physical_delta')::numeric),0)::text,
   'quality',case when bool_or((r->>'available_balance')::numeric<0 or(r->>'reserved_balance')::numeric<0 or(r->>'physical_balance')::numeric<0)then 'CONFLICT'else 'KNOWN'end)
   from complete where to_at is null or(r->>'physical_at')::timestamptz<to_at)
 into total,rows,balances from page;
 return jsonb_build_object('contract_version','cp7.fg-ledger.v2','purpose',purpose,'read_at',statement_timestamp(),'knowledge','CURRENT','financial_captured',a->'can_value',
  'position',header,'balances',balances,'balance_basis','COMPLETE_CHRONOLOGICAL_PREFIX_BEFORE_SEARCH_AND_PAGE',
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows)else null end));
end $$;
create function public.erp_cp7_get_fg_ledger_v2(p_query jsonb)returns jsonb
language sql stable security definer set search_path=''as $$select cp7_fg.corrected_ledger(p_query)$$;
grant create on schema public to cp7_fg_read;
alter function cp7_fg.corrected_ledger_rows(uuid,uuid,uuid,text)owner to cp7_fg_read;
alter function cp7_fg.corrected_ledger(jsonb)owner to cp7_fg_read;
alter function public.erp_cp7_get_fg_ledger_v2(jsonb)owner to cp7_fg_read;
revoke create on schema public from cp7_fg_read;
revoke all on function cp7_fg.corrected_ledger_rows(uuid,uuid,uuid,text),cp7_fg.corrected_ledger(jsonb)from public,anon,authenticated,service_role,cp7_capture;
revoke all on function public.erp_cp7_get_fg_ledger_v2(jsonb)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_fg_ledger_v2(jsonb)to authenticated;

-- P10/P12 candidate source module; not installed by the FG bundle.
-- Native component entitlements, never QC GOOD or browser tariff calculations.
create role cp7_payroll_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_payroll authorization cp7_payroll_read;
revoke all on schema cp7_payroll from public,anon,authenticated,service_role;
grant usage on schema auth,erp to cp7_payroll_read;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_payroll_read;
-- Both accepted eligibility views use security_invoker: grant their complete,
-- explicit dependency closure, not schema-wide SELECT or elevated view ownership.
grant select on erp.v_payroll_eligible_work_lines,erp.v_payroll_production_work_eligibility,
 erp.laundry_delivery_lines,erp.laundry_deliveries,erp.laundry_receipt_lines,erp.laundry_receipts,
 erp.payroll_work_items,erp.payroll_settlements,erp.bs_case_components,erp.bs_cases,
 erp.contractors,erp.work_components,erp.work_completion_lines,erp.work_completion_events,
 erp.rework_component_lines,erp.rework_orders,erp.fg_unsourced_repair_wages_v1,erp.fg_unsourced_receipts_v1,
 erp.production_orders,erp.cutting_groups to cp7_payroll_read;

create function cp7_payroll.access_now(p_purpose text) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;k text;
begin
 k:=case p_purpose when 'NOTA' then 'production.fg_handoff.view' when 'PAYROLL' then 'finance.payroll.view' end;
 if k is null or auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_PAYROLL_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission(k) then raise exception using errcode='42501',message='CP7_PAYROLL_ACCESS_DENIED';end if;
 return jsonb_build_object('actor',auth.uid(),'profile',a->'profile','permissions',a->'permissions',
  'financial',erp.has_permission('finance.payroll.view'),'can_post_nota',erp.has_permission('production.fg_handoff.post'));
end $$;

create function cp7_payroll.source_lines() returns table(
 source_type text,source_id uuid,origin_id uuid,origin_number text,contractor_id uuid,contractor_name text,contractor_active boolean,
 po_id uuid,po_number text,cutting_group_id uuid,group_number text,bs_case_id uuid,work_component_id uuid,component_code text,component_name text,component_order integer,
 eligible_at timestamptz,source_qty integer,eligible_qty integer,allocated_qty integer,remaining_qty integer,held_qty integer,rate_snapshot numeric,remaining_amount numeric,eligibility_reason text,source_revision text
) language sql stable security invoker set search_path='' as $$
 select e.source_type,e.source_id,coalesce(w.id,ro.id,receipt.id),coalesce(w.completion_number,ro.rework_number,receipt.id::text)::text,
  e.contractor_id,c.contractor_name::text,c.is_active,e.po_id,po.po_number::text,e.cutting_group_id,cg.group_number::text,e.bs_case_id,
  e.work_component_id,wc.component_code::text,wc.component_name::text,wc.sequence_default,e.eligible_at,e.source_qty,e.eligible_qty,e.allocated_qty,e.remaining_qty,e.held_qty,e.rate_snapshot,e.remaining_amount,e.eligibility_reason,concat_ws(':',wl.xmin::text,w.xmin::text,rl.xmin::text,ro.xmin::text,repair.xmin::text,receipt.xmin::text)
 from erp.v_payroll_eligible_work_lines e join erp.contractors c on c.id=e.contractor_id join erp.work_components wc on wc.id=e.work_component_id
 left join erp.production_orders po on po.id=e.po_id left join erp.cutting_groups cg on cg.id=e.cutting_group_id
 left join erp.work_completion_lines wl on e.source_type='PRODUCTION' and wl.id=e.source_id left join erp.work_completion_events w on w.id=wl.completion_id
 left join erp.rework_component_lines rl on e.source_type='REWORK' and rl.id=e.source_id left join erp.rework_orders ro on ro.id=rl.rework_order_id
 left join erp.fg_unsourced_repair_wages_v1 repair on e.source_type='FG_REPAIR' and repair.id=e.source_id left join erp.fg_unsourced_receipts_v1 receipt on receipt.id=repair.receipt_id
$$;

create function cp7_payroll.source_cards(p_financial boolean) returns table(card_key text,contractor_id uuid,eligible_at timestamptz,search_text text,card jsonb)
language sql stable security invoker set search_path='' as $$
 with grouped as(
  select e.source_type,e.origin_id,e.origin_number,e.contractor_id,e.contractor_name,e.contractor_active,e.po_id,e.po_number,e.cutting_group_id,e.group_number,e.bs_case_id,
   min(e.eligible_at) eligible_at,count(*) line_count,
   md5(jsonb_agg(jsonb_build_array(e.source_id,e.work_component_id,e.source_qty,e.eligible_qty,e.allocated_qty,e.remaining_qty,e.held_qty,e.source_revision,extract(epoch from e.eligible_at)) order by e.source_id,e.work_component_id)::text) source_token,
   sum(e.remaining_amount) remaining_amount,
   jsonb_agg(jsonb_build_object('source_type',e.source_type,'source_id',e.source_id,'component_id',e.work_component_id,'component_code',e.component_code,'component_name',e.component_name,
    'source_qty',e.source_qty::text,'eligible_qty',e.eligible_qty::text,'allocated_qty',e.allocated_qty::text,'remaining_qty',e.remaining_qty::text,'held_qty',e.held_qty::text,
    'eligible_at',to_char(e.eligible_at at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'eligibility_reason',e.eligibility_reason)
    ||case when p_financial then jsonb_build_object('rate',e.rate_snapshot::text,'amount',e.remaining_amount::text) else '{}'::jsonb end order by e.component_order,e.source_id) lines
  from cp7_payroll.source_lines() e
  group by e.source_type,e.origin_id,e.origin_number,e.contractor_id,e.contractor_name,e.contractor_active,e.po_id,e.po_number,e.cutting_group_id,e.group_number,e.bs_case_id
 )
 select source_type||':'||origin_id||':'||contractor_id,contractor_id,eligible_at,lower(concat_ws(' ',origin_number,contractor_name,po_number,group_number)),
  jsonb_build_object('card_key',source_type||':'||origin_id||':'||contractor_id,'source_type',source_type,'origin_id',origin_id,'origin_number',origin_number,'contractor_id',contractor_id,'contractor_name',contractor_name,
   'contractor_active',contractor_active,'po_id',po_id,'po_number',po_number,'cutting_group_id',cutting_group_id,'group_number',group_number,'bs_case_id',bs_case_id,'eligible_at',to_char(eligible_at at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
   'line_count',line_count::text,'source_token',source_token,'lines',lines,'basis','NATIVE_REMAINING_COMPONENT_ENTITLEMENT')
   ||case when p_financial then jsonb_build_object('remaining_amount',remaining_amount::text) else '{}'::jsonb end
 from grouped
$$;

create function cp7_payroll.source_workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;q text;n integer;off integer;contractor uuid;rows jsonb;total bigint;
begin
 a:=cp7_payroll.access_now('NOTA');
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','contractor_id','limit','offset'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','contractor_id') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query?'limit' and (jsonb_typeof(p_query->'limit')<>'number' or(p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query?'offset' and (jsonb_typeof(p_query->'offset')<>'number' or(p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_PAYROLL_SOURCE_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));contractor:=(p_query->>'contractor_id')::uuid;n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);
 if length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000 then raise exception 'CP7_PAYROLL_SOURCE_QUERY';end if;
 with filtered as materialized(select * from cp7_payroll.source_cards((a->>'financial')::boolean) c where(contractor is null or c.contractor_id=contractor) and(q='' or strpos(c.search_text,lower(q))>0)),
 page as(select * from filtered order by eligible_at,card_key limit n offset off)
 select(select count(*) from filtered),coalesce(jsonb_agg(card order by eligible_at,card_key),'[]') into total,rows from page;
 return jsonb_build_object('contract_version','cp7.nota-sources.v1','read_at',statement_timestamp(),'financial_captured',a->'financial','can_post',a->'can_post_nota',
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;

-- Source-only first increment. Note writers are not enabled by this module.
create function public.erp_cp7_get_nota_sources_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_payroll.source_workspace(p_query)$$;
grant create on schema public,cp7_payroll to cp7_payroll_read;
alter function cp7_payroll.access_now(text) owner to cp7_payroll_read;
alter function cp7_payroll.source_lines() owner to cp7_payroll_read;
alter function cp7_payroll.source_cards(boolean) owner to cp7_payroll_read;
alter function cp7_payroll.source_workspace(jsonb) owner to cp7_payroll_read;
alter function public.erp_cp7_get_nota_sources_v1(jsonb) owner to cp7_payroll_read;
revoke create on schema public,cp7_payroll from cp7_payroll_read;
revoke all on all functions in schema cp7_payroll from public,anon,authenticated,service_role,cp7_capture;
revoke all on function public.erp_cp7_get_nota_sources_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_nota_sources_v1(jsonb) to authenticated;

-- Selected complete source cards compose a Nota. Native payroll allocations are
-- the only payable reservation; composing/posting never creates FG or labor cost.
create role cp7_nota_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create role cp7_payroll_header nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
grant usage on schema cp7_payroll,auth,erp to cp7_nota_write,cp7_payroll_header;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_nota_write,cp7_payroll_header;
grant execute on function erp.merge_eligible_work_into_payroll_v2(uuid,jsonb,uuid,bigint) to cp7_nota_write;
-- No financial/status column mutation, item DML, or general ERP writer grant.
grant select on erp.payroll_settlements to cp7_payroll_header;
grant insert(id,payroll_number,contractor_id,period_start,period_end,notes) on erp.payroll_settlements to cp7_payroll_header;
grant update(id) on erp.payroll_settlements to cp7_payroll_header;

create table cp7_payroll.notes(
 id uuid primary key default gen_random_uuid(),note_number text not null unique,
 contractor_id uuid not null,note_date date not null,period_start date not null,period_end date not null,
 notes text not null default '',target_payroll_id uuid,target_version text,
 cards jsonb not null,status text not null check(status in('DRAFT','POSTED','VOID')),
 row_version bigint not null default 1,created_by uuid not null,updated_by uuid not null,
 created_at timestamptz not null default statement_timestamp(),updated_at timestamptz not null default statement_timestamp(),
 posted_payroll_id uuid,posted_at timestamptz,void_reason text,
 check(period_start<=period_end)
);
create table cp7_payroll.card_claims(card_key text primary key,note_id uuid not null references cp7_payroll.notes(id));
create table cp7_payroll.note_requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text,response jsonb,primary key(actor,request_id));
create table cp7_payroll.execution_context(backend_pid integer not null,transaction_id bigint not null,actor uuid not null,action text not null check(action='POST_NOTE'),permission_key text not null check(permission_key='production.fg_handoff.post'),primary key(backend_pid,transaction_id));
alter table cp7_payroll.notes owner to cp7_nota_write;
alter table cp7_payroll.card_claims owner to cp7_nota_write;
alter table cp7_payroll.note_requests owner to cp7_nota_write;
alter table cp7_payroll.execution_context owner to cp7_nota_write;
alter table cp7_payroll.notes enable row level security;
alter table cp7_payroll.card_claims enable row level security;
alter table cp7_payroll.note_requests enable row level security;
alter table cp7_payroll.execution_context enable row level security;
revoke all on cp7_payroll.notes,cp7_payroll.card_claims,cp7_payroll.note_requests from public,anon,authenticated,service_role,cp7_capture;
revoke all on cp7_payroll.execution_context from public,anon,authenticated,service_role,cp7_capture,cp7_payroll_read,cp7_payroll_header;
grant select on cp7_payroll.notes,cp7_payroll.card_claims to cp7_payroll_read;

create function cp7_payroll.note_access() returns jsonb
language plpgsql stable security definer set search_path='' as $$
begin return cp7_payroll.access_now('NOTA');end $$;

create function cp7_payroll.note_capture(p_cards jsonb,p_contractor uuid,p_end date) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare v jsonb;c jsonb;result jsonb:='[]';seen text[]:='{}';line_count integer:=0;
begin
 perform cp7_payroll.access_now('NOTA');
 if p_contractor is null or p_end is null or jsonb_typeof(p_cards) is distinct from 'array' or jsonb_array_length(p_cards) not between 1 and 50 then raise exception 'CP7_NOTA_CARDS';end if;
 for v in select value from jsonb_array_elements(p_cards) order by value->>'card_key' loop
  if jsonb_typeof(v) is distinct from 'object' or not v ?& array['card_key','source_token']
   or exists(select 1 from jsonb_each(v) e where e.key not in('card_key','source_token') or jsonb_typeof(e.value)<>'string')
   or coalesce(v->>'source_token','')!~'^[a-f0-9]{32}$' or v->>'card_key'=any(seen) then raise exception 'CP7_NOTA_EXACT_CARD';end if;
  seen:=array_append(seen,v->>'card_key');
  select s.card into c from cp7_payroll.source_cards(true) s where s.card_key=v->>'card_key';
  if c is null or c->>'source_token' is distinct from v->>'source_token' then raise exception 'CP7_NOTA_SOURCE_CHANGED';end if;
  if (c->>'contractor_id')::uuid<>p_contractor then raise exception 'CP7_NOTA_DIFFERENT_CONTRACTOR';end if;
  if exists(select 1 from jsonb_array_elements(c->'lines') l where ((l->>'eligible_at')::timestamptz at time zone 'Asia/Jakarta')::date>p_end) then raise exception 'CP7_NOTA_AFTER_PERIOD';end if;
  line_count:=line_count+jsonb_array_length(c->'lines');if line_count>500 then raise exception 'CP7_NOTA_TOO_MANY_COMPONENTS';end if;
  result:=result||jsonb_build_array(c);
 end loop;
 return result;
end $$;

create function cp7_payroll.note_payroll(p_id uuid,p_contractor uuid,p_start date,p_end date) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare p erp.payroll_settlements;
begin
 perform cp7_payroll.access_now('NOTA');
 select * into p from erp.payroll_settlements where id=p_id;
 if p.id is null or p.contractor_id<>p_contractor or p.period_start<>p_start or p.period_end<>p_end or p.status not in('DRAFT','CALCULATED','REVIEW') then raise exception 'CP7_NOTA_PAYROLL_TARGET_CHANGED';end if;
 return jsonb_build_object('id',p.id,'row_version',p.row_version::text);
end $$;

create function cp7_payroll.note_header(p_id uuid,p_contractor uuid,p_start date,p_end date,p_expected text,p_note uuid) returns jsonb
language plpgsql volatile security definer set search_path='' as $$
declare p erp.payroll_settlements;a jsonb;
begin
 a:=cp7_payroll.note_access();if a->'can_post_nota' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_NOTA_WRITE_DENIED';end if;
 if p_id is null then
  -- Native period-overlap trigger serializes new headers for the contractor.
  insert into erp.payroll_settlements(id,payroll_number,contractor_id,period_start,period_end,notes)
  values(gen_random_uuid(),'PAY-'||p_note::text,p_contractor,p_start,p_end,'Dibuat dari Nota FG '||p_note::text) returning * into p;
 else
  -- Match native lock order: payroll header, then contractor, then work sources.
  select * into p from erp.payroll_settlements where id=p_id for update;
  if p.id is null or p.row_version::text is distinct from p_expected or p.contractor_id<>p_contractor or p.period_start<>p_start or p.period_end<>p_end or p.status not in('DRAFT','CALCULATED','REVIEW') then raise exception 'CP7_NOTA_PAYROLL_TARGET_CHANGED';end if;
 end if;
 if cp7_payroll.note_access() is distinct from a then raise exception using errcode='42501',message='CP7_NOTA_ACCESS_CHANGED';end if;
 return jsonb_build_object('id',p.id,'row_version',p.row_version::text);
end $$;

create function cp7_payroll.note_allocation(p_id uuid) returns jsonb
language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(jsonb_build_object('source_type',i.source_type,'source_id',i.source_id,'component_id',i.work_component_id,'qty',i.qty_payable::text,'rate',i.rate_snapshot::text) order by i.id),'[]')
 from erp.payroll_work_items i where i.payroll_id=p_id
$$;

create function cp7_payroll.note_verify_allocation(p_id uuid,p_before jsonb,p_cards jsonb) returns void
language plpgsql stable security definer set search_path='' as $$
declare c jsonb;l jsonb;old_qty integer;i erp.payroll_work_items;
begin
 for c in select value from jsonb_array_elements(p_cards) loop
  for l in select value from jsonb_array_elements(c->'lines') loop
   select coalesce(sum((x->>'qty')::integer),0)::integer into old_qty from jsonb_array_elements(p_before) x where x->>'source_type'=l->>'source_type' and x->>'source_id'=l->>'source_id' and x->>'component_id'=l->>'component_id';
   select * into i from erp.payroll_work_items where payroll_id=p_id and source_type=l->>'source_type' and source_id=(l->>'source_id')::uuid and work_component_id=(l->>'component_id')::uuid;
   if i.id is null or i.qty_payable<>old_qty+(l->>'remaining_qty')::integer or i.rate_snapshot<>(l->>'rate')::numeric then raise exception 'CP7_NOTA_NATIVE_ALLOCATION_CHANGED';end if;
  end loop;
 end loop;
end $$;

create function cp7_payroll.note_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_payroll.note_requests;n cp7_payroll.notes;ident uuid;cid uuid;start_at date;end_at date;note_at date;snapshot_cards jsonb;target jsonb;prior jsonb;lines jsonb;r jsonb;refs jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_payroll.note_access();if a->'can_post_nota' is distinct from 'true'::jsonb then raise exception using errcode='42501',message='CP7_NOTA_WRITE_DENIED';end if;
 if p_action is null or p_action not in('SAVE','POST','VOID') or p_request is null or jsonb_typeof(p_payload) is distinct from 'object'
  or p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$' then raise exception 'CP7_NOTA_FIELDS';end if;
 insert into cp7_payroll.note_requests values(auth.uid(),p_request,p_action,p_payload,p_expected,null) on conflict do nothing;
 select * into old from cp7_payroll.note_requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_NOTA_REQUEST_CHANGED';end if;
 if cp7_payroll.note_access() is distinct from a then raise exception using errcode='42501',message='CP7_NOTA_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 ident:=(p_payload->>'id')::uuid;
 if ident is not null then
  select * into n from cp7_payroll.notes where id=ident for update;
  if n.id is null or n.row_version::text is distinct from p_expected then raise exception 'CP7_NOTA_STALE_VERSION';end if;
  if n.status<>'DRAFT' then raise exception 'CP7_NOTA_LOCKED';end if;
 elsif p_action<>'SAVE' or p_expected is not null then raise exception 'CP7_NOTA_FIELDS';end if;
 if p_action='SAVE' then
  if not p_payload ?& array['contractor_id','note_date','period_start','period_end','cards']
   or exists(select 1 from jsonb_each(p_payload) e where e.key not in('id','contractor_id','note_date','period_start','period_end','cards','target_payroll_id','notes') or(e.key<>'cards' and jsonb_typeof(e.value) not in('string','null')))
   or exists(select 1 from unnest(array['note_date','period_start','period_end']) k where coalesce(p_payload->>k,'')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$')
   or length(coalesce(p_payload->>'notes',''))>2000 then raise exception 'CP7_NOTA_FIELDS';end if;
  cid:=(p_payload->>'contractor_id')::uuid;start_at:=(p_payload->>'period_start')::date;end_at:=(p_payload->>'period_end')::date;note_at:=(p_payload->>'note_date')::date;
  if start_at>end_at or note_at>(statement_timestamp() at time zone 'Asia/Jakarta')::date then raise exception 'CP7_NOTA_DATES';end if;
  snapshot_cards:=cp7_payroll.note_capture(p_payload->'cards',cid,end_at);
  if p_payload->>'target_payroll_id' is not null then target:=cp7_payroll.note_payroll((p_payload->>'target_payroll_id')::uuid,cid,start_at,end_at);end if;
  if ident is null then
   ident:=gen_random_uuid();
   insert into cp7_payroll.notes(id,note_number,contractor_id,note_date,period_start,period_end,notes,target_payroll_id,target_version,cards,status,created_by,updated_by)
   values(ident,'NFG-'||ident::text,cid,note_at,start_at,end_at,coalesce(p_payload->>'notes',''),(target->>'id')::uuid,target->>'row_version',snapshot_cards,'DRAFT',auth.uid(),auth.uid());
  else
   update cp7_payroll.notes set contractor_id=cid,note_date=note_at,period_start=start_at,period_end=end_at,notes=coalesce(p_payload->>'notes',''),target_payroll_id=(target->>'id')::uuid,target_version=target->>'row_version',cards=snapshot_cards,row_version=row_version+1,updated_by=auth.uid(),updated_at=statement_timestamp() where id=ident;
  end if;
  delete from cp7_payroll.card_claims where note_id=ident;
  if exists(select 1 from cp7_payroll.card_claims q join jsonb_array_elements(snapshot_cards) c on c->>'card_key'=q.card_key) then raise exception 'CP7_NOTA_CARD_IN_OTHER_DRAFT';end if;
  insert into cp7_payroll.card_claims select c->>'card_key',ident from jsonb_array_elements(snapshot_cards) c order by c->>'card_key';
 elsif p_action='VOID' then
  if not p_payload ?& array['id','change_reason'] or exists(select 1 from jsonb_each(p_payload) e where e.key not in('id','change_reason') or jsonb_typeof(e.value)<>'string') or length(btrim(p_payload->>'change_reason')) not between 5 and 1000 then raise exception 'CP7_NOTA_REASON';end if;
  update cp7_payroll.notes set status='VOID',void_reason=btrim(p_payload->>'change_reason'),row_version=row_version+1,updated_by=auth.uid(),updated_at=statement_timestamp() where id=ident;
  delete from cp7_payroll.card_claims where note_id=ident;
 else
  if not p_payload ?& array['id','change_reason'] or exists(select 1 from jsonb_each(p_payload) e where e.key not in('id','change_reason') or jsonb_typeof(e.value)<>'string') or length(btrim(p_payload->>'change_reason')) not between 5 and 1000 then raise exception 'CP7_NOTA_REASON';end if;
  target:=cp7_payroll.note_header(n.target_payroll_id,n.contractor_id,n.period_start,n.period_end,n.target_version,n.id);
  select jsonb_agg(jsonb_build_object('card_key',c->'card_key','source_token',c->'source_token') order by c->>'card_key') into refs from jsonb_array_elements(n.cards) c;
  snapshot_cards:=cp7_payroll.note_capture(refs,n.contractor_id,n.period_end);
  if snapshot_cards is distinct from n.cards then raise exception 'CP7_NOTA_SOURCE_CHANGED';end if;
  prior:=cp7_payroll.note_allocation((target->>'id')::uuid);
  select jsonb_agg(jsonb_build_object('source_type',l->'source_type','source_id',l->'source_id','qty',(l->>'remaining_qty')::integer) order by l->>'source_type',l->>'source_id') into lines from jsonb_array_elements(snapshot_cards) c cross join lateral jsonb_array_elements(c->'lines') l;
  perform set_config('app.change_reason',btrim(p_payload->>'change_reason'),true);
  -- The private envelope owns retry identity. Do not forward an untrusted UUID
  -- into another scope's cache; its native request commits atomically with ours.
  insert into cp7_payroll.execution_context values(pg_backend_pid(),txid_current(),auth.uid(),'POST_NOTE','production.fg_handoff.post');
  r:=erp.merge_eligible_work_into_payroll_v2((target->>'id')::uuid,lines,gen_random_uuid(),(target->>'row_version')::bigint);
  delete from cp7_payroll.execution_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
  perform cp7_payroll.note_verify_allocation((target->>'id')::uuid,prior,snapshot_cards);
  update cp7_payroll.notes set status='POSTED',posted_payroll_id=(target->>'id')::uuid,posted_at=statement_timestamp(),row_version=row_version+1,updated_by=auth.uid(),updated_at=statement_timestamp() where id=ident;
  delete from cp7_payroll.card_claims where note_id=ident;
 end if;
 if cp7_payroll.note_access() is distinct from a then raise exception using errcode='42501',message='CP7_NOTA_ACCESS_CHANGED';end if;
 select * into n from cp7_payroll.notes where id=ident;
 r:=jsonb_build_object('contract_version','cp7.nota-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'note_id',n.id,'status',n.status,'row_version',n.row_version::text,'payroll_id',n.posted_payroll_id);
 update cp7_payroll.note_requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;

create function public.erp_cp7_save_nota_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_payroll.note_command(p_action,p_payload,p_request,p_expected)$$;

create function cp7_payroll.note_project_card(p_card jsonb,p_financial boolean) returns jsonb
language sql immutable security invoker set search_path='' as $$
 select case when p_financial then p_card else jsonb_set(p_card-'remaining_amount','{lines}',(select coalesce(jsonb_agg(l-'rate'-'amount' order by ord),'[]') from jsonb_array_elements(p_card->'lines') with ordinality a(l,ord))) end
$$;

create function cp7_payroll.note_document(p_note cp7_payroll.notes,p_financial boolean) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',p_note.id,'note_number',p_note.note_number,'contractor_id',p_note.contractor_id,'contractor_name',c.contractor_name,
  'note_date',p_note.note_date,'period_start',p_note.period_start,'period_end',p_note.period_end,'notes',p_note.notes,'status',p_note.status,'row_version',p_note.row_version::text,
  'target_payroll_id',p_note.target_payroll_id,'target_version',p_note.target_version,'posted_payroll_id',p_note.posted_payroll_id,
  'payroll_number',p.payroll_number,'payroll_status',p.status,'posted_at',p_note.posted_at,'void_reason',p_note.void_reason,
  'created_at',p_note.created_at,'updated_at',p_note.updated_at,
  'cards',(select jsonb_agg(cp7_payroll.note_project_card(x,p_financial) order by ord) from jsonb_array_elements(p_note.cards) with ordinality a(x,ord)))
  ||case when p_financial then jsonb_build_object('amount',(select sum((x->>'remaining_amount')::numeric)::text from jsonb_array_elements(p_note.cards) x)) else '{}'::jsonb end
 from erp.contractors c left join erp.payroll_settlements p on p.id=coalesce(p_note.posted_payroll_id,p_note.target_payroll_id) where c.id=p_note.contractor_id
$$;

create function cp7_payroll.note_workspace(p_section text,p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;w jsonb;rows jsonb;total bigint;n integer;off integer;contractor uuid;ident uuid;q text;
begin
 a:=cp7_payroll.access_now('NOTA');
 if p_section is null or p_section not in('SOURCES','NOTES','PAYROLLS') or jsonb_typeof(p_query) is distinct from 'object'
  or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','contractor_id','id','limit','offset'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','contractor_id','id') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query?'limit' and (jsonb_typeof(p_query->'limit')<>'number' or(p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query?'offset' and (jsonb_typeof(p_query->'offset')<>'number' or(p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_NOTA_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));contractor:=(p_query->>'contractor_id')::uuid;ident:=(p_query->>'id')::uuid;n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);
 if length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000 or (ident is not null and p_section<>'NOTES') or(p_section='PAYROLLS' and contractor is null) then raise exception 'CP7_NOTA_QUERY';end if;
 if p_section='SOURCES' then
  w:=cp7_payroll.source_workspace(p_query-'id');
  select coalesce(jsonb_agg(x||jsonb_build_object('claimed_by_note',c.note_id) order by ord),'[]') into rows from jsonb_array_elements(w->'page'->'rows') with ordinality a(x,ord) left join cp7_payroll.card_claims c on c.card_key=x->>'card_key';
  w:=jsonb_set(w,'{page,rows}',rows);
 else
  if p_section='NOTES' then
   with filtered as materialized(select h.* from cp7_payroll.notes h join erp.contractors c on c.id=h.contractor_id
    where (contractor is null or h.contractor_id=contractor) and(ident is null or h.id=ident) and(q='' or strpos(lower(concat_ws(' ',h.note_number,c.contractor_name,h.notes)),lower(q))>0)),
   page as(select * from filtered order by created_at desc,id limit n offset off)
   select(select count(*) from filtered),coalesce(jsonb_agg(cp7_payroll.note_document(page::cp7_payroll.notes,(a->>'financial')::boolean) order by created_at desc,id),'[]') into total,rows from page;
  else
   with filtered as materialized(select p.* from erp.payroll_settlements p where p.contractor_id=contractor and p.status in('DRAFT','CALCULATED','REVIEW') and(q='' or strpos(lower(p.payroll_number),lower(q))>0)),
   page as(select * from filtered order by period_end desc,id limit n offset off)
   select(select count(*) from filtered),coalesce(jsonb_agg(jsonb_build_object('id',id,'payroll_number',payroll_number,'contractor_id',contractor_id,'period_start',period_start,'period_end',period_end,'status',status,'row_version',row_version::text) order by period_end desc,id),'[]') into total,rows from page;
  end if;
  w:=jsonb_build_object('page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
 end if;
 return w||jsonb_build_object('contract_version','cp7.nota-workspace.v1','section',p_section,'read_at',statement_timestamp(),'financial_captured',a->'financial','can_post',a->'can_post_nota');
end $$;
create function public.erp_cp7_get_nota_workspace_v1(p_section text,p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_payroll.note_workspace(p_section,p_query)$$;

grant create on schema public,cp7_payroll to cp7_payroll_read,cp7_nota_write,cp7_payroll_header;
alter function cp7_payroll.note_access() owner to cp7_payroll_read;
alter function cp7_payroll.note_capture(jsonb,uuid,date) owner to cp7_payroll_read;
alter function cp7_payroll.note_payroll(uuid,uuid,date,date) owner to cp7_payroll_read;
alter function cp7_payroll.note_header(uuid,uuid,date,date,text,uuid) owner to cp7_payroll_header;
alter function cp7_payroll.note_allocation(uuid) owner to cp7_payroll_read;
alter function cp7_payroll.note_verify_allocation(uuid,jsonb,jsonb) owner to cp7_payroll_read;
alter function cp7_payroll.note_command(text,jsonb,uuid,text) owner to cp7_nota_write;
alter function cp7_payroll.note_project_card(jsonb,boolean) owner to cp7_payroll_read;
alter function cp7_payroll.note_document(cp7_payroll.notes,boolean) owner to cp7_payroll_read;
alter function cp7_payroll.note_workspace(text,jsonb) owner to cp7_payroll_read;
alter function public.erp_cp7_get_nota_workspace_v1(text,jsonb) owner to cp7_payroll_read;
alter function public.erp_cp7_save_nota_v1(text,jsonb,uuid,text) owner to cp7_nota_write;
revoke create on schema public,cp7_payroll from cp7_payroll_read,cp7_nota_write,cp7_payroll_header;
revoke all on all functions in schema cp7_payroll from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_payroll.note_access() to cp7_nota_write,cp7_payroll_header;
grant execute on function cp7_payroll.note_capture(jsonb,uuid,date),cp7_payroll.note_payroll(uuid,uuid,date,date),cp7_payroll.note_header(uuid,uuid,date,date,text,uuid),cp7_payroll.note_allocation(uuid),cp7_payroll.note_verify_allocation(uuid,jsonb,jsonb) to cp7_nota_write;
revoke all on function public.erp_cp7_get_nota_workspace_v1(text,jsonb),public.erp_cp7_save_nota_v1(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_nota_workspace_v1(text,jsonb),public.erp_cp7_save_nota_v1(text,jsonb,uuid,text) to authenticated;

do $patch$ declare old_definition text; begin
 if (select encode(extensions.digest(prosrc,'sha256'),'hex') from pg_proc where oid='erp.require_internal()'::regprocedure) <> '59c933d8f03e06525a376f5500b8b5d4e30455f878384ca7be5ff1d450282bb7' then raise exception 'CP7_NOTA_ADMISSION_PREDECESSOR_CHANGED';end if;
 old_definition:=pg_get_functiondef('erp.require_internal()'::regprocedure);
 execute replace(old_definition,$anchor$ v_app_role:=erp.current_app_role();$anchor$,$delta$ if exists(select 1 from cp7_payroll.execution_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
   and c.action='POST_NOTE' and c.permission_key='production.fg_handoff.post'
   then erp.has_permission('production.fg_handoff.view') and erp.has_permission(c.permission_key) else false end) then return;end if;
 v_app_role:=erp.current_app_role();$delta$);
end $patch$;
-- P12 finance-owned payroll review. Not included in Nota/source bundles.
-- Financial amounts are native snapshots. This reader never populates, approves,
-- pays, or recalculates a payroll as a read side effect.
grant select on erp.payroll_attendance_items,erp.payroll_reimbursements,
 erp.payroll_deductions,erp.cash_accounts to cp7_payroll_read;

create function cp7_payroll.settlement_token(p_id uuid) returns text
language sql stable security invoker set search_path='' as $$
 select md5(jsonb_build_array(
  p.id,p.xmin::text,p.row_version,
  (select coalesce(jsonb_agg(jsonb_build_array(i.id,i.xmin::text) order by i.id),'[]') from erp.payroll_work_items i where i.payroll_id=p.id),
  (select coalesce(jsonb_agg(jsonb_build_array(i.id,i.xmin::text) order by i.id),'[]') from erp.payroll_attendance_items i where i.payroll_id=p.id),
  (select coalesce(jsonb_agg(jsonb_build_array(i.id,i.xmin::text) order by i.id),'[]') from erp.payroll_reimbursements i where i.payroll_id=p.id),
  (select coalesce(jsonb_agg(jsonb_build_array(i.id,i.xmin::text) order by i.id),'[]') from erp.payroll_deductions i where i.payroll_id=p.id),
  (select coalesce(jsonb_agg(jsonb_build_array(n.id,n.row_version) order by n.id),'[]') from cp7_payroll.notes n where n.posted_payroll_id=p.id)
 )::text) from erp.payroll_settlements p where p.id=p_id
$$;

create function cp7_payroll.settlement_document(p_id uuid) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',p.id,'payroll_number',p.payroll_number,'contractor_id',p.contractor_id,'contractor_name',c.contractor_name,
  'attendance_required',c.attendance_required,'period_start',p.period_start,'period_end',p.period_end,'status',p.status,'row_version',p.row_version::text,
  'review_token',cp7_payroll.settlement_token(p.id),'notes',p.notes,'labor_total',p.labor_total::text,'attendance_total',p.attendance_total::text,
  'reimburse_total',p.reimburse_total::text,'deduction_total',p.deduction_total::text,'manual_adjustment',p.manual_adjustment::text,'net_payable',p.net_payable::text,
  'payment_cash_account_id',p.payment_cash_account_id,'payment_cash_account_name',a.cash_account_name,'payment_date',p.payment_date,
  'settled_at',to_char(p.settled_at at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
  'created_at',to_char(p.created_at at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
  'updated_at',to_char(p.updated_at at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
  -- A frozen payroll is compared with its own items; the contractor flag is
  -- editable master data and only describes what a new calculation would build.
  'totals_match_items',p.labor_total=(select coalesce(sum(i.amount),0) from erp.payroll_work_items i where i.payroll_id=p.id)
   and p.attendance_total=case when c.attendance_required or p.status in('APPROVED','PAID','REVERSED') then(select coalesce(sum(i.amount),0) from erp.payroll_attendance_items i where i.payroll_id=p.id) else 0 end
   and p.reimburse_total=(select coalesce(sum(i.amount),0) from erp.payroll_reimbursements i where i.payroll_id=p.id)
   and p.deduction_total=(select coalesce(sum(i.amount),0) from erp.payroll_deductions i where i.payroll_id=p.id),
  'counts',jsonb_build_object(
   'work',(select count(*)::text from erp.payroll_work_items i where i.payroll_id=p.id),
   'attendance',(select count(*)::text from erp.payroll_attendance_items i where i.payroll_id=p.id),
   'reimbursements',(select count(*)::text from erp.payroll_reimbursements i where i.payroll_id=p.id),
   'deductions',(select count(*)::text from erp.payroll_deductions i where i.payroll_id=p.id),
   'notes',(select count(*)::text from cp7_payroll.notes n where n.posted_payroll_id=p.id)))
 from erp.payroll_settlements p join erp.contractors c on c.id=p.contractor_id
 left join erp.cash_accounts a on a.id=p.payment_cash_account_id where p.id=p_id
$$;

create function cp7_payroll.settlement_rows(p_section text,p_id uuid) returns table(id uuid,ordering text,data jsonb)
language sql stable security invoker set search_path='' as $$
 select i.id,concat_ws(':',i.source_type,i.id),jsonb_build_object('id',i.id,'po_id',i.po_id,'po_number',p.po_number,
  'component_id',i.work_component_id,'component_code',c.component_code,'component_name',c.component_name,
  'source_type',i.source_type,'source_id',i.source_id,'qty',i.qty_payable::text,'rate',i.rate_snapshot::text,'amount',i.amount::text)
 from erp.payroll_work_items i join erp.work_components c on c.id=i.work_component_id left join erp.production_orders p on p.id=i.po_id
 where p_section='WORK' and i.payroll_id=p_id
 union all
 select i.id,concat_ws(':',i.attendance_date_snapshot,i.worker_id,i.id),jsonb_build_object('id',i.id,'worker_id',i.worker_id,
  'attendance_record_id',i.attendance_record_id,'date',i.attendance_date_snapshot,'worker_name',i.worker_name_snapshot,
  'job_description',i.job_description_snapshot,'paid_fraction',i.paid_fraction_snapshot::text,'daily_rate',i.daily_rate_snapshot::text,
  'rate_version_id',i.worker_rate_version_id,'amount',i.amount::text)
 from erp.payroll_attendance_items i where p_section='ATTENDANCE' and i.payroll_id=p_id
 union all
 select i.id,i.id::text,jsonb_build_object('id',i.id,'amount',i.amount::text,'description',i.description,'source_type',i.source_type,
  'source_id',i.source_id,'po_id',i.po_id,'opening_payable_balance_id',i.opening_payable_balance_id,
  'opening_carry_entitlement_id',i.opening_carry_entitlement_id,'opening_carry_qty',i.opening_carry_qty::text,'bc_credit_event_id',i.bc_credit_event_id)
 from erp.payroll_reimbursements i where p_section='REIMBURSEMENTS' and i.payroll_id=p_id
 union all
 select i.id,i.id::text,jsonb_build_object('id',i.id,'type',i.deduction_type,'amount',i.amount::text,'notes',i.notes,
  'contractor_issue_item_id',i.contractor_issue_item_id,'bs_resolution_id',i.bs_resolution_id,'opening_cash_advance_balance_id',i.opening_cash_advance_balance_id)
 from erp.payroll_deductions i where p_section='DEDUCTIONS' and i.payroll_id=p_id
 union all
 select n.id,concat_ws(':',n.note_date,n.id),cp7_payroll.note_document(n,true)
 from cp7_payroll.notes n where p_section='NOTES' and n.posted_payroll_id=p_id
$$;

create function cp7_payroll.settlement_workspace(p_section text,p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;q text;pid uuid;contractor uuid;filter_status text;n integer;off integer;rows jsonb;total bigint;doc jsonb;
begin
 a:=cp7_payroll.access_now('PAYROLL');
 if p_section is null or p_section not in('PAYROLLS','WORK','ATTENDANCE','REIMBURSEMENTS','DEDUCTIONS','NOTES','CASH_ACCOUNTS')
  or jsonb_typeof(p_query) is distinct from 'object'
  or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','id','contractor_id','status','limit','offset'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','id','contractor_id','status') and jsonb_typeof(e.value) not in('string','null'))
  or (p_query?'limit' and (jsonb_typeof(p_query->'limit')<>'number' or(p_query->>'limit')!~'^[0-9]{1,3}$'))
  or (p_query?'offset' and (jsonb_typeof(p_query->'offset')<>'number' or(p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_PAYROLL_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));pid:=(p_query->>'id')::uuid;contractor:=(p_query->>'contractor_id')::uuid;filter_status:=p_query->>'status';n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);
 if length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000
  or(filter_status is not null and filter_status not in('DRAFT','CALCULATED','REVIEW','APPROVED','PAID','REVERSED'))
  or(p_section not in('PAYROLLS','CASH_ACCOUNTS') and(pid is null or q<>'' or contractor is not null or filter_status is not null))
  or(p_section='CASH_ACCOUNTS' and(pid is not null or contractor is not null or filter_status is not null)) then raise exception 'CP7_PAYROLL_QUERY';end if;
 if p_section='PAYROLLS' then
  with filtered as materialized(select p.id,p.period_end,p.created_at from erp.payroll_settlements p join erp.contractors c on c.id=p.contractor_id
   where (pid is null or p.id=pid) and(contractor is null or p.contractor_id=contractor) and(filter_status is null or p.status=filter_status)
    and(q='' or strpos(lower(concat_ws(' ',p.payroll_number,c.contractor_name,p.notes)),lower(q))>0)),
  page as(select * from filtered order by period_end desc,created_at desc,id limit n offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(cp7_payroll.settlement_document(id) order by period_end desc,created_at desc,id),'[]') into total,rows from page;
 elsif p_section='CASH_ACCOUNTS' then
  with filtered as materialized(select * from erp.cash_accounts c where c.is_active and(q='' or strpos(lower(concat_ws(' ',c.cash_account_code,c.cash_account_name)),lower(q))>0)),
  page as(select * from filtered order by cash_account_code,id limit n offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(jsonb_build_object('id',id,'code',cash_account_code,'name',cash_account_name,'kind',account_kind) order by cash_account_code,id),'[]') into total,rows from page;
 else
  doc:=cp7_payroll.settlement_document(pid);if doc is null then raise exception 'CP7_PAYROLL_MISSING';end if;
  with filtered as materialized(select * from cp7_payroll.settlement_rows(p_section,pid)),page as(select * from filtered order by ordering,id limit n offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(data order by ordering,id),'[]') into total,rows from page;
 end if;
 return jsonb_build_object('contract_version','cp7.payroll-workspace.v1','section',p_section,'read_at',statement_timestamp(),
  'capabilities',jsonb_build_object('approve',erp.has_permission('finance.payroll.approve'),'pay',erp.has_permission('finance.payroll.pay')),
  'document',doc,'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;

create function public.erp_cp7_get_payroll_workspace_v1(p_section text,p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_payroll.settlement_workspace(p_section,p_query)$$;
grant create on schema public to cp7_payroll_read;
alter function cp7_payroll.settlement_token(uuid) owner to cp7_payroll_read;
alter function cp7_payroll.settlement_document(uuid) owner to cp7_payroll_read;
alter function cp7_payroll.settlement_rows(text,uuid) owner to cp7_payroll_read;
alter function cp7_payroll.settlement_workspace(text,jsonb) owner to cp7_payroll_read;
alter function public.erp_cp7_get_payroll_workspace_v1(text,jsonb) owner to cp7_payroll_read;
revoke create on schema public from cp7_payroll_read;
revoke all on function cp7_payroll.settlement_token(uuid),cp7_payroll.settlement_document(uuid),cp7_payroll.settlement_rows(text,uuid),cp7_payroll.settlement_workspace(text,jsonb) from public,anon,authenticated,service_role,cp7_capture,cp7_nota_write,cp7_payroll_header;
revoke all on function public.erp_cp7_get_payroll_workspace_v1(text,jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_payroll_workspace_v1(text,jsonb) to authenticated;

do $verify$ begin
 if encode(extensions.digest(pg_get_functiondef('erp.populate_payroll_draft(uuid)'::regprocedure),'sha256'),'hex')<>'2e330c64b54647eee0c6025a717fb425df58aa5a7c7e6e574e812db7ccd4cd62'
 or encode(extensions.digest(pg_get_functiondef('erp.require_owner_admin()'::regprocedure),'sha256'),'hex')<>'2d2c65c21156b7081d311c558116f876a0de15a59e91f636b6c732d90c327ed1'
 or(select encode(extensions.digest(prosrc,'sha256'),'hex') from pg_proc where oid='erp.require_internal()'::regprocedure)<>'85895dd4144835a0997cb06a2fbbe792203677f57f4cb6201829316aa48e7e04' then raise exception 'CP7_PAYROLL_PREDECESSOR_CHANGED';end if;
end $verify$;
-- P12 controlled preparation and native full settlement. This capability owns
-- only request/context metadata; no ERP business table DML is granted to it.
create role cp7_payroll_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
grant usage on schema cp7_payroll,auth,erp to cp7_payroll_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_payroll_write;
create table cp7_payroll.settlement_requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text not null,response jsonb,primary key(actor,request_id));
create table cp7_payroll.settlement_context(backend_pid integer not null,transaction_id bigint not null,actor uuid not null,payroll_id uuid not null,action text not null check(action in('PREPARE','APPROVE','PAY','CANCEL','REVERSE')),primary key(backend_pid,transaction_id));
alter table cp7_payroll.settlement_requests owner to cp7_payroll_write;
alter table cp7_payroll.settlement_context owner to cp7_payroll_write;
alter table cp7_payroll.settlement_requests enable row level security;
alter table cp7_payroll.settlement_context enable row level security;
revoke all on cp7_payroll.settlement_requests,cp7_payroll.settlement_context from public,anon,authenticated,service_role,cp7_capture,cp7_payroll_read,cp7_nota_write,cp7_payroll_header;

create function cp7_payroll.settlement_access(p_action text) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare a jsonb;
begin
 a:=cp7_payroll.access_now('PAYROLL');
 if p_action not in('PREPARE','APPROVE','PAY','CANCEL','REVERSE') or p_action is null
  or(p_action in('PREPARE','APPROVE','CANCEL','REVERSE') and not erp.has_permission('finance.payroll.approve'))
  or(p_action in('PAY','REVERSE') and not erp.has_permission('finance.payroll.pay')) then
  raise exception using errcode='42501',message='CP7_PAYROLL_WRITE_DENIED';end if;
 return a;
end $$;

create function cp7_payroll.require_settlement_context(p_id uuid) returns void
language plpgsql stable security definer set search_path='' as $$
declare c cp7_payroll.settlement_context;
begin
 select * into c from cp7_payroll.settlement_context where backend_pid=pg_backend_pid() and transaction_id=txid_current() and actor=auth.uid() and payroll_id=p_id;
 if c.actor is null then raise exception using errcode='42501',message='CP7_PAYROLL_PRIVATE_CONTEXT_REQUIRED';end if;
 perform cp7_payroll.settlement_access(c.action);
end $$;

-- Compare actual economic content, excluding generated child IDs. PREPARE keeps
-- selected work untouched; rebuilding source snapshots may generate new row IDs.
create function cp7_payroll.settlement_meaning(p_id uuid) returns jsonb
language sql stable security definer set search_path='' as $$
 select jsonb_build_object('contractor_id',p.contractor_id,'period_start',p.period_start,'period_end',p.period_end,
  'attendance_required',c.attendance_required,'labor_total',p.labor_total,'attendance_total',p.attendance_total,
  'reimburse_total',p.reimburse_total,'deduction_total',p.deduction_total,'manual_adjustment',p.manual_adjustment,'net_payable',p.net_payable,
  'work',(select coalesce(jsonb_agg(to_jsonb(i) order by i.id),'[]') from erp.payroll_work_items i where i.payroll_id=p.id),
  'attendance',(select coalesce(jsonb_agg(to_jsonb(i)-'id' order by i.attendance_record_id,i.worker_id),'[]') from erp.payroll_attendance_items i where i.payroll_id=p.id),
  'reimbursements',(select coalesce(jsonb_agg(to_jsonb(i)-'id' order by (to_jsonb(i)-'id')::text),'[]') from erp.payroll_reimbursements i where i.payroll_id=p.id),
  'deductions',(select coalesce(jsonb_agg(to_jsonb(i)-'id' order by (to_jsonb(i)-'id')::text),'[]') from erp.payroll_deductions i where i.payroll_id=p.id))
 from erp.payroll_settlements p join erp.contractors c on c.id=p.contractor_id where p.id=p_id
$$;

-- The only trusted business adapter. All source accounting still runs through
-- accepted native functions; payment edits are limited to date and cash account.
create function cp7_payroll.apply_settlement(p_action text,p_payload jsonb,p_expected text) returns jsonb
language plpgsql volatile security definer set search_path='' as $$
declare p erp.payroll_settlements;a jsonb;before_meaning jsonb;after_meaning jsonb;prior_work jsonb;reason text:=btrim(p_payload->>'change_reason');
begin
 a:=cp7_payroll.settlement_access(p_action);
 select * into p from erp.payroll_settlements where id=(p_payload->>'id')::uuid for update;
 if p.id is null then raise exception 'CP7_PAYROLL_MISSING';end if;
 perform cp7_payroll.require_settlement_context(p.id);
 perform pg_advisory_xact_lock(hashtextextended(p.contractor_id::text,0));
 -- Native child writers use the payroll lock. These locks also fence edits to
 -- already selected rows while the review token is checked.
 perform 1 from erp.payroll_work_items where payroll_id=p.id order by id for update;
 perform 1 from erp.payroll_attendance_items where payroll_id=p.id order by id for update;
 perform 1 from erp.payroll_reimbursements where payroll_id=p.id order by id for update;
 perform 1 from erp.payroll_deductions where payroll_id=p.id order by id for update;
 if cp7_payroll.settlement_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_PAYROLL_ACCESS_CHANGED';end if;
 if p.row_version::text is distinct from p_expected or cp7_payroll.settlement_token(p.id) is distinct from p_payload->>'review_token' then raise exception 'CP7_PAYROLL_REVIEW_CHANGED';end if;
 perform set_config('app.change_reason',reason,true);
 if p_action in('PREPARE','APPROVE') then
  if p.status not in('DRAFT','CALCULATED','REVIEW') then raise exception 'CP7_PAYROLL_DRAFT_ONLY';end if;
  -- Freeze existing source rows in native lock order. A new source visible
  -- before this rebuild is included and forces another review at APPROVE.
  perform 1 from erp.contractors where id=p.contractor_id for share;
  perform 1 from erp.attendance_periods where contractor_id=p.contractor_id and period_start<=p.period_end and period_end>=p.period_start order by id for share;
  perform 1 from erp.contractor_workers where contractor_id=p.contractor_id order by id for share;
  perform 1 from erp.attendance_records where contractor_id=p.contractor_id and attendance_date between p.period_start and p.period_end order by id for share;
  perform 1 from erp.contractor_accessory_reimbursement_entitlements where contractor_id=p.contractor_id order by id for update;
  perform 1 from erp.contractor_material_issues where contractor_id=p.contractor_id order by id for share;
  perform 1 from erp.contractor_material_issue_items i where exists(select 1 from erp.contractor_material_issues h where h.id=i.issue_id and h.contractor_id=p.contractor_id) order by i.id for update;
  before_meaning:=cp7_payroll.settlement_meaning(p.id);prior_work:=before_meaning->'work';
  -- Derived from the accepted populate function, with only automatic work
  -- removal/insertion removed. All non-work eligibility/formulas are identical.
  perform cp7_payroll.rebuild_nonwork(p.id);
  after_meaning:=cp7_payroll.settlement_meaning(p.id);
  if after_meaning->'work' is distinct from prior_work then raise exception 'CP7_PAYROLL_SELECTED_WORK_CHANGED';end if;
  if p_action='APPROVE' then
   if before_meaning is distinct from after_meaning then raise exception 'CP7_PAYROLL_PREPARE_REQUIRED: sumber atau jumlah berubah; hitung dan periksa ulang';end if;
   perform erp.approve_payroll(p.id);
  end if;
 elsif p_action='PAY' then
  if p.status<>'APPROVED' then raise exception 'CP7_PAYROLL_APPROVED_ONLY';end if;
  update erp.payroll_settlements set payment_date=(p_payload->>'payment_date')::date,payment_cash_account_id=(p_payload->>'cash_account_id')::uuid where id=p.id;
  perform erp.post_payroll_payment(p.id);
 elsif p_action='CANCEL' then
  if p.status not in('DRAFT','CALCULATED','REVIEW','APPROVED') then raise exception 'CP7_PAYROLL_UNPAID_ONLY';end if;
  perform erp.cancel_unpaid_payroll(p.id,reason);
 elsif p_action='REVERSE' then
  if p.status<>'PAID' then raise exception 'CP7_PAYROLL_PAID_ONLY';end if;
  perform erp.reverse_paid_payroll(p.id,reason);
 else raise exception 'CP7_PAYROLL_ACTION';end if;
 if cp7_payroll.settlement_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_PAYROLL_ACCESS_CHANGED';end if;
 return cp7_payroll.settlement_document(p.id);
end $$;

create function cp7_payroll.settlement_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_payroll.settlement_requests;d jsonb;r jsonb;keys text[];
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_payroll.settlement_access(p_action);
 keys:=array['id','review_token','change_reason']||case when p_action='PAY' then array['payment_date','cash_account_id'] else '{}'::text[] end;
 if p_request is null or p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'
  or jsonb_typeof(p_payload) is distinct from 'object' or not p_payload ?& keys
  or exists(select 1 from jsonb_each(p_payload) e where e.key<>all(keys) or (jsonb_typeof(e.value)<>'string' and not(e.key='cash_account_id' and e.value='null'::jsonb)))
  or coalesce(p_payload->>'id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p_payload->>'review_token','')!~'^[a-f0-9]{32}$'
  or length(btrim(p_payload->>'change_reason')) not between 5 and 1000
  or (p_action='PAY' and coalesce(p_payload->>'payment_date','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$') then raise exception 'CP7_PAYROLL_FIELDS';end if;
 insert into cp7_payroll.settlement_requests values(auth.uid(),p_request,p_action,p_payload,p_expected,null) on conflict do nothing;
 select * into old from cp7_payroll.settlement_requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_PAYROLL_REQUEST_CHANGED';end if;
 if cp7_payroll.settlement_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_PAYROLL_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 insert into cp7_payroll.settlement_context values(pg_backend_pid(),txid_current(),auth.uid(),(p_payload->>'id')::uuid,p_action);
 d:=cp7_payroll.apply_settlement(p_action,p_payload,p_expected);
 delete from cp7_payroll.settlement_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
 if cp7_payroll.settlement_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_PAYROLL_ACCESS_CHANGED';end if;
 r:=jsonb_build_object('contract_version','cp7.payroll-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'payroll_id',d->'id','status',d->'status','row_version',d->'row_version','review_token',d->'review_token');
 update cp7_payroll.settlement_requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;
create function public.erp_cp7_save_payroll_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_payroll.settlement_command(p_action,p_payload,p_request,p_expected)$$;

alter function cp7_payroll.settlement_access(text) owner to cp7_payroll_read;
alter function cp7_payroll.settlement_command(text,jsonb,uuid,text) owner to cp7_payroll_write;
grant create on schema public to cp7_payroll_write;
alter function public.erp_cp7_save_payroll_v1(text,jsonb,uuid,text) owner to cp7_payroll_write;
revoke create on schema public from cp7_payroll_write;
-- Trusted helpers are explicitly postgres-owned and never publicly executable.
alter function cp7_payroll.require_settlement_context(uuid) owner to postgres;
alter function cp7_payroll.settlement_meaning(uuid) owner to postgres;
alter function cp7_payroll.apply_settlement(text,jsonb,text) owner to postgres;
revoke all on function cp7_payroll.settlement_access(text),cp7_payroll.require_settlement_context(uuid),cp7_payroll.settlement_meaning(uuid),cp7_payroll.apply_settlement(text,jsonb,text),cp7_payroll.settlement_command(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture,cp7_nota_write,cp7_payroll_header;
grant execute on function cp7_payroll.settlement_access(text),cp7_payroll.apply_settlement(text,jsonb,text) to cp7_payroll_write;
-- Supabase's postgres role is not necessarily a superuser. Give the native
-- adapter only its private read/execute dependencies, never a client capability.
grant usage on schema cp7_payroll to postgres;
grant select on cp7_payroll.settlement_context,cp7_payroll.notes to postgres;
grant execute on function cp7_payroll.settlement_access(text),cp7_payroll.settlement_token(uuid),cp7_payroll.settlement_document(uuid) to postgres;
revoke all on function public.erp_cp7_save_payroll_v1(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_save_payroll_v1(text,jsonb,uuid,text) to authenticated;

CREATE OR REPLACE FUNCTION cp7_payroll.rebuild_nonwork(p_payroll_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  p erp.payroll_settlements%rowtype;
  r record;
  v_remaining numeric(24,6);
  v_apply numeric(24,6);
  v_budget numeric(24,6) := 0;
  v_attendance_required boolean;
begin
  perform cp7_payroll.require_settlement_context(p_payroll_id);
  select * into p from erp.payroll_settlements where id = p_payroll_id for update;
  if p.id is null or p.status not in ('DRAFT','CALCULATED','REVIEW') then
    raise exception 'Payroll draft cannot be rebuilt in current status';
  end if;
  perform pg_advisory_xact_lock(hashtextextended(p.contractor_id::text, 0));

  delete from erp.payroll_attendance_items where payroll_id = p.id;
  delete from erp.payroll_deductions
    where payroll_id = p.id and contractor_issue_item_id is not null;
  delete from erp.payroll_reimbursements
    where payroll_id = p.id and source_type = 'ACCESSORY_BOM';


  select attendance_required into v_attendance_required
  from erp.contractors where id = p.contractor_id;

  if v_attendance_required then
    insert into erp.payroll_attendance_items(
      payroll_id, worker_id, attendance_record_id,
      paid_fraction_snapshot, daily_rate_snapshot,
      worker_rate_version_id, attendance_date_snapshot,
      worker_name_snapshot, job_description_snapshot
    )
    select
      p.id,
      ar.worker_id,
      ar.id,
      ar.paid_fraction,
      erp.require_worker_daily_rate_at(ar.worker_id, ar.attendance_date),
      erp.worker_daily_rate_version_id_at(ar.worker_id, ar.attendance_date),
      ar.attendance_date,
      cw.worker_name,
      cw.job_description
    from erp.attendance_records ar
    join erp.contractor_workers cw on cw.id = ar.worker_id
    left join erp.attendance_periods ap on ap.id = ar.attendance_period_id
    where ar.contractor_id = p.contractor_id
      and ar.attendance_date between p.period_start and p.period_end
      and cw.pay_scheme in ('DAILY','HYBRID')
      and ar.paid_fraction > 0
      and (ar.attendance_period_id is null or ap.status = 'POSTED')
      and coalesce(ar.record_lifecycle, 'POSTED') = 'POSTED'
    order by ar.attendance_date, ar.id;
  end if;

  insert into erp.payroll_reimbursements(
    payroll_id, amount, description, source_type, source_id, po_id
  )
  select p.id, round(e.amount, 2),
         'Accessory reimbursement from accepted GOOD FG',
         'ACCESSORY_BOM', e.id, e.po_id
  from erp.contractor_accessory_reimbursement_entitlements e
  where e.contractor_id = p.contractor_id
    and e.amount > 0
    and e.payroll_status <> 'CANCELLED'
    and (e.physical_at AT TIME ZONE 'Asia/Jakarta')::date <= p.period_end
    and not exists (
      select 1
      from erp.payroll_reimbursements pr
      join erp.payroll_settlements ps2 on ps2.id = pr.payroll_id
      where pr.source_type = 'ACCESSORY_BOM'
        and pr.source_id = e.id
        and ps2.id <> p.id
        and ps2.status <> 'REVERSED'
    )
  order by e.physical_at, e.id;

  update erp.contractor_accessory_reimbursement_entitlements e
  set payroll_status = 'ALLOCATED'
  where exists (
    select 1
    from erp.payroll_reimbursements pr
    where pr.payroll_id = p.id
      and pr.source_type = 'ACCESSORY_BOM'
      and pr.source_id = e.id
  );

  perform erp.recalculate_payroll(p.id);
  select greatest(net_payable, 0) into v_budget
  from erp.payroll_settlements where id = p.id;

  for r in
    select
      cmii.id,
      cmii.total_receivable,
      cmi.physical_at,
      erp.bc_note_item_collectible_v1(cmii.id) - coalesce((
        select sum(pd.amount)
        from erp.payroll_deductions pd
        join erp.payroll_settlements ps2 on ps2.id = pd.payroll_id
        where pd.contractor_issue_item_id = cmii.id
          and ps2.id <> p.id
          and ps2.status <> 'REVERSED'
      ), 0) as remaining_amount
    from erp.contractor_material_issue_items cmii
    join erp.contractor_material_issues cmi on cmi.id = cmii.issue_id
    where cmi.contractor_id = p.contractor_id
      and cmi.status = 'POSTED'
      and (cmi.physical_at AT TIME ZONE 'Asia/Jakarta')::date <= p.period_end
    order by cmi.physical_at, cmii.id
  loop
    exit when v_budget <= 0;
    v_remaining := greatest(r.remaining_amount, 0);
    v_apply := least(v_remaining, v_budget);
    if v_apply > 0 then
      insert into erp.payroll_deductions(
        payroll_id, deduction_type, contractor_issue_item_id, amount, notes
      ) values (
        p.id, 'MATERIAL_KASBON', r.id, round(v_apply, 2),
        'Auto capped outstanding material/accessory kasbon (FIFO)'
      );
      v_budget := greatest(v_budget - round(v_apply, 2), 0);
    end if;
  end loop;

  perform erp.recalculate_payroll(p.id);
  for r in
    select cmii.id
    from erp.contractor_material_issue_items cmii
    join erp.contractor_material_issues cmi on cmi.id = cmii.issue_id
    where cmi.contractor_id = p.contractor_id
      and cmi.status = 'POSTED'
  loop
    perform erp.refresh_contractor_issue_payroll_status(r.id);
  end loop;
end;
$function$
;
alter function cp7_payroll.rebuild_nonwork(uuid) owner to postgres;

revoke all on function cp7_payroll.rebuild_nonwork(uuid) from public,anon,authenticated,service_role,cp7_capture,cp7_payroll_read,cp7_nota_write,cp7_payroll_header,cp7_payroll_write;
do $patch$ declare d text;begin
 d:=pg_get_functiondef('erp.require_internal()'::regprocedure);
 execute replace(d,$anchor$ v_app_role:=erp.current_app_role();$anchor$,$delta$  if exists(select 1 from cp7_payroll.settlement_context c where c.backend_pid=pg_backend_pid()
    and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
     and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
    then erp.has_permission('finance.payroll.view')
    and(c.action not in('PREPARE','APPROVE','CANCEL','REVERSE') or erp.has_permission('finance.payroll.approve'))
    and(c.action not in('PAY','REVERSE') or erp.has_permission('finance.payroll.pay'))
    else false end) then return;end if;
 v_app_role:=erp.current_app_role();$delta$);
 d:=pg_get_functiondef('erp.require_owner_admin()'::regprocedure);
 execute replace(d,$anchor$  if coalesce(erp.current_app_role(),'') not in ('OWNER','ADMIN') then$anchor$,$delta$  if exists(select 1 from cp7_payroll.settlement_context c where c.backend_pid=pg_backend_pid()
    and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
     and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
    then erp.has_permission('finance.payroll.view')
    and(c.action not in('PREPARE','APPROVE','CANCEL','REVERSE') or erp.has_permission('finance.payroll.approve'))
    and(c.action not in('PAY','REVERSE') or erp.has_permission('finance.payroll.pay'))
    else false end) then return;end if;
  if coalesce(erp.current_app_role(),'') not in ('OWNER','ADMIN') then$delta$);
end $patch$;
-- P12 attendance source reader candidate. Separate capability; no business DML.
create role cp7_attendance_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_attendance authorization cp7_attendance_read;
revoke all on schema cp7_attendance from public,anon,authenticated,service_role;
grant usage on schema erp,auth to cp7_attendance_read;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_attendance_read;
grant select on erp.contractors,erp.contractor_workers,erp.worker_daily_rate_versions,erp.worker_employment_periods,
 erp.attendance_periods,erp.attendance_records,erp.payroll_attendance_items,erp.payroll_settlements to cp7_attendance_read;

create function cp7_attendance.access_now() returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_ATTENDANCE_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission('finance.attendance.view') then raise exception using errcode='42501',message='CP7_ATTENDANCE_ACCESS_DENIED';end if;
 return a;
end $$;

create function cp7_attendance.source_token(p_contractor uuid,p_start date,p_end date) returns text
language sql stable security invoker set search_path='' as $$
 select md5(jsonb_build_array(c.id,c.xmin::text,p_start,p_end,
  (select coalesce(jsonb_agg(jsonb_build_array(w.id,w.xmin::text) order by w.id),'[]') from erp.contractor_workers w where w.contractor_id=c.id),
  (select coalesce(jsonb_agg(jsonb_build_array(r.id,r.xmin::text) order by r.id),'[]') from erp.worker_daily_rate_versions r join erp.contractor_workers w on w.id=r.worker_id where w.contractor_id=c.id),
  (select coalesce(jsonb_agg(jsonb_build_array(e.id,e.xmin::text) order by e.id),'[]') from erp.worker_employment_periods e join erp.contractor_workers w on w.id=e.worker_id where w.contractor_id=c.id),
  (select coalesce(jsonb_agg(jsonb_build_array(p.id,p.xmin::text) order by p.id),'[]') from erp.attendance_periods p where p.contractor_id=c.id and p.period_start<=p_end and p.period_end>=p_start),
  (select coalesce(jsonb_agg(jsonb_build_array(a.id,a.xmin::text) order by a.id),'[]') from erp.attendance_records a where a.contractor_id=c.id and a.attendance_date between p_start and p_end),
  (select coalesce(jsonb_agg(jsonb_build_array(i.id,i.xmin::text,p.id,p.xmin::text) order by i.id),'[]') from erp.payroll_attendance_items i join erp.payroll_settlements p on p.id=i.payroll_id join erp.attendance_records a on a.id=i.attendance_record_id where a.contractor_id=c.id and a.attendance_date between p_start and p_end)
 )::text) from erp.contractors c where c.id=p_contractor and c.contractor_type='MANDOR'
$$;

create function cp7_attendance.worker_document(p_worker uuid,p_at date) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',w.id,'contractor_id',w.contractor_id,'code',w.worker_code,'name',w.worker_name,'job_description',w.job_description,
  'pay_scheme',w.pay_scheme,'active_now',w.is_active,'joined_at',w.joined_at,'left_at',w.left_at,'notes',w.notes,'row_version',w.row_version::text,
  'rate_at',p_at,'daily_rate_at_date',(select r.daily_rate::text from erp.worker_daily_rate_versions r where r.worker_id=w.id and r.effective_from<=p_at and(r.effective_to is null or r.effective_to>=p_at) order by r.effective_from desc limit 1),
  'employed_at_date',exists(select 1 from erp.worker_employment_periods e where e.worker_id=w.id and e.started_on<=p_at and(e.ended_on is null or e.ended_on>=p_at)))
 from erp.contractor_workers w where w.id=p_worker
$$;

create function cp7_attendance.period_document(p_period uuid) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',p.id,'contractor_id',p.contractor_id,'number',p.period_number,'period_start',p.period_start,'period_end',p.period_end,
  'pay_date',p.pay_date,'status',p.status,'correction_of_id',p.correction_of_period_id,'notes',p.notes,'row_version',p.row_version::text,
  'record_count',(select count(*)::text from erp.attendance_records a where a.attendance_period_id=p.id),
  'consuming_payroll_count',(select count(distinct h.id)::text from erp.payroll_attendance_items i join erp.payroll_settlements h on h.id=i.payroll_id join erp.attendance_records a on a.id=i.attendance_record_id where a.attendance_period_id=p.id and h.status<>'REVERSED'))
 from erp.attendance_periods p where p.id=p_period
$$;

create function cp7_attendance.workspace(p_section text,p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare access jsonb;q text;cid uuid;wid uuid;pid uuid;d1 date;d2 date;lim integer;off integer;total bigint;rows jsonb;contractor jsonb;worker jsonb;period jsonb;token text;
begin
 access:=cp7_attendance.access_now();
 if p_section is null or p_section not in('CONTRACTORS','WORKERS','RATES','EMPLOYMENT','PERIODS','RECORDS')
  or jsonb_typeof(p_query) is distinct from 'object'
  or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','contractor_id','worker_id','period_id','date_from','date_to','limit','offset'))
  or exists(select 1 from jsonb_each(p_query) e where e.key not in('limit','offset') and jsonb_typeof(e.value)<>'string')
  or(p_query?'limit' and(jsonb_typeof(p_query->'limit')<>'number' or(p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query?'offset' and(jsonb_typeof(p_query->'offset')<>'number' or(p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_ATTENDANCE_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));cid:=(p_query->>'contractor_id')::uuid;wid:=(p_query->>'worker_id')::uuid;pid:=(p_query->>'period_id')::uuid;
 d1:=(p_query->>'date_from')::date;d2:=(p_query->>'date_to')::date;lim:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);
 if length(q)>120 or lim not between 1 and 100 or off not between 0 and 1000000
  or(p_section='CONTRACTORS' and(cid is not null or wid is not null or pid is not null or d1 is not null or d2 is not null))
  or(p_section<>'CONTRACTORS' and(cid is null or d1 is null or d2 is null or d2<d1 or(p_query->>'date_from')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$' or(p_query->>'date_to')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'))
  or(p_section in('RATES','EMPLOYMENT') and(wid is null or pid is not null or q<>''))
  or(p_section='RECORDS' and(pid is null or wid is not null or q<>''))
  or(p_section in('WORKERS','PERIODS') and(wid is not null or pid is not null)) then raise exception 'CP7_ATTENDANCE_QUERY';end if;
 if cid is not null then
  select jsonb_build_object('id',c.id,'name',c.contractor_name,'active_now',c.is_active,'attendance_required',c.attendance_required) into contractor from erp.contractors c where c.id=cid and c.contractor_type='MANDOR';
  if contractor is null then raise exception 'CP7_ATTENDANCE_CONTRACTOR';end if;
  token:=cp7_attendance.source_token(cid,d1,d2);
 end if;
 if wid is not null then
  worker:=cp7_attendance.worker_document(wid,d1);
  if worker is null or(worker->>'contractor_id')::uuid<>cid then raise exception 'CP7_ATTENDANCE_WORKER_PARENT';end if;
 end if;
 if pid is not null then
  period:=cp7_attendance.period_document(pid);
  if period is null or(period->>'contractor_id')::uuid<>cid or(period->>'period_start')::date<>d1 or(period->>'period_end')::date<>d2 then raise exception 'CP7_ATTENDANCE_PERIOD_PARENT';end if;
 end if;
 if p_section='CONTRACTORS' then
  with filtered as materialized(select c.* from erp.contractors c where c.contractor_type='MANDOR' and(q='' or strpos(lower(c.contractor_name),lower(q))>0)),page as(select * from filtered order by contractor_name,id limit lim offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(jsonb_build_object('id',id,'name',contractor_name,'active_now',is_active,'attendance_required',attendance_required) order by contractor_name,id),'[]') into total,rows from page;
 elsif p_section='WORKERS' then
  with filtered as materialized(select w.* from erp.contractor_workers w where w.contractor_id=cid and(q='' or strpos(lower(concat_ws(' ',w.worker_code,w.worker_name,w.job_description)),lower(q))>0)
   and exists(select 1 from erp.worker_employment_periods e where e.worker_id=w.id and e.started_on<=d2 and(e.ended_on is null or e.ended_on>=d1))),page as(select * from filtered order by worker_name,id limit lim offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(cp7_attendance.worker_document(id,d1) order by worker_name,id),'[]') into total,rows from page;
 elsif p_section='RATES' then
  with filtered as materialized(select r.* from erp.worker_daily_rate_versions r where r.worker_id=wid and r.effective_from<=d2 and(r.effective_to is null or r.effective_to>=d1)),page as(select * from filtered order by effective_from,id limit lim offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(jsonb_build_object('id',id,'worker_id',worker_id,'daily_rate',daily_rate::text,'date_from',effective_from,'date_to',effective_to,'reason',change_reason) order by effective_from,id),'[]') into total,rows from page;
 elsif p_section='EMPLOYMENT' then
  with filtered as materialized(select e.* from erp.worker_employment_periods e where e.worker_id=wid and e.started_on<=d2 and(e.ended_on is null or e.ended_on>=d1)),page as(select * from filtered order by started_on,id limit lim offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(jsonb_build_object('id',id,'worker_id',worker_id,'date_from',started_on,'date_to',ended_on,'start_reason',start_reason,'end_reason',end_reason) order by started_on,id),'[]') into total,rows from page;
 elsif p_section='PERIODS' then
  with filtered as materialized(select p.* from erp.attendance_periods p where p.contractor_id=cid and p.period_start<=d2 and p.period_end>=d1 and(q='' or strpos(lower(concat_ws(' ',p.period_number,p.notes)),lower(q))>0)),page as(select * from filtered order by period_start desc,id limit lim offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(cp7_attendance.period_document(id) order by period_start desc,id),'[]') into total,rows from page;
 else
  with filtered as materialized(select a.*,w.worker_name from erp.attendance_records a join erp.contractor_workers w on w.id=a.worker_id where a.attendance_period_id=pid),page as(select * from filtered order by attendance_date,worker_id,id limit lim offset off)
  select(select count(*) from filtered),coalesce(jsonb_agg(jsonb_build_object('id',id,'period_id',attendance_period_id,'worker_id',worker_id,'worker_name',worker_name,'date',attendance_date,'mark',status,'paid_fraction',paid_fraction::text,'lifecycle',coalesce(record_lifecycle,'LEGACY_POSTED'),'supersedes_id',supersedes_attendance_record_id,'notes',notes,'row_version',row_version::text) order by attendance_date,worker_id,id),'[]') into total,rows from page;
 end if;
 return jsonb_build_object('contract_version','cp7.attendance-workspace.v1','section',p_section,'date_from',d1,'date_to',d2,'source_token',token,'contractor',contractor,'worker',worker,'period',period,
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',lim,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;

create function public.erp_cp7_get_attendance_workspace_v1(p_section text,p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_attendance.workspace(p_section,p_query)$$;
grant create on schema public to cp7_attendance_read;
alter function cp7_attendance.access_now() owner to cp7_attendance_read;
alter function cp7_attendance.source_token(uuid,date,date) owner to cp7_attendance_read;
alter function cp7_attendance.worker_document(uuid,date) owner to cp7_attendance_read;
alter function cp7_attendance.period_document(uuid) owner to cp7_attendance_read;
alter function cp7_attendance.workspace(text,jsonb) owner to cp7_attendance_read;
alter function public.erp_cp7_get_attendance_workspace_v1(text,jsonb) owner to cp7_attendance_read;
revoke create on schema public from cp7_attendance_read;
revoke all on all functions in schema cp7_attendance from public,anon,authenticated,service_role,cp7_capture;
revoke all on function public.erp_cp7_get_attendance_workspace_v1(text,jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_attendance_workspace_v1(text,jsonb) to authenticated;

-- P12 roster/rate adapter. Native OWNER/ADMIN authority is preserved in
-- addition to current create/edit and attendance-view permissions.
create role cp7_roster_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
grant usage on schema cp7_attendance,auth,erp to cp7_roster_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_roster_write;
create table cp7_attendance.roster_requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text,response jsonb,primary key(actor,request_id));
alter table cp7_attendance.roster_requests owner to cp7_roster_write;
alter table cp7_attendance.roster_requests enable row level security;
revoke all on cp7_attendance.roster_requests from public,anon,authenticated,service_role,cp7_capture,cp7_attendance_read;

create function cp7_attendance.roster_access(p_action text) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare a jsonb;permission text;
begin
 a:=cp7_attendance.access_now();
 permission:=case p_action when 'CREATE_WORKER' then 'finance.attendance.create' when 'UPDATE_WORKER' then 'finance.attendance.edit_draft' when 'SET_RATE' then 'finance.attendance.edit_draft' end;
 if permission is null or not erp.has_permission(permission) then raise exception using errcode='42501',message='CP7_ROSTER_WRITE_DENIED';end if;
 if coalesce(a->'profile'->>'role_code','') not in('OWNER','ADMIN') then raise exception using errcode='42501',message='CP7_ROSTER_OWNER_ADMIN_REQUIRED';end if;
 return a;
end $$;

create function cp7_attendance.apply_roster(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security definer set search_path='' as $$
declare a jsonb;d jsonb:=p_payload->'document';cid uuid:=(p_payload->>'contractor_id')::uuid;wid uuid;w erp.contractor_workers;native jsonb;result jsonb;
begin
 a:=cp7_attendance.roster_access(p_action);
 -- Shared contractor advisory order serializes the connected payroll source
 -- rebuild with roster/rate changes; the native worker lock follows it.
 perform pg_advisory_xact_lock(hashtextextended(cid::text,0));
 perform 1 from erp.contractors where id=cid and contractor_type='MANDOR' for share;
 if not found then raise exception 'CP7_ROSTER_CONTRACTOR';end if;
 if p_action<>'CREATE_WORKER' then
  wid:=(d->>'worker_id')::uuid;select * into w from erp.contractor_workers where id=wid for update;
  if w.id is null or w.contractor_id<>cid then raise exception 'CP7_ROSTER_WORKER_PARENT';end if;
  if w.row_version::text is distinct from p_expected then raise exception 'CP7_ROSTER_VERSION_CHANGED';end if;
 end if;
 if cp7_attendance.roster_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_ROSTER_ACCESS_CHANGED';end if;
 if cp7_attendance.source_token(cid,(p_payload->>'date_from')::date,(p_payload->>'date_to')::date) is distinct from p_payload->>'source_token' then raise exception 'CP7_ROSTER_REVIEW_CHANGED';end if;
 if p_action='SET_RATE' then
  native:=erp.set_worker_daily_rate_v1(wid,(d->>'daily_rate')::numeric,(d->>'effective_from')::date,d->>'reason',p_request,p_expected::bigint);
 else
  if(d->>'contractor_id')::uuid is distinct from cid then raise exception 'CP7_ROSTER_CONTRACTOR_CHANGED';end if;
  -- The native writer always sets worker_code from the payload; an update
  -- carries the locked row's code so a rename never erases it.
  native:=erp.save_worker_roster_v1(case when p_action='UPDATE_WORKER' then d||jsonb_build_object('worker_code',w.worker_code) else d end,p_request,p_expected::bigint);
  wid:=(native->>'worker_id')::uuid;
 end if;
 select * into w from erp.contractor_workers where id=wid;
 if w.id is null or w.contractor_id<>cid or native->>'worker_id' is distinct from w.id::text or native->>'row_version' is distinct from w.row_version::text then raise exception 'CP7_ROSTER_NATIVE_OUTCOME';end if;
 if cp7_attendance.roster_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_ROSTER_ACCESS_CHANGED';end if;
 result:=jsonb_build_object('contract_version','cp7.roster-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'worker_id',w.id,'contractor_id',cid,'row_version',w.row_version::text,'status',case when w.is_active then 'ACTIVE' else 'INACTIVE' end,
  'source_token',cp7_attendance.source_token(cid,(p_payload->>'date_from')::date,(p_payload->>'date_to')::date));
 return result;
end $$;

create function cp7_attendance.roster_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_attendance.roster_requests;d jsonb;required text[];allowed text[];result jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_attendance.roster_access(p_action);
 if p_request is null or jsonb_typeof(p_payload) is distinct from 'object'
  or not p_payload ?& array['contractor_id','date_from','date_to','source_token','document']
  or exists(select 1 from jsonb_each(p_payload) e where e.key<>all(array['contractor_id','date_from','date_to','source_token','document']) or(e.key<>'document' and jsonb_typeof(e.value)<>'string'))
  or jsonb_typeof(p_payload->'document') is distinct from 'object'
  or coalesce(p_payload->>'contractor_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p_payload->>'source_token','')!~'^[a-f0-9]{32}$'
  or coalesce(p_payload->>'date_from','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$' or coalesce(p_payload->>'date_to','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
  or(p_payload->>'date_to')::date<(p_payload->>'date_from')::date
  or(p_action='CREATE_WORKER' and p_expected is not null)
  or(p_action<>'CREATE_WORKER' and(p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$')) then raise exception 'CP7_ROSTER_FIELDS';end if;
 d:=p_payload->'document';
 if p_action='SET_RATE' then required:=array['worker_id','daily_rate','effective_from','reason'];allowed:=required;
 else
  required:=array['contractor_id','worker_name','job_description','pay_scheme','joined_at','is_active','reason']||case when p_action='CREATE_WORKER' then array['initial_daily_rate','rate_effective_from'] else array['worker_id'] end;
  allowed:=required||array['notes','left_at']||case when p_action='CREATE_WORKER' then array['worker_code'] else array['reactivated_at'] end;
 end if;
 if not d ?& required or exists(select 1 from jsonb_each(d) e where e.key<>all(allowed))
  or exists(select 1 from jsonb_each(d) e where case when e.key='is_active' then jsonb_typeof(e.value)<>'boolean' when e.key in('notes','left_at','reactivated_at','worker_code') then jsonb_typeof(e.value) not in('string','null') else jsonb_typeof(e.value)<>'string' end)
  or length(btrim(d->>'reason')) not between 5 and 1000
  or(p_action<>'CREATE_WORKER' and coalesce(d->>'worker_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
  or exists(select 1 from jsonb_each_text(d) e where e.key in('joined_at','left_at','reactivated_at','rate_effective_from','effective_from') and e.value is not null and e.value!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$')
  or exists(select 1 from jsonb_each_text(d) e where e.key in('initial_daily_rate','daily_rate') and e.value!~'^(0|[1-9][0-9]{0,17})([.][0-9]{1,6})?$') then raise exception 'CP7_ROSTER_FIELDS';end if;
 insert into cp7_attendance.roster_requests values(auth.uid(),p_request,p_action,p_payload,p_expected,null) on conflict do nothing;
 select * into old from cp7_attendance.roster_requests where actor=auth.uid() and request_id=p_request for update;
 if old.action is distinct from p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_ROSTER_REQUEST_CHANGED';end if;
 if cp7_attendance.roster_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_ROSTER_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 result:=cp7_attendance.apply_roster(p_action,p_payload,p_request,p_expected);
 if cp7_attendance.roster_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_ROSTER_ACCESS_CHANGED';end if;
 update cp7_attendance.roster_requests set response=result where actor=auth.uid() and request_id=p_request;
 return result;
end $$;

create function public.erp_cp7_save_roster_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_attendance.roster_command(p_action,p_payload,p_request,p_expected)$$;
alter function cp7_attendance.roster_access(text) owner to cp7_attendance_read;
alter function cp7_attendance.apply_roster(text,jsonb,uuid,text) owner to postgres;
alter function cp7_attendance.roster_command(text,jsonb,uuid,text) owner to cp7_roster_write;
grant create on schema public to cp7_roster_write;
alter function public.erp_cp7_save_roster_v1(text,jsonb,uuid,text) owner to cp7_roster_write;
revoke create on schema public from cp7_roster_write;
revoke all on function cp7_attendance.roster_access(text),cp7_attendance.apply_roster(text,jsonb,uuid,text),cp7_attendance.roster_command(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture,cp7_payroll_read,cp7_payroll_write,cp7_nota_write,cp7_payroll_header;
grant usage on schema cp7_attendance to postgres;
grant execute on function cp7_attendance.roster_access(text),cp7_attendance.source_token(uuid,date,date) to postgres;
grant execute on function cp7_attendance.roster_access(text),cp7_attendance.apply_roster(text,jsonb,uuid,text) to cp7_roster_write;
revoke all on function public.erp_cp7_save_roster_v1(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_save_roster_v1(text,jsonb,uuid,text) to authenticated;

do $verify$ begin
 if(select encode(extensions.digest(prosrc,'sha256'),'hex') from pg_proc where oid='erp.require_internal()'::regprocedure)<>'173371883f5c8885c64accb59e051d3bfe486059a34e0af57bbc63fe3d455a14' then raise exception 'CP7_ATTENDANCE_PREDECESSOR_CHANGED';end if;
end $verify$;
-- P12 ordinary attendance source lifecycle. Native formulas, completeness and
-- correction/payroll lineage guards remain the authority.
create role cp7_attendance_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
grant usage on schema cp7_attendance,auth,erp to cp7_attendance_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_attendance_write;
create table cp7_attendance.command_requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text,response jsonb,primary key(actor,request_id));
create table cp7_attendance.command_context(backend_pid integer not null,transaction_id bigint not null,actor uuid not null,contractor_id uuid not null,period_id uuid,action text not null check(action in('PREVIEW','SAVE','POST','REVERSE')),permission text not null check(permission in('finance.attendance.create','finance.attendance.edit_draft','finance.attendance.post','finance.attendance.reverse')),owner_required boolean not null,primary key(backend_pid,transaction_id));
alter table cp7_attendance.command_requests owner to cp7_attendance_write;
alter table cp7_attendance.command_context owner to cp7_attendance_write;
alter table cp7_attendance.command_requests enable row level security;
alter table cp7_attendance.command_context enable row level security;
revoke all on cp7_attendance.command_requests,cp7_attendance.command_context from public,anon,authenticated,service_role,cp7_capture,cp7_attendance_read,cp7_roster_write;

create function cp7_attendance.command_access(p_action text,p_document jsonb,p_expected text) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare a jsonb;permission text;owner_needed boolean;
begin
 a:=cp7_attendance.access_now();
 permission:=case p_action when 'PREVIEW' then case when p_expected is null then 'finance.attendance.create' else 'finance.attendance.edit_draft' end when 'SAVE' then case when p_expected is null then 'finance.attendance.create' else 'finance.attendance.edit_draft' end when 'POST' then 'finance.attendance.post' when 'REVERSE' then 'finance.attendance.reverse' end;
 if permission is null or not erp.has_permission(permission) then raise exception using errcode='42501',message='CP7_ATTENDANCE_WRITE_DENIED';end if;
 owner_needed:=p_action='REVERSE' or p_document->>'correction_of_period_id' is not null or exists(select 1 from erp.attendance_periods where id=(p_document->>'period_id')::uuid and correction_of_period_id is not null);
 if owner_needed and coalesce(a->'profile'->>'role_code','') not in('OWNER','ADMIN') then raise exception using errcode='42501',message='CP7_ATTENDANCE_OWNER_ADMIN_REQUIRED';end if;
 return a||jsonb_build_object('attendance_permission',permission,'attendance_owner_required',owner_needed);
end $$;

create function cp7_attendance.validate_command(p_action text,p_payload jsonb,p_expected text) returns void
language plpgsql immutable security invoker set search_path='' as $$
declare d jsonb;line jsonb;required text[];allowed text[];
begin
 if p_action is null or p_action not in('PREVIEW','SAVE','POST','REVERSE') or jsonb_typeof(p_payload) is distinct from 'object'
  or not p_payload ?& array['contractor_id','date_from','date_to','source_token','document']
  or exists(select 1 from jsonb_each(p_payload) e where e.key<>all(array['contractor_id','date_from','date_to','source_token','document']) or(e.key<>'document' and jsonb_typeof(e.value)<>'string'))
  or jsonb_typeof(p_payload->'document') is distinct from 'object'
  or coalesce(p_payload->>'contractor_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p_payload->>'source_token','')!~'^[a-f0-9]{32}$'
  or coalesce(p_payload->>'date_from','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$' or coalesce(p_payload->>'date_to','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
  or(p_payload->>'date_to')::date<(p_payload->>'date_from')::date
  or(p_expected is not null and p_expected!~'^[1-9][0-9]{0,18}$') then raise exception 'CP7_ATTENDANCE_FIELDS';end if;
 d:=p_payload->'document';
 required:=case when p_action in('PREVIEW','SAVE') then array['contractor_id','period_number','period_start','period_end','pay_date','reason','attendance'] else array['period_id','reason'] end;
 allowed:=required||case when p_action in('PREVIEW','SAVE') then array['period_id','correction_of_period_id','notes'] else array[]::text[] end;
 if not d ?& required or exists(select 1 from jsonb_each(d) e where e.key<>all(allowed))
  or exists(select 1 from jsonb_each(d) e where case when e.key='attendance' then jsonb_typeof(e.value)<>'array' when e.key in('period_id','correction_of_period_id','notes') then jsonb_typeof(e.value) not in('string','null') else jsonb_typeof(e.value)<>'string' end)
  or length(btrim(d->>'reason')) not between 5 and 1000
  or exists(select 1 from jsonb_each_text(d) e where e.key in('period_id','correction_of_period_id','contractor_id') and e.value is not null and e.value!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
  or exists(select 1 from jsonb_each_text(d) e where e.key in('period_start','period_end','pay_date') and e.value!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$')
  or((d->>'period_id' is null) is distinct from (p_expected is null))
  or(p_action in('POST','REVERSE') and p_expected is null)
  or(p_action in('PREVIEW','SAVE') and(d->>'contractor_id' is distinct from p_payload->>'contractor_id' or d->>'period_start' is distinct from p_payload->>'date_from' or d->>'period_end' is distinct from p_payload->>'date_to')) then raise exception 'CP7_ATTENDANCE_FIELDS';end if;
 if p_action in('PREVIEW','SAVE') then
  for line in select value from jsonb_array_elements(d->'attendance') loop
   if jsonb_typeof(line) is distinct from 'object' or not line ?& array['worker_id','attendance_date','status','paid_fraction']
    or exists(select 1 from jsonb_each(line) e where e.key<>all(array['worker_id','attendance_date','status','paid_fraction','notes','supersedes_attendance_record_id']) or case when e.key in('notes','supersedes_attendance_record_id') then jsonb_typeof(e.value) not in('string','null') else jsonb_typeof(e.value)<>'string' end)
    or coalesce(line->>'worker_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    or coalesce(line->>'attendance_date','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
    or coalesce(line->>'status','') not in('PRESENT','ABSENT','HALF_DAY','SICK','LEAVE','OFF')
    or coalesce(line->>'paid_fraction','')!~'^(0([.][0-9]{1,4})?|1([.]0{1,4})?)$'
    or(line->>'supersedes_attendance_record_id' is not null and line->>'supersedes_attendance_record_id'!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$') then raise exception 'CP7_ATTENDANCE_LINE_FIELDS';end if;
   if(line->>'status'='HALF_DAY' and(line->>'paid_fraction')::numeric>0.5) or(line->>'status' in('ABSENT','OFF') and(line->>'paid_fraction')::numeric<>0) then raise exception 'CP7_ATTENDANCE_LINE_FRACTION';end if;
  end loop;
 end if;
end $$;

create function cp7_attendance.apply_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security definer set search_path='' as $$
declare a jsonb;d jsonb:=p_payload->'document';cid uuid:=(p_payload->>'contractor_id')::uuid;pid uuid:=(d->>'period_id')::uuid;p erp.attendance_periods;ctx cp7_attendance.command_context;native jsonb;
begin
 a:=cp7_attendance.command_access(p_action,d,p_expected);
 select * into ctx from cp7_attendance.command_context where backend_pid=pg_backend_pid() and transaction_id=txid_current() and actor=auth.uid() and action=p_action and contractor_id=cid and period_id is not distinct from pid;
 if ctx.actor is null or ctx.permission is distinct from a->>'attendance_permission' or ctx.owner_required is distinct from(a->>'attendance_owner_required')::boolean then raise exception using errcode='42501',message='CP7_ATTENDANCE_PRIVATE_CONTEXT_REQUIRED';end if;
 perform pg_advisory_xact_lock(hashtextextended(cid::text,0));
 perform 1 from erp.contractors where id=cid and contractor_type='MANDOR' for share;
 if not found then raise exception 'CP7_ATTENDANCE_CONTRACTOR';end if;
 if pid is not null then
  select * into p from erp.attendance_periods where id=pid for update;
  if p.id is null or p.contractor_id<>cid then raise exception 'CP7_ATTENDANCE_PERIOD_PARENT';end if;
  if p.row_version::text is distinct from p_expected then raise exception 'CP7_ATTENDANCE_VERSION_CHANGED';end if;
  if p_action in('PREVIEW','SAVE') and p.status<>'DRAFT' then raise exception 'CP7_ATTENDANCE_DRAFT_ONLY';end if;
  if p_action in('POST','REVERSE') and(p.period_start::text is distinct from p_payload->>'date_from' or p.period_end::text is distinct from p_payload->>'date_to') then raise exception 'CP7_ATTENDANCE_PERIOD_DATES';end if;
 end if;
 perform 1 from erp.contractor_workers where contractor_id=cid order by id for share;
 if cp7_attendance.command_access(p_action,d,p_expected) is distinct from a then raise exception using errcode='42501',message='CP7_ATTENDANCE_ACCESS_CHANGED';end if;
 if cp7_attendance.source_token(cid,(p_payload->>'date_from')::date,(p_payload->>'date_to')::date) is distinct from p_payload->>'source_token' then raise exception 'CP7_ATTENDANCE_REVIEW_CHANGED';end if;
 if p_action in('PREVIEW','SAVE') then
  native:=erp.save_attendance_period_v1(d,p_request,p_expected::bigint,p_action='PREVIEW');
  if p_action='SAVE' then pid:=(native->>'period_id')::uuid;end if;
 elsif p_action='POST' then native:=erp.post_attendance_period_v1(pid,d->>'reason',p_request,p_expected::bigint);
 elsif p_action='REVERSE' then native:=erp.reverse_attendance_period_v1(pid,d->>'reason',p_request,p_expected::bigint);
 end if;
 if cp7_attendance.command_access(p_action,d,p_expected) is distinct from a then raise exception using errcode='42501',message='CP7_ATTENDANCE_ACCESS_CHANGED';end if;
 if p_action='PREVIEW' then
  if native->'preview_only' is distinct from 'true'::jsonb then raise exception 'CP7_ATTENDANCE_NATIVE_PREVIEW';end if;
  return jsonb_build_object('contract_version','cp7.attendance-preview.v1','kind','READ_ONLY_PREVIEW','contractor_id',cid,'period_id',pid,'source_token',p_payload->>'source_token','line_count',native->>'line_count','paid_day_equivalent',native->>'paid_day_equivalent','estimated_amount',native->>'estimated_amount');
 end if;
 select * into p from erp.attendance_periods where id=pid;
 if p.id is null or p.contractor_id<>cid or native->>'period_id' is distinct from p.id::text or native->>'row_version' is distinct from p.row_version::text or p.status is distinct from (case p_action when 'SAVE' then 'DRAFT' when 'POST' then 'POSTED' when 'REVERSE' then 'REVERSED' end) then raise exception 'CP7_ATTENDANCE_NATIVE_OUTCOME';end if;
 return jsonb_build_object('contract_version','cp7.attendance-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'period_id',p.id,'contractor_id',cid,'row_version',p.row_version::text,'status',p.status,'source_token',cp7_attendance.source_token(cid,(p_payload->>'date_from')::date,(p_payload->>'date_to')::date));
end $$;

create function cp7_attendance.attendance_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_attendance.command_requests;result jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 perform cp7_attendance.validate_command(p_action,p_payload,p_expected);
 a:=cp7_attendance.command_access(p_action,p_payload->'document',p_expected);
 if p_action<>'PREVIEW' then
  if p_request is null then raise exception 'CP7_ATTENDANCE_REQUEST_REQUIRED';end if;
  insert into cp7_attendance.command_requests values(auth.uid(),p_request,p_action,p_payload,p_expected,null) on conflict do nothing;
  select * into old from cp7_attendance.command_requests where actor=auth.uid() and request_id=p_request for update;
  if old.action is distinct from p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_ATTENDANCE_REQUEST_CHANGED';end if;
  if cp7_attendance.command_access(p_action,p_payload->'document',p_expected) is distinct from a then raise exception using errcode='42501',message='CP7_ATTENDANCE_ACCESS_CHANGED';end if;
  if old.response is not null then return old.response;end if;
 end if;
 insert into cp7_attendance.command_context values(pg_backend_pid(),txid_current(),auth.uid(),(p_payload->>'contractor_id')::uuid,(p_payload->'document'->>'period_id')::uuid,p_action,a->>'attendance_permission',(a->>'attendance_owner_required')::boolean);
 result:=cp7_attendance.apply_command(p_action,p_payload,p_request,p_expected);
 delete from cp7_attendance.command_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
 if cp7_attendance.command_access(p_action,p_payload->'document',p_expected) is distinct from a then raise exception using errcode='42501',message='CP7_ATTENDANCE_ACCESS_CHANGED';end if;
 if p_action<>'PREVIEW' then update cp7_attendance.command_requests set response=result where actor=auth.uid() and request_id=p_request;end if;
 return result;
end $$;

create function public.erp_cp7_save_attendance_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security definer set search_path='' as $$begin
 if p_action='PREVIEW' then raise exception 'CP7_ATTENDANCE_USE_PREVIEW';end if;
 return cp7_attendance.attendance_command(p_action,p_payload,p_request,p_expected);
end $$;
create function public.erp_cp7_preview_attendance_v1(p_payload jsonb,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_attendance.attendance_command('PREVIEW',p_payload,null,p_expected)$$;
alter function cp7_attendance.command_access(text,jsonb,text) owner to cp7_attendance_read;
alter function cp7_attendance.validate_command(text,jsonb,text) owner to cp7_attendance_write;
alter function cp7_attendance.apply_command(text,jsonb,uuid,text) owner to postgres;
alter function cp7_attendance.attendance_command(text,jsonb,uuid,text) owner to cp7_attendance_write;
grant create on schema public to cp7_attendance_write;
alter function public.erp_cp7_save_attendance_v1(text,jsonb,uuid,text) owner to cp7_attendance_write;
alter function public.erp_cp7_preview_attendance_v1(jsonb,text) owner to cp7_attendance_write;
revoke create on schema public from cp7_attendance_write;
revoke all on function cp7_attendance.command_access(text,jsonb,text),cp7_attendance.validate_command(text,jsonb,text),cp7_attendance.apply_command(text,jsonb,uuid,text),cp7_attendance.attendance_command(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture,cp7_attendance_read,cp7_roster_write,cp7_payroll_write,cp7_payroll_read;
grant execute on function cp7_attendance.command_access(text,jsonb,text) to cp7_attendance_write,postgres;
grant execute on function cp7_attendance.apply_command(text,jsonb,uuid,text) to cp7_attendance_write;
grant select on cp7_attendance.command_context to postgres;
revoke all on function public.erp_cp7_save_attendance_v1(text,jsonb,uuid,text),public.erp_cp7_preview_attendance_v1(jsonb,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_save_attendance_v1(text,jsonb,uuid,text),public.erp_cp7_preview_attendance_v1(jsonb,text) to authenticated;

do $patch$ declare d text;begin
 d:=pg_get_functiondef('erp.require_internal()'::regprocedure);
 execute replace(d,$anchor$ v_app_role:=erp.current_app_role();$anchor$,$delta$  if exists(select 1 from cp7_attendance.command_context c where c.backend_pid=pg_backend_pid()
    and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
     and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
    then erp.has_permission('finance.attendance.view') and erp.has_permission(c.permission)
    and(not c.owner_required or erp.current_app_role() in('OWNER','ADMIN'))
    else false end) then return;end if;
 v_app_role:=erp.current_app_role();$delta$);
end $patch$;
-- Paged native worker/day matrix. Missing marks remain null. Existing draft
-- rows remain visible even when their worker no longer matches eligibility.
create function cp7_attendance.entry_workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare cid uuid;pid uuid;start_date date;end_date date;lim integer;off integer;c erp.contractors;p erp.attendance_periods;rows jsonb;total bigint;
begin
 perform cp7_attendance.access_now();
 if jsonb_typeof(p_query) is distinct from 'object' or not p_query ?& array['contractor_id','date_from','date_to']
  or exists(select 1 from jsonb_each(p_query) e where e.key<>all(array['contractor_id','date_from','date_to','period_id','limit','offset']) or case when e.key in('limit','offset') then jsonb_typeof(e.value)<>'number' when e.key='period_id' then jsonb_typeof(e.value) not in('string','null') else jsonb_typeof(e.value)<>'string' end)
  or coalesce(p_query->>'contractor_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or(p_query->>'period_id' is not null and p_query->>'period_id'!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
  or coalesce(p_query->>'date_from','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$' or coalesce(p_query->>'date_to','')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
  or coalesce(p_query->>'limit','100')!~'^[1-9][0-9]{0,2}$' or coalesce(p_query->>'offset','0')!~'^(0|[1-9][0-9]{0,6})$' then raise exception 'CP7_ATTENDANCE_ENTRY_QUERY';end if;
 cid:=(p_query->>'contractor_id')::uuid;pid:=(p_query->>'period_id')::uuid;start_date:=(p_query->>'date_from')::date;end_date:=(p_query->>'date_to')::date;lim:=coalesce((p_query->>'limit')::integer,100);off:=coalesce((p_query->>'offset')::integer,0);
 if end_date<start_date or lim>100 or off>1000000 then raise exception 'CP7_ATTENDANCE_ENTRY_QUERY';end if;
 select * into c from erp.contractors where id=cid and contractor_type='MANDOR';if c.id is null then raise exception 'CP7_ATTENDANCE_CONTRACTOR';end if;
 if pid is not null then
  select * into p from erp.attendance_periods where id=pid;
  if p.id is null or p.contractor_id<>cid or p.period_start<>start_date or p.period_end<>end_date then raise exception 'CP7_ATTENDANCE_ENTRY_PARENT';end if;
 end if;
 with cells as materialized(
  select w.id worker_id,w.worker_name,w.worker_code,w.pay_scheme,start_date+days.n work_date,
   exists(select 1 from erp.worker_employment_periods e where e.worker_id=w.id and e.started_on<=start_date+days.n and(e.ended_on is null or e.ended_on>=start_date+days.n)) employed,
   ar.id record_id,ar.status,ar.paid_fraction,ar.notes,ar.record_lifecycle,ar.supersedes_attendance_record_id,ar.row_version
  from erp.contractor_workers w cross join generate_series(0,end_date-start_date) days(n)
  left join erp.attendance_records ar on ar.attendance_period_id=pid and ar.worker_id=w.id and ar.attendance_date=start_date+days.n
  where w.contractor_id=cid
 ), eligible as materialized(select * from cells where employed or record_id is not null),paged as(
  select * from eligible order by work_date,worker_name,worker_id limit lim offset off
 )
 select(select count(*) from eligible),coalesce(jsonb_agg(jsonb_build_object('id',x.worker_id::text||':'||x.work_date::text,'worker_id',x.worker_id,'worker_name',x.worker_name,'worker_code',x.worker_code,'pay_scheme',x.pay_scheme,'date',x.work_date,'eligible',x.employed,'required',c.attendance_required and x.employed and x.pay_scheme in('DAILY','HYBRID'),
  'daily_rate',(select v.daily_rate::text from erp.worker_daily_rate_versions v where v.worker_id=x.worker_id and v.effective_from<=x.work_date and(v.effective_to is null or v.effective_to>=x.work_date) order by v.effective_from desc limit 1),
  'record',case when x.record_id is null then null else jsonb_build_object('id',x.record_id,'mark',x.status,'paid_fraction',x.paid_fraction::text,'notes',x.notes,'lifecycle',x.record_lifecycle,'supersedes_id',x.supersedes_attendance_record_id,'row_version',x.row_version::text) end) order by x.work_date,x.worker_name,x.worker_id),'[]') into total,rows from paged x;
 return jsonb_build_object('contract_version','cp7.attendance-entry.v1','date_from',start_date,'date_to',end_date,'source_token',cp7_attendance.source_token(cid,start_date,end_date),'contractor',jsonb_build_object('id',c.id,'name',c.contractor_name,'active_now',c.is_active,'attendance_required',c.attendance_required),'period',case when pid is null then null else cp7_attendance.period_document(pid) end,'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',lim,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;
create function public.erp_cp7_get_attendance_entry_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_attendance.entry_workspace(p_query)$$;
alter function cp7_attendance.entry_workspace(jsonb) owner to cp7_attendance_read;
grant create on schema public to cp7_attendance_read;
alter function public.erp_cp7_get_attendance_entry_v1(jsonb) owner to cp7_attendance_read;
revoke create on schema public from cp7_attendance_read;
revoke all on function cp7_attendance.entry_workspace(jsonb) from public,anon,authenticated,service_role,cp7_capture,cp7_roster_write,cp7_attendance_write;
revoke all on function public.erp_cp7_get_attendance_entry_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_attendance_entry_v1(jsonb) to authenticated;

-- P11 bounded invoice reader. It has no business writer capability. Financial
-- fields require AR authority; historical SKU is resolved at the invoice time.
create role cp7_sales_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_sales authorization cp7_sales_read;
revoke all on schema cp7_sales from public,anon,authenticated,service_role,cp7_capture;
grant usage on schema erp,auth to cp7_sales_read;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text),erp.bf_commercial_sku_at_v1(uuid,timestamptz) to cp7_sales_read;
grant select on erp.sales_headers,erp.sales_items,erp.customers,erp.locations,erp.products,erp.sizes,erp.brands,
 erp.sales_returns,erp.sales_return_items,erp.sales_payments,erp.fg_stock_movements,erp.sale_stock_allocations to cp7_sales_read;

create function cp7_sales.access_now() returns boolean
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_SALES_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission('sales.invoice.view') then raise exception using errcode='42501',message='CP7_SALES_ACCESS_DENIED';end if;
 return erp.has_permission('finance.ar.view');
end $$;

create function cp7_sales.review_token(p_id uuid) returns text
language sql stable security invoker set search_path='' as $$
 select md5(jsonb_build_object('header',to_jsonb(h),
  'items',(select coalesce(jsonb_agg(to_jsonb(i) order by i.id),'[]') from erp.sales_items i where i.sale_id=h.id),
  'allocations',(select coalesce(jsonb_agg(to_jsonb(a) order by a.id),'[]') from erp.sale_stock_allocations a join erp.sales_items i on i.id=a.sale_item_id where i.sale_id=h.id),
  'payments',(select coalesce(jsonb_agg(to_jsonb(p) order by p.id),'[]') from erp.sales_payments p where p.sale_id=h.id),
  'returns',(select coalesce(jsonb_agg(to_jsonb(r) order by r.id),'[]') from erp.sales_returns r where r.sale_id=h.id),
  'return_items',(select coalesce(jsonb_agg(to_jsonb(i) order by i.id),'[]') from erp.sales_return_items i join erp.sales_returns r on r.id=i.return_id where r.sale_id=h.id),
  'reservations',(select coalesce(jsonb_agg(to_jsonb(m) order by m.id),'[]') from erp.fg_stock_movements m join erp.sales_items i on i.id=m.source_id and m.source_type='SALE_ITEM' where i.sale_id=h.id))::text)
 from erp.sales_headers h where h.id=p_id
$$;

create function cp7_sales.header(h erp.sales_headers,p_financial boolean) returns jsonb
language sql stable security invoker set search_path='' as $$
 with amounts as(
  select coalesce((select sum(line_total) from erp.sales_items where sale_id=h.id),0)::numeric gross,
   coalesce((select sum(i.refund_amount) from erp.sales_return_items i join erp.sales_returns r on r.id=i.return_id where r.sale_id=h.id and r.status='POSTED'),0)::numeric returned,
   coalesce((select sum(round(amount,2)) from erp.sales_payments where sale_id=h.id and status='POSTED'),0)::numeric paid
 )
 select jsonb_build_object('id',h.id,'number',h.sale_number,'customer_id',h.customer_id,
  'customer_name',(select customer_name from erp.customers where id=h.customer_id),'location_id',h.source_location_id,
  'location_name',(select location_name from erp.locations where id=h.source_location_id),'physical_at',h.sale_date,
  'due_date',h.due_date,'status',h.status,'row_version',h.row_version::text,'notes',h.notes,'payment_terms',h.payment_terms,
  'line_count',(select count(*)::text from erp.sales_items where sale_id=h.id),
  'qty_pcs',(select coalesce(sum(qty_pcs),0)::text from erp.sales_items where sale_id=h.id),
  'reserved_qty',(select coalesce(sum(-m.qty_signed),0)::text from erp.fg_stock_movements m join erp.sales_items i on m.source_id=i.id and m.source_type='SALE_ITEM'
   where i.sale_id=h.id and m.movement_type='SALE_RESERVE' and not exists(select 1 from erp.fg_stock_movements rv where rv.reversal_of_id=m.id)),
  'returned_qty',(select coalesce(sum(i.qty_pcs),0)::text from erp.sales_return_items i join erp.sales_returns r on r.id=i.return_id where r.sale_id=h.id and r.status='POSTED'))
 ||case when p_financial then (select jsonb_build_object('financial',jsonb_build_object(
   'basis','CURRENT_NATIVE_DOCUMENT','state',case when h.status='DRAFT' then 'DRAFT_PREVIEW' when h.status in('POSTED','PARTIAL_PAID','PAID') then 'ACTIVE_RECEIVABLE' else 'INACTIVE_DOCUMENT' end,
   'gross_total',round(gross,2)::text,'return_total',round(returned,2)::text,'net_total',round(greatest(gross-returned,0),2)::text,
   'paid_total',round(paid,2)::text,'open_balance',case when h.status in('POSTED','PARTIAL_PAID','PAID') then round(greatest(gross-returned,0)-paid,2)::text else null end)) from amounts) else '{}'::jsonb end
$$;

create function cp7_sales.workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare financial boolean;q text;state text;chosen uuid;n integer;off integer;total bigint;rows jsonb;detail jsonb:=null;h erp.sales_headers;items jsonb;
begin
 financial:=cp7_sales.access_now();
 if jsonb_typeof(p_query) is distinct from 'object' or exists(select 1 from jsonb_object_keys(p_query) k where k not in('q','status','sale_id','offset','limit'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('q','status','sale_id') and jsonb_typeof(e.value) not in('string','null'))
  or(p_query ? 'limit' and (jsonb_typeof(p_query->'limit')<>'number' or (p_query->>'limit')!~'^[0-9]{1,3}$'))
  or(p_query ? 'offset' and (jsonb_typeof(p_query->'offset')<>'number' or (p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_SALES_QUERY';end if;
 q:=btrim(coalesce(p_query->>'q',''));state:=nullif(p_query->>'status','');chosen:=(p_query->>'sale_id')::uuid;n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);
 if length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000 or state is not null and state not in('DRAFT','POSTED','PARTIAL_PAID','PAID','CANCELLED','REVERSED') then raise exception 'CP7_SALES_QUERY';end if;
 select count(*) into total from erp.sales_headers x join erp.customers c on c.id=x.customer_id
 where (state is null or x.status=state) and(q='' or strpos(lower(concat_ws(' ',x.sale_number,c.customer_code,c.customer_name)),lower(q))>0);
 select coalesce(jsonb_agg(cp7_sales.header(x,financial) order by x.sale_date desc,x.id),'[]') into rows from(
  select x.* from erp.sales_headers x join erp.customers c on c.id=x.customer_id
  where (state is null or x.status=state) and(q='' or strpos(lower(concat_ws(' ',x.sale_number,c.customer_code,c.customer_name)),lower(q))>0)
  order by x.sale_date desc,x.id limit n offset off)x;
 if chosen is not null then
  select * into h from erp.sales_headers where id=chosen;
  if h.id is null then raise exception 'CP7_SALES_NOT_FOUND';end if;
  if (select count(*) from erp.sales_items where sale_id=h.id)>100 then raise exception 'CP7_SALES_DOCUMENT_TOO_LARGE';end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'product_id',i.product_id,'product_sku',p.sku,
   'commercial_sku',erp.bf_commercial_sku_at_v1(p.id,h.sale_date),'product_name',p.product_name,'size_code',s.size_code,'brand_name',b.brand_name,
   'qty_pcs',i.qty_pcs::text,'notes',i.notes)
   ||case when financial then jsonb_build_object('financial',jsonb_build_object('unit_price',i.unit_price_snapshot::text,'discount',i.discount_amount::text,'line_total',i.line_total::text)) else '{}'::jsonb end order by i.id),'[]')
  into items from erp.sales_items i join erp.products p on p.id=i.product_id join erp.sizes s on s.id=p.size_id join erp.brands b on b.id=p.brand_id where i.sale_id=h.id;
  if jsonb_array_length(items)<>(select count(*) from erp.sales_items where sale_id=h.id) then raise exception 'CP7_SALES_INCOMPLETE_ITEMS';end if;
  detail:=cp7_sales.header(h,financial)||jsonb_build_object('items',items)||case when financial then jsonb_build_object('review_token',cp7_sales.review_token(h.id)) else '{}'::jsonb end;
 end if;
 return jsonb_build_object('contract_version','cp7.sales-workspace.v1','read_at',statement_timestamp(),'financial_captured',financial,'read_only',true,
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end),'detail',detail);
end $$;
create function public.erp_cp7_get_sales_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_sales.workspace(p_query)$$;
alter function cp7_sales.access_now() owner to cp7_sales_read;
alter function cp7_sales.review_token(uuid) owner to cp7_sales_read;
alter function cp7_sales.header(erp.sales_headers,boolean) owner to cp7_sales_read;
alter function cp7_sales.workspace(jsonb) owner to cp7_sales_read;
grant create on schema public to cp7_sales_read;
alter function public.erp_cp7_get_sales_v1(jsonb) owner to cp7_sales_read;
revoke create on schema public from cp7_sales_read;
revoke all on all functions in schema cp7_sales from public,anon,authenticated,service_role,cp7_capture;
revoke all on function public.erp_cp7_get_sales_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_sales_v1(jsonb) to authenticated;

-- Reject lossy numeric/coercion and incomplete full-document replacements before
-- calling the native draft writer. Native stock/accounting policy is unchanged.
create function cp7_sales.validate_draft(p_payload jsonb,p_edit boolean) returns void
language plpgsql immutable security invoker set search_path='' as $$
declare keys text[];line jsonb;
begin
 keys:=array['sale_number','customer_id','source_location_id','sale_date','due_date','payment_terms','notes','change_reason','items']||case when p_edit then array['sale_id','review_token'] else '{}'::text[] end;
 if jsonb_typeof(p_payload) is distinct from 'object' or not p_payload ?& keys or exists(select 1 from jsonb_each(p_payload) e where e.key<>all(keys) or(e.key<>'items' and jsonb_typeof(e.value) not in('string','null')))
  or coalesce(length(btrim(p_payload->>'sale_number')),0) not between 1 and 60
  or coalesce(length(btrim(p_payload->>'change_reason')),0) not between 5 and 1000
  or coalesce(p_payload->>'customer_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p_payload->>'source_location_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p_payload->>'sale_date','')!~'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?(Z|[+-]\d{2}:\d{2})$'
  or(p_payload->>'due_date' is not null and(p_payload->>'due_date')!~'^\d{4}-\d{2}-\d{2}$')
  or length(p_payload->>'payment_terms')>100 or length(p_payload->>'notes')>4000
  or (p_edit and(coalesce(p_payload->>'sale_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' or coalesce(p_payload->>'review_token','')!~'^[a-f0-9]{32}$'))
  or jsonb_typeof(p_payload->'items') is distinct from 'array' or jsonb_array_length(p_payload->'items') not between 1 and 100 then raise exception 'CP7_SALES_DRAFT_FIELDS';end if;
 for line in select value from jsonb_array_elements(p_payload->'items') loop
  if jsonb_typeof(line) is distinct from 'object' or not line ?& array['product_id','qty_pcs','unit_price_snapshot','discount_amount','notes']
   or exists(select 1 from jsonb_each(line) e where e.key not in('product_id','qty_pcs','unit_price_snapshot','discount_amount','notes') or jsonb_typeof(e.value) not in('string','null'))
   or coalesce(line->>'product_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
   or coalesce(line->>'qty_pcs','')!~'^[1-9][0-9]{0,8}$'
   or coalesce(line->>'unit_price_snapshot','')!~'^(0|[1-9][0-9]{0,15})(\.[0-9]{1,2})?$'
   or coalesce(line->>'discount_amount','')!~'^(0|[1-9][0-9]{0,15})(\.[0-9]{1,2})?$'
   or length(line->>'notes')>4000 then raise exception 'CP7_SALES_DRAFT_LINE';end if;
  if (line->>'discount_amount')::numeric>(line->>'qty_pcs')::integer*(line->>'unit_price_snapshot')::numeric then raise exception 'CP7_SALES_DISCOUNT';end if;
 end loop;
end $$;
alter function cp7_sales.validate_draft(jsonb,boolean) owner to cp7_sales_read;
revoke all on function cp7_sales.validate_draft(jsonb,boolean) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_sales.validate_draft(jsonb,boolean) to postgres;

-- P11 reviewed draft transitions. Business effects remain accepted native calls.
create role cp7_sales_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
grant usage on schema cp7_sales,auth to cp7_sales_write;
grant execute on function auth.uid() to cp7_sales_write;
create table cp7_sales.requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text,response jsonb,primary key(actor,request_id));
create table cp7_sales.command_context(backend_pid integer not null,transaction_id bigint not null,actor uuid not null,sale_id uuid,action text not null check(action in('CREATE','EDIT','POST','CANCEL','PAYMENT','PAYMENT_REVERSE','RETURN','RETURN_REVERSE','SALE_REVERSE')),primary key(backend_pid,transaction_id));
alter table cp7_sales.requests owner to cp7_sales_write;
alter table cp7_sales.command_context owner to cp7_sales_write;
alter table cp7_sales.requests enable row level security;
alter table cp7_sales.command_context enable row level security;
revoke all on cp7_sales.requests,cp7_sales.command_context from public,anon,authenticated,service_role,cp7_capture,cp7_sales_read;

create function cp7_sales.command_access(p_action text) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare a jsonb;
begin
 -- Read the complete current access once per invocation. access_now() already
 -- obtains that same document; invoking it here and then reading it again
 -- multiplies full permission-list reads in each native account/HPP guard.
 -- This is never a command/transaction cache: every post-wait guard invocation
 -- still reads current authority and calls the native fine permission checks.
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_SALES_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission('sales.invoice.view') then raise exception using errcode='42501',message='CP7_SALES_ACCESS_DENIED';end if;
 if not erp.has_permission('finance.ar.view') or p_action is null or p_action not in('CREATE','EDIT','POST','CANCEL','PAYMENT','PAYMENT_REVERSE','RETURN','RETURN_REVERSE','SALE_REVERSE')
  or not erp.has_permission(case when p_action='POST' then 'sales.invoice.post' when p_action='CREATE' then 'sales.invoice.create' when p_action='PAYMENT' then 'sales.payment.create' when p_action='PAYMENT_REVERSE' then 'sales.payment.reverse' when p_action='RETURN' then 'sales.return.create' when p_action='RETURN_REVERSE' then 'sales.return.reverse' when p_action='SALE_REVERSE' then 'sales.invoice.reverse' else 'sales.invoice.edit_draft' end)
  or(p_action in('PAYMENT','PAYMENT_REVERSE') and not erp.has_permission('sales.payment.view'))
  or(p_action='PAYMENT' and not erp.has_permission('sales.payment.post'))
  or(p_action in('RETURN','RETURN_REVERSE') and not erp.has_permission('sales.return.view'))
  or(p_action='RETURN' and not erp.has_permission('sales.return.post'))
 then raise exception using errcode='42501',message='CP7_SALES_WRITE_DENIED';end if;
 if p_action in('PAYMENT_REVERSE','RETURN_REVERSE','SALE_REVERSE') and coalesce(a->'profile'->>'role_code','') not in('OWNER','ADMIN') then raise exception using errcode='42501',message='CP7_SALES_OWNER_ADMIN_REQUIRED';end if;
 return a;
end $$;

-- require_internal only needs an authorization decision. Rebuilding the full
-- profile/permission-list document for every Native account lookup multiplied
-- that read thousands of times in one historical correction. Keep the complete
-- command_access document at every owning command and post-wait comparison.
-- This private admission still reads Native current permissions on every call:
-- there is no request/transaction cache, GUC capability or stored authority.
create function cp7_sales.command_allowed(p_action text) returns boolean
language plpgsql stable security invoker set search_path='' as $$
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_SALES_ACCESS_DENIED';end if;
 -- Native has_permission(NULL) can only be true for its current active,
 -- protected OWNER universal grant here: service JWTs were refused above and
 -- a SQL NULL cannot equal a stored permission key. Read that Native decision
 -- anew; do not duplicate its role formula or cache authority. Invalid actions
 -- still follow the unchanged exact refusal checks below.
 if p_action in('CREATE','EDIT','POST','CANCEL','PAYMENT','PAYMENT_REVERSE','RETURN','RETURN_REVERSE','SALE_REVERSE') and erp.has_permission(null::text) then return true;end if;
 -- Native has_permission's positive invoice-view result also requires the
 -- same unique active app user and active role as get_my_access.allowed.
 if not erp.has_permission('sales.invoice.view') then raise exception using errcode='42501',message='CP7_SALES_ACCESS_DENIED';end if;
 if not erp.has_permission('finance.ar.view') or p_action is null or p_action not in('CREATE','EDIT','POST','CANCEL','PAYMENT','PAYMENT_REVERSE','RETURN','RETURN_REVERSE','SALE_REVERSE')
  or not erp.has_permission(case when p_action='POST' then 'sales.invoice.post' when p_action='CREATE' then 'sales.invoice.create' when p_action='PAYMENT' then 'sales.payment.create' when p_action='PAYMENT_REVERSE' then 'sales.payment.reverse' when p_action='RETURN' then 'sales.return.create' when p_action='RETURN_REVERSE' then 'sales.return.reverse' when p_action='SALE_REVERSE' then 'sales.invoice.reverse' else 'sales.invoice.edit_draft' end)
  or(p_action in('PAYMENT','PAYMENT_REVERSE') and not erp.has_permission('sales.payment.view'))
  or(p_action='PAYMENT' and not erp.has_permission('sales.payment.post'))
  or(p_action in('RETURN','RETURN_REVERSE') and not erp.has_permission('sales.return.view'))
  or(p_action='RETURN' and not erp.has_permission('sales.return.post'))
 then raise exception using errcode='42501',message='CP7_SALES_WRITE_DENIED';end if;
 if p_action in('PAYMENT_REVERSE','RETURN_REVERSE','SALE_REVERSE') and coalesce(erp.current_app_role(),'') not in('OWNER','ADMIN') then raise exception using errcode='42501',message='CP7_SALES_OWNER_ADMIN_REQUIRED';end if;
 return true;
end $$;

create function cp7_sales.apply_command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security definer set search_path='' as $$
declare a jsonb;h erp.sales_headers;r jsonb;ident uuid:=(p_payload->>'sale_id')::uuid;native_request uuid;payment_id uuid;payment erp.sales_payments;return_id uuid;returned erp.sales_returns;line jsonb;allocation record;
begin
 a:=cp7_sales.command_access(p_action);
 if not exists(select 1 from cp7_sales.command_context where backend_pid=pg_backend_pid() and transaction_id=txid_current() and actor=auth.uid() and sale_id is not distinct from ident and action=p_action)
 then raise exception using errcode='42501',message='CP7_SALES_PRIVATE_CONTEXT_REQUIRED';end if;
 -- Follow the native FG lock order, then recheck both authority and the exact
 -- document including child prices/allocations, not just its header revision.
 perform pg_advisory_xact_lock(hashtextextended('FG_HPP_SALES_V2620C',0));
 if p_action<>'CREATE' then
 -- Native cash functions lock payment before invoice. Preserve that order
 -- while the shared FG lock serializes ordinary invoice/return adapters.
 if p_action in('PAYMENT','PAYMENT_REVERSE','RETURN','RETURN_REVERSE','SALE_REVERSE') then perform 1 from erp.sales_payments where sale_id=ident order by id for update;end if;
 if p_action in('RETURN','RETURN_REVERSE','SALE_REVERSE') then perform 1 from erp.sales_returns where sale_id=ident order by id for update;end if;
 select * into h from erp.sales_headers where id=ident for update;
 if h.id is null then raise exception 'CP7_SALES_NOT_FOUND';end if;
 perform 1 from erp.sales_items where sale_id=ident order by id for update;
 perform 1 from erp.sale_stock_allocations x where exists(select 1 from erp.sales_items i where i.id=x.sale_item_id and i.sale_id=ident) order by x.id for update;
 if cp7_sales.command_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 if h.row_version::text is distinct from p_expected or cp7_sales.review_token(ident) is distinct from p_payload->>'review_token' then raise exception 'CP7_SALES_REVIEW_CHANGED';end if;
 if p_action in('EDIT','POST','CANCEL') and h.status<>'DRAFT' then raise exception 'CP7_SALES_DRAFT_ONLY';end if;
 if p_action in('PAYMENT','PAYMENT_REVERSE','RETURN','RETURN_REVERSE','SALE_REVERSE') and h.status not in('POSTED','PARTIAL_PAID','PAID') then raise exception 'CP7_SALES_ACTIVE_ONLY';end if;
 end if;
 if cp7_sales.command_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 perform set_config('app.change_reason',btrim(p_payload->>'change_reason'),true);
 native_request:=md5(auth.uid()::text||':'||p_action||':'||p_request::text)::uuid;
 if p_action in('CREATE','EDIT') then
  perform cp7_sales.validate_draft(p_payload,p_action='EDIT');
  perform 1 from erp.products where id in(select (value->>'product_id')::uuid from jsonb_array_elements(p_payload->'items')) order by id for share;
  if exists(select 1 from jsonb_array_elements(p_payload->'items') x where not exists(select 1 from erp.products p where p.id=(x->>'product_id')::uuid and p.is_active)) then raise exception 'CP7_SALES_PRODUCT_UNAVAILABLE';end if;
  perform 1 from erp.customers where id=(p_payload->>'customer_id')::uuid for share;
  perform 1 from erp.locations where id=(p_payload->>'source_location_id')::uuid for share;
  if (p_payload->>'sale_date')::timestamptz>statement_timestamp() then raise exception 'CP7_SALES_FUTURE_DATE';end if;
  r:=erp.save_sale_draft_v2((p_payload-'review_token'-'change_reason')||jsonb_build_object('reason',btrim(p_payload->>'change_reason')),native_request,p_expected::bigint);
  ident:=(r->>'sale_id')::uuid;
 elsif p_action='PAYMENT' then
  perform 1 from erp.cash_accounts where id=(p_payload->>'cash_account_id')::uuid for share;
  if not exists(select 1 from erp.cash_accounts where id=(p_payload->>'cash_account_id')::uuid and is_active) then raise exception 'CP7_SALES_CASH_UNAVAILABLE';end if;
  if cp7_sales.command_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
  insert into erp.sales_payments(sale_id,payment_number,payment_date,amount,cash_account_id,payment_method,reference_number,notes,status,created_by)
  values(ident,btrim(p_payload->>'payment_number'),(p_payload->>'payment_date')::timestamptz,(p_payload->>'amount')::numeric,(p_payload->>'cash_account_id')::uuid,p_payload->>'payment_method',p_payload->>'reference_number',p_payload->>'notes','DRAFT',erp.current_app_user_id()) returning id into payment_id;
  perform erp.post_sales_payment(payment_id);
 elsif p_action='PAYMENT_REVERSE' then
  payment_id:=(p_payload->>'payment_id')::uuid;select * into payment from erp.sales_payments where id=payment_id;
  if payment.id is null or payment.sale_id<>ident or payment.status<>'POSTED' then raise exception 'CP7_SALES_PAYMENT_SOURCE_CHANGED';end if;
  perform erp.reverse_sales_payment(payment_id,btrim(p_payload->>'change_reason'));
 elsif p_action='RETURN' then
  if(p_payload->>'physical_at')::timestamptz>statement_timestamp() then raise exception 'CP7_SALES_RETURN_FUTURE_DATE';end if;
  perform 1 from erp.locations where id in(select (value->>'location_id')::uuid from jsonb_array_elements(p_payload->'items')) order by id for share;
  if cp7_sales.command_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
  insert into erp.sales_returns(return_number,sale_id,customer_id,physical_at,notes,status,created_by)
  values(btrim(p_payload->>'return_number'),ident,h.customer_id,(p_payload->>'physical_at')::timestamptz,p_payload->>'notes','DRAFT',erp.current_app_user_id()) returning id into return_id;
  for line in select value from jsonb_array_elements(p_payload->'items') loop
   select a.id,a.lot_id,i.product_id into allocation from erp.sale_stock_allocations a join erp.sales_items i on i.id=a.sale_item_id where a.id=(line->>'allocation_id')::uuid and i.sale_id=ident;
   if not found then raise exception 'CP7_SALES_RETURN_ALLOCATION_CHANGED';end if;
   insert into erp.sales_return_items(return_id,sale_stock_allocation_id,product_id,lot_id,location_id,qty_pcs,quality_grade,refund_amount,notes)
   values(return_id,allocation.id,allocation.product_id,allocation.lot_id,(line->>'location_id')::uuid,(line->>'qty_pcs')::integer,line->>'quality_grade',(line->>'refund_amount')::numeric,line->>'notes');
  end loop;
  perform erp.post_sales_return(return_id);
 elsif p_action='RETURN_REVERSE' then
  return_id:=(p_payload->>'return_id')::uuid;select * into returned from erp.sales_returns where id=return_id;
  if returned.id is null or returned.sale_id<>ident or returned.status<>'POSTED' then raise exception 'CP7_SALES_RETURN_SOURCE_CHANGED';end if;
  perform erp.reverse_sales_return(return_id,btrim(p_payload->>'change_reason'));
 elsif p_action='SALE_REVERSE' then
  perform erp.reverse_sale(ident,btrim(p_payload->>'change_reason'));
  select jsonb_build_object('status',status,'row_version',row_version::text) into r from erp.sales_headers where id=ident;
 elsif p_action='POST' then r:=erp.post_sale_v2(ident,native_request,p_expected::bigint);
 else r:=erp.cancel_sale_draft_v2(ident,btrim(p_payload->>'change_reason'),native_request,p_expected::bigint);end if;
 if cp7_sales.command_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 if p_action in('PAYMENT','PAYMENT_REVERSE') then
  select * into h from erp.sales_headers where id=ident;select * into payment from erp.sales_payments where id=payment_id;
  return jsonb_build_object('sale_id',ident,'status',h.status,'row_version',h.row_version::text,'payment_id',payment.id,'payment_status',payment.status);
 end if;
 if p_action in('RETURN','RETURN_REVERSE') then
  select * into h from erp.sales_headers where id=ident;select * into returned from erp.sales_returns where id=return_id;
  return jsonb_build_object('sale_id',ident,'status',h.status,'row_version',h.row_version::text,'return_id',returned.id,'return_status',returned.status);
 end if;
 return jsonb_build_object('sale_id',ident,'status',r->'status','row_version',r->>'row_version');
end $$;

create function cp7_sales.command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_sales.requests;r jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed' then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_sales.command_access(p_action);
 if p_request is null or (p_action='CREATE' and p_expected is not null) or(p_action<>'CREATE' and(p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$')) then raise exception 'CP7_SALES_COMMAND_FIELDS';end if;
 if p_action in('CREATE','EDIT') then
  perform cp7_sales.validate_draft(p_payload,p_action='EDIT');
 elsif p_action in('PAYMENT','PAYMENT_REVERSE') then
  perform cp7_sales.validate_payment(p_payload,p_action='PAYMENT_REVERSE');
 elsif p_action in('RETURN','RETURN_REVERSE') then
  perform cp7_sales.validate_return(p_payload,p_action='RETURN_REVERSE');
 else
  if jsonb_typeof(p_payload) is distinct from 'object' or not p_payload ?& array['sale_id','review_token','change_reason']
   or exists(select 1 from jsonb_each(p_payload) e where e.key not in('sale_id','review_token','change_reason') or jsonb_typeof(e.value)<>'string')
   or coalesce(p_payload->>'sale_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
   or coalesce(p_payload->>'review_token','')!~'^[a-f0-9]{32}$'
   or length(btrim(p_payload->>'change_reason')) not between 5 and 1000 then raise exception 'CP7_SALES_COMMAND_FIELDS';end if;
 end if;
 insert into cp7_sales.requests values(auth.uid(),p_request,p_action,p_payload,p_expected,null) on conflict do nothing;
 select * into old from cp7_sales.requests where actor=auth.uid() and request_id=p_request for update;
 if old.action<>p_action or old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_SALES_REQUEST_CHANGED';end if;
 if cp7_sales.command_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 insert into cp7_sales.command_context values(pg_backend_pid(),txid_current(),auth.uid(),(p_payload->>'sale_id')::uuid,p_action);
 r:=cp7_sales.apply_command(p_action,p_payload,p_request,p_expected);
 delete from cp7_sales.command_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
 if cp7_sales.command_access(p_action) is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 r:=r||jsonb_build_object('contract_version','cp7.sales-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request);
 update cp7_sales.requests set response=r where actor=auth.uid() and request_id=p_request;
 return r;
end $$;
create function public.erp_cp7_save_sale_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_sales.command(p_action,p_payload,p_request,p_expected)$$;
alter function cp7_sales.command_access(text) owner to cp7_sales_read;
alter function cp7_sales.command_allowed(text) owner to cp7_sales_read;
alter function cp7_sales.apply_command(text,jsonb,uuid,text) owner to postgres;
alter function cp7_sales.command(text,jsonb,uuid,text) owner to cp7_sales_write;
grant create on schema public to cp7_sales_write;
alter function public.erp_cp7_save_sale_v1(text,jsonb,uuid,text) owner to cp7_sales_write;
revoke create on schema public from cp7_sales_write;
revoke all on function cp7_sales.command_access(text),cp7_sales.apply_command(text,jsonb,uuid,text),cp7_sales.command(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
revoke all on function cp7_sales.command_allowed(text) from public,anon,authenticated,service_role,cp7_capture,cp7_sales_write;
grant execute on function cp7_sales.command_access(text),cp7_sales.apply_command(text,jsonb,uuid,text),cp7_sales.validate_draft(jsonb,boolean) to cp7_sales_write;
grant usage on schema cp7_sales to postgres;
grant select on cp7_sales.command_context to postgres;
grant execute on function cp7_sales.command_access(text),cp7_sales.review_token(uuid) to postgres;
grant execute on function cp7_sales.command_allowed(text) to postgres;
revoke all on function public.erp_cp7_save_sale_v1(text,jsonb,uuid,text) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_save_sale_v1(text,jsonb,uuid,text) to authenticated;

-- Complete source selectors for invoice drafts. Availability is a current
-- reference only; native SAVE rechecks real stock and dated transaction rules.
grant select on erp.fg_inventory_balances to cp7_sales_read;
create function cp7_sales.form_options(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare kind text;q text;at_time timestamptz;loc uuid;n integer;off integer;total bigint;rows jsonb;
begin
 if not cp7_sales.access_now() or not(erp.has_permission('sales.invoice.create') or erp.has_permission('sales.invoice.edit_draft')) then raise exception using errcode='42501',message='CP7_SALES_FORM_DENIED';end if;
 if jsonb_typeof(p_query) is distinct from 'object' or not p_query ?& array['kind','physical_at']
  or exists(select 1 from jsonb_object_keys(p_query) k where k not in('kind','q','physical_at','location_id','offset','limit'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('kind','q','physical_at','location_id') and jsonb_typeof(e.value) not in('string','null'))
  or (p_query ? 'limit' and(jsonb_typeof(p_query->'limit')<>'number' or(p_query->>'limit')!~'^[0-9]{1,3}$'))
  or (p_query ? 'offset' and(jsonb_typeof(p_query->'offset')<>'number' or(p_query->>'offset')!~'^[0-9]{1,7}$')) then raise exception 'CP7_SALES_FORM_QUERY';end if;
 kind:=p_query->>'kind';q:=btrim(coalesce(p_query->>'q',''));at_time:=(p_query->>'physical_at')::timestamptz;loc:=(p_query->>'location_id')::uuid;n:=coalesce((p_query->>'limit')::integer,25);off:=coalesce((p_query->>'offset')::integer,0);
 if kind is null or kind not in('CUSTOMER','STOCK') or length(q)>120 or n not between 1 and 100 or off not between 0 and 1000000 or at_time is null or at_time>statement_timestamp() then raise exception 'CP7_SALES_FORM_QUERY';end if;
 if kind='CUSTOMER' then
  with eligible as materialized(select id,customer_code,customer_name from erp.customers where is_active and(q='' or strpos(lower(concat_ws(' ',customer_code,customer_name)),lower(q))>0)),
  sliced as(select * from eligible order by customer_code,id limit n offset off)
  select (select count(*) from eligible),coalesce((select jsonb_agg(jsonb_build_object('id',id,'code',customer_code,'name',customer_name) order by customer_code,id) from sliced),'[]') into total,rows;
 else
  with positions as materialized(
   select p.id as product_id,p.sku as product_sku,p.product_name,erp.bf_commercial_sku_at_v1(p.id,at_time) as commercial_sku,s.size_code,b.brand_name,l.id as location_id,l.location_name,x.cached_qty_pcs as available_qty
   from erp.fg_inventory_balances x join erp.products p on p.id=x.product_id join erp.sizes s on s.id=p.size_id join erp.brands b on b.id=p.brand_id join erp.locations l on l.id=x.location_id
   where x.quality_grade='GRADE_A' and x.cached_qty_pcs>0 and p.is_active and l.is_active and l.location_type='FG_WAREHOUSE' and(loc is null or l.id=loc)),
  eligible as materialized(select * from positions where q='' or strpos(lower(concat_ws(' ',product_sku,commercial_sku,product_name,size_code,brand_name,location_name)),lower(q))>0),
  sliced as(select * from eligible order by commercial_sku,size_code,product_id,location_id limit n offset off)
  select (select count(*) from eligible),coalesce((select jsonb_agg(jsonb_build_object('product_id',product_id,'product_sku',product_sku,'product_name',product_name,'commercial_sku',commercial_sku,'size_code',size_code,'brand_name',brand_name,'location_id',location_id,'location_name',location_name,'available_qty',available_qty::text) order by commercial_sku,size_code,product_id,location_id) from sliced),'[]') into total,rows;
 end if;
 return jsonb_build_object('contract_version','cp7.sales-form-options.v1','kind',kind,'physical_at',at_time,'location_id',loc,'availability_basis','CURRENT_AVAILABLE_NOT_HISTORICAL_STOCK','rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end);
end $$;
create function public.erp_cp7_get_sales_form_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_sales.form_options(p_query)$$;
alter function cp7_sales.form_options(jsonb) owner to cp7_sales_read;
grant create on schema public to cp7_sales_read;
alter function public.erp_cp7_get_sales_form_v1(jsonb) owner to cp7_sales_read;
revoke create on schema public from cp7_sales_read;
revoke all on function cp7_sales.form_options(jsonb),public.erp_cp7_get_sales_form_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture,cp7_sales_write;
grant execute on function public.erp_cp7_get_sales_form_v1(jsonb) to authenticated;

-- Source-bound cash receipt reader and immutable command validation.
-- This increment supports ordinary cash/bank payments only. Opening advances
-- and allocation replacements retain their separate accepted native workflows.
grant select on erp.cash_accounts to cp7_sales_read;

create function cp7_sales.validate_payment(p jsonb,p_reverse boolean) returns void
language plpgsql immutable security invoker set search_path='' as $$
declare k text;allowed text[];
begin
 allowed:=array['sale_id','review_token','change_reason']||case when p_reverse then array['payment_id'] else array['payment_number','payment_date','amount','cash_account_id','payment_method','reference_number','notes'] end;
 if jsonb_typeof(p) is distinct from 'object' or not p ?& allowed or exists(select 1 from jsonb_object_keys(p) x where not x=any(allowed)) then raise exception 'CP7_SALES_PAYMENT_FIELDS';end if;
 foreach k in array allowed loop
  if k in('notes','reference_number') then
   if jsonb_typeof(p->k) not in('string','null') or length(p->>k)>(case when k='notes' then 2000 else 100 end) then raise exception 'CP7_SALES_PAYMENT_FIELDS';end if;
  elsif jsonb_typeof(p->k) is distinct from 'string' then raise exception 'CP7_SALES_PAYMENT_FIELDS';end if;
 end loop;
 if (p->>'sale_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or(p->>'review_token')!~'^[a-f0-9]{32}$' or length(btrim(p->>'change_reason')) not between 5 and 1000 then raise exception 'CP7_SALES_PAYMENT_FIELDS';end if;
 if p_reverse then
  if (p->>'payment_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then raise exception 'CP7_SALES_PAYMENT_FIELDS';end if;
 else
  if length(btrim(p->>'payment_number')) not between 1 and 60
   or(p->>'amount')!~'^(0|[1-9][0-9]{0,17})(\.[0-9]{1,2})?$' or(p->>'amount')::numeric<=0
   or(p->>'cash_account_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
   or(p->>'payment_method') not in('CASH','BANK_TRANSFER')
   or length(p->>'payment_date') not between 20 and 40 or(p->>'payment_date')!~'(Z|[+-][0-9]{2}:[0-9]{2})$' then raise exception 'CP7_SALES_PAYMENT_FIELDS';end if;
 end if;
end $$;

create function cp7_sales.cash_workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare h erp.sales_headers;ident uuid;po integer;pn integer;bo integer;bn integer;q text;payments jsonb;banks jsonb;pt bigint;bt bigint;can_create boolean;
begin
 if not cp7_sales.access_now() or not erp.has_permission('sales.payment.view') then raise exception using errcode='42501',message='CP7_SALES_CASH_DENIED';end if;
 if jsonb_typeof(p_query) is distinct from 'object' or not p_query ? 'sale_id'
  or exists(select 1 from jsonb_object_keys(p_query) x where x not in('sale_id','payment_offset','payment_limit','bank_q','bank_offset','bank_limit'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('sale_id','bank_q') and jsonb_typeof(e.value)<>'string')
  or exists(select 1 from jsonb_each(p_query) e where e.key in('payment_offset','payment_limit','bank_offset','bank_limit') and(jsonb_typeof(e.value)<>'number' or e.value::text!~'^[0-9]{1,7}$')) then raise exception 'CP7_SALES_CASH_QUERY';end if;
 ident:=(p_query->>'sale_id')::uuid;po:=coalesce((p_query->>'payment_offset')::integer,0);pn:=coalesce((p_query->>'payment_limit')::integer,25);bo:=coalesce((p_query->>'bank_offset')::integer,0);bn:=coalesce((p_query->>'bank_limit')::integer,25);q:=btrim(coalesce(p_query->>'bank_q',''));
 if ident is null or po not between 0 and 1000000 or bo not between 0 and 1000000 or pn not between 1 and 100 or bn not between 1 and 100 or length(q)>120 then raise exception 'CP7_SALES_CASH_QUERY';end if;
 select * into h from erp.sales_headers where id=ident;if h.id is null then raise exception 'CP7_SALES_NOT_FOUND';end if;
 select count(*) into pt from erp.sales_payments where sale_id=ident;
 select coalesce(jsonb_agg(jsonb_build_object('id',x.id,'number',x.payment_number,'physical_at',x.payment_date,'amount',x.amount::text,'cash_account_id',x.cash_account_id,'cash_account_name',(select cash_account_name from erp.cash_accounts where id=x.cash_account_id),'method',x.payment_method,'reference',x.reference_number,'notes',x.notes,'status',x.status,'replaces_payment_id',x.replaces_payment_id) order by x.payment_date desc,x.id),'[]') into payments
 from(select * from erp.sales_payments where sale_id=ident order by payment_date desc,id limit pn offset po)x;
 can_create:=erp.has_permission('sales.payment.create') and erp.has_permission('sales.payment.post');
 with eligible as materialized(select id,cash_account_code,cash_account_name,account_kind from erp.cash_accounts where is_active and can_create and(q='' or strpos(lower(concat_ws(' ',cash_account_code,cash_account_name)),lower(q))>0)),
 sliced as(select * from eligible order by cash_account_code,id limit bn offset bo)
 select(select count(*) from eligible),coalesce((select jsonb_agg(jsonb_build_object('id',id,'code',cash_account_code,'name',cash_account_name,'kind',account_kind) order by cash_account_code,id) from sliced),'[]') into bt,banks;
 return jsonb_build_object('contract_version','cp7.sales-cash.v1','sale_id',ident,'row_version',h.row_version::text,'review_token',cp7_sales.review_token(ident),
  'payments',jsonb_build_object('rows',payments,'total',pt::text,'offset',po,'limit',pn,'next_offset',case when po+jsonb_array_length(payments)<pt then po+jsonb_array_length(payments) else null end),
  'cash_accounts',jsonb_build_object('rows',banks,'total',bt::text,'offset',bo,'limit',bn,'next_offset',case when bo+jsonb_array_length(banks)<bt then bo+jsonb_array_length(banks) else null end));
end $$;
create function public.erp_cp7_get_sales_cash_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_sales.cash_workspace(p_query)$$;
alter function cp7_sales.validate_payment(jsonb,boolean) owner to cp7_sales_read;
alter function cp7_sales.cash_workspace(jsonb) owner to cp7_sales_read;
grant create on schema public to cp7_sales_read;
alter function public.erp_cp7_get_sales_cash_v1(jsonb) owner to cp7_sales_read;
revoke create on schema public from cp7_sales_read;
revoke all on function cp7_sales.validate_payment(jsonb,boolean),cp7_sales.cash_workspace(jsonb),public.erp_cp7_get_sales_cash_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture,cp7_sales_write;
grant execute on function cp7_sales.validate_payment(jsonb,boolean) to cp7_sales_write;
grant execute on function public.erp_cp7_get_sales_cash_v1(jsonb) to authenticated;

-- Physical returns choose an original sale allocation. HPP/product/lot identity
-- comes from the native allocation normalizer; callers cannot supply its cost.
grant select on erp.fg_lots to cp7_sales_read;
create function cp7_sales.validate_return(p jsonb,p_reverse boolean) returns void
language plpgsql immutable security invoker set search_path='' as $$
declare allowed text[];x jsonb;k text;
begin
 allowed:=array['sale_id','review_token','change_reason']||case when p_reverse then array['return_id'] else array['return_number','physical_at','notes','items'] end;
 if jsonb_typeof(p) is distinct from 'object' or not p ?& allowed or exists(select 1 from jsonb_object_keys(p) key_name where not key_name=any(allowed)) then raise exception 'CP7_SALES_RETURN_FIELDS';end if;
 foreach k in array allowed loop
  if k='items' then continue;
  elsif k='notes' then
   if jsonb_typeof(p->k) not in('string','null') or length(p->>k)>2000 then raise exception 'CP7_SALES_RETURN_FIELDS';end if;
  elsif jsonb_typeof(p->k) is distinct from 'string' then raise exception 'CP7_SALES_RETURN_FIELDS';end if;
 end loop;
 if (p->>'sale_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or(p->>'review_token')!~'^[a-f0-9]{32}$' or length(btrim(p->>'change_reason')) not between 5 and 1000 then raise exception 'CP7_SALES_RETURN_FIELDS';end if;
 if p_reverse then
  if(p->>'return_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then raise exception 'CP7_SALES_RETURN_FIELDS';end if;
  return;
 end if;
 if length(btrim(p->>'return_number')) not between 1 and 60 or length(p->>'physical_at') not between 20 and 40 or(p->>'physical_at')!~'(Z|[+-][0-9]{2}:[0-9]{2})$'
  or jsonb_typeof(p->'items') is distinct from 'array' then raise exception 'CP7_SALES_RETURN_FIELDS';end if;
 if jsonb_array_length(p->'items') not between 1 and 100 then raise exception 'CP7_SALES_RETURN_LINES';end if;
 for x in select value from jsonb_array_elements(p->'items') loop
  if jsonb_typeof(x) is distinct from 'object' or not x ?& array['allocation_id','location_id','qty_pcs','quality_grade','refund_amount','notes']
   or exists(select 1 from jsonb_each(x) e where e.key not in('allocation_id','location_id','qty_pcs','quality_grade','refund_amount','notes') or(e.key<>'notes' and jsonb_typeof(e.value)<>'string'))
   or jsonb_typeof(x->'notes') not in('string','null') or length(x->>'notes')>2000
   or(x->>'allocation_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
   or(x->>'location_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
   or(x->>'qty_pcs')!~'^[1-9][0-9]{0,8}$' or(x->>'quality_grade') not in('GRADE_A','GRADE_B','HOLD')
   or(x->>'refund_amount')!~'^(0|[1-9][0-9]{0,17})(\.[0-9]{1,2})?$' then raise exception 'CP7_SALES_RETURN_LINES';end if;
 end loop;
 -- Accepted uq_sales_return_item_allocation allows one line per allocation
 -- in a document. Split grade/destination for the same allocation across
 -- explicit return documents; preserve the original unique constraint.
 if exists(select 1 from jsonb_array_elements(p->'items') as return_line(value) group by return_line.value->>'allocation_id' having count(*)>1) then raise exception 'CP7_SALES_RETURN_DUPLICATE_ALLOCATION';end if;
end $$;

create function cp7_sales.return_workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare h erp.sales_headers;ident uuid;kind text;q text;off integer;n integer;total bigint;rows jsonb;
begin
 if not cp7_sales.access_now() or not erp.has_permission('sales.return.view') then raise exception using errcode='42501',message='CP7_SALES_RETURN_DENIED';end if;
 if jsonb_typeof(p_query) is distinct from 'object' or not p_query ?& array['sale_id','kind']
  or exists(select 1 from jsonb_object_keys(p_query) k where k not in('sale_id','kind','q','offset','limit'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('sale_id','kind','q') and jsonb_typeof(e.value)<>'string')
  or exists(select 1 from jsonb_each(p_query) e where e.key in('offset','limit') and(jsonb_typeof(e.value)<>'number' or e.value::text!~'^[0-9]{1,7}$')) then raise exception 'CP7_SALES_RETURN_QUERY';end if;
 ident:=(p_query->>'sale_id')::uuid;kind:=p_query->>'kind';q:=btrim(coalesce(p_query->>'q',''));off:=coalesce((p_query->>'offset')::integer,0);n:=coalesce((p_query->>'limit')::integer,25);
 if ident is null or kind is null or kind not in('ALLOCATIONS','RETURNS','LOCATIONS') or off not between 0 and 1000000 or n not between 1 and 100 or length(q)>120 then raise exception 'CP7_SALES_RETURN_QUERY';end if;
 select * into h from erp.sales_headers where id=ident;if h.id is null then raise exception 'CP7_SALES_NOT_FOUND';end if;
 if kind='ALLOCATIONS' then
  with sources as materialized(
   select a.id,a.sale_item_id,a.lot_id,fl.lot_number,p.id product_id,p.sku product_sku,erp.bf_commercial_sku_at_v1(p.id,h.sale_date) commercial_sku,p.product_name,s.size_code,l.location_name source_location_name,
    a.qty_pcs allocated_qty,coalesce((select sum(ri.qty_pcs) from erp.sales_return_items ri join erp.sales_returns rh on rh.id=ri.return_id where ri.sale_stock_allocation_id=a.id and rh.sale_id=ident and rh.status='POSTED'),0) returned_qty,
    i.qty_pcs sale_item_qty,i.line_total sale_item_net
   from erp.sale_stock_allocations a join erp.sales_items i on i.id=a.sale_item_id join erp.products p on p.id=i.product_id join erp.sizes s on s.id=p.size_id join erp.fg_lots fl on fl.id=a.lot_id join erp.locations l on l.id=a.location_id
   where i.sale_id=ident and h.status in('POSTED','PARTIAL_PAID','PAID')),
  eligible as materialized(select * from sources where allocated_qty>returned_qty and(q='' or strpos(lower(concat_ws(' ',product_sku,commercial_sku,product_name,size_code,lot_number)),lower(q))>0)),
  sliced as(select * from eligible order by sale_item_id,lot_id,id limit n offset off)
  select(select count(*) from eligible),coalesce((select jsonb_agg(jsonb_build_object('allocation_id',id,'sale_item_id',sale_item_id,'product_id',product_id,'product_sku',product_sku,'commercial_sku',commercial_sku,'product_name',product_name,'size_code',size_code,'lot_id',lot_id,'lot_number',lot_number,'source_location_name',source_location_name,'allocated_qty',allocated_qty::text,'returned_qty',returned_qty::text,'remaining_qty',(allocated_qty-returned_qty)::text,'sale_item_qty',sale_item_qty::text,'sale_item_net',round(sale_item_net,2)::text) order by sale_item_id,lot_id,id) from sliced),'[]') into total,rows;
 elsif kind='LOCATIONS' then
  with eligible as materialized(select id,location_name from erp.locations where is_active and location_type='FG_WAREHOUSE' and(q='' or strpos(lower(location_name),lower(q))>0)),
  sliced as(select * from eligible order by location_name,id limit n offset off)
  select(select count(*) from eligible),coalesce((select jsonb_agg(jsonb_build_object('id',id,'name',location_name) order by location_name,id) from sliced),'[]') into total,rows;
 else
  if exists(select 1 from(select id from erp.sales_returns where sale_id=ident and(q='' or strpos(lower(return_number),lower(q))>0) order by physical_at desc,id limit n offset off)x where(select count(*) from erp.sales_return_items i where i.return_id=x.id)>100) then raise exception 'CP7_SALES_RETURN_DOCUMENT_TOO_LARGE';end if;
  select count(*) into total from erp.sales_returns where sale_id=ident and(q='' or strpos(lower(return_number),lower(q))>0);
  select coalesce(jsonb_agg(jsonb_build_object('id',x.id,'number',x.return_number,'physical_at',x.physical_at,'status',x.status,'notes',x.notes,'line_count',(select count(*)::text from erp.sales_return_items i where i.return_id=x.id),'items',
   (select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'allocation_id',i.sale_stock_allocation_id,'product_sku',p.sku,'lot_number',fl.lot_number,'location_id',i.location_id,'location_name',l.location_name,'qty_pcs',i.qty_pcs::text,'quality_grade',i.quality_grade,'refund_amount',i.refund_amount::text,'notes',i.notes) order by i.id),'[]') from erp.sales_return_items i join erp.products p on p.id=i.product_id join erp.fg_lots fl on fl.id=i.lot_id join erp.locations l on l.id=i.location_id where i.return_id=x.id)) order by x.physical_at desc,x.id),'[]') into rows
  from(select * from erp.sales_returns where sale_id=ident and(q='' or strpos(lower(return_number),lower(q))>0) order by physical_at desc,id limit n offset off)x;
 end if;
 return jsonb_build_object('contract_version','cp7.sales-returns.v1','kind',kind,'sale_id',ident,'row_version',h.row_version::text,'review_token',cp7_sales.review_token(ident),'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end));
end $$;
create function public.erp_cp7_get_sales_returns_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_sales.return_workspace(p_query)$$;
alter function cp7_sales.validate_return(jsonb,boolean) owner to cp7_sales_read;
alter function cp7_sales.return_workspace(jsonb) owner to cp7_sales_read;
grant create on schema public to cp7_sales_read;
alter function public.erp_cp7_get_sales_returns_v1(jsonb) owner to cp7_sales_read;
revoke create on schema public from cp7_sales_read;
revoke all on function cp7_sales.validate_return(jsonb,boolean),cp7_sales.return_workspace(jsonb),public.erp_cp7_get_sales_returns_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture,cp7_sales_write;
grant execute on function cp7_sales.validate_return(jsonb,boolean) to cp7_sales_write;
grant execute on function public.erp_cp7_get_sales_returns_v1(jsonb) to authenticated;

-- An ordinary payment is corrected by one Native inverse and one Native post
-- in the same transaction. Native allocation-replacement and advance lineage
-- keep their separate meaning; no posted payment field is overwritten.
create schema cp7_payment_correction authorization cp7_sales_read;
revoke all on schema cp7_payment_correction from public,anon,authenticated,service_role,cp7_capture;
grant usage,create on schema cp7_payment_correction to cp7_sales_write;
grant usage on schema cp7_payment_correction to postgres;
create table cp7_payment_correction.requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,
 expected_version text not null,response jsonb,primary key(actor,request_id)
);
create table cp7_payment_correction.context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 request_id uuid not null,payload jsonb not null,expected_version text not null,
 primary key(backend_pid,transaction_id)
);
create table cp7_payment_correction.links(
 original_id uuid primary key references erp.sales_payments(id),
 replacement_id uuid not null unique references erp.sales_payments(id),
 sale_id uuid not null references erp.sales_headers(id),actor uuid not null,
 request_id uuid not null,reason text not null,
 time_neutral_id uuid references erp.journal_entries(id),
 effective_inverse_id uuid references erp.journal_entries(id),
 recorded_at timestamptz not null default statement_timestamp(),
 check(original_id<>replacement_id),check(length(btrim(reason))between 5 and 1000),
 check((time_neutral_id is null)=(effective_inverse_id is null)),unique(actor,request_id)
);
alter table cp7_payment_correction.requests owner to cp7_sales_write;
alter table cp7_payment_correction.context owner to cp7_sales_write;
alter table cp7_payment_correction.links owner to cp7_sales_write;
alter table cp7_payment_correction.requests enable row level security;
alter table cp7_payment_correction.context enable row level security;
alter table cp7_payment_correction.links enable row level security;
create policy payment_correction_requests_deny on cp7_payment_correction.requests for all to public using(false)with check(false);
create policy payment_correction_context_deny on cp7_payment_correction.context for all to public using(false)with check(false);
create policy payment_correction_links_deny on cp7_payment_correction.links for all to public using(false)with check(false);
revoke all on all tables in schema cp7_payment_correction from public,anon,authenticated,service_role,cp7_capture;
grant select on cp7_payment_correction.context,cp7_payment_correction.links to postgres;

create function cp7_payment_correction.access_now()returns jsonb
language plpgsql stable security invoker set search_path=''as $$
declare a jsonb;
begin
 a:=cp7_sales.command_access('PAYMENT');
 if cp7_sales.command_access('PAYMENT_REVERSE')is distinct from a then
  raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 return a;
end $$;

create function cp7_payment_correction.validate(p jsonb)returns void
language plpgsql immutable security invoker set search_path=''as $$
begin
 if jsonb_typeof(p)is distinct from'object'or not(p?&array['sale_id','payment_id','review_token','replacement','change_reason'])
  or(select count(*)from jsonb_object_keys(p))<>5 then raise exception 'CP7_PAYMENT_CORRECTION_FIELDS';end if;
 perform cp7_sales.validate_payment(p-'replacement',true);
 if jsonb_typeof(p->'replacement')is distinct from'object'
  or not(p->'replacement'?&array['payment_number','payment_date','amount','cash_account_id','payment_method','reference_number','notes'])
  or(select count(*)from jsonb_object_keys(p->'replacement'))<>7 then raise exception 'CP7_PAYMENT_CORRECTION_FIELDS';end if;
 perform cp7_sales.validate_payment((p-'replacement'-'payment_id')||(p->'replacement'),false);
end $$;

create function cp7_payment_correction.document(p erp.sales_payments)returns jsonb
language sql stable security invoker set search_path=''set TimeZone='UTC'as $$
 select jsonb_build_object('id',p.id,'number',p.payment_number,'physical_at',p.payment_date,
  'amount',p.amount::text,'cash_account_id',p.cash_account_id,
  'cash_account_name',(select cash_account_name from erp.cash_accounts where id=p.cash_account_id),
  'method',p.payment_method,'reference',p.reference_number,'notes',p.notes,
  'status',p.status,'replaces_payment_id',p.replaces_payment_id)
$$;
create function cp7_payment_correction.link_value(p cp7_payment_correction.links)returns jsonb
language sql stable security definer set search_path=''set TimeZone='UTC'as $$
 select jsonb_build_object('original_id',p.original_id,'replacement_id',p.replacement_id,
  'sale_id',p.sale_id,'actor_scope_id',p.actor,'request_id',p.request_id,'reason',p.reason,
  'recorded_at',p.recorded_at,'time_restatement',case when p.time_neutral_id is null then null else(
   select jsonb_build_object('neutral_journal_id',n.id,'neutral_number',n.journal_number,
    'neutral_economic_date',n.economic_date,'neutral_transaction_date',n.transaction_date,
    'effective_journal_id',e.id,'effective_number',e.journal_number,
    'effective_economic_date',e.economic_date,'effective_transaction_date',e.transaction_date)
   from erp.journal_entries n join erp.journal_entries e on e.id=p.effective_inverse_id
   where n.id=p.time_neutral_id)end)
$$;

-- The public reader delegates only this guarded, source-bound read to the
-- existing non-superuser Native owner. No new ERP table grant is needed.
create function cp7_payment_correction.workspace(p_query jsonb)returns jsonb
language plpgsql stable security definer set search_path=''set TimeZone='UTC'as $$
declare original erp.sales_payments;h erp.sales_headers;cash jsonb;previous jsonb:='null';following jsonb:='null';
 prev cp7_payment_correction.links;nxt cp7_payment_correction.links;eligible boolean;a jsonb;
begin
 if not cp7_sales.access_now()or not erp.has_permission('sales.payment.view')then
  raise exception using errcode='42501',message='CP7_SALES_CASH_DENIED';end if;
 a:=erp.get_my_access_v1();
 if jsonb_typeof(p_query)is distinct from'object'or not(p_query?&array['sale_id','payment_id'])
  or exists(select 1 from jsonb_object_keys(p_query)x where x not in('sale_id','payment_id','bank_q','bank_offset','bank_limit'))
  or jsonb_typeof(p_query->'sale_id')is distinct from'string'or jsonb_typeof(p_query->'payment_id')is distinct from'string'
  or coalesce(p_query->>'sale_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p_query->>'payment_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'then
  raise exception 'CP7_PAYMENT_CORRECTION_QUERY';end if;
 cash:=cp7_sales.cash_workspace((p_query-'payment_id')||jsonb_build_object('payment_limit',1));
 select *into original from erp.sales_payments where id=(p_query->>'payment_id')::uuid and sale_id=(p_query->>'sale_id')::uuid;
 if original.id is null then raise exception 'CP7_SALES_PAYMENT_SOURCE_CHANGED';end if;
 select *into strict h from erp.sales_headers where id=original.sale_id;
 eligible:=original.status='POSTED'and h.status in('POSTED','PARTIAL_PAID','PAID')
  and length(btrim(original.payment_number))between 1 and 60
  and original.cash_account_id is not null and original.replaces_payment_id is null
  and original.payment_method in('CASH','BANK_TRANSFER')
  and not exists(select 1 from erp.initial_import_prepayment_payments where sales_payment_id=original.id)
  and not exists(select 1 from cp7_payment_correction.links where original_id=original.id);
 select *into prev from cp7_payment_correction.links where replacement_id=original.id and sale_id=h.id;
 select *into nxt from cp7_payment_correction.links where original_id=original.id and sale_id=h.id;
 if prev.original_id is not null then previous:=jsonb_build_object('link',cp7_payment_correction.link_value(prev),
  'document',(select cp7_payment_correction.document(p)from erp.sales_payments p where id=prev.original_id and sale_id=h.id));end if;
 if nxt.original_id is not null then following:=jsonb_build_object('link',cp7_payment_correction.link_value(nxt),
  'document',(select cp7_payment_correction.document(p)from erp.sales_payments p where id=nxt.replacement_id and sale_id=h.id));end if;
 if erp.get_my_access_v1()is distinct from a or not cp7_sales.access_now()or not erp.has_permission('sales.payment.view')then
  raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.sales-payment-correction-workspace.v1',
  'captured_at',statement_timestamp(),'sale_id',h.id,'row_version',h.row_version::text,
  'review_token',cp7_sales.review_token(h.id),'document',cp7_payment_correction.document(original),
  'eligible',coalesce(eligible,false),'previous',previous,'next',following,'cash_accounts',cash->'cash_accounts');
end $$;

create function cp7_payment_correction.protect_link()returns trigger
language plpgsql volatile security definer set search_path=''as $$
begin
 if tg_op<>'INSERT'then raise exception 'CP7_PAYMENT_CORRECTION_LINK_IMMUTABLE';end if;
 if not exists(select 1 from cp7_payment_correction.context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current()and c.actor=auth.uid()and c.actor=new.actor
  and c.request_id=new.request_id and c.payload->>'sale_id'=new.sale_id::text
  and c.payload->>'payment_id'=new.original_id::text and btrim(c.payload->>'change_reason')=new.reason)
  or not exists(select 1 from erp.sales_payments where id=new.original_id and sale_id=new.sale_id and status='REVERSED')
  or not exists(select 1 from erp.sales_payments where id=new.replacement_id and sale_id=new.sale_id and status='POSTED'and replaces_payment_id is null)then
  raise exception using errcode='42501',message='CP7_PAYMENT_CORRECTION_PRIVATE_CONTEXT_REQUIRED';end if;
 if new.time_neutral_id is not null and(not exists(select 1 from erp.journal_entries where id=new.time_neutral_id and source_type='PAYMENT_CORRECTION_TIME_NEUTRAL'and source_id=new.original_id and status='POSTED')
  or not exists(select 1 from erp.journal_entries where id=new.effective_inverse_id and source_type='PAYMENT_CORRECTION_EFFECTIVE'and source_id=new.original_id and status='POSTED'))then
  raise exception 'CP7_PAYMENT_CORRECTION_JOURNAL_SOURCE_CHANGED';end if;
 return new;
end $$;
create trigger payment_correction_link_immutable before insert or update or delete on cp7_payment_correction.links
 for each row execute function cp7_payment_correction.protect_link();
create trigger payment_correction_link_no_truncate before truncate on cp7_payment_correction.links
 for each statement execute function cp7_payment_correction.protect_link();

create function cp7_payment_correction.apply(p jsonb,p_request uuid,p_expected text)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;original erp.sales_payments;h erp.sales_headers;intent jsonb;posted jsonb;link cp7_payment_correction.links;
 original_journal erp.journal_entries;inverse_journal erp.journal_entries;lines jsonb;neutral uuid;effective uuid;
begin
 a:=cp7_payment_correction.access_now();perform cp7_payment_correction.validate(p);
 if not exists(select 1 from cp7_payment_correction.context where backend_pid=pg_backend_pid()and transaction_id=txid_current()
  and actor=auth.uid()and request_id=p_request and payload=p and expected_version=p_expected)
  or exists(select 1 from cp7_sales.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current())then
  raise exception using errcode='42501',message='CP7_PAYMENT_CORRECTION_PRIVATE_CONTEXT_REQUIRED';end if;
 perform pg_advisory_xact_lock(hashtextextended('FG_HPP_SALES_V2620C',0));
 perform 1 from erp.sales_payments where sale_id=(p->>'sale_id')::uuid order by id for update;
 select *into h from erp.sales_headers where id=(p->>'sale_id')::uuid for update;
 select *into original from erp.sales_payments where id=(p->>'payment_id')::uuid;
 if h.id is null or original.id is null or original.sale_id<>h.id then raise exception 'CP7_SALES_PAYMENT_SOURCE_CHANGED';end if;
 if cp7_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 if h.row_version::text is distinct from p_expected or cp7_sales.review_token(h.id)is distinct from p->>'review_token'then raise exception 'CP7_SALES_REVIEW_CHANGED';end if;
 if original.status<>'POSTED'or h.status not in('POSTED','PARTIAL_PAID','PAID')or original.cash_account_id is null
  or original.replaces_payment_id is not null or original.payment_method is null or original.payment_method not in('CASH','BANK_TRANSFER')
  or exists(select 1 from erp.initial_import_prepayment_payments where sales_payment_id=original.id)
  or exists(select 1 from cp7_payment_correction.links where original_id=original.id)then raise exception 'CP7_PAYMENT_CORRECTION_ORDINARY_ONLY';end if;
 if p->'replacement'->>'payment_number'is distinct from original.payment_number then raise exception 'CP7_PAYMENT_CORRECTION_NUMBER';end if;
 lock table erp.accounting_account_mappings in share mode;
 perform 1 from erp.cash_accounts where id in(original.cash_account_id,(p->'replacement'->>'cash_account_id')::uuid)order by id for share;
 perform 1 from erp.chart_accounts where id in(
  select coa_account_id from erp.cash_accounts where id in(original.cash_account_id,(p->'replacement'->>'cash_account_id')::uuid)
  union select account_id from erp.accounting_account_mappings where mapping_key='AR_CUSTOMER')order by id for share;
 if (p->'replacement'->>'amount')::numeric=original.amount
  and(p->'replacement'->>'payment_date')::timestamptz=original.payment_date
  and(p->'replacement'->>'cash_account_id')::uuid=original.cash_account_id
  and p->'replacement'->>'payment_method'is not distinct from original.payment_method
  and p->'replacement'->>'reference_number'is not distinct from original.reference_number
  and p->'replacement'->>'notes'is not distinct from original.notes then raise exception 'CP7_PAYMENT_CORRECTION_UNCHANGED';end if;
 -- Reuse both owning actions without extending their Native guard admission.
 -- The original review is checked again by the inverse; the replacement gets
 -- the real post-inverse revision/token. No client guesses the next version.
 intent:=p-'replacement';
 insert into cp7_sales.command_context values(pg_backend_pid(),txid_current(),auth.uid(),h.id,'PAYMENT_REVERSE');
 perform cp7_sales.apply_command('PAYMENT_REVERSE',intent,p_request,p_expected);
 select *into strict original_journal from erp.journal_entries where source_type='SALES_PAYMENT'and source_id=original.id and reversal_of_id is null;
 select *into strict inverse_journal from erp.journal_entries where reversal_of_id=original_journal.id and source_type='JOURNAL_REVERSAL'and source_id=original_journal.id;
 if original_journal.status<>'REVERSED'or inverse_journal.status<>'POSTED'then raise exception 'CP7_PAYMENT_CORRECTION_JOURNAL_SOURCE_CHANGED';end if;
 if original_journal.economic_date<>inverse_journal.economic_date then
  select jsonb_agg(jsonb_build_object('account_id',l.account_id,'debit',l.credit,'credit',l.debit,'description',l.description,
   'customer_id',l.customer_id,'vendor_id',l.vendor_id,'contractor_id',l.contractor_id,'po_id',l.po_id,'product_id',l.product_id)order by l.id)into lines
   from erp.journal_lines l where l.journal_entry_id=inverse_journal.id;
  neutral:=erp.post_journal('PAYMENT_CORRECTION_TIME_NEUTRAL',original.id,inverse_journal.economic_date,'Koreksi pembayaran: pindahkan waktu ekonomi pembalikan | '||btrim(p->>'change_reason'),lines);
  select jsonb_agg(jsonb_build_object('account_id',l.account_id,'debit',l.debit,'credit',l.credit,'description',l.description,
   'customer_id',l.customer_id,'vendor_id',l.vendor_id,'contractor_id',l.contractor_id,'po_id',l.po_id,'product_id',l.product_id)order by l.id)into lines
   from erp.journal_lines l where l.journal_entry_id=inverse_journal.id;
  effective:=erp.post_journal('PAYMENT_CORRECTION_EFFECTIVE',original.id,original_journal.economic_date,'Koreksi pembayaran: waktu ekonomi kejadian asal | '||btrim(p->>'change_reason'),lines);
 end if;
 delete from cp7_sales.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 select *into strict h from erp.sales_headers where id=h.id;
 intent:=(p-'replacement'-'payment_id')||(p->'replacement')||jsonb_build_object(
  'review_token',cp7_sales.review_token(h.id),'payment_number',left(original.payment_number,20)||' · K-'||replace(p_request::text,'-',''));
 insert into cp7_sales.command_context values(pg_backend_pid(),txid_current(),auth.uid(),h.id,'PAYMENT');
 posted:=cp7_sales.apply_command('PAYMENT',intent,p_request,h.row_version::text);
 delete from cp7_sales.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 insert into cp7_payment_correction.links(original_id,replacement_id,sale_id,actor,request_id,reason,time_neutral_id,effective_inverse_id)
  values(original.id,(posted->>'payment_id')::uuid,h.id,auth.uid(),p_request,btrim(p->>'change_reason'),neutral,effective)returning *into link;
 return posted||jsonb_build_object('original_payment_id',original.id,'original_payment_status','REVERSED','link',cp7_payment_correction.link_value(link));
end $$;

create function cp7_payment_correction.command(p jsonb,p_request uuid,p_expected text)returns jsonb
language plpgsql volatile security invoker set search_path=''as $$
declare a jsonb;saved cp7_payment_correction.requests;r jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_payment_correction.access_now();perform cp7_payment_correction.validate(p);
 if p_request is null or p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'then raise exception 'CP7_SALES_COMMAND_FIELDS';end if;
 insert into cp7_payment_correction.requests values(auth.uid(),p_request,p,p_expected,null)on conflict do nothing;
 select *into saved from cp7_payment_correction.requests where actor=auth.uid()and request_id=p_request for update;
 if cp7_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 if saved.payload is distinct from p or saved.expected_version is distinct from p_expected then raise exception 'CP7_SALES_REQUEST_CHANGED';end if;
 if saved.response is not null then return saved.response;end if;
 insert into cp7_payment_correction.context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,p,p_expected);
 r:=cp7_payment_correction.apply(p,p_request,p_expected);
 delete from cp7_payment_correction.context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_payment_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 r:=r||jsonb_build_object('contract_version','cp7.sales-payment-correction.v1','kind','COMMITTED_OUTCOME','action','PAYMENT_CORRECT','request_id',p_request);
 update cp7_payment_correction.requests set response=r where actor=auth.uid()and request_id=p_request;return r;
end $$;

alter function cp7_payment_correction.access_now()owner to cp7_sales_read;
alter function cp7_payment_correction.validate(jsonb)owner to cp7_sales_read;
alter function cp7_payment_correction.document(erp.sales_payments)owner to cp7_sales_read;
alter function cp7_payment_correction.link_value(cp7_payment_correction.links)owner to postgres;
alter function cp7_payment_correction.workspace(jsonb)owner to postgres;
alter function cp7_payment_correction.protect_link()owner to postgres;
alter function cp7_payment_correction.apply(jsonb,uuid,text)owner to postgres;
alter function cp7_payment_correction.command(jsonb,uuid,text)owner to cp7_sales_write;
revoke all on all functions in schema cp7_payment_correction from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_payment_correction.access_now(),cp7_payment_correction.validate(jsonb),cp7_payment_correction.apply(jsonb,uuid,text)to cp7_sales_write;
grant execute on function cp7_payment_correction.access_now(),cp7_payment_correction.validate(jsonb),cp7_payment_correction.document(erp.sales_payments),cp7_payment_correction.link_value(cp7_payment_correction.links)to postgres;
grant execute on function cp7_sales.validate_payment(jsonb,boolean),cp7_sales.access_now(),cp7_sales.cash_workspace(jsonb)to postgres;
grant insert,delete on cp7_sales.command_context to postgres;
grant insert on cp7_payment_correction.links to postgres;
grant execute on function cp7_payment_correction.link_value(cp7_payment_correction.links)to cp7_sales_write;
grant execute on function cp7_payment_correction.workspace(jsonb)to cp7_sales_read;
revoke create on schema cp7_payment_correction from cp7_sales_write;
grant create on schema public to cp7_sales_write;
create function public.erp_cp7_correct_sales_payment_v1(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_payment_correction.command(p_payload,p_request,p_expected)$$;
alter function public.erp_cp7_correct_sales_payment_v1(jsonb,uuid,text)owner to cp7_sales_write;
revoke create on schema public from cp7_sales_write;
grant create on schema public to cp7_sales_read;
create function public.erp_cp7_get_sales_payment_correction_v1(p_query jsonb)returns jsonb
language sql stable security definer set search_path=''as $$select cp7_payment_correction.workspace(p_query)$$;
alter function public.erp_cp7_get_sales_payment_correction_v1(jsonb)owner to cp7_sales_read;
revoke create on schema public from cp7_sales_read;
revoke all on function public.erp_cp7_correct_sales_payment_v1(jsonb,uuid,text),public.erp_cp7_get_sales_payment_correction_v1(jsonb)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_correct_sales_payment_v1(jsonb,uuid,text),public.erp_cp7_get_sales_payment_correction_v1(jsonb)to authenticated;

do $patch$ declare old_definition text;begin
 if(select encode(extensions.digest(prosrc,'sha256'),'hex') from pg_proc where oid='erp.require_internal()'::regprocedure)<>'62941848e0f822d721051aacc39eeee82f74ef84d8313d015b10618f43ce3f61' then raise exception 'CP7_SALES_ADMISSION_PREDECESSOR_CHANGED';end if;
 old_definition:=pg_get_functiondef('erp.require_internal()'::regprocedure);
 execute replace(replace(old_definition,$early_anchor$ if v_jwt_role='service_role' then return;end if;$early_anchor$,$early_delta$ if v_jwt_role='service_role' then return;end if;
 if exists(select 1 from cp7_sales.command_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
   and c.action in('CREATE','EDIT','POST','CANCEL','PAYMENT','PAYMENT_REVERSE','RETURN','RETURN_REVERSE','SALE_REVERSE')
   and not exists(select 1 from erp.cutting_bridge_execution_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current() union all select 1 from erp.bs_resolution_execution_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current() union all select 1 from erp.cp6_laundry_qc_execution_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current() union all select 1 from cp7_procurement.execution_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current() union all select 1 from cp7_material.execution_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current() union all select 1 from cp7_supplier_return.execution_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current() union all select 1 from cp7_payroll.execution_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current() union all select 1 from cp7_payroll.settlement_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current() union all select 1 from cp7_attendance.command_context before_sales where before_sales.backend_pid=pg_backend_pid() and before_sales.transaction_id=txid_current())
   then cp7_sales.command_allowed(c.action) else false end) then return;end if;
$early_delta$),$anchor$ v_app_role:=erp.current_app_role();$anchor$,$delta$ if exists(select 1 from cp7_sales.command_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current() and case when c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current() and c.actor=auth.uid() and v_jwt_role='authenticated'
   and c.action in('CREATE','EDIT','POST','CANCEL','PAYMENT','PAYMENT_REVERSE','RETURN','RETURN_REVERSE','SALE_REVERSE')
   then cp7_sales.command_allowed(c.action) else false end) then return;end if;
 v_app_role:=erp.current_app_role();$delta$);
end $patch$;
-- P13 source reader: accepted owner report, dated readiness and immutable filings.
-- It cannot close, reopen, recost or post a financial document.
create role cp7_finance_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_finance authorization cp7_finance_read;
revoke all on schema cp7_finance from public,anon,authenticated,service_role,cp7_capture;
grant usage on schema erp,auth to cp7_finance_read;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text),erp.get_owner_financial_snapshot_v2(date,date,date),erp.accounting_close_preflight_v1(date) to cp7_finance_read;
grant select on erp.accounting_close_filings_v1 to cp7_finance_read;

create function cp7_finance.access_now() returns void
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_FINANCE_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission('finance.reports.view') then raise exception using errcode='42501',message='CP7_FINANCE_ACCESS_DENIED';end if;
 -- Preserve the accepted owner report's native role boundary. This reader does
 -- not silently broaden it to a custom role or modify either native guard.
 if coalesce(a->'profile'->>'role_code','') not in('OWNER','ADMIN') then raise exception using errcode='42501',message='CP7_FINANCE_OWNER_ADMIN_REQUIRED';end if;
end $$;

create function cp7_finance.exact_numbers(p jsonb) returns jsonb
language plpgsql immutable security invoker set search_path='' as $$
declare r jsonb;
begin
 case jsonb_typeof(p)
 when 'number' then return to_jsonb(p::text);
 when 'object' then select coalesce(jsonb_object_agg(k,cp7_finance.exact_numbers(v)),'{}') into r from jsonb_each(p) e(k,v);return r;
 when 'array' then select coalesce(jsonb_agg(cp7_finance.exact_numbers(v) order by n),'[]') into r from jsonb_array_elements(p) with ordinality e(v,n);return r;
 else return p;
 end case;
end $$;

create function cp7_finance.workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' set TimeZone='UTC' set jit=off as $$
declare from_day date;to_day date;as_of date;chosen uuid;off integer;n integer;total bigint;rows jsonb;f erp.accounting_close_filings_v1;detail jsonb:=null;snapshot jsonb;preflight jsonb:=null;
begin
 perform cp7_finance.access_now();
 if jsonb_typeof(p_query) is distinct from 'object' or not p_query ?& array['from','to','as_of']
  or exists(select 1 from jsonb_object_keys(p_query) k where k not in('from','to','as_of','filing_id','offset','limit'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('from','to','as_of') and(jsonb_typeof(e.value)<>'string' or (e.value#>>'{}')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'))
  or(p_query ? 'filing_id' and jsonb_typeof(p_query->'filing_id') not in('string','null'))
  or exists(select 1 from jsonb_each(p_query) e where e.key in('offset','limit') and(jsonb_typeof(e.value)<>'number' or e.value::text!~'^[0-9]{1,7}$')) then raise exception 'CP7_FINANCE_QUERY';end if;
 from_day:=(p_query->>'from')::date;to_day:=(p_query->>'to')::date;as_of:=(p_query->>'as_of')::date;chosen:=(p_query->>'filing_id')::uuid;off:=coalesce((p_query->>'offset')::integer,0);n:=coalesce((p_query->>'limit')::integer,25);
 if from_day is null or to_day is null or as_of is null or from_day>to_day or to_day>as_of or as_of>(statement_timestamp() at time zone 'Asia/Jakarta')::date or off not between 0 and 1000000 or n not between 1 and 100 then raise exception 'CP7_FINANCE_QUERY';end if;
 snapshot:=erp.get_owner_financial_snapshot_v2(from_day,to_day,as_of);
 -- Bound the complete native payload; never truncate blockers into a false READY.
 if snapshot is null or jsonb_typeof(snapshot) is distinct from 'object' or octet_length(snapshot::text)>1000000 then raise exception 'CP7_FINANCE_REPORT_INCOMPLETE';end if;
 if erp.has_permission('finance.period_close.manage') then preflight:=erp.accounting_close_preflight_v1(as_of);end if;
 select count(*) into total from erp.accounting_close_filings_v1;
 select coalesce(jsonb_agg(jsonb_build_object('id',x.id,'closed_through',x.closed_through,'previous_closed_through',x.previous_closed_through,'filed_at',x.filed_at,'reason',x.reason,'filed_status',x.readiness->>'status') order by x.filed_at desc,x.id),'[]') into rows
 from(select * from erp.accounting_close_filings_v1 order by filed_at desc,id limit n offset off)x;
 if chosen is not null then
  select * into f from erp.accounting_close_filings_v1 where id=chosen;
  if f.id is null then raise exception 'CP7_FINANCE_FILING_NOT_FOUND';end if;
  if f.closed_through<>as_of then raise exception 'CP7_FINANCE_FILING_DATE_MISMATCH';end if;
  if octet_length(f.gl_balances::text)+octet_length(f.readiness::text)>1000000 then raise exception 'CP7_FINANCE_FILING_INCOMPLETE';end if;
  detail:=jsonb_build_object('id',f.id,'closed_through',f.closed_through,'previous_closed_through',f.previous_closed_through,'filed_at',f.filed_at,'reason',f.reason,'basis','IMMUTABLE_AS_FILED_GL_BALANCES','readiness',cp7_finance.exact_numbers(f.readiness),'gl_balances',cp7_finance.exact_numbers(f.gl_balances),'source_hash',md5(to_jsonb(f)::text));
 end if;
 return jsonb_build_object('contract_version','cp7.finance-report.v1','captured_at',statement_timestamp(),'knowledge_basis','CURRENT_RECORDED_KNOWLEDGE','historical_knowledge','NOT_RECONSTRUCTED','snapshot',cp7_finance.exact_numbers(snapshot),'close_preflight',cp7_finance.exact_numbers(preflight),'filings',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows) else null end),'filing',detail);
end $$;
create function public.erp_cp7_get_finance_report_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_finance.workspace(p_query)$$;
alter function cp7_finance.access_now() owner to cp7_finance_read;
alter function cp7_finance.exact_numbers(jsonb) owner to cp7_finance_read;
alter function cp7_finance.workspace(jsonb) owner to cp7_finance_read;
grant create on schema public to cp7_finance_read;
alter function public.erp_cp7_get_finance_report_v1(jsonb) owner to cp7_finance_read;
revoke create on schema public from cp7_finance_read;
revoke all on function cp7_finance.access_now(),cp7_finance.exact_numbers(jsonb),cp7_finance.workspace(jsonb),public.erp_cp7_get_finance_report_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_finance_report_v1(jsonb) to authenticated;

-- Recorded-period comparison and cash ledger projection. No financial writes.
grant select on erp.cash_accounts,erp.account_daily_balances,erp.journal_entries,erp.journal_lines to cp7_finance_read;
grant execute on function erp.account_id(text) to cp7_finance_read;

create function cp7_finance.analysis(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' set TimeZone='UTC' set jit=off as $$
declare f date;t date;a date;bf date;bt date;off integer;n integer;current_report jsonb;baseline_report jsonb;
 current_perf jsonb;baseline_perf jsonb;revenue numeric;baseline_revenue numeric;growth numeric; margin_delta numeric;
 cash_ids uuid[];opening numeric;closing numeric;debits numeric;credits numeric;total bigint;rows jsonb;
begin
 perform cp7_finance.access_now();
 if jsonb_typeof(p_query) is distinct from 'object' or not p_query ?& array['from','to','as_of','compare_from','compare_to']
  or exists(select 1 from jsonb_object_keys(p_query)k where k not in('from','to','as_of','compare_from','compare_to','offset','limit'))
  or exists(select 1 from jsonb_each(p_query)e where e.key in('from','to','as_of','compare_from','compare_to') and(jsonb_typeof(e.value)<>'string' or(e.value#>>'{}')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'))
  or exists(select 1 from jsonb_each(p_query)e where e.key in('offset','limit') and(jsonb_typeof(e.value)<>'number' or e.value::text!~'^[0-9]{1,7}$')) then raise exception 'CP7_FINANCE_ANALYSIS_QUERY';end if;
 f:=(p_query->>'from')::date;t:=(p_query->>'to')::date;a:=(p_query->>'as_of')::date;bf:=(p_query->>'compare_from')::date;bt:=(p_query->>'compare_to')::date;
 off:=coalesce((p_query->>'offset')::integer,0);n:=coalesce((p_query->>'limit')::integer,25);
 if f>t or t>a or bf>bt or bt>=f or a>(statement_timestamp() at time zone 'Asia/Jakarta')::date or off not between 0 and 1000000 or n not between 1 and 100 then raise exception 'CP7_FINANCE_ANALYSIS_QUERY';end if;
 -- Both native reports and the ledger below share this stable statement's
 -- snapshot. Baseline readiness belongs to its own cutoff, not today's one.
 current_report:=erp.get_owner_financial_snapshot_v2(f,t,a);
 baseline_report:=erp.get_owner_financial_snapshot_v2(bf,bt,bt);
 if current_report is null or baseline_report is null or octet_length(current_report::text)+octet_length(baseline_report::text)>2000000 then raise exception 'CP7_FINANCE_REPORT_INCOMPLETE';end if;
 current_perf:=current_report->'performance';baseline_perf:=baseline_report->'performance';
 revenue:=(current_perf->>'sales_revenue_gl')::numeric;baseline_revenue:=(baseline_perf->>'sales_revenue_gl')::numeric;
 -- Growth needs a positive base: a net-negative baseline (returns above sales)
 -- would invert the sign. Margin points need positive revenue on both sides.
 growth:=case when baseline_revenue>0 then round((revenue-baseline_revenue)/baseline_revenue*100,4)end;
 -- Aggregate original operands, not rounded row margins or averaged ratios.
 margin_delta:=case when revenue>0 and baseline_revenue>0 then round(((current_perf->>'gross_profit')::numeric/revenue-(baseline_perf->>'gross_profit')::numeric/baseline_revenue)*100,4)end;
 select array_agg(x.id order by x.id) into cash_ids from(select coa_account_id id from erp.cash_accounts union select erp.account_id('CASH'))x;
 select coalesce(sum(b.debit_total-b.credit_total)filter(where b.balance_date<f),0),coalesce(sum(b.debit_total-b.credit_total),0)
 into opening,closing from erp.account_daily_balances b where b.account_id=any(cash_ids) and b.balance_date<=t;
 select coalesce(sum(l.debit),0),coalesce(sum(l.credit),0),count(distinct j.id)
 into debits,credits,total from erp.journal_entries j join erp.journal_lines l on l.journal_entry_id=j.id
 where j.status in('POSTED','REVERSED') and j.transaction_date between f and t and l.account_id=any(cash_ids);
 select coalesce(jsonb_agg(to_jsonb(x) order by x.transaction_date,x.posting_at,x.id),'[]') into rows from(
  select j.id,j.journal_number,j.source_type,j.source_id,j.reversal_of_id,j.status,j.economic_date,j.transaction_date,j.posting_at,
   sum(l.debit)::text debit,sum(l.credit)::text credit,sum(l.debit-l.credit)::text net
  from erp.journal_entries j join erp.journal_lines l on l.journal_entry_id=j.id
  where j.status in('POSTED','REVERSED') and j.transaction_date between f and t and l.account_id=any(cash_ids)
  group by j.id order by j.transaction_date,j.posting_at,j.id limit n offset off
 )x;
 return jsonb_build_object('contract_version','cp7.finance-analysis.v1','captured_at',statement_timestamp(),
  'knowledge_basis','CURRENT_RECORDED_KNOWLEDGE','historical_knowledge','NOT_RECONSTRUCTED',
  'dates',jsonb_build_object('from',f,'to',t,'as_of',a,'compare_from',bf,'compare_to',bt),
  'comparison',jsonb_build_object('basis','NATIVE_OWNER_REPORT_OPERANDS','formula_version','GROWTH_POSITIVE_BASE_AND_GROSS_MARGIN_PP_V2','rounding_scale',4,
   'current',cp7_finance.exact_numbers(current_report),'baseline',cp7_finance.exact_numbers(baseline_report),
   'revenue_growth_pct',growth::text,'gross_margin_change_pp',margin_delta::text),
  'cash',jsonb_build_object('basis','GL_TRANSACTION_DATE_ALL_CONFIGURED_CASH_COA','account_scope','DISTINCT_COA_INCLUDING_INACTIVE_CASH_ACCOUNTS_AND_CASH_MAPPING',
   'opening',opening::text,'closing',closing::text,'debit',debits::text,'credit',credits::text,'net_change',(closing-opening)::text,
   'ledger_net',(debits-credits)::text,'source_difference',(closing-opening-debits+credits)::text,'reconciled',closing-opening=debits-credits,
   'entries',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows)else null end)));
end $$;
create function public.erp_cp7_get_finance_analysis_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_finance.analysis(p_query)$$;
alter function cp7_finance.analysis(jsonb) owner to cp7_finance_read;
grant create on schema public to cp7_finance_read;
alter function public.erp_cp7_get_finance_analysis_v1(jsonb) owner to cp7_finance_read;
revoke create on schema public from cp7_finance_read;
revoke all on function cp7_finance.analysis(jsonb),public.erp_cp7_get_finance_analysis_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_finance_analysis_v1(jsonb) to authenticated;

-- Bounded period control: accepted close/reopen functions own all business writes.
create role cp7_period_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create role cp7_period_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_period authorization cp7_period_read;
revoke all on schema cp7_period from public,anon,authenticated,service_role,cp7_capture;
grant usage,create on schema cp7_period to cp7_period_write;
grant usage on schema erp,auth to cp7_period_read,cp7_period_write;
grant usage on schema cp7_finance to cp7_period_read;
grant execute on function cp7_finance.exact_numbers(jsonb) to cp7_period_read;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_period_read,cp7_period_write;
grant execute on function erp.accounting_close_preflight_v1(date) to cp7_period_read;
grant select on erp.accounting_period_control,erp.accounting_close_filings_v1,erp.account_daily_balances to cp7_period_read;
grant execute on function erp.close_accounting_through(date,text),erp.reopen_accounting_through(date,text) to cp7_period_write;
create table cp7_period.requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,response jsonb,primary key(actor,request_id));
alter table cp7_period.requests owner to cp7_period_write;
alter table cp7_period.requests enable row level security;
revoke all on cp7_period.requests from public,anon,authenticated,service_role,cp7_capture,cp7_period_read;

create function cp7_period.access_now() returns void
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_PERIOD_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission('finance.reports.view') or not erp.has_permission('finance.period_close.manage') then raise exception using errcode='42501',message='CP7_PERIOD_ACCESS_DENIED';end if;
 if coalesce(a->'profile'->>'role_code','') not in('OWNER','ADMIN') then raise exception using errcode='42501',message='CP7_PERIOD_OWNER_ADMIN_REQUIRED';end if;
end $$;

create function cp7_period.workspace(p_through date) returns jsonb
language plpgsql stable security definer set search_path='' set TimeZone='UTC' as $$
declare control jsonb;preflight jsonb;balances jsonb;filing jsonb;token text;
begin
 perform cp7_period.access_now();
 if p_through is null or p_through>(statement_timestamp() at time zone 'Asia/Jakarta')::date then raise exception 'CP7_PERIOD_REVIEW_DATE';end if;
 select jsonb_build_object('closed_through',c.closed_through,'version_token',md5(jsonb_build_array(c.closed_through,extract(epoch from c.updated_at),c.updated_by,c.change_reason)::text)) into control from erp.accounting_period_control c where c.singleton_id=1;
 if control is null then raise exception 'CP7_PERIOD_CONTROL_MISSING';end if;
 preflight:=erp.accounting_close_preflight_v1(p_through);
 if preflight is null or jsonb_typeof(preflight) is distinct from 'object' or octet_length(preflight::text)>1000000 then raise exception 'CP7_PERIOD_REVIEW_INCOMPLETE';end if;
 select coalesce(jsonb_agg(jsonb_build_array(b.account_id,b.balance) order by b.account_id),'[]') into balances
 from(select a.account_id,sum(a.debit_total-a.credit_total) balance from erp.account_daily_balances a where a.balance_date<=p_through group by a.account_id)b;
 select jsonb_build_object('id',f.id,'closed_through',f.closed_through,'filed_at',f.filed_at) into filing from erp.accounting_close_filings_v1 f where f.closed_through=(control->>'closed_through')::date order by f.filed_at desc,f.id desc limit 1;
 token:=md5(jsonb_build_array(p_through,control,preflight,balances)::text);
 return jsonb_build_object('contract_version','cp7.period-control.v1','captured_at',statement_timestamp(),'through',p_through,'control',control,
  'review_token',token,'preflight',cp7_finance.exact_numbers(preflight),'current_filing',filing);
end $$;

-- Only this helper obtains the same native control-row lock. It grants no ERP
-- DML to the facade role and rechecks access after the actual lock wait.
create function cp7_period.lock_current() returns void
language plpgsql volatile security definer set search_path='' as $$
begin
 perform cp7_period.access_now();
 perform 1 from erp.accounting_period_control where singleton_id=1 for update;
 if not found then raise exception 'CP7_PERIOD_CONTROL_MISSING';end if;
 perform cp7_period.access_now();
end $$;

create function cp7_period.command(p_action text,p_payload jsonb,p_request uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare v_actor uuid;saved cp7_period.requests;state jsonb;after_state jsonb;target date;review_day date;outcome jsonb;
begin
 perform cp7_period.access_now();v_actor:=auth.uid();
 if p_request is null or p_action not in('CLOSE','REOPEN') or p_action is null or jsonb_typeof(p_payload) is distinct from 'object'
  or not p_payload ?& array['through','review_through','review_token','reason']
  or exists(select 1 from jsonb_object_keys(p_payload)k where k not in('through','review_through','review_token','reason'))
  or jsonb_typeof(p_payload->'through') not in('string','null')
  or exists(select 1 from jsonb_each(p_payload)e where e.key in('review_through','review_token','reason') and jsonb_typeof(e.value)<>'string')
  or (p_payload->>'review_through')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
  or(p_payload->>'through' is not null and(p_payload->>'through')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$')
  or(p_payload->>'review_token')!~'^[a-f0-9]{32}$' or length(btrim(p_payload->>'reason')) not between 1 and 1000 then raise exception 'CP7_PERIOD_COMMAND';end if;
 target:=(p_payload->>'through')::date;review_day:=(p_payload->>'review_through')::date;
 if p_action='CLOSE' and(target is null or target<>review_day) then raise exception 'CP7_PERIOD_CLOSE_REVIEW_DATE';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('cp7.period.request:'||v_actor::text||':'||p_request::text,0));
 perform cp7_period.access_now();
 select * into saved from cp7_period.requests where requests.actor=v_actor and request_id=p_request;
 if found then
  if saved.action<>p_action or saved.payload<>p_payload then raise exception 'CP7_PERIOD_REQUEST_CHANGED';end if;
  if saved.response is null then raise exception 'CP7_PERIOD_REQUEST_INCOMPLETE';end if;
  return saved.response;
 end if;
 perform cp7_period.lock_current();perform cp7_period.access_now();
 state:=cp7_period.workspace(review_day);
 if state->>'review_token'<>p_payload->>'review_token' then raise exception 'CP7_PERIOD_REVIEW_CHANGED';end if;
 insert into cp7_period.requests(actor,request_id,action,payload) values(v_actor,p_request,p_action,p_payload);
 if p_action='CLOSE' then perform erp.close_accounting_through(target,p_payload->>'reason');
 else
  if state->'control'->>'closed_through' is null then raise exception 'CP7_PERIOD_NOT_CLOSED';end if;
  perform erp.reopen_accounting_through(target,p_payload->>'reason');
 end if;
 perform cp7_period.access_now();after_state:=cp7_period.workspace(review_day);
 if (after_state->'control'->>'closed_through')::date is distinct from target then raise exception 'CP7_PERIOD_OUTCOME_MISMATCH';end if;
 outcome:=jsonb_build_object('contract_version','cp7.period-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'closed_through',target,
  'version_token',after_state->'control'->>'version_token','filing_id',case when p_action='CLOSE' then after_state->'current_filing'->'id' else 'null'::jsonb end);
 if p_action='CLOSE' and outcome->>'filing_id' is null then raise exception 'CP7_PERIOD_FILING_MISSING';end if;
 update cp7_period.requests set response=outcome where requests.actor=v_actor and request_id=p_request;
 return outcome;
end $$;

create function public.erp_cp7_get_period_control_v1(p_through date) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_period.workspace(p_through)$$;
create function public.erp_cp7_save_period_control_v1(p_action text,p_payload jsonb,p_request uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_period.command(p_action,p_payload,p_request)$$;
grant create on schema public to cp7_period_read,cp7_period_write;
alter function cp7_period.access_now() owner to cp7_period_read;
alter function cp7_period.workspace(date) owner to cp7_period_read;
alter function cp7_period.lock_current() owner to postgres;
alter function cp7_period.command(text,jsonb,uuid) owner to cp7_period_write;
alter function public.erp_cp7_get_period_control_v1(date) owner to cp7_period_read;
alter function public.erp_cp7_save_period_control_v1(text,jsonb,uuid) owner to cp7_period_write;
revoke create on schema public,cp7_period from cp7_period_read,cp7_period_write;
revoke all on all functions in schema cp7_period from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_period.access_now(),cp7_period.workspace(date),cp7_period.lock_current() to cp7_period_write;
-- Supabase postgres is not a superuser. The narrowly scoped lock helper must
-- explicitly be able to run the same current-user check before/after its wait.
grant execute on function cp7_period.access_now() to postgres;
revoke all on function public.erp_cp7_get_period_control_v1(date),public.erp_cp7_save_period_control_v1(text,jsonb,uuid) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_period_control_v1(date),public.erp_cp7_save_period_control_v1(text,jsonb,uuid) to authenticated;

-- Queue control delegates all costing, propagation and posting to the accepted
-- native processor. A batch is an upper bound, never a promise of selected IDs.
create role cp7_recost_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create role cp7_recost_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_recost authorization cp7_recost_read;
revoke all on schema cp7_recost from public,anon,authenticated,service_role,cp7_capture;
grant usage,create on schema cp7_recost to cp7_recost_write;
grant usage on schema erp,auth to cp7_recost_read,cp7_recost_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_recost_read,cp7_recost_write;
grant select on erp.cost_recalc_queue,erp.production_orders to cp7_recost_read;
grant execute on function erp.process_cost_recalc_queue(integer) to cp7_recost_write;
create table cp7_recost.requests(actor uuid not null,request_id uuid not null,payload jsonb not null,response jsonb,primary key(actor,request_id));
alter table cp7_recost.requests owner to cp7_recost_write;
alter table cp7_recost.requests enable row level security;
revoke all on cp7_recost.requests from public,anon,authenticated,service_role,cp7_capture,cp7_recost_read;

create function cp7_recost.access_now(p_write boolean) returns void
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if p_write is null or auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_RECOST_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission('finance.hpp.view') or(p_write and not erp.has_permission('finance.hpp.manage')) then raise exception using errcode='42501',message='CP7_RECOST_ACCESS_DENIED';end if;
 if p_write and coalesce(a->'profile'->>'role_code','') not in('OWNER','ADMIN','STAFF') then raise exception using errcode='42501',message='CP7_RECOST_NATIVE_ROLE_REQUIRED';end if;
end $$;

create function cp7_recost.workspace(p_offset integer) returns jsonb
language plpgsql stable security definer set search_path='' set TimeZone='UTC' as $$
declare totals jsonb;rows jsonb;n bigint;
begin
 perform cp7_recost.access_now(false);
 if p_offset is null or p_offset<0 or p_offset>1000000 then raise exception 'CP7_RECOST_QUERY';end if;
 select jsonb_build_object('pending',count(*) filter(where status='PENDING')::text,'running',count(*) filter(where status='RUNNING')::text,
  'failed',count(*) filter(where status='FAILED')::text,'done',count(*) filter(where status='DONE')::text,
  'eligible',count(*) filter(where status='PENDING' or(status='FAILED' and attempt_count<3 and coalesce(next_attempt_at,statement_timestamp())<=statement_timestamp()))::text,
  'exhausted',count(*) filter(where status='FAILED' and attempt_count>=3)::text) into totals from erp.cost_recalc_queue;
 select count(*) into n from erp.cost_recalc_queue where status<>'DONE';
 select coalesce(jsonb_agg(x.row order by x.queued_at,x.id),'[]') into rows from(
  select q.queued_at,q.id,jsonb_build_object('id',q.id::text,'entity_type',q.entity_type,'entity_id',q.entity_id,'po_number',p.po_number,
   'status',q.status,'reason',q.reason,'recalc_from',q.recalc_from,'queued_at',q.queued_at,'attempt_count',q.attempt_count,
   'next_attempt_at',q.next_attempt_at,'error_message',left(q.error_message,2000),'error_truncated',coalesce(length(q.error_message)>2000,false),
   'eligible',q.status='PENDING' or(q.status='FAILED' and q.attempt_count<3 and coalesce(q.next_attempt_at,statement_timestamp())<=statement_timestamp())) row
  from erp.cost_recalc_queue q left join erp.production_orders p on q.entity_type='PO' and p.id=q.entity_id
  where q.status<>'DONE' order by q.queued_at,q.id limit 25 offset p_offset
 )x;
 return jsonb_build_object('contract_version','cp7.recost-queue.v1','captured_at',statement_timestamp(),'scope','CURRENT_QUEUE_ALL_ENTITIES',
  'batch_semantics','AT_MOST_20_ELIGIBLE_UNLOCKED_NATIVE_JOBS','counts',totals,
  'page',jsonb_build_object('rows',rows,'total',n::text,'offset',p_offset,'limit',25,'next_offset',case when p_offset+jsonb_array_length(rows)<n then p_offset+jsonb_array_length(rows) end));
end $$;

create function cp7_recost.command(p_payload jsonb,p_request uuid) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare actor_id uuid;saved cp7_recost.requests;completed integer;outcome jsonb;
begin
 perform cp7_recost.access_now(true);actor_id:=auth.uid();
 if p_request is null or jsonb_typeof(p_payload) is distinct from 'object' or not p_payload ?& array['limit','reason']
  or exists(select 1 from jsonb_object_keys(p_payload)k where k not in('limit','reason'))
  or p_payload->'limit' is distinct from '20'::jsonb or jsonb_typeof(p_payload->'reason') is distinct from 'string'
  or length(btrim(p_payload->>'reason')) not between 1 and 1000 then raise exception 'CP7_RECOST_COMMAND';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('cp7.recost.request:'||actor_id::text||':'||p_request::text,0));
 perform cp7_recost.access_now(true);
 select * into saved from cp7_recost.requests where actor=actor_id and request_id=p_request;
 if found then
  if saved.payload<>p_payload then raise exception 'CP7_RECOST_REQUEST_CHANGED';end if;
  if saved.response is null then raise exception 'CP7_RECOST_REQUEST_INCOMPLETE';end if;
  return saved.response;
 end if;
 insert into cp7_recost.requests(actor,request_id,payload) values(actor_id,p_request,p_payload);
 completed:=erp.process_cost_recalc_queue(20);
 perform cp7_recost.access_now(true);
 if completed is null or completed<0 or completed>20 then raise exception 'CP7_RECOST_OUTCOME';end if;
 outcome:=jsonb_build_object('contract_version','cp7.recost-outcome.v1','kind','COMMITTED_OUTCOME','action','PROCESS_ELIGIBLE',
  'request_id',p_request,'limit',20,'completed',completed,'processed_at',statement_timestamp(),
  'batch_semantics','AT_MOST_20_ELIGIBLE_UNLOCKED_NATIVE_JOBS','queue_after',cp7_recost.workspace(0));
 update cp7_recost.requests set response=outcome where actor=actor_id and request_id=p_request;
 return outcome;
end $$;

create function public.erp_cp7_get_recost_queue_v1(p_offset integer default 0) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_recost.workspace(p_offset)$$;
create function public.erp_cp7_process_recost_v1(p_payload jsonb,p_request uuid) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_recost.command(p_payload,p_request)$$;
grant create on schema public to cp7_recost_read,cp7_recost_write;
alter function cp7_recost.access_now(boolean) owner to cp7_recost_read;
alter function cp7_recost.workspace(integer) owner to cp7_recost_read;
alter function cp7_recost.command(jsonb,uuid) owner to cp7_recost_write;
alter function public.erp_cp7_get_recost_queue_v1(integer) owner to cp7_recost_read;
alter function public.erp_cp7_process_recost_v1(jsonb,uuid) owner to cp7_recost_write;
revoke create on schema public,cp7_recost from cp7_recost_read,cp7_recost_write;
revoke all on all functions in schema cp7_recost from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_recost.access_now(boolean),cp7_recost.workspace(integer) to cp7_recost_write;
revoke all on function public.erp_cp7_get_recost_queue_v1(integer),public.erp_cp7_process_recost_v1(jsonb,uuid) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_recost_queue_v1(integer),public.erp_cp7_process_recost_v1(jsonb,uuid) to authenticated;

-- Complete posted journal source. Read-only, with current native authority.
create role cp7_journal_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_journal authorization cp7_journal_read;
revoke all on schema cp7_journal from public,anon,authenticated,service_role,cp7_capture;
grant usage on schema erp,auth to cp7_journal_read;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_journal_read;
grant select on erp.journal_entries,erp.journal_lines,erp.chart_accounts to cp7_journal_read;

create function cp7_journal.access_now() returns void
language plpgsql stable security invoker set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_JOURNAL_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission('finance.journal.view') then raise exception using errcode='42501',message='CP7_JOURNAL_ACCESS_DENIED';end if;
 if coalesce(a->'profile'->>'role_code','') not in('OWNER','ADMIN') then raise exception using errcode='42501',message='CP7_JOURNAL_OWNER_ADMIN_REQUIRED';end if;
end $$;

create function cp7_journal.header(h erp.journal_entries) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',h.id,'number',h.journal_number,'source_type',h.source_type,'source_id',h.source_id,
  'status',h.status,'reversal_of_id',h.reversal_of_id,'description',h.description,'economic_date',h.economic_date,
  'transaction_date',h.transaction_date,'posting_at',h.posting_at,'period_shifted',h.period_shifted,
  'line_count',count(l.id)::text,'debit',coalesce(sum(l.debit),0)::text,'credit',coalesce(sum(l.credit),0)::text,
  'balanced',count(l.id)>0 and coalesce(sum(l.debit),0)=coalesce(sum(l.credit),0))
 from erp.journal_lines l where l.journal_entry_id=h.id
$$;

create function cp7_journal.workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' set TimeZone='UTC' as $$
declare f date;t date;q text;chosen uuid;off integer;n integer;total bigint;rows jsonb;detail jsonb:=null;
 h erp.journal_entries;lines jsonb;debits numeric;credits numeric;line_count bigint;unbalanced bigint;
begin
 perform cp7_journal.access_now();
 if jsonb_typeof(p_query) is distinct from 'object' or not p_query ?& array['from','to']
  or exists(select 1 from jsonb_object_keys(p_query)k where k not in('from','to','q','journal_id','offset','limit'))
  or exists(select 1 from jsonb_each(p_query)e where e.key in('from','to') and(jsonb_typeof(e.value)<>'string' or(e.value#>>'{}')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'))
  or exists(select 1 from jsonb_each(p_query)e where e.key in('q','journal_id') and jsonb_typeof(e.value) not in('string','null'))
  or exists(select 1 from jsonb_each(p_query)e where e.key in('offset','limit') and(jsonb_typeof(e.value)<>'number' or e.value::text!~'^[0-9]{1,7}$')) then raise exception 'CP7_JOURNAL_QUERY';end if;
 begin f:=(p_query->>'from')::date;t:=(p_query->>'to')::date;chosen:=(p_query->>'journal_id')::uuid;
 exception when invalid_text_representation or datetime_field_overflow then raise exception 'CP7_JOURNAL_QUERY';end;
 q:=btrim(coalesce(p_query->>'q',''));off:=coalesce((p_query->>'offset')::integer,0);n:=coalesce((p_query->>'limit')::integer,25);
 if f is null or t is null or f>t or t>(statement_timestamp() at time zone 'Asia/Jakarta')::date or length(q)>120 or off not between 0 and 1000000 or n not between 1 and 25 then raise exception 'CP7_JOURNAL_QUERY';end if;
 -- Full filtered totals and both source/detail reads share one stable snapshot.
 -- Reversed originals remain at their accounting date alongside linked inverses.
 with sources as(
  select j.id,count(l.id) native_line_count,coalesce(sum(l.debit),0) d,coalesce(sum(l.credit),0) c
  from erp.journal_entries j left join erp.journal_lines l on l.journal_entry_id=j.id
  where j.status in('POSTED','REVERSED') and j.transaction_date between f and t
   and(q='' or strpos(lower(concat_ws(' ',j.journal_number,j.source_type,j.description)),lower(q))>0)
  group by j.id
 ) select count(*),coalesce(sum(s.native_line_count),0),coalesce(sum(s.d),0),coalesce(sum(s.c),0),count(*)filter(where s.native_line_count=0 or s.d<>s.c)
 into total,line_count,debits,credits,unbalanced from sources s;
 select coalesce(jsonb_agg(cp7_journal.header(x) order by x.transaction_date,x.posting_at,x.id),'[]') into rows
 from(select j.* from erp.journal_entries j where j.status in('POSTED','REVERSED') and j.transaction_date between f and t
  and(q='' or strpos(lower(concat_ws(' ',j.journal_number,j.source_type,j.description)),lower(q))>0)
  order by j.transaction_date,j.posting_at,j.id limit n offset off)x;
 if chosen is not null then
  select * into h from erp.journal_entries where id=chosen and status in('POSTED','REVERSED') and transaction_date between f and t;
  if h.id is null then raise exception 'CP7_JOURNAL_SOURCE_NOT_IN_PERIOD';end if;
  if(select count(*) from erp.journal_lines where journal_entry_id=h.id)>250 then raise exception 'CP7_JOURNAL_DETAIL_TOO_LARGE';end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'account_id',l.account_id,'account_code',a.account_code,
   'account_name',a.account_name,'description',l.description,'debit',l.debit::text,'credit',l.credit::text,
   'customer_id',l.customer_id,'vendor_id',l.vendor_id,'contractor_id',l.contractor_id,'po_id',l.po_id,'product_id',l.product_id) order by l.id),'[]')
  into lines from erp.journal_lines l join erp.chart_accounts a on a.id=l.account_id where l.journal_entry_id=h.id;
  if jsonb_array_length(lines)<>(select count(*) from erp.journal_lines where journal_entry_id=h.id) then raise exception 'CP7_JOURNAL_DETAIL_INCOMPLETE';end if;
  detail:=cp7_journal.header(h)||jsonb_build_object('lines',lines);
 end if;
 return jsonb_build_object('contract_version','cp7.journal-read.v1','captured_at',statement_timestamp(),
  'knowledge_basis','CURRENT_RECORDED_KNOWLEDGE','historical_knowledge','NOT_RECONSTRUCTED',
  'basis',jsonb_build_object('from',f,'to',t,'q',q,'scope','POSTED_AND_REVERSED_JOURNALS_BY_ACCOUNTING_DATE'),
  'totals',jsonb_build_object('journal_count',total::text,'line_count',line_count::text,'debit',debits::text,'credit',credits::text,'unbalanced_journal_count',unbalanced::text),
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',n,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows)else null end),
  'detail',detail);
end $$;
create function public.erp_cp7_get_journal_book_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_journal.workspace(p_query)$$;
alter function cp7_journal.access_now() owner to cp7_journal_read;
alter function cp7_journal.header(erp.journal_entries) owner to cp7_journal_read;
alter function cp7_journal.workspace(jsonb) owner to cp7_journal_read;
grant create on schema public to cp7_journal_read;
alter function public.erp_cp7_get_journal_book_v1(jsonb) owner to cp7_journal_read;
revoke create on schema public from cp7_journal_read;
revoke all on all functions in schema cp7_journal from public,anon,authenticated,service_role,cp7_capture;
revoke all on function public.erp_cp7_get_journal_book_v1(jsonb) from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_journal_book_v1(jsonb) to authenticated;

-- Reviewed native miscellaneous income/expense. No new accounting engine or
-- admission delta. Browser callers never acquire ERP DML or native writer EXEC.
create role cp7_misc_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create role cp7_misc_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_misc authorization cp7_misc_read;
revoke all on schema cp7_misc from public,anon,authenticated,service_role,cp7_capture;
grant usage,create on schema cp7_misc to cp7_misc_write;
grant usage on schema erp,auth to cp7_misc_read;
grant usage on schema auth to cp7_misc_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_misc_read;
grant execute on function auth.uid() to cp7_misc_write;
grant select on erp.misc_finance_transactions,erp.misc_finance_categories,erp.cash_accounts,erp.chart_accounts,erp.accounting_account_mappings,erp.journal_entries,erp.journal_lines to cp7_misc_read;
create table cp7_misc.requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,response jsonb,primary key(actor,request_id));
create table cp7_misc.command_context(backend_pid integer not null,transaction_id bigint not null,actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,primary key(backend_pid,transaction_id));
alter table cp7_misc.requests owner to cp7_misc_write;
alter table cp7_misc.command_context owner to cp7_misc_write;
alter table cp7_misc.requests enable row level security;
alter table cp7_misc.command_context enable row level security;
create policy cp7_misc_requests_deny on cp7_misc.requests for all to public using(false)with check(false);
create policy cp7_misc_context_deny on cp7_misc.command_context for all to public using(false)with check(false);
revoke all on cp7_misc.requests,cp7_misc.command_context from public,anon,authenticated,service_role,cp7_capture,cp7_misc_read;

create function cp7_misc.access_now() returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare a jsonb;
begin
 if auth.uid() is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_MISC_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed' is distinct from 'true'::jsonb or not erp.has_permission('finance.journal.view') or not erp.has_permission('finance.cash.view') then raise exception using errcode='42501',message='CP7_MISC_ACCESS_DENIED';end if;
 -- The accepted native writer is OWNER/ADMIN only. View permissions cannot
 -- turn a custom role into a financial writer.
 if coalesce(a->'profile'->>'role_code','') not in('OWNER','ADMIN') then raise exception using errcode='42501',message='CP7_MISC_OWNER_ADMIN_REQUIRED';end if;
 return a;
end $$;

create function cp7_misc.category(p_id uuid) returns jsonb
language sql stable security definer set search_path='' as $$
 select jsonb_build_object('id',c.id,'code',c.category_code,'name',c.category_name,'type',c.category_type,
  'account_id',a.id,'account_code',a.account_code,'account_name',a.account_name,
  'eligible',c.is_active and a.is_active and a.is_postable and a.account_type=case c.category_type when 'OTHER_INCOME' then 'REVENUE' when 'OTHER_EXPENSE' then 'EXPENSE' end
   and not exists(select 1 from erp.accounting_account_mappings m where m.account_id=a.id and m.mapping_key not in('OTHER_INCOME','OTHER_EXPENSE')),
  'review_token',md5(jsonb_build_object('category',to_jsonb(c),'account',to_jsonb(a),'mappings',coalesce((select jsonb_agg(to_jsonb(m) order by m.mapping_key)from erp.accounting_account_mappings m where m.account_id=a.id),'[]'))::text))
 from erp.misc_finance_categories c join erp.chart_accounts a on a.id=c.default_account_id where c.id=p_id
$$;
create function cp7_misc.cash(p_id uuid) returns jsonb
language sql stable security definer set search_path='' as $$
 select jsonb_build_object('id',c.id,'code',c.cash_account_code,'name',c.cash_account_name,'kind',c.account_kind,
  'account_id',a.id,'account_code',a.account_code,'account_name',a.account_name,
  'eligible',c.is_active and a.is_active and a.is_postable and a.account_type='ASSET'
   and not exists(select 1 from erp.accounting_account_mappings m where m.account_id=a.id and m.mapping_key not in('CASH','BANK')),
  'review_token',md5(jsonb_build_object('cash',to_jsonb(c),'account',to_jsonb(a),'mappings',coalesce((select jsonb_agg(to_jsonb(m) order by m.mapping_key)from erp.accounting_account_mappings m where m.account_id=a.id),'[]'))::text))
 from erp.cash_accounts c join erp.chart_accounts a on a.id=c.coa_account_id where c.id=p_id
$$;
create function cp7_misc.source(p_id uuid) returns jsonb
language plpgsql stable security definer set search_path='' set TimeZone='UTC' as $$
declare t erp.misc_finance_transactions;c jsonb;cash jsonb;journals jsonb;fingerprint jsonb;
begin
 select * into t from erp.misc_finance_transactions where id=p_id;if t.id is null then return null;end if;
 c:=cp7_misc.category(t.category_id);cash:=cp7_misc.cash(t.cash_account_id);
 select coalesce(jsonb_agg(jsonb_build_object('id',j.id,'number',j.journal_number,'status',j.status,'reversal_of_id',j.reversal_of_id,
  'economic_date',j.economic_date,'transaction_date',j.transaction_date,'posting_at',j.posting_at,'period_shifted',j.period_shifted,
  'debit',(select coalesce(sum(l.debit),0)::text from erp.journal_lines l where l.journal_entry_id=j.id),
  'credit',(select coalesce(sum(l.credit),0)::text from erp.journal_lines l where l.journal_entry_id=j.id))order by j.posting_at,j.id),'[]')into journals
 from erp.journal_entries j where(j.source_type='MISC_FINANCE' and j.source_id=t.id)
  or j.reversal_of_id in(select id from erp.journal_entries where source_type='MISC_FINANCE' and source_id=t.id);
 select jsonb_build_object('transaction',to_jsonb(t),'category',c,'cash',cash,'journals',journals,
  'lines',coalesce(jsonb_agg(to_jsonb(l)order by l.id),'[]'))into fingerprint
 from erp.journal_lines l where l.journal_entry_id in(select (x->>'id')::uuid from jsonb_array_elements(journals)x);
 return jsonb_build_object('id',t.id,'number',t.transaction_number,'type',t.transaction_type,'category_id',t.category_id,
  'category_name',c->>'name','category_eligible',coalesce((c->>'eligible')::boolean,false),'cash_account_id',t.cash_account_id,
  'cash_account_name',cash->>'name','cash_eligible',coalesce((cash->>'eligible')::boolean,false),'physical_at',t.physical_at,
  'amount',t.amount::text,'counterparty_name',t.counterparty_name,'reference_number',t.reference_number,'notes',t.notes,
  'status',t.status,'review_token',md5(fingerprint::text),'category_source',c,'cash_source',cash,'journals',journals);
end $$;

create function cp7_misc.workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' set TimeZone='UTC' as $$
declare q text;st text;selected uuid;off integer;coff integer;boff integer;cats jsonb;banks jsonb;rows jsonb;detail jsonb;total bigint;ct bigint;bt bigint;
begin
 perform cp7_misc.access_now();
 if jsonb_typeof(p_query)is distinct from 'object'
  or exists(select 1 from jsonb_object_keys(p_query)k where k not in('q','status','transaction_id','offset','category_offset','cash_offset'))
  or exists(select 1 from jsonb_each(p_query)e where e.key in('q','status','transaction_id')and jsonb_typeof(e.value)not in('string','null'))
  or exists(select 1 from jsonb_each(p_query)e where e.key in('offset','category_offset','cash_offset')and(jsonb_typeof(e.value)<>'number'or e.value::text!~'^[0-9]{1,7}$'))then raise exception 'CP7_MISC_QUERY';end if;
 begin selected:=(p_query->>'transaction_id')::uuid;exception when invalid_text_representation then raise exception 'CP7_MISC_QUERY';end;
 q:=btrim(coalesce(p_query->>'q',''));st:=p_query->>'status';off:=coalesce((p_query->>'offset')::integer,0);coff:=coalesce((p_query->>'category_offset')::integer,0);boff:=coalesce((p_query->>'cash_offset')::integer,0);
 if length(q)>120 or(st is not null and st not in('DRAFT','POSTED','REVERSED'))or off not between 0 and 1000000 or coff not between 0 and 1000000 or boff not between 0 and 1000000 then raise exception 'CP7_MISC_QUERY';end if;
 select count(*)into total from erp.misc_finance_transactions t where(st is null or t.status=st)and(q=''or strpos(lower(concat_ws(' ',t.transaction_number,t.counterparty_name,t.reference_number,t.notes)),lower(q))>0);
 select coalesce(jsonb_agg(cp7_misc.source(t.id)order by t.physical_at desc,t.id),'[]')into rows from(select * from erp.misc_finance_transactions t where(st is null or t.status=st)and(q=''or strpos(lower(concat_ws(' ',t.transaction_number,t.counterparty_name,t.reference_number,t.notes)),lower(q))>0)order by t.physical_at desc,t.id limit 25 offset off)t;
 with eligible as materialized(select cp7_misc.category(c.id)value from erp.misc_finance_categories c),all_rows as materialized(select value from eligible where value->'eligible'='true'::jsonb),slice as(select value from all_rows order by value->>'code',value->>'id' limit 25 offset coff)
 select(select count(*)from all_rows),coalesce((select jsonb_agg(value order by value->>'code',value->>'id')from slice),'[]')into ct,cats;
 with eligible as materialized(select cp7_misc.cash(c.id)value from erp.cash_accounts c),all_rows as materialized(select value from eligible where value->'eligible'='true'::jsonb),slice as(select value from all_rows order by value->>'code',value->>'id' limit 25 offset boff)
 select(select count(*)from all_rows),coalesce((select jsonb_agg(value order by value->>'code',value->>'id')from slice),'[]')into bt,banks;
 if selected is not null then detail:=cp7_misc.source(selected);if detail is null then raise exception 'CP7_MISC_NOT_FOUND';end if;end if;
 return jsonb_build_object('contract_version','cp7.misc-read.v1','captured_at',statement_timestamp(),'scope','CURRENT_NATIVE_MISC_FINANCE_DOCUMENTS',
  'query',jsonb_build_object('q',q,'status',st,'transaction_id',selected),
  'page',jsonb_build_object('rows',rows,'total',total::text,'offset',off,'limit',25,'next_offset',case when off+jsonb_array_length(rows)<total then off+jsonb_array_length(rows)end),
  'categories',jsonb_build_object('rows',cats,'total',ct::text,'offset',coff,'limit',25,'next_offset',case when coff+jsonb_array_length(cats)<ct then coff+jsonb_array_length(cats)end),
  'cash_accounts',jsonb_build_object('rows',banks,'total',bt::text,'offset',boff,'limit',25,'next_offset',case when boff+jsonb_array_length(banks)<bt then boff+jsonb_array_length(banks)end),'detail',detail);
end $$;

create function cp7_misc.validate(p_action text,p jsonb) returns void
language plpgsql immutable security invoker set search_path='' as $$
declare allowed text[];k text;
begin
 allowed:=array['transaction_id','review_token','change_reason'];
 if p_action='SAVE'then allowed:=allowed||array['transaction_number','transaction_type','category_id','category_review_token','cash_account_id','cash_review_token','physical_at','amount','counterparty_name','reference_number','notes'];
 elsif p_action not in('POST','REVERSE')or p_action is null then raise exception 'CP7_MISC_ACTION';end if;
 if jsonb_typeof(p)is distinct from 'object'or not p ?& allowed or exists(select 1 from jsonb_object_keys(p)as x(field)where not x.field=any(allowed))then raise exception 'CP7_MISC_FIELDS';end if;
 foreach k in array allowed loop
  if k in('counterparty_name','reference_number','notes')or(p_action='SAVE'and k in('transaction_id','review_token'))then
   if jsonb_typeof(p->k)not in('string','null')then raise exception 'CP7_MISC_FIELDS';end if;
  elsif jsonb_typeof(p->k)is distinct from 'string'then raise exception 'CP7_MISC_FIELDS';end if;
 end loop;
 if(p->>'transaction_id'is not null and(p->>'transaction_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
  or(p->>'review_token'is not null and(p->>'review_token')!~'^[a-f0-9]{32}$')
  or(p_action='SAVE'and(p->>'transaction_id'is null)is distinct from(p->>'review_token'is null))
  or length(btrim(p->>'change_reason'))not between 5 and 1000 then raise exception 'CP7_MISC_FIELDS';end if;
 if p_action='SAVE'then
  if length(btrim(p->>'transaction_number'))not between 1 and 60 or(p->>'transaction_type')not in('OTHER_INCOME','OTHER_EXPENSE')
   or(p->>'category_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'or(p->>'cash_account_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
   or(p->>'category_review_token')!~'^[a-f0-9]{32}$'or(p->>'cash_review_token')!~'^[a-f0-9]{32}$'
   or(p->>'amount')!~'^(0|[1-9][0-9]{0,17})(\.[0-9]{1,2})?$'or(p->>'amount')::numeric<=0
   or(p->>'physical_at')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?(Z|[+-][0-9]{2}:[0-9]{2})$'
   or length(p->>'counterparty_name')>150 or length(p->>'reference_number')>100 or length(p->>'notes')>2000 then raise exception 'CP7_MISC_FIELDS';end if;
 end if;
end $$;

create function cp7_misc.apply_command(p_action text,p jsonb,p_request uuid) returns jsonb
language plpgsql volatile security definer set search_path='' set TimeZone='UTC' as $$
declare a jsonb;t erp.misc_finance_transactions;ident uuid:=(p->>'transaction_id')::uuid;cat uuid;bank uuid;c jsonb;cash jsonb;physical timestamptz;
begin
 a:=cp7_misc.access_now();perform cp7_misc.validate(p_action,p);
 if not exists(select 1 from cp7_misc.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid()and request_id=p_request and action=p_action and payload=p)then raise exception using errcode='42501',message='CP7_MISC_PRIVATE_CONTEXT_REQUIRED';end if;
 if ident is not null then select * into t from erp.misc_finance_transactions where id=ident for update;if t.id is null then raise exception 'CP7_MISC_NOT_FOUND';end if;end if;
 -- Lock mutable category/cash/account identities and mapping insertions before
 -- comparing the reviewed source. Native journal posting retains its own close
 -- lock and determines the accounting date; no caller can bypass either guard.
 lock table erp.accounting_account_mappings in share mode;
 cat:=case when p_action='SAVE'then(p->>'category_id')::uuid else t.category_id end;
 bank:=case when p_action='SAVE'then(p->>'cash_account_id')::uuid else t.cash_account_id end;
 perform 1 from erp.misc_finance_categories where id=cat for share;
 perform 1 from erp.cash_accounts where id=bank for share;
 perform 1 from erp.chart_accounts where id in(select default_account_id from erp.misc_finance_categories where id=cat union select coa_account_id from erp.cash_accounts where id=bank)order by id for share;
 if ident is not null then
  perform 1 from erp.journal_entries j where(j.source_type='MISC_FINANCE'and j.source_id=ident)or j.reversal_of_id in(select id from erp.journal_entries where source_type='MISC_FINANCE'and source_id=ident)order by j.id for update;
  perform 1 from erp.journal_lines l where l.journal_entry_id in(select id from erp.journal_entries where source_type='MISC_FINANCE'and source_id=ident)order by l.id for update;
 end if;
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 if ident is not null and cp7_misc.source(ident)->>'review_token'is distinct from p->>'review_token'then raise exception 'CP7_MISC_REVIEW_CHANGED';end if;
 c:=cp7_misc.category(cat);cash:=cp7_misc.cash(bank);
 if p_action in('SAVE','POST')then
  if c is null or c->'eligible'is distinct from 'true'::jsonb or cash is null or cash->'eligible'is distinct from 'true'::jsonb then raise exception 'CP7_MISC_SOURCE_UNAVAILABLE';end if;
  if p_action='SAVE'then
   if c->>'type'is distinct from p->>'transaction_type'or c->>'review_token'is distinct from p->>'category_review_token'or cash->>'review_token'is distinct from p->>'cash_review_token'then raise exception 'CP7_MISC_OPTIONS_CHANGED';end if;
   begin physical:=(p->>'physical_at')::timestamptz;exception when invalid_datetime_format or datetime_field_overflow then raise exception 'CP7_MISC_PHYSICAL_DATE';end;
   if physical>statement_timestamp()then raise exception 'CP7_MISC_FUTURE_DATE';end if;
  end if;
 end if;
 perform set_config('app.change_reason',btrim(p->>'change_reason'),true);
 if p_action='SAVE'then
  if ident is null then
   insert into erp.misc_finance_transactions(transaction_number,transaction_type,category_id,physical_at,amount,cash_account_id,counterparty_name,reference_number,notes,created_by)
   values(btrim(p->>'transaction_number'),p->>'transaction_type',cat,physical,(p->>'amount')::numeric,bank,p->>'counterparty_name',p->>'reference_number',p->>'notes',erp.current_app_user_id())returning id into ident;
  else
   if t.status<>'DRAFT'then raise exception 'CP7_MISC_DRAFT_ONLY';end if;
   update erp.misc_finance_transactions set transaction_number=btrim(p->>'transaction_number'),transaction_type=p->>'transaction_type',category_id=cat,physical_at=physical,amount=(p->>'amount')::numeric,cash_account_id=bank,counterparty_name=p->>'counterparty_name',reference_number=p->>'reference_number',notes=p->>'notes',updated_at=clock_timestamp()where id=ident;
  end if;
  -- Native trg_audit_misc_finance_transactions records INSERT/UPDATE with the
  -- app.change_reason already set above. Do not duplicate it with a new action.
 elsif p_action='POST'then
  if t.status<>'DRAFT'then raise exception 'CP7_MISC_DRAFT_ONLY';end if;
  if t.physical_at>statement_timestamp()then raise exception 'CP7_MISC_FUTURE_DATE';end if;
  perform erp.post_misc_finance(ident);
 else
  if t.status<>'POSTED'then raise exception 'CP7_MISC_POSTED_ONLY';end if;
  perform erp.reverse_misc_finance(ident,btrim(p->>'change_reason'));
 end if;
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 return jsonb_build_object('transaction_id',ident,'document',cp7_misc.source(ident));
end $$;

create function cp7_misc.command(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;saved cp7_misc.requests;r jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_misc.access_now();perform cp7_misc.validate(p_action,p_payload);
 -- This native relation has no row_version. The complete reviewed source token
 -- is mandatory on updates/post/inverse; never invent a frontend revision.
 if p_request is null or p_expected is not null then raise exception 'CP7_MISC_COMMAND_FIELDS';end if;
 insert into cp7_misc.requests(actor,request_id,action,payload)values(auth.uid(),p_request,p_action,p_payload)on conflict do nothing;
 select * into saved from cp7_misc.requests where actor=auth.uid()and request_id=p_request for update;
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 if saved.action<>p_action or saved.payload is distinct from p_payload then raise exception 'CP7_MISC_REQUEST_CHANGED';end if;
 if saved.response is not null then return saved.response;end if;
 insert into cp7_misc.command_context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,p_action,p_payload);
 r:=cp7_misc.apply_command(p_action,p_payload,p_request);
 delete from cp7_misc.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 r:=r||jsonb_build_object('contract_version','cp7.misc-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request);
 update cp7_misc.requests set response=r where actor=auth.uid()and request_id=p_request;
 return r;
end $$;
create function public.erp_cp7_get_misc_finance_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_misc.workspace(p_query)$$;
create function public.erp_cp7_save_misc_finance_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_misc.command(p_action,p_payload,p_request,p_expected)$$;
alter function cp7_misc.access_now()owner to cp7_misc_read;
alter function cp7_misc.category(uuid)owner to cp7_misc_read;
alter function cp7_misc.cash(uuid)owner to cp7_misc_read;
alter function cp7_misc.source(uuid)owner to cp7_misc_read;
alter function cp7_misc.workspace(jsonb)owner to cp7_misc_read;
alter function cp7_misc.validate(text,jsonb)owner to cp7_misc_read;
alter function cp7_misc.apply_command(text,jsonb,uuid)owner to postgres;
alter function cp7_misc.command(text,jsonb,uuid,text)owner to cp7_misc_write;
grant create on schema public to cp7_misc_read,cp7_misc_write;
alter function public.erp_cp7_get_misc_finance_v1(jsonb)owner to cp7_misc_read;
alter function public.erp_cp7_save_misc_finance_v1(text,jsonb,uuid,text)owner to cp7_misc_write;
revoke create on schema public,cp7_misc from cp7_misc_read,cp7_misc_write;
revoke all on all functions in schema cp7_misc from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_misc.access_now(),cp7_misc.validate(text,jsonb),cp7_misc.apply_command(text,jsonb,uuid)to cp7_misc_write;
grant usage on schema cp7_misc to postgres;
grant select on cp7_misc.command_context to postgres;
grant execute on function cp7_misc.access_now(),cp7_misc.validate(text,jsonb),cp7_misc.category(uuid),cp7_misc.cash(uuid),cp7_misc.source(uuid)to postgres;
revoke all on function public.erp_cp7_get_misc_finance_v1(jsonb),public.erp_cp7_save_misc_finance_v1(text,jsonb,uuid,text)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_misc_finance_v1(jsonb),public.erp_cp7_save_misc_finance_v1(text,jsonb,uuid,text)to authenticated;

do $verify$ begin
if encode(extensions.digest(pg_get_functiondef('erp.post_payroll_payment(uuid)'::regprocedure),'sha256'),'hex')<>'3ed74e090199067b4a1fd5c954f57abf9401dfdd48807437cc0aac1976a1b949' then raise exception 'CP7_INSTALLMENT_NATIVE_PREDECESSOR_CHANGED';end if;
if encode(extensions.digest(pg_get_functiondef('erp.reverse_paid_payroll(uuid,text)'::regprocedure),'sha256'),'hex')<>'62e5a76ec8075e94b838a83e92fc5fa9eb1b9151dd9370a0efd348c24625946b' then raise exception 'CP7_INSTALLMENT_NATIVE_PREDECESSOR_CHANGED';end if;
if encode(extensions.digest(pg_get_functiondef('erp.cancel_unpaid_payroll(uuid,text)'::regprocedure),'sha256'),'hex')<>'826ea6388f9346a990bbfa2946688ccd5850fd951aeea7455b02615d1825898f' then raise exception 'CP7_INSTALLMENT_NATIVE_PREDECESSOR_CHANGED';end if;
end $verify$;
-- E05 owner-approved cash installments against one immutable approved payroll.
-- Read capability has no native DML; command capability owns metadata only.
create role cp7_installment_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create role cp7_installment_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_installment authorization cp7_installment_read;
revoke all on schema cp7_installment from public,anon,authenticated,service_role,cp7_capture;
grant usage,create on schema cp7_installment to cp7_installment_write;
grant usage on schema erp,auth,cp7_misc,cp7_payroll to cp7_installment_read;
grant usage on schema auth to cp7_installment_write;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text),cp7_misc.cash(uuid),cp7_payroll.settlement_token(uuid) to cp7_installment_read;
grant execute on function auth.uid() to cp7_installment_write;
grant select on erp.payroll_settlements,erp.payroll_work_items,erp.payroll_attendance_items,erp.payroll_reimbursements,erp.payroll_deductions,erp.contractors,erp.cash_accounts,erp.chart_accounts,erp.accounting_account_mappings,erp.journal_entries,erp.journal_lines to cp7_installment_read;
grant select on cp7_payroll.notes to cp7_installment_read;

create table cp7_installment.accounts(
 payroll_id uuid primary key references erp.payroll_settlements(id),
 approved_meaning jsonb not null,approved_net numeric(20,2) not null check(approved_net>0),
 payable_account_id uuid not null references erp.chart_accounts(id),
 created_by uuid not null,created_at timestamptz not null default statement_timestamp()
);
create table cp7_installment.payments(
 id uuid primary key,payroll_id uuid not null references cp7_installment.accounts(payroll_id),
 amount numeric(20,2) not null check(amount>0),payment_date date not null,
 cash_account_id uuid not null references erp.cash_accounts(id),cash_coa_id uuid not null references erp.chart_accounts(id),
 journal_id uuid not null unique references erp.journal_entries(id),
 reversal_journal_id uuid unique references erp.journal_entries(id),
 created_by uuid not null,request_id uuid not null,created_at timestamptz not null default statement_timestamp()
);
create table cp7_installment.requests(actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text not null,response jsonb,primary key(actor,request_id));
create table cp7_installment.command_context(backend_pid integer not null,transaction_id bigint not null,actor uuid not null,request_id uuid not null,action text not null,payload jsonb not null,expected_version text not null,native_payment_id uuid,primary key(backend_pid,transaction_id));
alter table cp7_installment.accounts owner to postgres;
alter table cp7_installment.payments owner to postgres;
alter table cp7_installment.requests owner to cp7_installment_write;
alter table cp7_installment.command_context owner to cp7_installment_write;
alter table cp7_installment.accounts enable row level security;
alter table cp7_installment.payments enable row level security;
alter table cp7_installment.requests enable row level security;
alter table cp7_installment.command_context enable row level security;
create policy cp7_installment_accounts_deny on cp7_installment.accounts for all to public using(false)with check(false);
create policy cp7_installment_payments_deny on cp7_installment.payments for all to public using(false)with check(false);
create policy cp7_installment_requests_deny on cp7_installment.requests for all to public using(false)with check(false);
create policy cp7_installment_context_deny on cp7_installment.command_context for all to public using(false)with check(false);
revoke all on cp7_installment.accounts,cp7_installment.payments,cp7_installment.requests,cp7_installment.command_context from public,anon,authenticated,service_role,cp7_capture;
grant select on cp7_installment.requests,cp7_installment.command_context to cp7_installment_read;
grant select on cp7_installment.accounts,cp7_installment.payments to cp7_installment_read;

create function cp7_installment.access_now(p_action text default null) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare a jsonb;
begin
 if auth.uid()is null or coalesce(auth.jwt()->>'role','')<>'authenticated' then raise exception using errcode='42501',message='CP7_INSTALLMENT_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed'is distinct from 'true'::jsonb or not erp.has_permission('finance.payroll.view')
  or(p_action is not null and(p_action not in('PAY','REVERSE_PAYMENT','REVERSE_PAYROLL')or not erp.has_permission('finance.payroll.pay')))
  or(p_action='REVERSE_PAYROLL'and not erp.has_permission('finance.payroll.approve'))then raise exception using errcode='42501',message='CP7_INSTALLMENT_ACCESS_DENIED';end if;
 return a;
end $$;

-- The reviewed cash fingerprint includes native timestamptz fields. Keep its
-- rendering fixed across the UTC reader and the WIB payment transaction.
-- This adapter leaves the accepted miscellaneous-finance helper unchanged.
create function cp7_installment.cash(p_id uuid) returns jsonb
language sql stable security definer set search_path='' set TimeZone='UTC' as $$
 select cp7_misc.cash(p_id)
$$;

create function cp7_installment.meaning(p_id uuid) returns jsonb
language sql stable security definer set search_path='' set TimeZone='UTC' as $$
 select jsonb_build_object('header',to_jsonb(p)-array['status','payment_date','payment_cash_account_id','settled_at','updated_at','row_version'],
  'work',coalesce((select jsonb_agg(to_jsonb(i)order by i.id)from erp.payroll_work_items i where i.payroll_id=p.id),'[]'),
  'attendance',coalesce((select jsonb_agg(to_jsonb(i)order by i.id)from erp.payroll_attendance_items i where i.payroll_id=p.id),'[]'),
  'reimbursements',coalesce((select jsonb_agg(to_jsonb(i)order by i.id)from erp.payroll_reimbursements i where i.payroll_id=p.id),'[]'),
  'deductions',coalesce((select jsonb_agg(to_jsonb(i)order by i.id)from erp.payroll_deductions i where i.payroll_id=p.id),'[]'))
 from erp.payroll_settlements p where p.id=p_id
$$;

create function cp7_installment.require_context(p_id uuid) returns void
language plpgsql stable security definer set search_path='' as $$
declare c cp7_installment.command_context;
begin
 select * into c from cp7_installment.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid()and(payload->>'payroll_id')::uuid=p_id;
 if c.actor is null or not exists(select 1 from cp7_installment.requests r where r.actor=c.actor and r.request_id=c.request_id and r.action=c.action and r.payload=c.payload and r.expected_version=c.expected_version and r.response is null)then raise exception using errcode='42501',message='CP7_INSTALLMENT_PRIVATE_CONTEXT_REQUIRED';end if;
 perform cp7_installment.access_now(c.action);
end $$;

-- This additional trigger preserves the accepted native lifecycle trigger.
-- Managed payment fields may change only inside the exact private command.
create function cp7_installment.guard_header() returns trigger
language plpgsql volatile security definer set search_path='' as $$
begin
 if exists(select 1 from cp7_installment.accounts where payroll_id=old.id)then
  if tg_op='DELETE'then raise exception 'CP7_INSTALLMENT_APPROVED_SOURCE_IMMUTABLE';end if;
  -- net_payable is generated after BEFORE triggers; freeze its exact component
  -- columns here and verify the computed value in the reviewed native meaning.
  if(to_jsonb(new)-array['status','payment_date','payment_cash_account_id','settled_at','updated_at','row_version','net_payable'])is distinct from(to_jsonb(old)-array['status','payment_date','payment_cash_account_id','settled_at','updated_at','row_version','net_payable'])then raise exception 'CP7_INSTALLMENT_APPROVED_SOURCE_IMMUTABLE';end if;
  perform cp7_installment.require_context(old.id);
 end if;
 if tg_op='DELETE'then return old;end if;return new;
end $$;
create trigger cp7_installment_managed_header before update or delete on erp.payroll_settlements for each row execute function cp7_installment.guard_header();

create function cp7_installment.guard_journal() returns trigger
language plpgsql volatile security definer set search_path='' as $$
declare p_id uuid;entry erp.journal_entries;c cp7_installment.command_context;
begin
 if tg_op='DELETE'then entry:=old;else entry:=new;end if;
 if tg_op='INSERT'and entry.source_type='PAYROLL_INSTALLMENT'then
  select * into c from cp7_installment.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid()and action='PAY'and native_payment_id=entry.source_id;
  if c.actor is null then raise exception using errcode='42501',message='CP7_INSTALLMENT_PRIVATE_CONTEXT_REQUIRED';end if;
  p_id:=(c.payload->>'payroll_id')::uuid;
 else
  select p.payroll_id into p_id from cp7_installment.payments p where entry.id in(p.journal_id,p.reversal_journal_id)or entry.reversal_of_id=p.journal_id;
  if p_id is null and entry.source_type like 'PAYROLL_%'then select payroll_id into p_id from cp7_installment.accounts where payroll_id=entry.source_id;end if;
  if p_id is null and entry.reversal_of_id is not null then
   select a.payroll_id into p_id from erp.journal_entries original join cp7_installment.accounts a on a.payroll_id=original.source_id where original.id=entry.reversal_of_id and original.source_type like 'PAYROLL_%';
  end if;
 end if;
 if p_id is not null then perform cp7_installment.require_context(p_id);end if;
 if tg_op='DELETE'then return old;end if;return new;
end $$;
create trigger cp7_installment_managed_journal before insert or update or delete on erp.journal_entries for each row execute function cp7_installment.guard_journal();

create function cp7_installment.guard_child() returns trigger
language plpgsql volatile security definer set search_path='' as $$
begin
 if(tg_op<>'INSERT'and exists(select 1 from cp7_installment.accounts where payroll_id=old.payroll_id))or(tg_op<>'DELETE'and exists(select 1 from cp7_installment.accounts where payroll_id=new.payroll_id))then raise exception 'CP7_INSTALLMENT_APPROVED_SOURCE_IMMUTABLE';end if;
 if tg_op='DELETE'then return old;end if;return new;
end $$;
create trigger cp7_installment_managed_work before insert or update or delete on erp.payroll_work_items for each row execute function cp7_installment.guard_child();
create trigger cp7_installment_managed_attendance before insert or update or delete on erp.payroll_attendance_items for each row execute function cp7_installment.guard_child();
create trigger cp7_installment_managed_reimbursements before insert or update or delete on erp.payroll_reimbursements for each row execute function cp7_installment.guard_child();
create trigger cp7_installment_managed_deductions before insert or update or delete on erp.payroll_deductions for each row execute function cp7_installment.guard_child();

create function cp7_installment.guard_line() returns trigger
language plpgsql volatile security definer set search_path='' as $$
declare p_id uuid;j erp.journal_entries;c cp7_installment.command_context;
begin
 select * into j from erp.journal_entries where id=case when tg_op='DELETE'then old.journal_entry_id else new.journal_entry_id end;
 select p.payroll_id into p_id from cp7_installment.payments p where j.id in(p.journal_id,p.reversal_journal_id)or j.reversal_of_id=p.journal_id;
 if p_id is null and j.source_type like 'PAYROLL_%'then select payroll_id into p_id from cp7_installment.accounts where payroll_id=j.source_id;end if;
 if p_id is null and j.source_type='PAYROLL_INSTALLMENT'then
  select * into c from cp7_installment.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid()and action='PAY'and native_payment_id=j.source_id;
  p_id:=(c.payload->>'payroll_id')::uuid;
 end if;
 if p_id is null and j.reversal_of_id is not null then select a.payroll_id into p_id from erp.journal_entries original join cp7_installment.accounts a on a.payroll_id=original.source_id where original.id=j.reversal_of_id and original.source_type like 'PAYROLL_%';end if;
 if p_id is not null then
  if tg_op<>'INSERT'then raise exception 'CP7_INSTALLMENT_NATIVE_JOURNAL_IMMUTABLE';end if;
  perform cp7_installment.require_context(p_id);
 end if;
 if tg_op='DELETE'then return old;end if;return new;
end $$;
create trigger cp7_installment_managed_line before insert or update or delete on erp.journal_lines for each row execute function cp7_installment.guard_line();

create function cp7_installment.assert_payment_amount(p_id uuid,p_amount numeric,p_final boolean) returns void
language plpgsql stable security definer set search_path='' as $$
declare remaining numeric;a cp7_installment.accounts;
begin
 perform cp7_installment.require_context(p_id);
 select * into a from cp7_installment.accounts where payroll_id=p_id;
 if a.payroll_id is null or a.approved_meaning is distinct from cp7_installment.meaning(p_id)then raise exception 'CP7_INSTALLMENT_APPROVED_SOURCE_CHANGED';end if;
 select a.approved_net-coalesce(sum(p.amount)filter(where p.reversal_journal_id is null),0)into remaining from cp7_installment.payments p where p.payroll_id=p_id;
 if p_amount is null or p_amount::text in('NaN','Infinity','-Infinity')or p_amount<=0 or p_amount<>round(p_amount,2)or p_amount>remaining or(p_final and p_amount<>remaining)then raise exception 'CP7_INSTALLMENT_AMOUNT_EXCEEDS_REMAINING';end if;
end $$;

CREATE OR REPLACE FUNCTION cp7_installment.check_payment(p_payroll_id uuid, p_cash_amount numeric)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
 SET TimeZone TO 'Asia/Jakarta'
AS $function$
declare
  p erp.payroll_settlements%rowtype;
  v_cash uuid;
  v_material_deduction numeric(20,2):=0;
  v_other_deduction numeric(20,2):=0;v_cash_advance numeric(20,2):=0;
  v_expected_attendance numeric(20,2):=0;
  v_actual_attendance numeric(20,2):=0;
  v_attendance_journal_count bigint:=0;
  r record;
begin
  perform cp7_installment.require_context(p_payroll_id);
  perform erp.require_internal();
  select * into p from erp.payroll_settlements where id=p_payroll_id for update;
  if p.id is null or p.status<>'APPROVED' then raise exception 'Payroll must be APPROVED'; end if;
  perform erp.check_opening_cash_advance_payroll_v1(p.id);
  perform erp.bb_check_opening_payable_payroll_v1(p.id);
  perform erp._cp3_lock_business_period(p.period_start,p.period_end);
  if p.net_payable<0 then raise exception 'Payroll net payable cannot be negative; carry deductions forward instead'; end if;
  if p.payment_date is null then raise exception 'Payroll payment date is required'; end if;
  if p.payment_date>((statement_timestamp() AT TIME ZONE 'Asia/Jakarta'::text))::date then raise exception 'Tanggal pembayaran payroll berada di masa depan'; end if;
  if p.net_payable>0 then
    select coa_account_id into v_cash from erp.cash_accounts where id=p.payment_cash_account_id and is_active=true;
    if v_cash is null then raise exception 'Active payroll cash/bank account is required when cash payment is positive'; end if;
  end if;

  v_expected_attendance:=round(coalesce(p.attendance_total,0),2);
  select count(distinct je.id),coalesce(sum(jl.debit),0)
    into v_attendance_journal_count,v_actual_attendance
  from erp.journal_entries je
  join erp.journal_lines jl on jl.journal_entry_id=je.id
  where je.source_type='PAYROLL_ATTENDANCE_ACCRUAL' and je.source_id=p.id and je.status='POSTED'
    and jl.account_id=erp.account_id('WIP') and jl.debit>0;
  if (v_expected_attendance=0 and v_attendance_journal_count<>0)
     or (v_expected_attendance>0 and (v_attendance_journal_count<>1 or round(v_actual_attendance,2) is distinct from v_expected_attendance)) then
    raise exception 'PAYROLL_APPROVAL_ACCRUAL_MISSING_OR_MISMATCH: expected attendance %, journal count %, WIP debit %',
      v_expected_attendance,v_attendance_journal_count,round(v_actual_attendance,2);
  end if;

  perform cp7_installment.assert_payment_amount(p.id,p_cash_amount,false);
end;
$function$
;
CREATE OR REPLACE FUNCTION cp7_installment.final_payment(p_payroll_id uuid, p_cash_amount numeric)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
 SET TimeZone TO 'Asia/Jakarta'
AS $function$
declare
  p erp.payroll_settlements%rowtype;
  v_cash uuid;
  v_material_deduction numeric(20,2):=0;
  v_other_deduction numeric(20,2):=0;v_cash_advance numeric(20,2):=0;
  v_expected_attendance numeric(20,2):=0;
  v_actual_attendance numeric(20,2):=0;
  v_attendance_journal_count bigint:=0;
  r record;
begin
  perform cp7_installment.require_context(p_payroll_id);
  perform erp.require_internal();
  select * into p from erp.payroll_settlements where id=p_payroll_id for update;
  if p.id is null or p.status<>'APPROVED' then raise exception 'Payroll must be APPROVED'; end if;
  perform erp.check_opening_cash_advance_payroll_v1(p.id);
  perform erp.bb_check_opening_payable_payroll_v1(p.id);
  perform erp._cp3_lock_business_period(p.period_start,p.period_end);
  if p.net_payable<0 then raise exception 'Payroll net payable cannot be negative; carry deductions forward instead'; end if;
  if p.payment_date is null then raise exception 'Payroll payment date is required'; end if;
  if p.payment_date>((statement_timestamp() AT TIME ZONE 'Asia/Jakarta'::text))::date then raise exception 'Tanggal pembayaran payroll berada di masa depan'; end if;
  if p.net_payable>0 then
    select coa_account_id into v_cash from erp.cash_accounts where id=p.payment_cash_account_id and is_active=true;
    if v_cash is null then raise exception 'Active payroll cash/bank account is required when cash payment is positive'; end if;
  end if;

  v_expected_attendance:=round(coalesce(p.attendance_total,0),2);
  select count(distinct je.id),coalesce(sum(jl.debit),0)
    into v_attendance_journal_count,v_actual_attendance
  from erp.journal_entries je
  join erp.journal_lines jl on jl.journal_entry_id=je.id
  where je.source_type='PAYROLL_ATTENDANCE_ACCRUAL' and je.source_id=p.id and je.status='POSTED'
    and jl.account_id=erp.account_id('WIP') and jl.debit>0;
  if (v_expected_attendance=0 and v_attendance_journal_count<>0)
     or (v_expected_attendance>0 and (v_attendance_journal_count<>1 or round(v_actual_attendance,2) is distinct from v_expected_attendance)) then
    raise exception 'PAYROLL_APPROVAL_ACCRUAL_MISSING_OR_MISMATCH: expected attendance %, journal count %, WIP debit %',
      v_expected_attendance,v_attendance_journal_count,round(v_actual_attendance,2);
  end if;

  perform cp7_installment.assert_payment_amount(p.id,p_cash_amount,true);
  select coalesce(sum(amount),0) into v_material_deduction
  from erp.payroll_deductions where payroll_id=p.id and deduction_type='MATERIAL_KASBON';
  select coalesce(sum(amount),0) into v_other_deduction
  from erp.payroll_deductions where payroll_id=p.id and deduction_type not in('MATERIAL_KASBON','CASH_ADVANCE');
  if v_material_deduction>0 then
    perform erp.post_journal('PAYROLL_MATERIAL_DEDUCTION',p.id,p.payment_date,
      'Physical material/accessory purchase deduction',jsonb_build_array(
        jsonb_build_object('mapping_key','CONTRACTOR_PAYABLE','debit',v_material_deduction,'credit',0,'contractor_id',p.contractor_id),
        jsonb_build_object('mapping_key','CONTRACTOR_RECEIVABLE','debit',0,'credit',v_material_deduction,'contractor_id',p.contractor_id)));
  end if;
  select coalesce(sum(amount),0) into v_cash_advance from erp.payroll_deductions
    where payroll_id=p.id and deduction_type='CASH_ADVANCE';
  if v_cash_advance>0 then
    perform erp.post_journal('PAYROLL_CASH_ADVANCE_DEDUCTION',p.id,p.payment_date,'Pelunasan kasbon tunai melalui payroll',jsonb_build_array(
      jsonb_build_object('mapping_key','CONTRACTOR_PAYABLE','debit',v_cash_advance,'credit',0,'contractor_id',p.contractor_id),
      jsonb_build_object('mapping_key','CONTRACTOR_RECEIVABLE','debit',0,'credit',v_cash_advance,'contractor_id',p.contractor_id)));
  end if;
  if v_other_deduction>0 then
    perform erp.post_journal('PAYROLL_OTHER_DEDUCTION',p.id,p.payment_date,
      'BS/penalty/other payroll deduction',jsonb_build_array(
        jsonb_build_object('mapping_key','CONTRACTOR_PAYABLE','debit',v_other_deduction,'credit',0,'contractor_id',p.contractor_id),
        jsonb_build_object('mapping_key','OTHER_INCOME','debit',0,'credit',v_other_deduction,'contractor_id',p.contractor_id)));
  end if;
  if p.net_payable>0 then
    perform erp.post_journal('PAYROLL_INSTALLMENT',(select c.native_payment_id from cp7_installment.command_context c where c.backend_pid=pg_backend_pid() and c.transaction_id=txid_current() and c.actor=auth.uid()),p.payment_date,'Mandor payroll payment',jsonb_build_array(
      jsonb_build_object('mapping_key','CONTRACTOR_PAYABLE','debit',p_cash_amount,'credit',0,'contractor_id',p.contractor_id),
      jsonb_build_object('account_id',v_cash,'debit',0,'credit',p_cash_amount,'contractor_id',p.contractor_id)));
  end if;

  update erp.payroll_settlements set status='PAID',settled_at=statement_timestamp(),updated_at=statement_timestamp() where id=p.id;
  update erp.opening_subledger_balances b set settled_amount=b.settled_amount+x.amount,
    status=case when b.settled_amount+x.amount=b.original_amount then 'SETTLED' else 'PARTIAL' end,updated_at=statement_timestamp()
  from(select opening_cash_advance_balance_id id,sum(amount) amount from erp.payroll_deductions
    where payroll_id=p.id and deduction_type='CASH_ADVANCE' group by opening_cash_advance_balance_id) x where b.id=x.id;
  -- BB (ALL-Y01): imported contractor payables paid by this payroll, then the dated floor of every opening balance it touched.
  update erp.opening_subledger_balances b set settled_amount=b.settled_amount+x.amount,
    status=case when b.settled_amount+x.amount=b.original_amount then 'SETTLED' else 'PARTIAL' end,updated_at=statement_timestamp()
  from(select opening_payable_balance_id id,sum(amount) amount from erp.payroll_reimbursements
    where payroll_id=p.id and source_type='OPENING_PAYABLE' group by opening_payable_balance_id) x where b.id=x.id;
  for r in select z.id from(select opening_payable_balance_id id from erp.payroll_reimbursements where payroll_id=p.id and opening_payable_balance_id is not null
      union select opening_cash_advance_balance_id from erp.payroll_deductions where payroll_id=p.id and opening_cash_advance_balance_id is not null) z order by z.id
  loop perform erp.bb_assert_opening_balance_floor_v1(r.id,p.payment_date); end loop;

  for r in select distinct pd.contractor_issue_item_id id from erp.payroll_deductions pd
           where pd.payroll_id=p.id and pd.contractor_issue_item_id is not null
  loop perform erp.refresh_contractor_issue_payroll_status(r.id); end loop;
  update erp.contractor_accessory_reimbursement_entitlements e set payroll_status='SETTLED'
  where e.id in(select pr.source_id from erp.payroll_reimbursements pr
                where pr.payroll_id=p.id and pr.source_type='ACCESSORY_BOM' and pr.source_id is not null);
  for r in
    select distinct bc.id as bs_case_id from erp.bs_cases bc
    where exists(select 1 from erp.payroll_work_items pwi where pwi.payroll_id=p.id and pwi.po_id=bc.po_id)
       or exists(select 1 from erp.payroll_work_items pwi join erp.rework_component_lines rcl on rcl.id=pwi.source_id
                 join erp.bs_case_components bcc on bcc.id=rcl.bs_case_component_id
                 where pwi.payroll_id=p.id and bcc.bs_case_id=bc.id)
  loop perform erp.rebuild_bs_component_counters(r.bs_case_id); end loop;

  insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)
  values('payroll_settlements',p.id,'POST',
    jsonb_build_object('lifecycle_action','PAY','payment_settlement_only',true,'attendance_accrual_created_at_payment',false),
    erp.current_app_user_id(),'Payroll payment settled approved payable without recognizing attendance cost again');
end;
$function$
;
CREATE OR REPLACE FUNCTION cp7_installment.reopen_settlement(p_payroll_id uuid, p_reason text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
 SET TimeZone TO 'Asia/Jakarta'
AS $function$
declare
  p erp.payroll_settlements%rowtype;
  r record;
begin
  perform cp7_installment.require_context(p_payroll_id);
  if nullif(trim(p_reason),'') is null then raise exception 'Payroll reversal reason is required'; end if;
  select * into p from erp.payroll_settlements where id=p_payroll_id for update;
  if p.id is null then raise exception 'Payroll not found'; end if;
  if p.status='REVERSED' then return; end if;
  if p.status<>'PAID' then raise exception 'Only PAID payroll uses reverse_paid_payroll; unpaid payroll uses cancel_unpaid_payroll'; end if;
  perform 1 from erp.opening_subledger_balances b where exists(select 1 from erp.payroll_deductions d
    where d.payroll_id=p.id and d.opening_cash_advance_balance_id=b.id) or exists(select 1 from erp.payroll_reimbursements pr
    where pr.payroll_id=p.id and pr.opening_payable_balance_id=b.id) order by b.id for update;
  perform erp._cp3_lock_business_period(p.period_start,p.period_end);

  for r in
    select je.id from erp.journal_entries je
    where je.source_id=p.id
      and je.source_type in ('PAYROLL_MATERIAL_DEDUCTION','PAYROLL_OTHER_DEDUCTION','PAYROLL_CASH_ADVANCE_DEDUCTION')
      and je.status='POSTED'
    order by je.posting_at desc,je.id desc
  loop perform erp._cp3_r4_reverse_journal_internal(r.id,p_reason); end loop;

  update erp.payroll_settlements set status='APPROVED',settled_at=null,updated_at=statement_timestamp() where id=p.id;
  update erp.opening_subledger_balances b set settled_amount=b.settled_amount-x.amount,
    status=case when b.settled_amount-x.amount=b.original_amount then 'SETTLED' when b.settled_amount-x.amount>0 then 'PARTIAL' else 'OPEN' end,
    updated_at=statement_timestamp()
  from(select opening_cash_advance_balance_id id,sum(amount) amount from erp.payroll_deductions
    where payroll_id=p.id and deduction_type='CASH_ADVANCE' group by opening_cash_advance_balance_id) x where b.id=x.id;
  -- BB (ALL-Y01): the imported contractor payables this payroll paid are open again.
  update erp.opening_subledger_balances b set settled_amount=b.settled_amount-x.amount,
    status=case when b.settled_amount-x.amount=b.original_amount then 'SETTLED' when b.settled_amount-x.amount>0 then 'PARTIAL' else 'OPEN' end,
    updated_at=statement_timestamp()
  from(select opening_payable_balance_id id,sum(amount) amount from erp.payroll_reimbursements
    where payroll_id=p.id and source_type='OPENING_PAYABLE' group by opening_payable_balance_id) x where b.id=x.id;

  for r in select distinct pd.contractor_issue_item_id id from erp.payroll_deductions pd
           where pd.payroll_id=p.id and pd.contractor_issue_item_id is not null
  loop perform erp.refresh_contractor_issue_payroll_status(r.id); end loop;
  for r in select distinct pr.source_id id from erp.payroll_reimbursements pr
           where pr.payroll_id=p.id and pr.source_type='ACCESSORY_BOM' and pr.source_id is not null
  loop
    update erp.contractor_accessory_reimbursement_entitlements e
    set payroll_status=case
      when exists(select 1 from erp.payroll_reimbursements pr2 join erp.payroll_settlements ps2 on ps2.id=pr2.payroll_id
                  where pr2.source_type='ACCESSORY_BOM' and pr2.source_id=e.id and ps2.status='PAID') then 'SETTLED'
      when exists(select 1 from erp.payroll_reimbursements pr2 join erp.payroll_settlements ps2 on ps2.id=pr2.payroll_id
                  where pr2.source_type='ACCESSORY_BOM' and pr2.source_id=e.id and ps2.status<>'REVERSED') then 'ALLOCATED'
      else 'UNALLOCATED' end
    where e.id=r.id;
  end loop;
  for r in
    select distinct bc.id as bs_case_id from erp.bs_cases bc
    where exists(select 1 from erp.payroll_work_items pwi where pwi.payroll_id=p.id and pwi.po_id=bc.po_id)
       or exists(select 1 from erp.payroll_work_items pwi join erp.rework_component_lines rcl on rcl.id=pwi.source_id
                 join erp.bs_case_components bcc on bcc.id=rcl.bs_case_component_id
                 where pwi.payroll_id=p.id and bcc.bs_case_id=bc.id)
  loop perform erp.rebuild_bs_component_counters(r.bs_case_id); end loop;
  insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)
  values('payroll_settlements',p.id,'UPDATE',jsonb_build_object('previous_status','PAID','lifecycle_action','REOPEN_INSTALLMENT_SETTLEMENT','approved_cost_unchanged',true),erp.current_app_user_id(),p_reason);
end;
$function$
;

create function cp7_installment.source(p_id uuid) returns jsonb
language plpgsql stable security definer set search_path='' set TimeZone='UTC' as $$
declare h erp.payroll_settlements;a cp7_installment.accounts;r record;paid numeric(20,2):=0;rows jsonb:='[]';journals jsonb;lines jsonb;fingerprint jsonb;orig erp.journal_entries;inverse erp.journal_entries;state text;
begin
 select * into h from erp.payroll_settlements where id=p_id;
 if h.id is null then raise exception 'CP7_INSTALLMENT_PAYROLL_NOT_FOUND';end if;
 select * into a from cp7_installment.accounts where payroll_id=p_id;
 if a.payroll_id is not null then
  if a.approved_net is distinct from h.net_payable or a.approved_meaning is distinct from cp7_installment.meaning(p_id)then raise exception 'CP7_INSTALLMENT_APPROVED_SOURCE_CHANGED';end if;
  for r in select p.*,c.cash_account_code,c.cash_account_name from cp7_installment.payments p join erp.cash_accounts c on c.id=p.cash_account_id where p.payroll_id=p_id order by p.payment_date,p.created_at,p.id loop
   select * into orig from erp.journal_entries where id=r.journal_id;
   if orig.id is null or orig.reversal_of_id is not null
    or not(orig.source_type='PAYROLL_INSTALLMENT'and orig.source_id=r.id)
    or orig.economic_date is distinct from r.payment_date
    or(select count(*)from erp.journal_lines where journal_entry_id=orig.id)<>2
    or not exists(select 1 from erp.journal_lines where journal_entry_id=orig.id and account_id=a.payable_account_id and contractor_id=h.contractor_id and debit=r.amount and credit=0)
    or not exists(select 1 from erp.journal_lines where journal_entry_id=orig.id and account_id=r.cash_coa_id and contractor_id=h.contractor_id and credit=r.amount and debit=0)then raise exception 'CP7_INSTALLMENT_NATIVE_PAYMENT_SOURCE_MISMATCH';end if;
   inverse:=null;
   if r.reversal_journal_id is null then
    if orig.status<>'POSTED'or exists(select 1 from erp.journal_entries where reversal_of_id=orig.id)then raise exception 'CP7_INSTALLMENT_NATIVE_PAYMENT_SOURCE_MISMATCH';end if;
    paid:=paid+r.amount;
   else
    select * into inverse from erp.journal_entries where id=r.reversal_journal_id;
    if orig.status<>'REVERSED'or inverse.id is null or inverse.status<>'POSTED'or inverse.reversal_of_id is distinct from orig.id
     or(select count(*)from erp.journal_lines where journal_entry_id=inverse.id)<>2
     or not exists(select 1 from erp.journal_lines where journal_entry_id=inverse.id and account_id=a.payable_account_id and contractor_id=h.contractor_id and credit=r.amount and debit=0)
     or not exists(select 1 from erp.journal_lines where journal_entry_id=inverse.id and account_id=r.cash_coa_id and contractor_id=h.contractor_id and debit=r.amount and credit=0)then raise exception 'CP7_INSTALLMENT_NATIVE_PAYMENT_INVERSE_MISMATCH';end if;
   end if;
   rows:=rows||jsonb_build_array(jsonb_build_object('id',r.id,'amount',r.amount::text,'payment_date',r.payment_date,'cash_account_id',r.cash_account_id,'cash_account_code',r.cash_account_code,'cash_account_name',r.cash_account_name,
    'journal_id',orig.id,'journal_number',orig.journal_number,'status',orig.status,'economic_date',orig.economic_date,'accounting_date',orig.transaction_date,'posting_at',orig.posting_at,'period_shifted',orig.period_shifted,
    'reversal_journal_id',inverse.id,'reversal_journal_number',inverse.journal_number,'reversal_economic_date',inverse.economic_date,'reversal_accounting_date',inverse.transaction_date,'reversal_posting_at',inverse.posting_at));
  end loop;
  if exists(select 1 from erp.journal_entries j where j.source_type='PAYROLL_PAYMENT'and j.source_id=p_id and j.reversal_of_id is null and not exists(select 1 from cp7_installment.payments p where p.payroll_id=p_id and p.journal_id=j.id))then raise exception 'CP7_INSTALLMENT_UNTRACKED_NATIVE_PAYMENT';end if;
  if paid>a.approved_net or h.status not in('APPROVED','PAID','REVERSED')or(h.status='PAID'and paid<>a.approved_net)or(h.status='APPROVED'and paid>=a.approved_net)or(h.status='REVERSED'and paid<>0)then raise exception 'CP7_INSTALLMENT_NATIVE_STATUS_MISMATCH';end if;
 else
  -- Historic native full payments remain native facts; they are never imported
  -- as invented installment records or silently reported as unpaid/zero.
  select coalesce(sum(l.credit),0)into paid from erp.journal_entries j join erp.journal_lines l on l.journal_entry_id=j.id
   where j.source_type='PAYROLL_PAYMENT'and j.source_id=p_id and j.status='POSTED';
  if(h.status='PAID'and paid<>h.net_payable)or(h.status<>'PAID'and paid<>0)then raise exception 'CP7_INSTALLMENT_LEGACY_PAYMENT_MISMATCH';end if;
 end if;
 state:=case when h.status='REVERSED'then 'REVERSED'when h.status='PAID'then 'PAID'when paid>0 then 'PARTIAL'when h.status='APPROVED'then 'UNPAID'else 'NOT_APPROVED'end;
 select coalesce(jsonb_agg(to_jsonb(j)order by j.id),'[]')into journals from erp.journal_entries j
  where(j.source_id=p_id and j.source_type like 'PAYROLL_%')or j.id in(select p.journal_id from cp7_installment.payments p where p.payroll_id=p_id union select p.reversal_journal_id from cp7_installment.payments p where p.payroll_id=p_id);
 select coalesce(jsonb_agg(to_jsonb(l)order by l.id),'[]')into lines from erp.journal_lines l where l.journal_entry_id in(select(x->>'id')::uuid from jsonb_array_elements(journals)x);
 fingerprint:=jsonb_build_object('header',to_jsonb(h),'native_payroll_review',cp7_payroll.settlement_token(p_id),'approved_account',to_jsonb(a),'meaning',cp7_installment.meaning(p_id),'payments',rows,'journals',journals,'lines',lines,
  'cash_sources',coalesce((select jsonb_agg(cp7_installment.cash(p.cash_account_id)order by p.id)from cp7_installment.payments p where p.payroll_id=p_id),'[]'),
  'payable_mapping',coalesce((select jsonb_agg(to_jsonb(m)order by m.mapping_key)from erp.accounting_account_mappings m where m.mapping_key='CONTRACTOR_PAYABLE'),'[]'));
 return jsonb_build_object('payroll_id',h.id,'payroll_number',h.payroll_number,'contractor_id',h.contractor_id,'contractor_name',(select contractor_name from erp.contractors where id=h.contractor_id),
  'native_status',h.status,'payment_state',state,'managed',a.payroll_id is not null,'approved_net',h.net_payable::text,'paid_amount',paid::text,
  'remaining_amount',case when h.status in('APPROVED','PAID')then(h.net_payable-paid)::text end,'row_version',h.row_version::text,'source_review_token',cp7_payroll.settlement_token(p_id),'review_token',md5(fingerprint::text),'payments',rows);
end $$;

create function cp7_installment.workspace(p_query jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' set TimeZone='UTC' as $$
declare id uuid;off integer;coff integer;q text;d jsonb;payments jsonb;cash jsonb;ct bigint;pt bigint;
begin
 perform cp7_installment.access_now();
 if jsonb_typeof(p_query)is distinct from 'object'or not p_query ? 'payroll_id'
  or exists(select 1 from jsonb_object_keys(p_query)k where k not in('payroll_id','payment_offset','cash_offset','cash_query'))
  or jsonb_typeof(p_query->'payroll_id')is distinct from 'string'
  or(p_query->>'payroll_id')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or exists(select 1 from jsonb_each(p_query)e where e.key in('payment_offset','cash_offset')and(jsonb_typeof(e.value)<>'number'or e.value::text!~'^[0-9]{1,7}$'))
  or(p_query ? 'cash_query'and jsonb_typeof(p_query->'cash_query')is distinct from 'string')then raise exception 'CP7_INSTALLMENT_QUERY';end if;
 id:=(p_query->>'payroll_id')::uuid;off:=coalesce((p_query->>'payment_offset')::integer,0);coff:=coalesce((p_query->>'cash_offset')::integer,0);q:=btrim(coalesce(p_query->>'cash_query',''));
 if off not between 0 and 1000000 or coff not between 0 and 1000000 or length(q)>120 then raise exception 'CP7_INSTALLMENT_QUERY';end if;
 d:=cp7_installment.source(id);pt:=jsonb_array_length(d->'payments');
 select coalesce(jsonb_agg(value order by ordinal),'[]')into payments from(select value,ordinal from jsonb_array_elements(d->'payments')with ordinality a(value,ordinal)order by ordinal limit 25 offset off)s;
 with eligible as materialized(select cp7_installment.cash(c.id)value from erp.cash_accounts c),all_rows as materialized(select value from eligible where value->'eligible'='true'::jsonb and(q=''or strpos(lower(concat_ws(' ',value->>'code',value->>'name')),lower(q))>0)),slice as(select value from all_rows order by value->>'code',value->>'id'limit 25 offset coff)
 select(select count(*)from all_rows),coalesce((select jsonb_agg(value order by value->>'code',value->>'id')from slice),'[]')into ct,cash;
 return jsonb_build_object('contract_version','cp7.payroll-installment-read.v1','captured_at',statement_timestamp(),'document',d-'payments',
  'payments',jsonb_build_object('rows',payments,'total',pt::text,'offset',off,'limit',25,'next_offset',case when off+jsonb_array_length(payments)<pt then off+jsonb_array_length(payments)end),
  'cash_accounts',jsonb_build_object('rows',cash,'total',ct::text,'offset',coff,'limit',25,'next_offset',case when coff+jsonb_array_length(cash)<ct then coff+jsonb_array_length(cash)end),
  'capabilities',jsonb_build_object('pay',erp.has_permission('finance.payroll.pay'),'reverse_payroll',erp.has_permission('finance.payroll.pay')and erp.has_permission('finance.payroll.approve')));
end $$;

create function cp7_installment.validate(p_action text,p jsonb,p_expected text) returns void
language plpgsql immutable security invoker set search_path='' as $$
declare keys text[];k text;
begin
 keys:=array['payroll_id','review_token','change_reason'];
 if p_action='PAY'then keys:=keys||array['amount','payment_date','cash_account_id','cash_review_token'];
 elsif p_action='REVERSE_PAYMENT'then keys:=keys||array['payment_id'];
 elsif p_action is null or p_action<>'REVERSE_PAYROLL'then raise exception 'CP7_INSTALLMENT_ACTION';end if;
 if p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'or jsonb_typeof(p)is distinct from 'object'or not p ?& keys or exists(select 1 from jsonb_object_keys(p)x where x<>all(keys))then raise exception 'CP7_INSTALLMENT_FIELDS';end if;
 foreach k in array keys loop
  if jsonb_typeof(p->k)is distinct from 'string'then raise exception 'CP7_INSTALLMENT_FIELDS';end if;
  if k in('payroll_id','cash_account_id','payment_id')and(p->>k)!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'then raise exception 'CP7_INSTALLMENT_FIELDS';end if;
  if k in('review_token','cash_review_token')and(p->>k)!~'^[a-f0-9]{32}$'then raise exception 'CP7_INSTALLMENT_FIELDS';end if;
 end loop;
 if length(btrim(p->>'change_reason'))not between 5 and 1000 then raise exception 'CP7_INSTALLMENT_FIELDS';end if;
 if p_action='PAY'and((p->>'amount')!~'^(0|[1-9][0-9]{0,17})(\.[0-9]{1,2})?$'or(p->>'amount')::numeric<=0 or(p->>'payment_date')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$')then raise exception 'CP7_INSTALLMENT_FIELDS';end if;
end $$;

create function cp7_installment.apply_command(p_action text,p jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security definer set search_path='' set TimeZone='Asia/Jakarta' as $$
declare ident uuid:=(p->>'payroll_id')::uuid;h erp.payroll_settlements;a jsonb;d jsonb;cash jsonb;acct cp7_installment.accounts;payment cp7_installment.payments;
 amount numeric(20,2);remaining numeric(20,2);payment_id uuid;journal_id uuid;inverse_id uuid;pay_date date;native_action text;r record;
begin
 a:=cp7_installment.access_now(p_action);perform cp7_installment.validate(p_action,p,p_expected);
 if not exists(select 1 from cp7_installment.command_context c where c.backend_pid=pg_backend_pid()and c.transaction_id=txid_current()and c.actor=auth.uid()and c.request_id=p_request and c.action=p_action and c.payload=p and c.expected_version=p_expected)then raise exception using errcode='42501',message='CP7_INSTALLMENT_PRIVATE_CONTEXT_REQUIRED';end if;
 select * into h from erp.payroll_settlements where id=ident for update;
 if h.id is null then raise exception 'CP7_INSTALLMENT_PAYROLL_NOT_FOUND';end if;
 perform cp7_installment.require_context(ident);
 perform pg_advisory_xact_lock(hashtextextended(h.contractor_id::text,0));
 perform 1 from erp.payroll_work_items where payroll_id=ident order by id for update;
 perform 1 from erp.payroll_attendance_items where payroll_id=ident order by id for update;
 perform 1 from erp.payroll_reimbursements where payroll_id=ident order by id for update;
 perform 1 from erp.payroll_deductions where payroll_id=ident order by id for update;
 perform 1 from erp.opening_subledger_balances b where exists(select 1 from erp.payroll_deductions x where x.payroll_id=ident and x.opening_cash_advance_balance_id=b.id)or exists(select 1 from erp.payroll_reimbursements x where x.payroll_id=ident and x.opening_payable_balance_id=b.id)order by b.id for update;
 lock table erp.accounting_account_mappings in share mode;
 perform 1 from erp.cash_accounts c where c.id=(p->>'cash_account_id')::uuid or exists(select 1 from cp7_installment.payments x where x.payroll_id=ident and x.cash_account_id=c.id)order by c.id for share;
 perform 1 from erp.chart_accounts c where c.id in(select coa_account_id from erp.cash_accounts where id=(p->>'cash_account_id')::uuid union select cash_coa_id from cp7_installment.payments where payroll_id=ident union select account_id from erp.accounting_account_mappings where mapping_key='CONTRACTOR_PAYABLE')order by c.id for share;
 perform 1 from erp.journal_entries j where(j.source_id=ident and j.source_type like 'PAYROLL_%')or exists(select 1 from cp7_installment.payments x where x.payroll_id=ident and j.id in(x.journal_id,x.reversal_journal_id))order by j.id for update;
 perform 1 from erp.journal_lines l where exists(select 1 from erp.journal_entries j where j.id=l.journal_entry_id and((j.source_id=ident and j.source_type like 'PAYROLL_%')or exists(select 1 from cp7_installment.payments x where x.payroll_id=ident and j.id in(x.journal_id,x.reversal_journal_id))))order by l.id for update;
 if cp7_installment.access_now(p_action)is distinct from a then raise exception using errcode='42501',message='CP7_INSTALLMENT_ACCESS_CHANGED';end if;
 d:=cp7_installment.source(ident);
 if h.row_version::text is distinct from p_expected or d->>'review_token'is distinct from p->>'review_token'then raise exception 'CP7_INSTALLMENT_REVIEW_CHANGED';end if;
 perform set_config('app.change_reason',btrim(p->>'change_reason'),true);
 native_action:=case when p_action='REVERSE_PAYROLL'then case when h.status='PAID'then 'REVERSE'else 'CANCEL'end else 'PAY'end;
 -- Keep the accepted native admission predicates unchanged. This trusted apply
 -- creates their exact transaction-local payroll context after its own checks.
 insert into cp7_payroll.settlement_context values(pg_backend_pid(),txid_current(),auth.uid(),ident,native_action);
 if p_action='PAY'then
  if h.status<>'APPROVED'or h.net_payable<=0 then raise exception 'CP7_INSTALLMENT_APPROVED_POSITIVE_PAYROLL_ONLY';end if;
  cash:=cp7_installment.cash((p->>'cash_account_id')::uuid);
  if cash is null or cash->'eligible'is distinct from 'true'::jsonb or cash->>'review_token'is distinct from p->>'cash_review_token'then raise exception 'CP7_INSTALLMENT_CASH_SOURCE_CHANGED';end if;
  amount:=(p->>'amount')::numeric;
  begin pay_date:=(p->>'payment_date')::date;exception when datetime_field_overflow or invalid_datetime_format then raise exception 'CP7_INSTALLMENT_PAYMENT_DATE';end;
  if pay_date::text is distinct from p->>'payment_date'or pay_date>(statement_timestamp()at time zone 'Asia/Jakarta')::date then raise exception 'CP7_INSTALLMENT_PAYMENT_DATE';end if;
  if not(d->>'managed')::boolean then
   insert into cp7_installment.accounts(payroll_id,approved_meaning,approved_net,payable_account_id,created_by)
    values(ident,cp7_installment.meaning(ident),h.net_payable,erp.account_id('CONTRACTOR_PAYABLE'),auth.uid());
  end if;
  select * into acct from cp7_installment.accounts where payroll_id=ident;
  if erp.account_id('CONTRACTOR_PAYABLE')is distinct from acct.payable_account_id then raise exception 'CP7_INSTALLMENT_PAYABLE_MAPPING_CHANGED';end if;
  remaining:=(d->>'remaining_amount')::numeric;
  perform cp7_installment.assert_payment_amount(ident,amount,false);
  update erp.payroll_settlements set payment_date=pay_date,payment_cash_account_id=(p->>'cash_account_id')::uuid where id=ident;
  payment_id:=gen_random_uuid();
  update cp7_installment.command_context set native_payment_id=payment_id where backend_pid=pg_backend_pid()and transaction_id=txid_current();
  if amount=remaining then
   perform cp7_installment.final_payment(ident,amount);
   select id into journal_id from erp.journal_entries where source_type='PAYROLL_INSTALLMENT'and source_id=payment_id and status='POSTED';
  else
   perform cp7_installment.check_payment(ident,amount);
   journal_id:=erp.post_journal('PAYROLL_INSTALLMENT',payment_id,pay_date,'Cicilan payroll '||h.payroll_number,jsonb_build_array(
    jsonb_build_object('mapping_key','CONTRACTOR_PAYABLE','debit',amount,'credit',0,'contractor_id',h.contractor_id),
    jsonb_build_object('account_id',(cash->>'account_id')::uuid,'debit',0,'credit',amount,'contractor_id',h.contractor_id)));
  end if;
  if journal_id is null then raise exception 'CP7_INSTALLMENT_NATIVE_JOURNAL_MISSING';end if;
  insert into cp7_installment.payments(id,payroll_id,amount,payment_date,cash_account_id,cash_coa_id,journal_id,created_by,request_id)
   values(payment_id,ident,amount,pay_date,(p->>'cash_account_id')::uuid,(cash->>'account_id')::uuid,journal_id,auth.uid(),p_request);
  insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)values('payroll_settlements',ident,'POST',jsonb_build_object('lifecycle_action','PAY_INSTALLMENT','payment_id',payment_id,'amount',amount::text,'approved_net',h.net_payable::text,'approved_cost_unchanged',true),erp.current_app_user_id(),btrim(p->>'change_reason'));
 elsif p_action='REVERSE_PAYMENT'then
  if not(d->>'managed')::boolean or h.status not in('APPROVED','PAID')then raise exception 'CP7_INSTALLMENT_MANAGED_ACTIVE_PAYROLL_ONLY';end if;
  select * into payment from cp7_installment.payments where id=(p->>'payment_id')::uuid and payroll_id=ident for update;
  if payment.id is null or payment.reversal_journal_id is not null then raise exception 'CP7_INSTALLMENT_ACTIVE_PAYMENT_REQUIRED';end if;
  if h.status='PAID'then perform cp7_installment.reopen_settlement(ident,btrim(p->>'change_reason'));end if;
  perform erp.reverse_journal(payment.journal_id,btrim(p->>'change_reason'));
  select id into inverse_id from erp.journal_entries where reversal_of_id=payment.journal_id and status='POSTED';
  if inverse_id is null then raise exception 'CP7_INSTALLMENT_NATIVE_INVERSE_MISSING';end if;
  update cp7_installment.payments set reversal_journal_id=inverse_id where id=payment.id;payment_id:=payment.id;
  update erp.payroll_settlements set status='APPROVED',settled_at=null,updated_at=statement_timestamp()where id=ident;
 elsif p_action='REVERSE_PAYROLL'then
  if not(d->>'managed')::boolean or h.status not in('APPROVED','PAID')then raise exception 'CP7_INSTALLMENT_MANAGED_ACTIVE_PAYROLL_ONLY';end if;
  -- Native owning-flow dependency guard runs before any cash effect.
  if exists(select 1 from erp.attendance_hpp_pool_sources s join erp.attendance_hpp_pools hp on hp.id=s.pool_id where s.payroll_id=ident and hp.status='ACTIVE')then raise exception 'PAYROLL_CONSUMED_BY_ACTIVE_HPP_POOL: cancel the active attendance HPP pool first';end if;
  for r in select * from cp7_installment.payments where payroll_id=ident and reversal_journal_id is null order by created_at desc,id desc loop
   perform erp.reverse_journal(r.journal_id,btrim(p->>'change_reason'));
   select id into inverse_id from erp.journal_entries where reversal_of_id=r.journal_id and status='POSTED';
   if inverse_id is null then raise exception 'CP7_INSTALLMENT_NATIVE_INVERSE_MISSING';end if;
   update cp7_installment.payments set reversal_journal_id=inverse_id where id=r.id;
  end loop;
  if h.status='PAID'then perform erp.reverse_paid_payroll(ident,btrim(p->>'change_reason'));else perform erp.cancel_unpaid_payroll(ident,btrim(p->>'change_reason'));end if;
 end if;
 delete from cp7_payroll.settlement_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_installment.access_now(p_action)is distinct from a then raise exception using errcode='42501',message='CP7_INSTALLMENT_ACCESS_CHANGED';end if;
 d:=cp7_installment.source(ident);
 return jsonb_build_object('payroll_id',ident,'payment_id',payment_id,'native_status',d->>'native_status','payment_state',d->>'payment_state','row_version',d->>'row_version','review_token',d->>'review_token');
end $$;

create function cp7_installment.command(p_action text,p jsonb,p_request uuid,p_expected text) returns jsonb
language plpgsql volatile security invoker set search_path='' as $$
declare a jsonb;old cp7_installment.requests;d jsonb;r jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_installment.access_now(p_action);perform cp7_installment.validate(p_action,p,p_expected);
 if p_request is null then raise exception 'CP7_INSTALLMENT_REQUEST_REQUIRED';end if;
 insert into cp7_installment.requests values(auth.uid(),p_request,p_action,p,p_expected,null)on conflict do nothing;
 select * into old from cp7_installment.requests where actor=auth.uid()and request_id=p_request for update;
 if old.action is distinct from p_action or old.payload is distinct from p or old.expected_version is distinct from p_expected then raise exception 'CP7_INSTALLMENT_REQUEST_CHANGED';end if;
 if cp7_installment.access_now(p_action)is distinct from a then raise exception using errcode='42501',message='CP7_INSTALLMENT_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 insert into cp7_installment.command_context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,p_action,p,p_expected,null);
 d:=cp7_installment.apply_command(p_action,p,p_request,p_expected);
 delete from cp7_installment.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_installment.access_now(p_action)is distinct from a then raise exception using errcode='42501',message='CP7_INSTALLMENT_ACCESS_CHANGED';end if;
 r:=jsonb_build_object('contract_version','cp7.payroll-installment-outcome.v1','kind','COMMITTED_OUTCOME','action',p_action,'request_id',p_request,'request_payload',p,'expected_version',p_expected)||d;
 update cp7_installment.requests set response=r where actor=auth.uid()and request_id=p_request;
 return r;
end $$;

create function public.erp_cp7_get_payroll_installments_v1(p_query jsonb) returns jsonb
language sql stable security definer set search_path='' as $$select cp7_installment.workspace(p_query)$$;
create function public.erp_cp7_save_payroll_installment_v1(p_action text,p_payload jsonb,p_request uuid,p_expected text) returns jsonb
language sql volatile security definer set search_path='' as $$select cp7_installment.command(p_action,p_payload,p_request,p_expected)$$;

do $owners$ declare r record;begin
 for r in select p.oid::regprocedure signature,p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='cp7_installment'loop
  execute format('alter function %s owner to %I',r.signature,case when r.proname in('apply_command','check_payment','final_payment','reopen_settlement')then 'postgres'when r.proname='command'then 'cp7_installment_write'else 'cp7_installment_read'end);
  execute format('revoke all on function %s from public,anon,authenticated,service_role,cp7_capture',r.signature);
 end loop;
end $owners$;
grant create on schema public to cp7_installment_read,cp7_installment_write;
alter function public.erp_cp7_get_payroll_installments_v1(jsonb)owner to cp7_installment_read;
alter function public.erp_cp7_save_payroll_installment_v1(text,jsonb,uuid,text)owner to cp7_installment_write;
revoke create on schema public from cp7_installment_read,cp7_installment_write;
grant execute on function cp7_installment.access_now(text),cp7_installment.validate(text,jsonb,text),cp7_installment.apply_command(text,jsonb,uuid,text)to cp7_installment_write;
grant usage on schema cp7_installment,cp7_payroll,cp7_misc to postgres;
grant select on cp7_installment.requests,cp7_installment.command_context to postgres;
grant update(native_payment_id)on cp7_installment.command_context to postgres;
grant insert,delete on cp7_payroll.settlement_context to postgres;
grant execute on all functions in schema cp7_installment to postgres;
grant execute on function cp7_misc.cash(uuid)to postgres;
revoke all on function public.erp_cp7_get_payroll_installments_v1(jsonb),public.erp_cp7_save_payroll_installment_v1(text,jsonb,uuid,text)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_payroll_installments_v1(jsonb),public.erp_cp7_save_payroll_installment_v1(text,jsonb,uuid,text)to authenticated;

-- Owning correction command. Original posted quantities/prices are never edited.
-- Every inverse/replacement uses accepted writers in this same transaction.
create schema cp7_note authorization cp7_sales_write;
revoke all on schema cp7_note from public,anon,authenticated,service_role,cp7_capture;
create table cp7_note.requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,expected_version text not null,
 response jsonb,primary key(actor,request_id)
);
create table cp7_note.revisions(
 id uuid primary key default gen_random_uuid(),root_sale_id uuid not null references erp.sales_headers,
 previous_sale_id uuid not null unique references erp.sales_headers,
 replacement_sale_id uuid not null unique references erp.sales_headers,
 revision bigint not null,actor uuid not null,request_id uuid not null,reason text not null,
 effective_at timestamptz not null,recorded_at timestamptz not null default clock_timestamp(),
 unique(root_sale_id,revision),unique(actor,request_id)
);
create table cp7_note.context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 source_sale_id uuid not null,primary key(backend_pid,transaction_id)
);
create table cp7_note.helper_sources(native_signature text primary key,native_definition_sha256 text not null);
create table cp7_note.journal_restatements(
 inverse_journal_id uuid primary key references erp.journal_entries,
 source_journal_id uuid not null unique references erp.journal_entries,
 previous_sale_id uuid not null references erp.sales_headers,
 neutral_journal_id uuid not null unique references erp.journal_entries,
 effective_journal_id uuid not null unique references erp.journal_entries,
 native_economic_date date not null,corrected_economic_date date not null,
 recorded_at timestamptz not null default clock_timestamp()
);
create index note_journal_source on cp7_note.journal_restatements(previous_sale_id);
-- Note replay is reversal plus a fresh use of the same original funding.
-- Native replaces_payment_id is reserved for cash reallocation at the reversal
-- date and explicitly excludes imported advances. Keep note lineage here.
create table cp7_note.payment_replays(
 previous_payment_id uuid primary key references erp.sales_payments,
 replacement_payment_id uuid not null unique references erp.sales_payments,
 correction_id uuid not null references cp7_note.revisions(id)deferrable initially deferred,
 recorded_at timestamptz not null default clock_timestamp()
);
-- postgres is a non-superuser Native business executor on Supabase. Own only
-- this private command's metadata; the low public wrapper obtains no table DML.
alter table cp7_note.requests owner to postgres;
alter table cp7_note.revisions owner to postgres;
alter table cp7_note.context owner to postgres;
alter table cp7_note.helper_sources owner to postgres;
alter table cp7_note.journal_restatements owner to postgres;
alter table cp7_note.payment_replays owner to postgres;
alter table cp7_note.requests enable row level security;
alter table cp7_note.revisions enable row level security;
alter table cp7_note.context enable row level security;
alter table cp7_note.helper_sources enable row level security;
alter table cp7_note.journal_restatements enable row level security;
alter table cp7_note.payment_replays enable row level security;
create policy private_requests on cp7_note.requests for all using(false)with check(false);
create policy private_revisions on cp7_note.revisions for all using(false)with check(false);
create policy private_context on cp7_note.context for all using(false)with check(false);
create policy private_helper_sources on cp7_note.helper_sources for all using(false)with check(false);
create policy private_journal_restatements on cp7_note.journal_restatements for all using(false)with check(false);
create policy private_payment_replays on cp7_note.payment_replays for all using(false)with check(false);
revoke all on all tables in schema cp7_note from public,anon,authenticated,service_role,cp7_capture;

create function cp7_note.immutable_revision()returns trigger
language plpgsql security invoker set search_path=''as $$
begin raise exception 'CP7_NOTE_POSTED_REVISION_IMMUTABLE';end $$;
create trigger immutable_revision before update or delete on cp7_note.revisions
 for each row execute function cp7_note.immutable_revision();
create trigger immutable_journal_restatement before update or delete on cp7_note.journal_restatements
 for each row execute function cp7_note.immutable_revision();
create trigger immutable_payment_replay before update or delete on cp7_note.payment_replays
 for each row execute function cp7_note.immutable_revision();

create function cp7_note.access_now()returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;k text;
begin
 if auth.uid()is null or coalesce(auth.jwt()->>'role','')<>'authenticated'
  then raise exception using errcode='42501',message='CP7_NOTE_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed'is distinct from'true'::jsonb or erp.has_permission('sales.invoice.view')is distinct from true then
  raise exception using errcode='42501',message='CP7_SALES_ACCESS_DENIED';end if;
 if coalesce(a->'profile'->>'role_code','')not in('OWNER','ADMIN')then
  raise exception using errcode='42501',message='CP7_NOTE_OWNER_ADMIN_REQUIRED';end if;
 foreach k in array array['sales.invoice.view','sales.invoice.create','sales.invoice.edit_draft',
  'sales.invoice.post','sales.invoice.reverse','finance.ar.view','finance.hpp.view']loop
  if erp.has_permission(k)is distinct from true then raise exception using errcode='42501',message='CP7_NOTE_ACCESS_DENIED';end if;
 end loop;
 return a;
end $$;
create function cp7_note.require_context()returns void
language plpgsql volatile security definer set search_path=''as $$
begin
 perform cp7_note.access_now();
 if not exists(select 1 from cp7_note.context where backend_pid=pg_backend_pid()
  and transaction_id=txid_current()and actor=auth.uid())then
  raise exception using errcode='42501',message='CP7_NOTE_PRIVATE_CONTEXT_REQUIRED';end if;
end $$;

-- Generic Native reversals keep their accepted current economic date, posting
-- fact and lineage. A source-owned pair moves that exact inverse's economic
-- effect to the original date without changing one Native line or whole-ledger
-- amount. Native post_journal retains its closed-period/open-GL-date rule.
create function cp7_note.restate_reversal(p_source uuid,p_inverse uuid,p_reason text)returns void
language plpgsql volatile security definer set search_path=''as $$
declare original erp.journal_entries%rowtype;inverse erp.journal_entries%rowtype;
 leaf uuid;neutral uuid;effective uuid;lines jsonb;
begin
 perform cp7_note.require_context();
 select source_sale_id into strict leaf from cp7_note.context
  where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid();
 select *into strict original from erp.journal_entries where id=p_source;
 select *into strict inverse from erp.journal_entries where id=p_inverse;
 if original.status<>'REVERSED'or inverse.status<>'POSTED'
  or inverse.source_type<>'JOURNAL_REVERSAL'or inverse.source_id<>original.id
  or inverse.reversal_of_id is distinct from original.id
  or not(original.source_type='SALE'and original.source_id=leaf
   or original.source_type='SALES_RETURN'and exists(select 1 from erp.sales_returns where id=original.source_id and sale_id=leaf)
   or original.source_type='SALES_PAYMENT'and exists(select 1 from erp.sales_payments where id=original.source_id and sale_id=leaf))then
  raise exception 'CP7_NOTE_JOURNAL_SOURCE_CHANGED';end if;
 if original.economic_date=inverse.economic_date then return;end if;
 -- Undo the inverse only in its current economic period, from its exact lines.
 select jsonb_agg(jsonb_build_object('account_id',j.account_id,'debit',j.credit,'credit',j.debit,
  'description',j.description,'customer_id',j.customer_id,'vendor_id',j.vendor_id,
  'contractor_id',j.contractor_id,'po_id',j.po_id,'product_id',j.product_id)order by j.id)into lines
 from erp.journal_lines j where j.journal_entry_id=inverse.id;
 neutral:=erp.post_journal('NOTE_REVERSAL_TIME_NEUTRAL',inverse.id,inverse.economic_date,
  'Pembetulan nota: pindahkan waktu ekonomi pembalikan | '||p_reason,lines);
 -- Apply the same inverse exactly in the original economic period.
 select jsonb_agg(jsonb_build_object('account_id',j.account_id,'debit',j.debit,'credit',j.credit,
  'description',j.description,'customer_id',j.customer_id,'vendor_id',j.vendor_id,
  'contractor_id',j.contractor_id,'po_id',j.po_id,'product_id',j.product_id)order by j.id)into lines
 from erp.journal_lines j where j.journal_entry_id=inverse.id;
 effective:=erp.post_journal('NOTE_REVERSAL_EFFECTIVE',inverse.id,original.economic_date,
  'Pembetulan nota: waktu ekonomi kejadian asal | '||p_reason,lines);
 insert into cp7_note.journal_restatements values(inverse.id,original.id,leaf,neutral,effective,
  inverse.economic_date,original.economic_date,clock_timestamp());
end $$;

-- Copy the actual accepted Native definitions into this private namespace.
-- Original definitions/owners/ACLs are untouched. Scope physical/HPP inverse
-- dates, exact-line economic reclassification, helper calls and admission.
do $derive$
declare signature text;definition text;body text;changed text;name text;
begin
 foreach signature in array array['erp.reverse_fg_movement(uuid,text)',
  'erp._cp3_r4_reverse_journal_internal(uuid,text)','erp.reverse_journal(uuid,text)',
  'erp.reverse_sale(uuid,text)','erp.reverse_sales_return(uuid,text)','erp.reverse_sales_payment(uuid,text)']loop
  select pg_get_functiondef(oid),prosrc into strict definition,body from pg_proc where oid=signature::regprocedure;
  name:=split_part(split_part(signature,'.',2),'(',1);
  changed:=regexp_replace(body,'\m[Bb][Ee][Gg][Ii][Nn]\M',E'begin\n perform cp7_note.require_context();');
  if changed=body then raise exception 'CP7_NOTE_NATIVE_HELPER_BODY_CHANGED';end if;
  changed:=replace(changed,'erp.reverse_fg_movement(','cp7_note.reverse_fg_movement(');
  changed:=replace(changed,'erp.reverse_journal(','cp7_note.reverse_journal(');
  changed:=replace(changed,'erp._cp3_r4_reverse_journal_internal(','cp7_note._cp3_r4_reverse_journal_internal(');
  if name='reverse_fg_movement'then
   if length(body)-length(replace(body,'clock_timestamp()',''))<>length('clock_timestamp()')then
    raise exception 'CP7_NOTE_NATIVE_FG_CLOCK_CHANGED';end if;
   changed:=replace(changed,'clock_timestamp()','m.physical_at');
  elsif name='_cp3_r4_reverse_journal_internal'then
   if body!~*'\mcurrent_date\M'and strpos(body,'statement_timestamp() AT TIME ZONE')=0
    and strpos(body,'erp._cp3_business_date(current_timestamp)')=0
    and strpos(body,'erp._cp3_business_date(statement_timestamp())')=0 then raise exception 'CP7_NOTE_NATIVE_JOURNAL_CLOCK_CHANGED';end if;
   if strpos(body,'RETURN v_new_id;')=0 then raise exception 'CP7_NOTE_NATIVE_JOURNAL_RETURN_CHANGED';end if;
   changed:=replace(changed,'RETURN v_new_id;',
    'PERFORM cp7_note.restate_reversal(p_journal_entry_id,v_new_id,p_reason); RETURN v_new_id;');
  elsif name in('reverse_sale','reverse_sales_return')then
   if strpos(body,'statement_timestamp() AT TIME ZONE')=0 then raise exception 'CP7_NOTE_NATIVE_HPP_CLOCK_CHANGED';end if;
   changed:=replace(changed,$$((statement_timestamp() AT TIME ZONE 'Asia/Jakarta'::text))::date$$,
    case when name='reverse_sale'then $$((h.sale_date AT TIME ZONE 'Asia/Jakarta'::text))::date$$
    else $$((h.physical_at AT TIME ZONE 'Asia/Jakarta'::text))::date$$ end);
  end if;
  definition:=replace(definition,body,changed);
  definition:=replace(definition,'FUNCTION erp.'||name||'(','FUNCTION cp7_note.'||name||'(');
  execute definition;
  -- The disposable accepted installer is deliberately not postgres. Private
  -- copies run only under the admitted owning command; pin ownership rather
  -- than inherit the installer identity. Preserve Native security/config.
  execute format('alter function cp7_note.%I(uuid,text)owner to postgres',name);
  insert into cp7_note.helper_sources values(signature,encode(pg_catalog.sha256(convert_to(pg_get_functiondef(signature::regprocedure),'UTF8')),'hex'));
 end loop;
end $derive$;

create function cp7_note.workspace(p_sale uuid)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;root uuid;leaf uuid;history jsonb;native jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_note.access_now();
 if p_sale is null then raise exception 'CP7_NOTE_SOURCE_REQUIRED';end if;
 select root_sale_id into root from cp7_note.revisions where replacement_sale_id=p_sale or previous_sale_id=p_sale order by revision desc limit 1;
 root:=coalesce(root,p_sale);
 select replacement_sale_id into leaf from cp7_note.revisions where root_sale_id=root order by revision desc limit 1;
 leaf:=coalesce(leaf,root);
 native:=public.erp_cp7_get_sales_v1(jsonb_build_object('sale_id',leaf,'limit',1,'offset',0));
 select coalesce(jsonb_agg(jsonb_build_object('revision_id',id,'revision',revision::text,
  'previous_sale_id',previous_sale_id,'replacement_sale_id',replacement_sale_id,
  'effective_at',effective_at,'recorded_at',recorded_at,'reason',reason)order by revision),'[]')into history
 from cp7_note.revisions where root_sale_id=root;
 if cp7_note.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_NOTE_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.note-correction-workspace.v1','read_at',clock_timestamp(),
  'root_sale_id',root,'current_sale_id',leaf,'history',history,'current',native,
  'original_note_number',(select sale_number from erp.sales_headers where id=root),'production_go',false);
end $$;

create function cp7_note.command(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;old cp7_note.requests%rowtype;h erp.sales_headers%rowtype;root uuid;leaf uuid;
 revision bigint;replaced uuid;native_request uuid;result jsonb;draft jsonb;line jsonb;payment record;returned record;
 paid jsonb;returns jsonb;returned_lines jsonb;new_payment uuid;new_return uuid;new_return_item uuid;allocation uuid;
 return_lineage jsonb:='{}'::jsonb;
 correction_id uuid:=gen_random_uuid();before_movements uuid[];origin record;new_move record;anchor uuid;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_note.access_now();perform cp7_sales.validate_draft(p_payload-'item_lineage',true);
 if p_request is null or p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'then raise exception 'CP7_NOTE_REQUEST_REQUIRED';end if;
 insert into cp7_note.requests values(auth.uid(),p_request,p_payload,p_expected,null)on conflict do nothing;
 select *into strict old from cp7_note.requests where actor=auth.uid()and request_id=p_request for update;
 if old.payload is distinct from p_payload or old.expected_version is distinct from p_expected then raise exception 'CP7_NOTE_REQUEST_CHANGED';end if;
 if cp7_note.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_NOTE_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 perform pg_advisory_xact_lock(hashtextextended('FG_HPP_SALES_V2620C',0));
 perform pg_advisory_xact_lock(hashtextextended('FGBOOK|GLOBAL',0));
 if cp7_note.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_NOTE_ACCESS_CHANGED';end if;
 leaf:=(p_payload->>'sale_id')::uuid;
 perform 1 from erp.sales_payments where sale_id=leaf order by id for update;
 perform 1 from erp.sales_returns where sale_id=leaf order by id for update;
 select *into h from erp.sales_headers where id=leaf for update;
 if h.id is null or h.status not in('POSTED','PARTIAL_PAID','PAID')then raise exception 'CP7_NOTE_ACTIVE_POSTED_ONLY';end if;
 if h.row_version::text<>p_expected or cp7_sales.review_token(h.id)<>p_payload->>'review_token'then raise exception 'CP7_NOTE_REVIEW_CHANGED';end if;
 -- Historical correction keeps the actual original event identity/time.
 if p_payload->>'sale_number'is distinct from h.sale_number
  or(p_payload->>'sale_date')::timestamptz is distinct from h.sale_date
  or(p_payload->>'customer_id')::uuid is distinct from h.customer_id
  or(p_payload->>'source_location_id')::uuid is distinct from h.source_location_id then raise exception 'CP7_NOTE_SOURCE_IDENTITY_CHANGED';end if;
 select root_sale_id into root from cp7_note.revisions where replacement_sale_id=leaf;
 root:=coalesce(root,leaf);
 select coalesce(max(r.revision),0)+1 into revision from cp7_note.revisions r where r.root_sale_id=root;
 if exists(select 1 from cp7_note.revisions where previous_sale_id=leaf)then raise exception 'CP7_NOTE_SOURCE_SUPERSEDED';end if;
 if exists(select 1 from erp.sales_payments where sale_id=leaf and status='DRAFT')
  or exists(select 1 from erp.sales_returns where sale_id=leaf and status='DRAFT')then
  raise exception 'CP7_NOTE_PENDING_CHILD_REVIEW_REQUIRED';end if;
 -- A native cash reallocation is journaled at its predecessor's reversal date.
 -- Replaying it here would move that cash back to the original receipt clock;
 -- like payment correction, such a payment stays outside this command.
 if exists(select 1 from erp.sales_payments where sale_id=leaf and status='POSTED'and replaces_payment_id is not null)then
  raise exception 'CP7_NOTE_REALLOCATED_PAYMENT_REVIEW_REQUIRED';end if;
 select coalesce(jsonb_agg(to_jsonb(p)||jsonb_build_object('advance_id',l.advance_id)order by p.payment_date,p.id),'[]')into paid
 from erp.sales_payments p left join erp.initial_import_prepayment_payments l on l.payment_id=p.id
 where p.sale_id=leaf and p.status='POSTED';
 select coalesce(jsonb_agg(to_jsonb(r)||jsonb_build_object('items',
  (select jsonb_agg(to_jsonb(i)||jsonb_build_object('allocation_location_id',x.location_id)order by i.id)
    from erp.sales_return_items i join erp.sale_stock_allocations x on x.id=i.sale_stock_allocation_id where i.return_id=r.id))order by r.physical_at,r.id),'[]')into returns
 from erp.sales_returns r where r.sale_id=leaf and r.status='POSTED';
 select array_agg(m.id)into before_movements from erp.fg_stock_movements m where
  (m.source_type='SALE_ITEM'and exists(select 1 from erp.sales_items i where i.id=m.source_id and i.sale_id=leaf)
   or m.source_type='SALES_RETURN_ITEM'and exists(select 1 from erp.sales_return_items i join erp.sales_returns r on r.id=i.return_id where i.id=m.source_id and r.sale_id=leaf and r.status='POSTED'))
  and m.movement_type in('SALE','SALE_RETURN')and not exists(select 1 from erp.fg_stock_movements rv where rv.reversal_of_id=m.id);
 insert into cp7_note.context values(pg_backend_pid(),txid_current(),auth.uid(),leaf);
 insert into cp7_sales.command_context values(pg_backend_pid(),txid_current(),auth.uid(),leaf,'SALE_REVERSE');
 perform set_config('app.change_reason',p_payload->>'change_reason',true);
 -- Remove active children before reversing the invoice, then restore their
 -- immutable original physical inputs onto its replacement in one command.
 for payment in select *from jsonb_to_recordset(paid)as p(id uuid)loop
  perform cp7_sales.command_access('PAYMENT_REVERSE');perform cp7_note.reverse_sales_payment(payment.id,p_payload->>'change_reason');
 end loop;
 for returned in select *from jsonb_to_recordset(returns)as r(id uuid)loop
  perform cp7_sales.command_access('RETURN_REVERSE');perform cp7_note.reverse_sales_return(returned.id,p_payload->>'change_reason');
 end loop;
 perform cp7_note.reverse_sale(leaf,p_payload->>'change_reason');
 native_request:=md5(auth.uid()::text||':NOTE:'||p_request::text)::uuid;
 draft:=(p_payload-'sale_id'-'review_token'-'change_reason'-'item_lineage')||jsonb_build_object('sale_number',left((select sale_number from erp.sales_headers where id=root),38)||' · R'||revision::text||'-'||left(p_request::text,8),'reason',p_payload->>'change_reason');
 result:=erp.save_sale_draft_v2(draft,native_request,null);
 replaced:=(result->>'sale_id')::uuid;
 perform cp7_note.bind_items(leaf,replaced,correction_id,p_payload->'items',p_payload->'item_lineage');
 perform erp.post_sale(replaced);
 for returned in select value from jsonb_array_elements(returns)loop
  perform cp7_sales.command_access('RETURN');
  insert into erp.sales_returns(return_number,sale_id,customer_id,physical_at,notes,status,created_by)
  values(left(returned.value->>'return_number',38)||' · K-'||left(p_request::text,8),replaced,h.customer_id,
   (returned.value->>'physical_at')::timestamptz,returned.value->>'notes','DRAFT',erp.current_app_user_id())returning id into new_return;
  for line in select value from jsonb_array_elements(returned.value->'items')loop
   select x.id into allocation from erp.sale_stock_allocations x join erp.sales_items i on i.id=x.sale_item_id
    where i.sale_id=replaced and i.product_id=(line->>'product_id')::uuid and x.lot_id=(line->>'lot_id')::uuid
     and x.location_id=(line->>'allocation_location_id')::uuid
     and x.sale_item_id=(select l.replacement_item_id from cp7_note.item_lineage l
      join erp.sale_stock_allocations prior_allocation on prior_allocation.sale_item_id=l.previous_item_id
      where prior_allocation.id=(line->>'sale_stock_allocation_id')::uuid and l.replacement_item_id=x.sale_item_id)
     and not exists(select 1 from erp.sales_return_items z where z.return_id=new_return and z.sale_stock_allocation_id=x.id)
     and x.qty_pcs>=
      (line->>'qty_pcs')::integer+coalesce((select sum(z.qty_pcs)from erp.sales_return_items z where z.sale_stock_allocation_id=x.id),0)
    order by x.id limit 1;
   if allocation is null then raise exception 'CP7_NOTE_RETURN_ALLOCATION_CHANGED';end if;
   -- The refund was agreed for the old net price of each returned piece.
   -- Replaying it onto a line sold at another net price would overstate (or
   -- refuse) receivable without anyone seeing it: correct the return first.
   if exists(select 1 from erp.sale_stock_allocations old_x join erp.sales_items o on o.id=old_x.sale_item_id,
     erp.sale_stock_allocations new_x join erp.sales_items n on n.id=new_x.sale_item_id
    where old_x.id=(line->>'sale_stock_allocation_id')::uuid and new_x.id=allocation
     and(o.qty_pcs*o.unit_price_snapshot-coalesce(o.discount_amount,0))*n.qty_pcs
      <>(n.qty_pcs*n.unit_price_snapshot-coalesce(n.discount_amount,0))*o.qty_pcs)then
    raise exception 'CP7_NOTE_RETURNED_LINE_PRICE_CHANGED';end if;
   insert into erp.sales_return_items(return_id,sale_stock_allocation_id,product_id,lot_id,location_id,qty_pcs,quality_grade,refund_amount,notes)
   values(new_return,allocation,(line->>'product_id')::uuid,(line->>'lot_id')::uuid,(line->>'location_id')::uuid,
    (line->>'qty_pcs')::integer,line->>'quality_grade',(line->>'refund_amount')::numeric,line->>'notes')returning id into new_return_item;
   return_lineage:=return_lineage||jsonb_build_object(new_return_item::text,line->>'id');
  end loop;
  perform erp.post_sales_return(new_return);
 end loop;
 for payment in select value from jsonb_array_elements(paid)loop
  perform cp7_sales.command_access('PAYMENT');
  insert into erp.sales_payments(sale_id,payment_number,payment_date,amount,cash_account_id,payment_method,reference_number,notes,status,created_by)
  values(replaced,left(payment.value->>'payment_number',38)||' · K-'||left(p_request::text,8),
   (payment.value->>'payment_date')::timestamptz,(payment.value->>'amount')::numeric,(payment.value->>'cash_account_id')::uuid,
   payment.value->>'payment_method',payment.value->>'reference_number',payment.value->>'notes','DRAFT',erp.current_app_user_id())returning id into new_payment;
  if payment.value->>'advance_id'is not null then
   -- Same original wallet and amount. Accepted Native funding validation locks
   -- it, checks its actual remaining amount/customer/source snapshot and dates,
   -- and posts liability/AR rather than cash. No opening balance is edited.
   insert into erp.initial_import_prepayment_payments(payment_id,advance_id,sales_payment_id,payment_snapshot)
   select new_payment,(payment.value->>'advance_id')::uuid,new_payment,to_jsonb(p)-'status'
   from erp.sales_payments p where p.id=new_payment;
  end if;
  perform erp.post_sales_payment(new_payment);
  insert into cp7_note.payment_replays(previous_payment_id,replacement_payment_id,correction_id)
  values((payment.value->>'id')::uuid,new_payment,correction_id);
 end loop;
 -- Collapse compensating movements under their original source card. A newly
 -- added SKU gets its own Native card inserted beside this note's source,
 -- using the accepted move writer. Unrelated manual order is never reset.
 -- Original quantity, recorded clock and posted price are never edited.
 for new_move in select m.*from erp.fg_stock_movements m where m.reversal_of_id=any(coalesce(before_movements,'{}'::uuid[]))
  or m.source_type='SALE_ITEM'and exists(select 1 from erp.sales_items i where i.id=m.source_id and i.sale_id=replaced)
  or exists(select 1 from erp.fg_stock_movements reservation join erp.sales_items i on i.id=reservation.source_id
    where reservation.id=m.reversal_of_id and reservation.source_type='SALE_ITEM'and i.sale_id=replaced)
  or m.source_type='SALES_RETURN_ITEM'and exists(select 1 from erp.sales_return_items i join erp.sales_returns r on r.id=i.return_id where i.id=m.source_id and r.sale_id=replaced)
  order by case when m.movement_type='SALE'and m.reversal_of_id is null then 0
    when m.reversal_of_id is null then 1 else 2 end,m.system_created_at,m.id loop
  anchor:=null;
  if new_move.reversal_of_id is not null then
   select coalesce(l.origin_id,new_move.reversal_of_id)into anchor from(select 1)x left join cp7_fg.correction_movements l on l.member_id=new_move.reversal_of_id;
  elsif new_move.source_type='SALE_ITEM'and exists(select 1 from erp.sales_items where id=new_move.source_id and sale_id=replaced)then
   anchor:=cp7_note.line_origin(leaf,new_move.source_id,new_move.product_id,new_move.lot_id,new_move.location_id,new_move.quality_grade);
   if anchor is null then
    select coalesce(l.origin_id,m.id)into anchor from erp.fg_stock_movements m join erp.sales_items i on i.id=m.source_id
     left join cp7_fg.correction_movements l on l.member_id=m.id
     where i.sale_id=replaced and i.id=new_move.source_id and m.movement_type='SALE'and m.product_id=new_move.product_id
      and m.location_id=new_move.location_id and m.quality_grade=new_move.quality_grade
     order by(m.lot_id=new_move.lot_id)desc,m.book_order,m.id limit 1;
    if anchor=new_move.id then
     select coalesce(l.origin_id,m.id) as origin_id into origin from erp.fg_stock_movements m join erp.sales_items i on i.id=m.source_id
      left join cp7_fg.correction_movements l on l.member_id=m.id
      where i.sale_id=leaf and m.movement_type='SALE'order by m.book_order,m.id limit 1;
     if origin.origin_id is null then raise exception 'CP7_NOTE_ORIGINAL_BOOK_SOURCE_REQUIRED';end if;
     perform erp.move_fg_stock_card_row_to_position(new_move.id,cp7_fg.book_anchor(new_move.id,origin.origin_id,'AFTER'));
    end if;
   end if;
  elsif new_move.source_type='SALES_RETURN_ITEM'then
   select coalesce(l.origin_id,m.id)into anchor from erp.fg_stock_movements m join erp.sales_return_items i on i.id=m.source_id join erp.sales_returns r on r.id=i.return_id
    left join cp7_fg.correction_movements l on l.member_id=m.id where r.sale_id=leaf and i.id=(return_lineage->>new_move.source_id::text)::uuid and m.movement_type='SALE_RETURN'
     and m.product_id=new_move.product_id and m.lot_id is not distinct from new_move.lot_id and m.location_id=new_move.location_id
     and m.quality_grade=new_move.quality_grade and m.physical_at=new_move.physical_at order by m.book_order,m.id limit 1;
  end if;
  if anchor is not null and anchor<>new_move.id then insert into cp7_fg.correction_movements values(new_move.id,anchor,correction_id,clock_timestamp());end if;
 end loop;
 if cp7_note.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_NOTE_ACCESS_CHANGED';end if;
 insert into cp7_note.revisions(id,root_sale_id,previous_sale_id,replacement_sale_id,revision,actor,request_id,reason,effective_at)
 values(correction_id,root,leaf,replaced,revision,auth.uid(),p_request,p_payload->>'change_reason',h.sale_date);
 delete from cp7_sales.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 delete from cp7_note.context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 result:=jsonb_build_object('contract_version','cp7.note-correction-outcome.v1','kind','COMMITTED_OUTCOME',
  'action','CORRECT','request_id',p_request,'root_sale_id',root,'previous_sale_id',leaf,
  'sale_id',replaced,'revision_id',correction_id,'revision',revision::text,'effective_at',h.sale_date);
 update cp7_note.requests set response=result where actor=auth.uid()and request_id=p_request;
 return result;
end $$;

alter function cp7_note.access_now()owner to postgres;
alter function cp7_note.require_context()owner to postgres;
alter function cp7_note.restate_reversal(uuid,uuid,text)owner to postgres;
alter function cp7_note.immutable_revision()owner to postgres;
alter function cp7_note.workspace(uuid)owner to postgres;
alter function cp7_note.command(jsonb,uuid,text)owner to postgres;
-- Exact private composition only. Reuse the admitted low read wrapper instead
-- of granting postgres every private sales reader. No Native privilege or
-- operational caller privilege changes. Context/lineage are CP7 metadata.
grant usage on schema cp7_note,cp7_fg to postgres;
grant execute on function public.erp_cp7_get_sales_v1(jsonb),cp7_fg.book_anchor(uuid,uuid,text)to postgres;
grant insert,delete on cp7_sales.command_context to postgres;
grant select,insert on cp7_fg.correction_movements to postgres;
revoke all on all functions in schema cp7_note from public,anon,authenticated,service_role,cp7_capture,cp7_sales_read,cp7_sales_write;
grant usage on schema cp7_note to cp7_sales_write;
grant execute on function cp7_note.workspace(uuid),cp7_note.command(jsonb,uuid,text)to cp7_sales_write;
create function public.erp_cp7_get_note_correction_v1(p_sale uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_note.workspace(p_sale)$$;
create function public.erp_cp7_correct_note_v1(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_note.command(p_payload,p_request,p_expected)$$;
grant create on schema public to cp7_sales_write;
alter function public.erp_cp7_get_note_correction_v1(uuid)owner to cp7_sales_write;
alter function public.erp_cp7_correct_note_v1(jsonb,uuid,text)owner to cp7_sales_write;
revoke create on schema public from cp7_sales_write;
revoke all on function public.erp_cp7_get_note_correction_v1(uuid),public.erp_cp7_correct_note_v1(jsonb,uuid,text)from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_get_note_correction_v1(uuid),public.erp_cp7_correct_note_v1(jsonb,uuid,text)to authenticated;

-- Preserve invoice-line identity even when one SKU occurs more than once.
-- No posted Native facts or financial helper definitions are edited here.
create table cp7_note.item_lineage(
 replacement_item_id uuid primary key references erp.sales_items(id),
 previous_item_id uuid references erp.sales_items(id),
 correction_id uuid not null references cp7_note.revisions(id)deferrable initially deferred,
 request_position integer not null check(request_position>0),
 unique(correction_id,request_position),unique(correction_id,previous_item_id)
);
alter table cp7_note.item_lineage owner to postgres;
alter table cp7_note.item_lineage enable row level security;
create policy note_item_lineage_private on cp7_note.item_lineage for all using(false)with check(false);
revoke all on cp7_note.item_lineage from public,anon,authenticated,service_role,cp7_capture,cp7_sales_write;
create trigger note_item_lineage_immutable before update or delete on cp7_note.item_lineage
 for each row execute function cp7_note.immutable_revision();

create function cp7_note.bind_items(previous_sale uuid,replacement_sale uuid,correction uuid,items jsonb,source_ids jsonb)returns void
language plpgsql volatile security definer set search_path=''as $$
declare row record;previous uuid;replacement uuid;occurrence integer;
begin
 if jsonb_typeof(items)is distinct from'array'or jsonb_array_length(items)not between 1 and 100
  or jsonb_array_length(items)<>(select count(*)from erp.sales_items where sale_id=replacement_sale)then raise exception 'CP7_NOTE_ITEM_LINEAGE_SCOPE';end if;
 if source_ids is not null then
  if jsonb_typeof(source_ids)is distinct from'array'or jsonb_array_length(source_ids)<>jsonb_array_length(items)
   or exists(select 1 from jsonb_array_elements(source_ids)x where jsonb_typeof(x)not in('string','null')
    or jsonb_typeof(x)='string'and(x#>>'{}')!~*'^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$')then raise exception 'CP7_NOTE_ITEM_LINEAGE_FIELDS';end if;
  if exists(select 1 from jsonb_array_elements_text(source_ids)x where x is not null group by x having count(*)>1)
   or exists(select 1 from jsonb_array_elements_text(source_ids)x where x is not null and not exists(select 1 from erp.sales_items i where i.id=x::uuid and i.sale_id=previous_sale))then raise exception 'CP7_NOTE_ITEM_LINEAGE_SOURCE';end if;
 end if;
 for row in select value,ordinality::integer position from jsonb_array_elements(items)with ordinality loop
  if source_ids is not null then previous:=(source_ids->>(row.position-1))::uuid;
  else
   -- Compatibility for already-held v1 requests. The existing reader orders
   -- Native lines by id; match each submitted SKU occurrence once in that order.
   select count(*)::integer-1 into occurrence from jsonb_array_elements(items)with ordinality x
    where x.ordinality<=row.position and(x.value->>'product_id')::uuid=(row.value->>'product_id')::uuid;
   select id into previous from erp.sales_items where sale_id=previous_sale and product_id=(row.value->>'product_id')::uuid order by id offset occurrence limit 1;
  end if;
  -- Native generates new ids and may normalize decimal strings/blank notes.
  -- Match its complete line values, never just SKU or random replacement order.
  select i.id into replacement from erp.sales_items i where i.sale_id=replacement_sale
   and i.product_id=(row.value->>'product_id')::uuid and i.qty_pcs=(row.value->>'qty_pcs')::integer
   and i.unit_price_snapshot=(row.value->>'unit_price_snapshot')::numeric
   and i.discount_amount=(row.value->>'discount_amount')::numeric
   and nullif(btrim(i.notes),'')is not distinct from nullif(btrim(row.value->>'notes'),'')
   and not exists(select 1 from cp7_note.item_lineage l where l.replacement_item_id=i.id)order by i.id limit 1;
  if replacement is null then raise exception 'CP7_NOTE_ITEM_LINEAGE_NATIVE_MISMATCH';end if;
  insert into cp7_note.item_lineage values(replacement,previous,correction,row.position);
 end loop;
end $$;

create function cp7_note.line_origin(previous_sale uuid,replacement_item uuid,p_product uuid,p_lot uuid,p_location uuid,p_grade text)returns uuid
language sql stable security definer set search_path=''as $$
 select coalesce(l.origin_id,m.id)from cp7_note.item_lineage item
 join erp.sales_items i on i.id=item.previous_item_id and i.sale_id=previous_sale
 join erp.fg_stock_movements m on m.source_id=i.id and m.source_type='SALE_ITEM'and m.movement_type='SALE'
 left join cp7_fg.correction_movements l on l.member_id=m.id
 where item.replacement_item_id=replacement_item and m.product_id=p_product
  and m.location_id=p_location and m.quality_grade=p_grade
 order by(m.lot_id is not distinct from p_lot)desc,m.book_order,m.id limit 1
$$;
alter function cp7_note.bind_items(uuid,uuid,uuid,jsonb,jsonb)owner to postgres;
alter function cp7_note.line_origin(uuid,uuid,uuid,uuid,uuid,text)owner to postgres;
revoke all on function cp7_note.bind_items(uuid,uuid,uuid,jsonb,jsonb),cp7_note.line_origin(uuid,uuid,uuid,uuid,uuid,text)
 from public,anon,authenticated,service_role,cp7_capture,cp7_sales_write;

-- Ordinary customer-return correction. Preserve original physical inputs;
-- admitted Native inverse and replacement run in this one transaction.
create schema cp7_sales_return_correction authorization cp7_sales_read;
revoke all on schema cp7_sales_return_correction from public,anon,authenticated,service_role,cp7_capture;
grant usage on schema cp7_sales_return_correction to postgres,cp7_sales_write;
create table cp7_sales_return_correction.requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,
 expected_version text not null,response jsonb,primary key(actor,request_id)
);
create table cp7_sales_return_correction.context(
 backend_pid integer not null,transaction_id bigint not null,actor uuid not null,
 request_id uuid not null,sale_id uuid not null,return_id uuid not null,
 primary key(backend_pid,transaction_id)
);
create table cp7_sales_return_correction.links(
 id uuid primary key default gen_random_uuid(),original_id uuid not null unique references erp.sales_returns,
 replacement_id uuid not null unique references erp.sales_returns,sale_id uuid not null references erp.sales_headers,
 actor uuid not null,request_id uuid not null,reason text not null,
 recorded_at timestamptz not null default clock_timestamp(),
 check(original_id<>replacement_id),check(length(btrim(reason))between 5 and 1000),unique(actor,request_id)
);
create table cp7_sales_return_correction.journal_restatements(
 source_journal_id uuid primary key references erp.journal_entries,
 inverse_journal_id uuid not null unique references erp.journal_entries,
 original_return_id uuid not null unique references erp.sales_returns,
 neutral_journal_id uuid not null unique references erp.journal_entries,
 effective_journal_id uuid not null unique references erp.journal_entries,
 native_economic_date date not null,corrected_economic_date date not null,
 recorded_at timestamptz not null default clock_timestamp()
);
create table cp7_sales_return_correction.helper_sources(
 native_signature text primary key,native_definition_sha256 text not null
);
alter table cp7_sales_return_correction.requests owner to postgres;
alter table cp7_sales_return_correction.context owner to postgres;
alter table cp7_sales_return_correction.links owner to postgres;
alter table cp7_sales_return_correction.journal_restatements owner to postgres;
alter table cp7_sales_return_correction.helper_sources owner to postgres;
alter table cp7_sales_return_correction.requests enable row level security;
alter table cp7_sales_return_correction.context enable row level security;
alter table cp7_sales_return_correction.links enable row level security;
alter table cp7_sales_return_correction.journal_restatements enable row level security;
alter table cp7_sales_return_correction.helper_sources enable row level security;
create policy private_requests on cp7_sales_return_correction.requests for all using(false)with check(false);
create policy private_context on cp7_sales_return_correction.context for all using(false)with check(false);
create policy private_links on cp7_sales_return_correction.links for all using(false)with check(false);
create policy private_journals on cp7_sales_return_correction.journal_restatements for all using(false)with check(false);
create policy private_helpers on cp7_sales_return_correction.helper_sources for all using(false)with check(false);
revoke all on all tables in schema cp7_sales_return_correction from public,anon,authenticated,service_role,cp7_capture,cp7_sales_read,cp7_sales_write;

create function cp7_sales_return_correction.access_now()returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;
begin
 a:=cp7_sales.command_access('RETURN');
 if cp7_sales.command_access('RETURN_REVERSE')is distinct from a or erp.has_permission('finance.hpp.view')is distinct from true then
  raise exception using errcode='42501',message='CP7_RETURN_CORRECTION_DENIED';end if;
 return a;
end $$;
create function cp7_sales_return_correction.require_context()returns void
language plpgsql volatile security definer set search_path=''as $$
begin
 perform cp7_sales_return_correction.access_now();
 if not exists(select 1 from cp7_sales_return_correction.context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current()and c.actor=auth.uid()
  and exists(select 1 from cp7_sales.command_context s where s.backend_pid=c.backend_pid
   and s.transaction_id=c.transaction_id and s.actor=c.actor and s.sale_id=c.sale_id and s.action='RETURN_REVERSE'))then
  raise exception using errcode='42501',message='CP7_RETURN_CORRECTION_PRIVATE_CONTEXT_REQUIRED';end if;
end $$;
create function cp7_sales_return_correction.immutable()returns trigger
language plpgsql security invoker set search_path=''as $$
begin raise exception 'CP7_RETURN_CORRECTION_HISTORY_IMMUTABLE';end $$;
create trigger immutable_links before update or delete on cp7_sales_return_correction.links
 for each row execute function cp7_sales_return_correction.immutable();
create trigger immutable_journals before update or delete on cp7_sales_return_correction.journal_restatements
 for each row execute function cp7_sales_return_correction.immutable();
create trigger immutable_helpers before update or delete on cp7_sales_return_correction.helper_sources
 for each row execute function cp7_sales_return_correction.immutable();
create trigger immutable_links_truncate before truncate on cp7_sales_return_correction.links
 for each statement execute function cp7_sales_return_correction.immutable();
create trigger immutable_journals_truncate before truncate on cp7_sales_return_correction.journal_restatements
 for each statement execute function cp7_sales_return_correction.immutable();
create trigger immutable_helpers_truncate before truncate on cp7_sales_return_correction.helper_sources
 for each statement execute function cp7_sales_return_correction.immutable();
create function cp7_sales_return_correction.protect_link()returns trigger
language plpgsql volatile security definer set search_path=''as $$
begin
 if new.actor is distinct from auth.uid()or not exists(select 1 from cp7_sales_return_correction.requests q
  where q.actor=new.actor and q.request_id=new.request_id and q.response is null
   and(q.payload->>'sale_id')::uuid=new.sale_id and(q.payload->>'return_id')::uuid=new.original_id)
  or not exists(select 1 from cp7_sales.command_context c where c.backend_pid=pg_backend_pid()
   and c.transaction_id=txid_current()and c.actor=new.actor and c.sale_id=new.sale_id and c.action='RETURN')
  or not exists(select 1 from erp.sales_returns original join erp.sales_returns replacement on replacement.id=new.replacement_id
   where original.id=new.original_id and original.sale_id=new.sale_id and replacement.sale_id=new.sale_id
    and original.status='REVERSED'and replacement.status='POSTED')then
  raise exception 'CP7_RETURN_CORRECTION_LINK_SOURCE_CHANGED';end if;
 return new;
end $$;
create trigger protect_links before insert on cp7_sales_return_correction.links
 for each row execute function cp7_sales_return_correction.protect_link();

create function cp7_sales_return_correction.validate(p jsonb)returns void
language plpgsql immutable security invoker set search_path=''as $$
begin
 if jsonb_typeof(p)is distinct from'object'or not(p?&array['sale_id','return_id','review_token','return_review_token','replacement','change_reason'])
  or(select count(*)from jsonb_object_keys(p))<>6
  or jsonb_typeof(p->'return_review_token')is distinct from'string'
  or coalesce(p->>'return_review_token','')!~'^[a-f0-9]{32}$'
  or jsonb_typeof(p->'replacement')is distinct from'object'
  or not(p->'replacement'?&array['physical_at','notes','items'])
  or(select count(*)from jsonb_object_keys(p->'replacement'))<>3 then raise exception 'CP7_RETURN_CORRECTION_FIELDS';end if;
 perform cp7_sales.validate_return(p-'return_review_token'-'replacement',true);
 perform cp7_sales.validate_return((p-'return_review_token'-'return_id'-'replacement')||(p->'replacement')
  ||jsonb_build_object('return_number','K-'||(p->>'return_id')),false);
end $$;
create function cp7_sales_return_correction.document(p_id uuid)returns jsonb
language sql stable security definer set search_path=''set TimeZone='UTC'as $$
 select jsonb_build_object('id',r.id,'sale_id',r.sale_id,'number',r.return_number,'physical_at',r.physical_at,
  'status',r.status,'notes',r.notes,'items',(select coalesce(jsonb_agg(jsonb_build_object(
   'id',i.id,'allocation_id',i.sale_stock_allocation_id,'product_id',i.product_id,'product_sku',p.sku,
   'lot_id',i.lot_id,'lot_number',fl.lot_number,'location_id',i.location_id,'location_name',l.location_name,
   'qty_pcs',i.qty_pcs::text,'quality_grade',i.quality_grade,'refund_amount',round(i.refund_amount,2)::text,
   'notes',i.notes)order by i.id),'[]')from erp.sales_return_items i
    join erp.products p on p.id=i.product_id join erp.fg_lots fl on fl.id=i.lot_id
    join erp.locations l on l.id=i.location_id where i.return_id=r.id))
 from erp.sales_returns r where r.id=p_id
$$;
-- Bind current stock, lot cost and destination state as well as Native invoice
-- children. This token does not claim an arbitrary historical reconstruction.
create function cp7_sales_return_correction.review_token(p_id uuid)returns text
language sql stable security definer set search_path=''as $$
 select md5(jsonb_build_object('return',to_jsonb(r),'sale',cp7_sales.review_token(r.sale_id),
  'items',(select jsonb_agg(to_jsonb(i)order by i.id)from erp.sales_return_items i where i.return_id=r.id),
  'lots',(select jsonb_agg(to_jsonb(l)order by l.id)from erp.fg_lots l where exists(
   select 1 from erp.sales_return_items i where i.return_id=r.id and i.lot_id=l.id)),
  'hpp',(select jsonb_agg(to_jsonb(h)order by h.lot_id,h.id)from erp.hpp_versions h where h.is_current and exists(
   select 1 from erp.sale_stock_allocations a join erp.sales_items i on i.id=a.sale_item_id where i.sale_id=r.sale_id and a.lot_id=h.lot_id)),
  'stock',(select jsonb_agg(to_jsonb(x)order by x.lot_id,x.location_id,x.quality_grade)from(
   select m.lot_id,m.location_id,m.quality_grade,sum(m.qty_signed)qty,max(m.system_created_at)last_recorded_at,count(*)n
   from erp.fg_stock_movements m where exists(select 1 from erp.sale_stock_allocations a
    join erp.sales_items i on i.id=a.sale_item_id where i.sale_id=r.sale_id and a.lot_id=m.lot_id)
   group by m.lot_id,m.location_id,m.quality_grade)x),
  'locations',(select jsonb_agg(to_jsonb(l)order by l.id)from erp.locations l where l.location_type='FG_WAREHOUSE'),
  'journals',(select jsonb_agg(to_jsonb(j)order by j.id)from erp.journal_entries j
   where j.source_type='SALES_RETURN'and j.source_id=r.id))::text)
 from erp.sales_returns r where r.id=p_id
$$;
create function cp7_sales_return_correction.link_value(p cp7_sales_return_correction.links)returns jsonb
language sql stable security definer set search_path=''set TimeZone='UTC'as $$
 select jsonb_build_object('id',p.id,'original_id',p.original_id,'replacement_id',p.replacement_id,'sale_id',p.sale_id,
  'actor_scope_id',p.actor,'request_id',p.request_id,'reason',p.reason,'recorded_at',p.recorded_at,
  'time_restatement',(select jsonb_build_object('source_journal_id',j.source_journal_id,
   'inverse_journal_id',j.inverse_journal_id,'neutral_journal_id',j.neutral_journal_id,
   'effective_journal_id',j.effective_journal_id,'native_economic_date',j.native_economic_date,
   'corrected_economic_date',j.corrected_economic_date)from cp7_sales_return_correction.journal_restatements j
   where j.original_return_id=p.original_id))
$$;
create function cp7_sales_return_correction.restate_reversal(p_source uuid,p_inverse uuid,p_reason text)returns void
language plpgsql volatile security definer set search_path=''as $$
declare original erp.journal_entries;inverse erp.journal_entries;source_return uuid;neutral uuid;effective uuid;lines jsonb;
begin
 perform cp7_sales_return_correction.require_context();
 select return_id into strict source_return from cp7_sales_return_correction.context
  where backend_pid=pg_backend_pid()and transaction_id=txid_current()and actor=auth.uid();
 select *into strict original from erp.journal_entries where id=p_source;
 select *into strict inverse from erp.journal_entries where id=p_inverse;
 if original.status<>'REVERSED'or original.source_type<>'SALES_RETURN'or original.source_id<>source_return
  or inverse.status<>'POSTED'or inverse.source_type<>'JOURNAL_REVERSAL'or inverse.source_id<>original.id
  or inverse.reversal_of_id is distinct from original.id then raise exception 'CP7_RETURN_CORRECTION_JOURNAL_SOURCE_CHANGED';end if;
 if original.economic_date=inverse.economic_date then return;end if;
 select jsonb_agg(jsonb_build_object('account_id',j.account_id,'debit',j.credit,'credit',j.debit,
  'description',j.description,'customer_id',j.customer_id,'vendor_id',j.vendor_id,
  'contractor_id',j.contractor_id,'po_id',j.po_id,'product_id',j.product_id)order by j.id)into lines
 from erp.journal_lines j where j.journal_entry_id=inverse.id;
 neutral:=erp.post_journal('RETURN_CORRECTION_TIME_NEUTRAL',inverse.id,inverse.economic_date,
  'Pembetulan retur: pindahkan waktu ekonomi pembalikan | '||p_reason,lines);
 select jsonb_agg(jsonb_build_object('account_id',j.account_id,'debit',j.debit,'credit',j.credit,
  'description',j.description,'customer_id',j.customer_id,'vendor_id',j.vendor_id,
  'contractor_id',j.contractor_id,'po_id',j.po_id,'product_id',j.product_id)order by j.id)into lines
 from erp.journal_lines j where j.journal_entry_id=inverse.id;
 effective:=erp.post_journal('RETURN_CORRECTION_EFFECTIVE',inverse.id,original.economic_date,
  'Pembetulan retur: waktu ekonomi kejadian asal | '||p_reason,lines);
 insert into cp7_sales_return_correction.journal_restatements values(original.id,inverse.id,source_return,
  neutral,effective,inverse.economic_date,original.economic_date,clock_timestamp());
end $$;

-- Original Native helpers remain unchanged. Derive only private admission,
-- helper calls, original physical/HPP inverse date and exact journal timing.
do $derive$
declare signature text;definition text;body text;changed text;name text;
begin
 foreach signature in array array['erp.reverse_fg_movement(uuid,text)',
  'erp._cp3_r4_reverse_journal_internal(uuid,text)','erp.reverse_journal(uuid,text)','erp.reverse_sales_return(uuid,text)']loop
  select pg_get_functiondef(oid),prosrc into strict definition,body from pg_proc where oid=signature::regprocedure;
  name:=split_part(split_part(signature,'.',2),'(',1);
  changed:=regexp_replace(body,'\m[Bb][Ee][Gg][Ii][Nn]\M',E'begin\n perform cp7_sales_return_correction.require_context();');
  if changed=body then raise exception 'CP7_RETURN_CORRECTION_NATIVE_BODY_CHANGED';end if;
  changed:=replace(changed,'erp.reverse_fg_movement(','cp7_sales_return_correction.reverse_fg_movement(');
  changed:=replace(changed,'erp.reverse_journal(','cp7_sales_return_correction.reverse_journal(');
  changed:=replace(changed,'erp._cp3_r4_reverse_journal_internal(','cp7_sales_return_correction._cp3_r4_reverse_journal_internal(');
  if name='reverse_fg_movement'then
   if length(body)-length(replace(body,'clock_timestamp()',''))<>length('clock_timestamp()')then
    raise exception 'CP7_RETURN_CORRECTION_NATIVE_FG_CLOCK_CHANGED';end if;
   changed:=replace(changed,'clock_timestamp()','m.physical_at');
  elsif name='_cp3_r4_reverse_journal_internal'then
   if strpos(body,'RETURN v_new_id;')=0 then raise exception 'CP7_RETURN_CORRECTION_NATIVE_JOURNAL_RETURN_CHANGED';end if;
   changed:=replace(changed,'RETURN v_new_id;',
    'PERFORM cp7_sales_return_correction.restate_reversal(p_journal_entry_id,v_new_id,p_reason); RETURN v_new_id;');
  elsif name='reverse_sales_return'then
   if strpos(body,$$((statement_timestamp() AT TIME ZONE 'Asia/Jakarta'::text))::date$$)=0 then
    raise exception 'CP7_RETURN_CORRECTION_NATIVE_HPP_CLOCK_CHANGED';end if;
   changed:=replace(changed,$$((statement_timestamp() AT TIME ZONE 'Asia/Jakarta'::text))::date$$,
    $$((h.physical_at AT TIME ZONE 'Asia/Jakarta'::text))::date$$);
  end if;
  definition:=replace(definition,body,changed);
  definition:=replace(definition,'FUNCTION erp.'||name||'(','FUNCTION cp7_sales_return_correction.'||name||'(');
  execute definition;
  execute format('alter function cp7_sales_return_correction.%I(uuid,text)owner to postgres',name);
  insert into cp7_sales_return_correction.helper_sources values(signature,
   encode(pg_catalog.sha256(convert_to(pg_get_functiondef(signature::regprocedure),'UTF8')),'hex'));
 end loop;
end $derive$;

create function cp7_sales_return_correction.workspace(p jsonb)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;r erp.sales_returns;h erp.sales_headers;eligible boolean;previous cp7_sales_return_correction.links;
 following cp7_sales_return_correction.links;allocations jsonb;current_allocations jsonb;total bigint;off integer;n integer;q text;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 if not cp7_sales.access_now()or erp.has_permission('sales.return.view')is distinct from true then
  raise exception using errcode='42501',message='CP7_RETURN_CORRECTION_READ_DENIED';end if;
 a:=erp.get_my_access_v1();
 if jsonb_typeof(p)is distinct from'object'or not(p?&array['sale_id','return_id'])
  or exists(select 1 from jsonb_object_keys(p)x where x not in('sale_id','return_id','q','offset','limit'))
  or jsonb_typeof(p->'sale_id')is distinct from'string'or jsonb_typeof(p->'return_id')is distinct from'string'
  or coalesce(p->>'sale_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or coalesce(p->>'return_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or(p?'q'and jsonb_typeof(p->'q')is distinct from'string')
  or exists(select 1 from jsonb_each(p)e where e.key in('offset','limit')and(jsonb_typeof(e.value)<>'number'or e.value::text!~'^[0-9]{1,7}$'))then
  raise exception 'CP7_RETURN_CORRECTION_QUERY';end if;
 off:=coalesce((p->>'offset')::integer,0);n:=coalesce((p->>'limit')::integer,25);q:=btrim(coalesce(p->>'q',''));
 if off not between 0 and 1000000 or n not between 1 and 100 or length(q)>120 then raise exception 'CP7_RETURN_CORRECTION_QUERY';end if;
 select *into r from erp.sales_returns where id=(p->>'return_id')::uuid and sale_id=(p->>'sale_id')::uuid;
 if r.id is null then raise exception 'CP7_RETURN_CORRECTION_NOT_FOUND';end if;
 select *into strict h from erp.sales_headers where id=r.sale_id;
 if(select count(*)from erp.sales_return_items where return_id=r.id)not between 1 and 100 then
  raise exception 'CP7_RETURN_CORRECTION_DOCUMENT_TOO_LARGE';end if;
 eligible:=r.status='POSTED'and h.status in('POSTED','PARTIAL_PAID','PAID')
  and not exists(select 1 from cp7_sales_return_correction.links where original_id=r.id);
 select *into previous from cp7_sales_return_correction.links where replacement_id=r.id and sale_id=h.id;
 select *into following from cp7_sales_return_correction.links where original_id=r.id and sale_id=h.id;
 -- Include this return's own capacity even when fully returned. Peer posted
 -- returns consume capacity; Native quantity/refund/HPP guards still decide.
 with sources as materialized(
  select x.id allocation_id,x.sale_item_id,x.lot_id,fl.lot_number,pr.id product_id,pr.sku product_sku,
   pr.product_name,s.size_code,l.location_name source_location_name,x.qty_pcs allocated_qty,
   coalesce((select sum(i.qty_pcs)from erp.sales_return_items i join erp.sales_returns rh on rh.id=i.return_id
    where i.sale_stock_allocation_id=x.id and rh.sale_id=h.id and rh.status='POSTED'and rh.id<>r.id),0)peer_returned_qty,
   i.qty_pcs sale_item_qty,i.line_total sale_item_net
  from erp.sale_stock_allocations x join erp.sales_items i on i.id=x.sale_item_id
   join erp.products pr on pr.id=i.product_id join erp.sizes s on s.id=pr.size_id
   join erp.fg_lots fl on fl.id=x.lot_id join erp.locations l on l.id=x.location_id where i.sale_id=h.id),
 eligible_rows as materialized(select *from sources where allocated_qty>peer_returned_qty
  and(q=''or strpos(lower(concat_ws(' ',product_sku,product_name,size_code,lot_number)),lower(q))>0)),
 sliced as(select *from eligible_rows order by sale_item_id,lot_id,allocation_id limit n offset off)
 select(select count(*)from eligible_rows),coalesce((select jsonb_agg(jsonb_build_object(
  'allocation_id',allocation_id,'sale_item_id',sale_item_id,'product_id',product_id,'product_sku',product_sku,
  'product_name',product_name,'size_code',size_code,'lot_id',lot_id,'lot_number',lot_number,
  'source_location_name',source_location_name,'allocated_qty',allocated_qty::text,
  'peer_returned_qty',peer_returned_qty::text,'replacement_capacity',(allocated_qty-peer_returned_qty)::text,
  'sale_item_qty',sale_item_qty::text,'sale_item_net',round(sale_item_net,2)::text)
  order by sale_item_id,lot_id,allocation_id)from sliced),'[]'),
 coalesce((select jsonb_agg(jsonb_build_object(
  'allocation_id',s.allocation_id,'sale_item_id',s.sale_item_id,'product_id',s.product_id,'product_sku',s.product_sku,
  'product_name',s.product_name,'size_code',s.size_code,'lot_id',s.lot_id,'lot_number',s.lot_number,
  'source_location_name',s.source_location_name,'allocated_qty',s.allocated_qty::text,
  'peer_returned_qty',s.peer_returned_qty::text,'replacement_capacity',(s.allocated_qty-s.peer_returned_qty)::text,
  'sale_item_qty',s.sale_item_qty::text,'sale_item_net',round(s.sale_item_net,2)::text)
  order by s.sale_item_id,s.lot_id,s.allocation_id)from sources s where exists(
   select 1 from erp.sales_return_items i where i.return_id=r.id and i.sale_stock_allocation_id=s.allocation_id)),'[]')
 into total,allocations,current_allocations;
 if erp.get_my_access_v1()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.sales-return-correction-workspace.v1','read_at',clock_timestamp(),
  'source',jsonb_build_object('sale_id',h.id,'row_version',h.row_version::text,'review_token',cp7_sales.review_token(h.id)),
  'document',cp7_sales_return_correction.document(r.id),'return_review_token',cp7_sales_return_correction.review_token(r.id),
  'financial',cp7_sales.header(h,true)->'financial','eligible',eligible,
  'can_correct',eligible and a->'profile'->>'role_code'in('OWNER','ADMIN')
   and erp.has_permission('sales.return.create')and erp.has_permission('sales.return.post')
   and erp.has_permission('sales.return.reverse')and erp.has_permission('finance.hpp.view'),
  'allocations',jsonb_build_object('rows',allocations,'total',total::text,'offset',off,'limit',n,
   'next_offset',case when off+jsonb_array_length(allocations)<total then off+jsonb_array_length(allocations)else null end),
  'current_allocations',current_allocations,
  'previous',case when previous.id is null then null else jsonb_build_object(
   'link',cp7_sales_return_correction.link_value(previous),'document',cp7_sales_return_correction.document(previous.original_id))end,
  'next',case when following.id is null then null else jsonb_build_object(
   'link',cp7_sales_return_correction.link_value(following),'document',cp7_sales_return_correction.document(following.replacement_id))end,
  'production_go',false);
end $$;

create function cp7_sales_return_correction.command(p jsonb,p_request uuid,p_expected text)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;old cp7_sales_return_correction.requests;h erp.sales_headers;r erp.sales_returns;
 replacement uuid;line jsonb;allocation record;origin uuid;movement record;
 link cp7_sales_return_correction.links;result jsonb;resolved jsonb;correction_id uuid:=gen_random_uuid();
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_sales_return_correction.access_now();perform cp7_sales_return_correction.validate(p);
 if p_request is null or p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'then raise exception 'CP7_RETURN_CORRECTION_REQUEST_REQUIRED';end if;
 insert into cp7_sales_return_correction.requests values(auth.uid(),p_request,p,p_expected,null)on conflict do nothing;
 select *into strict old from cp7_sales_return_correction.requests where actor=auth.uid()and request_id=p_request for update;
 if old.payload is distinct from p or old.expected_version is distinct from p_expected then raise exception 'CP7_RETURN_CORRECTION_REQUEST_CHANGED';end if;
 if cp7_sales_return_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 if exists(select 1 from cp7_sales.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current())then
  raise exception using errcode='42501',message='CP7_RETURN_CORRECTION_PRIVATE_CONTEXT_REQUIRED';end if;
 -- Preserve Native FG, child, header and allocation lock order.
 perform pg_advisory_xact_lock(hashtextextended('FG_HPP_SALES_V2620C',0));
 perform 1 from erp.sales_payments where sale_id=(p->>'sale_id')::uuid order by id for update;
 perform 1 from erp.sales_returns where sale_id=(p->>'sale_id')::uuid order by id for update;
 select *into h from erp.sales_headers where id=(p->>'sale_id')::uuid for update;
 select *into r from erp.sales_returns where id=(p->>'return_id')::uuid and sale_id=h.id;
 if h.id is null or r.id is null then raise exception 'CP7_RETURN_CORRECTION_NOT_FOUND';end if;
 perform 1 from erp.sales_items where sale_id=h.id order by id for update;
 perform 1 from erp.sale_stock_allocations x where exists(select 1 from erp.sales_items i
  where i.id=x.sale_item_id and i.sale_id=h.id)order by x.id for update;
 perform 1 from erp.sales_return_items i join erp.sales_returns rh on rh.id=i.return_id
  where rh.sale_id=h.id order by i.id for update of i;
 perform 1 from erp.locations where id in(select (value->>'location_id')::uuid from jsonb_array_elements(p->'replacement'->'items'))order by id for share;
 perform 1 from erp.hpp_versions v where v.is_current and exists(select 1 from erp.sale_stock_allocations x
  join erp.sales_items i on i.id=x.sale_item_id where i.sale_id=h.id and x.lot_id=v.lot_id)order by v.id for share;
 if cp7_sales_return_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 if h.row_version::text is distinct from p_expected or cp7_sales.review_token(h.id)is distinct from p->>'review_token'
  or cp7_sales_return_correction.review_token(r.id)is distinct from p->>'return_review_token'then raise exception 'CP7_RETURN_CORRECTION_STALE_REVIEW';end if;
 if r.status<>'POSTED'or h.status not in('POSTED','PARTIAL_PAID','PAID')
  or exists(select 1 from cp7_sales_return_correction.links where original_id=r.id)then raise exception 'CP7_RETURN_CORRECTION_INELIGIBLE';end if;
 if(p->'replacement'->>'physical_at')::timestamptz>statement_timestamp()then raise exception 'CP7_SALES_RETURN_FUTURE_DATE';end if;
 if r.physical_at=(p->'replacement'->>'physical_at')::timestamptz and r.notes is not distinct from p->'replacement'->>'notes'
  and(select jsonb_agg(jsonb_build_object('allocation_id',i.sale_stock_allocation_id,'location_id',i.location_id,
   'qty_pcs',i.qty_pcs::text,'quality_grade',i.quality_grade,'refund_amount',round(i.refund_amount,2)::text,'notes',i.notes)order by i.sale_stock_allocation_id)
   from erp.sales_return_items i where i.return_id=r.id)=(select jsonb_agg(jsonb_build_object(
    'allocation_id',(value->>'allocation_id')::uuid,'location_id',(value->>'location_id')::uuid,
    'qty_pcs',value->>'qty_pcs','quality_grade',value->>'quality_grade','refund_amount',round((value->>'refund_amount')::numeric,2)::text,
    'notes',value->>'notes')order by value->>'allocation_id')from jsonb_array_elements(p->'replacement'->'items'))then
  raise exception 'CP7_RETURN_CORRECTION_UNCHANGED';end if;
 perform set_config('app.change_reason',btrim(p->>'change_reason'),true);
 insert into cp7_sales_return_correction.context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,h.id,r.id);
 insert into cp7_sales.command_context values(pg_backend_pid(),txid_current(),auth.uid(),h.id,'RETURN_REVERSE');
 perform cp7_sales_return_correction.reverse_sales_return(r.id,btrim(p->>'change_reason'));
 -- Exact inverses share the effective original card. No Native row is edited.
 for movement in select m.id,m.reversal_of_id from erp.fg_stock_movements m
  join erp.fg_stock_movements o on o.id=m.reversal_of_id
  join erp.sales_return_items i on i.id=o.source_id and o.source_type='SALES_RETURN_ITEM'
  where i.return_id=r.id and not exists(select 1 from cp7_fg.correction_movements x where x.member_id=m.id)loop
  select coalesce(x.origin_id,movement.reversal_of_id)into origin from(select 1)t
   left join cp7_fg.correction_movements x on x.member_id=movement.reversal_of_id;
  insert into cp7_fg.correction_movements values(movement.id,origin,correction_id,clock_timestamp());
 end loop;
 delete from cp7_sales.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 delete from cp7_sales_return_correction.context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 insert into cp7_sales.command_context values(pg_backend_pid(),txid_current(),auth.uid(),h.id,'RETURN');
 insert into erp.sales_returns(return_number,sale_id,customer_id,physical_at,notes,status,created_by)
 values('K-'||p_request::text,h.id,h.customer_id,(p->'replacement'->>'physical_at')::timestamptz,
  p->'replacement'->>'notes','DRAFT',erp.current_app_user_id())returning id into replacement;
 for line in select value from jsonb_array_elements(p->'replacement'->'items')loop
  select x.id,x.lot_id,i.product_id into allocation from erp.sale_stock_allocations x join erp.sales_items i on i.id=x.sale_item_id
   where x.id=(line->>'allocation_id')::uuid and i.sale_id=h.id;
  if not found then raise exception 'CP7_SALES_RETURN_ALLOCATION_CHANGED';end if;
  insert into erp.sales_return_items(return_id,sale_stock_allocation_id,product_id,lot_id,location_id,qty_pcs,quality_grade,refund_amount,notes)
  values(replacement,allocation.id,allocation.product_id,allocation.lot_id,(line->>'location_id')::uuid,
   (line->>'qty_pcs')::integer,line->>'quality_grade',(line->>'refund_amount')::numeric,line->>'notes');
 end loop;
 perform erp.post_sales_return(replacement);
 -- A changed date/destination/grade remains a separate physical row. Only an
 -- identical product/lot/destination/grade/time can share an original card.
 for movement in select m.*from erp.fg_stock_movements m join erp.sales_return_items i
  on i.id=m.source_id and m.source_type='SALES_RETURN_ITEM'where i.return_id=replacement and m.movement_type='SALE_RETURN'loop
  select coalesce(x.origin_id,o.id)into origin from erp.fg_stock_movements o
   join erp.sales_return_items i on i.id=o.source_id and o.source_type='SALES_RETURN_ITEM'
   left join cp7_fg.correction_movements x on x.member_id=o.id
   where i.return_id=r.id and i.sale_stock_allocation_id=(select sale_stock_allocation_id from erp.sales_return_items where id=movement.source_id)
    and o.movement_type='SALE_RETURN'and o.product_id=movement.product_id and o.lot_id is not distinct from movement.lot_id
    and o.location_id=movement.location_id and o.quality_grade=movement.quality_grade and o.physical_at=movement.physical_at
   order by o.book_order,o.id limit 1;
  if origin is not null then insert into cp7_fg.correction_movements values(movement.id,origin,correction_id,clock_timestamp());end if;
 end loop;
 if cp7_sales_return_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 insert into cp7_sales_return_correction.links(id,original_id,replacement_id,sale_id,actor,request_id,reason)
 values(correction_id,r.id,replacement,h.id,auth.uid(),p_request,btrim(p->>'change_reason'))returning *into link;
 delete from cp7_sales.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 select *into strict h from erp.sales_headers where id=h.id;
 resolved:=public.erp_cp7_resolve_transaction_source_v1(jsonb_build_object('source_type','SALES_RETURN','source_id',replacement));
 if resolved->>'status'is distinct from 'AVAILABLE'or resolved#>>'{document,domain}'is distinct from 'SALE'
  or resolved#>>'{document,id}'is distinct from h.id::text
  or resolved#>>'{document,focus,kind}'is distinct from 'SALES_RETURN'
  or resolved#>>'{document,focus,id}'is distinct from replacement::text
  or resolved#>>'{document,focus,page_offset}'is null then raise exception 'CP7_RETURN_CORRECTION_SOURCE_UNAVAILABLE';end if;
 result:=jsonb_build_object('contract_version','cp7.sales-return-correction.v1','kind','COMMITTED_OUTCOME','action','RETURN_CORRECT',
  'request_id',p_request,'sale_id',h.id,'row_version',h.row_version::text,'status',h.status,
  'original_return_id',r.id,'original_return_status','REVERSED','return_id',replacement,'return_status','POSTED',
  'return_page_offset',(resolved#>>'{document,focus,page_offset}')::integer,
  'link',cp7_sales_return_correction.link_value(link),'production_go',false);
 update cp7_sales_return_correction.requests set response=result where actor=auth.uid()and request_id=p_request;
 return result;
end $$;
create function cp7_sales_return_correction.report_lifecycle(p_from date,p_to date)
returns table(source_id uuid,event_sign integer)
language sql stable security definer set search_path=''as $$
 select original.source_id,e.event_sign from cp7_sales_return_correction.journal_restatements r
 join erp.journal_entries original on original.id=r.source_journal_id
 cross join lateral(values(r.neutral_journal_id,1,'RETURN_CORRECTION_TIME_NEUTRAL'),
  (r.effective_journal_id,-1,'RETURN_CORRECTION_EFFECTIVE'))e(journal_id,event_sign,source_type)
 join erp.journal_entries posted on posted.id=e.journal_id and posted.source_type=e.source_type and posted.source_id=r.inverse_journal_id
 where original.status='REVERSED'and original.source_type='SALES_RETURN'and posted.status='POSTED'
  and posted.transaction_date between p_from and p_to
$$;

alter function cp7_sales_return_correction.access_now()owner to postgres;
alter function cp7_sales_return_correction.require_context()owner to postgres;
alter function cp7_sales_return_correction.immutable()owner to postgres;
alter function cp7_sales_return_correction.protect_link()owner to postgres;
alter function cp7_sales_return_correction.validate(jsonb)owner to postgres;
alter function cp7_sales_return_correction.document(uuid)owner to postgres;
alter function cp7_sales_return_correction.review_token(uuid)owner to postgres;
alter function cp7_sales_return_correction.link_value(cp7_sales_return_correction.links)owner to postgres;
alter function cp7_sales_return_correction.restate_reversal(uuid,uuid,text)owner to postgres;
alter function cp7_sales_return_correction.workspace(jsonb)owner to postgres;
alter function cp7_sales_return_correction.command(jsonb,uuid,text)owner to postgres;
alter function cp7_sales_return_correction.report_lifecycle(date,date)owner to postgres;
grant execute on function cp7_sales.validate_return(jsonb,boolean),cp7_sales.header(erp.sales_headers,boolean)to postgres;
revoke all on all functions in schema cp7_sales_return_correction from public,anon,authenticated,service_role,cp7_capture,cp7_sales_read,cp7_sales_write;
grant execute on function cp7_sales_return_correction.workspace(jsonb)to cp7_sales_read;
grant execute on function cp7_sales_return_correction.command(jsonb,uuid,text)to cp7_sales_write;
create function public.erp_cp7_get_sales_return_correction_v1(p_query jsonb)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_sales_return_correction.workspace(p_query)$$;
create function public.erp_cp7_correct_sales_return_v1(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_sales_return_correction.command(p_payload,p_request,p_expected)$$;
grant create on schema public to cp7_sales_read,cp7_sales_write;
alter function public.erp_cp7_get_sales_return_correction_v1(jsonb)owner to cp7_sales_read;
alter function public.erp_cp7_correct_sales_return_v1(jsonb,uuid,text)owner to cp7_sales_write;
revoke create on schema public from cp7_sales_read,cp7_sales_write;
revoke all on function public.erp_cp7_get_sales_return_correction_v1(jsonb),public.erp_cp7_correct_sales_return_v1(jsonb,uuid,text)from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_get_sales_return_correction_v1(jsonb),public.erp_cp7_correct_sales_return_v1(jsonb,uuid,text)to authenticated;

-- The Native report retains its owner guard, amounts, GL dates and readiness.
-- These are the operational counterparts of the exact journal restatement
-- pair. They use the actual GL posting period, including a closed old period.
create table cp7_note.report_sources(
 native_signature text primary key,original_definition text not null,
 original_sha256 text not null,overlay_sha256 text not null
);
alter table cp7_note.report_sources owner to postgres;
alter table cp7_note.report_sources enable row level security;
create policy private_report_sources on cp7_note.report_sources for all using(false)with check(false);
revoke all on cp7_note.report_sources from public,anon,authenticated,service_role,cp7_capture,cp7_sales_write;
create trigger immutable_report_source before update or delete on cp7_note.report_sources
 for each row execute function cp7_note.immutable_revision();

create function cp7_note.report_lifecycle(p_from date,p_to date,p_source_type text)
returns table(source_id uuid,event_sign integer)
language sql stable security definer set search_path=''as $$
 select original.source_id,e.event_sign
 from cp7_note.journal_restatements r
 join erp.journal_entries original on original.id=r.source_journal_id
 cross join lateral(values
  (r.neutral_journal_id,1,'NOTE_REVERSAL_TIME_NEUTRAL'),
  (r.effective_journal_id,-1,'NOTE_REVERSAL_EFFECTIVE')
 )e(journal_id,event_sign,source_type)
 join erp.journal_entries posted on posted.id=e.journal_id
  and posted.source_type=e.source_type and posted.source_id=r.inverse_journal_id
 where original.status='REVERSED'and original.source_type=p_source_type
  and p_source_type in('SALE','SALES_RETURN')and posted.status='POSTED'
  and posted.transaction_date between p_from and p_to
$$;
alter function cp7_note.report_lifecycle(date,date,text)owner to postgres;
revoke all on function cp7_note.report_lifecycle(date,date,text)
 from public,anon,authenticated,service_role,cp7_capture,cp7_sales_write;

do $report$
declare definition text;original text;signature text:='erp.get_owner_financial_snapshot_v2(date,date,date)';
begin
 original:=pg_get_functiondef(signature::regprocedure);definition:=original;
 if length(definition)-length(replace(definition,$anchor$      and original.source_type='SALE'
    where reversal.source_type='JOURNAL_REVERSAL' and reversal.status='POSTED'
      and reversal.transaction_date between p_from and p_to
  )$anchor$,''))<>length($anchor$      and original.source_type='SALE'
    where reversal.source_type='JOURNAL_REVERSAL' and reversal.status='POSTED'
      and reversal.transaction_date between p_from and p_to
  )$anchor$)then raise exception 'CP7_NOTE_NATIVE_REPORT_SOURCE_CHANGED';end if;
 definition:=replace(definition,$anchor$      and original.source_type='SALE'
    where reversal.source_type='JOURNAL_REVERSAL' and reversal.status='POSTED'
      and reversal.transaction_date between p_from and p_to
  )$anchor$,$changed$      and original.source_type='SALE'
    where reversal.source_type='JOURNAL_REVERSAL' and reversal.status='POSTED'
      and reversal.transaction_date between p_from and p_to
    union all
    select source_id,event_sign
    from cp7_note.report_lifecycle(p_from,p_to,'SALE')
  )$changed$);
 if length(definition)-length(replace(definition,$anchor$      and original.source_type='SALES_RETURN'
    where reversal.source_type='JOURNAL_REVERSAL' and reversal.status='POSTED'
      and reversal.transaction_date between p_from and p_to
  )$anchor$,''))<>length($anchor$      and original.source_type='SALES_RETURN'
    where reversal.source_type='JOURNAL_REVERSAL' and reversal.status='POSTED'
      and reversal.transaction_date between p_from and p_to
  )$anchor$)then raise exception 'CP7_NOTE_NATIVE_REPORT_SOURCE_CHANGED';end if;
 definition:=replace(definition,$anchor$      and original.source_type='SALES_RETURN'
    where reversal.source_type='JOURNAL_REVERSAL' and reversal.status='POSTED'
      and reversal.transaction_date between p_from and p_to
  )$anchor$,$changed$      and original.source_type='SALES_RETURN'
    where reversal.source_type='JOURNAL_REVERSAL' and reversal.status='POSTED'
      and reversal.transaction_date between p_from and p_to
    union all
    select source_id,event_sign
    from cp7_note.report_lifecycle(p_from,p_to,'SALES_RETURN')
    union all
    select source_id,event_sign
    from cp7_sales_return_correction.report_lifecycle(p_from,p_to)
  )$changed$);
 execute definition;
 insert into cp7_note.report_sources values(signature,original,
 encode(pg_catalog.sha256(convert_to(original,'UTF8')),'hex'),
 encode(pg_catalog.sha256(convert_to(definition,'UTF8')),'hex'));
end $report$;

-- Immutable revision actor UUID; current profile label is presentation only.
-- Do not claim a renamed profile is the name captured at correction time.
create function cp7_note.workspace_with_actors(p_sale uuid)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;w jsonb;history jsonb;
begin
 a:=cp7_note.access_now();w:=cp7_note.workspace(p_sale);
 select coalesce(jsonb_agg(h.value||jsonb_build_object('actor_id',r.actor,
  'actor_display_name',(select nullif(btrim(u.full_name),'')from erp.app_users u where u.auth_user_id=r.actor),
  'actor_name_basis','CURRENT_PROFILE')order by r.revision),'[]')into history
 from jsonb_array_elements(w->'history')h(value)join cp7_note.revisions r on r.id=(h.value->>'revision_id')::uuid;
 if cp7_note.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_NOTE_ACCESS_CHANGED';end if;
 return w||jsonb_build_object('contract_version','cp7.note-correction-workspace.v2','history',history);
end $$;
alter function cp7_note.workspace_with_actors(uuid)owner to postgres;
revoke all on function cp7_note.workspace_with_actors(uuid)from public,anon,authenticated,service_role,cp7_capture,cp7_sales_read,cp7_sales_write;
grant execute on function cp7_note.workspace_with_actors(uuid)to cp7_sales_write;
create function public.erp_cp7_get_note_correction_v2(p_sale uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_note.workspace_with_actors(p_sale)$$;
grant create on schema public to cp7_sales_write;
alter function public.erp_cp7_get_note_correction_v2(uuid)owner to cp7_sales_write;
revoke create on schema public from cp7_sales_write;
revoke all on function public.erp_cp7_get_note_correction_v2(uuid)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_note_correction_v2(uuid)to authenticated;

-- Exact source navigation only. No stock, money, cost, or document writer.
create role cp7_transaction_source_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication bypassrls;
create schema cp7_transaction_source authorization cp7_transaction_source_read;
revoke all on schema cp7_transaction_source from public,anon,authenticated,service_role;
grant usage on schema erp,auth to cp7_transaction_source_read;
grant usage on schema cp7_installment to cp7_transaction_source_read;
grant select on cp7_installment.payments to cp7_transaction_source_read;
grant usage on schema cp7_payment_correction to cp7_transaction_source_read;
grant select on cp7_payment_correction.links to cp7_transaction_source_read;
grant usage on schema cp7_supplier_payment_correction to cp7_transaction_source_read;
grant select on cp7_supplier_payment_correction.links to cp7_transaction_source_read;
grant usage on schema cp7_sales_return_correction to cp7_transaction_source_read;
grant select on cp7_sales_return_correction.links,cp7_sales_return_correction.journal_restatements to cp7_transaction_source_read;
grant execute on function auth.uid(),auth.jwt(),erp.get_my_access_v1(),erp.has_permission(text) to cp7_transaction_source_read;
grant select on erp.material_purchase_headers,erp.material_purchase_items,erp.material_rolls,
 erp.material_supplier_invoices,erp.material_supplier_invoice_lines,erp.supplier_payments,
 erp.material_transfers,erp.material_transfer_items,erp.material_adjustments,erp.material_adjustment_items,
 erp.fg_adjustments,erp.fg_adjustment_items,erp.sales_headers,erp.sales_items,erp.sales_payments,
 erp.sales_returns,erp.sales_return_items,erp.misc_finance_transactions,erp.journal_entries,erp.payroll_settlements,
 erp.contractor_material_issues,erp.contractor_material_issue_items,erp.materials,erp.uom_definitions,
 erp.bs_cases,erp.rework_orders,erp.qc_inspections,erp.qc_inspection_items,erp.fg_stock_movements,
 erp.laundry_deliveries,erp.laundry_delivery_lines,erp.laundry_delivery_batch_size_lines,
 erp.laundry_receipts,erp.laundry_receipt_lines,erp.laundry_receipt_batch_size_lines,
 erp.cutting_groups,erp.production_orders,erp.product_models
 to cp7_transaction_source_read;

create function cp7_transaction_source.authority()returns jsonb
language plpgsql stable security invoker set search_path=''as $$
declare a jsonb;
begin
 if auth.uid()is null or coalesce(auth.jwt()->>'role','')<>'authenticated'then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
 a:=erp.get_my_access_v1();
 -- Native active custom roles use their own role_code. Their current domain
 -- permissions below are authoritative for reads; a STAFF-code whitelist
 -- would reject an otherwise authorized owning workspace. Financial owner
 -- restrictions remain at their specific domains and never grant a writer.
 if a->'allowed'is distinct from'true'::jsonb then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
 return a;
end $$;

create function cp7_transaction_source.resolve(p jsonb)returns jsonb
language plpgsql stable security invoker set search_path=''set TimeZone='UTC'as $$
declare a jsonb;kind text;ident uuid;domain text;route text;permission text;
 parent_id uuid;doc jsonb;focus jsonb:='null';hops integer:=0;visited uuid[]:='{}';label text;focus_offset bigint;
begin
 if jsonb_typeof(p)is distinct from'object'or not(p?&array['source_type','source_id'])
  or(select count(*)from jsonb_object_keys(p))<>2 or jsonb_typeof(p->'source_type')is distinct from'string'
  or jsonb_typeof(p->'source_id')is distinct from'string'or p->>'source_type'!~'^[A-Z][A-Z0-9_]{0,79}$'
  or p->>'source_id'!~'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'then
  raise exception using errcode='22023',message='CP7_TRANSACTION_SOURCE_FIELDS';end if;
 a:=cp7_transaction_source.authority();kind:=p->>'source_type';ident:=(p->>'source_id')::uuid;
 -- Journal inverses point at journals, not at business documents. Follow
 -- only actual immutable journal links; never guess a document from a UUID.
 while kind='JOURNAL_REVERSAL'loop
  if not erp.has_permission('finance.journal.view')or a->'profile'->>'role_code'not in('OWNER','ADMIN')then
   raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
  hops:=hops+1;
  if hops>16 or ident=any(visited)then raise exception 'CP7_TRANSACTION_SOURCE_CHAIN_INVALID';end if;
  visited:=array_append(visited,ident);
  select j.source_type,j.source_id into kind,ident from erp.journal_entries j where j.id=ident;
  if not found or ident is null then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 end loop;
 -- Economic-date entries belong to the exact ordinary payment correction.
 -- Require both the immutable correction FK and the actual Native journal;
 -- an arbitrary payment UUID cannot masquerade as a correction source.
 if kind in('PAYMENT_CORRECTION_TIME_NEUTRAL','PAYMENT_CORRECTION_EFFECTIVE')then
  if not erp.has_permission('finance.journal.view')or a->'profile'->>'role_code'not in('OWNER','ADMIN')then
   raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
  if not exists(select 1 from cp7_payment_correction.links l join erp.journal_entries j
   on j.id=case when kind='PAYMENT_CORRECTION_TIME_NEUTRAL'then l.time_neutral_id else l.effective_inverse_id end
   where l.original_id=ident and j.source_type=kind and j.source_id=ident and j.status='POSTED')then
   raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
  kind:='SALES_PAYMENT';
 end if;
 if kind in('SUPPLIER_PAYMENT_CORRECTION_TIME_NEUTRAL','SUPPLIER_PAYMENT_CORRECTION_EFFECTIVE')then
  if not erp.has_permission('finance.journal.view')or a->'profile'->>'role_code'not in('OWNER','ADMIN')then
   raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
  if not exists(select 1 from cp7_supplier_payment_correction.links l join erp.journal_entries j
   on j.id=case when kind='SUPPLIER_PAYMENT_CORRECTION_TIME_NEUTRAL'then l.time_neutral_id else l.effective_inverse_id end
   where l.original_id=ident and j.source_type=kind and j.source_id=ident and j.status='POSTED')then
   raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
  kind:='SUPPLIER_PAYMENT';
 end if;
 if kind in('RETURN_CORRECTION_TIME_NEUTRAL','RETURN_CORRECTION_EFFECTIVE')then
  if not erp.has_permission('finance.journal.view')or a->'profile'->>'role_code'not in('OWNER','ADMIN')then
   raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
  select r.original_return_id into ident from cp7_sales_return_correction.journal_restatements r
   join cp7_sales_return_correction.links l on l.original_id=r.original_return_id
   join erp.journal_entries j on j.id=case when kind='RETURN_CORRECTION_TIME_NEUTRAL'then r.neutral_journal_id else r.effective_journal_id end
   where r.inverse_journal_id=ident and j.source_type=kind and j.source_id=r.inverse_journal_id and j.status='POSTED';
  if not found then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
  kind:='SALES_RETURN';
 end if;
 -- A Native FG inverse references the original movement UUID, not a QC
 -- inspection. Follow that actual immutable link only for the qualified QC
 -- source family. Other FG inverse families stay explicitly unsupported.
 if kind='FG_MOVEMENT_REVERSAL' then
  if not(erp.has_permission('warehouse.stock.view')or erp.has_permission('warehouse.movement.view'))then
   raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
  select m.source_type,m.source_id into kind,ident from erp.fg_stock_movements m where m.id=ident and m.reversal_of_id is null;
  if not found or ident is null then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
  if kind<>'QC_ITEM'and not(kind='SALES_RETURN_ITEM'and exists(select 1 from erp.sales_return_items i
   join cp7_sales_return_correction.links l on l.original_id=i.return_id where i.id=ident))then
   return jsonb_build_object('contract_version','cp7.transaction-source.v1','actor_scope_id',auth.uid(),'source',p,
    'status','UNSUPPORTED_SOURCE','document',null,'read_at',statement_timestamp(),'business_DML',false);
  end if;
 end if;
 case
 when kind in('MATERIAL_PURCHASE','MATERIAL_PURCHASE_GRNI_RECLASS','MATERIAL_PURCHASE_REVERSAL','MATERIAL_PURCHASE_ITEM','MATERIAL_PURCHASE_ROLL','MATERIAL_SUPPLIER_INVOICE','MATERIAL_SUPPLIER_INVOICE_LINE','SUPPLIER_PAYMENT')then
  domain:='RECEIPT';route:='procurement';permission:='warehouse.procurement.view';
 when kind in('MATERIAL_TRANSFER','MATERIAL_TRANSFER_ITEM')then
  domain:='MATERIAL_TRANSFER';route:='materials-rolls';permission:='warehouse.material.view';
 when kind in('MATERIAL_ADJUSTMENT','MATERIAL_ADJUSTMENT_ITEM')then
  domain:='MATERIAL_COUNT';route:='stock-adjustment';permission:='warehouse.material.view';
 when kind in('FG_ADJUSTMENT','FG_ADJUSTMENT_ITEM')then
  domain:='FG_ADJUSTMENT';route:='stock-adjustment';permission:='warehouse.fg.view';
 when kind in('SALE','SALE_ITEM','SALES_ITEM','SALES_PAYMENT','SALES_RETURN','SALES_RETURN_ITEM')then
  domain:='SALE';route:=case when kind='SALES_PAYMENT'then'sales-payments'when kind in('SALES_RETURN','SALES_RETURN_ITEM')then'sales-returns'else'sales-invoice'end;
  permission:='sales.invoice.view';
 when kind in('MISC_FINANCE','MISC_CORRECTION_TIME_NEUTRAL','MISC_CORRECTION_EFFECTIVE')then
  domain:='MISC_FINANCE';route:='finance-journal';permission:='finance.journal.view';
 when kind in('PAYROLL_ATTENDANCE_ACCRUAL','PAYROLL_EXTRA_ACCRUAL','PAYROLL_MANUAL_REDUCTION','PAYROLL_MATERIAL_DEDUCTION','PAYROLL_CASH_ADVANCE_DEDUCTION','PAYROLL_OTHER_DEDUCTION','PAYROLL_PAYMENT','PAYROLL_INSTALLMENT')then
  domain:='PAYROLL';route:='finance-payroll';permission:='finance.payroll.view';
 when kind in('CONTRACTOR_ACCESSORY_STOCK_COST','CONTRACTOR_MATERIAL_RECEIVABLE','CONTRACTOR_MATERIAL_ISSUE_ITEM')then
  domain:='ACCESSORY_ISSUE';route:='contractor-issue';permission:='finance.contractor_accessory.view';
 when kind in('REWORK_ORDER','REWORK_COMPLETION')then
  domain:='BS_REWORK';route:='bs-rework';permission:='production.bs_rework.view';
 when kind in('QC_INSPECTION','QC_ITEM')then
  domain:='QC';route:='qc';permission:='production.final_sku.view';
 when kind in('LAUNDRY_DELIVERY','LAUNDRY_DELIVERY_LINE','LAUNDRY_DELIVERY_BATCH_SIZE_LINE',
  'LAUNDRY_RECEIPT','LAUNDRY_RECEIPT_LINE','LAUNDRY_RECEIPT_BATCH_SIZE_LINE')then
  domain:='LAUNDRY';route:='laundry';permission:='production.laundry.view';
 when kind in('CUTTING_GROUP','CUTTING_MATERIAL_ISSUE')then
  -- Posted cutting is read by the existing Native ALL distribution queue,
  -- never by the unposted cutting-draft selector. Its current view right is
  -- production.distribution.view; cutting.view alone cannot open that reader.
  domain:='CUTTING';route:='mandor-wip';permission:='production.distribution.view';
 else
  return jsonb_build_object('contract_version','cp7.transaction-source.v1','actor_scope_id',auth.uid(),
   'source',p,'status','UNSUPPORTED_SOURCE','document',null,'read_at',statement_timestamp(),'business_DML',false);
 end case;
 -- Check the owner's current view permission before resolving child IDs or
 -- returning any Native document number/version. No finance is returned.
 if not erp.has_permission(permission)or(domain in('MATERIAL_COUNT','FG_ADJUSTMENT')and not erp.has_permission('warehouse.stock.adjust'))
  or(kind in('MATERIAL_SUPPLIER_INVOICE','MATERIAL_SUPPLIER_INVOICE_LINE','SUPPLIER_PAYMENT')and not erp.has_permission('finance.ap.view'))
  or(domain='MISC_FINANCE'and(not erp.has_permission('finance.cash.view')or a->'profile'->>'role_code'not in('OWNER','ADMIN')))
  or(kind='SALES_PAYMENT'and(not erp.has_permission('sales.payment.view')or not erp.has_permission('finance.ar.view')))
  or(kind in('SALES_RETURN','SALES_RETURN_ITEM')and(not erp.has_permission('sales.return.view')or not erp.has_permission('finance.ar.view')))then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
 parent_id:=ident;
 case kind
 when'MATERIAL_PURCHASE_ITEM'then select i.purchase_id into parent_id from erp.material_purchase_items i where i.id=ident;
 when'MATERIAL_PURCHASE_ROLL'then select i.purchase_id into parent_id from erp.material_rolls r join erp.material_purchase_items i on i.id=r.purchase_item_id where r.id=ident;
 when'MATERIAL_SUPPLIER_INVOICE'then
  select i.purchase_id into parent_id from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=ident order by i.purchase_id,l.id limit 1;
  focus:=jsonb_build_object('kind','PURCHASE_INVOICE','id',ident);
 when'MATERIAL_SUPPLIER_INVOICE_LINE'then
  select i.purchase_id,jsonb_build_object('kind','PURCHASE_INVOICE','id',l.invoice_id)into parent_id,focus
   from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.id=ident;
 when'SUPPLIER_PAYMENT'then
  select s.purchase_id into parent_id from erp.supplier_payments s where s.id=ident;
  focus:=jsonb_build_object('kind','SUPPLIER_PAYMENT','id',ident);
 when'MATERIAL_TRANSFER_ITEM'then select i.transfer_id into parent_id from erp.material_transfer_items i where i.id=ident;
 when'MATERIAL_ADJUSTMENT_ITEM'then select i.adjustment_id into parent_id from erp.material_adjustment_items i where i.id=ident;
 when'FG_ADJUSTMENT_ITEM'then select i.adjustment_id into parent_id from erp.fg_adjustment_items i where i.id=ident;
 when'SALE_ITEM','SALES_ITEM'then select i.sale_id into parent_id from erp.sales_items i where i.id=ident;
 when'SALES_PAYMENT'then
  select i.sale_id into parent_id from erp.sales_payments i where i.id=ident;
  focus:=jsonb_build_object('kind','SALES_PAYMENT','id',ident);
 when'SALES_RETURN'then
  select i.sale_id into parent_id from erp.sales_returns i where i.id=ident;
  focus:=jsonb_build_object('kind','SALES_RETURN','id',ident);
 when'SALES_RETURN_ITEM'then
  select i.sale_id,jsonb_build_object('kind','SALES_RETURN','id',i.id)into parent_id,focus
   from erp.sales_return_items l join erp.sales_returns i on i.id=l.return_id where l.id=ident;
 when'PAYROLL_INSTALLMENT'then
  select i.payroll_id into parent_id from cp7_installment.payments i where i.id=ident;
  focus:=jsonb_build_object('kind','PAYROLL_INSTALLMENT','id',ident);
 when'CONTRACTOR_MATERIAL_ISSUE_ITEM'then
  select i.issue_id into parent_id from erp.contractor_material_issue_items i where i.id=ident;
 when'REWORK_ORDER','REWORK_COMPLETION'then
  select r.bs_case_id into parent_id from erp.rework_orders r where r.id=ident;
  focus:=jsonb_build_object('kind','REWORK_ORDER','id',ident);
 when'QC_ITEM'then
  select i.inspection_id into parent_id from erp.qc_inspection_items i where i.id=ident;
 when'LAUNDRY_DELIVERY_LINE'then
  select l.delivery_id into parent_id from erp.laundry_delivery_lines l where l.id=ident;
 when'LAUNDRY_DELIVERY_BATCH_SIZE_LINE'then
  select l.delivery_id into parent_id from erp.laundry_delivery_batch_size_lines s
   join erp.laundry_delivery_lines l on l.id=s.delivery_line_id where s.id=ident;
 when'LAUNDRY_RECEIPT'then
  select r.delivery_id into parent_id from erp.laundry_receipts r where r.id=ident;
  focus:=jsonb_build_object('kind','LAUNDRY_RECEIPT','id',ident);
 when'LAUNDRY_RECEIPT_LINE'then
  select r.delivery_id,jsonb_build_object('kind','LAUNDRY_RECEIPT','id',r.id)into parent_id,focus
   from erp.laundry_receipt_lines l join erp.laundry_receipts r on r.id=l.receipt_id where l.id=ident;
 when'LAUNDRY_RECEIPT_BATCH_SIZE_LINE'then
  select r.delivery_id,jsonb_build_object('kind','LAUNDRY_RECEIPT','id',r.id)into parent_id,focus
   from erp.laundry_receipt_batch_size_lines s join erp.laundry_receipt_lines l on l.id=s.receipt_line_id
   join erp.laundry_receipts r on r.id=l.receipt_id where s.id=ident;
 else null;
 end case;
 if parent_id is null then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 case domain
 when'RECEIPT'then select to_jsonb(h),h.purchase_number into doc,label from erp.material_purchase_headers h where h.id=parent_id;
 when'MATERIAL_TRANSFER'then select to_jsonb(h),h.transfer_number into doc,label from erp.material_transfers h where h.id=parent_id;
 when'MATERIAL_COUNT'then select to_jsonb(h),h.adjustment_number into doc,label from erp.material_adjustments h where h.id=parent_id;
 when'FG_ADJUSTMENT'then select to_jsonb(h),h.adjustment_number into doc,label from erp.fg_adjustments h where h.id=parent_id;
 when'SALE'then select to_jsonb(h),h.sale_number into doc,label from erp.sales_headers h where h.id=parent_id;
 when'MISC_FINANCE'then select to_jsonb(h),h.transaction_number into doc,label from erp.misc_finance_transactions h where h.id=parent_id;
 when'PAYROLL'then select to_jsonb(h),h.payroll_number into doc,label from erp.payroll_settlements h where h.id=parent_id;
 when'ACCESSORY_ISSUE'then select to_jsonb(h),h.issue_number into doc,label from erp.contractor_material_issues h where h.id=parent_id;
 when'BS_REWORK'then select to_jsonb(h),h.bs_number into doc,label from erp.bs_cases h where h.id=parent_id;
 when'QC'then select to_jsonb(h),h.inspection_number into doc,label from erp.qc_inspections h where h.id=parent_id;
 when'LAUNDRY'then select to_jsonb(h),h.delivery_number into doc,label from erp.laundry_deliveries h where h.id=parent_id;
 when'CUTTING'then
  select to_jsonb(g),g.group_number into doc,label from erp.cutting_groups g
   join erp.production_orders po on po.id=g.po_id
   join erp.product_models pm on pm.id=po.model_id where g.id=parent_id;
 end case;
 if doc is null or coalesce(label,'')=''then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 if domain='CUTTING'then
  if doc->'material_issue_posted'is distinct from'true'::jsonb then
   return jsonb_build_object('contract_version','cp7.transaction-source.v1','actor_scope_id',auth.uid(),
    'source',p,'status','UNSUPPORTED_SOURCE','document',null,'read_at',statement_timestamp(),'business_DML',false);
  end if;
  focus:=jsonb_build_object('kind','CUTTING_GROUP','id',parent_id,'parent_id',doc->>'po_id');
 end if;
 -- The existing CP6 owner reads complete Native laundry-linked QC only.
 -- Legacy/import outputs are distinct sources, never guessed into this form.
 if domain='QC'and(not exists(select 1 from erp.qc_inspection_items i where i.inspection_id=parent_id)
  or exists(select 1 from erp.qc_inspection_items i where i.inspection_id=parent_id and i.source_laundry_receipt_batch_size_line_id is null))then
  return jsonb_build_object('contract_version','cp7.transaction-source.v1','actor_scope_id',auth.uid(),
   'source',p,'status','UNSUPPORTED_SOURCE','document',null,'read_at',statement_timestamp(),'business_DML',false);
 end if;
 -- The unchanged owning Laundry workspace reads batch-linked deliveries.
 -- Receipt numbers are not searched by that reader: use its actual delivery
 -- number and recheck the embedded receipt UUID inside that exact parent.
 if domain='LAUNDRY'and(not exists(select 1 from erp.laundry_delivery_lines l where l.delivery_id=parent_id)
  or exists(select 1 from erp.laundry_delivery_lines l where l.delivery_id=parent_id
   and not exists(select 1 from erp.laundry_delivery_batch_size_lines s where s.delivery_line_id=l.id)))then
  return jsonb_build_object('contract_version','cp7.transaction-source.v1','actor_scope_id',auth.uid(),
   'source',p,'status','UNSUPPORTED_SOURCE','document',null,'read_at',statement_timestamp(),'business_DML',false);
 end if;
 -- The current owner is specifically a counted-PCS accessory workspace.
 -- A mixed or fabric issue is a different Native document and cannot be
 -- redirected into that editor merely because its receivable has this kind.
 if domain='ACCESSORY_ISSUE'and exists(
  select 1 from erp.contractor_material_issue_items i
   left join erp.materials m on m.id=i.material_id
   left join erp.uom_definitions u on u.unit_code=m.unit_code
  where i.issue_id=parent_id and(m.material_type is distinct from'ACCESSORY'
   or upper(m.unit_code)is distinct from'PCS'or u.dimension is distinct from'COUNT'))then
  return jsonb_build_object('contract_version','cp7.transaction-source.v1','actor_scope_id',auth.uid(),
   'source',p,'status','UNSUPPORTED_SOURCE','document',null,'read_at',statement_timestamp(),'business_DML',false);
 end if;
 -- Match each unchanged owning reader's pagination and exact ordering.
 -- BS uses ALL/BS, no query or pattern, and 50 rows; other children use 25.
 -- The owner re-reads the page and checks both identities; no client scan.
 if focus is not null and focus<>'null'::jsonb then
  case focus->>'kind'
  when'CUTTING_GROUP'then
   -- Exactly Native get_cutting_pickup_queue_v1(ALL,NULL,NULL,100,offset):
   -- all posted groups including picked-up/finished PO history, same inner
   -- joins and cut_at/group_number/id order. No query scan or first-row guess.
   select ((n-1)/100)*100 into focus_offset from(
    select g.id,row_number()over(order by g.cut_at,g.group_number,g.id)n
    from erp.cutting_groups g join erp.production_orders po on po.id=g.po_id
    join erp.product_models pm on pm.id=po.model_id where g.material_issue_posted
   )x where id=parent_id;
  when'LAUNDRY_RECEIPT'then
   -- Embedded child, not an independently paginated list. Zero is the closed
   -- focus position; the owner re-reads and checks this receipt's actual FK.
   if exists(select 1 from erp.laundry_receipts r where r.id=(focus->>'id')::uuid and r.delivery_id=parent_id)then
    focus_offset:=0;
   end if;
  when'SALES_PAYMENT'then
   select ((n-1)/25)*25 into focus_offset from(select id,row_number()over(order by payment_date desc,id)n from erp.sales_payments where sale_id=parent_id)x where id=(focus->>'id')::uuid;
  when'SALES_RETURN'then
   select ((n-1)/25)*25 into focus_offset from(select id,row_number()over(order by physical_at desc,id)n from erp.sales_returns where sale_id=parent_id)x where id=(focus->>'id')::uuid;
  when'PURCHASE_INVOICE'then
   select ((n-1)/25)*25 into focus_offset from(select ih.id,row_number()over(order by ih.received_at desc,ih.id)n from erp.material_supplier_invoices ih where exists(select 1 from erp.material_supplier_invoice_lines l join erp.material_purchase_items i on i.id=l.purchase_item_id where l.invoice_id=ih.id and i.purchase_id=parent_id))x where id=(focus->>'id')::uuid;
  when'SUPPLIER_PAYMENT'then
   select ((n-1)/25)*25 into focus_offset from(select p.id,row_number()over(order by p.payment_date,p.created_at,p.id)n from erp.supplier_payments p where p.purchase_id=parent_id)x where id=(focus->>'id')::uuid;
  when'PAYROLL_INSTALLMENT'then
   -- Match the existing installment source loop, including reversed history.
   select ((n-1)/25)*25 into focus_offset from(select i.id,row_number()over(order by i.payment_date,i.created_at,i.id)n from cp7_installment.payments i where i.payroll_id=parent_id)x where id=(focus->>'id')::uuid;
  when'REWORK_ORDER'then
   -- Native get_bs_resolution_workspace_v1 orders open cases before closed,
   -- then physical_at DESC, bs_number, id. Status comes from the same header;
   -- the Native owning reader remains authoritative for quantities and history.
   select ((n-1)/50)*50 into focus_offset from(select b.id,row_number()over(
    order by(b.status in('RESOLVED','SCRAPPED','WRITTEN_OFF','CANCELLED')),
     b.physical_at desc,b.bs_number,b.id)n from erp.bs_cases b)x where id=parent_id;
  end case;
  if focus_offset is null or focus_offset>1000000 then raise exception 'CP7_TRANSACTION_SOURCE_FOCUS_UNAVAILABLE';end if;
  focus:=focus||jsonb_build_object('page_offset',focus_offset);
 end if;
 if cp7_transaction_source.authority()is distinct from a or not erp.has_permission(permission)then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.transaction-source.v1','actor_scope_id',auth.uid(),'source',p,
  'status','AVAILABLE','document',jsonb_build_object('domain',domain,'route',route,'id',parent_id,'number',label,
   'status',doc->'status','revision',doc->>'row_version','focus',focus),
  'read_at',statement_timestamp(),'business_DML',false);
end $$;

alter function cp7_transaction_source.authority()owner to cp7_transaction_source_read;
alter function cp7_transaction_source.resolve(jsonb)owner to cp7_transaction_source_read;
revoke all on function cp7_transaction_source.authority(),cp7_transaction_source.resolve(jsonb)from public,anon,authenticated,service_role;
grant create on schema public to cp7_transaction_source_read;
create function public.erp_cp7_resolve_transaction_source_v1(p_source jsonb)returns jsonb
language sql stable security definer set search_path=''as $$select cp7_transaction_source.resolve(p_source)$$;
alter function public.erp_cp7_resolve_transaction_source_v1(jsonb)owner to cp7_transaction_source_read;
revoke create on schema public from cp7_transaction_source_read;
revoke all on function public.erp_cp7_resolve_transaction_source_v1(jsonb)from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_resolve_transaction_source_v1(jsonb)to authenticated;
grant execute on function public.erp_cp7_resolve_transaction_source_v1(jsonb)to postgres;

-- Current, paginated Native QC dependencies of one physical Laundry receipt.
-- Uses the existing read-only source role; no inverse, reservation or ERP DML.
create function cp7_transaction_source.dependencies(p_source jsonb,p_offset integer)returns jsonb
language plpgsql stable security invoker set search_path=''set TimeZone='UTC'as $$
declare a jsonb;ident uuid;h erp.laundry_receipts%rowtype;n bigint;items jsonb;
begin
 if jsonb_typeof(p_source)is distinct from'object'or not(p_source?&array['source_type','source_id'])
  or(select count(*)from jsonb_object_keys(p_source))<>2
  or p_source->>'source_type'is distinct from'LAUNDRY_RECEIPT'
  or jsonb_typeof(p_source->'source_id')is distinct from'string'
  or p_source->>'source_id'!~'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or p_offset is null or p_offset<0 or p_offset>1000000 or p_offset%25<>0 then
  raise exception using errcode='22023',message='CP7_TRANSACTION_DEPENDENCY_FIELDS';end if;
 a:=cp7_transaction_source.authority();
 -- Both current view permissions precede header/FK resolution. Laundry view
 -- alone never exposes inspection numbers from another operational domain.
 if not erp.has_permission('production.laundry.view')or not erp.has_permission('production.final_sku.view')then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_DENIED';end if;
 ident:=(p_source->>'source_id')::uuid;
 select * into h from erp.laundry_receipts where id=ident;
 if not found then raise exception 'CP7_TRANSACTION_SOURCE_UNAVAILABLE';end if;
 -- Exactly the relationship and active-status predicate used by the frozen
 -- Native receipt inverse. EXISTS deduplicates a QC with multiple source lines.
 select count(*)into n from erp.qc_inspections q where q.status<>'REVERSED'and exists(
  select 1 from erp.qc_inspection_items i join erp.laundry_receipt_lines l on l.id=i.source_laundry_receipt_line_id
  where i.inspection_id=q.id and l.receipt_id=ident);
 select coalesce(jsonb_agg(x.item order by x.physical_at desc,x.id),'[]'::jsonb)into items from(
  select q.id,q.physical_at,jsonb_build_object('source_type','QC_INSPECTION','source_id',q.id,
   'number',q.inspection_number,'status',q.status,'revision',q.row_version::text)as item
  from erp.qc_inspections q where q.status<>'REVERSED'and exists(
   select 1 from erp.qc_inspection_items i join erp.laundry_receipt_lines l on l.id=i.source_laundry_receipt_line_id
   where i.inspection_id=q.id and l.receipt_id=ident)
  order by q.physical_at desc,q.id limit 25 offset p_offset
 )x;
 if cp7_transaction_source.authority()is distinct from a
  or not erp.has_permission('production.laundry.view')or not erp.has_permission('production.final_sku.view')then
  raise exception using errcode='42501',message='CP7_TRANSACTION_SOURCE_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.transaction-dependencies.v1','actor_scope_id',auth.uid(),
  'source',p_source,'parent',jsonb_build_object('id',h.id,'number',h.receipt_number,'status',h.status,'revision',h.row_version::text),
  'page',jsonb_build_object('offset',p_offset,'limit',25,'total',n,'has_more',p_offset+jsonb_array_length(items)<n),
  'dependencies',items,'read_at',statement_timestamp(),'business_DML',false);
end $$;
alter function cp7_transaction_source.dependencies(jsonb,integer)owner to cp7_transaction_source_read;
revoke all on function cp7_transaction_source.dependencies(jsonb,integer)from public,anon,authenticated,service_role;
grant create on schema public to cp7_transaction_source_read;
create function public.erp_cp7_get_transaction_dependencies_v1(p_source jsonb,p_offset integer default 0)returns jsonb
language sql stable security definer set search_path=''as $$select cp7_transaction_source.dependencies(p_source,p_offset)$$;
alter function public.erp_cp7_get_transaction_dependencies_v1(jsonb,integer)owner to cp7_transaction_source_read;
revoke create on schema public from cp7_transaction_source_read;
revoke all on function public.erp_cp7_get_transaction_dependencies_v1(jsonb,integer)from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_get_transaction_dependencies_v1(jsonb,integer)to authenticated;

-- One atomic correction through the unchanged reviewed miscellaneous writers.
-- Posted documents and their Native journals remain append-only history.
create schema cp7_misc_correction authorization cp7_misc_read;
revoke all on schema cp7_misc_correction from public,anon,authenticated,service_role,cp7_capture;
grant usage,create on schema cp7_misc_correction to cp7_misc_write;
create table cp7_misc_correction.links(
 original_id uuid primary key references erp.misc_finance_transactions(id),
 replacement_id uuid not null unique references erp.misc_finance_transactions(id),
 actor uuid not null,request_id uuid not null,reason text not null,
 time_neutral_id uuid references erp.journal_entries(id),effective_inverse_id uuid references erp.journal_entries(id),
 recorded_at timestamptz not null default statement_timestamp(),
 check(original_id<>replacement_id),check(length(btrim(reason))between 5 and 1000),
 check((time_neutral_id is null)=(effective_inverse_id is null)),
 unique(actor,request_id)
);
alter table cp7_misc_correction.links owner to cp7_misc_write;
alter table cp7_misc_correction.links enable row level security;
create policy cp7_misc_correction_links_deny on cp7_misc_correction.links for all to public using(false)with check(false);
revoke all on cp7_misc_correction.links from public,anon,authenticated,service_role,cp7_capture;
grant select on cp7_misc_correction.links to cp7_misc_read;

create function cp7_misc_correction.validate(p jsonb)returns void
language plpgsql immutable security invoker set search_path=''as $$
begin
 if jsonb_typeof(p)is distinct from'object'or not(p?&array['transaction_id','review_token','replacement','change_reason'])
  or(select count(*)from jsonb_object_keys(p))<>4 then raise exception 'CP7_MISC_CORRECTION_FIELDS';end if;
 perform cp7_misc.validate('REVERSE',p-'replacement');
 perform cp7_misc.validate('SAVE',p->'replacement');
 if p->'replacement'->'transaction_id'is distinct from'null'::jsonb
  or p->'replacement'->'review_token'is distinct from'null'::jsonb
  or p->'replacement'->>'change_reason'is distinct from p->>'change_reason'then
  raise exception 'CP7_MISC_CORRECTION_FIELDS';end if;
end $$;

create function cp7_misc_correction.link_value(p cp7_misc_correction.links)returns jsonb
language sql stable security invoker set search_path=''set TimeZone='UTC'as $$
 select jsonb_build_object('original_id',p.original_id,'replacement_id',p.replacement_id,
  'actor_scope_id',p.actor,'request_id',p.request_id,'reason',p.reason,'recorded_at',p.recorded_at,
  'time_restatement',case when p.time_neutral_id is null then null else(
   select jsonb_build_object('neutral_journal_id',n.id,'neutral_number',n.journal_number,'neutral_economic_date',n.economic_date,'neutral_transaction_date',n.transaction_date,
    'effective_journal_id',e.id,'effective_number',e.journal_number,'effective_economic_date',e.economic_date,'effective_transaction_date',e.transaction_date)
   from erp.journal_entries n join erp.journal_entries e on e.id=p.effective_inverse_id where n.id=p.time_neutral_id)end)
$$;

create function cp7_misc_correction.history(p_id uuid)returns jsonb
language plpgsql stable security invoker set search_path=''set TimeZone='UTC'as $$
declare a jsonb;prev cp7_misc_correction.links;nxt cp7_misc_correction.links;previous jsonb:='null';following jsonb:='null';
begin
 a:=cp7_misc.access_now();
 if p_id is null or cp7_misc.source(p_id)is null then raise exception 'CP7_MISC_NOT_FOUND';end if;
 select * into prev from cp7_misc_correction.links where replacement_id=p_id;
 select * into nxt from cp7_misc_correction.links where original_id=p_id;
 if prev.original_id is not null then previous:=jsonb_build_object('link',cp7_misc_correction.link_value(prev),'document',cp7_misc.source(prev.original_id));end if;
 if nxt.original_id is not null then following:=jsonb_build_object('link',cp7_misc_correction.link_value(nxt),'document',cp7_misc.source(nxt.replacement_id));end if;
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.misc-correction-history.v1','captured_at',statement_timestamp(),
  'transaction_id',p_id,'previous',previous,'next',following);
end $$;

create function cp7_misc_correction.protect_link()returns trigger
language plpgsql volatile security definer set search_path=''as $$
begin
 if tg_op<>'INSERT'then raise exception 'CP7_MISC_CORRECTION_LINK_IMMUTABLE';end if;
 if not exists(select 1 from cp7_misc.command_context c where c.backend_pid=pg_backend_pid()
  and c.transaction_id=txid_current()and c.actor=auth.uid()and c.actor=new.actor
  and c.request_id=new.request_id and c.action='CORRECT'
  and c.payload->>'transaction_id'=new.original_id::text and btrim(c.payload->>'change_reason')=new.reason)
  or not exists(select 1 from erp.misc_finance_transactions t where t.id=new.original_id and t.status='REVERSED')
  or not exists(select 1 from erp.misc_finance_transactions t where t.id=new.replacement_id and t.status='POSTED')then
  raise exception using errcode='42501',message='CP7_MISC_PRIVATE_CONTEXT_REQUIRED';end if;
 if new.time_neutral_id is not null and(not exists(select 1 from erp.journal_entries where id=new.time_neutral_id and source_type='MISC_CORRECTION_TIME_NEUTRAL'and source_id=new.original_id and status='POSTED')
  or not exists(select 1 from erp.journal_entries where id=new.effective_inverse_id and source_type='MISC_CORRECTION_EFFECTIVE'and source_id=new.original_id and status='POSTED'))then
  raise exception 'CP7_MISC_JOURNAL_SOURCE_CHANGED';end if;
 return new;
end $$;
create trigger cp7_misc_correction_link_immutable before insert or update or delete on cp7_misc_correction.links
 for each row execute function cp7_misc_correction.protect_link();
create trigger cp7_misc_correction_link_no_truncate before truncate on cp7_misc_correction.links
 for each statement execute function cp7_misc_correction.protect_link();

create function cp7_misc_correction.apply(p jsonb,p_request uuid)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;original erp.misc_finance_transactions;review jsonb;replacement jsonb;reversed jsonb;saved jsonb;posted jsonb;link cp7_misc_correction.links;intent jsonb;
 original_journal erp.journal_entries;inverse_journal erp.journal_entries;lines jsonb;neutral uuid;effective uuid;
begin
 a:=cp7_misc.access_now();perform cp7_misc_correction.validate(p);
 if not exists(select 1 from cp7_misc.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current()
  and actor=auth.uid()and request_id=p_request and action='CORRECT'and payload=p)then
  raise exception using errcode='42501',message='CP7_MISC_PRIVATE_CONTEXT_REQUIRED';end if;
 select * into original from erp.misc_finance_transactions where id=(p->>'transaction_id')::uuid for update;
 if original.id is null then raise exception 'CP7_MISC_NOT_FOUND';end if;
 lock table erp.accounting_account_mappings in share mode;
 perform 1 from erp.misc_finance_categories where id in(original.category_id,(p->'replacement'->>'category_id')::uuid)order by id for share;
 perform 1 from erp.cash_accounts where id in(original.cash_account_id,(p->'replacement'->>'cash_account_id')::uuid)order by id for share;
 perform 1 from erp.chart_accounts where id in(
  select default_account_id from erp.misc_finance_categories where id in(original.category_id,(p->'replacement'->>'category_id')::uuid)
  union select coa_account_id from erp.cash_accounts where id in(original.cash_account_id,(p->'replacement'->>'cash_account_id')::uuid))order by id for share;
 perform 1 from erp.journal_entries j where(j.source_type='MISC_FINANCE'and j.source_id=original.id)
  or j.reversal_of_id in(select id from erp.journal_entries where source_type='MISC_FINANCE'and source_id=original.id)order by j.id for update;
 perform 1 from erp.journal_lines l where l.journal_entry_id in(select id from erp.journal_entries where source_type='MISC_FINANCE'and source_id=original.id)order by l.id for update;
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 review:=cp7_misc.source(original.id);
 if review->>'review_token'is distinct from p->>'review_token'then raise exception 'CP7_MISC_REVIEW_CHANGED';end if;
 if original.status<>'POSTED'then raise exception 'CP7_MISC_POSTED_ONLY';end if;
 if exists(select 1 from cp7_misc_correction.links where original_id=original.id)then raise exception 'CP7_MISC_ALREADY_CORRECTED';end if;
 if p->'replacement'->>'transaction_number'is distinct from original.transaction_number then raise exception 'CP7_MISC_CORRECTION_NUMBER';end if;
 -- Keep the original number. A bounded full-request suffix identifies the
 -- replacement without a caller-chosen row ID or collision-prone counter.
 replacement:=(p->'replacement')||jsonb_build_object('transaction_number',left(original.transaction_number,20)||' · K-'||replace(p_request::text,'-',''));
 -- These calls reuse every Native amount, source, close, audit and current
 -- authority guard. All three are in this single transaction. Any failure
 -- rolls back the inverse, replacement, journals, link and UUID receipt.
 delete from cp7_misc.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 intent:=p-'replacement';
 insert into cp7_misc.command_context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,'REVERSE',intent);
 reversed:=cp7_misc.apply_command('REVERSE',intent,p_request);
 -- A plain Native inverse has today's economic date. Correcting an old
 -- document also needs its inverse's effect at the original economic date.
 -- Reuse the exact immutable Native lines, as the owning note correction
 -- does: neutralize today, apply at the original date. Native post_journal
 -- alone selects the allowed open accounting date; closed books stay intact.
 select * into strict original_journal from erp.journal_entries where source_type='MISC_FINANCE'and source_id=original.id and reversal_of_id is null;
 select * into strict inverse_journal from erp.journal_entries where reversal_of_id=original_journal.id and source_type='JOURNAL_REVERSAL'and source_id=original_journal.id;
 if original_journal.status<>'REVERSED'or inverse_journal.status<>'POSTED'then raise exception 'CP7_MISC_JOURNAL_SOURCE_CHANGED';end if;
 if original_journal.economic_date<>inverse_journal.economic_date then
  select jsonb_agg(jsonb_build_object('account_id',l.account_id,'debit',l.credit,'credit',l.debit,'description',l.description,
   'customer_id',l.customer_id,'vendor_id',l.vendor_id,'contractor_id',l.contractor_id,'po_id',l.po_id,'product_id',l.product_id)order by l.id)into lines
   from erp.journal_lines l where l.journal_entry_id=inverse_journal.id;
  neutral:=erp.post_journal('MISC_CORRECTION_TIME_NEUTRAL',original.id,inverse_journal.economic_date,'Koreksi transaksi lain: pindahkan waktu ekonomi pembalikan | '||btrim(p->>'change_reason'),lines);
  select jsonb_agg(jsonb_build_object('account_id',l.account_id,'debit',l.debit,'credit',l.credit,'description',l.description,
   'customer_id',l.customer_id,'vendor_id',l.vendor_id,'contractor_id',l.contractor_id,'po_id',l.po_id,'product_id',l.product_id)order by l.id)into lines
   from erp.journal_lines l where l.journal_entry_id=inverse_journal.id;
  effective:=erp.post_journal('MISC_CORRECTION_EFFECTIVE',original.id,original_journal.economic_date,'Koreksi transaksi lain: waktu ekonomi kejadian asal | '||btrim(p->>'change_reason'),lines);
 end if;
 delete from cp7_misc.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 insert into cp7_misc.command_context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,'SAVE',replacement);
 saved:=cp7_misc.apply_command('SAVE',replacement,p_request);
 delete from cp7_misc.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 intent:=jsonb_build_object('transaction_id',saved->>'transaction_id','review_token',saved->'document'->>'review_token','change_reason',p->>'change_reason');
 insert into cp7_misc.command_context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,'POST',intent);
 posted:=cp7_misc.apply_command('POST',intent,p_request);
 delete from cp7_misc.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 insert into cp7_misc.command_context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,'CORRECT',p);
 insert into cp7_misc_correction.links(original_id,replacement_id,actor,request_id,reason,time_neutral_id,effective_inverse_id)
  values(original.id,(posted->>'transaction_id')::uuid,auth.uid(),p_request,btrim(p->>'change_reason'),neutral,effective)returning * into link;
 return posted||jsonb_build_object('original_document',reversed->'document','original_review_token',p->>'review_token','link',cp7_misc_correction.link_value(link));
end $$;

create function cp7_misc_correction.command(p jsonb,p_request uuid)returns jsonb
language plpgsql volatile security invoker set search_path=''as $$
declare a jsonb;saved cp7_misc.requests;r jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_misc.access_now();perform cp7_misc_correction.validate(p);
 if p_request is null then raise exception 'CP7_MISC_COMMAND_FIELDS';end if;
 insert into cp7_misc.requests(actor,request_id,action,payload)values(auth.uid(),p_request,'CORRECT',p)on conflict do nothing;
 select * into saved from cp7_misc.requests where actor=auth.uid()and request_id=p_request for update;
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 if saved.action<>'CORRECT'or saved.payload is distinct from p then raise exception 'CP7_MISC_REQUEST_CHANGED';end if;
 if saved.response is not null then return saved.response;end if;
 insert into cp7_misc.command_context values(pg_backend_pid(),txid_current(),auth.uid(),p_request,'CORRECT',p);
 r:=cp7_misc_correction.apply(p,p_request);
 delete from cp7_misc.command_context where backend_pid=pg_backend_pid()and transaction_id=txid_current();
 if cp7_misc.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_MISC_ACCESS_CHANGED';end if;
 r:=r||jsonb_build_object('contract_version','cp7.misc-correction.v1','kind','COMMITTED_OUTCOME','action','CORRECT','request_id',p_request);
 update cp7_misc.requests set response=r where actor=auth.uid()and request_id=p_request;return r;
end $$;

alter function cp7_misc_correction.validate(jsonb)owner to cp7_misc_read;
alter function cp7_misc_correction.link_value(cp7_misc_correction.links)owner to cp7_misc_read;
alter function cp7_misc_correction.history(uuid)owner to cp7_misc_read;
alter function cp7_misc_correction.command(jsonb,uuid)owner to cp7_misc_write;
alter function cp7_misc_correction.apply(jsonb,uuid)owner to postgres;
alter function cp7_misc_correction.protect_link()owner to postgres;
revoke all on all functions in schema cp7_misc_correction from public,anon,authenticated,service_role,cp7_capture;
grant execute on function cp7_misc_correction.validate(jsonb),cp7_misc_correction.apply(jsonb,uuid)to cp7_misc_write;
grant execute on function cp7_misc_correction.link_value(cp7_misc_correction.links)to cp7_misc_write;
-- Hosted postgres is an ordinary privileged owner, not a superuser. The
-- definer driver needs these exact private capabilities; no app principal
-- receives private context access, ERP DML or a Native writer grant.
grant usage on schema cp7_misc_correction to postgres;
grant execute on function cp7_misc_correction.validate(jsonb),cp7_misc_correction.link_value(cp7_misc_correction.links)to postgres;
grant select,insert on cp7_misc_correction.links to postgres;
grant insert,delete on cp7_misc.command_context to postgres;
revoke create on schema cp7_misc_correction from cp7_misc_write;

create function public.erp_cp7_correct_misc_finance_v1(p_payload jsonb,p_request uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_misc_correction.command(p_payload,p_request)$$;
alter function public.erp_cp7_correct_misc_finance_v1(jsonb,uuid)owner to cp7_misc_write;
revoke all on function public.erp_cp7_correct_misc_finance_v1(jsonb,uuid)from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_correct_misc_finance_v1(jsonb,uuid)to authenticated;
create function public.erp_cp7_get_misc_correction_history_v1(p_transaction_id uuid)returns jsonb
language sql stable security definer set search_path=''as $$select cp7_misc_correction.history(p_transaction_id)$$;
alter function public.erp_cp7_get_misc_correction_history_v1(uuid)owner to cp7_misc_read;
revoke all on function public.erp_cp7_get_misc_correction_history_v1(uuid)from public,anon,authenticated,service_role;
grant execute on function public.erp_cp7_get_misc_correction_history_v1(uuid)to authenticated;

-- One explicitly reviewed sale/payment/return cancellation transaction.
-- Reuse the admitted owning commands. No Native helper or guard is replaced.
create schema cp7_sales_chain authorization cp7_sales_read;
revoke all on schema cp7_sales_chain from public,anon,authenticated,service_role,cp7_capture;
grant usage on schema cp7_sales_chain to postgres,cp7_sales_write;
create table cp7_sales_chain.requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,
 expected_version text not null,response jsonb,primary key(actor,request_id)
);
create table cp7_sales_chain.history(
 actor uuid not null,request_id uuid not null,sale_id uuid not null references erp.sales_headers,
 reviewed_source jsonb not null,steps jsonb not null,reason text not null,
 recorded_at timestamptz not null default clock_timestamp(),primary key(actor,request_id),unique(sale_id)
);
alter table cp7_sales_chain.requests owner to postgres;
alter table cp7_sales_chain.history owner to postgres;
alter table cp7_sales_chain.requests enable row level security;
alter table cp7_sales_chain.history enable row level security;
create policy private_requests on cp7_sales_chain.requests for all using(false)with check(false);
create policy private_history on cp7_sales_chain.history for all using(false)with check(false);
revoke all on all tables in schema cp7_sales_chain from public,anon,authenticated,service_role,cp7_capture,cp7_sales_read,cp7_sales_write;

create function cp7_sales_chain.access_now()returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;
begin
 a:=cp7_sales.command_access('SALE_REVERSE');
 if cp7_sales.command_access('PAYMENT_REVERSE')is distinct from a
  or cp7_sales.command_access('RETURN_REVERSE')is distinct from a
  or erp.has_permission('finance.hpp.view')is distinct from true then
  raise exception using errcode='42501',message='CP7_SALES_CHAIN_DENIED';end if;
 return a;
end $$;

create function cp7_sales_chain.immutable()returns trigger
language plpgsql security invoker set search_path=''as $$
begin raise exception 'CP7_SALES_CHAIN_HISTORY_IMMUTABLE';end $$;
create trigger immutable_history before update or delete on cp7_sales_chain.history
 for each row execute function cp7_sales_chain.immutable();
create trigger immutable_history_truncate before truncate on cp7_sales_chain.history
 for each statement execute function cp7_sales_chain.immutable();

create function cp7_sales_chain.snapshot(p_sale uuid)returns jsonb
language sql stable security definer set search_path=''set TimeZone='UTC'as $$
 select jsonb_build_object('sale_id',h.id,'number',h.sale_number,'status',h.status,
  'row_version',h.row_version::text,'review_token',cp7_sales.review_token(h.id),
  'payments',coalesce((select jsonb_agg(jsonb_build_object('id',p.id,'number',p.payment_number,
   'physical_at',p.payment_date,'amount',p.amount::text)order by p.payment_date desc,p.id)
   from erp.sales_payments p where p.sale_id=h.id and p.status='POSTED'),'[]'),
  'returns',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'number',r.return_number,
   'physical_at',r.physical_at,'line_count',(select count(*)::text from erp.sales_return_items i where i.return_id=r.id))
   order by r.physical_at desc,r.id)from erp.sales_returns r where r.sale_id=h.id and r.status='POSTED'),'[]'),
  'pending_children',coalesce((select jsonb_agg(x order by x->>'kind',x->>'id')from(
   select jsonb_build_object('kind','PAYMENT','id',p.id,'number',p.payment_number)as x
    from erp.sales_payments p where p.sale_id=h.id and p.status='DRAFT'
   union all select jsonb_build_object('kind','RETURN','id',r.id,'number',r.return_number)
    from erp.sales_returns r where r.sale_id=h.id and r.status='DRAFT')pending),'[]'))
 from erp.sales_headers h where h.id=p_sale
$$;

create function cp7_sales_chain.token(p_sale uuid)returns text
language sql stable security definer set search_path=''as $$
 select md5(jsonb_build_object('source',cp7_sales_chain.snapshot(h.id),
  'header',to_jsonb(h),
  'payments',(select jsonb_agg(to_jsonb(p)order by p.id)from erp.sales_payments p where p.sale_id=h.id),
  'returns',(select jsonb_agg(to_jsonb(r)order by r.id)from erp.sales_returns r where r.sale_id=h.id),
  'return_items',(select jsonb_agg(to_jsonb(i)order by i.id)from erp.sales_return_items i
   where exists(select 1 from erp.sales_returns r where r.id=i.return_id and r.sale_id=h.id)),
  'stock',(select jsonb_agg(to_jsonb(m)order by m.id)from erp.fg_stock_movements m where exists(
   select 1 from erp.sale_stock_allocations a join erp.sales_items i on i.id=a.sale_item_id
   where i.sale_id=h.id and a.lot_id=m.lot_id)),
  'hpp',(select jsonb_agg(to_jsonb(v)order by v.id)from erp.hpp_versions v where v.is_current and exists(
   select 1 from erp.sale_stock_allocations a join erp.sales_items i on i.id=a.sale_item_id
   where i.sale_id=h.id and a.lot_id=v.lot_id)),
  'cash',(select jsonb_agg(to_jsonb(c)order by c.id)from erp.cash_accounts c where exists(
   select 1 from erp.sales_payments p where p.sale_id=h.id and p.status='POSTED'and p.cash_account_id=c.id)),
  'accounts',(select jsonb_agg(to_jsonb(c)order by c.id)from erp.chart_accounts c where c.id in(
   select account_id from erp.accounting_account_mappings union select coa_account_id from erp.cash_accounts
    where id in(select cash_account_id from erp.sales_payments where sale_id=h.id and status='POSTED'))),
  'mappings',(select jsonb_agg(to_jsonb(m)order by m.mapping_key)from erp.accounting_account_mappings m),
  'period',(select jsonb_agg(to_jsonb(c))from erp.accounting_period_control c))::text)
 from erp.sales_headers h where h.id=p_sale
$$;

create function cp7_sales_chain.workspace(p_sale uuid)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;source jsonb;
begin
 a:=cp7_sales_chain.access_now();source:=cp7_sales_chain.snapshot(p_sale);
 if source is null then raise exception 'CP7_SALES_CHAIN_NOT_FOUND';end if;
 if cp7_sales_chain.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.sales-chain-workspace.v1','captured_at',clock_timestamp(),
  'source',source,'chain_token',cp7_sales_chain.token(p_sale),
  'eligible',source->>'status'in('POSTED','PARTIAL_PAID','PAID')and jsonb_array_length(source->'pending_children')=0);
end $$;

create function cp7_sales_chain.validate(p jsonb)returns void
language plpgsql immutable security invoker set search_path=''as $$
declare key text;
begin
 if jsonb_typeof(p)is distinct from'object'or not(p?&array['sale_id','review_token','chain_token','payment_ids','return_ids','change_reason'])
  or(select count(*)from jsonb_object_keys(p))<>6
  or jsonb_typeof(p->'sale_id')is distinct from'string'
  or coalesce(p->>'sale_id','')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or jsonb_typeof(p->'review_token')is distinct from'string'or coalesce(p->>'review_token','')!~'^[a-f0-9]{32}$'
  or jsonb_typeof(p->'chain_token')is distinct from'string'or coalesce(p->>'chain_token','')!~'^[a-f0-9]{32}$'
  or jsonb_typeof(p->'change_reason')is distinct from'string'or length(btrim(p->>'change_reason'))not between 5 and 1000 then
  raise exception 'CP7_SALES_CHAIN_FIELDS';end if;
 foreach key in array array['payment_ids','return_ids']loop
  if jsonb_typeof(p->key)is distinct from'array'then raise exception 'CP7_SALES_CHAIN_FIELDS';end if;
  if exists(select 1 from jsonb_array_elements(p->key)x where jsonb_typeof(x)is distinct from'string'
   or (x#>>'{}')!~*'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
   or(select count(*)from jsonb_array_elements(p->key))<>(select count(distinct lower(x#>>'{}'))from jsonb_array_elements(p->key)x)then
   raise exception 'CP7_SALES_CHAIN_FIELDS';end if;
 end loop;
end $$;

create function cp7_sales_chain.command(p jsonb,p_request uuid,p_expected text)returns jsonb
language plpgsql volatile security definer set search_path=''set TimeZone='UTC'as $$
declare a jsonb;old cp7_sales_chain.requests;h erp.sales_headers;source jsonb;payments jsonb;returns jsonb;
 child jsonb;intent jsonb;result jsonb;steps jsonb:='[]';child_request uuid;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_sales_chain.access_now();perform cp7_sales_chain.validate(p);
 if p_request is null or p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'then raise exception 'CP7_SALES_CHAIN_FIELDS';end if;
 insert into cp7_sales_chain.requests values(auth.uid(),p_request,p,p_expected,null)on conflict do nothing;
 select *into strict old from cp7_sales_chain.requests where actor=auth.uid()and request_id=p_request for update;
 if old.payload is distinct from p or old.expected_version is distinct from p_expected then raise exception 'CP7_SALES_CHAIN_REQUEST_CHANGED';end if;
 if cp7_sales_chain.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 -- Acquire the same FG/payment/return/header order as the owning adapter.
 perform pg_advisory_xact_lock(hashtextextended('FG_HPP_SALES_V2620C',0));
 perform 1 from erp.sales_payments where sale_id=(p->>'sale_id')::uuid order by id for update;
 perform 1 from erp.sales_returns where sale_id=(p->>'sale_id')::uuid order by id for update;
 select *into h from erp.sales_headers where id=(p->>'sale_id')::uuid for update;
 if h.id is null then raise exception 'CP7_SALES_CHAIN_NOT_FOUND';end if;
 perform 1 from erp.sales_items where sale_id=h.id order by id for update;
 perform 1 from erp.sale_stock_allocations x where exists(select 1 from erp.sales_items i where i.id=x.sale_item_id and i.sale_id=h.id)order by x.id for update;
 lock table erp.accounting_account_mappings in share mode;
 perform 1 from erp.cash_accounts c where exists(select 1 from erp.sales_payments x where x.sale_id=h.id and x.status='POSTED'and x.cash_account_id=c.id)order by c.id for share;
 perform 1 from erp.chart_accounts c where c.id in(select coa_account_id from erp.cash_accounts
  where id in(select cash_account_id from erp.sales_payments where sale_id=h.id and status='POSTED')
  union select account_id from erp.accounting_account_mappings)order by c.id for share;
 -- Recheck the complete reviewed source only after every possible wait.
 if cp7_sales_chain.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 source:=cp7_sales_chain.snapshot(h.id);
 if h.row_version::text is distinct from p_expected or source->>'review_token'is distinct from p->>'review_token'
  or cp7_sales_chain.token(h.id)is distinct from p->>'chain_token'then raise exception 'CP7_SALES_CHAIN_STALE_REVIEW';end if;
 if h.status not in('POSTED','PARTIAL_PAID','PAID')then raise exception 'CP7_SALES_ACTIVE_ONLY';end if;
 if jsonb_array_length(source->'pending_children')<>0 then raise exception 'CP7_SALES_CHAIN_PENDING_CHILD';end if;
 select coalesce(jsonb_agg(x->'id'order by ordinal),'[]')into payments from jsonb_array_elements(source->'payments')with ordinality e(x,ordinal);
 select coalesce(jsonb_agg(x->'id'order by ordinal),'[]')into returns from jsonb_array_elements(source->'returns')with ordinality e(x,ordinal);
 if payments is distinct from p->'payment_ids'or returns is distinct from p->'return_ids'then raise exception 'CP7_SALES_CHAIN_CHILDREN_CHANGED';end if;
 -- Every nested receipt has a deterministic distinct key. All are committed
 -- with the outer receipt or rolled back with it, including the final sale.
 for child in select value from jsonb_array_elements(source->'payments')loop
  select *into strict h from erp.sales_headers where id=h.id;
  intent:=jsonb_build_object('sale_id',h.id,'review_token',cp7_sales.review_token(h.id),'payment_id',child->>'id','change_reason',btrim(p->>'change_reason'));
  child_request:=md5(auth.uid()::text||':SALE_CHAIN:'||p_request::text||':PAYMENT:'||(child->>'id'))::uuid;
  result:=public.erp_cp7_save_sale_v1('PAYMENT_REVERSE',intent,child_request,h.row_version::text);
  steps:=steps||jsonb_build_array(jsonb_build_object('action','PAYMENT_REVERSE','id',child->>'id','status',result->>'payment_status'));
 end loop;
 for child in select value from jsonb_array_elements(source->'returns')loop
  select *into strict h from erp.sales_headers where id=h.id;
  intent:=jsonb_build_object('sale_id',h.id,'review_token',cp7_sales.review_token(h.id),'return_id',child->>'id','change_reason',btrim(p->>'change_reason'));
  child_request:=md5(auth.uid()::text||':SALE_CHAIN:'||p_request::text||':RETURN:'||(child->>'id'))::uuid;
  result:=public.erp_cp7_save_sale_v1('RETURN_REVERSE',intent,child_request,h.row_version::text);
  steps:=steps||jsonb_build_array(jsonb_build_object('action','RETURN_REVERSE','id',child->>'id','status',result->>'return_status'));
 end loop;
 select *into strict h from erp.sales_headers where id=h.id;
 intent:=jsonb_build_object('sale_id',h.id,'review_token',cp7_sales.review_token(h.id),'change_reason',btrim(p->>'change_reason'));
 child_request:=md5(auth.uid()::text||':SALE_CHAIN:'||p_request::text||':SALE:'||h.id::text)::uuid;
 result:=public.erp_cp7_save_sale_v1('SALE_REVERSE',intent,child_request,h.row_version::text);
 steps:=steps||jsonb_build_array(jsonb_build_object('action','SALE_REVERSE','id',h.id,'status',result->>'status'));
 if result->>'status'is distinct from'REVERSED'or exists(select 1 from jsonb_array_elements(steps)x where x->>'status'is distinct from'REVERSED')then
  raise exception 'CP7_SALES_CHAIN_INCOMPLETE';end if;
 if cp7_sales_chain.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_SALES_ACCESS_CHANGED';end if;
 insert into cp7_sales_chain.history(actor,request_id,sale_id,reviewed_source,steps,reason)
  values(auth.uid(),p_request,h.id,source,steps,btrim(p->>'change_reason'));
 result:=jsonb_build_object('contract_version','cp7.sales-chain-outcome.v1','kind','COMMITTED_OUTCOME',
  'action','SALE_CHAIN_REVERSE','request_id',p_request,'sale_id',h.id,'status','REVERSED',
  'row_version',result->>'row_version','steps',steps);
 update cp7_sales_chain.requests set response=result where actor=auth.uid()and request_id=p_request;
 return result;
end $$;

create function public.erp_cp7_get_sales_chain_v1(p_sale uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_sales_chain.workspace(p_sale)$$;
create function public.erp_cp7_reverse_sales_chain_v1(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_sales_chain.command(p_payload,p_request,p_expected)$$;
alter function cp7_sales_chain.access_now()owner to postgres;
alter function cp7_sales_chain.immutable()owner to postgres;
alter function cp7_sales_chain.snapshot(uuid)owner to postgres;
alter function cp7_sales_chain.token(uuid)owner to postgres;
alter function cp7_sales_chain.workspace(uuid)owner to postgres;
alter function cp7_sales_chain.validate(jsonb)owner to postgres;
alter function cp7_sales_chain.command(jsonb,uuid,text)owner to postgres;
grant create on schema public to cp7_sales_read,cp7_sales_write;
alter function public.erp_cp7_get_sales_chain_v1(uuid)owner to cp7_sales_read;
alter function public.erp_cp7_reverse_sales_chain_v1(jsonb,uuid,text)owner to cp7_sales_write;
revoke create on schema public from cp7_sales_read,cp7_sales_write;
revoke all on all functions in schema cp7_sales_chain from public,anon,authenticated,service_role,cp7_capture,cp7_sales_read,cp7_sales_write;
grant execute on function cp7_sales_chain.workspace(uuid)to cp7_sales_read;
grant execute on function cp7_sales_chain.command(jsonb,uuid,text)to cp7_sales_write;
-- The coordinator's postgres owner is not a superuser. Enter through the
-- existing facade owned by cp7_sales_write so its invoker command retains
-- private request/context ownership. Do not grant postgres private table DML
-- or direct invoker execution; every current-authority and Native guard runs.
grant execute on function public.erp_cp7_save_sale_v1(text,jsonb,uuid,text)to postgres;
revoke all on function public.erp_cp7_get_sales_chain_v1(uuid),public.erp_cp7_reverse_sales_chain_v1(jsonb,uuid,text)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_sales_chain_v1(uuid),public.erp_cp7_reverse_sales_chain_v1(jsonb,uuid,text)to authenticated;

-- Reopen an unpicked posted cutting group through its unchanged Native inverse.
-- No business table DML or new internal/Native guard admission is introduced.
create role cp7_cutting_read nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create role cp7_cutting_write nologin noinherit nosuperuser nocreatedb nocreaterole noreplication;
create schema cp7_cutting_correction authorization cp7_cutting_read;
revoke all on schema cp7_cutting_correction from public,anon,authenticated,service_role,cp7_capture;
grant usage on schema cp7_cutting_correction to postgres,cp7_cutting_write;
create table cp7_cutting_correction.requests(
 actor uuid not null,request_id uuid not null,payload jsonb not null,expected_version text not null,
 response jsonb,primary key(actor,request_id)
);
create table cp7_cutting_correction.history(
 actor uuid not null,request_id uuid not null,group_id uuid not null references erp.cutting_groups,
 original_source jsonb not null,Native_response jsonb not null,reason text not null,
 recorded_at timestamptz not null default clock_timestamp(),primary key(actor,request_id)
);
alter table cp7_cutting_correction.requests owner to postgres;
alter table cp7_cutting_correction.history owner to postgres;
alter table cp7_cutting_correction.requests enable row level security;
alter table cp7_cutting_correction.history enable row level security;
create policy private_requests on cp7_cutting_correction.requests for all using(false)with check(false);
create policy private_history on cp7_cutting_correction.history for all using(false)with check(false);
revoke all on all tables in schema cp7_cutting_correction from public,anon,authenticated,service_role,cp7_capture,cp7_cutting_read,cp7_cutting_write;

create function cp7_cutting_correction.access_now()returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;permission text;
begin
 if auth.uid()is null or auth.jwt()->>'role'is distinct from'authenticated'then
  raise exception using errcode='42501',message='CP7_CUTTING_CORRECTION_DENIED';end if;
 a:=erp.get_my_access_v1();
 if a->'allowed'is distinct from'true'::jsonb or coalesce(a->'profile'->>'role_code','')not in('OWNER','ADMIN')then
  raise exception using errcode='42501',message='CP7_CUTTING_CORRECTION_DENIED';end if;
 foreach permission in array array['production.distribution.view','production.cutting.view','production.cutting.edit_draft','production.cutting.post']loop
  if erp.has_permission(permission)is distinct from true then
   raise exception using errcode='42501',message='CP7_CUTTING_CORRECTION_DENIED';end if;
 end loop;
 return a;
end $$;

create function cp7_cutting_correction.immutable()returns trigger
language plpgsql security invoker set search_path=''as $$
begin raise exception 'CP7_CUTTING_CORRECTION_HISTORY_IMMUTABLE';end $$;
create trigger immutable_history before update or delete on cp7_cutting_correction.history
 for each row execute function cp7_cutting_correction.immutable();
create trigger immutable_history_truncate before truncate on cp7_cutting_correction.history
 for each statement execute function cp7_cutting_correction.immutable();

create function cp7_cutting_correction.snapshot(p_group uuid)returns jsonb
language sql stable security definer set search_path=''set TimeZone='UTC'as $$
 select jsonb_build_object('group',to_jsonb(g),'po',to_jsonb(po),
  'rolls',(select jsonb_agg(to_jsonb(r)order by r.id)from erp.cutting_group_rolls r where r.cutting_group_id=g.id),
  'slots',(select jsonb_agg(to_jsonb(s)order by s.id)from erp.cutting_group_size_slots s where s.cutting_group_id=g.id),
  'yields',(select jsonb_agg(to_jsonb(y)order by y.id)from erp.cutting_roll_yields y join erp.cutting_group_rolls r on r.id=y.cutting_group_roll_id where r.cutting_group_id=g.id),
  'pickups',(select coalesce(jsonb_agg(to_jsonb(p)order by p.id),'[]'::jsonb)from erp.cutting_pickups p where p.cutting_group_id=g.id),
  'materials',(select jsonb_agg(to_jsonb(m)order by m.id)from erp.material_rolls m where exists(select 1 from erp.cutting_group_rolls r where r.cutting_group_id=g.id and r.roll_id=m.id)),
  'movements',(select jsonb_agg(to_jsonb(m)order by m.id)from erp.material_stock_movements m where exists(select 1 from erp.cutting_group_rolls r where r.cutting_group_id=g.id and r.roll_id=m.roll_id)),
  'journals',(select jsonb_agg(to_jsonb(j)order by j.id)from erp.journal_entries j where j.source_id=g.id or exists(select 1 from erp.cutting_group_rolls r where r.cutting_group_id=g.id and r.id=j.source_id)),
  'period',(select jsonb_agg(to_jsonb(p))from erp.accounting_period_control p),
  'downstream',erp.cutting_group_has_downstream_after_pickup(g.id))
 from erp.cutting_groups g join erp.production_orders po on po.id=g.po_id where g.id=p_group
$$;

create function cp7_cutting_correction.workspace(p_group uuid)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;s jsonb;g jsonb;blockers jsonb:='[]';
begin
 a:=cp7_cutting_correction.access_now();s:=cp7_cutting_correction.snapshot(p_group);g:=s->'group';
 if s is null then raise exception 'CP7_CUTTING_CORRECTION_NOT_FOUND';end if;
 if g->>'status'is distinct from'CUT'or g->'picked_up_at'is distinct from'null'::jsonb then
  blockers:=blockers||jsonb_build_array(jsonb_build_object('kind','PICKUP_OR_LIFECYCLE','id',p_group,'label',g->>'group_number'));end if;
 if s->'downstream'is distinct from'false'::jsonb then
  blockers:=blockers||jsonb_build_array(jsonb_build_object('kind','DOWNSTREAM','id',p_group,'label',g->>'group_number'));end if;
 if exists(select 1 from jsonb_array_elements(coalesce(s->'pickups','[]'))p where p->>'status'in('DRAFT','POSTED'))then
  blockers:=blockers||(select jsonb_agg(jsonb_build_object('kind','PICKUP','id',p->>'id','label',g->>'group_number','status',p->>'status')order by p->>'id')
   from jsonb_array_elements(s->'pickups')p where p->>'status'in('DRAFT','POSTED'));end if;
 if g->'material_issue_posted'is distinct from'true'::jsonb or g->'material_return_posted'is distinct from'false'::jsonb then
  blockers:=blockers||jsonb_build_array(jsonb_build_object('kind','MATERIAL_FLOW','id',p_group,'label',g->>'group_number'));end if;
 if cp7_cutting_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_CUTTING_CORRECTION_ACCESS_CHANGED';end if;
 return jsonb_build_object('contract_version','cp7.cutting-reopen-workspace.v1','group_id',p_group,'po_id',g->>'po_id',
  'number',g->>'group_number','row_version',g->>'row_version','review_token',md5(s::text),
  'eligible',jsonb_array_length(blockers)=0,'blockers',blockers,'business_DML',false);
end $$;

create function cp7_cutting_correction.command(p jsonb,p_request uuid,p_expected text)returns jsonb
language plpgsql volatile security definer set search_path=''as $$
declare a jsonb;old cp7_cutting_correction.requests;g erp.cutting_groups;s jsonb;w jsonb;r jsonb;answer jsonb;
begin
 if current_setting('transaction_isolation')<>'read committed'then raise exception 'CP7_FRESH_ACCESS_REQUIRED';end if;
 a:=cp7_cutting_correction.access_now();
 if p_request is null or p_expected is null or p_expected!~'^[1-9][0-9]{0,18}$'
  or jsonb_typeof(p)is distinct from'object'or not(p?&array['group_id','po_id','review_token','change_reason'])
  or(select count(*)from jsonb_object_keys(p))<>4
  or jsonb_typeof(p->'group_id')is distinct from'string'or coalesce(p->>'group_id','')!~'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or jsonb_typeof(p->'po_id')is distinct from'string'or coalesce(p->>'po_id','')!~'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  or jsonb_typeof(p->'review_token')is distinct from'string'or coalesce(p->>'review_token','')!~'^[a-f0-9]{32}$'
  or jsonb_typeof(p->'change_reason')is distinct from'string'or length(btrim(p->>'change_reason'))not between 5 and 1000 then
  raise exception 'CP7_CUTTING_CORRECTION_FIELDS';end if;
 insert into cp7_cutting_correction.requests values(auth.uid(),p_request,p,p_expected,null)on conflict do nothing;
 select *into strict old from cp7_cutting_correction.requests where actor=auth.uid()and request_id=p_request for update;
 if old.payload is distinct from p or old.expected_version is distinct from p_expected then raise exception 'CP7_CUTTING_CORRECTION_REQUEST_CHANGED';end if;
 if cp7_cutting_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_CUTTING_CORRECTION_ACCESS_CHANGED';end if;
 if old.response is not null then return old.response;end if;
 perform pg_advisory_xact_lock(hashtextextended('CP6FLOW:'||(p->>'group_id'),0));
 select *into g from erp.cutting_groups where id=(p->>'group_id')::uuid for update;
 if g.id is null then raise exception 'CP7_CUTTING_CORRECTION_NOT_FOUND';end if;
 if cp7_cutting_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_CUTTING_CORRECTION_ACCESS_CHANGED';end if;
 s:=cp7_cutting_correction.snapshot(g.id);w:=cp7_cutting_correction.workspace(g.id);
 if g.row_version::text is distinct from p_expected or g.po_id::text is distinct from p->>'po_id'
  or md5(s::text)is distinct from p->>'review_token'then raise exception 'CP7_CUTTING_CORRECTION_STALE_REVIEW';end if;
 if w->'eligible'is distinct from'true'::jsonb then raise exception 'CP7_CUTTING_CORRECTION_DEPENDENCIES';end if;
 -- This is the accepted Native transaction. Its stock, GL, period, downstream,
 -- negative-stock, actor and immutable reversal-link guards execute unchanged.
 r:=erp.reverse_cutting_material_flow_before_sewing_v2(g.id,btrim(p->>'change_reason'),p_request,g.row_version);
 -- A revocation during any Native stock/journal lock wait rolls every effect
 -- and both request receipts back, including the immutable Native inverses.
 if cp7_cutting_correction.access_now()is distinct from a then raise exception using errcode='42501',message='CP7_CUTTING_CORRECTION_ACCESS_CHANGED';end if;
 if r->>'cutting_group_id'is distinct from g.id::text or r->>'status'is distinct from'CUT'
  or r->'presewing_reversible'is distinct from'true'::jsonb or exists(
   select 1 from erp.cutting_groups x where x.id=g.id and(x.material_issue_posted or x.material_return_posted or x.picked_up_at is not null))then
  raise exception 'CP7_CUTTING_CORRECTION_INCOMPLETE';end if;
 insert into cp7_cutting_correction.history values(auth.uid(),p_request,g.id,s,r,btrim(p->>'change_reason'),clock_timestamp());
 answer:=jsonb_build_object('contract_version','cp7.cutting-reopen-outcome.v1','kind','COMMITTED_OUTCOME','action','REOPEN_POSTED',
  'request_id',p_request,'group_id',g.id,'po_id',g.po_id,'number',g.group_number,'row_version',r->>'row_version',
  'status','DRAFT_FOR_CORRECTION','Native_response',r);
 update cp7_cutting_correction.requests set response=answer where actor=auth.uid()and request_id=p_request;
 return answer;
end $$;

create function public.erp_cp7_get_cutting_correction_v1(p_group uuid)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_cutting_correction.workspace(p_group)$$;
create function public.erp_cp7_reopen_cutting_v1(p_payload jsonb,p_request uuid,p_expected text)returns jsonb
language sql volatile security definer set search_path=''as $$select cp7_cutting_correction.command(p_payload,p_request,p_expected)$$;
alter function cp7_cutting_correction.access_now()owner to postgres;
alter function cp7_cutting_correction.immutable()owner to postgres;
alter function cp7_cutting_correction.snapshot(uuid)owner to postgres;
alter function cp7_cutting_correction.workspace(uuid)owner to postgres;
alter function cp7_cutting_correction.command(jsonb,uuid,text)owner to postgres;
grant create on schema public to cp7_cutting_read,cp7_cutting_write;
alter function public.erp_cp7_get_cutting_correction_v1(uuid)owner to cp7_cutting_read;
alter function public.erp_cp7_reopen_cutting_v1(jsonb,uuid,text)owner to cp7_cutting_write;
revoke create on schema public from cp7_cutting_read,cp7_cutting_write;
revoke all on all functions in schema cp7_cutting_correction from public,anon,authenticated,service_role,cp7_capture,cp7_cutting_read,cp7_cutting_write;
grant execute on function cp7_cutting_correction.workspace(uuid)to cp7_cutting_read;
grant execute on function cp7_cutting_correction.command(jsonb,uuid,text)to cp7_cutting_write;
revoke all on function public.erp_cp7_get_cutting_correction_v1(uuid),public.erp_cp7_reopen_cutting_v1(jsonb,uuid,text)from public,anon,authenticated,service_role,cp7_capture;
grant execute on function public.erp_cp7_get_cutting_correction_v1(uuid),public.erp_cp7_reopen_cutting_v1(jsonb,uuid,text)to authenticated;
