import {Buffer} from 'node:buffer'
import {expect,it} from 'vitest'
import original from '../tests/fixtures/nativeAnalysisStandin.json'
import {ruleSourceFixture,ruleFixtureActor} from '../tests/fixtures/nativeRuleSource'
import {parseNativeAnalysis} from './nativeAnalysis'
import {parseRuleSource} from './nativeRuleSource'
import type {NativeDemandQuery} from './nativeDemandHistory'

// Adversarial receiver fixtures, not Native Auth or factory-volume credit.
// Node's byte oracle is independent of the browser receiver's encoder.
const q=original.query as NativeDemandQuery,finance={ownerReports:false,preflight:false},rights={ar:true,ap:true}
const bytes=(v:unknown)=>Buffer.byteLength(JSON.stringify(v),'utf8')
function sizedAnalysis(size:number,multibyte=true){
 const wire=structuredClone(original);wire.analysis.generation_warnings=['']
 const gap=size-bytes(wire.analysis);expect(gap).toBeGreaterThan(0)
 wire.analysis.generation_warnings[0]=multibyte?'漢'.repeat(Math.floor(gap/3))+'x'.repeat(gap%3):'x'.repeat(gap)
 expect(bytes(wire.analysis)).toBe(size)
 return wire
}
const parseAnalysis=(v:unknown)=>parseNativeAnalysis(v,q,ruleFixtureActor)
const parseRules=(v:unknown)=>parseRuleSource(v,q,ruleFixtureActor,finance,rights)

it('rejects an over-8MB UTF8 analysis even when its UTF16 count fits the old cap',()=>{
 const wire=sizedAnalysis(8_000_001)
 expect(JSON.stringify(wire.analysis).length).toBeLessThan(8_000_000)
 expect(()=>parseAnalysis(wire)).toThrow()
})
it.each([false,true])('preserves a complete analysis at exactly 8MB; multibyte=%s',multibyte=>{
 const wire=sizedAnalysis(8_000_000,multibyte),parsed=parseAnalysis(wire)
 expect(parsed.analysis).toEqual(wire.analysis)
 expect(parsed.labels[0].sku).toBe(original.product_labels[0].sku)
 expect(parsed.analysis.recommendations[0].q_base).toEqual(original.analysis.recommendations[0].q_base)
})
it('rejects oversized complete condition rows without enabling a partial source',()=>{
 const wire=ruleSourceFixture();wire.rows[2].label='漢'.repeat(3_000_000)
 expect(bytes(wire.rows)).toBeGreaterThan(8_000_000)
 expect(JSON.stringify(wire.rows).length).toBeLessThan(8_000_000)
 expect(()=>parseRules(wire)).toThrow()
})
it('rejects an oversized copied Native financial document measured in UTF8 bytes',()=>{
 const wire=ruleSourceFixture(),document=wire.rows[2].financial_source!.document
 document.notes='漢'.repeat(3_000_000)
 expect(bytes(document)).toBeGreaterThan(8_000_000)
 expect(JSON.stringify(document).length).toBeLessThan(8_000_000)
 expect(()=>parseRules(wire)).toThrow()
})
it('retains complete under-budget Unicode conditions, financial values and rights checks',()=>{
 const wire=ruleSourceFixture();wire.rows[2].label='漢'.repeat(100_000)
 const parsed=parseRules(wire)
 expect(parsed.rows).toEqual(wire.rows)
 expect(parsed.rows[2].financial_source).toEqual(wire.rows[2].financial_source)
 expect(()=>parseRuleSource(wire,q,ruleFixtureActor,finance,{ar:false,ap:true})).toThrow()
})
