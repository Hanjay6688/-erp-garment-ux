-- ERP Enteng schema-only bootstrap for disposable full-schema CI.
-- Generated from immutable supabase_migrations source rows; no business data.
\set ON_ERROR_STOP on

create schema if not exists supabase_migrations;
create table if not exists supabase_migrations.schema_migrations(version text primary key);
alter table supabase_migrations.schema_migrations add column if not exists statements text[];
alter table supabase_migrations.schema_migrations add column if not exists name text;

insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826104553','compact_export_marker',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826105139','enable_pg_net_for_compact_export',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826105442','invoke_compact_export_proxy',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826105822','invoke_compact_installer_dryrun_validator',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826105958','create_compact_validation_snapshot_helper',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826110134','enable_http_for_compact_validation',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826111946','overwrite_erp_enteng_reset',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;

-- BEGIN PLATFORM MIGRATION 20260826112217 compact_replay_001
SET search_path=erp,public;
-- ERP GARMENT v2.6.0 — DEVELOPER SEMANTIC COMPACT
-- Generated from canonical FINAL installer.
-- Conservative semantic compaction:
--   * preserves original statement order
--   * removes only superseded CREATE OR REPLACE FUNCTION/VIEW definitions
--     when no intermediate invocation was detected
--   * leaves tables, constraints, triggers, policies, indexes, seed data,
--     accounting/HPP/reversal logic and verification statements untouched
--
-- ============================================================================
-- ERP-Garment ONE-SHOT INSTALLER / CANONICAL MIGRATION REPLAY
-- Source: LIVE Supabase project vlxdhpkjeevubjxexnfo
-- Built: 2026-08-26
-- Migration count: 228
-- First migration: 20260825053204
-- Last migration: 20260826081134
-- Target: fresh Supabase/PostgreSQL database. Execute this file once, top-to-bottom.
-- Contents: schema + functions/RPC + triggers + RLS/grants + required ERP config/seeds
--           as represented by the full canonical live migration history.
-- Data note: operational/business rows are NOT backed up by this installer.
-- Safety note: this is the high-equivalence replay installer; keep migration order intact.
-- ============================================================================

-- ============================================================================
-- LIVE SUPABASE MIGRATION
-- VERSION: 20260825053204
-- NAME: erp_v25_part_01
-- ============================================================================
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE SCHEMA IF NOT EXISTS erp;
SET search_path = erp, public;
CREATE OR REPLACE FUNCTION erp.touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;
CREATE TABLE erp.app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_user_id uuid UNIQUE,
  full_name varchar(150) NOT NULL,
  role varchar(20) NOT NULL CHECK (role IN ('OWNER','ADMIN','STAFF','CUSTOMER')),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_code varchar(30) UNIQUE NOT NULL,
  brand_name varchar(100) UNIQUE NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_code varchar(30) UNIQUE NOT NULL,
  customer_name varchar(150) NOT NULL,
  phone varchar(50),
  address text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.customer_user_access (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_user_id uuid NOT NULL UNIQUE REFERENCES erp.app_users(id) ON DELETE CASCADE,
  customer_id uuid NOT NULL REFERENCES erp.customers(id) ON DELETE CASCADE,
  can_view_stock boolean NOT NULL DEFAULT true,
  can_view_wip boolean NOT NULL DEFAULT true,
  can_view_laundry boolean NOT NULL DEFAULT true,
  can_view_purchases boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_code varchar(30) UNIQUE NOT NULL,
  location_name varchar(120) NOT NULL,
  location_type varchar(30) NOT NULL CHECK (location_type IN ('RAW_MATERIAL_WAREHOUSE','CUTTING_WIP','CONTRACTOR_WIP','LAUNDRY_WIP','QC_WIP','FG_WAREHOUSE','SCRAP_AREA','OTHER')),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_code varchar(30) UNIQUE NOT NULL,
  supplier_name varchar(150) NOT NULL,
  supplier_type varchar(20) NOT NULL DEFAULT 'MATERIAL' CHECK (supplier_type IN ('MATERIAL','ACCESSORY','OTHER')),
  phone varchar(50),
  address text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_sku varchar(60) UNIQUE NOT NULL,
  material_name varchar(150) NOT NULL,
  material_type varchar(20) NOT NULL CHECK (material_type IN ('FABRIC','ACCESSORY','OTHER')),
  unit_code varchar(20) NOT NULL,
  moving_average_cost numeric(18,6) NOT NULL DEFAULT 0 CHECK (moving_average_cost >= 0),
  cached_stock_qty numeric(18,6) NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.sizes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  size_code varchar(20) UNIQUE NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true
);
CREATE TABLE erp.product_models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_code varchar(50) UNIQUE NOT NULL,
  model_name varchar(150) NOT NULL,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.product_model_sizes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_id uuid NOT NULL REFERENCES erp.product_models(id) ON DELETE CASCADE,
  size_id uuid NOT NULL REFERENCES erp.sizes(id),
  sort_order integer NOT NULL DEFAULT 0,
  UNIQUE(model_id, size_id)
);
CREATE TABLE erp.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sku varchar(100) UNIQUE NOT NULL,
  model_id uuid NOT NULL REFERENCES erp.product_models(id),
  brand_id uuid NOT NULL REFERENCES erp.brands(id),
  color_name varchar(100) NOT NULL,
  size_id uuid NOT NULL REFERENCES erp.sizes(id),
  product_name varchar(180) NOT NULL,
  is_portal_visible boolean NOT NULL DEFAULT true,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(model_id, brand_id, color_name, size_id)
);
CREATE TABLE erp.product_price_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES erp.products(id) ON DELETE CASCADE,
  price numeric(18,2) NOT NULL CHECK (price >= 0),
  effective_from timestamptz NOT NULL DEFAULT now(),
  effective_to timestamptz,
  change_note text,
  created_by uuid REFERENCES erp.app_users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (effective_to IS NULL OR effective_to > effective_from)
);
CREATE TABLE erp.material_purchase_headers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_number varchar(60) UNIQUE NOT NULL,
  supplier_id uuid REFERENCES erp.suppliers(id),
  physical_at timestamptz NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','POSTED','REVERSED')),
  notes text,
  created_by uuid REFERENCES erp.app_users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.material_purchase_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_id uuid NOT NULL REFERENCES erp.material_purchase_headers(id) ON DELETE CASCADE,
  material_id uuid NOT NULL REFERENCES erp.materials(id),
  qty numeric(18,6) NOT NULL CHECK (qty > 0),
  unit_price numeric(18,6) NOT NULL CHECK (unit_price >= 0),
  line_total numeric(24,6) GENERATED ALWAYS AS (qty * unit_price) STORED,
  lot_number varchar(80),
  notes text
);
CREATE TABLE erp.material_rolls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_id uuid NOT NULL REFERENCES erp.materials(id),
  purchase_item_id uuid REFERENCES erp.material_purchase_items(id),
  supplier_id uuid REFERENCES erp.suppliers(id),
  roll_number varchar(80) NOT NULL,
  original_qty numeric(18,6) NOT NULL CHECK (original_qty > 0),
  cached_qty numeric(18,6) NOT NULL CHECK (cached_qty >= 0),
  status varchar(25) NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE','HALF_USED','IN_CUTTING','RETURNED_SUPPLIER','EXHAUSTED','ADJUSTED')),
  received_at timestamptz,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(material_id, roll_number)
);
CREATE TABLE erp.material_stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_id uuid NOT NULL REFERENCES erp.materials(id),
  roll_id uuid REFERENCES erp.material_rolls(id),
  location_id uuid REFERENCES erp.locations(id),
  movement_type varchar(40) NOT NULL CHECK (movement_type IN ('OPENING','PURCHASE','CUTTING_ISSUE','CUTTING_RETURN','CONTRACTOR_ISSUE','PERSONAL_USE','INTERNAL_USE','SAMPLE','DAMAGE','LOSS','SUPPLIER_RETURN','ADJUSTMENT','REVERSAL')),
  qty_signed numeric(18,6) NOT NULL CHECK (qty_signed <> 0),
  input_unit_cost numeric(18,6),
  unit_cost_snapshot numeric(18,6) NOT NULL DEFAULT 0 CHECK (unit_cost_snapshot >= 0),
  source_type varchar(50) NOT NULL,
  source_id uuid,
  physical_at timestamptz NOT NULL,
  system_created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES erp.app_users(id),
  reversal_of_id uuid REFERENCES erp.material_stock_movements(id),
  is_cost_recalculated boolean NOT NULL DEFAULT false,
  note text,
  CHECK (input_unit_cost IS NULL OR input_unit_cost >= 0)
);
CREATE TABLE erp.material_cost_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_id uuid NOT NULL REFERENCES erp.materials(id),
  movement_id uuid NOT NULL REFERENCES erp.material_stock_movements(id) ON DELETE CASCADE,
  physical_at timestamptz NOT NULL,
  stock_before numeric(18,6) NOT NULL,
  average_before numeric(18,6) NOT NULL,
  movement_qty numeric(18,6) NOT NULL,
  movement_unit_cost numeric(18,6) NOT NULL,
  stock_after numeric(18,6) NOT NULL,
  average_after numeric(18,6) NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(movement_id)
);
CREATE TABLE erp.material_adjustments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  adjustment_number varchar(60) UNIQUE NOT NULL,
  reason_code varchar(30) NOT NULL CHECK (reason_code IN ('PERSONAL_USE','INTERNAL_FACTORY_USE','SAMPLE','MAINTENANCE','GIVEAWAY','DAMAGE','LOSS','COUNT_CORRECTION','OTHER')),
  physical_at timestamptz NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','POSTED','REVERSED')),
  notes text,
  created_by uuid REFERENCES erp.app_users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.material_adjustment_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  adjustment_id uuid NOT NULL REFERENCES erp.material_adjustments(id) ON DELETE CASCADE,
  material_id uuid NOT NULL REFERENCES erp.materials(id),
  roll_id uuid REFERENCES erp.material_rolls(id),
  qty_signed numeric(18,6) NOT NULL CHECK (qty_signed <> 0),
  input_unit_cost numeric(18,6),
  notes text
);
CREATE TABLE erp.contractors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contractor_code varchar(30) UNIQUE NOT NULL,
  contractor_name varchar(120) NOT NULL,
  contractor_type varchar(30) NOT NULL DEFAULT 'MANDOR',
  attendance_required boolean NOT NULL DEFAULT true,
  is_active boolean NOT NULL DEFAULT true,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- ============================================================================
-- LIVE SUPABASE MIGRATION
-- VERSION: 20260825053342
-- NAME: erp_v25_part_02
-- ============================================================================
SET search_path = erp, public;
CREATE TABLE erp.production_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_number varchar(60) UNIQUE NOT NULL,
  model_id uuid NOT NULL REFERENCES erp.product_models(id),
  contractor_id uuid REFERENCES erp.contractors(id),
  target_qty_pcs integer CHECK (target_qty_pcs IS NULL OR target_qty_pcs > 0),
  target_dozens numeric(18,4) CHECK (target_dozens IS NULL OR target_dozens > 0),
  status varchar(30) NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','CUTTING','SEWING','LAUNDRY','QC','FINISHED','ON_HOLD','CANCELLED')),
  current_stage varchar(30) NOT NULL DEFAULT 'CUTTING' CHECK (current_stage IN ('CUTTING','SEWING','LAUNDRY','QC','FINISHED','ON_HOLD')),
  portal_visibility varchar(20) NOT NULL DEFAULT 'HIDDEN' CHECK (portal_visibility IN ('HIDDEN','ALL_CUSTOMERS','SELECTED_CUSTOMERS')),
  physical_start_at timestamptz,
  notes text,
  created_by uuid REFERENCES erp.app_users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE erp.po_customer_visibility (id uuid PRIMARY KEY DEFAULT gen_random_uuid(),po_id uuid NOT NULL REFERENCES erp.production_orders(id) ON DELETE CASCADE,customer_id uuid NOT NULL REFERENCES erp.customers(id) ON DELETE CASCADE,UNIQUE(po_id,customer_id));
CREATE TABLE erp.cutting_groups (id uuid PRIMARY KEY DEFAULT gen_random_uuid(),po_id uuid NOT NULL REFERENCES erp.production_orders(id) ON DELETE CASCADE,group_number varchar(60) NOT NULL,cut_at timestamptz NOT NULL,executor_name varchar(120),picked_up_at timestamptz,status varchar(30) NOT NULL DEFAULT 'CUT' CHECK (status IN ('CUT','PICKED_UP','SEWING','LAUNDRY','RETURNED','QC','DONE','HOLD')),code varchar(80),pattern_type varchar(150),notes text,created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),UNIQUE(po_id,group_number));
CREATE TABLE erp.cutting_group_rolls (id uuid PRIMARY KEY DEFAULT gen_random_uuid(),cutting_group_id uuid NOT NULL REFERENCES erp.cutting_groups(id) ON DELETE CASCADE,roll_id uuid NOT NULL REFERENCES erp.material_rolls(id),qty_issued numeric(18,6) NOT NULL CHECK (qty_issued > 0),qty_consumed numeric(18,6) CHECK (qty_consumed IS NULL OR qty_consumed >= 0),qty_reported_remaining numeric(18,6) CHECK (qty_reported_remaining IS NULL OR qty_reported_remaining >= 0),qty_physically_returned numeric(18,6) NOT NULL DEFAULT 0 CHECK (qty_physically_returned >= 0),return_destination varchar(20) CHECK (return_destination IS NULL OR return_destination IN ('WAREHOUSE','SUPPLIER','SCRAP','NONE')),returned_at timestamptz,unit_cost_snapshot numeric(18,6) CHECK (unit_cost_snapshot IS NULL OR unit_cost_snapshot >= 0),notes text,UNIQUE(cutting_group_id,roll_id),CHECK (qty_consumed IS NULL OR qty_consumed <= qty_issued),CHECK (qty_physically_returned <= qty_issued),CHECK (qty_consumed IS NULL OR qty_consumed + qty_physically_returned <= qty_issued));
CREATE TABLE erp.cutting_group_size_slots (id uuid PRIMARY KEY DEFAULT gen_random_uuid(),cutting_group_id uuid NOT NULL REFERENCES erp.cutting_groups(id) ON DELETE CASCADE,slot_no integer NOT NULL CHECK (slot_no > 0),size_id uuid NOT NULL REFERENCES erp.sizes(id),drawing_no integer NOT NULL DEFAULT 1 CHECK (drawing_no > 0),label_override varchar(30),UNIQUE(cutting_group_id,slot_no),UNIQUE(cutting_group_id,size_id,drawing_no));
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826112217','compact_replay_001',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826112217 compact_replay_001

-- BEGIN PLATFORM MIGRATION 20260826123747 fix_sales_reversal_hpp_chronology
create or replace function erp.reverse_sale(p_sale_id uuid,p_reason text)
returns void
language plpgsql
security definer
set search_path=erp,public
as $function$
declare
  h erp.sales_headers%rowtype;
  r record;
  v_journal uuid;
  v_expected numeric(24,6);
  v_po uuid;
  v_reversal_hpp numeric(24,6);
begin
  perform erp.require_owner_admin();
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan reversal penjualan wajib diisi'; end if;

  select * into h from erp.sales_headers where id=p_sale_id for update;
  if h.id is null then raise exception 'Penjualan tidak ditemukan'; end if;
  if h.status='REVERSED' then return; end if;
  if h.status not in ('POSTED','PARTIAL_PAID','PAID') then
    raise exception 'Hanya penjualan yang sudah POSTED/aktif yang dapat direverse';
  end if;

  if exists(select 1 from erp.sales_payments where sale_id=h.id and status='POSTED') then
    raise exception 'Penjualan ini sudah memiliki pembayaran customer. Reverse pembayaran aktif terlebih dahulu.';
  end if;
  if exists(select 1 from erp.sales_returns where sale_id=h.id and status='POSTED') then
    raise exception 'Penjualan ini sudah memiliki retur POSTED. Reverse retur aktif terlebih dahulu.';
  end if;

  select coalesce((select sum(line_total) from erp.sales_items where sale_id=h.id),0)
       + coalesce((select sum(a.qty_pcs*a.unit_hpp_snapshot) from erp.sale_stock_allocations a join erp.sales_items si on si.id=a.sale_item_id where si.sale_id=h.id),0)
  into v_expected;

  select id into v_journal
  from erp.journal_entries
  where source_type='SALE' and source_id=h.id and status='POSTED'
  order by posting_at desc,id desc limit 1;
  if v_expected>0.005 and v_journal is null then
    raise exception 'Jurnal penjualan tidak ditemukan; reversal dibatalkan agar piutang/HPP tidak rusak';
  end if;

  for r in
    select fm.id
    from erp.fg_stock_movements fm
    join erp.sales_items si on si.id=fm.source_id
    where si.sale_id=h.id
      and fm.source_type='SALE_ITEM' and fm.movement_type='SALE'
      and not exists(select 1 from erp.fg_stock_movements rv where rv.reversal_of_id=fm.id)
    order by fm.physical_at desc,fm.id desc
  loop
    perform erp.reverse_fg_movement(r.id,p_reason);
  end loop;

  if v_journal is not null then perform erp.reverse_journal(v_journal,p_reason); end if;
  update erp.sales_headers set status='REVERSED' where id=h.id;

  for v_po in
    select distinct fl.po_id
    from erp.sale_stock_allocations a
    join erp.sales_items si on si.id=a.sale_item_id
    join erp.fg_lots fl on fl.id=a.lot_id
    where si.sale_id=h.id and fl.po_id is not null
    order by fl.po_id
  loop
    select coalesce(sum(a.qty_pcs*a.unit_hpp_snapshot),0)
    into v_reversal_hpp
    from erp.sale_stock_allocations a
    join erp.sales_items si on si.id=a.sale_item_id
    join erp.fg_lots fl on fl.id=a.lot_id
    where si.sale_id=h.id and fl.po_id=v_po;

    -- The compensating journal has already moved this historical snapshot
    -- from COGS back to FG. Advance the state by that same movement first;
    -- sync_po_hpp_to_gl must post only the remaining current-HPP chronology delta.
    update erp.po_hpp_gl_state
    set fg_value=fg_value+v_reversal_hpp,
        cogs_value=cogs_value-v_reversal_hpp,
        updated_at=now()
    where po_id=v_po;
    if not found then
      raise exception 'PO HPP GL state missing for sale reversal; reversal aborted to protect FG/COGS';
    end if;

    perform erp.sync_po_hpp_to_gl(v_po,current_date);
  end loop;

  insert into erp.audit_logs(entity_type,entity_id,action,changed_by,change_reason)
  values('sales_headers',h.id,'REVERSE',erp.current_app_user_id(),p_reason);
end;
$function$;

create or replace function erp.reverse_sales_return(p_return_id uuid,p_reason text)
returns void
language plpgsql
security definer
set search_path=erp,public
as $function$
declare
  h erp.sales_returns%rowtype;
  s erp.sales_headers%rowtype;
  r record;
  v_journal uuid;
  v_expected numeric(24,6);
  v_paid numeric(20,2);
  v_total numeric(20,2);
  v_po uuid;
  v_reversal_hpp numeric(24,6);
begin
  perform erp.require_owner_admin();
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan reversal retur penjualan wajib diisi'; end if;

  select * into h from erp.sales_returns where id=p_return_id for update;
  if h.id is null then raise exception 'Retur penjualan tidak ditemukan'; end if;
  if h.status='REVERSED' then return; end if;
  if h.status<>'POSTED' then raise exception 'Hanya retur penjualan POSTED yang dapat direverse'; end if;

  select * into s from erp.sales_headers where id=h.sale_id for update;
  if s.id is null or s.status='REVERSED' then raise exception 'Penjualan sumber retur tidak aktif'; end if;

  select coalesce(sum(sri.refund_amount+sri.qty_pcs*sri.unit_hpp_snapshot),0)
  into v_expected
  from erp.sales_return_items sri where sri.return_id=h.id;

  select id into v_journal
  from erp.journal_entries
  where source_type='SALES_RETURN' and source_id=h.id and status='POSTED'
  order by posting_at desc,id desc limit 1;
  if v_expected>0.005 and v_journal is null then
    raise exception 'Jurnal retur penjualan tidak ditemukan; reversal dibatalkan agar piutang/HPP tidak rusak';
  end if;

  -- A return reversal removes the returned stock again. If that stock has already
  -- been consumed/sold, reverse the downstream transaction first.
  for r in
    select fm.id,fm.lot_id,fm.location_id,fm.quality_grade,fm.qty_signed,fl.cached_qty_pcs
    from erp.fg_stock_movements fm
    join erp.sales_return_items sri on sri.id=fm.source_id
    join erp.fg_lots fl on fl.id=fm.lot_id
    where sri.return_id=h.id
      and fm.source_type='SALES_RETURN_ITEM'
      and fm.movement_type='SALE_RETURN'
      and not exists(select 1 from erp.fg_stock_movements rv where rv.reversal_of_id=fm.id)
    order by fm.physical_at desc,fm.id desc
  loop
    if r.cached_qty_pcs<r.qty_signed then
      raise exception 'Barang dari retur ini sudah dipakai/dijual lagi. Reverse transaksi downstream dulu sebelum membatalkan retur.';
    end if;
    perform erp.reverse_fg_movement(r.id,p_reason);
  end loop;

  if v_journal is not null then perform erp.reverse_journal(v_journal,p_reason); end if;
  update erp.sales_returns set status='REVERSED' where id=h.id;

  select erp.sale_net_total(s.id)::numeric(20,2) into v_total;
  select coalesce(sum(amount),0)::numeric(20,2) into v_paid
  from erp.sales_payments where sale_id=s.id and status='POSTED';
  update erp.sales_headers
  set status=case when v_paid>=v_total-0.01 then 'PAID' when v_paid>0 then 'PARTIAL_PAID' else 'POSTED' end
  where id=s.id;

  for v_po in
    select distinct fl.po_id
    from erp.sales_return_items sri
    join erp.fg_lots fl on fl.id=sri.lot_id
    where sri.return_id=h.id and fl.po_id is not null
    order by fl.po_id
  loop
    select coalesce(sum(sri.qty_pcs*sri.unit_hpp_snapshot),0)
    into v_reversal_hpp
    from erp.sales_return_items sri
    join erp.fg_lots fl on fl.id=sri.lot_id
    where sri.return_id=h.id and fl.po_id=v_po;

    -- The compensating journal has already removed this historical snapshot
    -- from FG and restored it to COGS. Move the baseline by the same amount so
    -- the following sync only records any later HPP-version difference.
    update erp.po_hpp_gl_state
    set fg_value=fg_value-v_reversal_hpp,
        cogs_value=cogs_value+v_reversal_hpp,
        updated_at=now()
    where po_id=v_po;
    if not found then
      raise exception 'PO HPP GL state missing for sales-return reversal; reversal aborted to protect FG/COGS';
    end if;

    perform erp.sync_po_hpp_to_gl(v_po,current_date);
  end loop;

  insert into erp.audit_logs(entity_type,entity_id,action,changed_by,change_reason)
  values('sales_returns',h.id,'REVERSE',erp.current_app_user_id(),p_reason);
end;
$function$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826123747','fix_sales_reversal_hpp_chronology',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826123747 fix_sales_reversal_hpp_chronology

-- BEGIN PLATFORM MIGRATION 20260826123756 fix_no_accessory_bom_integrity_gates
create or replace function erp.run_v24_accessory_integrity_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language plpgsql
stable
security definer
set search_path=erp,public
as $function$
begin
  perform erp.require_owner_admin();

  return query
  select 'ACCESSORY_WITHOUT_CATEGORY','ERROR',count(*)::bigint,
         'Active ACCESSORY materials must map to a broad accessory category'
  from erp.materials
  where material_type='ACCESSORY' and is_active=true and accessory_category_id is null;

  return query
  select 'ACCESSORY_CATEGORY_UOM_MISMATCH','ERROR',count(*)::bigint,
         'Accessory variant base UOM must equal category base UOM'
  from erp.materials m
  join erp.accessory_categories c on c.id=m.accessory_category_id
  where m.material_type='ACCESSORY' and m.unit_code<>c.base_uom_code;

  return query
  select 'ACCESSORY_ISSUE_UOM_MISMATCH','ERROR',count(*)::bigint,
         'Physical base quantity differs from transaction quantity x snapshotted conversion'
  from erp.contractor_material_issue_items cmii
  join erp.materials m on m.id=cmii.material_id
  where m.material_type='ACCESSORY'
    and abs(cmii.qty-(cmii.transaction_qty*cmii.base_qty_per_transaction_uom))>0.000001;

  return query
  select 'ACCESSORY_REIMBURSE_DUPLICATE_PAYROLL','ERROR',count(*)::bigint,
         'One GOOD-FG accessory reimbursement entitlement appears in multiple non-reversed payrolls'
  from (
    select pr.source_id
    from erp.payroll_reimbursements pr
    join erp.payroll_settlements ps on ps.id=pr.payroll_id
    where pr.source_type='ACCESSORY_BOM' and ps.status<>'REVERSED'
    group by pr.source_id
    having count(*)>1
  ) x;

  return query
  select 'ACCESSORY_HPP_PHYSICAL_ISSUE_LINK','ERROR',count(*)::bigint,
         'Current HPP must never source ACCESSORY cost directly from contractor physical issue items'
  from erp.hpp_version_components hvc
  join erp.hpp_versions hv on hv.id=hvc.hpp_version_id and hv.is_current=true
  where hvc.component_type='ACCESSORY'
    and hvc.source_type in ('CONTRACTOR_MATERIAL_ISSUE_ITEM','CONTRACTOR_MATERIAL_ISSUE');

  return query
  select 'ACCESSORY_SNAPSHOT_REIMBURSE_MISMATCH','ERROR',count(*)::bigint,
         'Reimbursement entitlement must equal frozen GOOD-FG snapshot reimbursement'
  from erp.fg_accessory_cost_snapshots s
  join erp.contractor_accessory_reimbursement_entitlements e on e.snapshot_id=s.id
  where abs(e.amount-s.total_reimbursement)>0.01;

  return query
  select 'ACCESSORY_BOM_SNAPSHOT_MISSING','WARN',count(*)::bigint,
         'Production lots with a non-empty effective accessory BOM but no frozen accessory snapshot'
  from erp.fg_lots fl
  join erp.production_orders po on po.id=fl.po_id
  where fl.lot_origin='PRODUCTION'
    and exists (
      select 1
      from erp.accessory_bom_versions abv
      where abv.product_id=fl.product_id
        and abv.is_active=true
        and abv.effective_from<=coalesce(po.physical_start_at,fl.produced_at)
        and (abv.effective_to is null or abv.effective_to>coalesce(po.physical_start_at,fl.produced_at))
        and exists(select 1 from erp.accessory_bom_items abi where abi.bom_version_id=abv.id)
    )
    and not exists(select 1 from erp.fg_accessory_cost_snapshots s where s.lot_id=fl.id);
end;
$function$;

create or replace function erp.run_v25_integrity_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language plpgsql
stable
security definer
set search_path=erp,public
as $function$
begin
  perform erp.require_owner_admin();

  return query
  select 'BOM_COMMIT_PRODUCT_MISMATCH','ERROR',count(*)::bigint,
         'Committed accessory BOM must belong to the same logical SKU identity root as the committed PO/SKU product'
  from erp.po_accessory_bom_commitments c
  join erp.accessory_bom_versions b on b.id=c.bom_version_id
  join erp.products cp on cp.id=c.product_id
  join erp.products bp on bp.id=b.product_id
  where cp.identity_root_id is distinct from bp.identity_root_id;

  return query
  select 'PO_LOGICAL_SKU_MULTIPLE_BOM_COMMITMENTS','ERROR',count(*)::bigint,
         'One PO + logical SKU identity root must not freeze more than one accessory BOM economics version'
  from (
    select c.po_id,p.identity_root_id
    from erp.po_accessory_bom_commitments c
    join erp.products p on p.id=c.product_id
    group by c.po_id,p.identity_root_id
    having count(distinct c.bom_version_id)>1
  ) x;

  return query
  select 'BOM_COMMIT_PO_MODEL_MISMATCH','ERROR',count(*)::bigint,
         'Committed final SKU model must match production-order model'
  from erp.po_accessory_bom_commitments c
  join erp.production_orders po on po.id=c.po_id
  join erp.products p on p.id=c.product_id
  where p.model_id<>po.model_id;

  return query
  select 'ACCESSORY_SNAPSHOT_COMMIT_MISMATCH','ERROR',count(*)::bigint,
         'Historical accessory snapshot must use the PO/SKU committed BOM version'
  from erp.fg_accessory_cost_snapshots s
  join erp.po_accessory_bom_commitments c on c.po_id=s.po_id and c.product_id=s.product_id
  where s.bom_version_id<>c.bom_version_id;

  return query
  select 'BOM_COMMITTED_BY_PO_START_ONLY','ERROR',count(*)::bigint,
         'Non-empty V2.5 commitments may not be created merely because PO physically started'
  from erp.po_accessory_bom_commitments c
  where c.commit_source='FIRST_FINANCIAL_USE'
    and exists(select 1 from erp.accessory_bom_items abi where abi.bom_version_id=c.bom_version_id)
    and not exists(
      select 1
      from erp.fg_accessory_cost_snapshots s
      where s.po_id=c.po_id and s.product_id=c.product_id and s.bom_version_id=c.bom_version_id
    );

  return query
  select 'MIGRATION_BATCH_ERRORS','WARN',count(*)::bigint,
         'Migration batches currently contain validation-error staging rows'
  from erp.migration_batches b
  where exists(
    select 1 from erp.migration_staging_rows s
    where s.batch_id=b.id and s.validation_status='ERROR'
  );

  return query
  select 'POSTED_MIGRATION_UNAPPLIED_ROWS','ERROR',count(*)::bigint,
         'POSTED migration batches must not retain valid unapplied rows'
  from erp.migration_batches b
  where b.status='POSTED'
    and exists(
      select 1 from erp.migration_staging_rows s
      where s.batch_id=b.id and s.validation_status='VALID' and s.posted_entity_id is null
    );
end;
$function$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826123756','fix_no_accessory_bom_integrity_gates',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826123756 fix_no_accessory_bom_integrity_gates

-- BEGIN PLATFORM MIGRATION 20260826131023 cleanup_compact_validation_artifacts
drop function if exists public._compact_validation_snapshot();
drop table if exists public._erp_short_export_blob_260826;
drop table if exists public._erp_short_export_260826;
drop extension if exists http;
drop extension if exists pg_net;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826131023','cleanup_compact_validation_artifacts',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826131023 cleanup_compact_validation_artifacts

-- BEGIN PLATFORM MIGRATION 20260826131736 fix_opening_hpp_chained_reversal
create or replace function erp.reverse_opening_hpp_correction(p_correction_id uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path to 'erp','public'
as $function$
declare
  c erp.opening_hpp_corrections%rowtype;
  l erp.fg_lots%rowtype;
  v_current_id uuid;
  v_current_hpp numeric(20,6);
  v_ver integer;
  v_new_id uuid;
  v_descends boolean;
begin
  perform erp.require_owner_admin();
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan reversal koreksi HPP opening wajib diisi'; end if;
  select * into c from erp.opening_hpp_corrections where id=p_correction_id for update;
  if c.id is null then raise exception 'Koreksi HPP opening tidak ditemukan'; end if;
  if c.status='REVERSED' then return; end if;
  if exists(
    select 1 from erp.opening_hpp_corrections x
    where x.lot_id=c.lot_id and x.status='POSTED' and x.id<>c.id
      and (x.created_at,x.id)>(c.created_at,c.id)
  ) then
    raise exception 'Ada koreksi HPP opening yang lebih baru. Reverse yang terbaru dulu.';
  end if;

  select * into l from erp.fg_lots where id=c.lot_id for update;
  if exists(
    select 1
    from erp.product_conversion_allocations pca
    join erp.product_conversions pc on pc.id=pca.conversion_id
    where pca.source_lot_id=l.id and pc.status='POSTED'
      and pca.original_hpp_per_pcs is distinct from c.previous_hpp_snapshot
  ) then
    raise exception 'Lot sudah dipakai conversion dengan HPP hasil koreksi. Reverse/correct conversion dulu sebelum reversal HPP.';
  end if;

  select hpp_version_id,hpp_per_pcs into v_current_id,v_current_hpp
  from erp.v_current_hpp where lot_id=l.id;
  if v_current_id is null then raise exception 'Current HPP lot opening tidak ditemukan'; end if;

  if v_current_id is distinct from c.hpp_version_id then
    with recursive chain as (
      select h.id,h.supersedes_id from erp.hpp_versions h where h.id=v_current_id
      union all
      select h.id,h.supersedes_id
      from erp.hpp_versions h
      join chain x on h.id=x.supersedes_id
    )
    select exists(select 1 from chain where id=c.hpp_version_id) into v_descends;

    if not coalesce(v_descends,false) or abs(v_current_hpp-c.corrected_hpp)>0.000001 then
      raise exception 'Current HPP version tidak lagi konsisten dengan correction ini';
    end if;
  end if;

  select coalesce(max(version_no),0)+1 into v_ver from erp.hpp_versions where lot_id=l.id;
  update erp.hpp_versions set is_current=false where lot_id=l.id and is_current=true;
  insert into erp.hpp_versions(lot_id,version_no,cost_state,qty_basis_pcs,total_cost,is_current,supersedes_id,calculation_reason,created_by)
  values(l.id,v_ver,'ADJUSTED',l.initial_qty_pcs,l.initial_qty_pcs*c.previous_hpp_snapshot,true,v_current_id,'Reversal opening HPP correction: '||p_reason,erp.current_app_user_id())
  returning id into v_new_id;

  update erp.opening_hpp_corrections
  set status='REVERSED',reversed_at=now(),reversal_reason=p_reason
  where id=c.id;
  perform erp.sync_opening_lot_hpp_to_gl(l.id,current_date);
  insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)
  values('fg_lots',l.id,'REVERSE',jsonb_build_object('correction_id',c.id,'restored_hpp',c.previous_hpp_snapshot),erp.current_app_user_id(),p_reason);
end;
$function$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826131736','fix_opening_hpp_chained_reversal',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826131736 fix_opening_hpp_chained_reversal

-- BEGIN PLATFORM MIGRATION 20260826131910 fix_opening_hpp_reversal_ordering
create or replace function erp.reverse_opening_hpp_correction(p_correction_id uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path to 'erp','public'
as $function$
declare
  c erp.opening_hpp_corrections%rowtype;
  l erp.fg_lots%rowtype;
  v_current_id uuid;
  v_current_hpp numeric(20,6);
  v_ver integer;
  v_new_id uuid;
  v_descends boolean;
begin
  perform erp.require_owner_admin();
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan reversal koreksi HPP opening wajib diisi'; end if;
  select * into c from erp.opening_hpp_corrections where id=p_correction_id for update;
  if c.id is null then raise exception 'Koreksi HPP opening tidak ditemukan'; end if;
  if c.status='REVERSED' then return; end if;

  if exists(
    select 1
    from erp.opening_hpp_corrections x
    join erp.hpp_versions hx on hx.id=x.hpp_version_id
    join erp.hpp_versions hc on hc.id=c.hpp_version_id
    where x.lot_id=c.lot_id and x.status='POSTED' and x.id<>c.id
      and hx.version_no>hc.version_no
  ) then
    raise exception 'Ada koreksi HPP opening yang lebih baru. Reverse yang terbaru dulu.';
  end if;

  select * into l from erp.fg_lots where id=c.lot_id for update;
  if exists(
    select 1
    from erp.product_conversion_allocations pca
    join erp.product_conversions pc on pc.id=pca.conversion_id
    where pca.source_lot_id=l.id and pc.status='POSTED'
      and pca.original_hpp_per_pcs is distinct from c.previous_hpp_snapshot
  ) then
    raise exception 'Lot sudah dipakai conversion dengan HPP hasil koreksi. Reverse/correct conversion dulu sebelum reversal HPP.';
  end if;

  select hpp_version_id,hpp_per_pcs into v_current_id,v_current_hpp
  from erp.v_current_hpp where lot_id=l.id;
  if v_current_id is null then raise exception 'Current HPP lot opening tidak ditemukan'; end if;

  if v_current_id is distinct from c.hpp_version_id then
    with recursive chain as (
      select h.id,h.supersedes_id from erp.hpp_versions h where h.id=v_current_id
      union all
      select h.id,h.supersedes_id
      from erp.hpp_versions h
      join chain x on h.id=x.supersedes_id
    )
    select exists(select 1 from chain where id=c.hpp_version_id) into v_descends;

    if not coalesce(v_descends,false) or abs(v_current_hpp-c.corrected_hpp)>0.000001 then
      raise exception 'Current HPP version tidak lagi konsisten dengan correction ini';
    end if;
  end if;

  select coalesce(max(version_no),0)+1 into v_ver from erp.hpp_versions where lot_id=l.id;
  update erp.hpp_versions set is_current=false where lot_id=l.id and is_current=true;
  insert into erp.hpp_versions(lot_id,version_no,cost_state,qty_basis_pcs,total_cost,is_current,supersedes_id,calculation_reason,created_by)
  values(l.id,v_ver,'ADJUSTED',l.initial_qty_pcs,l.initial_qty_pcs*c.previous_hpp_snapshot,true,v_current_id,'Reversal opening HPP correction: '||p_reason,erp.current_app_user_id())
  returning id into v_new_id;

  update erp.opening_hpp_corrections
  set status='REVERSED',reversed_at=now(),reversal_reason=p_reason
  where id=c.id;
  perform erp.sync_opening_lot_hpp_to_gl(l.id,current_date);
  insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)
  values('fg_lots',l.id,'REVERSE',jsonb_build_object('correction_id',c.id,'restored_hpp',c.previous_hpp_snapshot),erp.current_app_user_id(),p_reason);
end;
$function$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826131910','fix_opening_hpp_reversal_ordering',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826131910 fix_opening_hpp_reversal_ordering

-- BEGIN PLATFORM MIGRATION 20260826140721 fix_opening_financial_correction_ordering
alter table erp.opening_financial_corrections
  add column correction_seq bigint not null;

alter table erp.opening_financial_corrections
  add constraint opening_financial_corrections_seq_positive check (correction_seq > 0);

create unique index opening_financial_corrections_item_seq_uq
  on erp.opening_financial_corrections(opening_item_id, correction_seq);

create or replace function erp.post_opening_financial_correction(p_opening_item_id uuid, p_corrected_amount numeric, p_reason text, p_effective_date date default current_date)
returns uuid
language plpgsql
security definer
set search_path to 'erp','public'
as $function$
declare
  i erp.opening_balance_items%rowtype;
  h_status text;
  b erp.opening_subledger_balances%rowtype;
  v_old numeric(20,2);
  v_new numeric(20,2);
  v_delta numeric(20,2);
  v_id uuid;
  v_no text;
  v_lines jsonb:='[]'::jsonb;
  v_cash uuid;
  v_abs numeric(20,2);
  v_seq bigint;
begin
  perform erp.require_owner_admin();
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan koreksi saldo awal wajib diisi'; end if;
  if p_corrected_amount is null or p_corrected_amount<0 then raise exception 'Saldo awal hasil koreksi tidak boleh negatif'; end if;
  if p_effective_date is null then raise exception 'Tanggal koreksi saldo awal wajib diisi'; end if;

  select * into i from erp.opening_balance_items where id=p_opening_item_id for update;
  if i.id is null then raise exception 'Item saldo awal tidak ditemukan'; end if;
  select status into h_status from erp.opening_balance_headers where id=i.opening_id for update;
  if h_status<>'POSTED' then raise exception 'Saldo awal harus sudah POSTED sebelum dikoreksi'; end if;
  if i.balance_type not in ('WIP','CONTRACTOR_RECEIVABLE','CONTRACTOR_PAYABLE','VENDOR_PAYABLE','SUPPLIER_PAYABLE','CUSTOMER_RECEIVABLE','CASH_BANK') then
    raise exception 'Jenis saldo awal % tidak dikoreksi lewat jalur finansial ini. Stok MATERIAL/FG gunakan stock adjustment agar lineage tetap aman.',i.balance_type;
  end if;

  select coalesce(max(c.correction_seq),0)+1
    into v_seq
  from erp.opening_financial_corrections c
  where c.opening_item_id=i.id;

  if i.balance_type in ('CONTRACTOR_RECEIVABLE','CONTRACTOR_PAYABLE','VENDOR_PAYABLE','SUPPLIER_PAYABLE','CUSTOMER_RECEIVABLE') then
    select * into b from erp.opening_subledger_balances where opening_item_id=i.id for update;
    if b.id is null then raise exception 'Opening subledger untuk item ini tidak ditemukan'; end if;
    v_old:=b.original_amount;
    if p_corrected_amount < b.settled_amount-0.01 then
      raise exception 'Saldo awal tidak boleh dikoreksi menjadi % karena sudah disettle %. Reverse settlement terkait terlebih dahulu.',p_corrected_amount,b.settled_amount;
    end if;
  else
    select coalesce((select c.corrected_amount from erp.opening_financial_corrections c where c.opening_item_id=i.id and c.status='POSTED' order by c.correction_seq desc limit 1),
                    case when i.balance_type='WIP' then coalesce(i.amount,coalesce(i.qty,0)*coalesce(i.unit_cost_snapshot,0)) else coalesce(i.amount,0) end)::numeric(20,2)
    into v_old;
  end if;

  v_new:=round(p_corrected_amount::numeric,2);
  v_delta:=v_new-v_old;
  if abs(v_delta)<=0.005 then raise exception 'Nilai koreksi sama dengan saldo awal efektif saat ini (%)',v_old; end if;
  v_no:='OFC-'||to_char(clock_timestamp(),'YYYYMMDDHH24MISSMS')||'-'||substr(gen_random_uuid()::text,1,6);
  insert into erp.opening_financial_corrections(correction_number,opening_item_id,previous_amount_snapshot,corrected_amount,delta_amount,effective_date,reason,created_by,created_at,correction_seq)
  values(v_no,i.id,v_old,v_new,v_delta,p_effective_date,p_reason,erp.current_app_user_id(),clock_timestamp(),v_seq) returning id into v_id;

  v_abs:=round(abs(v_delta),2);
  if i.balance_type='CASH_BANK' then
    select coa_account_id into v_cash from erp.cash_accounts where id=i.cash_account_id;
    if v_cash is null then raise exception 'Cash/bank account saldo awal tidak ditemukan'; end if;
    if v_delta>0 then v_lines:=jsonb_build_array(
      jsonb_build_object('account_id',v_cash,'debit',v_abs,'credit',0),
      jsonb_build_object('mapping_key','OPENING_EQUITY','debit',0,'credit',v_abs));
    else v_lines:=jsonb_build_array(
      jsonb_build_object('mapping_key','OPENING_EQUITY','debit',v_abs,'credit',0),
      jsonb_build_object('account_id',v_cash,'debit',0,'credit',v_abs)); end if;
  elsif i.balance_type in ('WIP','CUSTOMER_RECEIVABLE','CONTRACTOR_RECEIVABLE') then
    if v_delta>0 then v_lines:=jsonb_build_array(
      case when i.balance_type='WIP' then jsonb_build_object('mapping_key','WIP','debit',v_abs,'credit',0)
           when i.balance_type='CUSTOMER_RECEIVABLE' then jsonb_build_object('mapping_key','AR_CUSTOMER','debit',v_abs,'credit',0,'customer_id',i.customer_id)
           else jsonb_build_object('mapping_key','CONTRACTOR_RECEIVABLE','debit',v_abs,'credit',0,'contractor_id',i.contractor_id) end,
      jsonb_build_object('mapping_key','OPENING_EQUITY','debit',0,'credit',v_abs));
    else v_lines:=jsonb_build_array(
      jsonb_build_object('mapping_key','OPENING_EQUITY','debit',v_abs,'credit',0),
      case when i.balance_type='WIP' then jsonb_build_object('mapping_key','WIP','debit',0,'credit',v_abs)
           when i.balance_type='CUSTOMER_RECEIVABLE' then jsonb_build_object('mapping_key','AR_CUSTOMER','debit',0,'credit',v_abs,'customer_id',i.customer_id)
           else jsonb_build_object('mapping_key','CONTRACTOR_RECEIVABLE','debit',0,'credit',v_abs,'contractor_id',i.contractor_id) end); end if;
  else
    if v_delta>0 then v_lines:=jsonb_build_array(
      jsonb_build_object('mapping_key','OPENING_EQUITY','debit',v_abs,'credit',0),
      case when i.balance_type='SUPPLIER_PAYABLE' then jsonb_build_object('mapping_key','AP_SUPPLIER','debit',0,'credit',v_abs)
           when i.balance_type='VENDOR_PAYABLE' then jsonb_build_object('mapping_key','AP_VENDOR','debit',0,'credit',v_abs,'vendor_id',i.vendor_id)
           else jsonb_build_object('mapping_key','CONTRACTOR_PAYABLE','debit',0,'credit',v_abs,'contractor_id',i.contractor_id) end);
    else v_lines:=jsonb_build_array(
      case when i.balance_type='SUPPLIER_PAYABLE' then jsonb_build_object('mapping_key','AP_SUPPLIER','debit',v_abs,'credit',0)
           when i.balance_type='VENDOR_PAYABLE' then jsonb_build_object('mapping_key','AP_VENDOR','debit',v_abs,'credit',0,'vendor_id',i.vendor_id)
           else jsonb_build_object('mapping_key','CONTRACTOR_PAYABLE','debit',v_abs,'credit',0,'contractor_id',i.contractor_id) end,
      jsonb_build_object('mapping_key','OPENING_EQUITY','debit',0,'credit',v_abs)); end if;
  end if;

  perform erp.post_journal('OPENING_FINANCIAL_CORRECTION',v_id,p_effective_date,'Correction saldo awal: '||p_reason,v_lines);
  if b.id is not null then
    update erp.opening_subledger_balances
    set original_amount=v_new,
        status=case when settled_amount>=v_new-0.01 then 'SETTLED' when settled_amount>0 then 'PARTIAL' else 'OPEN' end,
        updated_at=now()
    where id=b.id;
  end if;
  insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)
  values('opening_balance_items',i.id,'UPDATE',jsonb_build_object('correction_id',v_id,'previous_amount',v_old,'corrected_amount',v_new,'delta',v_delta,'correction_type','OPENING_FINANCIAL_CORRECTION'),erp.current_app_user_id(),p_reason);
  return v_id;
end;
$function$;

create or replace function erp.reverse_opening_financial_correction(p_correction_id uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path to 'erp','public'
as $function$
declare c erp.opening_financial_corrections%rowtype;i erp.opening_balance_items%rowtype;b erp.opening_subledger_balances%rowtype;v_journal uuid;
begin
  perform erp.require_owner_admin();
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan reversal koreksi saldo awal wajib diisi'; end if;
  select * into c from erp.opening_financial_corrections where id=p_correction_id for update;
  if c.id is null then raise exception 'Koreksi saldo awal tidak ditemukan'; end if;
  if c.status='REVERSED' then return; end if;
  if exists(select 1 from erp.opening_financial_corrections x where x.opening_item_id=c.opening_item_id and x.status='POSTED' and x.id<>c.id and x.correction_seq>c.correction_seq) then
    raise exception 'Ada koreksi saldo awal yang lebih baru. Reverse koreksi terbaru terlebih dahulu.';
  end if;
  select * into i from erp.opening_balance_items where id=c.opening_item_id for update;
  if i.balance_type in ('CONTRACTOR_RECEIVABLE','CONTRACTOR_PAYABLE','VENDOR_PAYABLE','SUPPLIER_PAYABLE','CUSTOMER_RECEIVABLE') then
    select * into b from erp.opening_subledger_balances where opening_item_id=i.id for update;
    if b.settled_amount>c.previous_amount_snapshot+0.01 then
      raise exception 'Reversal koreksi akan menurunkan saldo awal ke %, tetapi sudah disettle %. Reverse settlement terkait terlebih dahulu.',c.previous_amount_snapshot,b.settled_amount;
    end if;
  end if;
  select id into v_journal from erp.journal_entries where source_type='OPENING_FINANCIAL_CORRECTION' and source_id=c.id and status='POSTED' order by posting_at desc,id desc limit 1;
  if v_journal is null then raise exception 'Jurnal koreksi saldo awal tidak ditemukan'; end if;
  perform erp.reverse_journal(v_journal,p_reason);
  if b.id is not null then
    update erp.opening_subledger_balances set original_amount=c.previous_amount_snapshot,
      status=case when settled_amount>=c.previous_amount_snapshot-0.01 then 'SETTLED' when settled_amount>0 then 'PARTIAL' else 'OPEN' end,
      updated_at=now() where id=b.id;
  end if;
  update erp.opening_financial_corrections set status='REVERSED',reversed_at=clock_timestamp(),reversal_reason=p_reason where id=c.id;
  insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)
  values('opening_balance_items',i.id,'REVERSE',jsonb_build_object('correction_id',c.id,'restored_amount',c.previous_amount_snapshot,'correction_type','OPENING_FINANCIAL_CORRECTION'),erp.current_app_user_id(),p_reason);
end;
$function$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826140721','fix_opening_financial_correction_ordering',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826140721 fix_opening_financial_correction_ordering

-- BEGIN PLATFORM MIGRATION 20260826141228 fix_material_purchase_cost_correction_ordering
alter table erp.material_purchase_cost_corrections
  add column post_seq bigint;

with ranked as (
  select id,
         row_number() over (
           partition by purchase_id
           order by coalesce(posted_at,created_at),created_at,id
         )::bigint as seq
  from erp.material_purchase_cost_corrections
  where status in ('POSTED','REVERSED')
)
update erp.material_purchase_cost_corrections c
set post_seq=r.seq
from ranked r
where r.id=c.id;

alter table erp.material_purchase_cost_corrections
  add constraint material_purchase_cost_corrections_post_seq_positive
  check (post_seq is null or post_seq>0),
  add constraint material_purchase_cost_corrections_post_seq_state
  check ((status='DRAFT' and post_seq is null) or (status in ('POSTED','REVERSED') and post_seq is not null));

create unique index material_purchase_cost_corrections_purchase_seq_uq
  on erp.material_purchase_cost_corrections(purchase_id,post_seq)
  where post_seq is not null;

create or replace function erp.material_purchase_current_unit_cost(p_purchase_item_id uuid)
returns numeric
language sql
stable security definer
set search_path to 'erp','public'
as $function$
select coalesce(
  (select mpcci.new_unit_price
   from erp.material_purchase_cost_correction_items mpcci
   join erp.material_purchase_cost_corrections mpcc on mpcc.id=mpcci.correction_id
   where mpcci.purchase_item_id=$1 and mpcc.status='POSTED'
   order by mpcc.post_seq desc,mpcc.posted_at desc,mpcc.created_at desc,mpcci.id desc limit 1),
  (select mpi.unit_price from erp.material_purchase_items mpi where mpi.id=$1)
)::numeric
$function$;

create or replace function erp.post_material_purchase_cost_correction(p_correction_id uuid)
returns void
language plpgsql
security definer
set search_path to 'erp','public'
as $function$
declare
  h erp.material_purchase_cost_corrections%rowtype;
  p erp.material_purchase_headers%rowtype;
  m record;
  r record;
  v_delta_payable numeric(24,6);
  v_old_cost numeric(18,6);
  v_material_delta numeric(24,6);
  v_current_payable numeric(24,6);
  v_proposed_payable numeric(24,6);
  v_paid numeric(24,6);
  v_lines jsonb:='[]'::jsonb;
  v_post_seq bigint;
begin
  perform erp.require_owner_admin();
  select * into h from erp.material_purchase_cost_corrections where id=p_correction_id for update;
  if h.id is null or h.status<>'DRAFT' then raise exception 'Material purchase cost correction must be DRAFT'; end if;
  select * into p from erp.material_purchase_headers where id=h.purchase_id for update;
  if p.id is null or p.status<>'POSTED' then raise exception 'Source material purchase must be POSTED'; end if;
  if not exists(select 1 from erp.material_purchase_cost_correction_items where correction_id=h.id) then raise exception 'Cost correction has no lines'; end if;

  select coalesce(max(c.post_seq),0)+1 into v_post_seq
  from erp.material_purchase_cost_corrections c
  where c.purchase_id=p.id and c.post_seq is not null;

  select erp.material_purchase_payable_total(p.id) into v_current_payable;
  select coalesce(sum(mpi.qty*(ci.new_unit_price-erp.material_purchase_current_unit_cost(mpi.id))),0)
  into v_delta_payable
  from erp.material_purchase_cost_correction_items ci
  join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id
  where ci.correction_id=h.id;
  v_proposed_payable:=v_current_payable+v_delta_payable;
  select coalesce(sum(sp.amount),0) into v_paid from erp.supplier_payments sp where sp.purchase_id=p.id and sp.status='POSTED';
  if v_proposed_payable< -0.01 then raise exception 'Corrected purchase payable cannot become negative'; end if;
  if v_paid>v_proposed_payable+0.01 then raise exception 'Cost correction would make supplier payments exceed corrected payable. Use supplier credit/receivable correction flow'; end if;

  for m in
    select distinct mpi.material_id
    from erp.material_purchase_cost_correction_items ci join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id
    where ci.correction_id=h.id
  loop
    v_material_delta:=0;
    for r in
      select ci.id as correction_item_id,ci.purchase_item_id,ci.new_unit_price,mpi.qty,mpi.material_id
      from erp.material_purchase_cost_correction_items ci
      join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id
      where ci.correction_id=h.id and mpi.material_id=m.material_id
      order by ci.id
    loop
      v_old_cost:=erp.material_purchase_current_unit_cost(r.purchase_item_id);
      update erp.material_purchase_cost_correction_items
      set old_unit_cost_snapshot=v_old_cost,qty_basis=r.qty,delta_amount=r.qty*(r.new_unit_price-v_old_cost)
      where id=r.correction_item_id;
      v_material_delta:=v_material_delta+(r.qty*(r.new_unit_price-v_old_cost));
      update erp.material_stock_movements msm
      set input_unit_cost=r.new_unit_price
      where msm.movement_type='PURCHASE' and msm.qty_signed>0 and (
        (msm.source_type='MATERIAL_PURCHASE_ITEM' and msm.source_id=r.purchase_item_id)
        or (msm.source_type='MATERIAL_PURCHASE_ROLL' and msm.source_id in(select mr.id from erp.material_rolls mr where mr.purchase_item_id=r.purchase_item_id))
      );
      if not found then raise exception 'Original purchase stock movement not found for purchase item %',r.purchase_item_id; end if;
    end loop;

    perform erp.recalculate_material_cost(m.material_id);

    if abs(v_material_delta)>0.005 then
      if v_material_delta>0 then
        v_lines:=v_lines||jsonb_build_array(
          jsonb_build_object('mapping_key','MATERIAL_INVENTORY','debit',round(v_material_delta,2),'credit',0),
          jsonb_build_object('mapping_key','AP_SUPPLIER','debit',0,'credit',round(v_material_delta,2))
        );
      else
        v_lines:=v_lines||jsonb_build_array(
          jsonb_build_object('mapping_key','AP_SUPPLIER','debit',round(abs(v_material_delta),2),'credit',0),
          jsonb_build_object('mapping_key','MATERIAL_INVENTORY','debit',0,'credit',round(abs(v_material_delta),2))
        );
      end if;
    end if;
  end loop;

  if jsonb_array_length(v_lines)>=2 then
    perform erp.post_journal('MATERIAL_PURCHASE_COST_CORRECTION',h.id,h.invoice_date,'Late/final fabric supplier invoice cost correction',v_lines);
  end if;
  update erp.material_purchase_cost_corrections
  set status='POSTED',posted_at=clock_timestamp(),post_seq=v_post_seq
  where id=h.id;
  select erp.material_purchase_payable_total(p.id) into v_proposed_payable;
  select coalesce(sum(sp.amount),0) into v_paid from erp.supplier_payments sp where sp.purchase_id=p.id and sp.status='POSTED';
  update erp.material_purchase_headers set payment_status=case when v_paid>=v_proposed_payable-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end where id=p.id;
end;
$function$;

create or replace function erp.reverse_material_purchase_cost_correction(p_correction_id uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path to 'erp','public'
as $function$
declare
  h erp.material_purchase_cost_corrections%rowtype;
  p erp.material_purchase_headers%rowtype;
  r record;
  m uuid;
  v_journal uuid;
  v_current_payable numeric(24,6);
  v_delta numeric(24,6);
  v_projected numeric(24,6);
  v_paid numeric(24,6);
begin
  perform erp.require_owner_admin();
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan reversal koreksi harga pembelian wajib diisi'; end if;
  select * into h from erp.material_purchase_cost_corrections where id=p_correction_id for update;
  if h.id is null then raise exception 'Koreksi harga pembelian tidak ditemukan'; end if;
  if h.status='REVERSED' then return; end if;
  if h.status<>'POSTED' then raise exception 'Hanya koreksi harga pembelian POSTED yang dapat direverse'; end if;
  if h.post_seq is null then raise exception 'Urutan posting koreksi harga pembelian tidak ditemukan; reversal dibatalkan'; end if;
  select * into p from erp.material_purchase_headers where id=h.purchase_id for update;
  if p.id is null or p.status<>'POSTED' then raise exception 'Pembelian sumber harus masih POSTED'; end if;

  if exists(
    select 1
    from erp.material_purchase_cost_correction_items ci
    join erp.material_purchase_cost_correction_items ci2 on ci2.purchase_item_id=ci.purchase_item_id
    join erp.material_purchase_cost_corrections c2 on c2.id=ci2.correction_id
    where ci.correction_id=h.id and c2.status='POSTED' and c2.id<>h.id
      and c2.post_seq>h.post_seq
  ) then
    raise exception 'Ada koreksi harga yang lebih baru pada item pembelian ini. Reverse koreksi terbaru terlebih dahulu.';
  end if;

  select erp.material_purchase_payable_total(p.id) into v_current_payable;
  select coalesce(sum(delta_amount),0) into v_delta
  from erp.material_purchase_cost_correction_items where correction_id=h.id;
  v_projected:=v_current_payable-v_delta;
  select coalesce(sum(amount),0) into v_paid from erp.supplier_payments where purchase_id=p.id and status='POSTED';
  if v_paid>v_projected+0.01 then
    raise exception 'Reversal koreksi harga membuat pembayaran supplier melebihi hutang tersisa. Reverse/koreksi pembayaran supplier terlebih dahulu.';
  end if;

  for r in
    select ci.*,mpi.material_id
    from erp.material_purchase_cost_correction_items ci
    join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id
    where ci.correction_id=h.id order by ci.id
  loop
    if r.old_unit_cost_snapshot is null then
      raise exception 'Snapshot harga sebelum koreksi tidak ditemukan untuk item %; reversal dibatalkan',r.purchase_item_id;
    end if;
    update erp.material_stock_movements msm
    set input_unit_cost=r.old_unit_cost_snapshot
    where msm.movement_type='PURCHASE' and msm.qty_signed>0 and (
      (msm.source_type='MATERIAL_PURCHASE_ITEM' and msm.source_id=r.purchase_item_id)
      or (msm.source_type='MATERIAL_PURCHASE_ROLL' and msm.source_id in (select mr.id from erp.material_rolls mr where mr.purchase_item_id=r.purchase_item_id))
    );
  end loop;

  update erp.material_purchase_cost_corrections set status='REVERSED' where id=h.id;
  for m in
    select distinct mpi.material_id from erp.material_purchase_cost_correction_items ci
    join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id where ci.correction_id=h.id
  loop
    perform erp.recalculate_material_cost(m);
  end loop;

  select id into v_journal from erp.journal_entries
  where source_type='MATERIAL_PURCHASE_COST_CORRECTION' and source_id=h.id and status='POSTED'
  order by posting_at desc,id desc limit 1;
  if abs(v_delta)>0.005 and v_journal is null then
    raise exception 'Jurnal koreksi harga pembelian tidak ditemukan; reversal dibatalkan agar inventory/AP tidak rusak';
  end if;
  if v_journal is not null then perform erp.reverse_journal(v_journal,p_reason); end if;

  select erp.material_purchase_payable_total(p.id) into v_projected;
  select coalesce(sum(amount),0) into v_paid from erp.supplier_payments where purchase_id=p.id and status='POSTED';
  update erp.material_purchase_headers set payment_status=case when v_paid>=v_projected-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end where id=p.id;

  insert into erp.audit_logs(entity_type,entity_id,action,changed_by,change_reason)
  values('material_purchase_cost_corrections',h.id,'REVERSE',erp.current_app_user_id(),p_reason);
end;
$function$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826141228','fix_material_purchase_cost_correction_ordering',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826141228 fix_material_purchase_cost_correction_ordering

-- BEGIN PLATFORM MIGRATION 20260826154125 rls_performance_hygiene_v260
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'accessory_bom_items','accessory_bom_versions','contractor_accessory_price_versions',
    'contractor_material_price_versions','contractor_work_rates','laundry_vendor_rate_versions',
    'product_price_versions','work_bom_items','work_bom_versions'
  ] LOOP
    EXECUTE format('ALTER POLICY internal_read ON erp.%I USING ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text,''STAFF''::text]))', t);
    EXECUTE format('DROP POLICY IF EXISTS owner_admin_write ON erp.%I', t);
    EXECUTE format('DROP POLICY IF EXISTS owner_admin_insert ON erp.%I', t);
    EXECUTE format('DROP POLICY IF EXISTS owner_admin_update ON erp.%I', t);
    EXECUTE format('DROP POLICY IF EXISTS owner_admin_delete ON erp.%I', t);
    EXECUTE format('CREATE POLICY owner_admin_insert ON erp.%I FOR INSERT TO authenticated WITH CHECK ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text]))', t);
    EXECUTE format('CREATE POLICY owner_admin_update ON erp.%I FOR UPDATE TO authenticated USING ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text])) WITH CHECK ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text]))', t);
    EXECUTE format('CREATE POLICY owner_admin_delete ON erp.%I FOR DELETE TO authenticated USING ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text]))', t);
  END LOOP;

  FOREACH t IN ARRAY ARRAY[
    'accounting_account_mappings','cash_accounts','chart_accounts',
    'material_purchase_cost_correction_items','material_purchase_cost_corrections','uom_definitions'
  ] LOOP
    EXECUTE format('DROP POLICY IF EXISTS owner_admin_manage ON erp.%I', t);
    EXECUTE format('DROP POLICY IF EXISTS owner_admin_insert ON erp.%I', t);
    EXECUTE format('DROP POLICY IF EXISTS owner_admin_update ON erp.%I', t);
    EXECUTE format('DROP POLICY IF EXISTS owner_admin_delete ON erp.%I', t);
    EXECUTE format('CREATE POLICY owner_admin_insert ON erp.%I FOR INSERT TO authenticated WITH CHECK ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text]))', t);
    EXECUTE format('CREATE POLICY owner_admin_update ON erp.%I FOR UPDATE TO authenticated USING ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text])) WITH CHECK ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text]))', t);
    EXECUTE format('CREATE POLICY owner_admin_delete ON erp.%I FOR DELETE TO authenticated USING ((SELECT erp.current_app_role()) = ANY (ARRAY[''OWNER''::text,''ADMIN''::text]))', t);
  END LOOP;
END $$;

ALTER POLICY own_app_user ON erp.app_users
USING (auth_user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS internal_app_users ON erp.app_users;
DROP POLICY IF EXISTS internal_app_users_insert ON erp.app_users;
DROP POLICY IF EXISTS internal_app_users_update ON erp.app_users;
DROP POLICY IF EXISTS internal_app_users_delete ON erp.app_users;
CREATE POLICY internal_app_users_insert ON erp.app_users
  FOR INSERT TO public
  WITH CHECK ((SELECT erp.current_app_role()) = ANY (ARRAY['OWNER'::text,'ADMIN'::text]));
CREATE POLICY internal_app_users_update ON erp.app_users
  FOR UPDATE TO public
  USING ((SELECT erp.current_app_role()) = ANY (ARRAY['OWNER'::text,'ADMIN'::text]))
  WITH CHECK ((SELECT erp.current_app_role()) = ANY (ARRAY['OWNER'::text,'ADMIN'::text]));
CREATE POLICY internal_app_users_delete ON erp.app_users
  FOR DELETE TO public
  USING ((SELECT erp.current_app_role()) = ANY (ARRAY['OWNER'::text,'ADMIN'::text]));

ALTER POLICY own_customer_access ON erp.customer_user_access
USING (app_user_id = (SELECT erp.current_app_user_id()));

DROP POLICY IF EXISTS internal_customer_access ON erp.customer_user_access;
DROP POLICY IF EXISTS internal_customer_access_insert ON erp.customer_user_access;
DROP POLICY IF EXISTS internal_customer_access_update ON erp.customer_user_access;
DROP POLICY IF EXISTS internal_customer_access_delete ON erp.customer_user_access;
CREATE POLICY internal_customer_access_insert ON erp.customer_user_access
  FOR INSERT TO public
  WITH CHECK ((SELECT erp.current_app_role()) = ANY (ARRAY['OWNER'::text,'ADMIN'::text]));
CREATE POLICY internal_customer_access_update ON erp.customer_user_access
  FOR UPDATE TO public
  USING ((SELECT erp.current_app_role()) = ANY (ARRAY['OWNER'::text,'ADMIN'::text]))
  WITH CHECK ((SELECT erp.current_app_role()) = ANY (ARRAY['OWNER'::text,'ADMIN'::text]));
CREATE POLICY internal_customer_access_delete ON erp.customer_user_access
  FOR DELETE TO public
  USING ((SELECT erp.current_app_role()) = ANY (ARRAY['OWNER'::text,'ADMIN'::text]));
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826154125','rls_performance_hygiene_v260',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826154125 rls_performance_hygiene_v260

-- BEGIN PLATFORM MIGRATION 20260826162724 v261_material_cost_checkpoint_replay
create table if not exists erp.material_cost_checkpoints (
  material_id uuid primary key references erp.materials(id) on delete cascade,
  checkpoint_date date not null,
  stock_qty numeric(18,6) not null check (stock_qty>=0),
  moving_average_cost numeric(18,6) not null check (moving_average_cost>=0),
  last_physical_at timestamptz,
  last_system_created_at timestamptz,
  last_movement_id uuid,
  checkpoint_created_at timestamptz not null default clock_timestamp(),
  constraint material_cost_checkpoint_last_key_ck check (
    (last_movement_id is null and last_physical_at is null and last_system_created_at is null)
    or
    (last_movement_id is not null and last_physical_at is not null and last_system_created_at is not null)
  )
);
alter table erp.material_cost_checkpoints enable row level security;
revoke all on erp.material_cost_checkpoints from public, anon, authenticated;

create or replace function erp.refresh_material_cost_checkpoint(p_material_id uuid,p_checkpoint_date date)
returns void
language plpgsql
security definer
set search_path='erp','public'
as $function$
declare
  v_stock numeric(18,6):=0;
  v_avg numeric(18,6):=0;
  v_last_physical timestamptz;
  v_last_system timestamptz;
  v_last_id uuid;
  v_has_active boolean;
begin
  perform erp.require_internal();
  if p_checkpoint_date is null then raise exception 'Checkpoint date is required'; end if;
  perform 1 from erp.materials where id=p_material_id for update;
  if not found then raise exception 'Material not found'; end if;

  select exists(
    select 1 from erp.material_stock_movements msm
    where msm.material_id=p_material_id
      and msm.physical_at::date<=p_checkpoint_date
      and msm.reversal_of_id is null
      and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=msm.id)
  ) into v_has_active;

  select h.stock_after,h.average_after,msm.physical_at,msm.system_created_at,msm.id
  into v_stock,v_avg,v_last_physical,v_last_system,v_last_id
  from erp.material_cost_history h
  join erp.material_stock_movements msm on msm.id=h.movement_id
  where h.material_id=p_material_id
    and msm.physical_at::date<=p_checkpoint_date
    and msm.reversal_of_id is null
    and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=msm.id)
  order by msm.physical_at desc,msm.system_created_at desc,msm.id desc
  limit 1;

  if v_has_active and v_last_id is null then
    raise exception 'Cannot checkpoint material %: chronological cost history is incomplete before %',p_material_id,p_checkpoint_date;
  end if;

  if not v_has_active then
    v_stock:=0; v_avg:=0; v_last_physical:=null; v_last_system:=null; v_last_id:=null;
  end if;

  insert into erp.material_cost_checkpoints(material_id,checkpoint_date,stock_qty,moving_average_cost,last_physical_at,last_system_created_at,last_movement_id,checkpoint_created_at)
  values(p_material_id,p_checkpoint_date,coalesce(v_stock,0),coalesce(v_avg,0),v_last_physical,v_last_system,v_last_id,clock_timestamp())
  on conflict(material_id) do update
  set checkpoint_date=excluded.checkpoint_date,
      stock_qty=excluded.stock_qty,
      moving_average_cost=excluded.moving_average_cost,
      last_physical_at=excluded.last_physical_at,
      last_system_created_at=excluded.last_system_created_at,
      last_movement_id=excluded.last_movement_id,
      checkpoint_created_at=excluded.checkpoint_created_at;
end;
$function$;
revoke all on function erp.refresh_material_cost_checkpoint(uuid,date) from public,anon,authenticated;

create or replace function erp._recalculate_material_cost_core(p_material_id uuid,p_recalc_from timestamptz,p_allow_checkpoint boolean)
returns void
language plpgsql
security definer
set search_path='erp','public'
as $function$
declare
  r erp.material_stock_movements%rowtype;
  rr record;
  v_stock numeric(18,6):=0;
  v_avg numeric(18,6):=0;
  v_stock_before numeric(18,6);
  v_avg_before numeric(18,6);
  v_cost numeric(18,6);
  v_new_stock numeric(18,6);
  v_new_avg numeric(18,6);
  v_closed date;
  v_cp erp.material_cost_checkpoints%rowtype;
  v_use_checkpoint boolean:=false;
begin
  perform erp.require_internal();
  select closed_through into v_closed from erp.accounting_period_control where singleton_id=1 for share;
  perform 1 from erp.materials where id=p_material_id for update;
  if not found then raise exception 'Material not found'; end if;

  if p_allow_checkpoint and p_recalc_from is not null and v_closed is not null then
    select * into v_cp from erp.material_cost_checkpoints where material_id=p_material_id;
    if v_cp.material_id is not null
       and v_cp.checkpoint_date<=v_closed
       and p_recalc_from::date>v_cp.checkpoint_date then
      v_use_checkpoint:=true;
      v_stock:=v_cp.stock_qty;
      v_avg:=v_cp.moving_average_cost;
    end if;
  end if;

  if v_use_checkpoint then
    if v_cp.last_movement_id is null then
      delete from erp.material_cost_history where material_id=p_material_id;
    else
      delete from erp.material_cost_history h
      using erp.material_stock_movements msm
      where h.material_id=p_material_id and h.movement_id=msm.id
        and (msm.physical_at,msm.system_created_at,msm.id)>(v_cp.last_physical_at,v_cp.last_system_created_at,v_cp.last_movement_id);
    end if;
  else
    delete from erp.material_cost_history where material_id=p_material_id;
  end if;

  for r in
    select * from erp.material_stock_movements msm
    where msm.material_id=p_material_id
      and msm.reversal_of_id is null
      and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=msm.id)
      and (
        not v_use_checkpoint
        or v_cp.last_movement_id is null
        or (msm.physical_at,msm.system_created_at,msm.id)>(v_cp.last_physical_at,v_cp.last_system_created_at,v_cp.last_movement_id)
      )
    order by msm.physical_at,msm.system_created_at,msm.id
    for update
  loop
    v_stock_before:=v_stock;
    v_avg_before:=v_avg;
    if r.qty_signed>0 then
      if r.movement_type='REVERSAL' and r.reversal_of_id is not null then
        select x.unit_cost_snapshot into v_cost from erp.material_stock_movements x where x.id=r.reversal_of_id;
        v_cost:=coalesce(v_cost,r.input_unit_cost,r.unit_cost_snapshot,v_avg);
      elsif r.movement_type='CUTTING_RETURN' and r.source_type='CUTTING_GROUP_RETURN' then
        select x.unit_cost_snapshot into v_cost
        from erp.material_stock_movements x
        where x.material_id=r.material_id
          and x.source_type='CUTTING_GROUP' and x.source_id=r.source_id
          and x.movement_type='CUTTING_ISSUE'
          and x.roll_id is not distinct from r.roll_id
        order by x.physical_at desc,x.system_created_at desc,x.id desc limit 1;
        v_cost:=coalesce(v_cost,r.input_unit_cost,r.unit_cost_snapshot,v_avg);
      else
        v_cost:=coalesce(r.input_unit_cost,r.unit_cost_snapshot,v_avg);
      end if;
      v_new_stock:=v_stock+r.qty_signed;
      if v_new_stock>0 then
        v_new_avg:=((v_stock*v_avg)+(r.qty_signed*v_cost))/v_new_stock;
      else
        v_new_avg:=0;
      end if;
    else
      v_new_stock:=v_stock+r.qty_signed;
      if v_new_stock<0 then
        raise exception 'Backdate/correction would create negative material stock for material %, movement %',p_material_id,r.id;
      end if;
      v_cost:=v_avg;
      v_new_avg:=case when v_new_stock=0 then 0 else v_avg end;
    end if;

    update erp.material_stock_movements
    set original_unit_cost_snapshot=coalesce(original_unit_cost_snapshot,v_cost),
        unit_cost_snapshot=v_cost,
        is_cost_recalculated=true
    where id=r.id;

    insert into erp.material_cost_history(material_id,movement_id,physical_at,stock_before,average_before,movement_qty,movement_unit_cost,stock_after,average_after)
    values(p_material_id,r.id,r.physical_at,v_stock_before,v_avg_before,r.qty_signed,v_cost,v_new_stock,v_new_avg);
    v_stock:=v_new_stock;
    v_avg:=v_new_avg;
  end loop;

  for rr in
    select mr.id as roll_id,coalesce(sum(msm.qty_signed),0)::numeric as roll_qty
    from erp.material_rolls mr
    left join erp.material_stock_movements msm on msm.roll_id=mr.id
    where mr.material_id=p_material_id
    group by mr.id
  loop
    if rr.roll_qty<0 then raise exception 'Correction would create negative roll stock for roll %',rr.roll_id; end if;
    update erp.material_rolls
    set cached_qty=rr.roll_qty,
        status=case when rr.roll_qty=0 then 'EXHAUSTED' when rr.roll_qty<original_qty then 'HALF_USED' else 'AVAILABLE' end,
        updated_at=now()
    where id=rr.roll_id and status<>'RETURNED_SUPPLIER';
  end loop;

  update erp.cutting_group_rolls cgr
  set unit_cost_snapshot=(
    select msm.unit_cost_snapshot
    from erp.material_stock_movements msm
    where msm.material_id=p_material_id and msm.source_type='CUTTING_GROUP'
      and msm.source_id=cgr.cutting_group_id and msm.movement_type='CUTTING_ISSUE'
      and msm.roll_id is not distinct from cgr.roll_id
    order by msm.physical_at desc,msm.system_created_at desc,msm.id desc limit 1
  )
  where exists(
    select 1 from erp.material_stock_movements msm
    where msm.material_id=p_material_id and msm.source_type='CUTTING_GROUP'
      and msm.source_id=cgr.cutting_group_id and msm.movement_type='CUTTING_ISSUE'
      and msm.roll_id is not distinct from cgr.roll_id
  );

  update erp.contractor_material_issue_items ii
  set unit_cost_snapshot=(
    select msm.unit_cost_snapshot from erp.material_stock_movements msm
    where msm.material_id=p_material_id and msm.source_type='CONTRACTOR_MATERIAL_ISSUE_ITEM'
      and msm.source_id=ii.id and msm.movement_type='CONTRACTOR_ISSUE'
    order by msm.physical_at desc,msm.system_created_at desc,msm.id desc limit 1
  )
  where ii.material_id=p_material_id and exists(
    select 1 from erp.material_stock_movements msm
    where msm.material_id=p_material_id and msm.source_type='CONTRACTOR_MATERIAL_ISSUE_ITEM'
      and msm.source_id=ii.id and msm.movement_type='CONTRACTOR_ISSUE'
  );

  update erp.materials set cached_stock_qty=v_stock,moving_average_cost=v_avg,updated_at=now() where id=p_material_id;

  perform erp.sync_material_cost_revaluation(p_material_id);

  insert into erp.cost_recalc_queue(entity_type,entity_id,recalc_from,reason)
  select distinct 'PO',cg.po_id,min(msm.physical_at),'Material moving-average/backdate recalculation'
  from erp.material_stock_movements msm
  join erp.cutting_groups cg on msm.source_type in('CUTTING_GROUP','CUTTING_GROUP_RETURN') and msm.source_id=cg.id
  where msm.material_id=p_material_id
    and exists(select 1 from erp.fg_lots fl where fl.po_id=cg.po_id)
    and not exists(select 1 from erp.cost_recalc_queue q where q.entity_type='PO' and q.entity_id=cg.po_id and (q.status in('PENDING','RUNNING') or (q.status='FAILED' and q.attempt_count<3)))
  group by cg.po_id;

  insert into erp.cost_recalc_queue(entity_type,entity_id,recalc_from,reason)
  select distinct 'PO',cmi.po_id,min(msm.physical_at),'Contractor material moving-average/backdate recalculation'
  from erp.material_stock_movements msm
  join erp.contractor_material_issue_items ii on msm.source_type='CONTRACTOR_MATERIAL_ISSUE_ITEM' and msm.source_id=ii.id
  join erp.contractor_material_issues cmi on cmi.id=ii.issue_id
  where msm.material_id=p_material_id and cmi.po_id is not null
    and exists(select 1 from erp.fg_lots fl where fl.po_id=cmi.po_id)
    and not exists(select 1 from erp.cost_recalc_queue q where q.entity_type='PO' and q.entity_id=cmi.po_id and (q.status in('PENDING','RUNNING') or (q.status='FAILED' and q.attempt_count<3)))
  group by cmi.po_id;

  insert into erp.audit_logs(entity_type,entity_id,action,new_data,changed_by,change_reason)
  values('materials',p_material_id,'RECALCULATE',jsonb_build_object('cached_stock_qty',v_stock,'moving_average_cost',v_avg,'original_movement_snapshots_preserved',true,'gl_revaluation_synced',true,'checkpoint_used',v_use_checkpoint,'recalc_from',p_recalc_from),erp.current_app_user_id(),'Material chronological moving-average recalculation');

  perform erp.refresh_accessory_hpp_after_material_recost(p_material_id,'Material chronological moving-average recalculation');

  if not v_use_checkpoint and v_closed is not null then
    perform erp.refresh_material_cost_checkpoint(p_material_id,v_closed);
  end if;
end;
$function$;
revoke all on function erp._recalculate_material_cost_core(uuid,timestamptz,boolean) from public,anon,authenticated;

create or replace function erp.recalculate_material_cost(p_material_id uuid)
returns void
language plpgsql
security definer
set search_path='erp','public'
as $function$
begin
  perform erp._recalculate_material_cost_core(p_material_id,null,false);
end;
$function$;

create or replace function erp.recalculate_material_cost(p_material_id uuid,p_recalc_from timestamptz)
returns void
language plpgsql
security definer
set search_path='erp','public'
as $function$
begin
  perform erp._recalculate_material_cost_core(p_material_id,p_recalc_from,true);
end;
$function$;
revoke all on function erp.recalculate_material_cost(uuid,timestamptz) from public,anon,authenticated;

create or replace function erp.close_accounting_through(p_closed_through date,p_reason text)
returns void
language plpgsql
security definer
set search_path='erp','public'
as $function$
declare v_old date; v_material uuid;
begin
  perform erp.require_owner_admin();
  if p_closed_through is null then raise exception 'Tanggal tutup buku wajib diisi'; end if;
  if p_closed_through>=current_date then raise exception 'Tutup buku hanya boleh sampai tanggal sebelum hari ini'; end if;
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan tutup buku wajib diisi'; end if;
  select closed_through into v_old from erp.accounting_period_control where singleton_id=1 for update;
  if v_old is not null and p_closed_through<v_old then
    raise exception 'Untuk membuka kembali periode gunakan reopen_accounting_through(); periode saat ini sudah ditutup sampai %',v_old;
  end if;
  update erp.accounting_period_control
  set closed_through=p_closed_through,updated_at=now(),updated_by=erp.current_app_user_id(),change_reason=p_reason
  where singleton_id=1;

  for v_material in select id from erp.materials order by id loop
    perform erp.refresh_material_cost_checkpoint(v_material,p_closed_through);
  end loop;

  insert into erp.audit_logs(entity_type,entity_id,action,old_data,new_data,changed_by,change_reason)
  values('accounting_period_control',null,'UPDATE',jsonb_build_object('closed_through',v_old),jsonb_build_object('closed_through',p_closed_through,'material_cost_checkpoints_refreshed',true),erp.current_app_user_id(),p_reason);
end;
$function$;

create or replace function erp.post_material_purchase_cost_correction(p_correction_id uuid)
returns void
language plpgsql
security definer
set search_path='erp','public'
as $function$
declare
  h erp.material_purchase_cost_corrections%rowtype;
  p erp.material_purchase_headers%rowtype;
  m record;
  r record;
  v_delta_payable numeric(24,6);
  v_old_cost numeric(18,6);
  v_material_delta numeric(24,6);
  v_current_payable numeric(24,6);
  v_proposed_payable numeric(24,6);
  v_paid numeric(24,6);
  v_lines jsonb:='[]'::jsonb;
  v_post_seq bigint;
begin
  perform erp.require_owner_admin();
  select * into h from erp.material_purchase_cost_corrections where id=p_correction_id for update;
  if h.id is null or h.status<>'DRAFT' then raise exception 'Material purchase cost correction must be DRAFT'; end if;
  select * into p from erp.material_purchase_headers where id=h.purchase_id for update;
  if p.id is null or p.status<>'POSTED' then raise exception 'Source material purchase must be POSTED'; end if;
  if not exists(select 1 from erp.material_purchase_cost_correction_items where correction_id=h.id) then raise exception 'Cost correction has no lines'; end if;

  select coalesce(max(c.post_seq),0)+1 into v_post_seq
  from erp.material_purchase_cost_corrections c
  where c.purchase_id=p.id and c.post_seq is not null;

  select erp.material_purchase_payable_total(p.id) into v_current_payable;
  select coalesce(sum(mpi.qty*(ci.new_unit_price-erp.material_purchase_current_unit_cost(mpi.id))),0)
  into v_delta_payable
  from erp.material_purchase_cost_correction_items ci
  join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id
  where ci.correction_id=h.id;
  v_proposed_payable:=v_current_payable+v_delta_payable;
  select coalesce(sum(sp.amount),0) into v_paid from erp.supplier_payments sp where sp.purchase_id=p.id and sp.status='POSTED';
  if v_proposed_payable< -0.01 then raise exception 'Corrected purchase payable cannot become negative'; end if;
  if v_paid>v_proposed_payable+0.01 then raise exception 'Cost correction would make supplier payments exceed corrected payable. Use supplier credit/receivable correction flow'; end if;

  for m in
    select distinct mpi.material_id
    from erp.material_purchase_cost_correction_items ci join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id
    where ci.correction_id=h.id
  loop
    v_material_delta:=0;
    for r in
      select ci.id as correction_item_id,ci.purchase_item_id,ci.new_unit_price,mpi.qty,mpi.material_id
      from erp.material_purchase_cost_correction_items ci
      join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id
      where ci.correction_id=h.id and mpi.material_id=m.material_id
      order by ci.id
    loop
      v_old_cost:=erp.material_purchase_current_unit_cost(r.purchase_item_id);
      update erp.material_purchase_cost_correction_items
      set old_unit_cost_snapshot=v_old_cost,qty_basis=r.qty,delta_amount=r.qty*(r.new_unit_price-v_old_cost)
      where id=r.correction_item_id;
      v_material_delta:=v_material_delta+(r.qty*(r.new_unit_price-v_old_cost));
      update erp.material_stock_movements msm
      set input_unit_cost=r.new_unit_price
      where msm.movement_type='PURCHASE' and msm.qty_signed>0 and (
        (msm.source_type='MATERIAL_PURCHASE_ITEM' and msm.source_id=r.purchase_item_id)
        or (msm.source_type='MATERIAL_PURCHASE_ROLL' and msm.source_id in(select mr.id from erp.material_rolls mr where mr.purchase_item_id=r.purchase_item_id))
      );
      if not found then raise exception 'Original purchase stock movement not found for purchase item %',r.purchase_item_id; end if;
    end loop;

    perform erp.recalculate_material_cost(m.material_id,p.physical_at);

    if abs(v_material_delta)>0.005 then
      if v_material_delta>0 then
        v_lines:=v_lines||jsonb_build_array(
          jsonb_build_object('mapping_key','MATERIAL_INVENTORY','debit',round(v_material_delta,2),'credit',0),
          jsonb_build_object('mapping_key','AP_SUPPLIER','debit',0,'credit',round(v_material_delta,2))
        );
      else
        v_lines:=v_lines||jsonb_build_array(
          jsonb_build_object('mapping_key','AP_SUPPLIER','debit',round(abs(v_material_delta),2),'credit',0),
          jsonb_build_object('mapping_key','MATERIAL_INVENTORY','debit',0,'credit',round(abs(v_material_delta),2))
        );
      end if;
    end if;
  end loop;

  if jsonb_array_length(v_lines)>=2 then
    perform erp.post_journal('MATERIAL_PURCHASE_COST_CORRECTION',h.id,h.invoice_date,'Late/final fabric supplier invoice cost correction',v_lines);
  end if;
  update erp.material_purchase_cost_corrections
  set status='POSTED',posted_at=clock_timestamp(),post_seq=v_post_seq
  where id=h.id;
  select erp.material_purchase_payable_total(p.id) into v_proposed_payable;
  select coalesce(sum(sp.amount),0) into v_paid from erp.supplier_payments sp where sp.purchase_id=p.id and sp.status='POSTED';
  update erp.material_purchase_headers set payment_status=case when v_paid>=v_proposed_payable-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end where id=p.id;
end;
$function$;

create or replace function erp.reverse_material_purchase_cost_correction(p_correction_id uuid,p_reason text)
returns void
language plpgsql
security definer
set search_path='erp','public'
as $function$
declare
  h erp.material_purchase_cost_corrections%rowtype;
  p erp.material_purchase_headers%rowtype;
  r record;
  m uuid;
  v_journal uuid;
  v_current_payable numeric(24,6);
  v_delta numeric(24,6);
  v_projected numeric(24,6);
  v_paid numeric(24,6);
begin
  perform erp.require_owner_admin();
  if nullif(trim(p_reason),'') is null then raise exception 'Alasan reversal koreksi harga pembelian wajib diisi'; end if;
  select * into h from erp.material_purchase_cost_corrections where id=p_correction_id for update;
  if h.id is null then raise exception 'Koreksi harga pembelian tidak ditemukan'; end if;
  if h.status='REVERSED' then return; end if;
  if h.status<>'POSTED' then raise exception 'Hanya koreksi harga pembelian POSTED yang dapat direverse'; end if;
  if h.post_seq is null then raise exception 'Urutan posting koreksi harga pembelian tidak ditemukan; reversal dibatalkan'; end if;
  select * into p from erp.material_purchase_headers where id=h.purchase_id for update;
  if p.id is null or p.status<>'POSTED' then raise exception 'Pembelian sumber harus masih POSTED'; end if;

  if exists(
    select 1
    from erp.material_purchase_cost_correction_items ci
    join erp.material_purchase_cost_correction_items ci2 on ci2.purchase_item_id=ci.purchase_item_id
    join erp.material_purchase_cost_corrections c2 on c2.id=ci2.correction_id
    where ci.correction_id=h.id and c2.status='POSTED' and c2.id<>h.id
      and c2.post_seq>h.post_seq
  ) then
    raise exception 'Ada koreksi harga yang lebih baru pada item pembelian ini. Reverse koreksi terbaru terlebih dahulu.';
  end if;

  select erp.material_purchase_payable_total(p.id) into v_current_payable;
  select coalesce(sum(delta_amount),0) into v_delta
  from erp.material_purchase_cost_correction_items where correction_id=h.id;
  v_projected:=v_current_payable-v_delta;
  select coalesce(sum(amount),0) into v_paid from erp.supplier_payments where purchase_id=p.id and status='POSTED';
  if v_paid>v_projected+0.01 then
    raise exception 'Reversal koreksi harga membuat pembayaran supplier melebihi hutang tersisa. Reverse/koreksi pembayaran supplier terlebih dahulu.';
  end if;

  for r in
    select ci.*,mpi.material_id
    from erp.material_purchase_cost_correction_items ci
    join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id
    where ci.correction_id=h.id order by ci.id
  loop
    if r.old_unit_cost_snapshot is null then
      raise exception 'Snapshot harga sebelum koreksi tidak ditemukan untuk item %; reversal dibatalkan',r.purchase_item_id;
    end if;
    update erp.material_stock_movements msm
    set input_unit_cost=r.old_unit_cost_snapshot
    where msm.movement_type='PURCHASE' and msm.qty_signed>0 and (
      (msm.source_type='MATERIAL_PURCHASE_ITEM' and msm.source_id=r.purchase_item_id)
      or (msm.source_type='MATERIAL_PURCHASE_ROLL' and msm.source_id in (select mr.id from erp.material_rolls mr where mr.purchase_item_id=r.purchase_item_id))
    );
  end loop;

  update erp.material_purchase_cost_corrections set status='REVERSED' where id=h.id;
  for m in
    select distinct mpi.material_id from erp.material_purchase_cost_correction_items ci
    join erp.material_purchase_items mpi on mpi.id=ci.purchase_item_id where ci.correction_id=h.id
  loop
    perform erp.recalculate_material_cost(m,p.physical_at);
  end loop;

  select id into v_journal from erp.journal_entries
  where source_type='MATERIAL_PURCHASE_COST_CORRECTION' and source_id=h.id and status='POSTED'
  order by posting_at desc,id desc limit 1;
  if abs(v_delta)>0.005 and v_journal is null then
    raise exception 'Jurnal koreksi harga pembelian tidak ditemukan; reversal dibatalkan agar inventory/AP tidak rusak';
  end if;
  if v_journal is not null then perform erp.reverse_journal(v_journal,p_reason); end if;

  select erp.material_purchase_payable_total(p.id) into v_projected;
  select coalesce(sum(amount),0) into v_paid from erp.supplier_payments where purchase_id=p.id and status='POSTED';
  update erp.material_purchase_headers set payment_status=case when v_paid>=v_projected-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end where id=p.id;

  insert into erp.audit_logs(entity_type,entity_id,action,changed_by,change_reason)
  values('material_purchase_cost_corrections',h.id,'REVERSE',erp.current_app_user_id(),p_reason);
end;
$function$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826162724','v261_material_cost_checkpoint_replay',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826162724 v261_material_cost_checkpoint_replay

-- BEGIN PLATFORM MIGRATION 20260826163218 v261_checkpoint_hotpath_indexes
create index if not exists idx_material_stock_movements_reversal_of on erp.material_stock_movements(reversal_of_id) where reversal_of_id is not null;
create index if not exists idx_fg_stock_movements_reversal_of on erp.fg_stock_movements(reversal_of_id) where reversal_of_id is not null;
create index if not exists idx_journal_entries_reversal_of on erp.journal_entries(reversal_of_id) where reversal_of_id is not null;

create or replace function erp.refresh_material_cost_checkpoint(p_material_id uuid,p_checkpoint_date date)
returns void
language plpgsql
security definer
set search_path='erp','public'
as $function$
declare
  v_stock numeric(18,6):=0;
  v_avg numeric(18,6):=0;
  v_last_physical timestamptz;
  v_last_system timestamptz;
  v_last_id uuid;
  v_has_active boolean;
  v_cutoff timestamptz;
begin
  perform erp.require_internal();
  if p_checkpoint_date is null then raise exception 'Checkpoint date is required'; end if;
  v_cutoff:=(p_checkpoint_date+1)::timestamptz;
  perform 1 from erp.materials where id=p_material_id for update;
  if not found then raise exception 'Material not found'; end if;

  select exists(
    select 1 from erp.material_stock_movements msm
    where msm.material_id=p_material_id
      and msm.physical_at<v_cutoff
      and msm.reversal_of_id is null
      and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=msm.id)
  ) into v_has_active;

  select h.stock_after,h.average_after,msm.physical_at,msm.system_created_at,msm.id
  into v_stock,v_avg,v_last_physical,v_last_system,v_last_id
  from erp.material_stock_movements msm
  join erp.material_cost_history h on h.movement_id=msm.id and h.material_id=p_material_id
  where msm.material_id=p_material_id
    and msm.physical_at<v_cutoff
    and msm.reversal_of_id is null
    and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=msm.id)
  order by msm.physical_at desc,msm.system_created_at desc,msm.id desc
  limit 1;

  if v_has_active and v_last_id is null then
    raise exception 'Cannot checkpoint material %: chronological cost history is incomplete before %',p_material_id,p_checkpoint_date;
  end if;
  if not v_has_active then
    v_stock:=0; v_avg:=0; v_last_physical:=null; v_last_system:=null; v_last_id:=null;
  end if;

  insert into erp.material_cost_checkpoints(material_id,checkpoint_date,stock_qty,moving_average_cost,last_physical_at,last_system_created_at,last_movement_id,checkpoint_created_at)
  values(p_material_id,p_checkpoint_date,coalesce(v_stock,0),coalesce(v_avg,0),v_last_physical,v_last_system,v_last_id,clock_timestamp())
  on conflict(material_id) do update
  set checkpoint_date=excluded.checkpoint_date,
      stock_qty=excluded.stock_qty,
      moving_average_cost=excluded.moving_average_cost,
      last_physical_at=excluded.last_physical_at,
      last_system_created_at=excluded.last_system_created_at,
      last_movement_id=excluded.last_movement_id,
      checkpoint_created_at=excluded.checkpoint_created_at;
end;
$function$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826163218','v261_checkpoint_hotpath_indexes',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826163218 v261_checkpoint_hotpath_indexes

-- BEGIN PLATFORM MIGRATION 20260826163732 v261_checkpoint_rls_policy
drop policy if exists system_no_direct_access on erp.material_cost_checkpoints;
create policy system_no_direct_access on erp.material_cost_checkpoints as restrictive for all to anon,authenticated using (false) with check (false);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826163732','v261_checkpoint_rls_policy',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826163732 v261_checkpoint_rls_policy

-- BEGIN PLATFORM MIGRATION 20260826165735 v261_use_checkpoint_for_dirty_material_recalc
create or replace function erp.recalculate_material_cost(p_material_id uuid)
returns void
language plpgsql
security definer
set search_path to 'erp','public'
as $function$
declare
  v_recalc_from timestamptz;
begin
  -- Operational callers normally arrive here immediately after inserting a new
  -- material movement/reversal. Use the earliest not-yet-recalculated economic
  -- point so a valid closed-period checkpoint can bound the replay. If nothing
  -- is marked dirty, preserve the historical explicit-rebuild behaviour.
  select min(x.recalc_from)
  into v_recalc_from
  from (
    select msm.physical_at as recalc_from
    from erp.material_stock_movements msm
    where msm.material_id=p_material_id
      and msm.is_cost_recalculated=false
      and msm.reversal_of_id is null

    union all

    select src.physical_at as recalc_from
    from erp.material_stock_movements rv
    join erp.material_stock_movements src on src.id=rv.reversal_of_id
    where rv.material_id=p_material_id
      and rv.is_cost_recalculated=false
      and rv.reversal_of_id is not null
  ) x;

  if v_recalc_from is null then
    perform erp._recalculate_material_cost_core(p_material_id,null,false);
  else
    perform erp._recalculate_material_cost_core(p_material_id,v_recalc_from,true);

    -- Reversal rows are audit events excluded from active cost-history replay;
    -- mark them handled only after the full material recalc succeeds.
    update erp.material_stock_movements
    set is_cost_recalculated=true
    where material_id=p_material_id
      and is_cost_recalculated=false
      and reversal_of_id is not null;
  end if;
end;
$function$;

comment on function erp.recalculate_material_cost(uuid) is
'Operational material recost entrypoint. Uses the earliest dirty movement/reversal as recalc_from so closed-period checkpoints bound normal replay; falls back to a full rebuild when no dirty marker exists.';
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260826165735','v261_use_checkpoint_for_dirty_material_recalc',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260826165735 v261_use_checkpoint_for_dirty_material_recalc

-- BEGIN PLATFORM MIGRATION 20260827142734 lock_qc_posting_until_upstream_ready
revoke execute on function erp.post_qc(uuid) from authenticated;
do $$
begin
  if to_regprocedure('erp.reverse_qc(uuid,text)') is not null then
    execute 'revoke execute on function erp.reverse_qc(uuid,text) from authenticated';
  end if;
end $$;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260827142734','lock_qc_posting_until_upstream_ready',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260827142734 lock_qc_posting_until_upstream_ready

-- BEGIN PLATFORM MIGRATION 20260827143801 restore_qc_permissions_after_frontend_disconnect
grant execute on function erp.post_qc(uuid) to authenticated;
grant execute on function erp.reverse_qc(uuid, text) to authenticated;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260827143801','restore_qc_permissions_after_frontend_disconnect',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260827143801 restore_qc_permissions_after_frontend_disconnect

-- BEGIN PLATFORM MIGRATION 20260828070429 erp_v262_crud_fabric_benchmark
-- ERP Garment v2.6.2
-- Safe CRUD foundation, fabric benchmark master, material warehouse read models,
-- and reversible pre-sewing cutting corrections.
--
-- Deployment contract:
--   1. Apply to ERP Enteng and run the companion stress test.
--   2. Apply this exact file to ERP-Garment only after ERP Enteng passes.
--   3. Never edit posted operational or financial rows directly.

set lock_timeout = '10s';
set statement_timeout = '180s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_2', 0));

do $$
begin
  if not exists (
    select 1 from erp.schema_migrations where version = 'v2.6.0'
  ) or to_regclass('erp.material_purchase_cost_corrections') is null
    or not exists (
      select 1 from information_schema.columns
      where table_schema = 'erp'
        and table_name = 'material_purchase_cost_corrections'
        and column_name = 'post_seq'
    )
    or to_regprocedure('erp.guard_cutting_group_delete_after_use()') is null
    or to_regprocedure('erp.run_v260_integrity_checks()') is null
  then
    raise exception 'ERP Garment v2.6.0 plus developer-clean v2.6.1 capabilities are required before v2.6.2';
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. Optimistic locking and idempotency primitives
-- ---------------------------------------------------------------------------

create or replace function erp.bump_row_version()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
begin
  new.row_version := old.row_version + 1;
  return new;
end;
$$;

do $$
declare
  v_table text;
begin
  foreach v_table in array array[
    'app_users', 'materials', 'material_purchase_headers',
    'cutting_batches', 'cutting_groups'
  ] loop
    execute format(
      'alter table erp.%I add column if not exists row_version bigint not null default 1 check (row_version > 0)',
      v_table
    );
    execute format('drop trigger if exists trg_00_bump_row_version on erp.%I', v_table);
    execute format(
      'create trigger trg_00_bump_row_version before update on erp.%I for each row execute function erp.bump_row_version()',
      v_table
    );
  end loop;
end;
$$;

create table erp.idempotency_requests (
  actor_key text not null,
  operation_name text not null,
  client_request_id uuid not null,
  request_hash text not null,
  status varchar(20) not null default 'IN_PROGRESS'
    check (status in ('IN_PROGRESS', 'COMPLETED')),
  response_payload jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '30 days'),
  primary key (actor_key, operation_name, client_request_id),
  check ((status = 'IN_PROGRESS' and response_payload is null)
      or (status = 'COMPLETED' and response_payload is not null))
);

alter table erp.idempotency_requests enable row level security;
revoke all on erp.idempotency_requests from public, anon, authenticated;

create index idx_idempotency_requests_expiry
  on erp.idempotency_requests(expires_at);

create or replace function erp._idempotency_actor_key()
returns text
language sql
stable
security definer
set search_path = erp, public, auth, pg_temp
as $$
  select coalesce(
    erp.current_app_user_id()::text,
    auth.uid()::text,
    'database:' || session_user
  )
$$;

create or replace function erp._request_hash(p_payload jsonb)
returns text
language sql
immutable
security definer
set search_path = erp, public, extensions, pg_temp
as $$
  select encode(extensions.digest(convert_to(coalesce(p_payload, '{}'::jsonb)::text, 'UTF8'), 'sha256'), 'hex')
$$;

create or replace function erp._idempotency_begin(
  p_operation_name text,
  p_client_request_id uuid,
  p_request_hash text
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, pg_temp
as $$
declare
  v_actor text := erp._idempotency_actor_key();
  v_row erp.idempotency_requests%rowtype;
begin
  if p_client_request_id is null then
    raise exception 'client_request_id is required';
  end if;
  if coalesce(btrim(p_operation_name), '') = '' then
    raise exception 'operation_name is required';
  end if;

  insert into erp.idempotency_requests(
    actor_key, operation_name, client_request_id, request_hash
  ) values (
    v_actor, p_operation_name, p_client_request_id, p_request_hash
  )
  on conflict do nothing;

  select * into v_row
  from erp.idempotency_requests
  where actor_key = v_actor
    and operation_name = p_operation_name
    and client_request_id = p_client_request_id
  for update;

  if v_row.request_hash <> p_request_hash then
    raise exception 'client_request_id was already used with a different payload';
  end if;
  if v_row.status = 'COMPLETED' then
    return v_row.response_payload;
  end if;
  return null;
end;
$$;

create or replace function erp._idempotency_complete(
  p_operation_name text,
  p_client_request_id uuid,
  p_response jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, pg_temp
as $$
declare
  v_actor text := erp._idempotency_actor_key();
begin
  update erp.idempotency_requests
  set status = 'COMPLETED', response_payload = p_response, updated_at = now()
  where actor_key = v_actor
    and operation_name = p_operation_name
    and client_request_id = p_client_request_id
    and status = 'IN_PROGRESS';
  if not found then
    raise exception 'Idempotency request is missing or already completed';
  end if;
  return p_response;
end;
$$;

revoke all on function erp._idempotency_actor_key() from public;
revoke all on function erp._request_hash(jsonb) from public;
revoke all on function erp._idempotency_begin(text, uuid, text) from public;
revoke all on function erp._idempotency_complete(text, uuid, jsonb) from public;

-- ---------------------------------------------------------------------------
-- 2. Fabric profile and effective-dated benchmark price
-- ---------------------------------------------------------------------------

create table erp.fabric_master_profiles (
  material_id uuid primary key references erp.materials(id) on delete restrict,
  fabric_category varchar(100),
  composition text,
  construction text,
  color_name varchar(100),
  width_cm numeric(12,3) check (width_cm is null or width_cm > 0),
  gsm numeric(12,3) check (gsm is null or gsm > 0),
  minimum_stock_qty numeric(18,6) not null default 0 check (minimum_stock_qty >= 0),
  preferred_supplier_id uuid references erp.suppliers(id) on delete restrict,
  notes text,
  row_version bigint not null default 1 check (row_version > 0),
  created_by uuid references erp.app_users(id) on delete set null,
  updated_by uuid references erp.app_users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table erp.fabric_benchmark_price_versions (
  id uuid primary key default gen_random_uuid(),
  material_id uuid not null references erp.materials(id) on delete restrict,
  benchmark_price_per_base_uom numeric(18,6) not null
    check (benchmark_price_per_base_uom > 0),
  base_uom_code_snapshot varchar(20) not null,
  effective_from timestamptz not null,
  effective_to timestamptz,
  change_reason text not null check (btrim(change_reason) <> ''),
  created_by uuid references erp.app_users(id) on delete set null,
  created_at timestamptz not null default now(),
  check (effective_to is null or effective_to > effective_from)
);

create unique index uq_fabric_benchmark_open_version
  on erp.fabric_benchmark_price_versions(material_id)
  where effective_to is null;
create index idx_fabric_benchmark_lookup
  on erp.fabric_benchmark_price_versions(material_id, effective_from desc);
create index idx_fabric_profile_supplier
  on erp.fabric_master_profiles(preferred_supplier_id)
  where preferred_supplier_id is not null;

alter table erp.fabric_master_profiles enable row level security;
alter table erp.fabric_benchmark_price_versions enable row level security;

create policy fabric_profile_internal_read
on erp.fabric_master_profiles for select to authenticated
using ((select erp.current_app_role()) = any (array['OWNER','ADMIN','STAFF']));

create policy fabric_benchmark_internal_read
on erp.fabric_benchmark_price_versions for select to authenticated
using ((select erp.current_app_role()) = any (array['OWNER','ADMIN','STAFF']));

grant select on erp.fabric_master_profiles to authenticated;
grant select on erp.fabric_benchmark_price_versions to authenticated;
revoke insert, update, delete on erp.fabric_master_profiles from public, anon, authenticated;
revoke insert, update, delete on erp.fabric_benchmark_price_versions from public, anon, authenticated;

create or replace function erp.validate_fabric_profile()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
declare
  v_type text;
begin
  select material_type into v_type from erp.materials where id = new.material_id;
  if v_type is distinct from 'FABRIC' then
    raise exception 'Fabric profile can only be attached to a FABRIC material';
  end if;
  return new;
end;
$$;

create or replace function erp.validate_fabric_benchmark_version()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
declare
  v_type text;
  v_uom text;
begin
  if tg_op = 'DELETE' then
    raise exception 'Benchmark price history cannot be deleted; add a new effective version';
  end if;

  select material_type, unit_code into v_type, v_uom
  from erp.materials where id = new.material_id;
  if v_type is distinct from 'FABRIC' then
    raise exception 'Benchmark price can only be defined for a FABRIC material';
  end if;
  new.base_uom_code_snapshot := v_uom;

  if tg_op = 'UPDATE' and (
       new.material_id is distinct from old.material_id
    or new.benchmark_price_per_base_uom is distinct from old.benchmark_price_per_base_uom
    or new.effective_from is distinct from old.effective_from
    or new.change_reason is distinct from old.change_reason
    or new.created_by is distinct from old.created_by
    or new.created_at is distinct from old.created_at
  ) then
    raise exception 'Benchmark versions are immutable except for closing effective_to';
  end if;

  if exists (
    select 1
    from erp.fabric_benchmark_price_versions x
    where x.material_id = new.material_id
      and x.id <> coalesce(new.id, gen_random_uuid())
      and tstzrange(x.effective_from, x.effective_to, '[)')
          && tstzrange(new.effective_from, new.effective_to, '[)')
  ) then
    raise exception 'Fabric benchmark effective periods cannot overlap';
  end if;
  return new;
end;
$$;

create trigger trg_validate_fabric_profile
before insert or update on erp.fabric_master_profiles
for each row execute function erp.validate_fabric_profile();

create trigger trg_00_bump_fabric_profile_version
before update on erp.fabric_master_profiles
for each row execute function erp.bump_row_version();

create trigger trg_touch_fabric_profile
before update on erp.fabric_master_profiles
for each row execute function erp.touch_updated_at();

create trigger trg_validate_fabric_benchmark_version
before insert or update or delete on erp.fabric_benchmark_price_versions
for each row execute function erp.validate_fabric_benchmark_version();

create trigger trg_audit_fabric_profile
after insert or update or delete on erp.fabric_master_profiles
for each row execute function erp.audit_row_change();

create trigger trg_audit_fabric_benchmark
after insert or update or delete on erp.fabric_benchmark_price_versions
for each row execute function erp.audit_row_change();

create or replace function erp.save_fabric_master_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_id uuid := nullif(p_payload->>'id', '')::uuid;
  v_material erp.materials%rowtype;
  v_profile jsonb := coalesce(p_payload->'profile', '{}'::jsonb);
  v_reason text := nullif(btrim(p_payload->>'change_reason'), '');
  v_is_active boolean := coalesce((p_payload->>'is_active')::boolean, true);
begin
  perform erp.require_owner_admin();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if coalesce(btrim(p_payload->>'material_sku'), '') = '' then raise exception 'material_sku is required'; end if;
  if coalesce(btrim(p_payload->>'material_name'), '') = '' then raise exception 'material_name is required'; end if;
  if coalesce(btrim(p_payload->>'unit_code'), '') = '' then raise exception 'unit_code is required'; end if;

  v_hash := erp._request_hash(jsonb_build_object('payload', p_payload, 'expected_version', p_expected_version));
  v_cached := erp._idempotency_begin('save_fabric_master_v2', p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  if v_id is null then
    if p_expected_version is not null then
      raise exception 'expected_version must be null when creating a fabric';
    end if;
    insert into erp.materials(
      material_sku, material_name, material_type, unit_code, is_active
    ) values (
      btrim(p_payload->>'material_sku'), btrim(p_payload->>'material_name'),
      'FABRIC', upper(btrim(p_payload->>'unit_code')), v_is_active
    ) returning * into v_material;
    v_id := v_material.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required when updating a fabric'; end if;
    select * into v_material from erp.materials where id = v_id for update;
    if v_material.id is null then raise exception 'Fabric material not found'; end if;
    if v_material.material_type <> 'FABRIC' then raise exception 'Material is not FABRIC'; end if;
    if v_material.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_material.row_version;
    end if;
    if not v_is_active and abs(v_material.cached_stock_qty) > 0.000001 then
      raise exception 'Fabric with non-zero stock cannot be deactivated';
    end if;
    update erp.materials
    set material_sku = btrim(p_payload->>'material_sku'),
        material_name = btrim(p_payload->>'material_name'),
        unit_code = upper(btrim(p_payload->>'unit_code')),
        is_active = v_is_active,
        updated_at = now()
    where id = v_id
    returning * into v_material;
  end if;

  insert into erp.fabric_master_profiles(
    material_id, fabric_category, composition, construction, color_name,
    width_cm, gsm, minimum_stock_qty, preferred_supplier_id, notes,
    created_by, updated_by
  ) values (
    v_id,
    nullif(btrim(v_profile->>'fabric_category'), ''),
    nullif(btrim(v_profile->>'composition'), ''),
    nullif(btrim(v_profile->>'construction'), ''),
    nullif(btrim(v_profile->>'color_name'), ''),
    nullif(v_profile->>'width_cm', '')::numeric,
    nullif(v_profile->>'gsm', '')::numeric,
    coalesce(nullif(v_profile->>'minimum_stock_qty', '')::numeric, 0),
    nullif(v_profile->>'preferred_supplier_id', '')::uuid,
    nullif(btrim(v_profile->>'notes'), ''),
    erp.current_app_user_id(), erp.current_app_user_id()
  )
  on conflict (material_id) do update
  set fabric_category = excluded.fabric_category,
      composition = excluded.composition,
      construction = excluded.construction,
      color_name = excluded.color_name,
      width_cm = excluded.width_cm,
      gsm = excluded.gsm,
      minimum_stock_qty = excluded.minimum_stock_qty,
      preferred_supplier_id = excluded.preferred_supplier_id,
      notes = excluded.notes,
      updated_by = erp.current_app_user_id(),
      updated_at = now();

  select * into v_material from erp.materials where id = v_id;
  v_response := jsonb_build_object(
    'material_id', v_id,
    'row_version', v_material.row_version,
    'material_sku', v_material.material_sku,
    'status', case when v_material.is_active then 'ACTIVE' else 'INACTIVE' end
  );
  return erp._idempotency_complete('save_fabric_master_v2', p_client_request_id, v_response);
end;
$$;

create or replace function erp.set_fabric_benchmark_price_v2(
  p_material_id uuid,
  p_benchmark_price numeric,
  p_effective_from timestamptz,
  p_change_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_material erp.materials%rowtype;
  v_open erp.fabric_benchmark_price_versions%rowtype;
  v_version_id uuid;
begin
  perform erp.require_owner_admin();
  if p_material_id is null or p_benchmark_price is null or p_benchmark_price <= 0 then
    raise exception 'Material and positive benchmark price are required';
  end if;
  if p_effective_from is null then raise exception 'effective_from is required'; end if;
  if coalesce(btrim(p_change_reason), '') = '' then raise exception 'change_reason is required'; end if;
  if p_expected_version is null then raise exception 'expected_version is required'; end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'material_id', p_material_id, 'benchmark_price', p_benchmark_price,
    'effective_from', p_effective_from, 'change_reason', p_change_reason,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin('set_fabric_benchmark_price_v2', p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  perform pg_advisory_xact_lock(hashtextextended('fabric-benchmark:' || p_material_id::text, 0));
  select * into v_material from erp.materials where id = p_material_id for update;
  if v_material.id is null or v_material.material_type <> 'FABRIC' then
    raise exception 'FABRIC material not found';
  end if;
  if v_material.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_material.row_version;
  end if;

  select * into v_open
  from erp.fabric_benchmark_price_versions
  where material_id = p_material_id and effective_to is null
  for update;

  if v_open.id is not null then
    if p_effective_from <= v_open.effective_from then
      raise exception 'New benchmark effective_from must be later than the current version';
    end if;
    update erp.fabric_benchmark_price_versions
    set effective_to = p_effective_from
    where id = v_open.id;
  elsif exists (
    select 1 from erp.fabric_benchmark_price_versions
    where material_id = p_material_id and effective_from >= p_effective_from
  ) then
    raise exception 'Backdated benchmark would overlap existing history';
  end if;

  perform set_config('app.change_reason', btrim(p_change_reason), true);
  insert into erp.fabric_benchmark_price_versions(
    material_id, benchmark_price_per_base_uom, base_uom_code_snapshot,
    effective_from, change_reason, created_by
  ) values (
    p_material_id, p_benchmark_price, v_material.unit_code,
    p_effective_from, btrim(p_change_reason), erp.current_app_user_id()
  ) returning id into v_version_id;

  update erp.materials set updated_at = now() where id = p_material_id
  returning * into v_material;

  v_response := jsonb_build_object(
    'material_id', p_material_id,
    'benchmark_version_id', v_version_id,
    'benchmark_price', p_benchmark_price,
    'effective_from', p_effective_from,
    'row_version', v_material.row_version
  );
  return erp._idempotency_complete('set_fabric_benchmark_price_v2', p_client_request_id, v_response);
end;
$$;

revoke all on function erp.save_fabric_master_v2(jsonb, uuid, bigint) from public;
revoke all on function erp.set_fabric_benchmark_price_v2(uuid, numeric, timestamptz, text, uuid, bigint) from public;
grant execute on function erp.save_fabric_master_v2(jsonb, uuid, bigint) to authenticated, service_role;
grant execute on function erp.set_fabric_benchmark_price_v2(uuid, numeric, timestamptz, text, uuid, bigint) to authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 3. App-user hierarchy: ADMIN cannot create, mutate, or deactivate OWNER/ADMIN
-- ---------------------------------------------------------------------------

drop policy if exists internal_app_users on erp.app_users;
drop policy if exists internal_app_users_insert on erp.app_users;
drop policy if exists internal_app_users_update on erp.app_users;
drop policy if exists internal_app_users_delete on erp.app_users;

revoke insert, update, delete on erp.app_users from public, anon, authenticated;

create or replace function erp.save_app_user_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_id uuid := nullif(p_payload->>'id', '')::uuid;
  v_target erp.app_users%rowtype;
  v_actor_role text := erp.current_app_role();
  v_new_role text := upper(coalesce(nullif(btrim(p_payload->>'role'), ''), 'STAFF'));
  v_new_active boolean := coalesce((p_payload->>'is_active')::boolean, true);
  v_new_auth_user_id uuid;
  v_reason text := nullif(btrim(p_payload->>'change_reason'), '');
begin
  perform erp.require_owner_admin();
  if v_actor_role is null and session_user in ('postgres', 'supabase_admin') then
    v_actor_role := 'OWNER';
  end if;
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if coalesce(btrim(p_payload->>'full_name'), '') = '' then raise exception 'full_name is required'; end if;
  if v_new_role not in ('OWNER','ADMIN','STAFF','CUSTOMER') then raise exception 'Invalid app role'; end if;

  v_hash := erp._request_hash(jsonb_build_object('payload', p_payload, 'expected_version', p_expected_version));
  v_cached := erp._idempotency_begin('save_app_user_v2', p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  if v_id is null then
    if p_expected_version is not null then raise exception 'expected_version must be null when creating a user'; end if;
    if v_actor_role = 'ADMIN' and v_new_role in ('OWNER','ADMIN') then
      raise exception 'ADMIN cannot create OWNER or ADMIN';
    end if;
    v_new_auth_user_id := nullif(p_payload->>'auth_user_id', '')::uuid;
    insert into erp.app_users(auth_user_id, full_name, role, is_active)
    values (v_new_auth_user_id, btrim(p_payload->>'full_name'), v_new_role, v_new_active)
    returning * into v_target;
  else
    if p_expected_version is null then raise exception 'expected_version is required when updating a user'; end if;
    select * into v_target from erp.app_users where id = v_id for update;
    if v_target.id is null then raise exception 'App user not found'; end if;
    if v_target.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_target.row_version;
    end if;
    if v_actor_role = 'ADMIN' and (v_target.role in ('OWNER','ADMIN') or v_new_role in ('OWNER','ADMIN')) then
      raise exception 'ADMIN cannot mutate OWNER or ADMIN';
    end if;
    if v_target.role = 'OWNER' and v_target.is_active
       and (v_new_role <> 'OWNER' or not v_new_active)
       and not exists (
         select 1 from erp.app_users
         where id <> v_target.id and role = 'OWNER' and is_active
       ) then
      raise exception 'The last active OWNER cannot be demoted or deactivated';
    end if;
    v_new_auth_user_id := case
      when p_payload ? 'auth_user_id' then nullif(p_payload->>'auth_user_id', '')::uuid
      else v_target.auth_user_id
    end;
    update erp.app_users
    set auth_user_id = v_new_auth_user_id,
        full_name = btrim(p_payload->>'full_name'),
        role = v_new_role,
        is_active = v_new_active,
        updated_at = now()
    where id = v_id
    returning * into v_target;
  end if;

  v_response := jsonb_build_object(
    'app_user_id', v_target.id,
    'role', v_target.role,
    'is_active', v_target.is_active,
    'row_version', v_target.row_version
  );
  return erp._idempotency_complete('save_app_user_v2', p_client_request_id, v_response);
end;
$$;

revoke all on function erp.save_app_user_v2(jsonb, uuid, bigint) from public;
grant execute on function erp.save_app_user_v2(jsonb, uuid, bigint) to authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 4. Aggregate material-purchase draft, benchmark snapshot, and final invoice
-- ---------------------------------------------------------------------------

alter table erp.material_purchase_items
  add column price_state varchar(20) not null default 'ESTIMATED'
    check (price_state in ('ESTIMATED','FINAL')),
  add column price_source varchar(30) not null default 'MANUAL_ESTIMATE'
    check (price_source in ('BENCHMARK','SUPPLIER_QUOTE','SUPPLIER_INVOICE','MANUAL_ESTIMATE','MIGRATION')),
  add column benchmark_price_version_id uuid
    references erp.fabric_benchmark_price_versions(id) on delete restrict,
  add column benchmark_unit_price_snapshot numeric(18,6)
    check (benchmark_unit_price_snapshot is null or benchmark_unit_price_snapshot > 0),
  add column supplier_final_unit_price_snapshot numeric(18,6)
    check (supplier_final_unit_price_snapshot is null or supplier_final_unit_price_snapshot >= 0),
  add column price_finalized_at timestamptz,
  add column price_finalized_by uuid references erp.app_users(id) on delete set null;

alter table erp.material_purchase_items
  add constraint material_purchase_item_benchmark_provenance
  check (
    price_source <> 'BENCHMARK'
    or (benchmark_price_version_id is not null and benchmark_unit_price_snapshot is not null)
  ),
  add constraint material_purchase_item_final_provenance
  check (
    price_state <> 'FINAL'
    or price_source = 'SUPPLIER_INVOICE'
    or price_source = 'MIGRATION'
  );

create index idx_material_purchase_headers_supplier_date
  on erp.material_purchase_headers(supplier_id, physical_at desc)
  where supplier_id is not null;
create index idx_material_purchase_headers_location_date
  on erp.material_purchase_headers(location_id, physical_at desc)
  where location_id is not null;
create index idx_material_purchase_items_material
  on erp.material_purchase_items(material_id, purchase_id);
create index idx_material_purchase_items_benchmark
  on erp.material_purchase_items(benchmark_price_version_id)
  where benchmark_price_version_id is not null;
create index idx_material_rolls_purchase_item
  on erp.material_rolls(purchase_item_id)
  where purchase_item_id is not null;
create index idx_material_rolls_supplier
  on erp.material_rolls(supplier_id)
  where supplier_id is not null;
create index idx_material_stock_movements_location_time
  on erp.material_stock_movements(location_id, physical_at, system_created_at, id);
create index idx_material_stock_movements_source
  on erp.material_stock_movements(source_type, source_id)
  where source_id is not null;
create index idx_supplier_payments_purchase_posted
  on erp.supplier_payments(purchase_id, payment_date)
  where status = 'POSTED';

create or replace function erp.save_material_purchase_draft_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_purchase_id uuid := nullif(p_payload->>'id', '')::uuid;
  v_header erp.material_purchase_headers%rowtype;
  v_line jsonb;
  v_roll jsonb;
  v_material erp.materials%rowtype;
  v_item_id uuid;
  v_roll_id uuid;
  v_qty numeric;
  v_unit_price numeric;
  v_effective_unit_price numeric;
  v_benchmark_id uuid;
  v_benchmark_price numeric;
  v_price_state text;
  v_price_source text;
  v_roll_total numeric;
  v_roll_count integer;
  v_reason text := nullif(btrim(p_payload->>'change_reason'), '');
  v_physical_at timestamptz := nullif(p_payload->>'physical_at', '')::timestamptz;
begin
  perform erp.require_internal();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if coalesce(btrim(p_payload->>'purchase_number'), '') = '' then raise exception 'purchase_number is required'; end if;
  if v_physical_at is null then raise exception 'physical_at is required'; end if;
  if v_physical_at > clock_timestamp() + interval '5 minutes' then raise exception 'physical_at cannot be in the future'; end if;
  if p_payload ? 'lines' and jsonb_typeof(p_payload->'lines') <> 'array' then raise exception 'lines must be an array'; end if;

  v_hash := erp._request_hash(jsonb_build_object('payload', p_payload, 'expected_version', p_expected_version));
  v_cached := erp._idempotency_begin('save_material_purchase_draft_v2', p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  if v_purchase_id is null then
    if p_expected_version is not null then raise exception 'expected_version must be null when creating a purchase'; end if;
    insert into erp.material_purchase_headers(
      purchase_number, supplier_id, physical_at, status, notes, created_by,
      location_id, supplier_invoice_number, due_date
    ) values (
      btrim(p_payload->>'purchase_number'),
      nullif(p_payload->>'supplier_id', '')::uuid,
      v_physical_at, 'DRAFT', nullif(btrim(p_payload->>'notes'), ''),
      erp.current_app_user_id(), nullif(p_payload->>'location_id', '')::uuid,
      nullif(btrim(p_payload->>'supplier_invoice_number'), ''),
      nullif(p_payload->>'due_date', '')::date
    ) returning * into v_header;
    v_purchase_id := v_header.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required when updating a purchase'; end if;
    select * into v_header
    from erp.material_purchase_headers where id = v_purchase_id for update;
    if v_header.id is null then raise exception 'Material purchase not found'; end if;
    if v_header.status <> 'DRAFT' then raise exception 'Only DRAFT material purchases can be saved'; end if;
    if v_header.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_header.row_version;
    end if;
    update erp.material_purchase_headers
    set purchase_number = btrim(p_payload->>'purchase_number'),
        supplier_id = nullif(p_payload->>'supplier_id', '')::uuid,
        physical_at = v_physical_at,
        notes = nullif(btrim(p_payload->>'notes'), ''),
        location_id = nullif(p_payload->>'location_id', '')::uuid,
        supplier_invoice_number = nullif(btrim(p_payload->>'supplier_invoice_number'), ''),
        due_date = nullif(p_payload->>'due_date', '')::date,
        updated_at = now()
    where id = v_purchase_id
    returning * into v_header;
  end if;

  delete from erp.material_rolls r
  using erp.material_purchase_items i
  where r.purchase_item_id = i.id and i.purchase_id = v_purchase_id;
  delete from erp.material_purchase_items where purchase_id = v_purchase_id;

  for v_line in
    select value from jsonb_array_elements(coalesce(p_payload->'lines', '[]'::jsonb))
  loop
    if coalesce(nullif(v_line->>'material_id', ''), '') = '' then raise exception 'Each purchase line requires material_id'; end if;
    select * into v_material
    from erp.materials where id = (v_line->>'material_id')::uuid;
    if v_material.id is null then raise exception 'Purchase material not found'; end if;
    if not v_material.is_active then raise exception 'Inactive material % cannot be purchased', v_material.material_sku; end if;

    v_qty := coalesce(
      nullif(v_line->>'qty', '')::numeric,
      nullif(v_line->>'purchase_qty_entered', '')::numeric
        * coalesce(nullif(v_line->>'purchase_uom_factor_snapshot', '')::numeric, 1)
    );
    if v_qty is null or v_qty <= 0 then raise exception 'Purchase quantity must be positive'; end if;

    v_benchmark_id := null;
    v_benchmark_price := null;
    v_unit_price := nullif(v_line->>'unit_price', '')::numeric;
    v_price_source := upper(coalesce(nullif(btrim(v_line->>'price_source'), ''), 'MANUAL_ESTIMATE'));
    v_price_state := upper(coalesce(nullif(btrim(v_line->>'price_state'), ''),
      case when v_price_source = 'SUPPLIER_INVOICE' then 'FINAL' else 'ESTIMATED' end));

    if v_unit_price is null and v_material.material_type = 'FABRIC' then
      select id, benchmark_price_per_base_uom
      into v_benchmark_id, v_benchmark_price
      from erp.fabric_benchmark_price_versions
      where material_id = v_material.id
        and effective_from <= v_physical_at
        and (effective_to is null or v_physical_at < effective_to)
      order by effective_from desc
      limit 1;
      if v_benchmark_id is null then
        raise exception 'Fabric % has no benchmark price effective at receipt time', v_material.material_sku;
      end if;
      v_unit_price := v_benchmark_price;
      v_price_source := 'BENCHMARK';
      v_price_state := 'ESTIMATED';
    elsif v_price_source = 'BENCHMARK' then
      select id, benchmark_price_per_base_uom
      into v_benchmark_id, v_benchmark_price
      from erp.fabric_benchmark_price_versions
      where material_id = v_material.id
        and effective_from <= v_physical_at
        and (effective_to is null or v_physical_at < effective_to)
      order by effective_from desc
      limit 1;
      if v_benchmark_id is null then raise exception 'Benchmark source has no effective benchmark version'; end if;
      if abs(v_unit_price - v_benchmark_price) > 0.000001 then
        raise exception 'Benchmark source price must match the effective benchmark snapshot';
      end if;
    end if;

    if v_price_state not in ('ESTIMATED','FINAL') then raise exception 'Invalid price_state'; end if;
    if v_price_source not in ('BENCHMARK','SUPPLIER_QUOTE','SUPPLIER_INVOICE','MANUAL_ESTIMATE','MIGRATION') then
      raise exception 'Invalid price_source';
    end if;
    if v_price_state = 'FINAL' and v_price_source not in ('SUPPLIER_INVOICE','MIGRATION') then
      raise exception 'FINAL purchase price must come from SUPPLIER_INVOICE or MIGRATION';
    end if;
    if v_unit_price is null and v_line->>'purchase_price_per_uom_snapshot' is null then
      raise exception 'unit_price or purchase_price_per_uom_snapshot is required';
    end if;
    if v_unit_price is not null and v_unit_price < 0 then raise exception 'unit_price cannot be negative'; end if;

    v_item_id := coalesce(nullif(v_line->>'id', '')::uuid, gen_random_uuid());
    insert into erp.material_purchase_items(
      id, purchase_id, material_id, qty, unit_price, lot_number, notes,
      purchase_qty_entered, purchase_uom_code, purchase_uom_factor_snapshot,
      purchase_price_per_uom_snapshot, price_state, price_source,
      benchmark_price_version_id, benchmark_unit_price_snapshot,
      supplier_final_unit_price_snapshot, price_finalized_at, price_finalized_by
    ) values (
      v_item_id, v_purchase_id, v_material.id, v_qty, v_unit_price,
      nullif(btrim(v_line->>'lot_number'), ''), nullif(btrim(v_line->>'notes'), ''),
      nullif(v_line->>'purchase_qty_entered', '')::numeric,
      nullif(upper(btrim(v_line->>'purchase_uom_code')), ''),
      nullif(v_line->>'purchase_uom_factor_snapshot', '')::numeric,
      nullif(v_line->>'purchase_price_per_uom_snapshot', '')::numeric,
      v_price_state, v_price_source, v_benchmark_id,
      v_benchmark_price,
      case when v_price_state = 'FINAL' then v_unit_price else null end,
      case when v_price_state = 'FINAL' then now() else null end,
      case when v_price_state = 'FINAL' then erp.current_app_user_id() else null end
    ) returning unit_price into v_effective_unit_price;

    if v_price_state = 'FINAL' and v_unit_price is null then
      update erp.material_purchase_items
      set supplier_final_unit_price_snapshot = v_effective_unit_price
      where id = v_item_id;
    end if;

    v_roll_total := 0;
    v_roll_count := 0;
    if v_line ? 'rolls' and jsonb_typeof(v_line->'rolls') <> 'array' then raise exception 'rolls must be an array'; end if;
    for v_roll in
      select value from jsonb_array_elements(coalesce(v_line->'rolls', '[]'::jsonb))
    loop
      if coalesce(btrim(v_roll->>'roll_number'), '') = '' then raise exception 'roll_number is required'; end if;
      if nullif(v_roll->>'qty', '')::numeric is null or nullif(v_roll->>'qty', '')::numeric <= 0 then
        raise exception 'Roll quantity must be positive';
      end if;
      v_roll_id := coalesce(nullif(v_roll->>'id', '')::uuid, gen_random_uuid());
      insert into erp.material_rolls(
        id, material_id, purchase_item_id, supplier_id, roll_number,
        original_qty, cached_qty, status, received_at, notes
      ) values (
        v_roll_id, v_material.id, v_item_id, v_header.supplier_id,
        btrim(v_roll->>'roll_number'), (v_roll->>'qty')::numeric,
        (v_roll->>'qty')::numeric, 'AVAILABLE', v_physical_at,
        nullif(btrim(v_roll->>'notes'), '')
      );
      v_roll_total := v_roll_total + (v_roll->>'qty')::numeric;
      v_roll_count := v_roll_count + 1;
    end loop;
    if v_roll_count > 0 and abs(v_roll_total - v_qty) > 0.000001 then
      raise exception 'Line quantity % does not equal roll total %', v_qty, v_roll_total;
    end if;
  end loop;

  select * into v_header from erp.material_purchase_headers where id = v_purchase_id;
  v_response := jsonb_build_object(
    'purchase_id', v_purchase_id,
    'status', v_header.status,
    'row_version', v_header.row_version,
    'lines', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', i.id, 'material_id', i.material_id, 'qty', i.qty,
        'unit_price', i.unit_price, 'price_state', i.price_state,
        'price_source', i.price_source
      ) order by i.id)
      from erp.material_purchase_items i where i.purchase_id = v_purchase_id
    ), '[]'::jsonb)
  );
  return erp._idempotency_complete('save_material_purchase_draft_v2', p_client_request_id, v_response);
end;
$$;

create or replace function erp.post_material_purchase_v2(
  p_purchase_id uuid,
  p_client_request_id uuid,
  p_expected_version bigint,
  p_change_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_header erp.material_purchase_headers%rowtype;
begin
  perform erp.require_internal();
  if coalesce(btrim(p_change_reason), '') = '' then raise exception 'change_reason is required'; end if;
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  v_hash := erp._request_hash(jsonb_build_object(
    'purchase_id', p_purchase_id, 'expected_version', p_expected_version,
    'change_reason', p_change_reason
  ));
  v_cached := erp._idempotency_begin('post_material_purchase_v2', p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_header
  from erp.material_purchase_headers where id = p_purchase_id for update;
  if v_header.id is null or v_header.status <> 'DRAFT' then raise exception 'Purchase must be DRAFT'; end if;
  if v_header.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_header.row_version;
  end if;
  if v_header.supplier_id is null then raise exception 'supplier_id is required before posting'; end if;
  if v_header.location_id is null then raise exception 'location_id is required before posting'; end if;
  if not exists (select 1 from erp.material_purchase_items where purchase_id = p_purchase_id) then
    raise exception 'At least one purchase line is required before posting';
  end if;

  perform set_config('app.change_reason', btrim(p_change_reason), true);
  perform erp.post_material_purchase(p_purchase_id);
  select * into v_header from erp.material_purchase_headers where id = p_purchase_id;
  v_response := jsonb_build_object(
    'purchase_id', p_purchase_id, 'status', v_header.status,
    'row_version', v_header.row_version
  );
  return erp._idempotency_complete('post_material_purchase_v2', p_client_request_id, v_response);
end;
$$;

create or replace function erp.finalize_material_purchase_invoice_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_purchase_id uuid := nullif(p_payload->>'purchase_id', '')::uuid;
  v_header erp.material_purchase_headers%rowtype;
  v_line jsonb;
  v_item erp.material_purchase_items%rowtype;
  v_correction_id uuid := gen_random_uuid();
  v_correction_number text;
  v_reason text := nullif(btrim(p_payload->>'reason'), '');
  v_invoice_number text := nullif(btrim(p_payload->>'supplier_invoice_number'), '');
  v_invoice_date date := nullif(p_payload->>'invoice_date', '')::date;
  v_final_price numeric;
begin
  perform erp.require_owner_admin();
  if v_purchase_id is null then raise exception 'purchase_id is required'; end if;
  if v_invoice_number is null then raise exception 'supplier_invoice_number is required'; end if;
  if v_invoice_date is null then raise exception 'invoice_date is required'; end if;
  if v_reason is null then raise exception 'reason is required'; end if;
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if coalesce(jsonb_typeof(p_payload->'lines'), 'null') <> 'array'
     or jsonb_array_length(p_payload->'lines') = 0 then
    raise exception 'At least one final invoice line is required';
  end if;

  v_hash := erp._request_hash(jsonb_build_object('payload', p_payload, 'expected_version', p_expected_version));
  v_cached := erp._idempotency_begin('finalize_material_purchase_invoice_v2', p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_header
  from erp.material_purchase_headers where id = v_purchase_id for update;
  if v_header.id is null or v_header.status <> 'POSTED' then raise exception 'Purchase must be POSTED'; end if;
  if v_header.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_header.row_version;
  end if;

  v_correction_number := 'MPC-' || to_char(clock_timestamp(), 'YYYYMMDDHH24MISSMS')
    || '-' || left(replace(v_correction_id::text, '-', ''), 8);
  perform set_config('app.change_reason', v_reason, true);
  insert into erp.material_purchase_cost_corrections(
    id, correction_number, purchase_id, supplier_invoice_number,
    invoice_date, reason, status, created_by
  ) values (
    v_correction_id, v_correction_number, v_purchase_id, v_invoice_number,
    v_invoice_date, v_reason, 'DRAFT', erp.current_app_user_id()
  );

  for v_line in select value from jsonb_array_elements(p_payload->'lines') loop
    v_final_price := nullif(v_line->>'final_unit_price', '')::numeric;
    if v_final_price is null or v_final_price < 0 then raise exception 'Each final invoice line requires non-negative final_unit_price'; end if;
    select * into v_item
    from erp.material_purchase_items
    where id = nullif(v_line->>'purchase_item_id', '')::uuid
      and purchase_id = v_purchase_id
    for update;
    if v_item.id is null then raise exception 'Final invoice line does not belong to the purchase'; end if;
    insert into erp.material_purchase_cost_correction_items(
      correction_id, purchase_item_id, new_unit_price, notes
    ) values (
      v_correction_id, v_item.id, v_final_price,
      nullif(btrim(v_line->>'notes'), '')
    );
  end loop;

  perform erp.post_material_purchase_cost_correction(v_correction_id);

  for v_line in select value from jsonb_array_elements(p_payload->'lines') loop
    update erp.material_purchase_items
    set price_state = 'FINAL',
        price_source = 'SUPPLIER_INVOICE',
        supplier_final_unit_price_snapshot = (v_line->>'final_unit_price')::numeric,
        price_finalized_at = now(),
        price_finalized_by = erp.current_app_user_id()
    where id = (v_line->>'purchase_item_id')::uuid;
  end loop;

  update erp.material_purchase_headers
  set supplier_invoice_number = v_invoice_number,
      due_date = case when p_payload ? 'due_date' then nullif(p_payload->>'due_date', '')::date else due_date end,
      updated_at = now()
  where id = v_purchase_id
  returning * into v_header;

  v_response := jsonb_build_object(
    'purchase_id', v_purchase_id,
    'correction_id', v_correction_id,
    'correction_number', v_correction_number,
    'price_state', 'FINAL',
    'row_version', v_header.row_version
  );
  return erp._idempotency_complete('finalize_material_purchase_invoice_v2', p_client_request_id, v_response);
end;
$$;

revoke insert, update, delete on erp.material_purchase_headers from public, anon, authenticated;
revoke insert, update, delete on erp.material_purchase_items from public, anon, authenticated;
revoke insert, update, delete on erp.material_rolls from public, anon, authenticated;

revoke execute on function erp.post_material_purchase(uuid) from public, authenticated;
grant execute on function erp.post_material_purchase(uuid) to service_role;

revoke all on function erp.save_material_purchase_draft_v2(jsonb, uuid, bigint) from public;
revoke all on function erp.post_material_purchase_v2(uuid, uuid, bigint, text) from public;
revoke all on function erp.finalize_material_purchase_invoice_v2(jsonb, uuid, bigint) from public;
grant execute on function erp.save_material_purchase_draft_v2(jsonb, uuid, bigint) to authenticated, service_role;
grant execute on function erp.post_material_purchase_v2(uuid, uuid, bigint, text) to authenticated, service_role;
grant execute on function erp.finalize_material_purchase_invoice_v2(jsonb, uuid, bigint) to authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 5. Controlled correction for "Diambil Mandor" and "Bagi Potongan"
-- ---------------------------------------------------------------------------

create or replace function erp.is_cutting_group_presewing_reversible(p_cutting_group_id uuid)
returns boolean
language sql
stable
security definer
set search_path = erp, public, pg_temp
as $$
  select coalesce((
    select
      cg.status in ('CUT','PICKED_UP')
      and not cg.material_issue_posted
      and not cg.material_return_posted
      and not exists (
        select 1 from erp.material_stock_movements m
        where m.source_id = cg.id
          and m.source_type in ('CUTTING_GROUP','CUTTING_GROUP_RETURN')
      )
      and not exists (select 1 from erp.wip_stage_events w where w.cutting_group_id = cg.id)
      and not exists (
        select 1 from erp.work_completion_events w
        where w.cutting_group_id = cg.id and w.status <> 'DRAFT'
      )
      and not exists (
        select 1
        from erp.laundry_delivery_lines ldl
        join erp.laundry_deliveries ld on ld.id = ldl.delivery_id
        where ldl.cutting_group_id = cg.id and ld.status not in ('DRAFT','REVERSED')
      )
      and not exists (
        select 1
        from erp.qc_inspection_items qi
        join erp.qc_inspections qh on qh.id = qi.inspection_id
        where qi.cutting_group_id = cg.id and qh.status <> 'DRAFT'
      )
      and not exists (
        select 1 from erp.fg_lots f
        where f.cutting_group_id = cg.id and f.lot_origin <> 'VOIDED_PRODUCTION'
      )
      and not exists (
        select 1 from erp.bs_cases b
        where b.cutting_group_id = cg.id and b.status <> 'CANCELLED'
      )
      and not exists (
        select 1 from erp.scrap_batches s where s.source_cutting_group_id = cg.id
      )
      and not exists (
        select 1 from erp.cutting_qty_correction_lines c where c.cutting_group_id = cg.id
      )
    from erp.cutting_groups cg
    where cg.id = p_cutting_group_id
  ), false)
$$;

revoke all on function erp.is_cutting_group_presewing_reversible(uuid) from public;

create or replace function erp.validate_cutting_batch_link()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
declare
  v_po uuid;
begin
  if new.cutting_batch_id is not null then
    select po_id into v_po from erp.cutting_batches where id = new.cutting_batch_id;
    if v_po is null or v_po <> new.po_id then
      raise exception 'Cutting batch must belong to the same production order';
    end if;
  end if;

  if tg_op = 'UPDATE'
     and old.cutting_batch_id is distinct from new.cutting_batch_id
     and not erp.is_cutting_group_presewing_reversible(old.id) then
    raise exception 'Cutting batch assignment is locked after sewing/physical/financial use; use quantity correction or reverse downstream first';
  end if;
  return new;
end;
$$;

create or replace function erp.guard_cutting_group_delete_after_use()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
begin
  if current_user in ('postgres','service_role','supabase_admin') then return old; end if;
  if not erp.is_cutting_group_presewing_reversible(old.id) then
    raise exception 'Potongan sudah memiliki jahitan/transaksi fisik/biaya/downstream dan tidak boleh dihapus. Gunakan koreksi/reversal.';
  end if;
  return old;
end;
$$;

create or replace function erp.guard_cutting_group_header_after_commitment()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
declare
  v_committed boolean := false;
  v_has_downstream boolean := false;
  v_earliest timestamptz;
  v_status_allowed boolean := false;
begin
  if current_user in ('postgres','service_role','supabase_admin') then return new; end if;

  v_has_downstream :=
       exists(select 1 from erp.laundry_delivery_lines ldl join erp.laundry_deliveries ld on ld.id=ldl.delivery_id where ldl.cutting_group_id=old.id and ld.status not in('DRAFT','REVERSED'))
    or exists(select 1 from erp.work_completion_events w where w.cutting_group_id=old.id and w.status<>'DRAFT')
    or exists(select 1 from erp.qc_inspection_items q join erp.qc_inspections qi on qi.id=q.inspection_id where q.cutting_group_id=old.id and qi.status<>'DRAFT')
    or exists(select 1 from erp.fg_lots f where f.cutting_group_id=old.id and f.lot_origin<>'VOIDED_PRODUCTION')
    or exists(select 1 from erp.bs_cases b where b.cutting_group_id=old.id and b.status<>'CANCELLED')
    or exists(select 1 from erp.scrap_batches s where s.source_cutting_group_id=old.id);

  v_committed := not erp.is_cutting_group_presewing_reversible(old.id);
  if v_committed and (
       new.po_id is distinct from old.po_id
    or new.cutting_batch_id is distinct from old.cutting_batch_id
    or new.group_number is distinct from old.group_number
    or new.cut_at is distinct from old.cut_at
  ) then
    raise exception 'Potongan sudah dijahit/dipakai operasional. Identitas dan batch tidak boleh diganti langsung.';
  end if;

  if new.status is distinct from old.status then
    v_status_allowed :=
      (old.status='CUT' and new.status='PICKED_UP' and old.picked_up_at is null and new.picked_up_at is not null)
      or
      (old.status='PICKED_UP' and new.status='CUT' and old.picked_up_at is not null and new.picked_up_at is null and not v_committed);
    if not v_status_allowed then
      raise exception 'Status Potongan mengikuti pickup/posting fisik dan tidak boleh diganti manual.';
    end if;
  end if;

  if old.picked_up_at is not null
     and new.picked_up_at is distinct from old.picked_up_at
     and new.picked_up_at is not null then
    select min(x.ts) into v_earliest from (
      select ld.physical_at ts from erp.laundry_delivery_lines ldl join erp.laundry_deliveries ld on ld.id=ldl.delivery_id where ldl.cutting_group_id=old.id and ld.status not in('DRAFT','REVERSED')
      union all
      select w.physical_at from erp.work_completion_events w where w.cutting_group_id=old.id and w.status<>'DRAFT'
      union all
      select q.physical_at from erp.qc_inspection_items qi join erp.qc_inspections q on q.id=qi.inspection_id where qi.cutting_group_id=old.id and q.status<>'DRAFT'
      union all
      select f.produced_at from erp.fg_lots f where f.cutting_group_id=old.id and f.lot_origin<>'VOIDED_PRODUCTION'
    ) x where x.ts is not null;
    if v_earliest is not null and new.picked_up_at > v_earliest then
      raise exception 'Tanggal pickup baru melewati transaksi downstream paling awal %', v_earliest;
    end if;
  end if;
  return new;
end;
$$;

create or replace function erp.save_cutting_batch_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_id uuid := nullif(p_payload->>'id', '')::uuid;
  v_action text := upper(coalesce(nullif(btrim(p_payload->>'action'), ''), 'SAVE'));
  v_reason text := nullif(btrim(p_payload->>'change_reason'), '');
  v_batch erp.cutting_batches%rowtype;
begin
  perform erp.require_internal();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if v_action not in ('SAVE','DELETE') then raise exception 'Invalid cutting batch action'; end if;

  v_hash := erp._request_hash(jsonb_build_object('payload', p_payload, 'expected_version', p_expected_version));
  v_cached := erp._idempotency_begin('save_cutting_batch_v2', p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  if v_id is null then
    if v_action = 'DELETE' then raise exception 'Batch id is required for DELETE'; end if;
    if p_expected_version is not null then raise exception 'expected_version must be null when creating a batch'; end if;
    if nullif(p_payload->>'po_id', '')::uuid is null then raise exception 'po_id is required'; end if;
    if coalesce(btrim(p_payload->>'batch_number'), '') = '' then raise exception 'batch_number is required'; end if;
    if nullif(p_payload->>'cut_at', '')::timestamptz is null then raise exception 'cut_at is required'; end if;
    insert into erp.cutting_batches(
      po_id, batch_number, cut_at, status, notes, created_by
    ) values (
      (p_payload->>'po_id')::uuid, btrim(p_payload->>'batch_number'),
      (p_payload->>'cut_at')::timestamptz,
      upper(coalesce(nullif(btrim(p_payload->>'status'), ''), 'OPEN')),
      nullif(btrim(p_payload->>'notes'), ''), erp.current_app_user_id()
    ) returning * into v_batch;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into v_batch from erp.cutting_batches where id = v_id for update;
    if v_batch.id is null then raise exception 'Cutting batch not found'; end if;
    if v_batch.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_batch.row_version;
    end if;
    if v_action = 'DELETE' then
      if exists(select 1 from erp.cutting_groups where cutting_batch_id = v_id) then
        raise exception 'Delete or reassign eligible Potongan before deleting the batch';
      end if;
      if exists(select 1 from erp.cutting_qty_corrections where cutting_batch_id = v_id) then
        raise exception 'Batch with posted quantity corrections cannot be deleted';
      end if;
      delete from erp.cutting_batches where id = v_id;
      v_response := jsonb_build_object('cutting_batch_id', v_id, 'status', 'DELETED');
      return erp._idempotency_complete('save_cutting_batch_v2', p_client_request_id, v_response);
    end if;

    update erp.cutting_batches
    set po_id = case when p_payload ? 'po_id' then nullif(p_payload->>'po_id', '')::uuid else v_batch.po_id end,
        batch_number = coalesce(nullif(btrim(p_payload->>'batch_number'), ''), v_batch.batch_number),
        cut_at = coalesce(nullif(p_payload->>'cut_at', '')::timestamptz, v_batch.cut_at),
        status = upper(coalesce(nullif(btrim(p_payload->>'status'), ''), v_batch.status)),
        notes = case when p_payload ? 'notes' then nullif(btrim(p_payload->>'notes'), '') else v_batch.notes end,
        updated_at = now()
    where id = v_id
    returning * into v_batch;
  end if;

  v_response := jsonb_build_object(
    'cutting_batch_id', v_batch.id, 'status', v_batch.status,
    'row_version', v_batch.row_version
  );
  return erp._idempotency_complete('save_cutting_batch_v2', p_client_request_id, v_response);
end;
$$;

create or replace function erp.save_cutting_group_before_sewing_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_id uuid := nullif(p_payload->>'id', '')::uuid;
  v_action text := upper(coalesce(nullif(btrim(p_payload->>'action'), ''), 'SAVE'));
  v_reason text := nullif(btrim(p_payload->>'change_reason'), '');
  v_group erp.cutting_groups%rowtype;
  v_slot jsonb;
begin
  perform erp.require_internal();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if v_action not in ('SAVE','DELETE') then raise exception 'Invalid cutting group action'; end if;

  v_hash := erp._request_hash(jsonb_build_object('payload', p_payload, 'expected_version', p_expected_version));
  v_cached := erp._idempotency_begin('save_cutting_group_before_sewing_v2', p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  if v_id is null then
    if v_action = 'DELETE' then raise exception 'Potongan id is required for DELETE'; end if;
    if p_expected_version is not null then raise exception 'expected_version must be null when creating Potongan'; end if;
    if nullif(p_payload->>'po_id', '')::uuid is null then raise exception 'po_id is required'; end if;
    if coalesce(btrim(p_payload->>'group_number'), '') = '' then raise exception 'group_number is required'; end if;
    if nullif(p_payload->>'cut_at', '')::timestamptz is null then raise exception 'cut_at is required'; end if;
    insert into erp.cutting_groups(
      po_id, group_number, cut_at, executor_name, picked_up_at, status,
      code, pattern_type, notes, cutting_batch_id
    ) values (
      (p_payload->>'po_id')::uuid, btrim(p_payload->>'group_number'),
      (p_payload->>'cut_at')::timestamptz,
      nullif(btrim(p_payload->>'executor_name'), ''),
      nullif(p_payload->>'picked_up_at', '')::timestamptz,
      case when nullif(p_payload->>'picked_up_at', '')::timestamptz is null then 'CUT' else 'PICKED_UP' end,
      nullif(btrim(p_payload->>'code'), ''), nullif(btrim(p_payload->>'pattern_type'), ''),
      nullif(btrim(p_payload->>'notes'), ''), nullif(p_payload->>'cutting_batch_id', '')::uuid
    ) returning * into v_group;
    v_id := v_group.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into v_group from erp.cutting_groups where id = v_id for update;
    if v_group.id is null then raise exception 'Potongan not found'; end if;
    if v_group.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_group.row_version;
    end if;
    if not erp.is_cutting_group_presewing_reversible(v_id) then
      raise exception 'Potongan sudah dijahit/dipakai fisik atau finansial; gunakan correction/reversal';
    end if;

    if v_action = 'DELETE' then
      delete from erp.cutting_groups where id = v_id;
      v_response := jsonb_build_object('cutting_group_id', v_id, 'status', 'DELETED');
      return erp._idempotency_complete('save_cutting_group_before_sewing_v2', p_client_request_id, v_response);
    end if;

    update erp.cutting_groups
    set po_id = case when p_payload ? 'po_id' then nullif(p_payload->>'po_id', '')::uuid else v_group.po_id end,
        group_number = coalesce(nullif(btrim(p_payload->>'group_number'), ''), v_group.group_number),
        cut_at = coalesce(nullif(p_payload->>'cut_at', '')::timestamptz, v_group.cut_at),
        executor_name = case when p_payload ? 'executor_name' then nullif(btrim(p_payload->>'executor_name'), '') else v_group.executor_name end,
        picked_up_at = case when p_payload ? 'picked_up_at' then nullif(p_payload->>'picked_up_at', '')::timestamptz else v_group.picked_up_at end,
        status = case
          when (case when p_payload ? 'picked_up_at' then nullif(p_payload->>'picked_up_at', '')::timestamptz else v_group.picked_up_at end) is null
            then 'CUT' else 'PICKED_UP' end,
        code = case when p_payload ? 'code' then nullif(btrim(p_payload->>'code'), '') else v_group.code end,
        pattern_type = case when p_payload ? 'pattern_type' then nullif(btrim(p_payload->>'pattern_type'), '') else v_group.pattern_type end,
        notes = case when p_payload ? 'notes' then nullif(btrim(p_payload->>'notes'), '') else v_group.notes end,
        cutting_batch_id = case when p_payload ? 'cutting_batch_id' then nullif(p_payload->>'cutting_batch_id', '')::uuid else v_group.cutting_batch_id end,
        updated_at = now()
    where id = v_id
    returning * into v_group;
  end if;

  if p_payload ? 'size_slots' then
    if jsonb_typeof(p_payload->'size_slots') <> 'array' then raise exception 'size_slots must be an array'; end if;
    delete from erp.cutting_group_size_slots where cutting_group_id = v_id;
    for v_slot in select value from jsonb_array_elements(p_payload->'size_slots') loop
      insert into erp.cutting_group_size_slots(
        id, cutting_group_id, slot_no, size_id, drawing_no, label_override
      ) values (
        coalesce(nullif(v_slot->>'id', '')::uuid, gen_random_uuid()),
        v_id, (v_slot->>'slot_no')::integer, (v_slot->>'size_id')::uuid,
        (v_slot->>'drawing_no')::integer, nullif(btrim(v_slot->>'label_override'), '')
      );
    end loop;
    update erp.cutting_groups set updated_at = now() where id = v_id returning * into v_group;
  end if;

  v_response := jsonb_build_object(
    'cutting_group_id', v_group.id,
    'status', v_group.status,
    'row_version', v_group.row_version,
    'presewing_reversible', erp.is_cutting_group_presewing_reversible(v_group.id)
  );
  return erp._idempotency_complete('save_cutting_group_before_sewing_v2', p_client_request_id, v_response);
end;
$$;

revoke insert, update, delete on erp.cutting_batches from public, anon, authenticated;
revoke insert, update, delete on erp.cutting_groups from public, anon, authenticated;
revoke insert, update, delete on erp.cutting_group_size_slots from public, anon, authenticated;
revoke execute on function erp.create_cutting_batch(uuid, text, timestamptz, text) from public, authenticated;
revoke execute on function erp.assign_cutting_group_to_batch(uuid, uuid) from public, authenticated;
grant execute on function erp.create_cutting_batch(uuid, text, timestamptz, text) to service_role;
grant execute on function erp.assign_cutting_group_to_batch(uuid, uuid) to service_role;

revoke all on function erp.save_cutting_batch_v2(jsonb, uuid, bigint) from public;
revoke all on function erp.save_cutting_group_before_sewing_v2(jsonb, uuid, bigint) from public;
grant execute on function erp.save_cutting_batch_v2(jsonb, uuid, bigint) to authenticated, service_role;
grant execute on function erp.save_cutting_group_before_sewing_v2(jsonb, uuid, bigint) to authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 6. Gudang/material read models (filterable, chronological, security invoker)
-- ---------------------------------------------------------------------------

create or replace view erp.v_fabric_master_current_benchmark
with (security_invoker = true)
as
select
  m.id as material_id,
  m.material_sku,
  m.material_name,
  m.unit_code as base_uom_code,
  m.is_active,
  m.cached_stock_qty,
  m.moving_average_cost,
  m.row_version,
  fp.fabric_category,
  fp.composition,
  fp.construction,
  fp.color_name,
  fp.width_cm,
  fp.gsm,
  fp.minimum_stock_qty,
  fp.preferred_supplier_id,
  s.supplier_name as preferred_supplier_name,
  bp.id as benchmark_version_id,
  bp.benchmark_price_per_base_uom,
  bp.effective_from as benchmark_effective_from,
  bp.effective_to as benchmark_effective_to,
  bp.benchmark_price_per_base_uom - m.moving_average_cost as benchmark_vs_moving_average_delta,
  case
    when m.moving_average_cost = 0 then null
    else round(((bp.benchmark_price_per_base_uom - m.moving_average_cost) / m.moving_average_cost) * 100, 4)
  end as benchmark_vs_moving_average_pct
from erp.materials m
left join erp.fabric_master_profiles fp on fp.material_id = m.id
left join erp.suppliers s on s.id = fp.preferred_supplier_id
left join lateral (
  select x.*
  from erp.fabric_benchmark_price_versions x
  where x.material_id = m.id
    and x.effective_from <= now()
    and (x.effective_to is null or now() < x.effective_to)
  order by x.effective_from desc
  limit 1
) bp on true
where m.material_type = 'FABRIC';

create or replace view erp.v_material_stock_balance
with (security_invoker = true)
as
select
  m.id as material_id,
  m.material_sku,
  m.material_name,
  m.material_type,
  m.unit_code,
  sm.location_id,
  l.location_code,
  l.location_name,
  coalesce(sum(sm.qty_signed), 0)::numeric(24,6) as stock_qty,
  m.moving_average_cost,
  round(coalesce(sum(sm.qty_signed), 0) * m.moving_average_cost, 6) as stock_value_at_current_ma,
  max(sm.physical_at) as last_movement_at
from erp.materials m
join erp.material_stock_movements sm on sm.material_id = m.id
left join erp.locations l on l.id = sm.location_id
group by m.id, m.material_sku, m.material_name, m.material_type, m.unit_code,
         m.moving_average_cost, sm.location_id, l.location_code, l.location_name;

create or replace view erp.v_material_stock_card
with (security_invoker = true)
as
select
  sm.id as movement_id,
  sm.material_id,
  m.material_sku,
  m.material_name,
  m.unit_code,
  sm.roll_id,
  r.roll_number,
  sm.location_id,
  l.location_code,
  l.location_name,
  sm.movement_type,
  sm.qty_signed,
  sum(sm.qty_signed) over (
    partition by sm.material_id, sm.location_id
    order by sm.physical_at, sm.system_created_at, sm.id
    rows between unbounded preceding and current row
  ) as running_qty,
  sm.input_unit_cost,
  sm.unit_cost_snapshot,
  round(sm.qty_signed * sm.unit_cost_snapshot, 6) as movement_value,
  sm.source_type,
  sm.source_id,
  sm.physical_at,
  sm.system_created_at,
  sm.reversal_of_id,
  sm.note
from erp.material_stock_movements sm
join erp.materials m on m.id = sm.material_id
left join erp.material_rolls r on r.id = sm.roll_id
left join erp.locations l on l.id = sm.location_id;

create or replace view erp.v_material_stock_mutations
with (security_invoker = true)
as
select
  sm.id as mutation_id,
  sm.physical_at,
  sm.system_created_at,
  sm.material_id,
  m.material_sku,
  m.material_name,
  m.material_type,
  m.unit_code,
  sm.roll_id,
  r.roll_number,
  sm.location_id,
  l.location_code,
  sm.movement_type,
  sm.qty_signed,
  sm.unit_cost_snapshot,
  sm.source_type,
  sm.source_id,
  sm.reversal_of_id,
  sm.note
from erp.material_stock_movements sm
join erp.materials m on m.id = sm.material_id
left join erp.material_rolls r on r.id = sm.roll_id
left join erp.locations l on l.id = sm.location_id;

create or replace view erp.v_material_roll_availability
with (security_invoker = true)
as
select
  r.id as roll_id,
  r.material_id,
  m.material_sku,
  m.material_name,
  m.unit_code,
  r.roll_number,
  r.original_qty,
  r.cached_qty,
  coalesce(sum(sm.qty_signed), 0)::numeric(24,6) as ledger_qty,
  r.status,
  r.supplier_id,
  s.supplier_name,
  r.purchase_item_id,
  pi.purchase_id,
  ph.purchase_number,
  ph.physical_at as received_physical_at,
  r.received_at,
  r.updated_at
from erp.material_rolls r
join erp.materials m on m.id = r.material_id
left join erp.suppliers s on s.id = r.supplier_id
left join erp.material_purchase_items pi on pi.id = r.purchase_item_id
left join erp.material_purchase_headers ph on ph.id = pi.purchase_id
left join erp.material_stock_movements sm on sm.roll_id = r.id
group by r.id, r.material_id, m.material_sku, m.material_name, m.unit_code,
         r.roll_number, r.original_qty, r.cached_qty, r.status, r.supplier_id,
         s.supplier_name, r.purchase_item_id, pi.purchase_id, ph.purchase_number,
         ph.physical_at, r.received_at, r.updated_at;

create or replace view erp.v_material_purchase_price_status
with (security_invoker = true)
as
select
  h.id as purchase_id,
  h.purchase_number,
  h.status as purchase_status,
  h.physical_at,
  h.supplier_id,
  s.supplier_name,
  h.supplier_invoice_number,
  h.due_date,
  i.id as purchase_item_id,
  i.material_id,
  m.material_sku,
  m.material_name,
  m.material_type,
  m.unit_code,
  i.qty,
  i.unit_price as receipt_unit_price_snapshot,
  i.price_state,
  i.price_source,
  i.benchmark_price_version_id,
  i.benchmark_unit_price_snapshot,
  i.supplier_final_unit_price_snapshot,
  erp.material_purchase_current_unit_cost(i.id) as current_payable_and_cost_unit_price,
  round(i.qty * erp.material_purchase_current_unit_cost(i.id), 6) as current_line_total,
  i.price_finalized_at
from erp.material_purchase_headers h
join erp.material_purchase_items i on i.purchase_id = h.id
join erp.materials m on m.id = i.material_id
left join erp.suppliers s on s.id = h.supplier_id;

create or replace view erp.v_supplier_ap_aging
with (security_invoker = true)
as
with ap as (
  select
    h.id as purchase_id,
    h.purchase_number,
    h.supplier_id,
    s.supplier_name,
    h.supplier_invoice_number,
    h.physical_at,
    h.due_date,
    erp.material_purchase_payable_total(h.id) as payable_amount,
    coalesce((
      select sum(sp.amount)
      from erp.supplier_payments sp
      where sp.purchase_id = h.id and sp.status = 'POSTED'
    ), 0)::numeric as paid_amount
  from erp.material_purchase_headers h
  left join erp.suppliers s on s.id = h.supplier_id
  where h.status = 'POSTED'
)
select
  ap.*,
  greatest(ap.payable_amount - ap.paid_amount, 0)::numeric as outstanding_amount,
  case
    when ap.due_date is null or ap.payable_amount <= ap.paid_amount then 0
    else greatest(current_date - ap.due_date, 0)
  end as days_overdue,
  case
    when ap.payable_amount <= ap.paid_amount then 'PAID'
    when ap.due_date is null or current_date <= ap.due_date then 'CURRENT'
    when current_date - ap.due_date <= 30 then '1_30'
    when current_date - ap.due_date <= 60 then '31_60'
    when current_date - ap.due_date <= 90 then '61_90'
    else '90_PLUS'
  end as aging_bucket
from ap;

alter view erp.v_accessory_hpp_setup set (security_invoker = true);
alter view erp.v_product_price_current set (security_invoker = true);

grant select on
  erp.v_fabric_master_current_benchmark,
  erp.v_material_stock_balance,
  erp.v_material_stock_card,
  erp.v_material_stock_mutations,
  erp.v_material_roll_availability,
  erp.v_material_purchase_price_status,
  erp.v_supplier_ap_aging
to authenticated;

revoke all on
  erp.v_fabric_master_current_benchmark,
  erp.v_material_stock_balance,
  erp.v_material_stock_card,
  erp.v_material_stock_mutations,
  erp.v_material_roll_availability,
  erp.v_material_purchase_price_status,
  erp.v_supplier_ap_aging
from anon;

grant execute on function erp.material_purchase_current_unit_cost(uuid) to authenticated;
grant execute on function erp.material_purchase_payable_total(uuid) to authenticated;

-- ---------------------------------------------------------------------------
-- 7. Audit coverage and hard-delete reduction
-- ---------------------------------------------------------------------------

drop policy if exists internal_app_users_read_v262 on erp.app_users;
create policy internal_app_users_read_v262
on erp.app_users for select to authenticated
using ((select erp.current_app_role()) = any (array['OWNER','ADMIN']));

do $$
declare
  v_table text;
  v_reg regclass;
begin
  foreach v_table in array array[
    'app_users','brands','customers','customer_user_access','locations','suppliers',
    'laundry_vendors','laundry_vendor_rate_versions','supplier_payments',
    'vendor_payments','sales_payments','vendor_invoices','vendor_invoice_items',
    'material_purchase_items','material_rolls','cutting_group_size_slots'
  ] loop
    v_reg := to_regclass(format('erp.%I', v_table));
    if v_reg is not null and not exists (
      select 1 from pg_trigger
      where tgrelid = v_reg
        and tgfoid = 'erp.audit_row_change()'::regprocedure
        and not tgisinternal
    ) then
      execute format(
        'create trigger %I after insert or update or delete on erp.%I for each row execute function erp.audit_row_change()',
        'trg_audit_v262_' || v_table, v_table
      );
    end if;
  end loop;
end;
$$;

do $$
declare
  v_table text;
begin
  foreach v_table in array array[
    'brands','customers','customer_user_access','locations','suppliers','materials',
    'sizes','product_models','products','product_price_versions',
    'accessory_categories','accessory_bom_versions','accessory_bom_items',
    'contractors','contractor_workers','contractor_work_rates',
    'contractor_material_price_versions','contractor_accessory_price_versions',
    'work_components','work_bom_versions','work_bom_items',
    'laundry_vendors','laundry_vendor_rate_versions','uom_definitions',
    'cash_accounts','chart_accounts','accounting_account_mappings'
  ] loop
    if to_regclass(format('erp.%I', v_table)) is not null then
      execute format('revoke delete on erp.%I from public, anon, authenticated', v_table);
    end if;
  end loop;
end;
$$;

-- ---------------------------------------------------------------------------
-- 8. Release self-checks used by deployment and recurring red-team audits
-- ---------------------------------------------------------------------------

create or replace function erp.run_v262_integrity_checks()
returns table(check_name text, severity text, issue_count bigint, details text)
language sql
stable
security definer
set search_path = erp, public, pg_temp
as $$
  select
    'fabric_profile_non_fabric', 'CRITICAL', count(*)::bigint,
    'Fabric profile rows must reference materials.material_type=FABRIC'
  from erp.fabric_master_profiles fp
  join erp.materials m on m.id = fp.material_id
  where m.material_type <> 'FABRIC'

  union all
  select
    'fabric_benchmark_non_fabric', 'CRITICAL', count(*)::bigint,
    'Fabric benchmark rows must reference materials.material_type=FABRIC'
  from erp.fabric_benchmark_price_versions bp
  join erp.materials m on m.id = bp.material_id
  where m.material_type <> 'FABRIC'

  union all
  select
    'fabric_benchmark_period_overlap', 'CRITICAL', count(*)::bigint,
    'Effective benchmark periods for one fabric must not overlap'
  from erp.fabric_benchmark_price_versions a
  join erp.fabric_benchmark_price_versions b
    on b.material_id = a.material_id and b.id > a.id
   and tstzrange(a.effective_from, a.effective_to, '[)')
       && tstzrange(b.effective_from, b.effective_to, '[)')

  union all
  select
    'purchase_benchmark_snapshot_mismatch', 'CRITICAL', count(*)::bigint,
    'BENCHMARK purchase lines must preserve the referenced price and material snapshot'
  from erp.material_purchase_items i
  left join erp.fabric_benchmark_price_versions bp on bp.id = i.benchmark_price_version_id
  where i.price_source = 'BENCHMARK'
    and (
      bp.id is null
      or bp.material_id <> i.material_id
      or abs(bp.benchmark_price_per_base_uom - i.benchmark_unit_price_snapshot) > 0.000001
      or abs(i.unit_price - i.benchmark_unit_price_snapshot) > 0.000001
    )

  union all
  select
    'purchase_final_price_missing_provenance', 'CRITICAL', count(*)::bigint,
    'FINAL lines require final snapshot, timestamp, and a final source'
  from erp.material_purchase_items i
  where i.price_state = 'FINAL'
    and (
      i.price_source not in ('SUPPLIER_INVOICE','MIGRATION')
      or i.supplier_final_unit_price_snapshot is null
      or i.price_finalized_at is null
    )

  union all
  select
    'posted_purchase_without_lines', 'CRITICAL', count(*)::bigint,
    'Posted purchases must contain at least one line'
  from erp.material_purchase_headers h
  where h.status = 'POSTED'
    and not exists (select 1 from erp.material_purchase_items i where i.purchase_id = h.id)

  union all
  select
    'posted_fabric_roll_total_mismatch', 'CRITICAL', count(*)::bigint,
    'When rolls are used, their original quantity must equal the posted fabric line quantity'
  from erp.material_purchase_items i
  join erp.material_purchase_headers h on h.id = i.purchase_id and h.status = 'POSTED'
  join erp.materials m on m.id = i.material_id and m.material_type = 'FABRIC'
  cross join lateral (
    select count(*) roll_count, coalesce(sum(r.original_qty),0) roll_qty
    from erp.material_rolls r where r.purchase_item_id = i.id
  ) x
  where x.roll_count > 0 and abs(x.roll_qty - i.qty) > 0.000001

  union all
  select
    'stale_idempotency_in_progress', 'WARNING', count(*)::bigint,
    'IN_PROGRESS idempotency rows older than 15 minutes indicate an interrupted request'
  from erp.idempotency_requests
  where status = 'IN_PROGRESS' and updated_at < now() - interval '15 minutes'

  union all
  select
    'app_users_without_active_owner', 'CRITICAL',
    case
      when exists(select 1 from erp.app_users)
       and not exists(select 1 from erp.app_users where role='OWNER' and is_active)
      then 1 else 0
    end::bigint,
    'A non-empty app user registry must retain at least one active OWNER';
$$;

create or replace function erp.run_v262_security_checks()
returns table(check_name text, severity text, issue_count bigint, details text)
language sql
stable
security definer
set search_path = erp, public, pg_catalog, information_schema, pg_temp
as $$
  select
    'v262_new_tables_without_rls', 'CRITICAL', count(*)::bigint,
    'Every new Data API table must have RLS enabled'
  from pg_class c
  join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'erp'
    and c.relname in ('idempotency_requests','fabric_master_profiles','fabric_benchmark_price_versions')
    and not c.relrowsecurity

  union all
  select
    'protected_tables_with_direct_write_grant', 'CRITICAL', count(*)::bigint,
    'High-risk aggregates may only be written through domain RPCs'
  from information_schema.role_table_grants g
  where g.table_schema = 'erp'
    and g.grantee in ('PUBLIC','anon','authenticated')
    and g.privilege_type in ('INSERT','UPDATE','DELETE')
    and g.table_name in (
      'app_users','materials','fabric_master_profiles','fabric_benchmark_price_versions',
      'material_purchase_headers','material_purchase_items','material_rolls',
      'cutting_batches','cutting_groups','cutting_group_size_slots','idempotency_requests'
    )

  union all
  select
    'app_users_mutation_policy_present', 'CRITICAL', count(*)::bigint,
    'app_users mutations must go through hierarchy-aware RPCs'
  from pg_policy p
  where p.polrelid = 'erp.app_users'::regclass and p.polcmd in ('a','w','d')

  union all
  select
    'erp_view_without_security_invoker', 'CRITICAL', count(*)::bigint,
    'ERP views exposed to authenticated users must honor base-table RLS'
  from pg_class c
  join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'erp' and c.relkind = 'v'
    and not ('security_invoker=true' = any(coalesce(c.reloptions, array[]::text[])))

  union all
  select
    'public_execute_v262_security_definer', 'CRITICAL', count(distinct p.oid)::bigint,
    'New SECURITY DEFINER functions must not be executable by PUBLIC'
  from pg_proc p
  join pg_namespace n on n.oid = p.pronamespace
  join lateral aclexplode(coalesce(p.proacl, acldefault('f', p.proowner))) a on true
  where n.nspname = 'erp'
    and p.prosecdef
    and p.proname in (
      '_idempotency_actor_key','_request_hash','_idempotency_begin','_idempotency_complete',
      'save_fabric_master_v2','set_fabric_benchmark_price_v2','save_app_user_v2',
      'save_material_purchase_draft_v2','post_material_purchase_v2',
      'finalize_material_purchase_invoice_v2','is_cutting_group_presewing_reversible',
      'save_cutting_batch_v2','save_cutting_group_before_sewing_v2'
    )
    and a.grantee = 0 and a.privilege_type = 'EXECUTE'

  union all
  select
    'anon_access_v262_objects', 'CRITICAL', count(*)::bigint,
    'Anonymous role must not read or mutate the new backend objects'
  from information_schema.role_table_grants g
  where g.table_schema = 'erp' and g.grantee = 'anon'
    and g.table_name in (
      'idempotency_requests','fabric_master_profiles','fabric_benchmark_price_versions',
      'v_fabric_master_current_benchmark','v_material_stock_balance',
      'v_material_stock_card','v_material_stock_mutations','v_material_roll_availability',
      'v_material_purchase_price_status','v_supplier_ap_aging'
    );
$$;

revoke all on function erp.run_v262_integrity_checks() from public;
revoke all on function erp.run_v262_security_checks() from public;
grant execute on function erp.run_v262_integrity_checks() to authenticated, service_role;
grant execute on function erp.run_v262_security_checks() to authenticated, service_role;

comment on table erp.fabric_master_profiles is
  'Optional technical profile for FABRIC materials. Valuation fields remain on materials.';
comment on table erp.fabric_benchmark_price_versions is
  'Manual effective-dated purchase benchmark. It is not moving-average cost and not final supplier AP.';
comment on column erp.material_purchase_items.unit_price is
  'Immutable receipt-time price snapshot used by original stock posting; later supplier invoice deltas use cost corrections.';
comment on column erp.material_purchase_items.benchmark_unit_price_snapshot is
  'Manual benchmark captured at physical receipt time when the supplier invoice was not final.';
comment on function erp.save_cutting_group_before_sewing_v2(jsonb, uuid, bigint) is
  'Allows create/edit/reassign/delete only while Potongan is CUT/PICKED_UP and has no sewing, stock, cost, or downstream commitment.';

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.2',
  'Safe CRUD foundation, fabric benchmark, material Gudang read models, and pre-sewing cutting correction',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828070429','erp_v262_crud_fabric_benchmark',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828070429 erp_v262_crud_fabric_benchmark

-- BEGIN PLATFORM MIGRATION 20260828070524 erp_v262a_security_closure
-- ERP Garment v2.6.2a
-- Closure from the first post-migration security smoke test.

set lock_timeout = '10s';
set statement_timeout = '60s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_2a', 0));

do $$
begin
  if not exists (select 1 from erp.schema_migrations where version = 'v2.6.2') then
    raise exception 'ERP Garment v2.6.2 is required before v2.6.2a';
  end if;
end;
$$;

-- Master fabric writes are aggregate-RPC only. SELECT remains available through
-- existing RLS and the dedicated security-invoker read model.
revoke insert, update, delete on erp.materials from public, anon, authenticated;

-- Trigger functions never need direct API execution.
revoke all on function erp.bump_row_version() from public, anon, authenticated;
revoke all on function erp.validate_fabric_profile() from public, anon, authenticated;
revoke all on function erp.validate_fabric_benchmark_version() from public, anon, authenticated;

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.2a',
  'Close residual direct materials writes and PUBLIC trigger-function execution found by post-migration red-team smoke test',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828070524','erp_v262a_security_closure',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828070524 erp_v262a_security_closure

-- BEGIN PLATFORM MIGRATION 20260828071056 erp_v262b_audit_entity_resolver
-- ERP Garment v2.6.2b
-- Make the generic audit trigger safe for UUID-keyed tables whose key is not named id.

set lock_timeout = '10s';
set statement_timeout = '60s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_2b', 0));

do $$
begin
  if not exists (select 1 from erp.schema_migrations where version = 'v2.6.2a') then
    raise exception 'ERP Garment v2.6.2a is required before v2.6.2b';
  end if;
end;
$$;

create or replace function erp.audit_row_change()
returns trigger
language plpgsql
security definer
set search_path = erp, public, pg_temp
as $$
declare
  v_reason text := nullif(current_setting('app.change_reason', true), '');
  v_old jsonb;
  v_new jsonb;
  v_entity_id uuid;
begin
  if tg_op <> 'INSERT' then v_old := to_jsonb(old); end if;
  if tg_op <> 'DELETE' then v_new := to_jsonb(new); end if;

  v_entity_id := coalesce(
    nullif(coalesce(v_new, v_old)->>'id', '')::uuid,
    nullif(coalesce(v_new, v_old)->>'material_id', '')::uuid
  );
  if v_entity_id is null then
    raise exception 'Audit trigger on %.% requires a UUID id or material_id field', tg_table_schema, tg_table_name;
  end if;

  if tg_op = 'INSERT' then
    insert into erp.audit_logs(
      entity_type, entity_id, action, new_data, changed_by, change_reason
    ) values (
      tg_table_name, v_entity_id, 'INSERT', v_new,
      erp.current_app_user_id(), v_reason
    );
    return new;
  elsif tg_op = 'UPDATE' then
    if v_old is distinct from v_new then
      insert into erp.audit_logs(
        entity_type, entity_id, action, old_data, new_data, changed_by, change_reason
      ) values (
        tg_table_name, v_entity_id, 'UPDATE', v_old, v_new,
        erp.current_app_user_id(), v_reason
      );
    end if;
    return new;
  else
    insert into erp.audit_logs(
      entity_type, entity_id, action, old_data, changed_by, change_reason
    ) values (
      tg_table_name, v_entity_id, 'DELETE', v_old,
      erp.current_app_user_id(), v_reason
    );
    return old;
  end if;
end;
$$;

revoke all on function erp.audit_row_change() from public, anon, authenticated;

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.2b',
  'Generic audit entity resolver supports UUID id or material_id keys',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828071056','erp_v262b_audit_entity_resolver',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828071056 erp_v262b_audit_entity_resolver

-- BEGIN PLATFORM MIGRATION 20260828071239 erp_v262c_advisor_closure
-- ERP Garment v2.6.2c
-- Explicit deny policy, consolidated user read policy, and targeted FK indexes.

set lock_timeout = '10s';
set statement_timeout = '60s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_2c', 0));

do $$
begin
  if not exists (select 1 from erp.schema_migrations where version = 'v2.6.2b') then
    raise exception 'ERP Garment v2.6.2b is required before v2.6.2c';
  end if;
end;
$$;

-- Keep the internal idempotency ledger completely invisible to API roles while
-- making the deny-all intent explicit to the database advisor.
drop policy if exists idempotency_explicit_deny on erp.idempotency_requests;
create policy idempotency_explicit_deny
on erp.idempotency_requests for all to anon, authenticated
using (false)
with check (false);

-- One SELECT policy avoids multiple-permissive-policy evaluation while keeping
-- self-read plus OWNER/ADMIN directory access.
drop policy if exists own_app_user on erp.app_users;
drop policy if exists internal_app_users_read_v262 on erp.app_users;
drop policy if exists app_users_select_v262 on erp.app_users;
create policy app_users_select_v262
on erp.app_users for select to authenticated
using (
  auth_user_id = (select auth.uid())
  or (select erp.current_app_role()) = any (array['OWNER','ADMIN'])
);

-- Cover only new or newly-exposed foreign-key paths used by this release.
create index idx_fabric_profile_created_by
  on erp.fabric_master_profiles(created_by) where created_by is not null;
create index idx_fabric_profile_updated_by
  on erp.fabric_master_profiles(updated_by) where updated_by is not null;
create index idx_fabric_benchmark_created_by
  on erp.fabric_benchmark_price_versions(created_by) where created_by is not null;
create index idx_material_purchase_items_price_finalized_by
  on erp.material_purchase_items(price_finalized_by) where price_finalized_by is not null;
create index idx_material_purchase_items_purchase_uom
  on erp.material_purchase_items(purchase_uom_code) where purchase_uom_code is not null;

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.2c',
  'Explicit idempotency deny policy, consolidated app-user read policy, and targeted new FK indexes',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828071239','erp_v262c_advisor_closure',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828071239 erp_v262c_advisor_closure

-- BEGIN PLATFORM MIGRATION 20260828072332 erp_v263a_payroll_hold_nota
-- ERP Garment v2.6.3a
-- Laundry-aware payroll hold/release, authoritative eligible-Nota lines,
-- atomic Nota merge, and browser-safe work-snapshot wrapper.

set lock_timeout = '10s';
set statement_timeout = '180s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_3a', 0));

do $$
begin
  if not exists (select 1 from erp.schema_migrations where version='v2.6.2c') then
    raise exception 'ERP Garment v2.6.2c is required before v2.6.3a';
  end if;
end;
$$;

alter table erp.payroll_settlements
  add column row_version bigint not null default 1 check (row_version > 0);
drop trigger if exists trg_00_bump_row_version on erp.payroll_settlements;
create trigger trg_00_bump_row_version
before update on erp.payroll_settlements
for each row execute function erp.bump_row_version();

create index idx_payroll_work_items_source
  on erp.payroll_work_items(source_type, source_id, work_component_id);
create index idx_payroll_settlements_contractor_period
  on erp.payroll_settlements(contractor_id, period_end, status);
create index idx_laundry_delivery_lines_group_delivery
  on erp.laundry_delivery_lines(cutting_group_id, delivery_id);
create index idx_laundry_receipt_lines_delivery_line
  on erp.laundry_receipt_lines(delivery_line_id, receipt_id);

create or replace view erp.v_payroll_production_work_eligibility
with (security_invoker = true)
as
with laundry_sent as (
  select ldl.cutting_group_id, sum(ldl.qty_sent_pcs)::bigint as sent_qty
  from erp.laundry_delivery_lines ldl
  join erp.laundry_deliveries ld on ld.id=ldl.delivery_id
  where ld.status not in ('DRAFT','REVERSED')
  group by ldl.cutting_group_id
),
laundry_returned as (
  select ldl.cutting_group_id,
         sum(lrl.qty_good_received+lrl.qty_bs_laundry)::bigint as physically_returned_qty
  from erp.laundry_receipt_lines lrl
  join erp.laundry_receipts lr on lr.id=lrl.receipt_id and lr.status='POSTED'
  join erp.laundry_delivery_lines ldl on ldl.id=lrl.delivery_line_id
  group by ldl.cutting_group_id
),
base as (
  select
    wcl.id as source_id,
    wce.id as completion_id,
    wce.po_id,
    wce.contractor_id,
    wce.cutting_group_id,
    wcl.work_component_id,
    wce.physical_at,
    wcl.qty_payable,
    wcl.rate_snapshot,
    coalesce(ls.sent_qty,0) as laundry_sent_qty,
    coalesce(lr.physically_returned_qty,0) as laundry_returned_qty,
    ls.cutting_group_id is not null as laundry_required,
    coalesce(sum(wcl.qty_payable) over (
      partition by wce.cutting_group_id,wcl.work_component_id
      order by wce.physical_at,wce.id,wcl.id
      rows between unbounded preceding and 1 preceding
    ),0)::bigint as prior_component_qty,
    sum(wcl.qty_payable) over (
      partition by wce.cutting_group_id,wcl.work_component_id
      order by wce.physical_at,wce.id,wcl.id
      rows between unbounded preceding and current row
    )::bigint as cumulative_component_qty
  from erp.work_completion_lines wcl
  join erp.work_completion_events wce on wce.id=wcl.completion_id and wce.status='POSTED'
  left join laundry_sent ls on ls.cutting_group_id=wce.cutting_group_id
  left join laundry_returned lr on lr.cutting_group_id=wce.cutting_group_id
),
eligible as (
  select b.*,
    case
      when b.cutting_group_id is null or not b.laundry_required then b.qty_payable
      else greatest(
        least(b.cumulative_component_qty,b.laundry_returned_qty)
        - least(b.prior_component_qty,b.laundry_returned_qty),0
      )::integer
    end as eligible_after_laundry_qty
  from base b
),
allocated as (
  select pwi.source_id,pwi.work_component_id,sum(pwi.qty_payable)::integer as allocated_qty
  from erp.payroll_work_items pwi
  join erp.payroll_settlements ps on ps.id=pwi.payroll_id
  where pwi.source_type='PRODUCTION' and ps.status<>'REVERSED'
  group by pwi.source_id,pwi.work_component_id
)
select
  e.source_id,
  e.completion_id,
  e.po_id,
  e.contractor_id,
  e.cutting_group_id,
  e.work_component_id,
  e.physical_at,
  e.qty_payable as source_qty_payable,
  e.rate_snapshot,
  e.laundry_required,
  e.laundry_sent_qty,
  e.laundry_returned_qty,
  e.eligible_after_laundry_qty,
  e.qty_payable-e.eligible_after_laundry_qty as held_for_laundry_qty,
  coalesce(a.allocated_qty,0) as allocated_to_nonreversed_payroll_qty,
  greatest(e.eligible_after_laundry_qty-coalesce(a.allocated_qty,0),0)::integer as remaining_eligible_qty,
  round(greatest(e.eligible_after_laundry_qty-coalesce(a.allocated_qty,0),0)*e.rate_snapshot,2) as remaining_eligible_amount,
  case
    when not e.laundry_required then 'NO_LAUNDRY_REQUIRED'
    when e.eligible_after_laundry_qty=e.qty_payable then 'PHYSICALLY_RETURNED'
    when e.eligible_after_laundry_qty=0 then 'HELD_AT_LAUNDRY'
    else 'PARTIALLY_RELEASED'
  end as eligibility_state
from eligible e
left join allocated a on a.source_id=e.source_id and a.work_component_id=e.work_component_id;

create or replace view erp.v_payroll_eligible_work_lines
with (security_invoker = true)
as
select
  'PRODUCTION'::text as source_type,
  p.source_id,
  p.contractor_id,
  p.po_id,
  p.cutting_group_id,
  null::uuid as bs_case_id,
  p.work_component_id,
  p.physical_at as eligible_at,
  p.source_qty_payable as source_qty,
  p.eligible_after_laundry_qty as eligible_qty,
  p.allocated_to_nonreversed_payroll_qty as allocated_qty,
  p.remaining_eligible_qty as remaining_qty,
  p.held_for_laundry_qty as held_qty,
  p.rate_snapshot,
  p.remaining_eligible_amount as remaining_amount,
  p.eligibility_state as eligibility_reason
from erp.v_payroll_production_work_eligibility p
where p.remaining_eligible_qty>0

union all

select
  'REWORK'::text,
  rcl.id,
  ro.contractor_id,
  bc.po_id,
  bc.cutting_group_id,
  bc.id,
  bcc.work_component_id,
  coalesce(ro.completed_at,ro.physical_sent_at),
  rcl.qty_newly_payable,
  rcl.qty_newly_payable,
  coalesce(a.allocated_qty,0),
  greatest(rcl.qty_newly_payable-coalesce(a.allocated_qty,0),0)::integer,
  0::integer,
  rcl.rate_snapshot,
  round(greatest(rcl.qty_newly_payable-coalesce(a.allocated_qty,0),0)*rcl.rate_snapshot,2),
  'BS_CASE_RESOLVED'::text
from erp.rework_component_lines rcl
join erp.rework_orders ro on ro.id=rcl.rework_order_id
join erp.bs_case_components bcc on bcc.id=rcl.bs_case_component_id
join erp.bs_cases bc on bc.id=bcc.bs_case_id
left join lateral (
  select sum(pwi.qty_payable)::integer as allocated_qty
  from erp.payroll_work_items pwi
  join erp.payroll_settlements ps on ps.id=pwi.payroll_id
  where pwi.source_type='REWORK' and pwi.source_id=rcl.id and ps.status<>'REVERSED'
) a on true
where ro.destination_type='CONTRACTOR'
  and ro.status='COMPLETED'
  and ro.cost_posted
  and bc.status='RESOLVED'
  and greatest(rcl.qty_newly_payable-coalesce(a.allocated_qty,0),0)>0;

grant select on erp.v_payroll_production_work_eligibility,erp.v_payroll_eligible_work_lines to authenticated;
revoke all on erp.v_payroll_production_work_eligibility,erp.v_payroll_eligible_work_lines from anon;

create or replace function erp.validate_payroll_work_item_source()
returns trigger
language plpgsql
set search_path=erp,public,pg_temp
as $$
declare
  v_source_qty integer;
  v_source_component uuid;
  v_source_po uuid;
  v_source_contractor uuid;
  v_payroll_contractor uuid;
  v_already integer;
begin
  perform pg_advisory_xact_lock(hashtextextended(
    'PAYWORK|'||new.source_type||'|'||new.source_id::text||'|'||new.work_component_id::text,0
  ));
  select contractor_id into v_payroll_contractor
  from erp.payroll_settlements where id=new.payroll_id;

  if new.source_type='PRODUCTION' then
    select eligible_after_laundry_qty,work_component_id,po_id,contractor_id
    into v_source_qty,v_source_component,v_source_po,v_source_contractor
    from erp.v_payroll_production_work_eligibility
    where source_id=new.source_id;
  elsif new.source_type='REWORK' then
    select rcl.qty_newly_payable,bcc.work_component_id,bc.po_id,ro.contractor_id
    into v_source_qty,v_source_component,v_source_po,v_source_contractor
    from erp.rework_component_lines rcl
    join erp.bs_case_components bcc on bcc.id=rcl.bs_case_component_id
    join erp.bs_cases bc on bc.id=bcc.bs_case_id
    join erp.rework_orders ro on ro.id=rcl.rework_order_id
    where rcl.id=new.source_id
      and ro.destination_type='CONTRACTOR'
      and ro.status='COMPLETED'
      and ro.cost_posted
      and bc.status='RESOLVED';
  else
    raise exception 'Payroll source_type must be PRODUCTION or REWORK';
  end if;

  if v_source_qty is null then raise exception 'Payroll source is not currently eligible'; end if;
  if new.work_component_id<>v_source_component then raise exception 'Payroll work component does not match source'; end if;
  if new.po_id is distinct from v_source_po then raise exception 'Payroll PO does not match source'; end if;
  if v_source_contractor is not null and v_payroll_contractor<>v_source_contractor then
    raise exception 'Payroll contractor does not match work source';
  end if;

  select coalesce(sum(pwi.qty_payable),0) into v_already
  from erp.payroll_work_items pwi
  join erp.payroll_settlements ps on ps.id=pwi.payroll_id
  where pwi.source_type=new.source_type and pwi.source_id=new.source_id
    and pwi.work_component_id=new.work_component_id and pwi.id<>new.id
    and ps.status<>'REVERSED';
  if v_already+new.qty_payable>v_source_qty then
    raise exception 'Payroll would overpay/early-pay work source. Eligible %, already %, new %',
      v_source_qty,v_already,new.qty_payable;
  end if;
  return new;
end;
$$;

create or replace function erp.populate_payroll_draft(p_payroll_id uuid)
returns void
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
declare
  p erp.payroll_settlements%rowtype;
  r record;
  v_remaining numeric(24,6);
  v_apply numeric(24,6);
  v_budget numeric(24,6):=0;
  v_attendance_required boolean;
begin
  perform erp.require_internal();
  select * into p from erp.payroll_settlements where id=p_payroll_id for update;
  if p.id is null or p.status not in ('DRAFT','CALCULATED','REVIEW') then
    raise exception 'Payroll draft cannot be rebuilt in current status';
  end if;
  perform pg_advisory_xact_lock(hashtextextended(p.contractor_id::text,0));

  delete from erp.payroll_work_items where payroll_id=p.id;
  delete from erp.payroll_attendance_items where payroll_id=p.id;
  delete from erp.payroll_deductions where payroll_id=p.id and contractor_issue_item_id is not null;
  delete from erp.payroll_reimbursements where payroll_id=p.id and source_type='ACCESSORY_BOM';

  insert into erp.payroll_work_items(
    payroll_id,po_id,work_component_id,source_type,source_id,qty_payable,rate_snapshot
  )
  select p.id,e.po_id,e.work_component_id,e.source_type,e.source_id,e.remaining_qty,e.rate_snapshot
  from erp.v_payroll_eligible_work_lines e
  where e.contractor_id=p.contractor_id
    and e.eligible_at::date<=p.period_end
    and e.remaining_qty>0
  order by e.eligible_at,e.source_type,e.source_id;

  select attendance_required into v_attendance_required
  from erp.contractors where id=p.contractor_id;
  if v_attendance_required then
    insert into erp.payroll_attendance_items(
      payroll_id,worker_id,attendance_record_id,paid_fraction_snapshot,daily_rate_snapshot
    )
    select p.id,ar.worker_id,ar.id,ar.paid_fraction,cw.daily_rate
    from erp.attendance_records ar
    join erp.contractor_workers cw on cw.id=ar.worker_id
    where ar.contractor_id=p.contractor_id
      and ar.attendance_date between p.period_start and p.period_end
      and cw.pay_scheme in ('DAILY','HYBRID') and ar.paid_fraction>0
    order by ar.attendance_date,ar.id;
  end if;

  insert into erp.payroll_reimbursements(
    payroll_id,amount,description,source_type,source_id,po_id
  )
  select p.id,round(e.amount,2),'Accessory reimbursement from accepted GOOD FG',
         'ACCESSORY_BOM',e.id,e.po_id
  from erp.contractor_accessory_reimbursement_entitlements e
  where e.contractor_id=p.contractor_id and e.amount>0
    and e.payroll_status<>'CANCELLED' and e.physical_at::date<=p.period_end
    and not exists (
      select 1 from erp.payroll_reimbursements pr
      join erp.payroll_settlements ps2 on ps2.id=pr.payroll_id
      where pr.source_type='ACCESSORY_BOM' and pr.source_id=e.id
        and ps2.id<>p.id and ps2.status<>'REVERSED'
    )
  order by e.physical_at,e.id;

  update erp.contractor_accessory_reimbursement_entitlements e
  set payroll_status='ALLOCATED'
  where exists (
    select 1 from erp.payroll_reimbursements pr
    where pr.payroll_id=p.id and pr.source_type='ACCESSORY_BOM' and pr.source_id=e.id
  );

  perform erp.recalculate_payroll(p.id);
  select greatest(net_payable,0) into v_budget
  from erp.payroll_settlements where id=p.id;
  for r in
    select cmii.id,cmii.total_receivable,cmi.physical_at,
      cmii.total_receivable-coalesce((
        select sum(pd.amount) from erp.payroll_deductions pd
        join erp.payroll_settlements ps2 on ps2.id=pd.payroll_id
        where pd.contractor_issue_item_id=cmii.id and ps2.id<>p.id and ps2.status<>'REVERSED'
      ),0) as remaining_amount
    from erp.contractor_material_issue_items cmii
    join erp.contractor_material_issues cmi on cmi.id=cmii.issue_id
    where cmi.contractor_id=p.contractor_id and cmi.status='POSTED'
      and cmi.physical_at::date<=p.period_end
    order by cmi.physical_at,cmii.id
  loop
    exit when v_budget<=0;
    v_remaining:=greatest(r.remaining_amount,0);
    v_apply:=least(v_remaining,v_budget);
    if v_apply>0 then
      insert into erp.payroll_deductions(
        payroll_id,deduction_type,contractor_issue_item_id,amount,notes
      ) values(
        p.id,'MATERIAL_KASBON',r.id,round(v_apply,2),
        'Auto capped outstanding material/accessory kasbon (FIFO)'
      );
      v_budget:=greatest(v_budget-round(v_apply,2),0);
    end if;
  end loop;
  perform erp.recalculate_payroll(p.id);
  for r in
    select cmii.id
    from erp.contractor_material_issue_items cmii
    join erp.contractor_material_issues cmi on cmi.id=cmii.issue_id
    where cmi.contractor_id=p.contractor_id and cmi.status='POSTED'
  loop
    perform erp.refresh_contractor_issue_payroll_status(r.id);
  end loop;
end;
$$;

create or replace function erp.merge_eligible_work_into_payroll_v2(
  p_payroll_id uuid,
  p_lines jsonb,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_payroll erp.payroll_settlements%rowtype;
  v_line jsonb;
  v_eligible record;
  v_qty integer;
  v_added_qty integer:=0;
  v_added_amount numeric(24,2):=0;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if coalesce(jsonb_typeof(p_lines),'null')<>'array' then
    raise exception 'Eligible lines must be a JSON array';
  end if;
  if jsonb_array_length(p_lines)=0 then raise exception 'At least one eligible line is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'payroll_id',p_payroll_id,'lines',p_lines,'expected_version',p_expected_version
  ));
  v_cached:=erp._idempotency_begin('merge_eligible_work_into_payroll_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_payroll from erp.payroll_settlements where id=p_payroll_id for update;
  if v_payroll.id is null then raise exception 'Nota payroll not found'; end if;
  if v_payroll.status not in ('DRAFT','CALCULATED','REVIEW') then
    raise exception 'APPROVED/PAID/REVERSED Nota is locked; use reversal/correction';
  end if;
  if v_payroll.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_payroll.row_version;
  end if;
  perform pg_advisory_xact_lock(hashtextextended(v_payroll.contractor_id::text,0));

  for v_line in
    select value from jsonb_array_elements(p_lines)
    order by value->>'source_type',value->>'source_id'
  loop
    if upper(v_line->>'source_type')='PRODUCTION' then
      perform 1 from erp.work_completion_lines
      where id=(v_line->>'source_id')::uuid for update;
    elsif upper(v_line->>'source_type')='REWORK' then
      perform 1 from erp.rework_component_lines
      where id=(v_line->>'source_id')::uuid for update;
    else
      raise exception 'Unknown eligible source_type';
    end if;

    select * into v_eligible
    from erp.v_payroll_eligible_work_lines e
    where e.source_type=upper(v_line->>'source_type')
      and e.source_id=(v_line->>'source_id')::uuid;
    if v_eligible.source_id is null then raise exception 'Selected work line is no longer eligible'; end if;
    if v_eligible.contractor_id<>v_payroll.contractor_id then
      raise exception 'Eligible work belongs to a different Mandor';
    end if;
    if v_eligible.eligible_at::date>v_payroll.period_end then
      raise exception 'Eligible work is after the Nota period end';
    end if;
    v_qty:=coalesce(nullif(v_line->>'qty','')::integer,v_eligible.remaining_qty);
    if v_qty<=0 or v_qty>v_eligible.remaining_qty then
      raise exception 'Requested qty % exceeds remaining eligible qty %',v_qty,v_eligible.remaining_qty;
    end if;
    insert into erp.payroll_work_items(
      payroll_id,po_id,work_component_id,source_type,source_id,qty_payable,rate_snapshot
    ) values(
      v_payroll.id,v_eligible.po_id,v_eligible.work_component_id,
      v_eligible.source_type,v_eligible.source_id,v_qty,v_eligible.rate_snapshot
    );
    v_added_qty:=v_added_qty+v_qty;
    v_added_amount:=v_added_amount+round(v_qty*v_eligible.rate_snapshot,2);
  end loop;

  perform erp.recalculate_payroll(v_payroll.id);
  select * into v_payroll from erp.payroll_settlements where id=v_payroll.id;
  v_response:=jsonb_build_object(
    'payroll_id',v_payroll.id,'status',v_payroll.status,
    'row_version',v_payroll.row_version,'added_qty',v_added_qty,
    'added_amount',v_added_amount,'net_payable',v_payroll.net_payable
  );
  return erp._idempotency_complete('merge_eligible_work_into_payroll_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.ensure_po_work_component_snapshots_v2(
  p_po_id uuid,
  p_basis_at timestamptz,
  p_client_request_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_count integer;
begin
  perform erp.require_internal();
  if p_basis_at is null or p_basis_at>clock_timestamp()+interval '5 minutes' then
    raise exception 'Valid non-future basis_at is required';
  end if;
  v_hash:=erp._request_hash(jsonb_build_object('po_id',p_po_id,'basis_at',p_basis_at));
  v_cached:=erp._idempotency_begin('ensure_po_work_component_snapshots_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  v_count:=erp.ensure_po_work_component_snapshots(p_po_id,p_basis_at);
  v_response:=jsonb_build_object(
    'po_id',p_po_id,'component_count',v_count,'committed_at',p_basis_at,
    'components',coalesce((
      select jsonb_agg(jsonb_build_object(
        'snapshot_id',s.id,'work_component_id',s.work_component_id,
        'sequence_no',s.sequence_no,'rate_per_pcs_snapshot',s.rate_per_pcs_snapshot
      ) order by s.sequence_no,s.id)
      from erp.po_work_component_snapshots s where s.po_id=p_po_id
    ),'[]'::jsonb)
  );
  return erp._idempotency_complete('ensure_po_work_component_snapshots_v2',p_client_request_id,v_response);
end;
$$;

revoke insert,update,delete on erp.payroll_work_items from public,anon,authenticated;
revoke all on function erp.merge_eligible_work_into_payroll_v2(uuid,jsonb,uuid,bigint) from public;
revoke all on function erp.ensure_po_work_component_snapshots_v2(uuid,timestamptz,uuid) from public;
grant execute on function erp.merge_eligible_work_into_payroll_v2(uuid,jsonb,uuid,bigint) to authenticated,service_role;
grant execute on function erp.ensure_po_work_component_snapshots_v2(uuid,timestamptz,uuid) to authenticated,service_role;

create or replace function erp.run_v263a_payroll_integrity_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language sql
stable
security definer
set search_path=erp,public,pg_temp
as $$
  select
    'production_payroll_exceeds_laundry_release','CRITICAL',count(*)::bigint,
    'Allocated production payroll qty must not exceed physical laundry-return eligibility'
  from erp.v_payroll_production_work_eligibility e
  where e.allocated_to_nonreversed_payroll_qty>e.eligible_after_laundry_qty

  union all
  select
    'rework_payroll_before_case_resolution','CRITICAL',count(*)::bigint,
    'Rework Nota lines require COMPLETED+cost_posted rework and a RESOLVED BS case'
  from erp.payroll_work_items pwi
  join erp.payroll_settlements ps on ps.id=pwi.payroll_id and ps.status<>'REVERSED'
  join erp.rework_component_lines rcl on pwi.source_type='REWORK' and rcl.id=pwi.source_id
  join erp.rework_orders ro on ro.id=rcl.rework_order_id
  join erp.bs_case_components bcc on bcc.id=rcl.bs_case_component_id
  join erp.bs_cases bc on bc.id=bcc.bs_case_id
  where ro.status<>'COMPLETED' or not ro.cost_posted or bc.status<>'RESOLVED'

  union all
  select
    'payroll_work_wrong_contractor','CRITICAL',count(*)::bigint,
    'Every Nota work line must belong to the Nota Mandor'
  from erp.payroll_work_items pwi
  join erp.payroll_settlements ps on ps.id=pwi.payroll_id
  left join erp.work_completion_lines wcl on pwi.source_type='PRODUCTION' and wcl.id=pwi.source_id
  left join erp.work_completion_events wce on wce.id=wcl.completion_id
  left join erp.rework_component_lines rcl on pwi.source_type='REWORK' and rcl.id=pwi.source_id
  left join erp.rework_orders ro on ro.id=rcl.rework_order_id
  where ps.status<>'REVERSED'
    and ps.contractor_id is distinct from coalesce(wce.contractor_id,ro.contractor_id);
$$;

revoke all on function erp.run_v263a_payroll_integrity_checks() from public;
grant execute on function erp.run_v263a_payroll_integrity_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.3a',
  'Laundry-aware payroll hold/release, eligible Nota read model, atomic merge, and work snapshot wrapper',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828072332','erp_v263a_payroll_hold_nota',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828072332 erp_v263a_payroll_hold_nota

-- BEGIN PLATFORM MIGRATION 20260828072451 erp_v263a1_nota_increment
-- ERP Garment v2.6.3a1
-- Allow an unlocked Nota to absorb additional eligible qty released by a late receipt.

set lock_timeout = '10s';
set statement_timeout = '60s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_3a1',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.3a') then
    raise exception 'ERP Garment v2.6.3a is required before v2.6.3a1';
  end if;
end;
$$;

create or replace function erp.merge_eligible_work_into_payroll_v2(
  p_payroll_id uuid,
  p_lines jsonb,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_payroll erp.payroll_settlements%rowtype;
  v_line jsonb;
  v_eligible record;
  v_qty integer;
  v_added_qty integer:=0;
  v_added_amount numeric(24,2):=0;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if coalesce(jsonb_typeof(p_lines),'null')<>'array' then
    raise exception 'Eligible lines must be a JSON array';
  end if;
  if jsonb_array_length(p_lines)=0 then raise exception 'At least one eligible line is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'payroll_id',p_payroll_id,'lines',p_lines,'expected_version',p_expected_version
  ));
  v_cached:=erp._idempotency_begin('merge_eligible_work_into_payroll_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_payroll from erp.payroll_settlements where id=p_payroll_id for update;
  if v_payroll.id is null then raise exception 'Nota payroll not found'; end if;
  if v_payroll.status not in ('DRAFT','CALCULATED','REVIEW') then
    raise exception 'APPROVED/PAID/REVERSED Nota is locked; use reversal/correction';
  end if;
  if v_payroll.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_payroll.row_version;
  end if;
  perform pg_advisory_xact_lock(hashtextextended(v_payroll.contractor_id::text,0));

  for v_line in
    select value from jsonb_array_elements(p_lines)
    order by value->>'source_type',value->>'source_id'
  loop
    if upper(v_line->>'source_type')='PRODUCTION' then
      perform 1 from erp.work_completion_lines
      where id=(v_line->>'source_id')::uuid for update;
    elsif upper(v_line->>'source_type')='REWORK' then
      perform 1 from erp.rework_component_lines
      where id=(v_line->>'source_id')::uuid for update;
    else
      raise exception 'Unknown eligible source_type';
    end if;

    select * into v_eligible
    from erp.v_payroll_eligible_work_lines e
    where e.source_type=upper(v_line->>'source_type')
      and e.source_id=(v_line->>'source_id')::uuid;
    if v_eligible.source_id is null then raise exception 'Selected work line is no longer eligible'; end if;
    if v_eligible.contractor_id<>v_payroll.contractor_id then
      raise exception 'Eligible work belongs to a different Mandor';
    end if;
    if v_eligible.eligible_at::date>v_payroll.period_end then
      raise exception 'Eligible work is after the Nota period end';
    end if;
    v_qty:=coalesce(nullif(v_line->>'qty','')::integer,v_eligible.remaining_qty);
    if v_qty<=0 or v_qty>v_eligible.remaining_qty then
      raise exception 'Requested qty % exceeds remaining eligible qty %',v_qty,v_eligible.remaining_qty;
    end if;
    insert into erp.payroll_work_items(
      payroll_id,po_id,work_component_id,source_type,source_id,qty_payable,rate_snapshot
    ) values(
      v_payroll.id,v_eligible.po_id,v_eligible.work_component_id,
      v_eligible.source_type,v_eligible.source_id,v_qty,v_eligible.rate_snapshot
    )
    on conflict (payroll_id,source_type,source_id,work_component_id) do update
    set qty_payable=erp.payroll_work_items.qty_payable+excluded.qty_payable,
        rate_snapshot=excluded.rate_snapshot;
    v_added_qty:=v_added_qty+v_qty;
    v_added_amount:=v_added_amount+round(v_qty*v_eligible.rate_snapshot,2);
  end loop;

  perform erp.recalculate_payroll(v_payroll.id);
  select * into v_payroll from erp.payroll_settlements where id=v_payroll.id;
  v_response:=jsonb_build_object(
    'payroll_id',v_payroll.id,'status',v_payroll.status,
    'row_version',v_payroll.row_version,'added_qty',v_added_qty,
    'added_amount',v_added_amount,'net_payable',v_payroll.net_payable
  );
  return erp._idempotency_complete('merge_eligible_work_into_payroll_v2',p_client_request_id,v_response);
end;
$$;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.3a1',
  'Increment an existing unlocked Nota source line when a late receipt releases additional eligible quantity',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828072451','erp_v263a1_nota_increment',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828072451 erp_v263a1_nota_increment

-- BEGIN PLATFORM MIGRATION 20260828073640 erp_v263b_laundry_bs_lineage
-- ERP Garment v2.6.3b
-- Laundry receipt aggregate CRUD, BS product lineage, late-claim guard,
-- and payroll-safe receipt reversal.
--
-- Deployment contract:
--   1. Apply to ERP Enteng and run rollback stress tests.
--   2. Replay this exact file to ERP-Garment only after ERP Enteng passes.
--   3. Posted receipt data is corrected by reversal, never direct edit/delete.

set lock_timeout = '10s';
set statement_timeout = '180s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_3b', 0));

do $$
begin
  if not exists (select 1 from erp.schema_migrations where version='v2.6.3a')
     or not exists (select 1 from erp.schema_migrations where version='v2.6.2')
     or to_regprocedure('erp._idempotency_begin(text,uuid,text)') is null
     or to_regprocedure('erp.merge_eligible_work_into_payroll_v2(uuid,jsonb,uuid,bigint)') is null
  then
    raise exception 'ERP Garment v2.6.2 and v2.6.3a are required before v2.6.3b';
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. Optimistic versions on the affected aggregate roots
-- ---------------------------------------------------------------------------

do $$
declare v_table text;
begin
  foreach v_table in array array['laundry_receipts','bs_cases','rework_orders','laundry_claims']
  loop
    execute format(
      'alter table erp.%I add column if not exists row_version bigint not null default 1 check (row_version>0)',
      v_table
    );
    execute format('drop trigger if exists trg_00_bump_row_version on erp.%I',v_table);
    execute format(
      'create trigger trg_00_bump_row_version before update on erp.%I for each row execute function erp.bump_row_version()',
      v_table
    );
  end loop;
end;
$$;

-- ---------------------------------------------------------------------------
-- 2. Explicit product/size allocation for every laundry BS quantity
-- ---------------------------------------------------------------------------

create table erp.laundry_receipt_bs_product_allocations (
  id uuid primary key default gen_random_uuid(),
  receipt_line_id uuid not null references erp.laundry_receipt_lines(id) on delete cascade,
  product_id uuid not null references erp.products(id),
  qty_bs integer not null check(qty_bs>0),
  notes text,
  created_by uuid references erp.app_users(id),
  created_at timestamptz not null default now(),
  unique(receipt_line_id,product_id)
);

create index idx_laundry_bs_alloc_product
  on erp.laundry_receipt_bs_product_allocations(product_id);

alter table erp.laundry_receipt_bs_product_allocations enable row level security;
create policy internal_read on erp.laundry_receipt_bs_product_allocations
  for select to authenticated
  using (erp.current_app_role() in ('OWNER','ADMIN','STAFF'));
grant select on erp.laundry_receipt_bs_product_allocations to authenticated;
revoke insert,update,delete on erp.laundry_receipt_bs_product_allocations
  from public,anon,authenticated;

alter table erp.bs_cases
  add column if not exists source_laundry_receipt_line_id uuid
    references erp.laundry_receipt_lines(id),
  add column if not exists source_laundry_bs_allocation_id uuid
    references erp.laundry_receipt_bs_product_allocations(id),
  add column if not exists legacy_reference text;

create unique index if not exists uq_bs_cases_laundry_allocation
  on erp.bs_cases(source_laundry_bs_allocation_id)
  where source_laundry_bs_allocation_id is not null;
create index if not exists idx_bs_cases_laundry_receipt_line
  on erp.bs_cases(source_laundry_receipt_line_id)
  where source_laundry_receipt_line_id is not null;

create or replace function erp.validate_laundry_bs_product_allocation()
returns trigger
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
declare
  v_status text;
  v_physical_at timestamptz;
  v_po_model uuid;
  v_product_model uuid;
  v_product_size uuid;
  v_group uuid;
begin
  select lr.status,lr.physical_at,po.model_id,p.model_id,p.size_id,ldl.cutting_group_id
  into v_status,v_physical_at,v_po_model,v_product_model,v_product_size,v_group
  from erp.laundry_receipt_lines lrl
  join erp.laundry_receipts lr on lr.id=lrl.receipt_id
  join erp.laundry_delivery_lines ldl on ldl.id=lrl.delivery_line_id
  join erp.laundry_deliveries ld on ld.id=ldl.delivery_id
  join erp.production_orders po on po.id=ld.po_id
  join erp.products p on p.id=new.product_id
  where lrl.id=new.receipt_line_id;

  if v_status is null then raise exception 'Laundry receipt line/product not found'; end if;
  if v_status<>'DRAFT' then raise exception 'Laundry BS product allocation is editable only while receipt is DRAFT'; end if;
  if v_product_model is distinct from v_po_model then
    raise exception 'Laundry BS product model does not match the production order model';
  end if;
  if not exists(
    select 1 from erp.cutting_group_size_slots s
    where s.cutting_group_id=v_group and s.size_id=v_product_size
  ) then
    raise exception 'Laundry BS product size is not present in the source Potongan';
  end if;
  perform erp.assert_product_identity_time(new.product_id,v_physical_at,'NEW_STOCK');
  new.created_by:=coalesce(new.created_by,erp.current_app_user_id());
  return new;
end;
$$;

drop trigger if exists trg_validate_laundry_bs_product_allocation
  on erp.laundry_receipt_bs_product_allocations;
create trigger trg_validate_laundry_bs_product_allocation
before insert or update on erp.laundry_receipt_bs_product_allocations
for each row execute function erp.validate_laundry_bs_product_allocation();

create or replace function erp.touch_laundry_receipt_from_bs_allocation()
returns trigger
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
declare v_line uuid:=case when tg_op='DELETE' then old.receipt_line_id else new.receipt_line_id end;
begin
  update erp.laundry_receipts lr
  set updated_at=now()
  from erp.laundry_receipt_lines lrl
  where lrl.id=v_line and lr.id=lrl.receipt_id and lr.status='DRAFT';
  if tg_op='DELETE' then return old; else return new; end if;
end;
$$;

drop trigger if exists trg_touch_laundry_receipt_from_bs_allocation
  on erp.laundry_receipt_bs_product_allocations;
create trigger trg_touch_laundry_receipt_from_bs_allocation
after insert or update or delete on erp.laundry_receipt_bs_product_allocations
for each row execute function erp.touch_laundry_receipt_from_bs_allocation();

-- Native QC/laundry BS automatically snapshots which work components were
-- already completed at the time BS was detected. This is the server-side
-- basis for preventing duplicate component pay on later rework.
create or replace function erp.seed_bs_case_component_baseline()
returns trigger
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
begin
  if new.po_id is null then return new; end if;
  insert into erp.bs_case_components(
    bs_case_id,po_component_snapshot_id,work_component_id,
    completed_before_bs_qty,notes
  )
  select
    new.id,s.id,s.work_component_id,
    least(
      new.qty_pcs,
      coalesce((
        select sum(wcl.qty_completed)::integer
        from erp.work_completion_lines wcl
        join erp.work_completion_events wce on wce.id=wcl.completion_id
        where wce.po_id=new.po_id
          and wcl.work_component_id=s.work_component_id
          and wce.status='POSTED'
          and wce.physical_at<=new.physical_at
          and (new.cutting_group_id is null or wce.cutting_group_id=new.cutting_group_id)
      ),0)
    ),
    'Auto baseline from posted work history at BS detection'
  from erp.po_work_component_snapshots s
  where s.po_id=new.po_id
  on conflict(bs_case_id,work_component_id) do nothing;
  return new;
end;
$$;

drop trigger if exists trg_seed_bs_case_component_baseline on erp.bs_cases;
create trigger trg_seed_bs_case_component_baseline
after insert on erp.bs_cases
for each row execute function erp.seed_bs_case_component_baseline();

-- ---------------------------------------------------------------------------
-- 3. Safe aggregate draft save/delete for laundry receipts
-- ---------------------------------------------------------------------------

create or replace function erp.save_laundry_receipt_draft_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_receipt erp.laundry_receipts%rowtype;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_action text:=upper(coalesce(nullif(btrim(p_payload->>'action'),''),'SAVE'));
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  v_line jsonb;
  v_allocation jsonb;
  v_line_id uuid;
begin
  perform erp.require_internal();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if v_action not in ('SAVE','DELETE') then raise exception 'Invalid laundry receipt action'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'payload',p_payload,'expected_version',p_expected_version
  ));
  v_cached:=erp._idempotency_begin('save_laundry_receipt_draft_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',v_reason,true);

  if v_id is null then
    if v_action='DELETE' then raise exception 'Laundry receipt id is required for DELETE'; end if;
    if p_expected_version is not null then raise exception 'expected_version must be null when creating a receipt'; end if;
    if coalesce(btrim(p_payload->>'receipt_number'),'')='' then raise exception 'receipt_number is required'; end if;
    insert into erp.laundry_receipts(
      receipt_number,delivery_id,physical_at,status,created_by
    ) values(
      btrim(p_payload->>'receipt_number'),(p_payload->>'delivery_id')::uuid,
      (p_payload->>'physical_at')::timestamptz,'DRAFT',erp.current_app_user_id()
    ) returning * into v_receipt;
    v_id:=v_receipt.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into v_receipt from erp.laundry_receipts where id=v_id for update;
    if v_receipt.id is null then raise exception 'Laundry receipt not found'; end if;
    if v_receipt.status<>'DRAFT' then raise exception 'Posted receipt is locked; use reversal/correction'; end if;
    if v_receipt.row_version<>p_expected_version then
      raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_receipt.row_version;
    end if;
    if v_action='DELETE' then
      delete from erp.laundry_receipts where id=v_id;
      v_response:=jsonb_build_object('laundry_receipt_id',v_id,'status','DELETED');
      return erp._idempotency_complete('save_laundry_receipt_draft_v2',p_client_request_id,v_response);
    end if;
    update erp.laundry_receipts
    set receipt_number=coalesce(nullif(btrim(p_payload->>'receipt_number'),''),v_receipt.receipt_number),
        delivery_id=case when p_payload?'delivery_id' then (p_payload->>'delivery_id')::uuid else v_receipt.delivery_id end,
        physical_at=case when p_payload?'physical_at' then (p_payload->>'physical_at')::timestamptz else v_receipt.physical_at end,
        updated_at=now()
    where id=v_id returning * into v_receipt;
  end if;

  if p_payload?'lines' then
    if jsonb_typeof(p_payload->'lines')<>'array' then raise exception 'lines must be an array'; end if;
    delete from erp.laundry_receipt_lines where receipt_id=v_id;
    for v_line in select value from jsonb_array_elements(p_payload->'lines')
    loop
      v_line_id:=coalesce(nullif(v_line->>'id','')::uuid,gen_random_uuid());
      insert into erp.laundry_receipt_lines(
        id,receipt_id,delivery_line_id,actual_wash_process_id,
        qty_good_received,qty_bs_laundry,qty_stuck,qty_missing,
        actual_rate_snapshot,actual_cost_status,actual_cost,notes
      ) values(
        v_line_id,v_id,(v_line->>'delivery_line_id')::uuid,
        nullif(v_line->>'actual_wash_process_id','')::uuid,
        coalesce(nullif(v_line->>'qty_good_received','')::integer,0),
        coalesce(nullif(v_line->>'qty_bs_laundry','')::integer,0),
        coalesce(nullif(v_line->>'qty_stuck','')::integer,0),
        coalesce(nullif(v_line->>'qty_missing','')::integer,0),
        nullif(v_line->>'actual_rate_snapshot','')::numeric,
        upper(coalesce(nullif(v_line->>'actual_cost_status',''),'PENDING')),
        nullif(v_line->>'actual_cost','')::numeric,
        nullif(btrim(v_line->>'notes'),'')
      );
      if v_line?'bs_allocations' then
        if jsonb_typeof(v_line->'bs_allocations')<>'array' then
          raise exception 'bs_allocations must be an array';
        end if;
        for v_allocation in select value from jsonb_array_elements(v_line->'bs_allocations')
        loop
          insert into erp.laundry_receipt_bs_product_allocations(
            id,receipt_line_id,product_id,qty_bs,notes,created_by
          ) values(
            coalesce(nullif(v_allocation->>'id','')::uuid,gen_random_uuid()),
            v_line_id,(v_allocation->>'product_id')::uuid,
            (v_allocation->>'qty_bs')::integer,
            nullif(btrim(v_allocation->>'notes'),''),erp.current_app_user_id()
          );
        end loop;
      end if;
    end loop;
    update erp.laundry_receipts set updated_at=now() where id=v_id returning * into v_receipt;
  end if;

  select * into v_receipt from erp.laundry_receipts where id=v_id;
  v_response:=jsonb_build_object(
    'laundry_receipt_id',v_receipt.id,'status',v_receipt.status,
    'row_version',v_receipt.row_version,
    'line_count',(select count(*) from erp.laundry_receipt_lines where receipt_id=v_receipt.id),
    'lines',coalesce((
      select jsonb_agg(jsonb_build_object(
        'receipt_line_id',l.id,'delivery_line_id',l.delivery_line_id,
        'qty_good_received',l.qty_good_received,'qty_bs_laundry',l.qty_bs_laundry,
        'qty_stuck',l.qty_stuck,'qty_missing',l.qty_missing,
        'bs_allocations',coalesce((select jsonb_agg(jsonb_build_object(
          'allocation_id',a.id,'product_id',a.product_id,'qty_bs',a.qty_bs
        ) order by a.id) from erp.laundry_receipt_bs_product_allocations a
        where a.receipt_line_id=l.id),'[]'::jsonb)
      ) order by l.id) from erp.laundry_receipt_lines l where l.receipt_id=v_receipt.id
    ),'[]'::jsonb)
  );
  return erp._idempotency_complete('save_laundry_receipt_draft_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 4. Authoritative posting with lineage and late final-claim protection
-- ---------------------------------------------------------------------------

create or replace function erp.post_laundry_receipt(p_receipt_id uuid)
returns void
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
declare
  h erp.laundry_receipts%rowtype;
  d erp.laundry_deliveries%rowtype;
  r record;
  a record;
  v_sent bigint;
  v_returned bigint;
  v_allocated integer;
  v_bs_number text;
begin
  perform erp.require_internal();
  select * into h from erp.laundry_receipts where id=p_receipt_id for update;
  if h.id is null or h.status<>'DRAFT' then raise exception 'Laundry receipt must be DRAFT'; end if;
  select * into d from erp.laundry_deliveries where id=h.delivery_id for update;
  if d.status not in ('SENT','PARTIAL_RETURN') then raise exception 'Laundry delivery must already be sent'; end if;
  if not exists(select 1 from erp.laundry_receipt_lines where receipt_id=h.id) then
    raise exception 'Laundry receipt has no lines';
  end if;

  for r in
    select lrl.*,ldl.cutting_group_id
    from erp.laundry_receipt_lines lrl
    join erp.laundry_delivery_lines ldl on ldl.id=lrl.delivery_line_id
    where lrl.receipt_id=h.id order by lrl.id
  loop
    select coalesce(sum(x.qty_bs),0)::integer into v_allocated
    from erp.laundry_receipt_bs_product_allocations x where x.receipt_line_id=r.id;
    if v_allocated<>r.qty_bs_laundry then
      raise exception 'Laundry BS product allocation % must equal BS qty % for receipt line %',
        v_allocated,r.qty_bs_laundry,r.id;
    end if;

    if r.qty_good_received+r.qty_bs_laundry>0 and exists(
      select 1
      from erp.laundry_claims lc
      left join erp.laundry_receipt_lines prior_line on prior_line.id=lc.receipt_line_id
      where lc.status in ('SETTLED','WRITTEN_OFF')
        and lc.claim_type in ('MISSING','STUCK')
        and (
          prior_line.delivery_line_id=r.delivery_line_id
          or (lc.receipt_line_id is null and lc.delivery_id=d.id)
        )
    ) then
      raise exception 'Late physical return is blocked after a STUCK/MISSING claim is SETTLED/WRITTEN_OFF; reverse the claim resolution first';
    end if;

    if r.qty_good_received+r.qty_bs_laundry>0 then
      insert into erp.wip_stage_events(
        po_id,cutting_group_id,stage_from,stage_to,qty_pcs,
        source_type,source_id,physical_at,created_by,notes
      ) values(
        d.po_id,r.cutting_group_id,'LAUNDRY','QC',r.qty_good_received+r.qty_bs_laundry,
        'LAUNDRY_RECEIPT_LINE',r.id,h.physical_at,erp.current_app_user_id(),
        'Physically returned from laundry'
      );
      update erp.cutting_groups set status='RETURNED' where id=r.cutting_group_id;
    end if;

    for a in
      select * from erp.laundry_receipt_bs_product_allocations
      where receipt_line_id=r.id order by id
    loop
      perform erp.assert_product_identity_time(a.product_id,h.physical_at,'NEW_STOCK');
      v_bs_number:='BS-LAU-'||left(h.receipt_number,28)||'-'||substr(r.id::text,1,8)||'-'||substr(a.id::text,1,6);
      insert into erp.bs_cases(
        bs_number,po_id,cutting_group_id,product_id,
        source_laundry_receipt_line_id,source_laundry_bs_allocation_id,
        detected_at_stage,cause_source,responsible_vendor_id,
        qty_pcs,status,physical_at,notes
      ) values(
        v_bs_number,d.po_id,r.cutting_group_id,a.product_id,r.id,a.id,
        'LAUNDRY','LAUNDRY',d.vendor_id,a.qty_bs,'OPEN',h.physical_at,
        'Auto-created from laundry receipt with product/size lineage'
      ) on conflict(source_laundry_bs_allocation_id) where source_laundry_bs_allocation_id is not null do nothing;
    end loop;
  end loop;

  update erp.laundry_receipts set status='POSTED',updated_at=now() where id=h.id;
  select coalesce(sum(qty_sent_pcs),0) into v_sent
  from erp.laundry_delivery_lines where delivery_id=d.id;
  select coalesce(sum(lrl.qty_good_received+lrl.qty_bs_laundry),0) into v_returned
  from erp.laundry_receipt_lines lrl
  join erp.laundry_receipts lr on lr.id=lrl.receipt_id
  where lr.delivery_id=d.id and lr.status='POSTED';
  update erp.laundry_deliveries
  set status=case when v_returned>=v_sent then 'RETURNED' else 'PARTIAL_RETURN' end,
      updated_at=now()
  where id=d.id;
  if v_returned>0 then
    update erp.production_orders set status='QC',current_stage='QC',updated_at=now() where id=d.po_id;
  end if;
  perform erp.sync_laundry_accrual(d.po_id,h.physical_at::date);
  if exists(select 1 from erp.fg_lots where po_id=d.po_id) then
    perform erp.rebuild_po_hpp(d.po_id,'Laundry receipt posted/corrected');
    perform erp.propagate_conversion_hpp_for_po(d.po_id);
    perform erp.sync_po_hpp_to_gl(d.po_id,h.physical_at::date);
  end if;
end;
$$;

create or replace function erp.post_laundry_receipt_v2(
  p_receipt_id uuid,
  p_client_request_id uuid,
  p_expected_version bigint,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_receipt erp.laundry_receipts%rowtype;
begin
  perform erp.require_internal();
  if nullif(btrim(p_reason),'') is null then raise exception 'Posting reason is required'; end if;
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'receipt_id',p_receipt_id,'expected_version',p_expected_version,'reason',btrim(p_reason)
  ));
  v_cached:=erp._idempotency_begin('post_laundry_receipt_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  select * into v_receipt from erp.laundry_receipts where id=p_receipt_id for update;
  if v_receipt.id is null then raise exception 'Laundry receipt not found'; end if;
  if v_receipt.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_receipt.row_version;
  end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  perform erp.post_laundry_receipt(p_receipt_id);
  select * into v_receipt from erp.laundry_receipts where id=p_receipt_id;
  v_response:=jsonb_build_object(
    'laundry_receipt_id',v_receipt.id,'status',v_receipt.status,
    'row_version',v_receipt.row_version,
    'bs_case_count',(select count(*) from erp.bs_cases where source_laundry_receipt_line_id in(
      select id from erp.laundry_receipt_lines where receipt_id=v_receipt.id
    ))
  );
  return erp._idempotency_complete('post_laundry_receipt_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 5. Reversal cannot retract payroll eligibility already allocated to a Nota
-- ---------------------------------------------------------------------------

create or replace function erp.assert_laundry_receipt_reversal_payroll_safe(p_receipt_id uuid)
returns void
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
declare r record;v_release integer;
begin
  for r in
    select wce.cutting_group_id,wcl.work_component_id,
           coalesce(sum(pwi.qty_payable),0)::integer allocated_qty
    from erp.payroll_work_items pwi
    join erp.payroll_settlements ps on ps.id=pwi.payroll_id and ps.status<>'REVERSED'
    join erp.work_completion_lines wcl on pwi.source_type='PRODUCTION' and wcl.id=pwi.source_id
    join erp.work_completion_events wce on wce.id=wcl.completion_id
    where wce.cutting_group_id in(
      select ldl.cutting_group_id
      from erp.laundry_receipt_lines lrl
      join erp.laundry_delivery_lines ldl on ldl.id=lrl.delivery_line_id
      where lrl.receipt_id=p_receipt_id
    )
    group by wce.cutting_group_id,wcl.work_component_id
  loop
    select coalesce(sum(lrl.qty_good_received+lrl.qty_bs_laundry),0)::integer
    into v_release
    from erp.laundry_receipt_lines lrl
    join erp.laundry_receipts lr on lr.id=lrl.receipt_id and lr.status='POSTED'
    join erp.laundry_delivery_lines ldl on ldl.id=lrl.delivery_line_id
    where ldl.cutting_group_id=r.cutting_group_id and lr.id<>p_receipt_id;
    if r.allocated_qty>v_release then
      raise exception 'Laundry receipt reversal would retract payroll eligibility below allocated Nota qty for Potongan/component; reverse affected Nota first';
    end if;
  end loop;
end;
$$;

create or replace function erp.reverse_laundry_receipt(p_receipt_id uuid,p_reason text)
returns void
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
declare
  h erp.laundry_receipts%rowtype;
  d erp.laundry_deliveries%rowtype;
  r record;
  b record;
  v_sent bigint;
  v_returned bigint;
  v_po_status text;
begin
  perform erp.require_owner_admin();
  if nullif(btrim(p_reason),'') is null then raise exception 'Alasan reversal penerimaan laundry wajib diisi'; end if;
  select * into h from erp.laundry_receipts where id=p_receipt_id for update;
  if h.id is null then raise exception 'Penerimaan laundry tidak ditemukan'; end if;
  if h.status='REVERSED' then return; end if;
  if h.status<>'POSTED' then raise exception 'Hanya penerimaan laundry POSTED yang dapat direverse'; end if;
  select * into d from erp.laundry_deliveries where id=h.delivery_id for update;
  if d.id is null or d.status='REVERSED' then raise exception 'Pengiriman laundry sumber tidak aktif'; end if;
  select status into v_po_status from erp.production_orders where id=d.po_id for update;
  if v_po_status='FINISHED' then
    raise exception 'PO sudah FINISHED. Reopen/koreksi transaksi downstream terlebih dahulu sebelum reversal penerimaan laundry.';
  end if;

  perform erp.assert_laundry_receipt_reversal_payroll_safe(h.id);
  if exists(
    select 1 from erp.qc_inspection_items qi
    join erp.qc_inspections qh on qh.id=qi.inspection_id
    where qi.source_laundry_receipt_line_id in(select id from erp.laundry_receipt_lines where receipt_id=h.id)
      and qh.status<>'REVERSED'
  ) then raise exception 'Penerimaan laundry ini sudah dipakai QC. Reverse QC aktif terlebih dahulu.'; end if;
  if exists(
    select 1 from erp.vendor_invoice_items vii join erp.vendor_invoices vi on vi.id=vii.invoice_id
    where vii.receipt_line_id in(select id from erp.laundry_receipt_lines where receipt_id=h.id)
      and vi.status<>'REVERSED'
  ) then raise exception 'Penerimaan laundry ini sudah masuk invoice vendor. Reverse invoice vendor aktif terlebih dahulu.'; end if;
  if exists(
    select 1 from erp.laundry_claims lc
    where (lc.receipt_line_id in(select id from erp.laundry_receipt_lines where receipt_id=h.id) or lc.delivery_id=d.id)
      and lc.status<>'REJECTED'
  ) then raise exception 'Penerimaan/delivery laundry ini sudah memiliki claim aktif/terselesaikan. Bereskan claim terlebih dahulu.'; end if;

  for r in select * from erp.laundry_receipt_lines where receipt_id=h.id and qty_bs_laundry>0
  loop
    for b in
      select * from erp.bs_cases bc
      where bc.source_laundry_receipt_line_id=r.id
         or bc.bs_number='BS-LAU-'||h.receipt_number||'-'||substr(r.id::text,1,8)
      for update
    loop
      if exists(select 1 from erp.rework_orders where bs_case_id=b.id and status<>'CANCELLED')
         or exists(select 1 from erp.bs_resolutions where bs_case_id=b.id) then
        raise exception 'BS dari penerimaan laundry ini sudah diproses/rework. Batalkan downstream BS terlebih dahulu.';
      end if;
      update erp.bs_cases
      set status='CANCELLED',notes=concat_ws(E'\n',notes,'CANCELLED karena source laundry receipt direverse: '||p_reason),updated_at=now()
      where id=b.id;
    end loop;
  end loop;

  update erp.laundry_receipts set status='REVERSED',updated_at=now() where id=h.id;
  select coalesce(sum(qty_sent_pcs),0) into v_sent from erp.laundry_delivery_lines where delivery_id=d.id;
  select coalesce(sum(lrl.qty_good_received+lrl.qty_bs_laundry),0) into v_returned
  from erp.laundry_receipt_lines lrl join erp.laundry_receipts lr on lr.id=lrl.receipt_id
  where lr.delivery_id=d.id and lr.status='POSTED';
  update erp.laundry_deliveries
  set status=case when v_returned>=v_sent and v_sent>0 then 'RETURNED'
                  when v_returned>0 then 'PARTIAL_RETURN' else 'SENT' end,
      updated_at=now()
  where id=d.id;

  for r in
    select distinct ldl.cutting_group_id
    from erp.laundry_receipt_lines lrl
    join erp.laundry_delivery_lines ldl on ldl.id=lrl.delivery_line_id
    where lrl.receipt_id=h.id
  loop
    if exists(
      select 1 from erp.laundry_receipt_lines x
      join erp.laundry_receipts xr on xr.id=x.receipt_id
      join erp.laundry_delivery_lines xdl on xdl.id=x.delivery_line_id
      where xdl.cutting_group_id=r.cutting_group_id and xr.status='POSTED'
    ) then update erp.cutting_groups set status='RETURNED' where id=r.cutting_group_id;
    elsif exists(
      select 1 from erp.laundry_delivery_lines xdl
      join erp.laundry_deliveries xd on xd.id=xdl.delivery_id
      where xdl.cutting_group_id=r.cutting_group_id and xd.status not in('DRAFT','REVERSED')
    ) then update erp.cutting_groups set status='LAUNDRY' where id=r.cutting_group_id;
    else update erp.cutting_groups
      set status=case when picked_up_at is not null then 'PICKED_UP' else 'CUT' end
      where id=r.cutting_group_id;
    end if;
  end loop;

  if v_po_status not in ('ON_HOLD','CANCELLED') then
    if exists(select 1 from erp.qc_inspections where po_id=d.po_id and status='POSTED')
       or exists(select 1 from erp.laundry_receipts lr join erp.laundry_deliveries ld on ld.id=lr.delivery_id
                 where ld.po_id=d.po_id and lr.status='POSTED' and ld.status<>'REVERSED') then
      update erp.production_orders set status='QC',current_stage='QC',updated_at=now() where id=d.po_id;
    elsif exists(select 1 from erp.laundry_deliveries where po_id=d.po_id and status not in('DRAFT','REVERSED')) then
      update erp.production_orders set status='LAUNDRY',current_stage='LAUNDRY',updated_at=now() where id=d.po_id;
    elsif exists(select 1 from erp.cutting_groups where po_id=d.po_id and picked_up_at is not null) then
      update erp.production_orders set status='SEWING',current_stage='SEWING',updated_at=now() where id=d.po_id;
    else update erp.production_orders set status='CUTTING',current_stage='CUTTING',updated_at=now() where id=d.po_id;
    end if;
  end if;

  perform erp.sync_laundry_accrual(d.po_id,current_date);
  if exists(select 1 from erp.fg_lots where po_id=d.po_id) then
    perform erp.rebuild_po_hpp(d.po_id,'Laundry receipt reversed: '||p_reason);
    perform erp.propagate_conversion_hpp_for_po(d.po_id);
    perform erp.sync_po_hpp_to_gl(d.po_id,current_date);
  end if;
  insert into erp.audit_logs(entity_type,entity_id,action,changed_by,change_reason)
  values('laundry_receipts',h.id,'REVERSE',erp.current_app_user_id(),p_reason);
end;
$$;

-- Browser writes use aggregate RPCs; direct line/header mutation is closed.
revoke insert,update,delete on erp.laundry_receipts from public,anon,authenticated;
revoke insert,update,delete on erp.laundry_receipt_lines from public,anon,authenticated;
revoke execute on function erp.post_laundry_receipt(uuid) from public,authenticated;
grant execute on function erp.post_laundry_receipt(uuid) to service_role;
revoke all on function erp.save_laundry_receipt_draft_v2(jsonb,uuid,bigint) from public;
revoke all on function erp.post_laundry_receipt_v2(uuid,uuid,bigint,text) from public;
grant execute on function erp.save_laundry_receipt_draft_v2(jsonb,uuid,bigint) to authenticated,service_role;
grant execute on function erp.post_laundry_receipt_v2(uuid,uuid,bigint,text) to authenticated,service_role;
revoke all on function erp.assert_laundry_receipt_reversal_payroll_safe(uuid) from public,anon,authenticated;

-- ---------------------------------------------------------------------------
-- 6. Self-checks
-- ---------------------------------------------------------------------------

create or replace function erp.run_v263b_laundry_bs_integrity_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language sql
stable
security definer
set search_path=erp,public,pg_temp
as $$
  select 'posted_laundry_bs_allocation_mismatch','CRITICAL',count(*)::bigint,
         'Every posted laundry receipt line BS qty must equal its product allocations'
  from erp.laundry_receipt_lines l
  join erp.laundry_receipts h on h.id=l.receipt_id and h.status='POSTED'
  where l.qty_bs_laundry<>(select coalesce(sum(a.qty_bs),0) from erp.laundry_receipt_bs_product_allocations a where a.receipt_line_id=l.id)

  union all
  select 'active_laundry_bs_without_product_lineage','CRITICAL',count(*)::bigint,
         'Laundry-origin BS must retain product and receipt allocation lineage'
  from erp.bs_cases b
  where b.cause_source='LAUNDRY' and b.status<>'CANCELLED'
    and (b.product_id is null or b.source_laundry_receipt_line_id is null or b.source_laundry_bs_allocation_id is null)

  union all
  select 'laundry_bs_case_allocation_qty_mismatch','CRITICAL',count(*)::bigint,
         'Active laundry BS case qty/product must match its immutable allocation'
  from erp.bs_cases b
  join erp.laundry_receipt_bs_product_allocations a on a.id=b.source_laundry_bs_allocation_id
  where b.status<>'CANCELLED' and (b.qty_pcs<>a.qty_bs or b.product_id<>a.product_id)

  union all
  select 'settled_claim_followed_by_late_return','CRITICAL',count(*)::bigint,
         'No physical late return may post after final STUCK/MISSING claim resolution'
  from erp.laundry_claims c
  left join erp.laundry_receipt_lines claimed on claimed.id=c.receipt_line_id
  where c.status in('SETTLED','WRITTEN_OFF') and c.claim_type in('MISSING','STUCK')
    and exists(
      select 1 from erp.laundry_receipt_lines later
      join erp.laundry_receipts h on h.id=later.receipt_id and h.status='POSTED'
      where later.qty_good_received+later.qty_bs_laundry>0
        and h.physical_at>coalesce(c.resolved_at,c.opened_at)
        and (later.delivery_line_id=claimed.delivery_line_id
             or (c.receipt_line_id is null and h.delivery_id=c.delivery_id))
    );
$$;

revoke all on function erp.run_v263b_laundry_bs_integrity_checks() from public;
grant execute on function erp.run_v263b_laundry_bs_integrity_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.3b',
  'Laundry receipt aggregate CRUD, BS product lineage, late claim lock, payroll-safe reversal',
  now()
);

comment on table erp.laundry_receipt_bs_product_allocations is
  'Immutable-at-post split of laundry BS quantity by concrete product/size lineage.';
comment on function erp.save_laundry_receipt_draft_v2(jsonb,uuid,bigint) is
  'Idempotent optimistic aggregate draft save/delete for laundry receipts and BS product allocations.';
comment on function erp.post_laundry_receipt_v2(uuid,uuid,bigint,text) is
  'Idempotent optimistic posting wrapper; produces lineage-complete BS cases and releases physical payroll eligibility.';
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828073640','erp_v263b_laundry_bs_lineage',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828073640 erp_v263b_laundry_bs_lineage

-- BEGIN PLATFORM MIGRATION 20260828074629 erp_v263c_bs_rework_hardening
-- ERP Garment v2.6.3c
-- Controlled BS lifecycle/dispositions and server-priced cross-contractor rework.

set lock_timeout='10s';
set statement_timeout='180s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_3c',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.3b')
     or to_regprocedure('erp.save_laundry_receipt_draft_v2(jsonb,uuid,bigint)') is null
  then raise exception 'ERP Garment v2.6.3b is required before v2.6.3c'; end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. Provenance columns
-- ---------------------------------------------------------------------------

alter table erp.rework_component_lines
  add column if not exists source_contractor_rate_id uuid references erp.contractor_work_rates(id),
  add column if not exists source_po_component_snapshot_id uuid references erp.po_work_component_snapshots(id),
  add column if not exists rate_basis varchar(30) not null default 'LEGACY_CLIENT'
    check(rate_basis in('CONTRACTOR_RATE','PO_SNAPSHOT','LAUNDRY_ZERO','LEGACY_CLIENT'));

create index if not exists idx_rework_component_source_rate
  on erp.rework_component_lines(source_contractor_rate_id)
  where source_contractor_rate_id is not null;
create index if not exists idx_rework_component_source_po_snapshot
  on erp.rework_component_lines(source_po_component_snapshot_id)
  where source_po_component_snapshot_id is not null;

alter table erp.bs_resolutions
  add column if not exists source_laundry_claim_id uuid references erp.laundry_claims(id);
create index if not exists idx_bs_resolutions_laundry_claim
  on erp.bs_resolutions(source_laundry_claim_id)
  where source_laundry_claim_id is not null;

update erp.bs_cases
set legacy_reference=coalesce(nullif(btrim(legacy_reference),''),'MIGRATED:'||bs_number)
where untracked_type in('LEGACY','OUT_OF_NOWHERE')
  and nullif(btrim(legacy_reference),'') is null;

-- ---------------------------------------------------------------------------
-- 2. One authoritative BS status projection
-- ---------------------------------------------------------------------------

create or replace function erp.refresh_bs_case_status(p_bs_case_id uuid)
returns void
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
declare
  v_case erp.bs_cases%rowtype;
  v_resolved integer;
  v_active boolean;
  v_status text;
begin
  select * into v_case from erp.bs_cases where id=p_bs_case_id for update;
  if v_case.id is null or v_case.status='CANCELLED' then return; end if;
  select coalesce(sum(qty_pcs),0)::integer into v_resolved
  from erp.bs_resolutions where bs_case_id=v_case.id;
  select exists(
    select 1 from erp.rework_orders
    where bs_case_id=v_case.id and status in('OPEN','IN_PROGRESS','PARTIAL')
  ) into v_active;

  if v_resolved>=v_case.qty_pcs then
    if exists(select 1 from erp.bs_resolutions where bs_case_id=v_case.id)
       and not exists(select 1 from erp.bs_resolutions where bs_case_id=v_case.id and resolution_type<>'SCRAP') then
      v_status:='SCRAPPED';
    elsif exists(select 1 from erp.bs_resolutions where bs_case_id=v_case.id)
       and not exists(select 1 from erp.bs_resolutions where bs_case_id=v_case.id and resolution_type<>'WRITE_OFF') then
      v_status:='WRITTEN_OFF';
    else v_status:='RESOLVED'; end if;
  elsif v_active then v_status:='IN_REWORK';
  elsif v_resolved>0 then v_status:='PARTIAL';
  else v_status:='OPEN'; end if;

  if v_case.status is distinct from v_status then
    update erp.bs_cases set status=v_status,updated_at=now() where id=v_case.id;
  end if;
end;
$$;

create or replace function erp.sync_bs_case_status_from_rework()
returns trigger
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
begin
  if tg_op='DELETE' then
    perform erp.refresh_bs_case_status(old.bs_case_id);return old;
  end if;
  perform erp.refresh_bs_case_status(new.bs_case_id);
  if tg_op='UPDATE' and old.bs_case_id is distinct from new.bs_case_id then
    perform erp.refresh_bs_case_status(old.bs_case_id);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_refresh_bs_status_from_rework on erp.rework_orders;
create trigger trg_refresh_bs_status_from_rework
after insert or delete or update of bs_case_id,status,qty_sent,qty_good_returned,qty_bs_returned
on erp.rework_orders for each row execute function erp.sync_bs_case_status_from_rework();

create or replace function erp.sync_bs_case_status_from_resolution()
returns trigger
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
begin
  if tg_op='DELETE' then
    perform erp.refresh_bs_case_status(old.bs_case_id);return old;
  end if;
  perform erp.refresh_bs_case_status(new.bs_case_id);
  if tg_op='UPDATE' and old.bs_case_id is distinct from new.bs_case_id then
    perform erp.refresh_bs_case_status(old.bs_case_id);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_refresh_bs_status_from_resolution on erp.bs_resolutions;
create trigger trg_refresh_bs_status_from_resolution
after insert or delete or update of bs_case_id,qty_pcs,resolution_type
on erp.bs_resolutions for each row execute function erp.sync_bs_case_status_from_resolution();

-- ---------------------------------------------------------------------------
-- 3. Rework line pricing/entitlement is fully server-owned
-- ---------------------------------------------------------------------------

create or replace function erp.prepare_rework_component_line()
returns trigger
language plpgsql
security definer
set search_path=erp,public,pg_temp
as $$
declare
  v_order erp.rework_orders%rowtype;
  v_case erp.bs_cases%rowtype;
  v_component erp.bs_case_components%rowtype;
  v_model uuid;
  v_original_contractor uuid;
  v_rate_id uuid;
  v_rate numeric(18,2);
  v_po_snapshot uuid;
  v_remaining integer;
begin
  select * into v_order from erp.rework_orders where id=new.rework_order_id for update;
  if v_order.id is null then raise exception 'Rework order not found'; end if;
  if v_order.status not in('OPEN','IN_PROGRESS','PARTIAL') or v_order.cost_posted then
    raise exception 'Rework component lines are editable only before completion/cost posting';
  end if;
  select * into v_component from erp.bs_case_components where id=new.bs_case_component_id for update;
  if v_component.id is null then raise exception 'BS component not found'; end if;
  if v_component.bs_case_id<>v_order.bs_case_id then
    raise exception 'Rework component belongs to a different BS case';
  end if;
  select * into v_case from erp.bs_cases where id=v_order.bs_case_id;
  if new.qty_performed>v_order.qty_sent then
    raise exception 'Rework component qty performed % exceeds rework qty sent %',new.qty_performed,v_order.qty_sent;
  end if;
  v_remaining:=greatest(
    v_case.qty_pcs-v_component.completed_before_bs_qty-v_component.lifetime_newly_completed_qty,0
  );
  new.qty_newly_payable:=least(new.qty_performed,v_remaining);
  new.source_contractor_rate_id:=null;
  new.source_po_component_snapshot_id:=null;

  if v_order.destination_type='LAUNDRY' then
    new.rate_snapshot:=0;
    new.rate_basis:='LAUNDRY_ZERO';
    return new;
  end if;

  select coalesce(po.model_id,p.model_id),coalesce(po.contractor_id,v_case.responsible_contractor_id)
  into v_model,v_original_contractor
  from erp.bs_cases bc
  left join erp.production_orders po on po.id=bc.po_id
  left join erp.products p on p.id=bc.product_id
  where bc.id=v_case.id;
  if v_model is null then
    raise exception 'Contractor rework requires PO or product model lineage for server-side rate resolution';
  end if;

  select r.id,r.rate_per_pcs into v_rate_id,v_rate
  from erp.contractor_work_rates r
  where r.contractor_id=v_order.contractor_id
    and r.model_id=v_model
    and r.work_component_id=v_component.work_component_id
    and r.effective_from<=v_order.physical_sent_at
    and (r.effective_to is null or r.effective_to>v_order.physical_sent_at)
  order by r.effective_from desc,r.id desc limit 1;

  if v_rate_id is not null then
    new.rate_snapshot:=v_rate;
    new.source_contractor_rate_id:=v_rate_id;
    new.rate_basis:='CONTRACTOR_RATE';
    return new;
  end if;

  if v_order.contractor_id is distinct from v_original_contractor then
    raise exception 'Cross-Mandor rework requires an explicit effective contractor rate for this model/component';
  end if;
  select s.id,s.rate_per_pcs_snapshot into v_po_snapshot,v_rate
  from erp.po_work_component_snapshots s
  where s.po_id=v_case.po_id and s.work_component_id=v_component.work_component_id
  order by s.committed_at desc,s.id desc limit 1;
  if v_po_snapshot is null then
    raise exception 'No effective contractor rate or PO component snapshot exists for rework pricing';
  end if;
  new.rate_snapshot:=v_rate;
  new.source_po_component_snapshot_id:=v_po_snapshot;
  new.rate_basis:='PO_SNAPSHOT';
  return new;
end;
$$;

create or replace function erp.protect_rework_component_line()
returns trigger
language plpgsql
set search_path=erp,public,pg_temp
as $$
begin
  if tg_op='UPDATE' and (
    new.rework_order_id is distinct from old.rework_order_id
    or new.bs_case_component_id is distinct from old.bs_case_component_id
    or new.qty_performed is distinct from old.qty_performed
    or new.qty_newly_payable is distinct from old.qty_newly_payable
    or new.rate_snapshot is distinct from old.rate_snapshot
    or new.source_contractor_rate_id is distinct from old.source_contractor_rate_id
    or new.source_po_component_snapshot_id is distinct from old.source_po_component_snapshot_id
    or new.rate_basis is distinct from old.rate_basis
  ) then raise exception 'Rework entitlement/rate provenance is immutable; cancel and create a corrected line'; end if;
  return new;
end;
$$;

-- ---------------------------------------------------------------------------
-- 4. Controlled manual BS and classification/component correction
-- ---------------------------------------------------------------------------

create or replace function erp.create_manual_bs_case_v2(
  p_payload jsonb,p_client_request_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_id uuid:=gen_random_uuid();
  v_type text:=upper(coalesce(p_payload->>'untracked_type',''));
  v_ref text:=nullif(btrim(p_payload->>'legacy_reference'),'');
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  v_physical timestamptz:=nullif(p_payload->>'physical_at','')::timestamptz;
  v_component jsonb;
  v_case erp.bs_cases%rowtype;
begin
  perform erp.require_internal();
  if v_type not in('LEGACY','OUT_OF_NOWHERE') then
    raise exception 'Manual BS is allowed only for LEGACY or OUT_OF_NOWHERE';
  end if;
  if v_ref is null then raise exception 'legacy_reference is required for manual BS traceability'; end if;
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if v_physical is null or v_physical>clock_timestamp()+interval '5 minutes' then
    raise exception 'Valid non-future physical_at is required';
  end if;
  if coalesce(nullif(p_payload->>'qty_pcs','')::integer,0)<=0 then raise exception 'qty_pcs must be positive'; end if;
  v_hash:=erp._request_hash(p_payload);
  v_cached:=erp._idempotency_begin('create_manual_bs_case_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',v_reason,true);
  insert into erp.bs_cases(
    id,bs_number,po_id,cutting_group_id,qc_item_id,product_id,
    detected_at_stage,cause_source,untracked_type,
    responsible_contractor_id,responsible_vendor_id,qty_pcs,status,
    physical_at,legacy_reference,notes
  ) values(
    v_id,coalesce(nullif(btrim(p_payload->>'bs_number'),''),
      'BS-MAN-'||to_char(v_physical,'YYYYMMDD')||'-'||substr(v_id::text,1,8)),
    null,null,null,nullif(p_payload->>'product_id','')::uuid,
    'UNKNOWN','UNKNOWN',v_type,
    nullif(p_payload->>'responsible_contractor_id','')::uuid,
    nullif(p_payload->>'responsible_vendor_id','')::uuid,
    (p_payload->>'qty_pcs')::integer,'OPEN',v_physical,v_ref,
    nullif(btrim(p_payload->>'notes'),'')
  ) returning * into v_case;
  if p_payload?'components' then
    if jsonb_typeof(p_payload->'components')<>'array' then raise exception 'components must be an array'; end if;
    for v_component in select value from jsonb_array_elements(p_payload->'components') loop
      insert into erp.bs_case_components(
        bs_case_id,po_component_snapshot_id,work_component_id,completed_before_bs_qty,notes
      ) values(
        v_case.id,null,(v_component->>'work_component_id')::uuid,
        coalesce(nullif(v_component->>'completed_before_bs_qty','')::integer,0),
        nullif(btrim(v_component->>'notes'),'')
      );
    end loop;
  end if;
  select * into v_case from erp.bs_cases where id=v_case.id;
  v_response:=jsonb_build_object(
    'bs_case_id',v_case.id,'bs_number',v_case.bs_number,'status',v_case.status,
    'row_version',v_case.row_version,'untracked_type',v_case.untracked_type
  );
  return erp._idempotency_complete('create_manual_bs_case_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.classify_bs_case_v2(
  p_bs_case_id uuid,p_payload jsonb,p_client_request_id uuid,p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_case erp.bs_cases%rowtype;
  v_cause text;v_contractor uuid;v_vendor uuid;
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  v_component jsonb;v_snapshot uuid;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if v_reason is null then raise exception 'change_reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'bs_case_id',p_bs_case_id,'payload',p_payload,'expected_version',p_expected_version
  ));
  v_cached:=erp._idempotency_begin('classify_bs_case_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  select * into v_case from erp.bs_cases where id=p_bs_case_id for update;
  if v_case.id is null then raise exception 'BS case not found'; end if;
  if v_case.status not in('OPEN','PARTIAL','IN_REWORK') then raise exception 'Closed/cancelled BS case cannot be classified'; end if;
  if v_case.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_case.row_version;
  end if;
  v_cause:=upper(coalesce(nullif(p_payload->>'cause_source',''),v_case.cause_source));
  v_contractor:=case when p_payload?'responsible_contractor_id'
    then nullif(p_payload->>'responsible_contractor_id','')::uuid else v_case.responsible_contractor_id end;
  v_vendor:=case when p_payload?'responsible_vendor_id'
    then nullif(p_payload->>'responsible_vendor_id','')::uuid else v_case.responsible_vendor_id end;
  if v_cause='SEWING' and v_contractor is null then raise exception 'SEWING cause requires responsible contractor'; end if;
  if v_cause='LAUNDRY' and v_vendor is null then raise exception 'LAUNDRY cause requires responsible vendor'; end if;
  if v_cause not in('SEWING','LAUNDRY','UNKNOWN') then raise exception 'Invalid cause_source'; end if;
  perform set_config('app.change_reason',v_reason,true);
  update erp.bs_cases
  set cause_source=v_cause,responsible_contractor_id=v_contractor,
      responsible_vendor_id=v_vendor,
      notes=case when p_payload?'notes' then nullif(btrim(p_payload->>'notes'),'') else notes end,
      legacy_reference=case when p_payload?'legacy_reference' then nullif(btrim(p_payload->>'legacy_reference'),'') else legacy_reference end,
      updated_at=now()
  where id=v_case.id returning * into v_case;

  if p_payload?'components' then
    if exists(
      select 1 from erp.rework_component_lines rcl
      join erp.bs_case_components bcc on bcc.id=rcl.bs_case_component_id
      where bcc.bs_case_id=v_case.id
    ) then raise exception 'BS components are frozen after rework lines exist'; end if;
    if jsonb_typeof(p_payload->'components')<>'array' then raise exception 'components must be an array'; end if;
    delete from erp.bs_case_components where bs_case_id=v_case.id;
    for v_component in select value from jsonb_array_elements(p_payload->'components') loop
      select id into v_snapshot from erp.po_work_component_snapshots
      where po_id=v_case.po_id and work_component_id=(v_component->>'work_component_id')::uuid
      order by committed_at desc,id desc limit 1;
      insert into erp.bs_case_components(
        bs_case_id,po_component_snapshot_id,work_component_id,completed_before_bs_qty,notes
      ) values(
        v_case.id,v_snapshot,(v_component->>'work_component_id')::uuid,
        coalesce(nullif(v_component->>'completed_before_bs_qty','')::integer,0),
        nullif(btrim(v_component->>'notes'),'')
      );
    end loop;
    update erp.bs_cases set updated_at=now() where id=v_case.id returning * into v_case;
  end if;
  v_response:=jsonb_build_object(
    'bs_case_id',v_case.id,'status',v_case.status,'cause_source',v_case.cause_source,
    'row_version',v_case.row_version,'component_count',(
      select count(*) from erp.bs_case_components where bs_case_id=v_case.id
    )
  );
  return erp._idempotency_complete('classify_bs_case_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 5. Controlled non-rework dispositions and reversal
-- ---------------------------------------------------------------------------

create or replace function erp.resolve_bs_case_disposition_v2(
  p_bs_case_id uuid,p_resolution_type text,p_qty_pcs integer,
  p_compensation_amount numeric,p_source_laundry_claim_id uuid,
  p_physical_at timestamptz,p_notes text,
  p_client_request_id uuid,p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_type text:=upper(coalesce(p_resolution_type,''));
  v_hash text;v_cached jsonb;v_response jsonb;
  v_case erp.bs_cases%rowtype;v_claim erp.laundry_claims%rowtype;
  v_resolved integer;v_in_rework integer;v_remaining integer;
  v_used_amount numeric(20,2);v_used_qty integer;v_resolution uuid;
begin
  perform erp.require_internal();
  if v_type not in('CASH_COMPENSATION','SCRAP','WRITE_OFF','OTHER') then
    raise exception 'Disposition must be CASH_COMPENSATION, SCRAP, WRITE_OFF, or OTHER';
  end if;
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if coalesce(p_qty_pcs,0)<=0 then raise exception 'qty_pcs must be positive'; end if;
  if p_physical_at is null or p_physical_at>clock_timestamp()+interval '5 minutes' then
    raise exception 'Valid non-future physical_at is required';
  end if;
  if nullif(btrim(p_notes),'') is null then raise exception 'Disposition reason/notes are required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'bs_case_id',p_bs_case_id,'type',v_type,'qty',p_qty_pcs,
    'amount',coalesce(p_compensation_amount,0),'claim',p_source_laundry_claim_id,
    'physical_at',p_physical_at,'notes',btrim(p_notes),'expected_version',p_expected_version
  ));
  v_cached:=erp._idempotency_begin('resolve_bs_case_disposition_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  select * into v_case from erp.bs_cases where id=p_bs_case_id for update;
  if v_case.id is null then raise exception 'BS case not found'; end if;
  if v_case.status not in('OPEN','PARTIAL','IN_REWORK') then raise exception 'BS case is already closed/cancelled'; end if;
  if v_case.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_case.row_version;
  end if;
  if p_physical_at<v_case.physical_at then raise exception 'Disposition cannot predate BS detection'; end if;
  select coalesce(sum(qty_pcs),0)::integer into v_resolved from erp.bs_resolutions where bs_case_id=v_case.id;
  select coalesce(sum(qty_sent),0)::integer into v_in_rework from erp.rework_orders
  where bs_case_id=v_case.id and status in('OPEN','IN_PROGRESS','PARTIAL');
  v_remaining:=greatest(v_case.qty_pcs-v_resolved-v_in_rework,0);
  if p_qty_pcs>v_remaining then
    raise exception 'Disposition qty % exceeds currently available unresolved/non-rework qty %',p_qty_pcs,v_remaining;
  end if;

  if v_type='CASH_COMPENSATION' then
    if p_source_laundry_claim_id is null then raise exception 'CASH_COMPENSATION requires a settled laundry claim'; end if;
    if coalesce(p_compensation_amount,0)<=0 then raise exception 'CASH_COMPENSATION amount must be positive'; end if;
    select * into v_claim from erp.laundry_claims where id=p_source_laundry_claim_id for update;
    if v_claim.id is null or v_claim.status<>'SETTLED' then raise exception 'Linked laundry claim must be SETTLED'; end if;
    if v_case.responsible_vendor_id is null or v_claim.vendor_id<>v_case.responsible_vendor_id then
      raise exception 'Linked claim vendor does not match the BS responsible vendor';
    end if;
    if v_case.source_laundry_receipt_line_id is not null and not(
      v_claim.receipt_line_id=v_case.source_laundry_receipt_line_id
      or v_claim.delivery_id=(
        select lr.delivery_id from erp.laundry_receipt_lines l
        join erp.laundry_receipts lr on lr.id=l.receipt_id
        where l.id=v_case.source_laundry_receipt_line_id
      )
    ) then raise exception 'Linked claim does not belong to the BS laundry source'; end if;
    select coalesce(sum(compensation_amount),0),coalesce(sum(qty_pcs),0)::integer
    into v_used_amount,v_used_qty from erp.bs_resolutions
    where source_laundry_claim_id=v_claim.id;
    if v_used_amount+coalesce(p_compensation_amount,0)>v_claim.compensation_amount+0.005 then
      raise exception 'BS cash dispositions exceed settled laundry claim compensation';
    end if;
    if v_used_qty+p_qty_pcs>v_claim.qty_claimed then
      raise exception 'BS cash disposition qty exceeds settled laundry claim qty';
    end if;
  else
    if coalesce(p_compensation_amount,0)<>0 or p_source_laundry_claim_id is not null then
      raise exception 'Only CASH_COMPENSATION may carry claim/compensation amount';
    end if;
  end if;
  perform set_config('app.change_reason',btrim(p_notes),true);
  insert into erp.bs_resolutions(
    bs_case_id,resolution_type,qty_pcs,compensation_amount,
    responsible_contractor_id,responsible_vendor_id,
    source_laundry_claim_id,physical_at,notes
  ) values(
    v_case.id,v_type,p_qty_pcs,coalesce(p_compensation_amount,0),
    v_case.responsible_contractor_id,v_case.responsible_vendor_id,
    p_source_laundry_claim_id,p_physical_at,btrim(p_notes)
  ) returning id into v_resolution;
  perform erp.refresh_bs_case_status(v_case.id);
  select * into v_case from erp.bs_cases where id=v_case.id;
  v_response:=jsonb_build_object(
    'bs_resolution_id',v_resolution,'bs_case_id',v_case.id,'status',v_case.status,
    'row_version',v_case.row_version,'resolution_type',v_type,'qty_pcs',p_qty_pcs
  );
  return erp._idempotency_complete('resolve_bs_case_disposition_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.reverse_bs_disposition_v2(
  p_resolution_id uuid,p_reason text,p_client_request_id uuid,p_expected_bs_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_resolution erp.bs_resolutions%rowtype;v_case erp.bs_cases%rowtype;
begin
  perform erp.require_owner_admin();
  if nullif(btrim(p_reason),'') is null then raise exception 'Reversal reason is required'; end if;
  if p_expected_bs_version is null then raise exception 'expected_bs_version is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'resolution_id',p_resolution_id,'reason',btrim(p_reason),'expected_version',p_expected_bs_version
  ));
  v_cached:=erp._idempotency_begin('reverse_bs_disposition_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  select * into v_resolution from erp.bs_resolutions where id=p_resolution_id for update;
  if v_resolution.id is null then raise exception 'BS disposition not found'; end if;
  if v_resolution.source_rework_order_id is not null
     or v_resolution.resolution_type in('REWORK_SEWING','REWORK_LAUNDRY') then
    raise exception 'Rework resolution must be reversed through reverse_rework_completion';
  end if;
  select * into v_case from erp.bs_cases where id=v_resolution.bs_case_id for update;
  if v_case.row_version<>p_expected_bs_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_bs_version,v_case.row_version;
  end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  delete from erp.bs_resolutions where id=v_resolution.id;
  perform erp.refresh_bs_case_status(v_case.id);
  insert into erp.audit_logs(entity_type,entity_id,action,old_data,changed_by,change_reason)
  values('bs_resolutions',v_resolution.id,'REVERSE',to_jsonb(v_resolution),erp.current_app_user_id(),btrim(p_reason));
  select * into v_case from erp.bs_cases where id=v_case.id;
  v_response:=jsonb_build_object(
    'bs_resolution_id',v_resolution.id,'status','REVERSED',
    'bs_case_id',v_case.id,'bs_case_status',v_case.status,'row_version',v_case.row_version
  );
  return erp._idempotency_complete('reverse_bs_disposition_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 6. Aggregate rework save/cancel and completion
-- ---------------------------------------------------------------------------

create or replace function erp.save_rework_order_v2(
  p_payload jsonb,p_client_request_id uuid,p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_action text:=upper(coalesce(nullif(p_payload->>'action',''),'SAVE'));
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  v_order erp.rework_orders%rowtype;
  v_component jsonb;v_total_return integer;
begin
  perform erp.require_internal();
  if v_action not in('SAVE','CANCEL') then raise exception 'Rework action must be SAVE or CANCEL'; end if;
  if v_reason is null then raise exception 'change_reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('save_rework_order_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',v_reason,true);

  if v_id is null then
    if v_action='CANCEL' then raise exception 'Rework id is required for CANCEL'; end if;
    if p_expected_version is not null then raise exception 'expected_version must be null when creating rework'; end if;
    v_total_return:=coalesce(nullif(p_payload->>'qty_good_returned','')::integer,0)
      +coalesce(nullif(p_payload->>'qty_bs_returned','')::integer,0);
    if v_total_return>=coalesce(nullif(p_payload->>'qty_sent','')::integer,0) then
      raise exception 'Fully reconciled return must use complete_rework_order_v2 after creating the active order';
    end if;
    insert into erp.rework_orders(
      rework_number,bs_case_id,destination_type,contractor_id,vendor_id,
      qty_sent,qty_good_returned,qty_bs_returned,physical_sent_at,status,
      return_fg_location_id,notes
    ) values(
      btrim(p_payload->>'rework_number'),(p_payload->>'bs_case_id')::uuid,
      upper(p_payload->>'destination_type'),nullif(p_payload->>'contractor_id','')::uuid,
      nullif(p_payload->>'vendor_id','')::uuid,(p_payload->>'qty_sent')::integer,
      coalesce(nullif(p_payload->>'qty_good_returned','')::integer,0),
      coalesce(nullif(p_payload->>'qty_bs_returned','')::integer,0),
      (p_payload->>'physical_sent_at')::timestamptz,
      case when v_total_return>0 then 'PARTIAL'
           when upper(coalesce(nullif(p_payload->>'status',''),'OPEN'))='IN_PROGRESS' then 'IN_PROGRESS'
           else 'OPEN' end,
      nullif(p_payload->>'return_fg_location_id','')::uuid,nullif(btrim(p_payload->>'notes'),'')
    ) returning * into v_order;
    v_id:=v_order.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into v_order from erp.rework_orders where id=v_id for update;
    if v_order.id is null then raise exception 'Rework order not found'; end if;
    if v_order.row_version<>p_expected_version then
      raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_order.row_version;
    end if;
    if v_order.cost_posted or v_order.status in('COMPLETED','CANCELLED') then
      raise exception 'Completed/cancelled rework is locked; use reversal/correction';
    end if;
    if v_action='CANCEL' then
      if v_order.qty_good_returned+v_order.qty_bs_returned>0 then
        raise exception 'Partially returned rework must be fully reconciled before cancellation';
      end if;
      update erp.rework_orders set status='CANCELLED',notes=concat_ws(E'\n',notes,'CANCELLED: '||v_reason),updated_at=now()
      where id=v_id returning * into v_order;
      perform erp.refresh_bs_case_status(v_order.bs_case_id);
      v_response:=jsonb_build_object(
        'rework_order_id',v_order.id,'status',v_order.status,'row_version',v_order.row_version
      );
      return erp._idempotency_complete('save_rework_order_v2',p_client_request_id,v_response);
    end if;
    v_total_return:=coalesce(nullif(p_payload->>'qty_good_returned','')::integer,v_order.qty_good_returned)
      +coalesce(nullif(p_payload->>'qty_bs_returned','')::integer,v_order.qty_bs_returned);
    if v_total_return>=coalesce(nullif(p_payload->>'qty_sent','')::integer,v_order.qty_sent) then
      raise exception 'Fully reconciled return must use complete_rework_order_v2';
    end if;
    update erp.rework_orders
    set rework_number=coalesce(nullif(btrim(p_payload->>'rework_number'),''),v_order.rework_number),
        bs_case_id=case when p_payload?'bs_case_id' then (p_payload->>'bs_case_id')::uuid else v_order.bs_case_id end,
        destination_type=upper(coalesce(nullif(p_payload->>'destination_type',''),v_order.destination_type)),
        contractor_id=case when p_payload?'contractor_id' then nullif(p_payload->>'contractor_id','')::uuid else v_order.contractor_id end,
        vendor_id=case when p_payload?'vendor_id' then nullif(p_payload->>'vendor_id','')::uuid else v_order.vendor_id end,
        qty_sent=coalesce(nullif(p_payload->>'qty_sent','')::integer,v_order.qty_sent),
        qty_good_returned=coalesce(nullif(p_payload->>'qty_good_returned','')::integer,v_order.qty_good_returned),
        qty_bs_returned=coalesce(nullif(p_payload->>'qty_bs_returned','')::integer,v_order.qty_bs_returned),
        physical_sent_at=coalesce(nullif(p_payload->>'physical_sent_at','')::timestamptz,v_order.physical_sent_at),
        status=case when v_total_return>0 then 'PARTIAL'
                    when upper(coalesce(nullif(p_payload->>'status',''),'OPEN'))='IN_PROGRESS' then 'IN_PROGRESS'
                    else 'OPEN' end,
        return_fg_location_id=case when p_payload?'return_fg_location_id' then nullif(p_payload->>'return_fg_location_id','')::uuid else v_order.return_fg_location_id end,
        notes=case when p_payload?'notes' then nullif(btrim(p_payload->>'notes'),'') else v_order.notes end,
        updated_at=now()
    where id=v_id returning * into v_order;
  end if;

  if p_payload?'components' then
    if jsonb_typeof(p_payload->'components')<>'array' then raise exception 'components must be an array'; end if;
    delete from erp.rework_component_lines where rework_order_id=v_id;
    for v_component in select value from jsonb_array_elements(p_payload->'components') loop
      insert into erp.rework_component_lines(
        rework_order_id,bs_case_component_id,qty_performed,qty_newly_payable,
        rate_snapshot,notes
      ) values(
        v_id,(v_component->>'bs_case_component_id')::uuid,
        (v_component->>'qty_performed')::integer,0,0,
        nullif(btrim(v_component->>'notes'),'')
      );
    end loop;
    update erp.rework_orders set updated_at=now() where id=v_id returning * into v_order;
  end if;
  if v_order.destination_type='CONTRACTOR' and not exists(
    select 1 from erp.rework_component_lines where rework_order_id=v_order.id
  ) then raise exception 'Contractor rework requires at least one component line'; end if;
  perform erp.refresh_bs_case_status(v_order.bs_case_id);
  select * into v_order from erp.rework_orders where id=v_order.id;
  v_response:=jsonb_build_object(
    'rework_order_id',v_order.id,'status',v_order.status,'row_version',v_order.row_version,
    'bs_case_id',v_order.bs_case_id,'components',coalesce((
      select jsonb_agg(jsonb_build_object(
        'rework_component_line_id',l.id,'bs_case_component_id',l.bs_case_component_id,
        'qty_performed',l.qty_performed,'qty_newly_payable',l.qty_newly_payable,
        'rate_snapshot',l.rate_snapshot,'rate_basis',l.rate_basis,
        'source_contractor_rate_id',l.source_contractor_rate_id,
        'source_po_component_snapshot_id',l.source_po_component_snapshot_id
      ) order by l.id) from erp.rework_component_lines l where l.rework_order_id=v_order.id
    ),'[]'::jsonb)
  );
  return erp._idempotency_complete('save_rework_order_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.complete_rework_order_v2(
  p_rework_order_id uuid,p_qty_good integer,p_qty_bs integer,
  p_completed_at timestamptz,p_return_fg_location_id uuid,p_reason text,
  p_client_request_id uuid,p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_order erp.rework_orders%rowtype;v_case erp.bs_cases%rowtype;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'Completion reason is required'; end if;
  if p_completed_at is null or p_completed_at>clock_timestamp()+interval '5 minutes' then
    raise exception 'Valid non-future completed_at is required';
  end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'rework_order_id',p_rework_order_id,'good',p_qty_good,'bs',p_qty_bs,
    'completed_at',p_completed_at,'location',p_return_fg_location_id,
    'reason',btrim(p_reason),'expected_version',p_expected_version
  ));
  v_cached:=erp._idempotency_begin('complete_rework_order_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  select * into v_order from erp.rework_orders where id=p_rework_order_id for update;
  if v_order.id is null then raise exception 'Rework order not found'; end if;
  if v_order.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_order.row_version;
  end if;
  if v_order.status not in('OPEN','IN_PROGRESS','PARTIAL') or v_order.cost_posted then
    raise exception 'Only active unposted rework can be completed';
  end if;
  if coalesce(p_qty_good,0)<0 or coalesce(p_qty_bs,0)<0
     or coalesce(p_qty_good,0)+coalesce(p_qty_bs,0)<>v_order.qty_sent then
    raise exception 'Completion must reconcile exactly: GOOD + BS = qty sent';
  end if;
  if v_order.destination_type='CONTRACTOR' and not exists(
    select 1 from erp.rework_component_lines where rework_order_id=v_order.id
  ) then raise exception 'Contractor rework requires component lines'; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  update erp.rework_orders
  set qty_good_returned=coalesce(p_qty_good,0),qty_bs_returned=coalesce(p_qty_bs,0),
      completed_at=p_completed_at,status='COMPLETED',
      return_fg_location_id=coalesce(p_return_fg_location_id,return_fg_location_id),
      notes=concat_ws(E'\n',notes,'COMPLETED: '||btrim(p_reason)),updated_at=now()
  where id=v_order.id;
  perform erp.post_rework_completion(v_order.id);
  select * into v_order from erp.rework_orders where id=v_order.id;
  select * into v_case from erp.bs_cases where id=v_order.bs_case_id;
  v_response:=jsonb_build_object(
    'rework_order_id',v_order.id,'status',v_order.status,'row_version',v_order.row_version,
    'cost_posted',v_order.cost_posted,'good_fg_lot_id',v_order.good_fg_lot_id,
    'bs_case_id',v_case.id,'bs_case_status',v_case.status,'bs_case_row_version',v_case.row_version
  );
  return erp._idempotency_complete('complete_rework_order_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 7. Close direct browser writes; keep domain RPC/reversal surface
-- ---------------------------------------------------------------------------

revoke insert,update,delete on erp.bs_cases from public,anon,authenticated;
revoke insert,update,delete on erp.bs_case_components from public,anon,authenticated;
revoke insert,update,delete on erp.bs_resolutions from public,anon,authenticated;
revoke insert,update,delete on erp.rework_orders from public,anon,authenticated;
revoke insert,update,delete on erp.rework_component_lines from public,anon,authenticated;
revoke execute on function erp.post_rework_completion(uuid) from public,authenticated;
grant execute on function erp.post_rework_completion(uuid) to service_role;

do $$
declare r record;
begin
  for r in select p.oid::regprocedure signature
           from pg_proc p join pg_namespace n on n.oid=p.pronamespace
           where n.nspname='erp' and p.proname=any(array[
             'create_manual_bs_case_v2','classify_bs_case_v2',
             'resolve_bs_case_disposition_v2','reverse_bs_disposition_v2',
             'save_rework_order_v2','complete_rework_order_v2'
           ])
  loop
    execute format('revoke all on function %s from public',r.signature);
    execute format('grant execute on function %s to authenticated,service_role',r.signature);
  end loop;
end;
$$;
revoke all on function erp.refresh_bs_case_status(uuid) from public,anon,authenticated;
revoke all on function erp.sync_bs_case_status_from_rework() from public,anon,authenticated;
revoke all on function erp.sync_bs_case_status_from_resolution() from public,anon,authenticated;

-- ---------------------------------------------------------------------------
-- 8. Red-team integrity/security checks
-- ---------------------------------------------------------------------------

create or replace function erp.run_v263c_bs_rework_integrity_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language sql
stable
security definer
set search_path=erp,public,pg_temp
as $$
  select 'rework_component_wrong_bs_case','CRITICAL',count(*)::bigint,
         'Every rework component must belong to the order BS case'
  from erp.rework_component_lines l
  join erp.rework_orders o on o.id=l.rework_order_id
  join erp.bs_case_components c on c.id=l.bs_case_component_id
  where c.bs_case_id<>o.bs_case_id

  union all
  select 'rework_rate_provenance_mismatch','CRITICAL',count(*)::bigint,
         'Server-priced rework rate must equal its immutable source snapshot'
  from erp.rework_component_lines l
  left join erp.contractor_work_rates r on r.id=l.source_contractor_rate_id
  left join erp.po_work_component_snapshots s on s.id=l.source_po_component_snapshot_id
  where (l.rate_basis='CONTRACTOR_RATE' and (r.id is null or l.rate_snapshot<>r.rate_per_pcs))
     or (l.rate_basis='PO_SNAPSHOT' and (s.id is null or l.rate_snapshot<>s.rate_per_pcs_snapshot))
     or (l.rate_basis='LAUNDRY_ZERO' and l.rate_snapshot<>0)

  union all
  select 'rework_component_qty_exceeds_sent','CRITICAL',count(*)::bigint,
         'Component performed qty cannot exceed physical rework qty sent'
  from erp.rework_component_lines l join erp.rework_orders o on o.id=l.rework_order_id
  where l.qty_performed>o.qty_sent

  union all
  select 'active_cross_mandor_without_explicit_rate','CRITICAL',count(*)::bigint,
         'Cross-Mandor contractor rework requires effective contractor-rate provenance'
  from erp.rework_component_lines l
  join erp.rework_orders o on o.id=l.rework_order_id
  join erp.bs_cases b on b.id=o.bs_case_id
  left join erp.production_orders po on po.id=b.po_id
  where o.destination_type='CONTRACTOR' and o.status<>'CANCELLED'
    and o.contractor_id is distinct from coalesce(po.contractor_id,b.responsible_contractor_id)
    and (l.rate_basis<>'CONTRACTOR_RATE' or l.source_contractor_rate_id is null)

  union all
  select 'active_rework_bs_status_mismatch','CRITICAL',count(*)::bigint,
         'A BS case with active rework must project IN_REWORK while unresolved'
  from erp.bs_cases b
  where b.status not in('CANCELLED','RESOLVED','SCRAPPED','WRITTEN_OFF')
    and exists(select 1 from erp.rework_orders o where o.bs_case_id=b.id and o.status in('OPEN','IN_PROGRESS','PARTIAL'))
    and b.status<>'IN_REWORK'

  union all
  select 'bs_resolution_qty_exceeds_case','CRITICAL',count(*)::bigint,
         'Lifetime BS dispositions/resolutions cannot exceed case quantity'
  from (
    select b.id
    from erp.bs_cases b join erp.bs_resolutions r on r.bs_case_id=b.id
    group by b.id,b.qty_pcs having sum(r.qty_pcs)>b.qty_pcs
  ) excessive

  union all
  select 'cash_bs_resolution_invalid_claim','CRITICAL',count(*)::bigint,
         'Cash BS disposition requires matching settled laundry claim and capacity'
  from erp.bs_resolutions r
  join erp.bs_cases b on b.id=r.bs_case_id
  left join erp.laundry_claims c on c.id=r.source_laundry_claim_id
  where r.resolution_type='CASH_COMPENSATION'
    and (c.id is null or c.status<>'SETTLED' or c.vendor_id is distinct from b.responsible_vendor_id)

  union all
  select 'manual_bs_invalid_origin','CRITICAL',count(*)::bigint,
         'Manual/untracked BS must be only LEGACY or OUT_OF_NOWHERE with traceability'
  from erp.bs_cases b
  where b.untracked_type is not null
    and (b.untracked_type not in('LEGACY','OUT_OF_NOWHERE') or b.cause_source<>'UNKNOWN' or b.legacy_reference is null)

  union all
  select 'browser_direct_bs_rework_write_grant','CRITICAL',count(*)::bigint,
         'Authenticated browser must write BS/rework only through domain RPCs'
  from information_schema.role_table_grants g
  where g.table_schema='erp' and g.grantee='authenticated'
    and g.table_name in('bs_cases','bs_case_components','bs_resolutions','rework_orders','rework_component_lines')
    and g.privilege_type in('INSERT','UPDATE','DELETE');
$$;

revoke all on function erp.run_v263c_bs_rework_integrity_checks() from public;
grant execute on function erp.run_v263c_bs_rework_integrity_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.3c',
  'Controlled manual BS/classification/disposition plus server-priced cross-Mandor rework aggregate RPCs',
  now()
);

comment on function erp.create_manual_bs_case_v2(jsonb,uuid) is
  'Only supported manual BS entry: LEGACY or OUT_OF_NOWHERE with traceable reference.';
comment on function erp.save_rework_order_v2(jsonb,uuid,bigint) is
  'Idempotent optimistic aggregate rework save/cancel; all component rates are resolved server-side.';
comment on function erp.complete_rework_order_v2(uuid,integer,integer,timestamptz,uuid,text,uuid,bigint) is
  'Idempotent exact rework reconciliation and physical/cost/FG posting wrapper.';
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828074629','erp_v263c_bs_rework_hardening',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828074629 erp_v263c_bs_rework_hardening

-- BEGIN PLATFORM MIGRATION 20260828075325 erp_v263d_case_claim_read_models
-- ERP Garment v2.6.3d
-- Safe laundry-claim writes, unified Case/Nota browser read models,
-- customer-return-aware receivables, and visible NO ACCESSORY setup state.

set lock_timeout='10s';
set statement_timeout='180s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_3d',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.3c')
     or to_regprocedure('erp.run_v263c_bs_rework_integrity_checks()') is null
  then raise exception 'ERP Garment v2.6.3c is required before v2.6.3d'; end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. Safe laundry claim draft/accept/reject/reopen and final resolution wrapper
-- ---------------------------------------------------------------------------

create or replace function erp.guard_laundry_claim_insert_status()
returns trigger
language plpgsql
set search_path=erp,public,pg_temp
as $$
begin
  if current_user not in('postgres','service_role','supabase_admin') and new.status<>'OPEN' then
    raise exception 'Laundry claim must be created OPEN; use claim domain RPCs for transitions';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_guard_laundry_claim_insert_status on erp.laundry_claims;
create trigger trg_guard_laundry_claim_insert_status
before insert on erp.laundry_claims
for each row execute function erp.guard_laundry_claim_insert_status();

create or replace function erp.save_laundry_claim_v2(
  p_payload jsonb,p_client_request_id uuid,p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_action text:=upper(coalesce(nullif(p_payload->>'action',''),'SAVE'));
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  v_claim erp.laundry_claims%rowtype;
  v_target_status text;
begin
  perform erp.require_internal();
  if v_action not in('SAVE','REJECT','REOPEN') then
    raise exception 'Claim action must be SAVE, REJECT, or REOPEN';
  end if;
  if v_reason is null then raise exception 'change_reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('save_laundry_claim_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',v_reason,true);

  if v_id is null then
    if v_action<>'SAVE' then raise exception 'Create a claim with SAVE first'; end if;
    if p_expected_version is not null then raise exception 'expected_version must be null when creating a claim'; end if;
    if coalesce(btrim(p_payload->>'claim_number'),'')='' then raise exception 'claim_number is required'; end if;
    if nullif(p_payload->>'opened_at','')::timestamptz>clock_timestamp()+interval '5 minutes' then
      raise exception 'Claim opened_at cannot be in the future';
    end if;
    insert into erp.laundry_claims(
      claim_number,vendor_id,delivery_id,receipt_line_id,qty_claimed,claim_type,
      compensation_amount,status,opened_at,resolution_date,notes
    ) values(
      btrim(p_payload->>'claim_number'),(p_payload->>'vendor_id')::uuid,
      nullif(p_payload->>'delivery_id','')::uuid,nullif(p_payload->>'receipt_line_id','')::uuid,
      (p_payload->>'qty_claimed')::integer,upper(p_payload->>'claim_type'),
      coalesce(nullif(p_payload->>'compensation_amount','')::numeric,0),'OPEN',
      coalesce(nullif(p_payload->>'opened_at','')::timestamptz,now()),
      nullif(p_payload->>'resolution_date','')::date,nullif(btrim(p_payload->>'notes'),'')
    ) returning * into v_claim;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into v_claim from erp.laundry_claims where id=v_id for update;
    if v_claim.id is null then raise exception 'Laundry claim not found'; end if;
    if v_claim.row_version<>p_expected_version then
      raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_claim.row_version;
    end if;
    if v_claim.status in('SETTLED','WRITTEN_OFF') then
      raise exception 'Final claim is locked; use reverse_laundry_claim_resolution first';
    end if;
    if v_action='REOPEN' then
      perform erp.require_owner_admin();v_target_status:='OPEN';
    elsif v_action='REJECT' then v_target_status:='REJECTED';
    else
      if v_claim.status='REJECTED' then raise exception 'Rejected claim requires REOPEN by OWNER/ADMIN'; end if;
      v_target_status:=case when upper(coalesce(nullif(p_payload->>'status',''),v_claim.status))='ACCEPTED'
        then 'ACCEPTED' else 'OPEN' end;
    end if;
    update erp.laundry_claims
    set claim_number=coalesce(nullif(btrim(p_payload->>'claim_number'),''),v_claim.claim_number),
        vendor_id=case when p_payload?'vendor_id' then (p_payload->>'vendor_id')::uuid else v_claim.vendor_id end,
        delivery_id=case when p_payload?'delivery_id' then nullif(p_payload->>'delivery_id','')::uuid else v_claim.delivery_id end,
        receipt_line_id=case when p_payload?'receipt_line_id' then nullif(p_payload->>'receipt_line_id','')::uuid else v_claim.receipt_line_id end,
        qty_claimed=coalesce(nullif(p_payload->>'qty_claimed','')::integer,v_claim.qty_claimed),
        claim_type=upper(coalesce(nullif(p_payload->>'claim_type',''),v_claim.claim_type)),
        compensation_amount=coalesce(nullif(p_payload->>'compensation_amount','')::numeric,v_claim.compensation_amount),
        status=v_target_status,
        opened_at=coalesce(nullif(p_payload->>'opened_at','')::timestamptz,v_claim.opened_at),
        resolution_date=case when p_payload?'resolution_date' then nullif(p_payload->>'resolution_date','')::date else v_claim.resolution_date end,
        notes=case when p_payload?'notes' then nullif(btrim(p_payload->>'notes'),'') else v_claim.notes end
    where id=v_claim.id returning * into v_claim;
  end if;
  v_response:=jsonb_build_object(
    'laundry_claim_id',v_claim.id,'claim_number',v_claim.claim_number,
    'status',v_claim.status,'row_version',v_claim.row_version,
    'qty_claimed',v_claim.qty_claimed,'compensation_amount',v_claim.compensation_amount
  );
  return erp._idempotency_complete('save_laundry_claim_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.resolve_laundry_claim_v2(
  p_claim_id uuid,p_resolution text,p_reason text,
  p_client_request_id uuid,p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_claim erp.laundry_claims%rowtype;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'Claim resolution reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'claim_id',p_claim_id,'resolution',upper(p_resolution),'reason',btrim(p_reason),
    'expected_version',p_expected_version
  ));
  v_cached:=erp._idempotency_begin('resolve_laundry_claim_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  select * into v_claim from erp.laundry_claims where id=p_claim_id for update;
  if v_claim.id is null then raise exception 'Laundry claim not found'; end if;
  if v_claim.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_claim.row_version;
  end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  perform erp.resolve_laundry_claim(v_claim.id,upper(p_resolution),btrim(p_reason));
  select * into v_claim from erp.laundry_claims where id=v_claim.id;
  v_response:=jsonb_build_object(
    'laundry_claim_id',v_claim.id,'status',v_claim.status,
    'row_version',v_claim.row_version,'resolved_at',v_claim.resolved_at,
    'resolution_date',v_claim.resolution_date
  );
  return erp._idempotency_complete('resolve_laundry_claim_v2',p_client_request_id,v_response);
end;
$$;

revoke insert,update,delete on erp.laundry_claims from public,anon,authenticated;
revoke execute on function erp.resolve_laundry_claim(uuid,text,text) from public,authenticated;
grant execute on function erp.resolve_laundry_claim(uuid,text,text) to service_role;
revoke all on function erp.save_laundry_claim_v2(jsonb,uuid,bigint) from public;
revoke all on function erp.resolve_laundry_claim_v2(uuid,text,text,uuid,bigint) from public;
grant execute on function erp.save_laundry_claim_v2(jsonb,uuid,bigint) to authenticated,service_role;
grant execute on function erp.resolve_laundry_claim_v2(uuid,text,text,uuid,bigint) to authenticated,service_role;
revoke all on function erp.guard_laundry_claim_insert_status() from public,anon,authenticated;

-- ---------------------------------------------------------------------------
-- 2. Unified browse-first cases read model
-- ---------------------------------------------------------------------------

create or replace view erp.v_case_browser
with(security_invoker=true)
as
select
  'BS:'||b.id::text case_key,'BS'::text case_type,'bs_cases'::text source_table,b.id source_id,
  b.bs_number case_number,b.physical_at opened_at,b.status::text status,b.row_version,
  b.qty_pcs,b.po_id,po.po_number,po.model_id,pm.model_name,
  b.cutting_group_id,cg.group_number,b.product_id,p.sku,p.product_name,
  b.responsible_contractor_id,ct.contractor_name,b.responsible_vendor_id,lv.vendor_name,
  b.detected_at_stage::text detected_stage,b.cause_source::text cause_source,b.untracked_type::text untracked_type,
  b.source_laundry_receipt_line_id,b.qc_item_id,null::uuid laundry_delivery_id,
  0::integer held_payroll_qty,
  coalesce((select sum(e.remaining_qty)::integer
    from erp.v_payroll_eligible_work_lines e
    join erp.rework_component_lines rcl on e.source_type='REWORK' and rcl.id=e.source_id
    join erp.bs_case_components bcc on bcc.id=rcl.bs_case_component_id
    where bcc.bs_case_id=b.id),0) nota_eligible_rework_qty,
  coalesce((select sum(r.qty_pcs)::integer from erp.bs_resolutions r where r.bs_case_id=b.id),0) resolved_qty,
  (b.status in('RESOLVED','SCRAPPED','WRITTEN_OFF','CANCELLED')) is_closed,
  case when b.status in('OPEN','PARTIAL') then 'START_REWORK_OR_DISPOSITION'
       when b.status='IN_REWORK' then 'COMPLETE_REWORK' else 'VIEW_OR_REVERSE' end next_action,
  concat_ws(' ',b.bs_number,po.po_number,pm.model_name,cg.group_number,p.sku,p.product_name,
    ct.contractor_name,lv.vendor_name,b.status,b.cause_source,b.untracked_type,b.legacy_reference,b.notes) search_text,
  b.notes
from erp.bs_cases b
left join erp.production_orders po on po.id=b.po_id
left join erp.product_models pm on pm.id=po.model_id
left join erp.cutting_groups cg on cg.id=b.cutting_group_id
left join erp.products p on p.id=b.product_id
left join erp.contractors ct on ct.id=b.responsible_contractor_id
left join erp.laundry_vendors lv on lv.id=b.responsible_vendor_id

union all

select
  'LAUNDRY:'||c.id::text case_key,c.claim_type::text case_type,'laundry_claims'::text source_table,c.id source_id,
  c.claim_number case_number,c.opened_at,c.status::text,c.row_version,
  c.qty_claimed,ld.po_id,po.po_number,po.model_id,pm.model_name,
  null::uuid cutting_group_id,null::varchar group_number,null::uuid product_id,null::varchar sku,null::varchar product_name,
  null::uuid responsible_contractor_id,null::varchar contractor_name,c.vendor_id,lv.vendor_name,
  'LAUNDRY'::text detected_stage,'LAUNDRY'::text cause_source,null::text untracked_type,
  c.receipt_line_id source_laundry_receipt_line_id,null::uuid qc_item_id,c.delivery_id laundry_delivery_id,
  case when c.claim_type in('STUCK','MISSING') and c.status<>'REJECTED' then c.qty_claimed else 0 end held_payroll_qty,
  0::integer nota_eligible_rework_qty,
  case when c.status in('SETTLED','WRITTEN_OFF') then c.qty_claimed else 0 end resolved_qty,
  (c.status in('SETTLED','WRITTEN_OFF','REJECTED')) is_closed,
  case when c.status in('OPEN','ACCEPTED') then 'RESOLVE_CLAIM' else 'VIEW_OR_REVERSE' end next_action,
  concat_ws(' ',c.claim_number,c.claim_type,c.status,ld.delivery_number,po.po_number,pm.model_name,
    lv.vendor_name,c.qty_claimed,c.compensation_amount,c.notes) search_text,
  c.notes
from erp.laundry_claims c
join erp.laundry_deliveries ld on ld.id=c.delivery_id
join erp.production_orders po on po.id=ld.po_id
left join erp.product_models pm on pm.id=po.model_id
join erp.laundry_vendors lv on lv.id=c.vendor_id;

grant select on erp.v_case_browser to authenticated;

create or replace view erp.v_payroll_nota_browser
with(security_invoker=true)
as
select
  n.id payroll_id,n.payroll_number,n.contractor_id,c.contractor_code,c.contractor_name,
  n.period_start,n.period_end,n.status,n.row_version,n.payment_date,n.settled_at,
  n.labor_total,n.attendance_total,n.reimburse_total,n.deduction_total,n.manual_adjustment,n.net_payable,
  coalesce(x.work_line_count,0)::bigint work_line_count,
  coalesce(x.work_qty,0)::bigint work_qty,
  coalesce(e.eligible_line_count,0)::bigint eligible_line_count,
  coalesce(e.eligible_qty,0)::bigint eligible_qty,
  coalesce(e.eligible_amount,0)::numeric(24,2) eligible_amount,
  (n.status in('DRAFT','CALCULATED','REVIEW')) can_merge,
  (n.status in('APPROVED','PAID','REVERSED')) is_locked,
  n.notes,n.created_at,n.updated_at
from erp.payroll_settlements n
join erp.contractors c on c.id=n.contractor_id
left join lateral(
  select count(*) work_line_count,coalesce(sum(w.qty_payable),0) work_qty
  from erp.payroll_work_items w where w.payroll_id=n.id
) x on true
left join lateral(
  select count(*) eligible_line_count,coalesce(sum(q.remaining_qty),0) eligible_qty,
         coalesce(sum(q.remaining_qty*q.rate_snapshot),0) eligible_amount
  from erp.v_payroll_eligible_work_lines q
  where q.contractor_id=n.contractor_id and q.eligible_at::date<=n.period_end
) e on true;

grant select on erp.v_payroll_nota_browser to authenticated;

-- ---------------------------------------------------------------------------
-- 3. Customer returns net down receivables; overpayment becomes explicit credit
-- ---------------------------------------------------------------------------

create or replace view erp.v_customer_receivables
with(security_invoker=true)
as
with invoice as(
  select sh.id sale_id,coalesce(sum(si.line_total),0)::numeric(20,2) gross_amount
  from erp.sales_headers sh join erp.sales_items si on si.sale_id=sh.id
  group by sh.id
), payment as(
  select sp.sale_id,coalesce(sum(sp.amount),0)::numeric(20,2) paid_amount
  from erp.sales_payments sp where sp.status='POSTED' group by sp.sale_id
), returned as(
  select sr.sale_id,coalesce(sum(sri.refund_amount),0)::numeric(20,2) return_amount
  from erp.sales_returns sr join erp.sales_return_items sri on sri.return_id=sr.id
  where sr.status='POSTED' group by sr.sale_id
)
select
  sh.customer_id,c.customer_name,sh.id sale_id,sh.sale_number,sh.sale_date,sh.due_date,
  i.gross_amount invoice_amount,coalesce(p.paid_amount,0)::numeric(20,2) paid_amount,
  greatest(i.gross_amount-coalesce(r.return_amount,0)-coalesce(p.paid_amount,0),0)::numeric(20,2) outstanding_amount,
  coalesce(r.return_amount,0)::numeric(20,2) posted_return_amount,
  greatest(i.gross_amount-coalesce(r.return_amount,0),0)::numeric(20,2) net_invoice_amount,
  greatest(coalesce(p.paid_amount,0)-(i.gross_amount-coalesce(r.return_amount,0)),0)::numeric(20,2) credit_amount
from erp.sales_headers sh
join erp.customers c on c.id=sh.customer_id
join invoice i on i.sale_id=sh.id
left join payment p on p.sale_id=sh.id
left join returned r on r.sale_id=sh.id
where sh.status in('POSTED','PARTIAL_PAID','PAID');

-- ---------------------------------------------------------------------------
-- 4. Empty active accessory BOM is visible as NO_ACCESSORY, not missing data
-- ---------------------------------------------------------------------------

create or replace view erp.v_accessory_hpp_setup
with(security_invoker=true)
as
select
  p.id product_id,p.sku,p.product_name,
  abv.id bom_version_id,abv.effective_from,abv.effective_to,
  ac.category_code,ac.category_name,ac.base_uom_code,
  abi.qty_per_good_fg_base,abi.hpp_method,abi.hpp_standard_rate,abi.hpp_uom_code,
  abi.reimbursement_rate,abi.reimbursement_uom_code,
  case when abv.id is null then 'MISSING_BOM'
       when abi.id is null then 'NO_ACCESSORY' else 'CONFIGURED' end setup_state,
  count(abi.id) over(partition by p.id,abv.id)::bigint bom_item_count
from erp.v_products_current p
left join erp.accessory_bom_versions abv
  on abv.product_id=p.identity_root_id and abv.is_active=true
  and abv.effective_from<=clock_timestamp()
  and (abv.effective_to is null or abv.effective_to>clock_timestamp())
left join erp.accessory_bom_items abi on abi.bom_version_id=abv.id
left join erp.accessory_categories ac on ac.id=abi.category_id;

-- ---------------------------------------------------------------------------
-- 5. Integrity/security checks
-- ---------------------------------------------------------------------------

create or replace function erp.run_v263d_case_claim_read_integrity_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language sql
stable
security definer
set search_path=erp,public,pg_temp
as $$
  select 'browser_direct_laundry_claim_write_grant','CRITICAL',count(*)::bigint,
         'Authenticated browser must mutate laundry claims only through domain RPCs'
  from information_schema.role_table_grants g
  where g.table_schema='erp' and g.table_name='laundry_claims' and g.grantee='authenticated'
    and g.privilege_type in('INSERT','UPDATE','DELETE')

  union all
  select 'settled_claim_compensation_without_journal','CRITICAL',count(*)::bigint,
         'Positive SETTLED claim compensation must have a posted/reversed settlement journal'
  from erp.laundry_claims c
  where c.status='SETTLED' and c.compensation_amount>0
    and not exists(select 1 from erp.journal_entries j
      where j.source_type='LAUNDRY_CLAIM_SETTLEMENT' and j.source_id=c.id and j.status in('POSTED','REVERSED'))

  union all
  select 'active_case_missing_from_browser','CRITICAL',count(*)::bigint,
         'Every BS and laundry claim must appear exactly once in Case Browser'
  from(
    select 'BS:'||id::text key from erp.bs_cases
    union all select 'LAUNDRY:'||id::text from erp.laundry_claims
  ) s
  where (select count(*) from erp.v_case_browser b where b.case_key=s.key)<>1

  union all
  select 'empty_accessory_bom_hidden','CRITICAL',count(*)::bigint,
         'An active empty BOM must be visible as explicit NO_ACCESSORY'
  from erp.accessory_bom_versions b
  where b.is_active and b.effective_from<=clock_timestamp()
    and (b.effective_to is null or b.effective_to>clock_timestamp())
    and not exists(select 1 from erp.accessory_bom_items i where i.bom_version_id=b.id)
    and not exists(select 1 from erp.v_accessory_hpp_setup v
      where v.bom_version_id=b.id and v.setup_state='NO_ACCESSORY')

  union all
  select 'receivable_formula_mismatch','CRITICAL',count(*)::bigint,
         'Outstanding/credit must reconcile gross invoice less posted returns and payments'
  from erp.v_customer_receivables v
  where abs(v.outstanding_amount-greatest(v.net_invoice_amount-v.paid_amount,0))>0.005
     or abs(v.credit_amount-greatest(v.paid_amount-v.net_invoice_amount,0))>0.005;
$$;

revoke all on function erp.run_v263d_case_claim_read_integrity_checks() from public;
grant execute on function erp.run_v263d_case_claim_read_integrity_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.3d',
  'Safe laundry claim mutations, Case/Nota browser views, return-netted AR, visible NO ACCESSORY setup',
  now()
);

comment on view erp.v_case_browser is
  'Unified filterable BS, Stuck, Missing, Damage, and other laundry case list for browse-first UX.';
comment on view erp.v_payroll_nota_browser is
  'Existing Nota and currently mergeable eligible work summary side-by-side per Mandor/period.';
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828075325','erp_v263d_case_claim_read_models',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828075325 erp_v263d_case_claim_read_models

-- BEGIN PLATFORM MIGRATION 20260828080411 erp_v263e_red_team_closure
-- ERP Garment v2.6.3e
-- Red-team closure: lifecycle insert guards, master cascade closure,
-- missing audit coverage, private trigger routines, and hot-path indexes.

set lock_timeout = '10s';
set statement_timeout = '180s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_3e', 0));

do $$
begin
  if not exists (
    select 1 from erp.schema_migrations where version = 'v2.6.3d'
  ) then
    raise exception 'ERP Garment v2.6.3d is required before v2.6.3e';
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. Trigger routines are implementation details, never browser RPCs.
-- ---------------------------------------------------------------------------

revoke all on function erp.seed_bs_case_component_baseline()
  from public, anon, authenticated;
revoke all on function erp.touch_laundry_receipt_from_bs_allocation()
  from public, anon, authenticated;
revoke all on function erp.validate_laundry_bs_product_allocation()
  from public, anon, authenticated;

-- ---------------------------------------------------------------------------
-- 2. Browser inserts may only start at the initial lifecycle state.
--    SECURITY DEFINER domain RPCs run as their owner and remain able to perform
--    validated transitions after their own authorization and business checks.
-- ---------------------------------------------------------------------------

create or replace function erp.guard_initial_lifecycle_insert_v263e()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
begin
  if current_user in ('postgres', 'service_role', 'supabase_admin') then
    return new;
  end if;

  if tg_table_name = 'payroll_settlements' then
    if new.status <> 'DRAFT'
       or coalesce(new.labor_total, 0) <> 0
       or coalesce(new.attendance_total, 0) <> 0
       or coalesce(new.reimburse_total, 0) <> 0
       or coalesce(new.deduction_total, 0) <> 0
       or new.settled_at is not null
    then
      raise exception 'Payroll must be created as a zero-value DRAFT; use payroll RPCs for calculation and settlement';
    end if;
  elsif tg_table_name = 'production_orders' then
    if new.status <> 'DRAFT' or new.current_stage <> 'CUTTING' then
      raise exception 'Production order must be created DRAFT at CUTTING; lifecycle follows operational RPCs';
    end if;
  elsif tg_table_name = 'scrap_batches' then
    if new.status <> 'AVAILABLE' then
      raise exception 'Scrap batch must be created AVAILABLE; sale/disposal requires a domain RPC';
    end if;
  else
    raise exception 'Unsupported lifecycle guard target %.%', tg_table_schema, tg_table_name;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_guard_payroll_initial_state_v263e
  on erp.payroll_settlements;
create trigger trg_guard_payroll_initial_state_v263e
before insert on erp.payroll_settlements
for each row execute function erp.guard_initial_lifecycle_insert_v263e();

drop trigger if exists trg_guard_po_initial_state_v263e
  on erp.production_orders;
create trigger trg_guard_po_initial_state_v263e
before insert on erp.production_orders
for each row execute function erp.guard_initial_lifecycle_insert_v263e();

drop trigger if exists trg_guard_scrap_batch_initial_state_v263e
  on erp.scrap_batches;
create trigger trg_guard_scrap_batch_initial_state_v263e
before insert on erp.scrap_batches
for each row execute function erp.guard_initial_lifecycle_insert_v263e();

create or replace function erp.guard_scrap_batch_status_write_v263e()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
begin
  if current_user not in ('postgres', 'service_role', 'supabase_admin')
     and new.status is distinct from old.status
  then
    raise exception 'Scrap batch status is system-managed by scrap sale/disposal RPCs';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_guard_scrap_batch_status_write_v263e
  on erp.scrap_batches;
create trigger trg_guard_scrap_batch_status_write_v263e
before update of status on erp.scrap_batches
for each row execute function erp.guard_scrap_batch_status_write_v263e();

revoke all on function erp.guard_initial_lifecycle_insert_v263e()
  from public, anon, authenticated;
revoke all on function erp.guard_scrap_batch_status_write_v263e()
  from public, anon, authenticated;

-- ---------------------------------------------------------------------------
-- 3. A wash-process delete previously cascaded through effective-dated vendor
--    rate history. Deactivate instead. Product-model size mappings remain
--    correctable only while no concrete SKU uses that exact pair.
-- ---------------------------------------------------------------------------

revoke delete on erp.wash_processes from public, anon, authenticated;

create or replace function erp.guard_product_model_size_delete_v263e()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
begin
  if exists (
    select 1
    from erp.products p
    where p.model_id = old.model_id
      and p.size_id = old.size_id
  ) then
    raise exception 'Model-size mapping is already used by a product identity; deactivate/version the product before changing the mapping';
  end if;
  return old;
end;
$$;

drop trigger if exists trg_guard_product_model_size_delete_v263e
  on erp.product_model_sizes;
create trigger trg_guard_product_model_size_delete_v263e
before delete on erp.product_model_sizes
for each row execute function erp.guard_product_model_size_delete_v263e();

revoke all on function erp.guard_product_model_size_delete_v263e()
  from public, anon, authenticated;

-- ---------------------------------------------------------------------------
-- 4. Extend generic auditing to reference tables without a UUID key. Their
--    complete old/new JSON remains authoritative even when entity_id is null.
-- ---------------------------------------------------------------------------

create or replace function erp.audit_row_change()
returns trigger
language plpgsql
security definer
set search_path = erp, public, pg_temp
as $$
declare
  v_reason text := nullif(current_setting('app.change_reason', true), '');
  v_old jsonb;
  v_new jsonb;
  v_key jsonb;
  v_id_text text;
  v_entity_id uuid;
begin
  if tg_op <> 'INSERT' then v_old := to_jsonb(old); end if;
  if tg_op <> 'DELETE' then v_new := to_jsonb(new); end if;
  v_key := coalesce(v_new, v_old);
  v_id_text := coalesce(nullif(v_key->>'id', ''), nullif(v_key->>'material_id', ''));
  if v_id_text is not null then
    begin
      v_entity_id := v_id_text::uuid;
    exception when invalid_text_representation then
      v_entity_id := null;
    end;
  end if;

  if tg_op = 'INSERT' then
    insert into erp.audit_logs(
      entity_type, entity_id, action, new_data, changed_by, change_reason
    ) values (
      tg_table_name, v_entity_id, 'INSERT', v_new,
      erp.current_app_user_id(), v_reason
    );
    return new;
  elsif tg_op = 'UPDATE' then
    if v_old is distinct from v_new then
      insert into erp.audit_logs(
        entity_type, entity_id, action, old_data, new_data, changed_by, change_reason
      ) values (
        tg_table_name, v_entity_id, 'UPDATE', v_old, v_new,
        erp.current_app_user_id(), v_reason
      );
    end if;
    return new;
  else
    insert into erp.audit_logs(
      entity_type, entity_id, action, old_data, changed_by, change_reason
    ) values (
      tg_table_name, v_entity_id, 'DELETE', v_old,
      erp.current_app_user_id(), v_reason
    );
    return old;
  end if;
end;
$$;

revoke all on function erp.audit_row_change() from public, anon, authenticated;

drop trigger if exists trg_audit_po_customer_visibility_v263e
  on erp.po_customer_visibility;
create trigger trg_audit_po_customer_visibility_v263e
after insert or update or delete on erp.po_customer_visibility
for each row execute function erp.audit_row_change();

drop trigger if exists trg_audit_product_model_sizes_v263e
  on erp.product_model_sizes;
create trigger trg_audit_product_model_sizes_v263e
after insert or update or delete on erp.product_model_sizes
for each row execute function erp.audit_row_change();

drop trigger if exists trg_audit_sizes_v263e on erp.sizes;
create trigger trg_audit_sizes_v263e
after insert or update or delete on erp.sizes
for each row execute function erp.audit_row_change();

drop trigger if exists trg_audit_uom_definitions_v263e on erp.uom_definitions;
create trigger trg_audit_uom_definitions_v263e
after insert or update or delete on erp.uom_definitions
for each row execute function erp.audit_row_change();

drop trigger if exists trg_audit_wash_processes_v263e on erp.wash_processes;
create trigger trg_audit_wash_processes_v263e
after insert or update or delete on erp.wash_processes
for each row execute function erp.audit_row_change();

drop trigger if exists trg_audit_work_components_v263e on erp.work_components;
create trigger trg_audit_work_components_v263e
after insert or update or delete on erp.work_components
for each row execute function erp.audit_row_change();

-- ---------------------------------------------------------------------------
-- 5. Target only FK paths used repeatedly by Case Browser, Nota, receipt
--    posting/reversal and net-AR. The remaining legacy INFO lints are retained
--    for workload-led tuning instead of creating hundreds of speculative indexes.
-- ---------------------------------------------------------------------------

create index if not exists idx_bs_resolutions_bs_case
  on erp.bs_resolutions(bs_case_id);
create index if not exists idx_bs_case_components_work_component
  on erp.bs_case_components(work_component_id);
create index if not exists idx_laundry_claims_delivery
  on erp.laundry_claims(delivery_id) where delivery_id is not null;
create index if not exists idx_laundry_claims_receipt_line
  on erp.laundry_claims(receipt_line_id) where receipt_line_id is not null;
create index if not exists idx_laundry_receipt_lines_receipt
  on erp.laundry_receipt_lines(receipt_id);
create index if not exists idx_rework_component_lines_bs_component
  on erp.rework_component_lines(bs_case_component_id);
create index if not exists idx_payroll_work_items_component
  on erp.payroll_work_items(work_component_id);
create index if not exists idx_sales_returns_sale
  on erp.sales_returns(sale_id) where sale_id is not null;
create index if not exists idx_sales_returns_customer
  on erp.sales_returns(customer_id);
create index if not exists idx_cutting_group_size_slots_size
  on erp.cutting_group_size_slots(size_id);

-- ---------------------------------------------------------------------------
-- 6. Release-specific red-team checks.
-- ---------------------------------------------------------------------------

create or replace function erp.run_v263e_red_team_integrity_checks()
returns table(check_name text, severity text, issue_count bigint, details text)
language sql
stable
security definer
set search_path = erp, public, pg_catalog, information_schema, pg_temp
as $$
  select
    'public_erp_routine_execute', 'CRITICAL', count(*)::bigint,
    'PUBLIC must not execute any ERP routine'
  from pg_proc p
  join pg_namespace n on n.oid = p.pronamespace
  where n.nspname = 'erp'
    and has_function_privilege('public', p.oid, 'EXECUTE')

  union all
  select
    'wash_process_hard_delete_grant', 'CRITICAL', count(*)::bigint,
    'Browser roles must deactivate wash processes; deleting one cascades rate history'
  from information_schema.role_table_grants g
  where g.table_schema = 'erp'
    and g.table_name = 'wash_processes'
    and g.grantee in ('PUBLIC', 'anon', 'authenticated')
    and g.privilege_type = 'DELETE'

  union all
  select
    'missing_initial_lifecycle_guard', 'CRITICAL', count(*)::bigint,
    'Payroll, PO and scrap inserts require an initial-state trigger'
  from (values
    ('payroll_settlements', 'trg_guard_payroll_initial_state_v263e'),
    ('production_orders', 'trg_guard_po_initial_state_v263e'),
    ('scrap_batches', 'trg_guard_scrap_batch_initial_state_v263e')
  ) expected(table_name, trigger_name)
  where not exists (
    select 1
    from pg_trigger t
    join pg_class c on c.oid = t.tgrelid
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'erp'
      and c.relname = expected.table_name
      and t.tgname = expected.trigger_name
      and not t.tgisinternal
  )

  union all
  select
    'new_master_write_table_without_audit', 'ERROR', count(*)::bigint,
    'Directly writable reference tables in this closure must emit audit rows'
  from (values
    ('po_customer_visibility'), ('product_model_sizes'), ('sizes'),
    ('uom_definitions'), ('wash_processes'), ('work_components')
  ) expected(table_name)
  where not exists (
    select 1
    from pg_trigger t
    join pg_class c on c.oid = t.tgrelid
    join pg_namespace n on n.oid = c.relnamespace
    join pg_proc p on p.oid = t.tgfoid
    where n.nspname = 'erp'
      and c.relname = expected.table_name
      and p.proname = 'audit_row_change'
      and not t.tgisinternal
  )

  union all
  select
    'missing_case_nota_hot_path_index', 'ERROR', count(*)::bigint,
    'Release-defined hot-path indexes must remain installed'
  from (values
    ('erp.idx_bs_resolutions_bs_case'),
    ('erp.idx_laundry_claims_delivery'),
    ('erp.idx_laundry_receipt_lines_receipt'),
    ('erp.idx_rework_component_lines_bs_component'),
    ('erp.idx_payroll_work_items_component'),
    ('erp.idx_sales_returns_sale')
  ) expected(index_name)
  where to_regclass(expected.index_name) is null;
$$;

revoke all on function erp.run_v263e_red_team_integrity_checks() from public;
grant execute on function erp.run_v263e_red_team_integrity_checks()
  to authenticated, service_role;

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.3e',
  'Red-team closure for private triggers, lifecycle inserts, master cascade delete, audit coverage and hot indexes',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828080411','erp_v263e_red_team_closure',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828080411 erp_v263e_red_team_closure

-- BEGIN PLATFORM MIGRATION 20260828080921 erp_v264_material_transfer
-- ERP Garment v2.6.4
-- Atomic material/roll warehouse transfer with aggregate draft CRUD,
-- idempotent posting/reversal, optimistic locking, and browse read model.

set lock_timeout = '10s';
set statement_timeout = '180s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_4', 0));

do $$
begin
  if not exists (
    select 1 from erp.schema_migrations where version = 'v2.6.3e'
  ) then
    raise exception 'ERP Garment v2.6.3e is required before v2.6.4';
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. Transfer document and line contract
-- ---------------------------------------------------------------------------

create table erp.material_transfers (
  id uuid primary key default gen_random_uuid(),
  transfer_number varchar(80) not null unique,
  from_location_id uuid not null references erp.locations(id),
  to_location_id uuid not null references erp.locations(id),
  physical_at timestamptz not null,
  status varchar(20) not null default 'DRAFT'
    check (status in ('DRAFT', 'POSTED', 'REVERSED')),
  notes text,
  posted_at timestamptz,
  reversed_at timestamptz,
  reversal_reason text,
  created_by uuid references erp.app_users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  row_version bigint not null default 1 check (row_version > 0),
  check (from_location_id <> to_location_id),
  check (
    (status = 'DRAFT' and posted_at is null and reversed_at is null)
    or (status = 'POSTED' and posted_at is not null and reversed_at is null)
    or (status = 'REVERSED' and posted_at is not null and reversed_at is not null)
  )
);

create table erp.material_transfer_items (
  id uuid primary key default gen_random_uuid(),
  transfer_id uuid not null references erp.material_transfers(id) on delete cascade,
  material_id uuid not null references erp.materials(id),
  roll_id uuid references erp.material_rolls(id),
  qty numeric(24,6) not null check (qty > 0),
  notes text,
  created_at timestamptz not null default now(),
  constraint uq_material_transfer_item
    unique nulls not distinct (transfer_id, material_id, roll_id)
);

create index idx_material_transfers_from_physical
  on erp.material_transfers(from_location_id, physical_at desc, id);
create index idx_material_transfers_to_physical
  on erp.material_transfers(to_location_id, physical_at desc, id);
create index idx_material_transfers_status_physical
  on erp.material_transfers(status, physical_at desc, id);
create index idx_material_transfers_created_by
  on erp.material_transfers(created_by) where created_by is not null;
create index idx_material_transfer_items_material
  on erp.material_transfer_items(material_id);
create index idx_material_transfer_items_roll
  on erp.material_transfer_items(roll_id) where roll_id is not null;

alter table erp.material_transfers enable row level security;
alter table erp.material_transfer_items enable row level security;

create policy material_transfers_internal_read
on erp.material_transfers for select to authenticated
using ((select erp.current_app_role()) = any (array['OWNER','ADMIN','STAFF']));

create policy material_transfer_items_internal_read
on erp.material_transfer_items for select to authenticated
using ((select erp.current_app_role()) = any (array['OWNER','ADMIN','STAFF']));

grant select on erp.material_transfers, erp.material_transfer_items
  to authenticated, service_role;
revoke insert, update, delete on erp.material_transfers, erp.material_transfer_items
  from public, anon, authenticated;

drop trigger if exists trg_material_transfers_touch on erp.material_transfers;
create trigger trg_material_transfers_touch
before update on erp.material_transfers
for each row execute function erp.touch_updated_at();

drop trigger if exists trg_material_transfers_version on erp.material_transfers;
create trigger trg_material_transfers_version
before update on erp.material_transfers
for each row execute function erp.bump_row_version();

drop trigger if exists trg_material_transfers_guard on erp.material_transfers;
create trigger trg_material_transfers_guard
before insert or update or delete on erp.material_transfers
for each row execute function erp.guard_posted_document();

drop trigger if exists trg_material_transfers_audit on erp.material_transfers;
create trigger trg_material_transfers_audit
after insert or update or delete on erp.material_transfers
for each row execute function erp.audit_row_change();

drop trigger if exists trg_material_transfer_items_audit on erp.material_transfer_items;
create trigger trg_material_transfer_items_audit
after insert or update or delete on erp.material_transfer_items
for each row execute function erp.audit_row_change();

create or replace function erp.guard_material_transfer_item_parent()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $$
declare
  v_transfer_id uuid := case when tg_op = 'DELETE' then old.transfer_id else new.transfer_id end;
  v_status text;
  v_material_type text;
begin
  select status into v_status
  from erp.material_transfers
  where id = v_transfer_id
  for update;
  if v_status is null then raise exception 'Material transfer not found'; end if;
  if v_status <> 'DRAFT' then
    raise exception 'Posted/reversed material transfer lines are immutable';
  end if;

  if tg_op <> 'DELETE' then
    select material_type into v_material_type
    from erp.materials
    where id = new.material_id and is_active = true;
    if v_material_type is null then raise exception 'Active material is required'; end if;
    if v_material_type = 'FABRIC' and new.roll_id is null then
      raise exception 'FABRIC transfer requires concrete roll lineage';
    end if;
    if v_material_type <> 'FABRIC' and new.roll_id is not null then
      raise exception 'Only FABRIC may use roll_id in a warehouse transfer';
    end if;
    if new.roll_id is not null and not exists (
      select 1 from erp.material_rolls r
      where r.id = new.roll_id and r.material_id = new.material_id
    ) then
      raise exception 'Transfer roll does not belong to material';
    end if;
  end if;

  if tg_op = 'DELETE' then return old; else return new; end if;
end;
$$;

drop trigger if exists trg_guard_material_transfer_item_parent
  on erp.material_transfer_items;
create trigger trg_guard_material_transfer_item_parent
before insert or update or delete on erp.material_transfer_items
for each row execute function erp.guard_material_transfer_item_parent();

revoke all on function erp.guard_material_transfer_item_parent()
  from public, anon, authenticated;

-- Stock-card vocabulary: transfers are explicit, while reversal remains the
-- existing append-only reversal type linked with reversal_of_id.
alter table erp.material_stock_movements
  drop constraint material_stock_movements_movement_type_check;
alter table erp.material_stock_movements
  add constraint material_stock_movements_movement_type_check
  check (movement_type in (
    'OPENING','PURCHASE','CUTTING_ISSUE','CUTTING_RETURN','CONTRACTOR_ISSUE',
    'PERSONAL_USE','INTERNAL_USE','SAMPLE','DAMAGE','LOSS','SUPPLIER_RETURN',
    'ADJUSTMENT','TRANSFER_OUT','TRANSFER_IN','REVERSAL'
  ));

-- ---------------------------------------------------------------------------
-- 2. Aggregate draft save/delete
-- ---------------------------------------------------------------------------

create or replace function erp.save_material_transfer_draft_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_id uuid := nullif(p_payload->>'id', '')::uuid;
  v_action text := upper(coalesce(nullif(btrim(p_payload->>'action'), ''), 'SAVE'));
  v_reason text := nullif(btrim(p_payload->>'change_reason'), '');
  v_header erp.material_transfers%rowtype;
  v_line jsonb;
begin
  perform erp.require_internal();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if v_action not in ('SAVE','DELETE') then raise exception 'action must be SAVE or DELETE'; end if;
  if v_action = 'SAVE' and coalesce(jsonb_typeof(p_payload->'items'), 'null') <> 'array' then
    raise exception 'items must be a JSON array';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'payload', p_payload, 'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(
    'save_material_transfer_draft_v2', p_client_request_id, v_hash
  );
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  if v_id is null then
    if v_action = 'DELETE' then raise exception 'Transfer id is required for DELETE'; end if;
    if p_expected_version is not null then
      raise exception 'expected_version must be null when creating a transfer';
    end if;
    if coalesce(btrim(p_payload->>'transfer_number'), '') = '' then
      raise exception 'transfer_number is required';
    end if;
    insert into erp.material_transfers(
      transfer_number, from_location_id, to_location_id, physical_at,
      status, notes, created_by
    ) values (
      btrim(p_payload->>'transfer_number'),
      (p_payload->>'from_location_id')::uuid,
      (p_payload->>'to_location_id')::uuid,
      (p_payload->>'physical_at')::timestamptz,
      'DRAFT', nullif(btrim(p_payload->>'notes'), ''), erp.current_app_user_id()
    ) returning * into v_header;
    v_id := v_header.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into v_header from erp.material_transfers where id = v_id for update;
    if v_header.id is null then raise exception 'Material transfer not found'; end if;
    if v_header.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_header.row_version;
    end if;
    if v_header.status <> 'DRAFT' then
      raise exception 'Only DRAFT material transfer can be saved/deleted';
    end if;
    if v_action = 'DELETE' then
      delete from erp.material_transfers where id = v_id;
      v_response := jsonb_build_object('material_transfer_id', v_id, 'status', 'DELETED');
      return erp._idempotency_complete(
        'save_material_transfer_draft_v2', p_client_request_id, v_response
      );
    end if;
    update erp.material_transfers
    set transfer_number = coalesce(
          nullif(btrim(p_payload->>'transfer_number'), ''), v_header.transfer_number
        ),
        from_location_id = case when p_payload ? 'from_location_id'
          then (p_payload->>'from_location_id')::uuid else v_header.from_location_id end,
        to_location_id = case when p_payload ? 'to_location_id'
          then (p_payload->>'to_location_id')::uuid else v_header.to_location_id end,
        physical_at = coalesce(
          nullif(p_payload->>'physical_at', '')::timestamptz, v_header.physical_at
        ),
        notes = case when p_payload ? 'notes'
          then nullif(btrim(p_payload->>'notes'), '') else v_header.notes end
    where id = v_id
    returning * into v_header;
  end if;

  if jsonb_array_length(p_payload->'items') = 0 then
    raise exception 'At least one transfer item is required';
  end if;
  delete from erp.material_transfer_items where transfer_id = v_id;
  for v_line in select value from jsonb_array_elements(p_payload->'items') loop
    insert into erp.material_transfer_items(
      id, transfer_id, material_id, roll_id, qty, notes
    ) values (
      coalesce(nullif(v_line->>'id', '')::uuid, gen_random_uuid()),
      v_id, (v_line->>'material_id')::uuid,
      nullif(v_line->>'roll_id', '')::uuid,
      (v_line->>'qty')::numeric,
      nullif(btrim(v_line->>'notes'), '')
    );
  end loop;
  select * into v_header from erp.material_transfers where id = v_id;
  v_response := jsonb_build_object(
    'material_transfer_id', v_header.id,
    'transfer_number', v_header.transfer_number,
    'status', v_header.status,
    'row_version', v_header.row_version,
    'item_count', (select count(*) from erp.material_transfer_items i where i.transfer_id = v_id),
    'total_qty', (select sum(i.qty) from erp.material_transfer_items i where i.transfer_id = v_id)
  );
  return erp._idempotency_complete(
    'save_material_transfer_draft_v2', p_client_request_id, v_response
  );
end;
$$;

-- ---------------------------------------------------------------------------
-- 3. Atomic post and reversal
-- ---------------------------------------------------------------------------

create or replace function erp.post_material_transfer_v2(
  p_transfer_id uuid,
  p_client_request_id uuid,
  p_expected_version bigint,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_header erp.material_transfers%rowtype;
  r record;
  v_cost numeric(24,6);
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason), '') is null then raise exception 'Posting reason is required'; end if;
  v_hash := erp._request_hash(jsonb_build_object(
    'transfer_id', p_transfer_id, 'expected_version', p_expected_version,
    'reason', btrim(p_reason)
  ));
  v_cached := erp._idempotency_begin(
    'post_material_transfer_v2', p_client_request_id, v_hash
  );
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', btrim(p_reason), true);

  select * into v_header
  from erp.material_transfers where id = p_transfer_id for update;
  if v_header.id is null then raise exception 'Material transfer not found'; end if;
  if v_header.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_header.row_version;
  end if;
  if v_header.status <> 'DRAFT' then raise exception 'Material transfer must be DRAFT'; end if;
  if v_header.physical_at > clock_timestamp() + interval '5 minutes' then
    raise exception 'Transfer physical_at cannot be in the future';
  end if;
  if not exists (
    select 1 from erp.locations l
    where l.id = v_header.from_location_id and l.is_active
      and l.location_type = 'RAW_MATERIAL_WAREHOUSE'
  ) or not exists (
    select 1 from erp.locations l
    where l.id = v_header.to_location_id and l.is_active
      and l.location_type = 'RAW_MATERIAL_WAREHOUSE'
  ) then
    raise exception 'Both transfer locations must be active raw-material warehouses';
  end if;
  if not exists (
    select 1 from erp.material_transfer_items i where i.transfer_id = v_header.id
  ) then raise exception 'Material transfer requires at least one line'; end if;

  for r in
    select i.*, m.moving_average_cost
    from erp.material_transfer_items i
    join erp.materials m on m.id = i.material_id and m.is_active
    where i.transfer_id = v_header.id
    order by i.material_id, i.roll_id nulls first, i.id
  loop
    perform pg_advisory_xact_lock(hashtextextended(
      'MATTRANSFER|' || r.material_id::text || '|' ||
      coalesce(r.roll_id::text, 'NO_ROLL'), 0
    ));
    v_cost := coalesce(r.moving_average_cost, 0);
    insert into erp.material_stock_movements(
      material_id, roll_id, location_id, movement_type, qty_signed,
      input_unit_cost, source_type, source_id, physical_at, created_by, note
    ) values (
      r.material_id, r.roll_id, v_header.from_location_id, 'TRANSFER_OUT', -r.qty,
      v_cost, 'MATERIAL_TRANSFER', v_header.id, v_header.physical_at,
      erp.current_app_user_id(), coalesce(r.notes, 'Warehouse transfer out')
    );
    insert into erp.material_stock_movements(
      material_id, roll_id, location_id, movement_type, qty_signed,
      input_unit_cost, source_type, source_id, physical_at, created_by, note
    ) values (
      r.material_id, r.roll_id, v_header.to_location_id, 'TRANSFER_IN', r.qty,
      v_cost, 'MATERIAL_TRANSFER', v_header.id, v_header.physical_at,
      erp.current_app_user_id(), coalesce(r.notes, 'Warehouse transfer in')
    );
  end loop;

  for r in
    select distinct material_id
    from erp.material_transfer_items where transfer_id = v_header.id
  loop
    perform erp.recalculate_material_cost(r.material_id);
  end loop;

  update erp.material_transfers
  set status = 'POSTED', posted_at = clock_timestamp()
  where id = v_header.id
  returning * into v_header;

  v_response := jsonb_build_object(
    'material_transfer_id', v_header.id,
    'status', v_header.status,
    'row_version', v_header.row_version,
    'posted_at', v_header.posted_at,
    'movement_count', (
      select count(*) from erp.material_stock_movements m
      where m.source_type = 'MATERIAL_TRANSFER' and m.source_id = v_header.id
    )
  );
  return erp._idempotency_complete(
    'post_material_transfer_v2', p_client_request_id, v_response
  );
end;
$$;

create or replace function erp.reverse_material_transfer_v2(
  p_transfer_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_header erp.material_transfers%rowtype;
  r record;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason), '') is null then raise exception 'Reversal reason is required'; end if;
  v_hash := erp._request_hash(jsonb_build_object(
    'transfer_id', p_transfer_id, 'reason', btrim(p_reason),
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(
    'reverse_material_transfer_v2', p_client_request_id, v_hash
  );
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', btrim(p_reason), true);

  select * into v_header
  from erp.material_transfers where id = p_transfer_id for update;
  if v_header.id is null then raise exception 'Material transfer not found'; end if;
  if v_header.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_header.row_version;
  end if;
  if v_header.status <> 'POSTED' then raise exception 'Only POSTED transfer can be reversed'; end if;
  if exists (
    select 1
    from erp.material_stock_movements original
    join erp.material_stock_movements rv on rv.reversal_of_id = original.id
    where original.source_type = 'MATERIAL_TRANSFER'
      and original.source_id = v_header.id
  ) then raise exception 'Material transfer already has reversal movements'; end if;

  -- Reverse destination IN first so the normal negative-stock guard proves the
  -- destination still owns the quantity. Only then restore the source OUT.
  for r in
    select original.*
    from erp.material_stock_movements original
    where original.source_type = 'MATERIAL_TRANSFER'
      and original.source_id = v_header.id
    order by case original.movement_type when 'TRANSFER_IN' then 0 else 1 end,
             original.system_created_at, original.id
  loop
    insert into erp.material_stock_movements(
      material_id, roll_id, location_id, movement_type, qty_signed,
      input_unit_cost, source_type, source_id, physical_at, created_by,
      reversal_of_id, note
    ) values (
      r.material_id, r.roll_id, r.location_id, 'REVERSAL', -r.qty_signed,
      r.unit_cost_snapshot, 'MATERIAL_TRANSFER_REVERSAL', v_header.id,
      greatest(clock_timestamp(), r.physical_at), erp.current_app_user_id(),
      r.id, btrim(p_reason)
    );
  end loop;

  for r in
    select distinct material_id
    from erp.material_transfer_items where transfer_id = v_header.id
  loop
    perform erp.recalculate_material_cost(r.material_id);
  end loop;

  update erp.material_transfers
  set status = 'REVERSED', reversed_at = clock_timestamp(),
      reversal_reason = btrim(p_reason)
  where id = v_header.id
  returning * into v_header;

  v_response := jsonb_build_object(
    'material_transfer_id', v_header.id,
    'status', v_header.status,
    'row_version', v_header.row_version,
    'reversed_at', v_header.reversed_at,
    'reversal_movement_count', (
      select count(*)
      from erp.material_stock_movements m
      where m.source_type = 'MATERIAL_TRANSFER_REVERSAL'
        and m.source_id = v_header.id
    )
  );
  return erp._idempotency_complete(
    'reverse_material_transfer_v2', p_client_request_id, v_response
  );
end;
$$;

revoke all on function erp.save_material_transfer_draft_v2(jsonb,uuid,bigint)
  from public;
revoke all on function erp.post_material_transfer_v2(uuid,uuid,bigint,text)
  from public;
revoke all on function erp.reverse_material_transfer_v2(uuid,text,uuid,bigint)
  from public;
grant execute on function erp.save_material_transfer_draft_v2(jsonb,uuid,bigint)
  to authenticated, service_role;
grant execute on function erp.post_material_transfer_v2(uuid,uuid,bigint,text)
  to authenticated, service_role;
grant execute on function erp.reverse_material_transfer_v2(uuid,text,uuid,bigint)
  to authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 4. Browse-first transfer read model
-- ---------------------------------------------------------------------------

create or replace view erp.v_material_transfer_browser
with (security_invoker = true)
as
select
  h.id transfer_id,
  h.transfer_number,
  h.physical_at,
  h.status,
  h.from_location_id,
  f.location_code from_location_code,
  f.location_name from_location_name,
  h.to_location_id,
  t.location_code to_location_code,
  t.location_name to_location_name,
  count(i.id)::bigint item_count,
  coalesce(sum(i.qty), 0)::numeric(24,6) total_qty,
  count(distinct i.material_id)::bigint material_count,
  count(i.roll_id)::bigint roll_line_count,
  h.notes,
  h.posted_at,
  h.reversed_at,
  h.reversal_reason,
  h.row_version,
  h.created_at,
  h.updated_at,
  concat_ws(' ', h.transfer_number, f.location_code, f.location_name,
    t.location_code, t.location_name, h.status, h.notes) search_text
from erp.material_transfers h
join erp.locations f on f.id = h.from_location_id
join erp.locations t on t.id = h.to_location_id
left join erp.material_transfer_items i on i.transfer_id = h.id
group by h.id, f.id, t.id;

grant select on erp.v_material_transfer_browser to authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 5. Integrity/security checks
-- ---------------------------------------------------------------------------

create or replace function erp.run_v264_material_transfer_integrity_checks()
returns table(check_name text, severity text, issue_count bigint, details text)
language sql
stable
security definer
set search_path = erp, public, pg_catalog, information_schema, pg_temp
as $$
  select
    'posted_transfer_without_balanced_pair', 'CRITICAL', count(*)::bigint,
    'Every posted transfer line must have one active OUT and one active IN of equal quantity'
  from erp.material_transfer_items i
  join erp.material_transfers h on h.id = i.transfer_id and h.status = 'POSTED'
  where not exists (
    select 1
    from erp.material_stock_movements o
    join erp.material_stock_movements n
      on n.source_type = o.source_type and n.source_id = o.source_id
     and n.material_id = o.material_id and n.roll_id is not distinct from o.roll_id
    where o.source_type = 'MATERIAL_TRANSFER' and o.source_id = h.id
      and o.material_id = i.material_id and o.roll_id is not distinct from i.roll_id
      and o.movement_type = 'TRANSFER_OUT' and o.location_id = h.from_location_id
      and n.movement_type = 'TRANSFER_IN' and n.location_id = h.to_location_id
      and o.qty_signed = -i.qty and n.qty_signed = i.qty
      and not exists (select 1 from erp.material_stock_movements r where r.reversal_of_id = o.id)
      and not exists (select 1 from erp.material_stock_movements r where r.reversal_of_id = n.id)
  )

  union all
  select
    'reversed_transfer_with_active_source_movement', 'CRITICAL', count(*)::bigint,
    'Every source movement of a reversed transfer must have exactly one reversal'
  from erp.material_stock_movements o
  join erp.material_transfers h
    on o.source_type = 'MATERIAL_TRANSFER' and o.source_id = h.id
  where h.status = 'REVERSED'
    and (select count(*) from erp.material_stock_movements r where r.reversal_of_id = o.id) <> 1

  union all
  select
    'transfer_changes_global_material_qty', 'CRITICAL', count(*)::bigint,
    'An unreversed warehouse transfer must net zero globally per material/roll'
  from (
    select h.id, m.material_id, m.roll_id, sum(m.qty_signed) net_qty
    from erp.material_transfers h
    join erp.material_stock_movements m
      on m.source_type = 'MATERIAL_TRANSFER' and m.source_id = h.id
    where h.status = 'POSTED'
      and not exists (select 1 from erp.material_stock_movements r where r.reversal_of_id = m.id)
    group by h.id, m.material_id, m.roll_id
    having abs(sum(m.qty_signed)) > 0.000001
  ) bad

  union all
  select
    'browser_direct_transfer_write_grant', 'CRITICAL', count(*)::bigint,
    'Browser roles must mutate transfer header and lines only through aggregate RPCs'
  from information_schema.role_table_grants g
  where g.table_schema = 'erp'
    and g.table_name in ('material_transfers', 'material_transfer_items')
    and g.grantee in ('PUBLIC', 'anon', 'authenticated')
    and g.privilege_type in ('INSERT','UPDATE','DELETE')

  union all
  select
    'transfer_view_not_security_invoker', 'CRITICAL', count(*)::bigint,
    'Material transfer browser must honor caller RLS'
  from pg_class c
  join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'erp' and c.relname = 'v_material_transfer_browser'
    and coalesce(c.reloptions, array[]::text[]) @> array['security_invoker=false'];
$$;

revoke all on function erp.run_v264_material_transfer_integrity_checks()
  from public;
grant execute on function erp.run_v264_material_transfer_integrity_checks()
  to authenticated, service_role;

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.4',
  'Atomic material and roll warehouse transfer with safe draft, post, reversal and browser model',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828080921','erp_v264_material_transfer',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828080921 erp_v264_material_transfer

-- BEGIN PLATFORM MIGRATION 20260828081426 erp_v264a_cutting_presewing_reversal
-- ERP Garment v2.6.4a
-- Controlled reversal of cutting material flow before sewing so mistaken
-- Potongan/Diambil Mandor records can be corrected or deleted safely.

set lock_timeout = '10s';
set statement_timeout = '180s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_4a', 0));

do $$
begin
  if not exists (
    select 1 from erp.schema_migrations where version = 'v2.6.4'
  ) then
    raise exception 'ERP Garment v2.6.4 is required before v2.6.4a';
  end if;
end;
$$;

-- One source movement may be reversed exactly once. This closes concurrent
-- double-reversal races across all material workflows, not only cutting.
create unique index if not exists uq_material_stock_movement_single_reversal
  on erp.material_stock_movements(reversal_of_id)
  where reversal_of_id is not null;

create or replace function erp.cutting_group_has_downstream_after_pickup(
  p_cutting_group_id uuid
)
returns boolean
language sql
stable
security definer
set search_path = erp, public, pg_temp
as $$
  select
       exists(select 1 from erp.wip_stage_events w where w.cutting_group_id = p_cutting_group_id)
    or exists(
      select 1 from erp.work_completion_events w
      where w.cutting_group_id = p_cutting_group_id and w.status <> 'DRAFT'
    )
    or exists(
      select 1
      from erp.laundry_delivery_lines ldl
      join erp.laundry_deliveries ld on ld.id = ldl.delivery_id
      where ldl.cutting_group_id = p_cutting_group_id
        and ld.status not in ('DRAFT','REVERSED')
    )
    or exists(
      select 1
      from erp.qc_inspection_items qi
      join erp.qc_inspections qh on qh.id = qi.inspection_id
      where qi.cutting_group_id = p_cutting_group_id and qh.status <> 'DRAFT'
    )
    or exists(
      select 1 from erp.fg_lots f
      where f.cutting_group_id = p_cutting_group_id
        and f.lot_origin <> 'VOIDED_PRODUCTION'
    )
    or exists(
      select 1 from erp.bs_cases b
      where b.cutting_group_id = p_cutting_group_id and b.status <> 'CANCELLED'
    )
    or exists(
      select 1 from erp.scrap_batches s
      where s.source_cutting_group_id = p_cutting_group_id
    )
    or exists(
      select 1 from erp.cutting_qty_correction_lines c
      where c.cutting_group_id = p_cutting_group_id
    );
$$;

revoke all on function erp.cutting_group_has_downstream_after_pickup(uuid)
  from public;
grant execute on function erp.cutting_group_has_downstream_after_pickup(uuid)
  to authenticated, service_role;

-- A fully reversed material flow no longer blocks a pre-sewing correction.
-- The immutable original and reversal movements stay in the stock card/audit.
create or replace function erp.is_cutting_group_presewing_reversible(
  p_cutting_group_id uuid
)
returns boolean
language sql
stable
security definer
set search_path = erp, public, pg_temp
as $$
  select coalesce((
    select
      cg.status in ('CUT','PICKED_UP')
      and not cg.material_issue_posted
      and not cg.material_return_posted
      and not exists (
        select 1 from erp.material_stock_movements m
        where m.source_id = cg.id
          and m.source_type in ('CUTTING_GROUP','CUTTING_GROUP_RETURN')
          and not exists (
            select 1 from erp.material_stock_movements rv
            where rv.reversal_of_id = m.id
          )
      )
      and not erp.cutting_group_has_downstream_after_pickup(cg.id)
    from erp.cutting_groups cg
    where cg.id = p_cutting_group_id
  ), false);
$$;

revoke all on function erp.is_cutting_group_presewing_reversible(uuid)
  from public;
grant execute on function erp.is_cutting_group_presewing_reversible(uuid)
  to authenticated, service_role;

create or replace function erp.reverse_cutting_material_flow_before_sewing_v2(
  p_cutting_group_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_group erp.cutting_groups%rowtype;
  r record;
  v_reversed_movements integer := 0;
  v_reversed_journals integer := 0;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason), '') is null then raise exception 'Reversal reason is required'; end if;
  v_hash := erp._request_hash(jsonb_build_object(
    'cutting_group_id', p_cutting_group_id,
    'reason', btrim(p_reason),
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(
    'reverse_cutting_material_flow_before_sewing_v2', p_client_request_id, v_hash
  );
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', btrim(p_reason), true);

  select * into v_group
  from erp.cutting_groups where id = p_cutting_group_id for update;
  if v_group.id is null then raise exception 'Potongan not found'; end if;
  if v_group.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_group.row_version;
  end if;
  if v_group.status not in ('CUT','PICKED_UP') then
    raise exception 'Only CUT/PICKED_UP Potongan can use pre-sewing material reversal';
  end if;
  if erp.cutting_group_has_downstream_after_pickup(v_group.id) then
    raise exception 'Potongan already has sewing/downstream evidence; reverse downstream documents instead';
  end if;
  if not v_group.material_issue_posted
     and not v_group.material_return_posted
     and not exists (
       select 1 from erp.material_stock_movements m
       where m.source_id = v_group.id
         and m.source_type in ('CUTTING_GROUP','CUTTING_GROUP_RETURN')
         and not exists (
           select 1 from erp.material_stock_movements rv where rv.reversal_of_id = m.id
         )
     )
  then raise exception 'Potongan has no active cutting material flow to reverse'; end if;

  -- Reverse posted return journals first, then the original issue journal.
  -- Any later failure rolls this whole function back atomically.
  for r in
    select je.id
    from erp.journal_entries je
    join erp.cutting_group_rolls cgr on cgr.id = je.source_id
    where cgr.cutting_group_id = v_group.id
      and je.source_type = 'CUTTING_MATERIAL_RETURN_LINE'
      and je.status = 'POSTED'
    order by je.posting_at desc, je.id desc
  loop
    perform erp.reverse_journal(r.id, btrim(p_reason));
    v_reversed_journals := v_reversed_journals + 1;
  end loop;

  for r in
    select je.id
    from erp.journal_entries je
    where je.source_type = 'CUTTING_MATERIAL_ISSUE'
      and je.source_id = v_group.id
      and je.status = 'POSTED'
    order by je.posting_at desc, je.id desc
  loop
    perform erp.reverse_journal(r.id, btrim(p_reason));
    v_reversed_journals := v_reversed_journals + 1;
  end loop;

  -- Positive cutting returns are removed from warehouse first. The normal
  -- negative-stock guard blocks reversal if that returned quantity was consumed.
  -- The original issue is then restored to its source warehouse.
  for r in
    select m.*
    from erp.material_stock_movements m
    where m.source_id = v_group.id
      and m.source_type in ('CUTTING_GROUP','CUTTING_GROUP_RETURN')
      and not exists (
        select 1 from erp.material_stock_movements rv where rv.reversal_of_id = m.id
      )
    order by case m.source_type when 'CUTTING_GROUP_RETURN' then 0 else 1 end,
             m.system_created_at, m.id
  loop
    insert into erp.material_stock_movements(
      material_id, roll_id, location_id, movement_type, qty_signed,
      input_unit_cost, source_type, source_id, physical_at, created_by,
      reversal_of_id, note
    ) values (
      r.material_id, r.roll_id, r.location_id, 'REVERSAL', -r.qty_signed,
      r.unit_cost_snapshot, 'CUTTING_PRESEWING_REVERSAL', v_group.id,
      greatest(clock_timestamp(), r.physical_at), erp.current_app_user_id(),
      r.id, btrim(p_reason)
    );
    v_reversed_movements := v_reversed_movements + 1;
  end loop;

  for r in
    select distinct m.material_id
    from erp.material_stock_movements m
    where m.source_id = v_group.id
      and m.source_type in ('CUTTING_GROUP','CUTTING_GROUP_RETURN')
  loop
    perform erp.recalculate_material_cost(r.material_id);
  end loop;

  update erp.cutting_groups
  set material_issue_posted = false,
      material_return_posted = false,
      status = case when picked_up_at is null then 'CUT' else 'PICKED_UP' end,
      updated_at = now()
  where id = v_group.id
  returning * into v_group;

  v_response := jsonb_build_object(
    'cutting_group_id', v_group.id,
    'status', v_group.status,
    'row_version', v_group.row_version,
    'reversed_movement_count', v_reversed_movements,
    'reversed_journal_count', v_reversed_journals,
    'presewing_reversible', erp.is_cutting_group_presewing_reversible(v_group.id)
  );
  return erp._idempotency_complete(
    'reverse_cutting_material_flow_before_sewing_v2',
    p_client_request_id, v_response
  );
end;
$$;

revoke all on function erp.reverse_cutting_material_flow_before_sewing_v2(
  uuid,text,uuid,bigint
) from public;
grant execute on function erp.reverse_cutting_material_flow_before_sewing_v2(
  uuid,text,uuid,bigint
) to authenticated, service_role;

create or replace function erp.run_v264a_cutting_presewing_integrity_checks()
returns table(check_name text, severity text, issue_count bigint, details text)
language sql
stable
security definer
set search_path = erp, public, pg_catalog, information_schema, pg_temp
as $$
  select
    'duplicate_material_movement_reversal', 'CRITICAL', count(*)::bigint,
    'A material movement may have at most one reversal'
  from (
    select reversal_of_id
    from erp.material_stock_movements
    where reversal_of_id is not null
    group by reversal_of_id having count(*) > 1
  ) bad

  union all
  select
    'cutting_issue_flag_without_active_movement', 'CRITICAL', count(*)::bigint,
    'material_issue_posted requires an active CUTTING_GROUP movement'
  from erp.cutting_groups cg
  where cg.material_issue_posted
    and not exists (
      select 1 from erp.material_stock_movements m
      where m.source_type = 'CUTTING_GROUP' and m.source_id = cg.id
        and not exists (
          select 1 from erp.material_stock_movements rv where rv.reversal_of_id = m.id
        )
    )

  union all
  select
    'active_cutting_issue_without_flag', 'CRITICAL', count(*)::bigint,
    'An active CUTTING_GROUP movement requires material_issue_posted=true'
  from erp.cutting_groups cg
  where not cg.material_issue_posted
    and exists (
      select 1 from erp.material_stock_movements m
      where m.source_type = 'CUTTING_GROUP' and m.source_id = cg.id
        and not exists (
          select 1 from erp.material_stock_movements rv where rv.reversal_of_id = m.id
        )
    )

  union all
  select
    'cutting_return_flag_without_active_movement', 'CRITICAL', count(*)::bigint,
    'material_return_posted requires an active CUTTING_GROUP_RETURN movement when returned qty exists'
  from erp.cutting_groups cg
  where cg.material_return_posted
    and exists (
      select 1 from erp.cutting_group_rolls cgr
      where cgr.cutting_group_id = cg.id and cgr.qty_physically_returned > 0
    )
    and not exists (
      select 1 from erp.material_stock_movements m
      where m.source_type = 'CUTTING_GROUP_RETURN' and m.source_id = cg.id
        and not exists (
          select 1 from erp.material_stock_movements rv where rv.reversal_of_id = m.id
        )
    )

  union all
  select
    'presewing_reversal_without_reason', 'ERROR', count(*)::bigint,
    'Every pre-sewing stock reversal must retain a reason in its append-only row'
  from erp.material_stock_movements m
  where m.source_type = 'CUTTING_PRESEWING_REVERSAL'
    and nullif(btrim(m.note), '') is null;
$$;

revoke all on function erp.run_v264a_cutting_presewing_integrity_checks()
  from public;
grant execute on function erp.run_v264a_cutting_presewing_integrity_checks()
  to authenticated, service_role;

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.4a',
  'Controlled cutting material reversal before sewing, preserving stock and journal lineage',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828081426','erp_v264a_cutting_presewing_reversal',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828081426 erp_v264a_cutting_presewing_reversal

-- BEGIN PLATFORM MIGRATION 20260828082102 erp_v264b_platform_hygiene
-- ERP Garment v2.6.4b
-- Database-side platform hygiene for temporary installer/export storage.
-- Edge Function retirement is a project deployment action documented separately.

set lock_timeout = '10s';
set statement_timeout = '60s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_4b', 0));

do $$
begin
  if not exists (
    select 1 from erp.schema_migrations where version = 'v2.6.4a'
  ) then
    raise exception 'ERP Garment v2.6.4a is required before v2.6.4b';
  end if;
end;
$$;

-- Preserve the installer export object for recovery, but remove anonymous
-- public delivery. No storage object/policy is deleted by this migration.
update storage.buckets
set public = false,
    updated_at = now()
where id = 'chatgpt-temp-erp-export'
  and public = true;

create or replace function erp.run_v264b_platform_storage_integrity_checks()
returns table(check_name text, severity text, issue_count bigint, details text)
language sql
stable
security definer
set search_path = erp, public, storage, pg_catalog, information_schema, pg_temp
as $$
  select
    'public_temporary_erp_export_bucket', 'CRITICAL', count(*)::bigint,
    'Temporary installer/export buckets must never be publicly readable'
  from storage.buckets b
  where b.id = 'chatgpt-temp-erp-export' and b.public

  union all
  select
    'anonymous_temp_export_object_policy', 'CRITICAL', count(*)::bigint,
    'No anon/PUBLIC storage policy may expose the temporary ERP export bucket'
  from pg_policies p
  where p.schemaname = 'storage' and p.tablename = 'objects'
    and (
      'anon' = any(p.roles) or 'public' = any(p.roles)
      or p.roles = array['public']::name[]
    )
    and concat_ws(' ', p.qual, p.with_check) ilike '%chatgpt-temp-erp-export%';
$$;

revoke all on function erp.run_v264b_platform_storage_integrity_checks()
  from public;
grant execute on function erp.run_v264b_platform_storage_integrity_checks()
  to authenticated, service_role;

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.4b',
  'Make temporary ERP export storage private and add platform storage checks',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828082102','erp_v264b_platform_hygiene',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828082102 erp_v264b_platform_hygiene

-- BEGIN PLATFORM MIGRATION 20260828082704 erp_v265_gudang_write_contracts
-- ERP Garment v2.6.5
-- Safe Gudang write contracts for material adjustments, supplier returns,
-- and material/accessory issues to contractors.

set lock_timeout = '10s';
set statement_timeout = '180s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_5', 0));

do $$
begin
  if not exists (
    select 1 from erp.schema_migrations where version = 'v2.6.4b'
  ) then
    raise exception 'ERP Garment v2.6.4b is required before v2.6.5';
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. Concurrency, audit and browser-write closure
-- ---------------------------------------------------------------------------

alter table erp.material_adjustments
  add column if not exists row_version bigint not null default 1;
alter table erp.material_supplier_returns
  add column if not exists row_version bigint not null default 1;
alter table erp.contractor_material_issues
  add column if not exists row_version bigint not null default 1;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'erp.material_adjustments'::regclass
      and conname = 'material_adjustments_row_version_check'
  ) then
    alter table erp.material_adjustments
      add constraint material_adjustments_row_version_check check (row_version > 0);
  end if;
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'erp.material_supplier_returns'::regclass
      and conname = 'material_supplier_returns_row_version_check'
  ) then
    alter table erp.material_supplier_returns
      add constraint material_supplier_returns_row_version_check check (row_version > 0);
  end if;
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'erp.contractor_material_issues'::regclass
      and conname = 'contractor_material_issues_row_version_check'
  ) then
    alter table erp.contractor_material_issues
      add constraint contractor_material_issues_row_version_check check (row_version > 0);
  end if;
end;
$$;

drop trigger if exists trg_material_adjustments_version_v265
  on erp.material_adjustments;
create trigger trg_material_adjustments_version_v265
before update on erp.material_adjustments
for each row execute function erp.bump_row_version();

drop trigger if exists trg_material_supplier_returns_version_v265
  on erp.material_supplier_returns;
create trigger trg_material_supplier_returns_version_v265
before update on erp.material_supplier_returns
for each row execute function erp.bump_row_version();

drop trigger if exists trg_contractor_material_issues_version_v265
  on erp.contractor_material_issues;
create trigger trg_contractor_material_issues_version_v265
before update on erp.contractor_material_issues
for each row execute function erp.bump_row_version();

drop trigger if exists trg_audit_material_adjustment_items_v265
  on erp.material_adjustment_items;
create trigger trg_audit_material_adjustment_items_v265
after insert or update or delete on erp.material_adjustment_items
for each row execute function erp.audit_row_change();

revoke insert, update, delete on
  erp.material_adjustments,
  erp.material_adjustment_items,
  erp.material_supplier_returns,
  erp.material_supplier_return_items,
  erp.contractor_material_issues,
  erp.contractor_material_issue_items
from public, anon, authenticated;

-- Legacy posting routines remain available to service/backend composition only.
revoke execute on function erp.post_material_adjustment(uuid)
  from public, authenticated;
revoke execute on function erp.reverse_material_adjustment(uuid,text)
  from public, authenticated;
revoke execute on function erp.post_material_supplier_return(uuid)
  from public, authenticated;
revoke execute on function erp.reverse_material_supplier_return(uuid,text)
  from public, authenticated;
revoke execute on function erp.post_contractor_material_issue(uuid)
  from public, authenticated;
revoke execute on function erp.reverse_contractor_material_issue(uuid,text)
  from public, authenticated;
grant execute on function erp.post_material_adjustment(uuid),
  erp.reverse_material_adjustment(uuid,text),
  erp.post_material_supplier_return(uuid),
  erp.reverse_material_supplier_return(uuid,text),
  erp.post_contractor_material_issue(uuid),
  erp.reverse_contractor_material_issue(uuid,text)
to service_role;

-- ---------------------------------------------------------------------------
-- 2. Material adjustment: aggregate draft, post and reversal
-- ---------------------------------------------------------------------------

create or replace function erp.save_material_adjustment_draft_v2(
  p_payload jsonb, p_client_request_id uuid, p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text; v_cached jsonb; v_response jsonb;
  v_id uuid := nullif(p_payload->>'id', '')::uuid;
  v_action text := upper(coalesce(nullif(btrim(p_payload->>'action'), ''), 'SAVE'));
  v_reason text := nullif(btrim(p_payload->>'change_reason'), '');
  v_header erp.material_adjustments%rowtype;
  v_line jsonb; v_type text; v_roll uuid; v_material uuid;
begin
  perform erp.require_internal();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if v_action not in ('SAVE','DELETE') then raise exception 'action must be SAVE or DELETE'; end if;
  if v_action = 'SAVE' and coalesce(jsonb_typeof(p_payload->'items'), 'null') <> 'array' then
    raise exception 'items must be a JSON array';
  end if;
  v_hash := erp._request_hash(jsonb_build_object(
    'payload', p_payload, 'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(
    'save_material_adjustment_draft_v2', p_client_request_id, v_hash
  );
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  if v_id is null then
    if v_action = 'DELETE' then raise exception 'Adjustment id is required for DELETE'; end if;
    if p_expected_version is not null then raise exception 'expected_version must be null on create'; end if;
    insert into erp.material_adjustments(
      adjustment_number, reason_code, physical_at, status, notes, created_by, location_id
    ) values(
      btrim(p_payload->>'adjustment_number'), upper(p_payload->>'reason_code'),
      (p_payload->>'physical_at')::timestamptz, 'DRAFT',
      nullif(btrim(p_payload->>'notes'), ''), erp.current_app_user_id(),
      (p_payload->>'location_id')::uuid
    ) returning * into v_header;
    v_id := v_header.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into v_header from erp.material_adjustments where id = v_id for update;
    if v_header.id is null then raise exception 'Material adjustment not found'; end if;
    if v_header.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_header.row_version;
    end if;
    if v_header.status <> 'DRAFT' then raise exception 'Only DRAFT adjustment can be saved/deleted'; end if;
    if v_action = 'DELETE' then
      delete from erp.material_adjustments where id = v_id;
      v_response := jsonb_build_object('material_adjustment_id', v_id, 'status', 'DELETED');
      return erp._idempotency_complete(
        'save_material_adjustment_draft_v2', p_client_request_id, v_response
      );
    end if;
    update erp.material_adjustments
    set adjustment_number = coalesce(
          nullif(btrim(p_payload->>'adjustment_number'), ''), v_header.adjustment_number
        ),
        reason_code = upper(coalesce(nullif(p_payload->>'reason_code', ''), v_header.reason_code)),
        physical_at = coalesce(
          nullif(p_payload->>'physical_at', '')::timestamptz, v_header.physical_at
        ),
        location_id = case when p_payload ? 'location_id'
          then (p_payload->>'location_id')::uuid else v_header.location_id end,
        notes = case when p_payload ? 'notes'
          then nullif(btrim(p_payload->>'notes'), '') else v_header.notes end
    where id = v_id returning * into v_header;
  end if;

  if jsonb_array_length(p_payload->'items') = 0 then
    raise exception 'At least one adjustment line is required';
  end if;
  if not exists(
    select 1 from erp.locations l where l.id = v_header.location_id
      and l.is_active and l.location_type = 'RAW_MATERIAL_WAREHOUSE'
  ) then raise exception 'Adjustment location must be an active raw-material warehouse'; end if;
  delete from erp.material_adjustment_items where adjustment_id = v_id;
  for v_line in select value from jsonb_array_elements(p_payload->'items') loop
    v_material := (v_line->>'material_id')::uuid;
    v_roll := nullif(v_line->>'roll_id', '')::uuid;
    select material_type into v_type from erp.materials
    where id = v_material and is_active;
    if v_type is null then raise exception 'Active material is required'; end if;
    if v_type = 'FABRIC' and v_roll is null then raise exception 'FABRIC adjustment requires roll_id'; end if;
    if v_type <> 'FABRIC' and v_roll is not null then raise exception 'Only FABRIC may use roll_id'; end if;
    if v_roll is not null and not exists(
      select 1 from erp.material_rolls r where r.id = v_roll and r.material_id = v_material
    ) then raise exception 'Adjustment roll does not belong to material'; end if;
    insert into erp.material_adjustment_items(
      id, adjustment_id, material_id, roll_id, qty_signed, input_unit_cost, notes
    ) values(
      coalesce(nullif(v_line->>'id', '')::uuid, gen_random_uuid()),
      v_id, v_material, v_roll, (v_line->>'qty_signed')::numeric,
      nullif(v_line->>'input_unit_cost', '')::numeric,
      nullif(btrim(v_line->>'notes'), '')
    );
  end loop;
  select * into v_header from erp.material_adjustments where id = v_id;
  v_response := jsonb_build_object(
    'material_adjustment_id', v_header.id, 'status', v_header.status,
    'row_version', v_header.row_version,
    'item_count', (select count(*) from erp.material_adjustment_items i where i.adjustment_id = v_id),
    'net_qty', (select sum(i.qty_signed) from erp.material_adjustment_items i where i.adjustment_id = v_id)
  );
  return erp._idempotency_complete(
    'save_material_adjustment_draft_v2', p_client_request_id, v_response
  );
end;
$$;

create or replace function erp.post_material_adjustment_v2(
  p_adjustment_id uuid, p_client_request_id uuid,
  p_expected_version bigint, p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare v_hash text; v_cached jsonb; v_response jsonb; h erp.material_adjustments%rowtype;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason), '') is null then raise exception 'Posting reason is required'; end if;
  v_hash := erp._request_hash(jsonb_build_object(
    'id',p_adjustment_id,'expected_version',p_expected_version,'reason',btrim(p_reason)
  ));
  v_cached := erp._idempotency_begin('post_material_adjustment_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.material_adjustments where id=p_adjustment_id for update;
  if h.id is null then raise exception 'Material adjustment not found'; end if;
  if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
  perform erp.post_material_adjustment(h.id);
  select * into h from erp.material_adjustments where id=h.id;
  v_response:=jsonb_build_object('material_adjustment_id',h.id,'status',h.status,'row_version',h.row_version);
  return erp._idempotency_complete('post_material_adjustment_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.reverse_material_adjustment_v2(
  p_adjustment_id uuid, p_reason text,
  p_client_request_id uuid, p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare v_hash text; v_cached jsonb; v_response jsonb; h erp.material_adjustments%rowtype;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason), '') is null then raise exception 'Reversal reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('id',p_adjustment_id,'reason',btrim(p_reason),'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('reverse_material_adjustment_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.material_adjustments where id=p_adjustment_id for update;
  if h.id is null then raise exception 'Material adjustment not found'; end if;
  if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
  perform erp.reverse_material_adjustment(h.id,btrim(p_reason));
  select * into h from erp.material_adjustments where id=h.id;
  v_response:=jsonb_build_object('material_adjustment_id',h.id,'status',h.status,'row_version',h.row_version);
  return erp._idempotency_complete('reverse_material_adjustment_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 3. Supplier return: aggregate draft with server-owned credit provenance
-- ---------------------------------------------------------------------------

create or replace function erp.save_material_supplier_return_draft_v2(
  p_payload jsonb, p_client_request_id uuid, p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text; v_cached jsonb; v_response jsonb;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_action text:=upper(coalesce(nullif(btrim(p_payload->>'action'),''),'SAVE'));
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  h erp.material_supplier_returns%rowtype; v_line jsonb;
begin
  perform erp.require_internal();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if v_action not in('SAVE','DELETE') then raise exception 'action must be SAVE or DELETE'; end if;
  if v_action='SAVE' and coalesce(jsonb_typeof(p_payload->'items'),'null')<>'array' then raise exception 'items must be a JSON array'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('save_material_supplier_return_draft_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',v_reason,true);
  if v_id is null then
    if v_action='DELETE' then raise exception 'Return id is required for DELETE'; end if;
    if p_expected_version is not null then raise exception 'expected_version must be null on create'; end if;
    insert into erp.material_supplier_returns(
      return_number,supplier_id,location_id,physical_at,status,reason,created_by
    ) values(
      btrim(p_payload->>'return_number'),(p_payload->>'supplier_id')::uuid,
      (p_payload->>'location_id')::uuid,(p_payload->>'physical_at')::timestamptz,
      'DRAFT',coalesce(nullif(btrim(p_payload->>'reason'),''),v_reason),erp.current_app_user_id()
    ) returning * into h; v_id:=h.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into h from erp.material_supplier_returns where id=v_id for update;
    if h.id is null then raise exception 'Supplier return not found'; end if;
    if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
    if h.status<>'DRAFT' then raise exception 'Only DRAFT supplier return can be saved/deleted'; end if;
    if v_action='DELETE' then
      delete from erp.material_supplier_returns where id=v_id;
      v_response:=jsonb_build_object('material_supplier_return_id',v_id,'status','DELETED');
      return erp._idempotency_complete('save_material_supplier_return_draft_v2',p_client_request_id,v_response);
    end if;
    update erp.material_supplier_returns
    set return_number=coalesce(nullif(btrim(p_payload->>'return_number'),''),h.return_number),
        supplier_id=case when p_payload?'supplier_id' then (p_payload->>'supplier_id')::uuid else h.supplier_id end,
        location_id=case when p_payload?'location_id' then (p_payload->>'location_id')::uuid else h.location_id end,
        physical_at=coalesce(nullif(p_payload->>'physical_at','')::timestamptz,h.physical_at),
        reason=case when p_payload?'reason' then coalesce(nullif(btrim(p_payload->>'reason'),''),v_reason) else h.reason end
    where id=v_id returning * into h;
  end if;
  if jsonb_array_length(p_payload->'items')=0 then raise exception 'At least one supplier return line is required'; end if;
  if not exists(select 1 from erp.locations l where l.id=h.location_id and l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE') then
    raise exception 'Supplier return location must be an active raw-material warehouse';
  end if;
  delete from erp.material_supplier_return_items where return_id=v_id;
  for v_line in select value from jsonb_array_elements(p_payload->'items') loop
    -- supplier_credit_unit_price is deliberately omitted: the source validator
    -- resolves it from the authoritative current purchase cost.
    insert into erp.material_supplier_return_items(
      id,return_id,material_id,roll_id,qty,notes,purchase_item_id
    ) values(
      coalesce(nullif(v_line->>'id','')::uuid,gen_random_uuid()),v_id,
      (v_line->>'material_id')::uuid,nullif(v_line->>'roll_id','')::uuid,
      (v_line->>'qty')::numeric,nullif(btrim(v_line->>'notes'),''),
      nullif(v_line->>'purchase_item_id','')::uuid
    );
  end loop;
  select * into h from erp.material_supplier_returns where id=v_id;
  v_response:=jsonb_build_object(
    'material_supplier_return_id',h.id,'status',h.status,'row_version',h.row_version,
    'item_count',(select count(*) from erp.material_supplier_return_items i where i.return_id=v_id),
    'total_qty',(select sum(i.qty) from erp.material_supplier_return_items i where i.return_id=v_id),
    'credit_total',(select sum(i.qty*i.supplier_credit_unit_price) from erp.material_supplier_return_items i where i.return_id=v_id)
  );
  return erp._idempotency_complete('save_material_supplier_return_draft_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.post_material_supplier_return_v2(
  p_return_id uuid,p_client_request_id uuid,p_expected_version bigint,p_reason text
)
returns jsonb language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare v_hash text;v_cached jsonb;v_response jsonb;h erp.material_supplier_returns%rowtype;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'Posting reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('id',p_return_id,'expected_version',p_expected_version,'reason',btrim(p_reason)));
  v_cached:=erp._idempotency_begin('post_material_supplier_return_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.material_supplier_returns where id=p_return_id for update;
  if h.id is null then raise exception 'Supplier return not found'; end if;
  if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
  perform erp.post_material_supplier_return(h.id);
  select * into h from erp.material_supplier_returns where id=h.id;
  v_response:=jsonb_build_object('material_supplier_return_id',h.id,'status',h.status,'row_version',h.row_version);
  return erp._idempotency_complete('post_material_supplier_return_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.reverse_material_supplier_return_v2(
  p_return_id uuid,p_reason text,p_client_request_id uuid,p_expected_version bigint
)
returns jsonb language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare v_hash text;v_cached jsonb;v_response jsonb;h erp.material_supplier_returns%rowtype;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'Reversal reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('id',p_return_id,'reason',btrim(p_reason),'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('reverse_material_supplier_return_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.material_supplier_returns where id=p_return_id for update;
  if h.id is null then raise exception 'Supplier return not found'; end if;
  if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
  perform erp.reverse_material_supplier_return(h.id,btrim(p_reason));
  select * into h from erp.material_supplier_returns where id=h.id;
  v_response:=jsonb_build_object('material_supplier_return_id',h.id,'status',h.status,'row_version',h.row_version);
  return erp._idempotency_complete('reverse_material_supplier_return_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 4. Contractor material/accessory issue: server owns price snapshots
-- ---------------------------------------------------------------------------

create or replace function erp.save_contractor_material_issue_draft_v2(
  p_payload jsonb,p_client_request_id uuid,p_expected_version bigint default null
)
returns jsonb language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_action text:=upper(coalesce(nullif(btrim(p_payload->>'action'),''),'SAVE'));
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  h erp.contractor_material_issues%rowtype;v_line jsonb;v_type text;v_roll uuid;v_qty numeric;
begin
  perform erp.require_internal();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  if v_action not in('SAVE','DELETE') then raise exception 'action must be SAVE or DELETE'; end if;
  if v_action='SAVE' and coalesce(jsonb_typeof(p_payload->'items'),'null')<>'array' then raise exception 'items must be a JSON array'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('save_contractor_material_issue_draft_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',v_reason,true);
  if v_id is null then
    if v_action='DELETE' then raise exception 'Issue id is required for DELETE'; end if;
    if p_expected_version is not null then raise exception 'expected_version must be null on create'; end if;
    insert into erp.contractor_material_issues(
      issue_number,contractor_id,po_id,physical_at,status,notes,created_by,location_id
    ) values(
      btrim(p_payload->>'issue_number'),(p_payload->>'contractor_id')::uuid,
      nullif(p_payload->>'po_id','')::uuid,(p_payload->>'physical_at')::timestamptz,
      'DRAFT',nullif(btrim(p_payload->>'notes'),''),erp.current_app_user_id(),
      (p_payload->>'location_id')::uuid
    ) returning * into h;v_id:=h.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required'; end if;
    select * into h from erp.contractor_material_issues where id=v_id for update;
    if h.id is null then raise exception 'Contractor material issue not found'; end if;
    if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
    if h.status<>'DRAFT' then raise exception 'Only DRAFT contractor issue can be saved/deleted'; end if;
    if v_action='DELETE' then
      delete from erp.contractor_material_issues where id=v_id;
      v_response:=jsonb_build_object('contractor_material_issue_id',v_id,'status','DELETED');
      return erp._idempotency_complete('save_contractor_material_issue_draft_v2',p_client_request_id,v_response);
    end if;
    update erp.contractor_material_issues
    set issue_number=coalesce(nullif(btrim(p_payload->>'issue_number'),''),h.issue_number),
        contractor_id=case when p_payload?'contractor_id' then (p_payload->>'contractor_id')::uuid else h.contractor_id end,
        po_id=case when p_payload?'po_id' then nullif(p_payload->>'po_id','')::uuid else h.po_id end,
        physical_at=coalesce(nullif(p_payload->>'physical_at','')::timestamptz,h.physical_at),
        location_id=case when p_payload?'location_id' then (p_payload->>'location_id')::uuid else h.location_id end,
        notes=case when p_payload?'notes' then nullif(btrim(p_payload->>'notes'),'') else h.notes end
    where id=v_id returning * into h;
  end if;
  if jsonb_array_length(p_payload->'items')=0 then raise exception 'At least one contractor issue line is required'; end if;
  if not exists(select 1 from erp.locations l where l.id=h.location_id and l.is_active and l.location_type='RAW_MATERIAL_WAREHOUSE') then
    raise exception 'Contractor issue location must be an active raw-material warehouse';
  end if;
  delete from erp.contractor_material_issue_items where issue_id=v_id;
  for v_line in select value from jsonb_array_elements(p_payload->'items') loop
    select material_type into v_type from erp.materials
    where id=(v_line->>'material_id')::uuid and is_active;
    if v_type is null then raise exception 'Active material is required'; end if;
    v_roll:=nullif(v_line->>'roll_id','')::uuid;
    if v_type='FABRIC' and v_roll is null then raise exception 'FABRIC contractor issue requires roll_id'; end if;
    if v_type<>'FABRIC' and v_roll is not null then raise exception 'Only FABRIC may use roll_id'; end if;
    v_qty:=coalesce(nullif(v_line->>'qty','')::numeric,nullif(v_line->>'transaction_qty','')::numeric);
    -- The normalizer overwrites selling price/version and reconciles transaction
    -- UOM to base quantity. Client-supplied price fields are never accepted.
    insert into erp.contractor_material_issue_items(
      id,issue_id,material_id,roll_id,qty,unit_sale_price_snapshot,
      notes,transaction_qty
    ) values(
      coalesce(nullif(v_line->>'id','')::uuid,gen_random_uuid()),v_id,
      (v_line->>'material_id')::uuid,v_roll,v_qty,0,
      nullif(btrim(v_line->>'notes'),''),nullif(v_line->>'transaction_qty','')::numeric
    );
  end loop;
  select * into h from erp.contractor_material_issues where id=v_id;
  v_response:=jsonb_build_object(
    'contractor_material_issue_id',h.id,'status',h.status,'row_version',h.row_version,
    'item_count',(select count(*) from erp.contractor_material_issue_items i where i.issue_id=v_id),
    'base_qty_total',(select sum(i.qty) from erp.contractor_material_issue_items i where i.issue_id=v_id),
    'receivable_total',(select sum(i.total_receivable) from erp.contractor_material_issue_items i where i.issue_id=v_id)
  );
  return erp._idempotency_complete('save_contractor_material_issue_draft_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.post_contractor_material_issue_v2(
  p_issue_id uuid,p_client_request_id uuid,p_expected_version bigint,p_reason text
)
returns jsonb language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare v_hash text;v_cached jsonb;v_response jsonb;h erp.contractor_material_issues%rowtype;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'Posting reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('id',p_issue_id,'expected_version',p_expected_version,'reason',btrim(p_reason)));
  v_cached:=erp._idempotency_begin('post_contractor_material_issue_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.contractor_material_issues where id=p_issue_id for update;
  if h.id is null then raise exception 'Contractor material issue not found'; end if;
  if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
  perform erp.post_contractor_material_issue(h.id);
  select * into h from erp.contractor_material_issues where id=h.id;
  v_response:=jsonb_build_object('contractor_material_issue_id',h.id,'status',h.status,'row_version',h.row_version);
  return erp._idempotency_complete('post_contractor_material_issue_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.reverse_contractor_material_issue_v2(
  p_issue_id uuid,p_reason text,p_client_request_id uuid,p_expected_version bigint
)
returns jsonb language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare v_hash text;v_cached jsonb;v_response jsonb;h erp.contractor_material_issues%rowtype;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'Reversal reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('id',p_issue_id,'reason',btrim(p_reason),'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('reverse_contractor_material_issue_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.contractor_material_issues where id=p_issue_id for update;
  if h.id is null then raise exception 'Contractor material issue not found'; end if;
  if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
  perform erp.reverse_contractor_material_issue(h.id,btrim(p_reason));
  select * into h from erp.contractor_material_issues where id=h.id;
  v_response:=jsonb_build_object('contractor_material_issue_id',h.id,'status',h.status,'row_version',h.row_version);
  return erp._idempotency_complete('reverse_contractor_material_issue_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 5. Grants and browse-first read models
-- ---------------------------------------------------------------------------

revoke all on function erp.save_material_adjustment_draft_v2(jsonb,uuid,bigint),
  erp.post_material_adjustment_v2(uuid,uuid,bigint,text),
  erp.reverse_material_adjustment_v2(uuid,text,uuid,bigint),
  erp.save_material_supplier_return_draft_v2(jsonb,uuid,bigint),
  erp.post_material_supplier_return_v2(uuid,uuid,bigint,text),
  erp.reverse_material_supplier_return_v2(uuid,text,uuid,bigint),
  erp.save_contractor_material_issue_draft_v2(jsonb,uuid,bigint),
  erp.post_contractor_material_issue_v2(uuid,uuid,bigint,text),
  erp.reverse_contractor_material_issue_v2(uuid,text,uuid,bigint)
from public;

grant execute on function erp.save_material_adjustment_draft_v2(jsonb,uuid,bigint),
  erp.post_material_adjustment_v2(uuid,uuid,bigint,text),
  erp.reverse_material_adjustment_v2(uuid,text,uuid,bigint),
  erp.save_material_supplier_return_draft_v2(jsonb,uuid,bigint),
  erp.post_material_supplier_return_v2(uuid,uuid,bigint,text),
  erp.reverse_material_supplier_return_v2(uuid,text,uuid,bigint),
  erp.save_contractor_material_issue_draft_v2(jsonb,uuid,bigint),
  erp.post_contractor_material_issue_v2(uuid,uuid,bigint,text),
  erp.reverse_contractor_material_issue_v2(uuid,text,uuid,bigint)
to authenticated,service_role;

create or replace view erp.v_gudang_material_adjustment_browser
with(security_invoker=true) as
select h.id adjustment_id,h.adjustment_number,h.reason_code,h.physical_at,h.status,
       h.location_id,l.location_code,l.location_name,
       count(i.id)::bigint item_count,coalesce(sum(i.qty_signed),0)::numeric net_qty,
       coalesce(sum(abs(i.qty_signed)),0)::numeric absolute_qty,h.notes,h.row_version,
       h.created_at,h.updated_at,
       concat_ws(' ',h.adjustment_number,h.reason_code,h.status,l.location_code,l.location_name,h.notes) search_text
from erp.material_adjustments h join erp.locations l on l.id=h.location_id
left join erp.material_adjustment_items i on i.adjustment_id=h.id
group by h.id,l.id;

create or replace view erp.v_gudang_supplier_return_browser
with(security_invoker=true) as
select h.id return_id,h.return_number,h.supplier_id,s.supplier_code,s.supplier_name,
       h.location_id,l.location_code,l.location_name,h.physical_at,h.status,h.reason,
       count(i.id)::bigint item_count,coalesce(sum(i.qty),0)::numeric total_qty,
       coalesce(sum(i.qty*i.supplier_credit_unit_price),0)::numeric credit_total,
       h.row_version,h.created_at,h.updated_at,
       concat_ws(' ',h.return_number,s.supplier_code,s.supplier_name,h.status,l.location_code,h.reason) search_text
from erp.material_supplier_returns h join erp.suppliers s on s.id=h.supplier_id
join erp.locations l on l.id=h.location_id
left join erp.material_supplier_return_items i on i.return_id=h.id
group by h.id,s.id,l.id;

create or replace view erp.v_gudang_contractor_material_issue_browser
with(security_invoker=true) as
select h.id issue_id,h.issue_number,h.contractor_id,c.contractor_code,c.contractor_name,
       h.po_id,po.po_number,h.location_id,l.location_code,l.location_name,
       h.physical_at,h.status,count(i.id)::bigint item_count,
       coalesce(sum(i.qty),0)::numeric base_qty_total,
       coalesce(sum(i.total_receivable),0)::numeric receivable_total,
       coalesce(sum(i.qty*i.unit_cost_snapshot),0)::numeric inventory_cost_total,
       h.notes,h.row_version,h.created_at,h.updated_at,
       concat_ws(' ',h.issue_number,c.contractor_code,c.contractor_name,po.po_number,h.status,l.location_code,h.notes) search_text
from erp.contractor_material_issues h join erp.contractors c on c.id=h.contractor_id
join erp.locations l on l.id=h.location_id
left join erp.production_orders po on po.id=h.po_id
left join erp.contractor_material_issue_items i on i.issue_id=h.id
group by h.id,c.id,l.id,po.id;

grant select on erp.v_gudang_material_adjustment_browser,
  erp.v_gudang_supplier_return_browser,
  erp.v_gudang_contractor_material_issue_browser
to authenticated,service_role;

-- ---------------------------------------------------------------------------
-- 6. Integrity/security checks
-- ---------------------------------------------------------------------------

create or replace function erp.run_v265_gudang_write_integrity_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language sql stable security definer
set search_path=erp,public,pg_catalog,information_schema,pg_temp
as $$
  select 'browser_direct_gudang_document_write','CRITICAL',count(*)::bigint,
         'Gudang adjustments, supplier returns and contractor issues must mutate only through aggregate RPCs'
  from information_schema.role_table_grants g
  where g.table_schema='erp'
    and g.table_name in(
      'material_adjustments','material_adjustment_items',
      'material_supplier_returns','material_supplier_return_items',
      'contractor_material_issues','contractor_material_issue_items'
    ) and g.grantee in('PUBLIC','anon','authenticated')
    and g.privilege_type in('INSERT','UPDATE','DELETE')

  union all
  select 'browser_legacy_gudang_post_execute','CRITICAL',count(*)::bigint,
         'Authenticated browser must use idempotent/versioned v2 posting and reversal wrappers'
  from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='erp' and p.proname in(
    'post_material_adjustment','reverse_material_adjustment',
    'post_material_supplier_return','reverse_material_supplier_return',
    'post_contractor_material_issue','reverse_contractor_material_issue'
  ) and has_function_privilege('authenticated',p.oid,'EXECUTE')

  union all
  select 'posted_adjustment_without_active_movement','CRITICAL',count(*)::bigint,
         'Every POSTED adjustment line needs an unreversed stock movement'
  from erp.material_adjustment_items i join erp.material_adjustments h on h.id=i.adjustment_id and h.status='POSTED'
  where not exists(select 1 from erp.material_stock_movements m where m.source_type='MATERIAL_ADJUSTMENT_ITEM' and m.source_id=i.id
    and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=m.id))

  union all
  select 'posted_supplier_return_without_active_movement','CRITICAL',count(*)::bigint,
         'Every POSTED supplier return line needs an unreversed stock movement'
  from erp.material_supplier_return_items i join erp.material_supplier_returns h on h.id=i.return_id and h.status='POSTED'
  where not exists(select 1 from erp.material_stock_movements m where m.source_type='MATERIAL_SUPPLIER_RETURN_ITEM' and m.source_id=i.id
    and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=m.id))

  union all
  select 'posted_contractor_issue_without_active_movement','CRITICAL',count(*)::bigint,
         'Every POSTED contractor issue line needs an unreversed stock movement'
  from erp.contractor_material_issue_items i join erp.contractor_material_issues h on h.id=i.issue_id and h.status='POSTED'
  where not exists(select 1 from erp.material_stock_movements m where m.source_type='CONTRACTOR_MATERIAL_ISSUE_ITEM' and m.source_id=i.id
    and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=m.id))

  union all
  select 'supplier_return_client_price_provenance_gap','CRITICAL',count(*)::bigint,
         'Supplier return credit price must be populated from its source purchase'
  from erp.material_supplier_return_items i
  where i.supplier_credit_unit_price is null or i.purchase_item_id is null

  union all
  select 'contractor_issue_price_provenance_gap','CRITICAL',count(*)::bigint,
         'Contractor issue selling price must retain an authoritative version id'
  from erp.contractor_material_issue_items i join erp.materials m on m.id=i.material_id
  where (m.material_type='ACCESSORY' and i.accessory_price_version_id is null)
     or (m.material_type<>'ACCESSORY' and i.material_price_version_id is null);
$$;

revoke all on function erp.run_v265_gudang_write_integrity_checks() from public;
grant execute on function erp.run_v265_gudang_write_integrity_checks()
  to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.5',
  'Safe aggregate Gudang writes for material adjustment, supplier return and contractor issue',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828082704','erp_v265_gudang_write_contracts',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828082704 erp_v265_gudang_write_contracts

-- BEGIN PLATFORM MIGRATION 20260828083129 erp_v265a_audit_coverage
-- ERP Garment v2.6.5a
-- Complete row-audit coverage for remaining browser-writable reference,
-- configuration, draft-line and scrap tables.

set lock_timeout='10s';
set statement_timeout='60s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_5a',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.5') then
    raise exception 'ERP Garment v2.6.5 is required before v2.6.5a';
  end if;
end;
$$;

drop trigger if exists trg_audit_accessory_bom_items_v265a on erp.accessory_bom_items;
create trigger trg_audit_accessory_bom_items_v265a after insert or update or delete on erp.accessory_bom_items for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_accessory_bom_versions_v265a on erp.accessory_bom_versions;
create trigger trg_audit_accessory_bom_versions_v265a after insert or update or delete on erp.accessory_bom_versions for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_accessory_categories_v265a on erp.accessory_categories;
create trigger trg_audit_accessory_categories_v265a after insert or update or delete on erp.accessory_categories for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_accessory_uom_conversions_v265a on erp.accessory_category_uom_conversions;
create trigger trg_audit_accessory_uom_conversions_v265a after insert or update or delete on erp.accessory_category_uom_conversions for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_cash_accounts_v265a on erp.cash_accounts;
create trigger trg_audit_cash_accounts_v265a after insert or update or delete on erp.cash_accounts for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_chart_accounts_v265a on erp.chart_accounts;
create trigger trg_audit_chart_accounts_v265a after insert or update or delete on erp.chart_accounts for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_contractor_accessory_prices_v265a on erp.contractor_accessory_price_versions;
create trigger trg_audit_contractor_accessory_prices_v265a after insert or update or delete on erp.contractor_accessory_price_versions for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_fg_adjustment_items_v265a on erp.fg_adjustment_items;
create trigger trg_audit_fg_adjustment_items_v265a after insert or update or delete on erp.fg_adjustment_items for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_misc_finance_categories_v265a on erp.misc_finance_categories;
create trigger trg_audit_misc_finance_categories_v265a after insert or update or delete on erp.misc_finance_categories for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_opening_balance_headers_v265a on erp.opening_balance_headers;
create trigger trg_audit_opening_balance_headers_v265a after insert or update or delete on erp.opening_balance_headers for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_opening_balance_items_v265a on erp.opening_balance_items;
create trigger trg_audit_opening_balance_items_v265a after insert or update or delete on erp.opening_balance_items for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_opening_subledger_settlements_v265a on erp.opening_subledger_settlements;
create trigger trg_audit_opening_subledger_settlements_v265a after insert or update or delete on erp.opening_subledger_settlements for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_payroll_reimbursements_v265a on erp.payroll_reimbursements;
create trigger trg_audit_payroll_reimbursements_v265a after insert or update or delete on erp.payroll_reimbursements for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_product_conversion_allocations_v265a on erp.product_conversion_allocations;
create trigger trg_audit_product_conversion_allocations_v265a after insert or update or delete on erp.product_conversion_allocations for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_product_models_v265a on erp.product_models;
create trigger trg_audit_product_models_v265a after insert or update or delete on erp.product_models for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_product_price_versions_v265a on erp.product_price_versions;
create trigger trg_audit_product_price_versions_v265a after insert or update or delete on erp.product_price_versions for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_products_v265a on erp.products;
create trigger trg_audit_products_v265a after insert or update or delete on erp.products for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_scrap_batches_v265a on erp.scrap_batches;
create trigger trg_audit_scrap_batches_v265a after insert or update or delete on erp.scrap_batches for each row execute function erp.audit_row_change();
drop trigger if exists trg_audit_scrap_sales_v265a on erp.scrap_sales;
create trigger trg_audit_scrap_sales_v265a after insert or update or delete on erp.scrap_sales for each row execute function erp.audit_row_change();

create or replace function erp.run_v265a_audit_coverage_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language sql stable security definer
set search_path=erp,public,pg_catalog,information_schema,pg_temp
as $$
  with writable as(
    select c.oid,c.relname
    from pg_class c join pg_namespace n on n.oid=c.relnamespace
    where n.nspname='erp' and c.relkind='r'
      and (
        has_table_privilege('authenticated',c.oid,'INSERT')
        or has_table_privilege('authenticated',c.oid,'UPDATE')
        or has_table_privilege('authenticated',c.oid,'DELETE')
      )
  )
  select 'browser_writable_table_without_audit','ERROR',count(*)::bigint,
         'Every browser-writable non-system ERP table needs generic or approved specialized audit coverage'
  from writable w
  where not exists(
    select 1 from pg_trigger t join pg_proc p on p.oid=t.tgfoid
    where t.tgrelid=w.oid and not t.tgisinternal
      and p.proname in('audit_row_change','audit_accounting_mapping_change')
  )
  and not exists(
    select 1 from pg_trigger t join pg_proc p on p.oid=t.tgfoid
    where t.tgrelid=w.oid and not t.tgisinternal and p.proname='guard_system_managed_table'
  );
$$;

revoke all on function erp.run_v265a_audit_coverage_checks() from public;
grant execute on function erp.run_v265a_audit_coverage_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values('v2.6.5a','Complete row-audit coverage for browser-writable ERP tables',now());
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828083129','erp_v265a_audit_coverage',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828083129 erp_v265a_audit_coverage

-- BEGIN PLATFORM MIGRATION 20260828090017 erp_v266_gudang_accessory_fg_contracts
-- ERP Garment v2.6.6
-- Complete the remaining Gudang write contracts:
-- 1) safe accessory category/material/effective-dated UOM and selling-price APIs;
-- 2) idempotent, optimistic-locking FG adjustment aggregate APIs.

set lock_timeout='10s';
set statement_timeout='120s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_6',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.5a') then
    raise exception 'ERP Garment v2.6.5a is required before v2.6.6';
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. Concurrency and direct-write boundary
-- ---------------------------------------------------------------------------

alter table erp.accessory_categories
  add column if not exists row_version bigint not null default 1;

alter table erp.fg_adjustments
  add column if not exists row_version bigint not null default 1;

drop trigger if exists trg_accessory_categories_version_v266 on erp.accessory_categories;
create trigger trg_accessory_categories_version_v266
before update on erp.accessory_categories
for each row execute function erp.bump_row_version();

drop trigger if exists trg_fg_adjustments_version_v266 on erp.fg_adjustments;
create trigger trg_fg_adjustments_version_v266
before update on erp.fg_adjustments
for each row execute function erp.bump_row_version();

revoke insert,update,delete on
  erp.accessory_categories,
  erp.accessory_category_uom_conversions,
  erp.contractor_accessory_price_versions,
  erp.fg_adjustments,
  erp.fg_adjustment_items
from public,anon,authenticated;

revoke execute on function erp.post_fg_adjustment(uuid),
  erp.reverse_fg_adjustment(uuid,text)
from public,authenticated;
grant execute on function erp.post_fg_adjustment(uuid),
  erp.reverse_fg_adjustment(uuid,text)
to service_role;

-- ---------------------------------------------------------------------------
-- 2. Accessory category and material master
-- ---------------------------------------------------------------------------

create or replace function erp.save_accessory_category_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  v_row erp.accessory_categories%rowtype;
  v_active boolean:=coalesce((p_payload->>'is_active')::boolean,true);
begin
  perform erp.require_owner_admin();
  if v_reason is null then raise exception 'change_reason is required';end if;
  if coalesce(btrim(p_payload->>'category_code'),'')='' then raise exception 'category_code is required';end if;
  if coalesce(btrim(p_payload->>'category_name'),'')='' then raise exception 'category_name is required';end if;
  if coalesce(btrim(p_payload->>'base_uom_code'),'')='' then raise exception 'base_uom_code is required';end if;

  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('save_accessory_category_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached;end if;
  perform set_config('app.change_reason',v_reason,true);

  if v_id is null then
    if p_expected_version is not null then raise exception 'expected_version must be null on create';end if;
    insert into erp.accessory_categories(
      category_code,category_name,base_uom_code,is_active,notes
    ) values(
      upper(btrim(p_payload->>'category_code')),
      btrim(p_payload->>'category_name'),
      upper(btrim(p_payload->>'base_uom_code')),
      v_active,nullif(btrim(p_payload->>'notes'),'')
    ) returning * into v_row;
  else
    if p_expected_version is null then raise exception 'expected_version is required on update';end if;
    select * into v_row from erp.accessory_categories where id=v_id for update;
    if v_row.id is null then raise exception 'Accessory category not found';end if;
    if v_row.row_version<>p_expected_version then
      raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_row.row_version;
    end if;
    if not v_active and exists(
      select 1 from erp.materials m
      where m.accessory_category_id=v_id and m.is_active
    ) then raise exception 'Accessory category with active material variants cannot be deactivated';end if;
    update erp.accessory_categories
    set category_code=upper(btrim(p_payload->>'category_code')),
        category_name=btrim(p_payload->>'category_name'),
        base_uom_code=upper(btrim(p_payload->>'base_uom_code')),
        is_active=v_active,
        notes=case when p_payload?'notes' then nullif(btrim(p_payload->>'notes'),'') else notes end,
        updated_at=now()
    where id=v_id returning * into v_row;
  end if;

  v_response:=jsonb_build_object(
    'accessory_category_id',v_row.id,'row_version',v_row.row_version,
    'category_code',v_row.category_code,
    'status',case when v_row.is_active then 'ACTIVE' else 'INACTIVE' end
  );
  return erp._idempotency_complete('save_accessory_category_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.save_accessory_material_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  v_category uuid:=nullif(p_payload->>'accessory_category_id','')::uuid;
  v_base_uom text;
  v_row erp.materials%rowtype;
  v_active boolean:=coalesce((p_payload->>'is_active')::boolean,true);
begin
  perform erp.require_owner_admin();
  if v_reason is null then raise exception 'change_reason is required';end if;
  if coalesce(btrim(p_payload->>'material_sku'),'')='' then raise exception 'material_sku is required';end if;
  if coalesce(btrim(p_payload->>'material_name'),'')='' then raise exception 'material_name is required';end if;
  if v_category is null then raise exception 'accessory_category_id is required';end if;
  select base_uom_code into v_base_uom
  from erp.accessory_categories
  where id=v_category and is_active;
  if v_base_uom is null then raise exception 'Active accessory category is required';end if;

  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('save_accessory_material_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached;end if;
  perform set_config('app.change_reason',v_reason,true);

  if v_id is null then
    if p_expected_version is not null then raise exception 'expected_version must be null on create';end if;
    insert into erp.materials(
      material_sku,material_name,material_type,unit_code,accessory_category_id,is_active
    ) values(
      upper(btrim(p_payload->>'material_sku')),btrim(p_payload->>'material_name'),
      'ACCESSORY',v_base_uom,v_category,v_active
    ) returning * into v_row;
  else
    if p_expected_version is null then raise exception 'expected_version is required on update';end if;
    select * into v_row from erp.materials where id=v_id for update;
    if v_row.id is null or v_row.material_type<>'ACCESSORY' then
      raise exception 'Accessory material not found';
    end if;
    if v_row.row_version<>p_expected_version then
      raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_row.row_version;
    end if;
    if not v_active and abs(v_row.cached_stock_qty)>0.000001 then
      raise exception 'Accessory with non-zero stock cannot be deactivated';
    end if;
    update erp.materials
    set material_sku=upper(btrim(p_payload->>'material_sku')),
        material_name=btrim(p_payload->>'material_name'),
        unit_code=v_base_uom,
        accessory_category_id=v_category,
        is_active=v_active,
        updated_at=now()
    where id=v_id returning * into v_row;
  end if;

  v_response:=jsonb_build_object(
    'material_id',v_row.id,'row_version',v_row.row_version,
    'material_sku',v_row.material_sku,'accessory_category_id',v_row.accessory_category_id,
    'base_uom_code',v_row.unit_code,
    'status',case when v_row.is_active then 'ACTIVE' else 'INACTIVE' end
  );
  return erp._idempotency_complete('save_accessory_material_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 3. Effective-dated accessory UOM and selling-price successors
-- ---------------------------------------------------------------------------

create or replace function erp.set_accessory_uom_conversion_v2(
  p_category_id uuid,
  p_uom_code text,
  p_base_qty_per_uom numeric,
  p_effective_from timestamptz,
  p_notes text,
  p_change_reason text,
  p_client_request_id uuid,
  p_expected_category_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_category erp.accessory_categories%rowtype;
  v_prev erp.accessory_category_uom_conversions%rowtype;
  v_next_at timestamptz;v_new_id uuid;
  v_uom text:=upper(btrim(p_uom_code));
begin
  perform erp.require_owner_admin();
  if nullif(btrim(p_change_reason),'') is null then raise exception 'change_reason is required';end if;
  if p_expected_category_version is null then raise exception 'expected_category_version is required';end if;
  if p_effective_from is null then raise exception 'effective_from is required';end if;
  if coalesce(p_base_qty_per_uom,0)<=0 then raise exception 'base_qty_per_uom must be positive';end if;

  v_hash:=erp._request_hash(jsonb_build_object(
    'category_id',p_category_id,'uom_code',v_uom,'factor',p_base_qty_per_uom,
    'effective_from',p_effective_from,'notes',p_notes,
    'reason',btrim(p_change_reason),'expected_category_version',p_expected_category_version
  ));
  v_cached:=erp._idempotency_begin('set_accessory_uom_conversion_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached;end if;
  perform set_config('app.change_reason',btrim(p_change_reason),true);
  perform pg_advisory_xact_lock(hashtextextended('ACCUOM:'||p_category_id::text||':'||v_uom,0));

  select * into v_category from erp.accessory_categories where id=p_category_id for update;
  if v_category.id is null or not v_category.is_active then raise exception 'Active accessory category not found';end if;
  if v_category.row_version<>p_expected_category_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_category_version,v_category.row_version;
  end if;
  if v_uom=v_category.base_uom_code then
    raise exception 'Base UOM always has factor 1 and must not be versioned';
  end if;
  if not exists(select 1 from erp.uom_definitions where unit_code=v_uom) then
    raise exception 'UOM % is not registered',v_uom;
  end if;
  if exists(
    select 1 from erp.accessory_category_uom_conversions
    where category_id=p_category_id and uom_code=v_uom and effective_from=p_effective_from
  ) then raise exception 'A conversion version already starts at this effective_from';end if;

  select * into v_prev
  from erp.accessory_category_uom_conversions
  where category_id=p_category_id and uom_code=v_uom
    and effective_from<p_effective_from
    and (effective_to is null or effective_to>p_effective_from)
  order by effective_from desc limit 1 for update;

  select min(effective_from) into v_next_at
  from erp.accessory_category_uom_conversions
  where category_id=p_category_id and uom_code=v_uom
    and effective_from>p_effective_from;

  if v_prev.id is not null then
    update erp.accessory_category_uom_conversions
    set effective_to=p_effective_from
    where id=v_prev.id;
  end if;

  insert into erp.accessory_category_uom_conversions(
    category_id,uom_code,base_qty_per_uom,effective_from,effective_to,notes
  ) values(
    p_category_id,v_uom,p_base_qty_per_uom,p_effective_from,v_next_at,nullif(btrim(p_notes),'')
  ) returning id into v_new_id;

  update erp.accessory_categories set updated_at=now() where id=p_category_id
  returning * into v_category;

  v_response:=jsonb_build_object(
    'accessory_uom_conversion_id',v_new_id,'category_id',p_category_id,
    'uom_code',v_uom,'base_qty_per_uom',p_base_qty_per_uom,
    'effective_from',p_effective_from,'effective_to',v_next_at,
    'category_row_version',v_category.row_version
  );
  return erp._idempotency_complete('set_accessory_uom_conversion_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.set_accessory_selling_price_v2(
  p_category_id uuid,
  p_contractor_id uuid,
  p_selling_price numeric,
  p_selling_uom_code text,
  p_effective_from timestamptz,
  p_notes text,
  p_change_reason text,
  p_client_request_id uuid,
  p_expected_current_version_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_prev erp.contractor_accessory_price_versions%rowtype;
  v_next_at timestamptz;v_new_id uuid;
  v_uom text:=upper(btrim(p_selling_uom_code));
begin
  perform erp.require_owner_admin();
  if nullif(btrim(p_change_reason),'') is null then raise exception 'change_reason is required';end if;
  if p_effective_from is null then raise exception 'effective_from is required';end if;
  if p_selling_price is null or p_selling_price<0 then raise exception 'selling_price cannot be negative';end if;
  if not exists(select 1 from erp.accessory_categories where id=p_category_id and is_active) then
    raise exception 'Active accessory category not found';
  end if;
  if p_contractor_id is not null and not exists(
    select 1 from erp.contractors where id=p_contractor_id and is_active
  ) then raise exception 'Active contractor not found';end if;

  v_hash:=erp._request_hash(jsonb_build_object(
    'category_id',p_category_id,'contractor_id',p_contractor_id,
    'selling_price',p_selling_price,'selling_uom_code',v_uom,
    'effective_from',p_effective_from,'notes',p_notes,
    'reason',btrim(p_change_reason),
    'expected_current_version_id',p_expected_current_version_id
  ));
  v_cached:=erp._idempotency_begin('set_accessory_selling_price_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached;end if;
  perform set_config('app.change_reason',btrim(p_change_reason),true);
  perform pg_advisory_xact_lock(hashtextextended(
    'ACCPRICE:'||coalesce(p_contractor_id::text,'GLOBAL')||':'||p_category_id::text,0
  ));
  perform erp.accessory_uom_factor(p_category_id,v_uom,p_effective_from);

  if exists(
    select 1 from erp.contractor_accessory_price_versions
    where category_id=p_category_id
      and contractor_id is not distinct from p_contractor_id
      and effective_from=p_effective_from
  ) then raise exception 'A selling-price version already starts at this effective_from';end if;

  select * into v_prev
  from erp.contractor_accessory_price_versions
  where category_id=p_category_id
    and contractor_id is not distinct from p_contractor_id
    and effective_from<p_effective_from
    and (effective_to is null or effective_to>p_effective_from)
  order by effective_from desc limit 1 for update;

  if v_prev.id is null then
    if p_expected_current_version_id is not null then
      raise exception 'STALE_VERSION expected current %, but no predecessor covers effective_from',
        p_expected_current_version_id;
    end if;
  elsif p_expected_current_version_id is null or v_prev.id<>p_expected_current_version_id then
    raise exception 'STALE_VERSION expected current %, actual %',
      p_expected_current_version_id,v_prev.id;
  end if;

  select min(effective_from) into v_next_at
  from erp.contractor_accessory_price_versions
  where category_id=p_category_id
    and contractor_id is not distinct from p_contractor_id
    and effective_from>p_effective_from;

  if v_prev.id is not null then
    update erp.contractor_accessory_price_versions
    set effective_to=p_effective_from
    where id=v_prev.id;
  end if;

  insert into erp.contractor_accessory_price_versions(
    contractor_id,category_id,selling_price,selling_uom_code,
    effective_from,effective_to,notes
  ) values(
    p_contractor_id,p_category_id,p_selling_price,v_uom,
    p_effective_from,v_next_at,nullif(btrim(p_notes),'')
  ) returning id into v_new_id;

  v_response:=jsonb_build_object(
    'accessory_price_version_id',v_new_id,'predecessor_version_id',v_prev.id,
    'category_id',p_category_id,'contractor_id',p_contractor_id,
    'selling_price',p_selling_price,'selling_uom_code',v_uom,
    'effective_from',p_effective_from,'effective_to',v_next_at
  );
  return erp._idempotency_complete('set_accessory_selling_price_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 4. FG adjustment aggregate
-- ---------------------------------------------------------------------------

create or replace function erp.save_fg_adjustment_draft_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_action text:=upper(coalesce(nullif(btrim(p_payload->>'action'),''),'SAVE'));
  v_change_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
  v_header erp.fg_adjustments%rowtype;
  v_line jsonb;v_lot erp.fg_lots%rowtype;v_qty integer;v_quality text;
begin
  perform erp.require_owner_admin();
  if v_change_reason is null then raise exception 'change_reason is required';end if;
  if v_action not in('SAVE','DELETE') then raise exception 'action must be SAVE or DELETE';end if;
  if v_action='SAVE' and coalesce(jsonb_typeof(p_payload->'items'),'null')<>'array' then
    raise exception 'items must be a JSON array';
  end if;

  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('save_fg_adjustment_draft_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached;end if;
  perform set_config('app.change_reason',v_change_reason,true);

  if v_id is null then
    if v_action='DELETE' then raise exception 'FG adjustment id is required for DELETE';end if;
    if p_expected_version is not null then raise exception 'expected_version must be null on create';end if;
    insert into erp.fg_adjustments(
      adjustment_number,location_id,physical_at,reason_code,reason,status,notes,created_by
    ) values(
      btrim(p_payload->>'adjustment_number'),(p_payload->>'location_id')::uuid,
      (p_payload->>'physical_at')::timestamptz,upper(btrim(p_payload->>'reason_code')),
      btrim(p_payload->>'reason'),'DRAFT',nullif(btrim(p_payload->>'notes'),''),
      erp.current_app_user_id()
    ) returning * into v_header;
    v_id:=v_header.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required on update';end if;
    select * into v_header from erp.fg_adjustments where id=v_id for update;
    if v_header.id is null then raise exception 'FG adjustment not found';end if;
    if v_header.row_version<>p_expected_version then
      raise exception 'STALE_VERSION expected %, current %',p_expected_version,v_header.row_version;
    end if;
    if v_header.status<>'DRAFT' then raise exception 'Only DRAFT FG adjustment can be saved/deleted';end if;
    if v_action='DELETE' then
      delete from erp.fg_adjustments where id=v_id;
      v_response:=jsonb_build_object('fg_adjustment_id',v_id,'status','DELETED');
      return erp._idempotency_complete('save_fg_adjustment_draft_v2',p_client_request_id,v_response);
    end if;
    update erp.fg_adjustments
    set adjustment_number=coalesce(nullif(btrim(p_payload->>'adjustment_number'),''),v_header.adjustment_number),
        location_id=case when p_payload?'location_id' then (p_payload->>'location_id')::uuid else v_header.location_id end,
        physical_at=coalesce(nullif(p_payload->>'physical_at','')::timestamptz,v_header.physical_at),
        reason_code=upper(coalesce(nullif(btrim(p_payload->>'reason_code'),''),v_header.reason_code)),
        reason=coalesce(nullif(btrim(p_payload->>'reason'),''),v_header.reason),
        notes=case when p_payload?'notes' then nullif(btrim(p_payload->>'notes'),'') else v_header.notes end
    where id=v_id returning * into v_header;
  end if;

  if nullif(btrim(v_header.reason),'') is null then raise exception 'reason is required';end if;
  if not exists(
    select 1 from erp.locations l
    where l.id=v_header.location_id and l.is_active and l.location_type='FG_WAREHOUSE'
  ) then raise exception 'FG adjustment location must be an active FG warehouse';end if;
  if jsonb_array_length(p_payload->'items')=0 then raise exception 'At least one FG adjustment line is required';end if;

  delete from erp.fg_adjustment_items where adjustment_id=v_id;
  for v_line in select value from jsonb_array_elements(p_payload->'items') loop
    select * into v_lot from erp.fg_lots where id=(v_line->>'lot_id')::uuid;
    if v_lot.id is null then raise exception 'FG lot not found';end if;
    if v_line?'product_id' and nullif(v_line->>'product_id','')::uuid is distinct from v_lot.product_id then
      raise exception 'FG adjustment product must match the lot product';
    end if;
    v_qty:=(v_line->>'qty_signed')::integer;
    if v_qty=0 then raise exception 'qty_signed cannot be zero';end if;
    v_quality:=upper(coalesce(nullif(btrim(v_line->>'quality_grade'),''),'GRADE_A'));
    insert into erp.fg_adjustment_items(
      id,adjustment_id,lot_id,product_id,quality_grade,qty_signed,unit_hpp_snapshot,notes
    ) values(
      coalesce(nullif(v_line->>'id','')::uuid,gen_random_uuid()),v_id,v_lot.id,
      v_lot.product_id,v_quality,v_qty,0,nullif(btrim(v_line->>'notes'),'')
    );
  end loop;

  select * into v_header from erp.fg_adjustments where id=v_id;
  v_response:=jsonb_build_object(
    'fg_adjustment_id',v_header.id,'status',v_header.status,
    'row_version',v_header.row_version,
    'item_count',(select count(*) from erp.fg_adjustment_items where adjustment_id=v_id),
    'net_qty_pcs',(select sum(qty_signed) from erp.fg_adjustment_items where adjustment_id=v_id)
  );
  return erp._idempotency_complete('save_fg_adjustment_draft_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.post_fg_adjustment_v2(
  p_adjustment_id uuid,
  p_client_request_id uuid,
  p_expected_version bigint,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare v_hash text;v_cached jsonb;v_response jsonb;h erp.fg_adjustments%rowtype;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required';end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'Posting reason is required';end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'id',p_adjustment_id,'expected_version',p_expected_version,'reason',btrim(p_reason)
  ));
  v_cached:=erp._idempotency_begin('post_fg_adjustment_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached;end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.fg_adjustments where id=p_adjustment_id for update;
  if h.id is null then raise exception 'FG adjustment not found';end if;
  if h.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version;
  end if;
  perform erp.post_fg_adjustment(h.id);
  select * into h from erp.fg_adjustments where id=h.id;
  v_response:=jsonb_build_object('fg_adjustment_id',h.id,'status',h.status,'row_version',h.row_version);
  return erp._idempotency_complete('post_fg_adjustment_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.reverse_fg_adjustment_v2(
  p_adjustment_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare v_hash text;v_cached jsonb;v_response jsonb;h erp.fg_adjustments%rowtype;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required';end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'Reversal reason is required';end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'id',p_adjustment_id,'expected_version',p_expected_version,'reason',btrim(p_reason)
  ));
  v_cached:=erp._idempotency_begin('reverse_fg_adjustment_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached;end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.fg_adjustments where id=p_adjustment_id for update;
  if h.id is null then raise exception 'FG adjustment not found';end if;
  if h.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version;
  end if;
  perform erp.reverse_fg_adjustment(h.id,btrim(p_reason));
  select * into h from erp.fg_adjustments where id=h.id;
  v_response:=jsonb_build_object('fg_adjustment_id',h.id,'status',h.status,'row_version',h.row_version);
  return erp._idempotency_complete('reverse_fg_adjustment_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 5. Browse-first projections
-- ---------------------------------------------------------------------------

create or replace view erp.v_accessory_master_browser
with (security_invoker=true)
as
with stock as(
  select material_id,sum(stock_qty) stock_qty,
         sum(stock_value_at_current_ma) stock_value,
         max(last_movement_at) last_movement_at
  from erp.v_material_stock_balance group by material_id
)
select
  m.id material_id,m.material_sku,m.material_name,m.is_active,
  m.unit_code base_uom_code,m.row_version,m.cached_stock_qty,m.moving_average_cost,
  ac.id category_id,ac.category_code,ac.category_name,ac.row_version category_row_version,
  cc.weighted_avg_cost_per_base_uom category_weighted_avg_cost,
  coalesce(s.stock_qty,0) ledger_stock_qty,coalesce(s.stock_value,0) stock_value,
  s.last_movement_at,
  gp.id global_price_version_id,gp.selling_price global_selling_price,
  gp.selling_uom_code global_selling_uom_code,
  gp.effective_from global_price_effective_from,gp.effective_to global_price_effective_to,
  concat_ws(' ',m.material_sku,m.material_name,ac.category_code,ac.category_name) search_text
from erp.materials m
join erp.accessory_categories ac on ac.id=m.accessory_category_id
left join erp.v_accessory_category_current_cost cc on cc.category_id=ac.id
left join stock s on s.material_id=m.id
left join lateral(
  select p.*
  from erp.contractor_accessory_price_versions p
  where p.category_id=ac.id and p.contractor_id is null
    and p.effective_from<=now() and (p.effective_to is null or p.effective_to>now())
  order by p.effective_from desc limit 1
) gp on true
where m.material_type='ACCESSORY';

create or replace view erp.v_accessory_price_browser
with (security_invoker=true)
as
select
  p.id price_version_id,p.category_id,ac.category_code,ac.category_name,
  p.contractor_id,c.contractor_code,c.contractor_name,
  p.selling_price,p.selling_uom_code,p.effective_from,p.effective_to,p.notes,
  (p.effective_from<=now() and (p.effective_to is null or p.effective_to>now())) is_current,
  concat_ws(' ',ac.category_code,ac.category_name,c.contractor_code,c.contractor_name,p.selling_uom_code) search_text
from erp.contractor_accessory_price_versions p
join erp.accessory_categories ac on ac.id=p.category_id
left join erp.contractors c on c.id=p.contractor_id;

create or replace view erp.v_gudang_fg_adjustment_browser
with (security_invoker=true)
as
select
  h.id adjustment_id,h.adjustment_number,h.physical_at,h.status,
  h.location_id,l.location_code,l.location_name,h.reason_code,h.reason,h.notes,
  count(i.id) item_count,coalesce(sum(i.qty_signed),0) net_qty_pcs,
  coalesce(sum(abs(i.qty_signed*i.unit_hpp_snapshot)),0) absolute_value,
  h.row_version,h.created_at,h.updated_at,
  concat_ws(' ',h.adjustment_number,l.location_code,l.location_name,h.reason_code,h.reason,h.status) search_text
from erp.fg_adjustments h
join erp.locations l on l.id=h.location_id
left join erp.fg_adjustment_items i on i.adjustment_id=h.id
group by h.id,l.id;

grant select on erp.v_accessory_master_browser,
  erp.v_accessory_price_browser,
  erp.v_gudang_fg_adjustment_browser
to authenticated;
revoke all on erp.v_accessory_master_browser,
  erp.v_accessory_price_browser,
  erp.v_gudang_fg_adjustment_browser
from anon;

revoke all on function
  erp.save_accessory_category_v2(jsonb,uuid,bigint),
  erp.save_accessory_material_v2(jsonb,uuid,bigint),
  erp.set_accessory_uom_conversion_v2(uuid,text,numeric,timestamptz,text,text,uuid,bigint),
  erp.set_accessory_selling_price_v2(uuid,uuid,numeric,text,timestamptz,text,text,uuid,uuid),
  erp.save_fg_adjustment_draft_v2(jsonb,uuid,bigint),
  erp.post_fg_adjustment_v2(uuid,uuid,bigint,text),
  erp.reverse_fg_adjustment_v2(uuid,text,uuid,bigint)
from public;

grant execute on function
  erp.save_accessory_category_v2(jsonb,uuid,bigint),
  erp.save_accessory_material_v2(jsonb,uuid,bigint),
  erp.set_accessory_uom_conversion_v2(uuid,text,numeric,timestamptz,text,text,uuid,bigint),
  erp.set_accessory_selling_price_v2(uuid,uuid,numeric,text,timestamptz,text,text,uuid,uuid),
  erp.save_fg_adjustment_draft_v2(jsonb,uuid,bigint),
  erp.post_fg_adjustment_v2(uuid,uuid,bigint,text),
  erp.reverse_fg_adjustment_v2(uuid,text,uuid,bigint)
to authenticated,service_role;

-- ---------------------------------------------------------------------------
-- 6. Release checks
-- ---------------------------------------------------------------------------

create or replace function erp.run_v266_gudang_accessory_fg_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language sql stable security definer
set search_path=erp,public,pg_catalog,information_schema,pg_temp
as $$
  select 'v266_protected_tables_with_direct_write','CRITICAL',count(*)::bigint,
         'Accessory economic masters and FG adjustment aggregates may only be written through v2 RPCs'
  from information_schema.role_table_grants g
  where g.table_schema='erp' and g.grantee in('PUBLIC','anon','authenticated')
    and g.privilege_type in('INSERT','UPDATE','DELETE')
    and g.table_name in(
      'accessory_categories','accessory_category_uom_conversions',
      'contractor_accessory_price_versions','fg_adjustments','fg_adjustment_items'
    )
  union all
  select 'v266_legacy_fg_rpc_exposed','CRITICAL',count(*)::bigint,
         'Legacy FG adjustment post/reverse routines must not be executable by browser roles'
  from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='erp' and p.proname in('post_fg_adjustment','reverse_fg_adjustment')
    and (has_function_privilege('public',p.oid,'EXECUTE')
      or has_function_privilege('anon',p.oid,'EXECUTE')
      or has_function_privilege('authenticated',p.oid,'EXECUTE'))
  union all
  select 'v266_public_rpc_execute','CRITICAL',count(*)::bigint,
         'New v2.6.6 RPCs must not be executable by PUBLIC or anon'
  from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='erp' and p.proname in(
      'save_accessory_category_v2','save_accessory_material_v2',
      'set_accessory_uom_conversion_v2','set_accessory_selling_price_v2',
      'save_fg_adjustment_draft_v2','post_fg_adjustment_v2','reverse_fg_adjustment_v2'
    )
    and (has_function_privilege('public',p.oid,'EXECUTE')
      or has_function_privilege('anon',p.oid,'EXECUTE'))
  union all
  select 'v266_missing_optimistic_version','CRITICAL',count(*)::bigint,
         'Accessory category and FG adjustment headers require row_version'
  from (values('accessory_categories'),('fg_adjustments')) x(table_name)
  where not exists(
    select 1 from information_schema.columns c
    where c.table_schema='erp' and c.table_name=x.table_name and c.column_name='row_version'
  )
  union all
  select 'v266_view_without_security_invoker','CRITICAL',count(*)::bigint,
         'New Gudang views must honor base-table RLS'
  from (values('v_accessory_master_browser'),('v_accessory_price_browser'),('v_gudang_fg_adjustment_browser')) x(view_name)
  join pg_class c on c.relname=x.view_name
  join pg_namespace n on n.oid=c.relnamespace and n.nspname='erp'
  where not ('security_invoker=true'=any(coalesce(c.reloptions,array[]::text[])))
  union all
  select 'v266_accessory_material_category_mismatch','CRITICAL',count(*)::bigint,
         'Accessory materials must match their category base UOM'
  from erp.materials m
  left join erp.accessory_categories ac on ac.id=m.accessory_category_id
  where m.material_type='ACCESSORY'
    and (ac.id is null or m.unit_code<>ac.base_uom_code)
  union all
  select 'v266_posted_fg_adjustment_missing_movement','CRITICAL',count(*)::bigint,
         'Each posted FG adjustment item requires its authoritative movement'
  from erp.fg_adjustments h
  join erp.fg_adjustment_items i on i.adjustment_id=h.id
  where h.status in('POSTED','REVERSED') and not exists(
    select 1 from erp.fg_stock_movements m
    where m.source_type='FG_ADJUSTMENT_ITEM' and m.source_id=i.id
      and m.movement_type='ADJUSTMENT'
  )
  union all
  select 'v266_reversed_fg_adjustment_missing_reversal','CRITICAL',count(*)::bigint,
         'Each reversed FG adjustment movement requires an append-only reversal movement'
  from erp.fg_adjustments h
  join erp.fg_adjustment_items i on i.adjustment_id=h.id
  join erp.fg_stock_movements m on m.source_type='FG_ADJUSTMENT_ITEM'
    and m.source_id=i.id and m.movement_type='ADJUSTMENT'
  where h.status='REVERSED' and not exists(
    select 1 from erp.fg_stock_movements r where r.reversal_of_id=m.id
  );
$$;

revoke all on function erp.run_v266_gudang_accessory_fg_checks() from public;
grant execute on function erp.run_v266_gudang_accessory_fg_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.6',
  'Safe accessory category/material/UOM/price successors and idempotent FG adjustment aggregate',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828090017','erp_v266_gudang_accessory_fg_contracts',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828090017 erp_v266_gudang_accessory_fg_contracts

-- BEGIN PLATFORM MIGRATION 20260828093617 erp_v267_financial_truth_grni_late_invoice
-- ERP Garment v2.6.7
-- Financial-truth hardening for material receipts and late supplier invoices.
--
-- Business invariants:
-- 1. A physical receipt without a final supplier invoice creates GRNI / estimated
--    liability, not final supplier AP.
-- 2. A supplier invoice can match multiple receipt lines and partial quantities.
-- 3. Invoice price/discount corrections are append-only: DRAFT may be edited or
--    deleted; POSTED must be reversed and replaced.
-- 4. Late invoice cost differences replay chronological material MA and therefore
--    flow through RM/WIP/FG/COGS without overwriting historical sale snapshots.
-- 5. Supplier payment is capped by final AP only; GRNI is disclosed separately.

set lock_timeout='10s';
set statement_timeout='180s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_7',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.6') then
    raise exception 'ERP Garment v2.6.6 is required before v2.6.7';
  end if;

  -- This release deliberately changes the liability account used by estimated
  -- receipts. Existing live transactions require an explicit opening/reclass
  -- migration. Both authorized targets are transaction-empty at release time.
  if exists(select 1 from erp.material_purchase_headers where status<>'DRAFT')
     or exists(select 1 from erp.journal_entries) then
    raise exception 'v2.6.7 requires a transaction-empty target or a separately approved GRNI opening reclassification';
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1. GRNI chart account and protected mapping
-- ---------------------------------------------------------------------------

do $$
declare v_account uuid;
begin
  select id into v_account from erp.chart_accounts where account_code='2020';
  if v_account is null then
    v_account:=gen_random_uuid();
    insert into erp.chart_accounts(
      id,account_code,account_name,account_type,report_group,normal_balance,is_postable,is_active
    ) values(
      v_account,'2020','Estimasi Kewajiban Barang Diterima / GRNI',
      'LIABILITY','GRNI','CREDIT',true,true
    );
  elsif not exists(
    select 1 from erp.chart_accounts
    where id=v_account and account_type='LIABILITY' and normal_balance='CREDIT'
      and is_postable and is_active
  ) then
    raise exception 'Chart account 2020 exists but is not an active postable CREDIT liability';
  end if;

  insert into erp.accounting_account_mappings(mapping_key,account_id,notes)
  values(
    'GRNI_MATERIAL',v_account,
    'Estimated material receipt liability until a final supplier invoice is posted'
  )
  on conflict(mapping_key) do update
  set account_id=excluded.account_id,notes=excluded.notes;
end;
$$;

create or replace function erp.expected_mapping_account_type(p_mapping_key text)
returns text
language sql immutable
set search_path=erp,public,pg_temp
as $$
select case upper(p_mapping_key)
  when 'CASH' then 'ASSET' when 'BANK' then 'ASSET' when 'AR_CUSTOMER' then 'ASSET'
  when 'MATERIAL_INVENTORY' then 'ASSET' when 'WIP' then 'ASSET'
  when 'FG_INVENTORY' then 'ASSET' when 'CONTRACTOR_RECEIVABLE' then 'ASSET'
  when 'AP_VENDOR' then 'LIABILITY' when 'AP_SUPPLIER' then 'LIABILITY'
  when 'GRNI_MATERIAL' then 'LIABILITY'
  when 'ACCRUED_MANUFACTURING' then 'LIABILITY' when 'CONTRACTOR_PAYABLE' then 'LIABILITY'
  when 'OPENING_EQUITY' then 'EQUITY'
  when 'SALES_REVENUE' then 'REVENUE' when 'OTHER_INCOME' then 'REVENUE'
  when 'MATERIAL_RECOVERY' then 'REVENUE'
  when 'COGS' then 'EXPENSE' when 'LAUNDRY_COST' then 'EXPENSE'
  when 'LABOR_COST' then 'EXPENSE' when 'OTHER_EXPENSE' then 'EXPENSE'
  when 'HPP_ADJUSTMENT_CLEARING' then 'EXPENSE'
  when 'ACCESSORY_RECOVERY_COGS' then 'EXPENSE'
  when 'ACCESSORY_REIMBURSE_VARIANCE' then 'EXPENSE'
  when 'MATERIAL_PURCHASE_VARIANCE' then 'EXPENSE'
  else null end
$$;

-- ---------------------------------------------------------------------------
-- 2. Receipt-line matching state and supplier-invoice aggregate
-- ---------------------------------------------------------------------------

alter table erp.material_purchase_items
  add column if not exists invoice_match_state varchar(20) not null default 'UNMATCHED',
  add column if not exists receipt_price_source_snapshot varchar(30);

update erp.material_purchase_items
set invoice_match_state=case when price_state='FINAL' then 'DIRECT_FINAL' else 'UNMATCHED' end,
    receipt_price_source_snapshot=coalesce(receipt_price_source_snapshot,price_source);

alter table erp.material_purchase_items
  alter column receipt_price_source_snapshot set not null,
  drop constraint if exists material_purchase_items_price_state_check,
  add constraint material_purchase_items_price_state_check
    check(price_state in('ESTIMATED','PARTIAL','FINAL')),
  add constraint material_purchase_items_invoice_match_state_check
    check(invoice_match_state in('UNMATCHED','PARTIAL','MATCHED','DIRECT_FINAL'));

create or replace function erp.normalize_material_purchase_invoice_match_state()
returns trigger
language plpgsql
set search_path=erp,public,pg_temp
as $$
begin
  if tg_op='INSERT' then
    new.receipt_price_source_snapshot:=new.price_source;
  elsif new.invoice_match_state in('UNMATCHED','DIRECT_FINAL')
        and old.invoice_match_state in('UNMATCHED','DIRECT_FINAL') then
    new.receipt_price_source_snapshot:=new.price_source;
  end if;

  if new.invoice_match_state in('PARTIAL','MATCHED') then
    new.price_source:='SUPPLIER_INVOICE';
    new.price_state:=case when new.invoice_match_state='MATCHED' then 'FINAL' else 'PARTIAL' end;
  elsif new.price_state='FINAL' then
    new.invoice_match_state:='DIRECT_FINAL';
  else
    new.invoice_match_state:='UNMATCHED';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_normalize_material_purchase_invoice_match_state on erp.material_purchase_items;
create trigger trg_normalize_material_purchase_invoice_match_state
before insert or update of price_state,price_source,invoice_match_state,receipt_price_source_snapshot
on erp.material_purchase_items for each row
execute function erp.normalize_material_purchase_invoice_match_state();

create table erp.material_supplier_invoices(
  id uuid primary key default gen_random_uuid(),
  invoice_number varchar(100) not null,
  supplier_id uuid not null references erp.suppliers(id),
  invoice_date date not null,
  received_at timestamptz not null default clock_timestamp(),
  due_date date,
  status varchar(20) not null default 'DRAFT'
    check(status in('DRAFT','POSTED','REVERSED')),
  notes text,
  posting_reason text,
  reversal_reason text,
  row_version bigint not null default 1 check(row_version>0),
  created_by uuid references erp.app_users(id),
  created_at timestamptz not null default clock_timestamp(),
  updated_at timestamptz not null default clock_timestamp(),
  posted_at timestamptz,
  reversed_at timestamptz,
  unique(supplier_id,invoice_number),
  check(due_date is null or due_date>=invoice_date)
);

create table erp.material_supplier_invoice_lines(
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references erp.material_supplier_invoices(id) on delete cascade,
  purchase_item_id uuid not null references erp.material_purchase_items(id),
  qty_invoiced numeric(18,6) not null check(qty_invoiced>0),
  unit_price numeric(18,6) not null check(unit_price>=0),
  discount_amount numeric(24,6) not null default 0 check(discount_amount>=0),
  gross_amount numeric(24,6) generated always as(qty_invoiced*unit_price) stored,
  net_amount numeric(24,6) generated always as((qty_invoiced*unit_price)-discount_amount) stored,
  net_unit_cost numeric(18,6) generated always as(((qty_invoiced*unit_price)-discount_amount)/qty_invoiced) stored,
  receipt_estimate_unit_cost_snapshot numeric(18,6),
  prior_blended_unit_cost_snapshot numeric(18,6),
  posted_blended_unit_cost_snapshot numeric(18,6),
  grni_clear_amount_snapshot numeric(24,6),
  ap_create_amount_snapshot numeric(24,6),
  inventory_revaluation_snapshot numeric(24,6),
  bridge_variance_snapshot numeric(24,6),
  notes text,
  created_at timestamptz not null default clock_timestamp(),
  unique(invoice_id,purchase_item_id),
  check(discount_amount<=qty_invoiced*unit_price)
);

alter table erp.material_supplier_invoices enable row level security;
alter table erp.material_supplier_invoice_lines enable row level security;

revoke all on table erp.material_supplier_invoices,
  erp.material_supplier_invoice_lines
from public,anon,authenticated;
grant select on table erp.material_supplier_invoices,
  erp.material_supplier_invoice_lines
to authenticated;

create policy material_supplier_invoices_internal_read
on erp.material_supplier_invoices for select to authenticated
using(erp.current_app_role() in('OWNER','ADMIN','STAFF'));

create policy material_supplier_invoice_lines_internal_read
on erp.material_supplier_invoice_lines for select to authenticated
using(erp.current_app_role() in('OWNER','ADMIN','STAFF'));

create trigger trg_00_bump_row_version
before update on erp.material_supplier_invoices
for each row execute function erp.bump_row_version();
create trigger trg_touch_material_supplier_invoices
before update on erp.material_supplier_invoices
for each row execute function erp.touch_updated_at();
create trigger trg_guard_material_supplier_invoices
before insert or delete or update on erp.material_supplier_invoices
for each row execute function erp.guard_posted_document();
create trigger trg_guard_material_supplier_invoice_lines
before insert or delete or update on erp.material_supplier_invoice_lines
for each row execute function erp.guard_child_by_parent_status('material_supplier_invoices','invoice_id','DRAFT');
create trigger trg_audit_material_supplier_invoices
after insert or delete or update on erp.material_supplier_invoices
for each row execute function erp.audit_row_change();
create trigger trg_audit_material_supplier_invoice_lines
after insert or delete or update on erp.material_supplier_invoice_lines
for each row execute function erp.audit_row_change();

create index idx_material_supplier_invoice_lines_purchase_item
  on erp.material_supplier_invoice_lines(purchase_item_id,invoice_id);
create index idx_material_supplier_invoices_supplier_status_date
  on erp.material_supplier_invoices(supplier_id,status,invoice_date,id);

alter table erp.material_supplier_return_items
  add column if not exists ap_relief_qty_snapshot numeric(18,6),
  add column if not exists grni_relief_qty_snapshot numeric(18,6),
  add column if not exists ap_relief_amount_snapshot numeric(24,6),
  add column if not exists grni_relief_amount_snapshot numeric(24,6);

alter table erp.material_purchase_cost_correction_items
  add column if not exists item_supplier_final_price_before numeric(18,6),
  add column if not exists item_price_finalized_at_before timestamptz,
  add column if not exists item_price_finalized_by_before uuid;

-- ---------------------------------------------------------------------------
-- 3. Matching, valuation, AP and GRNI helpers
-- ---------------------------------------------------------------------------

create or replace function erp.material_purchase_grni_return_qty(p_purchase_item_id uuid)
returns numeric
language sql stable security definer
set search_path=erp,public,pg_temp
as $$
select coalesce(sum(coalesce(ri.grni_relief_qty_snapshot,0)),0)::numeric
from erp.material_supplier_return_items ri
join erp.material_supplier_returns r on r.id=ri.return_id
where ri.purchase_item_id=$1 and r.status='POSTED'
$$;

create or replace function erp.material_purchase_posted_invoice_qty(p_purchase_item_id uuid)
returns numeric
language sql stable security definer
set search_path=erp,public,pg_temp
as $$
select coalesce(sum(l.qty_invoiced),0)::numeric
from erp.material_supplier_invoice_lines l
join erp.material_supplier_invoices h on h.id=l.invoice_id
where l.purchase_item_id=$1 and h.status='POSTED'
$$;

create or replace function erp.material_purchase_invoice_capacity(p_purchase_item_id uuid)
returns numeric
language sql stable security definer
set search_path=erp,public,pg_temp
as $$
select greatest(i.qty-erp.material_purchase_grni_return_qty(i.id),0)::numeric
from erp.material_purchase_items i where i.id=$1
$$;

create or replace function erp.material_purchase_current_unit_cost(p_purchase_item_id uuid)
returns numeric
language plpgsql stable security definer
set search_path=erp,public,pg_temp
as $$
declare
  i erp.material_purchase_items%rowtype;
  v_basis_qty numeric;
  v_invoice_delta numeric;
  v_cost numeric;
begin
  select * into i from erp.material_purchase_items where id=p_purchase_item_id;
  if i.id is null then return null; end if;

  if exists(
    select 1 from erp.material_supplier_invoice_lines l
    join erp.material_supplier_invoices h on h.id=l.invoice_id
    where l.purchase_item_id=i.id and h.status='POSTED'
  ) then
    v_basis_qty:=erp.material_purchase_invoice_capacity(i.id);
    if v_basis_qty<=0 then return i.unit_price; end if;
    select coalesce(sum(l.net_amount-(l.qty_invoiced*i.unit_price)),0)
    into v_invoice_delta
    from erp.material_supplier_invoice_lines l
    join erp.material_supplier_invoices h on h.id=l.invoice_id
    where l.purchase_item_id=i.id and h.status='POSTED';
    return greatest(((v_basis_qty*i.unit_price)+v_invoice_delta)/v_basis_qty,0);
  end if;

  select ci.new_unit_price into v_cost
  from erp.material_purchase_cost_correction_items ci
  join erp.material_purchase_cost_corrections c on c.id=ci.correction_id
  where ci.purchase_item_id=i.id and c.status='POSTED'
  order by c.post_seq desc,c.posted_at desc,c.id desc limit 1;
  return coalesce(v_cost,i.unit_price);
end;
$$;

create or replace function erp.material_purchase_grni_total(p_purchase_id uuid)
returns numeric
language sql stable security definer
set search_path=erp,public,pg_temp
as $$
select coalesce(sum(
  case when i.invoice_match_state='DIRECT_FINAL' then 0
  else greatest(
    erp.material_purchase_invoice_capacity(i.id)
      - erp.material_purchase_posted_invoice_qty(i.id),0
  )*i.unit_price end
),0)::numeric
from erp.material_purchase_items i where i.purchase_id=$1
$$;

create or replace function erp.material_purchase_final_ap_total(p_purchase_id uuid)
returns numeric
language sql stable security definer
set search_path=erp,public,pg_temp
as $$
with item_ap as(
  select i.id,
    case when i.invoice_match_state='DIRECT_FINAL'
      then i.qty*erp.material_purchase_current_unit_cost(i.id)
      else coalesce((
        select sum(l.net_amount)
        from erp.material_supplier_invoice_lines l
        join erp.material_supplier_invoices h on h.id=l.invoice_id
        where l.purchase_item_id=i.id and h.status='POSTED'
      ),0)
    end as gross_ap
  from erp.material_purchase_items i where i.purchase_id=$1
),return_relief as(
  select coalesce(sum(coalesce(ri.ap_relief_amount_snapshot,0)),0) amount
  from erp.material_supplier_return_items ri
  join erp.material_supplier_returns r on r.id=ri.return_id
  join erp.material_purchase_items i on i.id=ri.purchase_item_id
  where i.purchase_id=$1 and r.status='POSTED'
)
select greatest(coalesce(sum(item_ap.gross_ap),0)-(select amount from return_relief),0)::numeric
from item_ap
$$;

create or replace function erp.material_purchase_payable_total(p_purchase_id uuid)
returns numeric
language sql stable security definer
set search_path=erp,public,pg_temp
as $$
select erp.material_purchase_final_ap_total($1)
$$;

create or replace function erp.material_purchase_total_liability(p_purchase_id uuid)
returns numeric
language sql stable security definer
set search_path=erp,public,pg_temp
as $$
select erp.material_purchase_final_ap_total($1)+erp.material_purchase_grni_total($1)
$$;

-- Existing purchase posting remains the authoritative stock function. This
-- status hook reclassifies only estimated receipt lines from AP to GRNI, and
-- reverses that reclassification when the purchase itself is reversed.
create or replace function erp.sync_material_purchase_grni_on_status()
returns trigger
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare v_estimated numeric(24,6);v_journal uuid;v_reason text;
begin
  if old.status='DRAFT' and new.status='POSTED' then
    select coalesce(sum(i.line_total),0) into v_estimated
    from erp.material_purchase_items i
    where i.purchase_id=new.id and i.invoice_match_state<>'DIRECT_FINAL';
    if v_estimated>0.005 then
      perform erp.post_journal(
        'MATERIAL_PURCHASE_GRNI_RECLASS',new.id,new.physical_at::date,
        'Receipt without final supplier invoice: AP reclassified to GRNI',
        jsonb_build_array(
          jsonb_build_object('mapping_key','AP_SUPPLIER','debit',round(v_estimated,2),'credit',0),
          jsonb_build_object('mapping_key','GRNI_MATERIAL','debit',0,'credit',round(v_estimated,2))
        )
      );
    end if;
  elsif old.status='POSTED' and new.status='REVERSED' then
    select id into v_journal from erp.journal_entries
    where source_type='MATERIAL_PURCHASE_GRNI_RECLASS' and source_id=new.id and status='POSTED'
    order by posting_at desc,id desc limit 1;
    if v_journal is not null then
      v_reason:=coalesce(nullif(current_setting('app.change_reason',true),''),'Material purchase reversal');
      perform erp.reverse_journal(v_journal,v_reason);
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_sync_material_purchase_grni_on_status on erp.material_purchase_headers;
create trigger trg_sync_material_purchase_grni_on_status
after update of status on erp.material_purchase_headers
for each row when(old.status is distinct from new.status)
execute function erp.sync_material_purchase_grni_on_status();

-- Legacy cost-correction rows remain valid only for purchases that were final
-- at physical receipt. Estimated/partially matched receipts must use the new
-- supplier-invoice aggregate so GRNI cannot be bypassed.
create or replace function erp.guard_direct_final_cost_correction_state()
returns trigger
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
begin
  if old.status='DRAFT' and new.status='POSTED' then
    if exists(
      select 1 from erp.material_purchase_cost_correction_items ci
      join erp.material_purchase_items i on i.id=ci.purchase_item_id
      where ci.correction_id=new.id and i.invoice_match_state<>'DIRECT_FINAL'
    ) then
      raise exception 'Estimated/partial receipt price must be finalized through material supplier invoice v2 so GRNI and AP remain separated';
    end if;
    update erp.material_purchase_cost_correction_items ci
    set item_supplier_final_price_before=i.supplier_final_unit_price_snapshot,
        item_price_finalized_at_before=i.price_finalized_at,
        item_price_finalized_by_before=i.price_finalized_by
    from erp.material_purchase_items i
    where ci.correction_id=new.id and i.id=ci.purchase_item_id;
  end if;
  return new;
end;
$$;

create or replace function erp.sync_direct_final_cost_correction_item_state()
returns trigger
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
begin
  if old.status='DRAFT' and new.status='POSTED' then
    update erp.material_purchase_items i
    set supplier_final_unit_price_snapshot=ci.new_unit_price,
        price_finalized_at=clock_timestamp(),
        price_finalized_by=erp.current_app_user_id()
    from erp.material_purchase_cost_correction_items ci
    where ci.correction_id=new.id and i.id=ci.purchase_item_id;
  elsif old.status='POSTED' and new.status='REVERSED' then
    update erp.material_purchase_items i
    set supplier_final_unit_price_snapshot=ci.item_supplier_final_price_before,
        price_finalized_at=ci.item_price_finalized_at_before,
        price_finalized_by=ci.item_price_finalized_by_before
    from erp.material_purchase_cost_correction_items ci
    where ci.correction_id=new.id and i.id=ci.purchase_item_id;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_05_guard_direct_final_cost_correction_state on erp.material_purchase_cost_corrections;
create trigger trg_05_guard_direct_final_cost_correction_state
before update of status on erp.material_purchase_cost_corrections
for each row when(old.status is distinct from new.status)
execute function erp.guard_direct_final_cost_correction_state();

drop trigger if exists trg_95_sync_direct_final_cost_correction_item_state on erp.material_purchase_cost_corrections;
create trigger trg_95_sync_direct_final_cost_correction_item_state
after update of status on erp.material_purchase_cost_corrections
for each row when(old.status is distinct from new.status)
execute function erp.sync_direct_final_cost_correction_item_state();

-- ---------------------------------------------------------------------------
-- 4. Atomic multi-receipt / partial-quantity supplier invoice contract
-- ---------------------------------------------------------------------------

create or replace function erp.refresh_material_purchase_item_match_state(p_purchase_item_id uuid)
returns void
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare
  i erp.material_purchase_items%rowtype;
  v_capacity numeric;
  v_matched numeric;
  v_actual_avg numeric;
  v_last_at timestamptz;
  v_last_by uuid;
begin
  perform erp.require_internal();
  select * into i from erp.material_purchase_items where id=p_purchase_item_id for update;
  if i.id is null then raise exception 'Material purchase item not found'; end if;
  if i.invoice_match_state='DIRECT_FINAL' then return; end if;

  v_capacity:=erp.material_purchase_invoice_capacity(i.id);
  select coalesce(sum(l.qty_invoiced),0),
         case when coalesce(sum(l.qty_invoiced),0)>0 then sum(l.net_amount)/sum(l.qty_invoiced) end,
         max(h.posted_at),
         (array_agg(h.created_by order by h.posted_at desc,h.id desc))[1]
  into v_matched,v_actual_avg,v_last_at,v_last_by
  from erp.material_supplier_invoice_lines l
  join erp.material_supplier_invoices h on h.id=l.invoice_id
  where l.purchase_item_id=i.id and h.status='POSTED';

  if v_matched<=0 then
    update erp.material_purchase_items
    set invoice_match_state='UNMATCHED',price_state='ESTIMATED',
        price_source=receipt_price_source_snapshot,
        supplier_final_unit_price_snapshot=null,
        price_finalized_at=null,price_finalized_by=null
    where id=i.id;
  elsif v_matched<v_capacity-0.000001 then
    update erp.material_purchase_items
    set invoice_match_state='PARTIAL',price_state='PARTIAL',price_source='SUPPLIER_INVOICE',
        supplier_final_unit_price_snapshot=v_actual_avg,
        price_finalized_at=v_last_at,price_finalized_by=v_last_by
    where id=i.id;
  else
    update erp.material_purchase_items
    set invoice_match_state='MATCHED',price_state='FINAL',price_source='SUPPLIER_INVOICE',
        supplier_final_unit_price_snapshot=v_actual_avg,
        price_finalized_at=v_last_at,price_finalized_by=v_last_by
    where id=i.id;
  end if;
end;
$$;

create or replace function erp.refresh_material_purchase_item_cost(p_purchase_item_id uuid)
returns void
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare
  i erp.material_purchase_items%rowtype;
  h erp.material_purchase_headers%rowtype;
  v_cost numeric;
begin
  perform erp.require_internal();
  select * into i from erp.material_purchase_items where id=p_purchase_item_id for update;
  if i.id is null then raise exception 'Material purchase item not found'; end if;
  select * into h from erp.material_purchase_headers where id=i.purchase_id for update;
  if h.id is null or h.status<>'POSTED' then raise exception 'Source purchase must be POSTED'; end if;
  v_cost:=erp.material_purchase_current_unit_cost(i.id);

  update erp.material_stock_movements msm
  set input_unit_cost=v_cost
  where msm.movement_type='PURCHASE' and msm.qty_signed>0 and(
    (msm.source_type='MATERIAL_PURCHASE_ITEM' and msm.source_id=i.id)
    or
    (msm.source_type='MATERIAL_PURCHASE_ROLL' and msm.source_id in(
      select mr.id from erp.material_rolls mr where mr.purchase_item_id=i.id
    ))
  );
  if not found then raise exception 'Original purchase stock movement not found for item %',i.id; end if;
  perform erp.recalculate_material_cost(i.material_id,h.physical_at);
end;
$$;

create or replace function erp.validate_material_supplier_invoice_line()
returns trigger
language plpgsql
set search_path=erp,public,pg_temp
as $$
declare v_invoice_supplier uuid;v_purchase_supplier uuid;v_status text;
begin
  select supplier_id,status into v_invoice_supplier,v_status
  from erp.material_supplier_invoices where id=new.invoice_id;
  if v_status is null then raise exception 'Supplier invoice header not found'; end if;
  if v_status<>'DRAFT' then raise exception 'Supplier invoice lines may only change while DRAFT'; end if;

  select h.supplier_id into v_purchase_supplier
  from erp.material_purchase_items i
  join erp.material_purchase_headers h on h.id=i.purchase_id
  where i.id=new.purchase_item_id and h.status='POSTED';
  if v_purchase_supplier is null then raise exception 'Invoice line must reference a POSTED material receipt'; end if;
  if v_purchase_supplier is distinct from v_invoice_supplier then
    raise exception 'Invoice supplier does not match receipt supplier';
  end if;
  return new;
end;
$$;

create trigger trg_validate_material_supplier_invoice_line
before insert or update of invoice_id,purchase_item_id,qty_invoiced,unit_price,discount_amount
on erp.material_supplier_invoice_lines for each row
execute function erp.validate_material_supplier_invoice_line();

create or replace function erp.post_material_supplier_invoice(p_invoice_id uuid)
returns void
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare
  h erp.material_supplier_invoices%rowtype;
  r record;
  v_capacity numeric;
  v_matched numeric;
  v_old_cost numeric;
  v_new_cost numeric;
  v_basis_qty numeric;
  v_delta_before numeric;
  v_delta_after numeric;
  v_inventory_delta numeric;
  v_liability_delta numeric;
  v_bridge numeric;
  v_grni_total numeric(24,6):=0;
  v_ap_total numeric(24,6):=0;
  v_inventory_total numeric(24,6):=0;
  v_bridge_total numeric(24,6):=0;
  v_lines jsonb:='[]'::jsonb;
  v_purchase uuid;
  v_paid numeric;
  v_payable numeric;
begin
  perform erp.require_owner_admin();
  select * into h from erp.material_supplier_invoices where id=p_invoice_id for update;
  if h.id is null or h.status<>'DRAFT' then raise exception 'Material supplier invoice must be DRAFT'; end if;
  if h.invoice_date>current_date then raise exception 'Supplier invoice date cannot be in the future'; end if;
  if h.received_at::date>current_date then raise exception 'Supplier invoice received_at cannot be in the future'; end if;
  if not exists(select 1 from erp.material_supplier_invoice_lines where invoice_id=h.id) then
    raise exception 'Material supplier invoice has no lines';
  end if;

  -- Deterministic lock order protects concurrent invoice/payment/return clicks.
  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id order by i.purchase_id
  loop
    perform 1 from erp.material_purchase_headers where id=v_purchase for update;
  end loop;
  for r in
    select distinct i.id
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id order by i.id
  loop
    perform 1 from erp.material_purchase_items where id=r.id for update;
  end loop;

  for r in
    select l.*,i.qty as receipt_qty,i.unit_price as estimate_unit_cost,
           i.material_id,i.purchase_id,i.invoice_match_state,
           ph.supplier_id,ph.physical_at
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    join erp.material_purchase_headers ph on ph.id=i.purchase_id
    where l.invoice_id=h.id order by i.id
  loop
    if r.supplier_id is distinct from h.supplier_id then
      raise exception 'Invoice supplier does not match receipt supplier for item %',r.purchase_item_id;
    end if;
    if r.invoice_match_state='DIRECT_FINAL' then
      raise exception 'Receipt item % was already final-invoiced at physical receipt',r.purchase_item_id;
    end if;
    v_capacity:=erp.material_purchase_invoice_capacity(r.purchase_item_id);
    v_matched:=erp.material_purchase_posted_invoice_qty(r.purchase_item_id);
    if v_matched+r.qty_invoiced>v_capacity+0.000001 then
      raise exception 'Invoice quantity exceeds unmatched receipt quantity for item %. Capacity %, already matched %, requested %',
        r.purchase_item_id,v_capacity,v_matched,r.qty_invoiced;
    end if;

    v_old_cost:=erp.material_purchase_current_unit_cost(r.purchase_item_id);
    v_basis_qty:=v_capacity;
    select coalesce(sum(x.net_amount-(x.qty_invoiced*r.estimate_unit_cost)),0)
    into v_delta_before
    from erp.material_supplier_invoice_lines x
    join erp.material_supplier_invoices xh on xh.id=x.invoice_id
    where x.purchase_item_id=r.purchase_item_id and xh.status='POSTED';
    v_delta_after:=v_delta_before+(r.net_amount-(r.qty_invoiced*r.estimate_unit_cost));
    v_new_cost:=greatest(((v_basis_qty*r.estimate_unit_cost)+v_delta_after)/v_basis_qty,0);
    v_inventory_delta:=r.receipt_qty*(v_new_cost-v_old_cost);
    v_liability_delta:=r.net_amount-(r.qty_invoiced*r.estimate_unit_cost);
    v_bridge:=v_inventory_delta-v_liability_delta;

    update erp.material_supplier_invoice_lines
    set receipt_estimate_unit_cost_snapshot=r.estimate_unit_cost,
        prior_blended_unit_cost_snapshot=v_old_cost,
        posted_blended_unit_cost_snapshot=v_new_cost,
        grni_clear_amount_snapshot=r.qty_invoiced*r.estimate_unit_cost,
        ap_create_amount_snapshot=r.net_amount,
        inventory_revaluation_snapshot=v_inventory_delta,
        bridge_variance_snapshot=v_bridge
    where id=r.id;

    v_grni_total:=v_grni_total+(r.qty_invoiced*r.estimate_unit_cost);
    v_ap_total:=v_ap_total+r.net_amount;
    v_inventory_total:=v_inventory_total+v_inventory_delta;
    v_bridge_total:=v_bridge_total+v_bridge;
  end loop;

  update erp.material_supplier_invoices
  set status='POSTED',posted_at=clock_timestamp(),posting_reason=coalesce(posting_reason,'Supplier invoice posted')
  where id=h.id;

  if v_grni_total>0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','GRNI_MATERIAL','debit',round(v_grni_total,2),'credit',0));
  end if;
  if v_inventory_total>0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','MATERIAL_INVENTORY','debit',round(v_inventory_total,2),'credit',0));
  elsif v_inventory_total< -0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','MATERIAL_INVENTORY','debit',0,'credit',round(abs(v_inventory_total),2)));
  end if;
  if v_bridge_total>0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','MATERIAL_PURCHASE_VARIANCE','debit',0,'credit',round(v_bridge_total,2)));
  elsif v_bridge_total< -0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','MATERIAL_PURCHASE_VARIANCE','debit',round(abs(v_bridge_total),2),'credit',0));
  end if;
  if v_ap_total>0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','AP_SUPPLIER','debit',0,'credit',round(v_ap_total,2)));
  end if;
  if jsonb_array_length(v_lines)>=2 then
    perform erp.post_journal(
      'MATERIAL_SUPPLIER_INVOICE',h.id,h.invoice_date,
      'Final supplier invoice / GRNI matching '||h.invoice_number,v_lines
    );
  end if;

  for r in
    select distinct l.purchase_item_id
    from erp.material_supplier_invoice_lines l
    where l.invoice_id=h.id order by l.purchase_item_id
  loop
    perform erp.refresh_material_purchase_item_cost(r.purchase_item_id);
    perform erp.refresh_material_purchase_item_match_state(r.purchase_item_id);
  end loop;

  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id order by i.purchase_id
  loop
    select erp.material_purchase_final_ap_total(v_purchase),
           coalesce((select sum(amount) from erp.supplier_payments where purchase_id=v_purchase and status='POSTED'),0)
    into v_payable,v_paid;
    update erp.material_purchase_headers
    set supplier_invoice_number=h.invoice_number,
        due_date=coalesce(h.due_date,due_date),
        payment_status=case when v_paid>=v_payable-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end
    where id=v_purchase;
  end loop;
end;
$$;

create or replace function erp.reverse_material_supplier_invoice(p_invoice_id uuid,p_reason text)
returns void
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare
  h erp.material_supplier_invoices%rowtype;
  r record;
  v_purchase uuid;
  v_current_ap numeric;
  v_invoice_ap numeric;
  v_paid numeric;
  v_journal uuid;
  v_latest record;
begin
  perform erp.require_owner_admin();
  if nullif(btrim(p_reason),'') is null then raise exception 'Supplier invoice reversal reason is required'; end if;
  select * into h from erp.material_supplier_invoices where id=p_invoice_id for update;
  if h.id is null then raise exception 'Material supplier invoice not found'; end if;
  if h.status='REVERSED' then return; end if;
  if h.status<>'POSTED' then raise exception 'Only a POSTED supplier invoice may be reversed'; end if;

  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id order by i.purchase_id
  loop
    perform 1 from erp.material_purchase_headers where id=v_purchase for update;
    select erp.material_purchase_final_ap_total(v_purchase),
           coalesce(sum(l.net_amount),0),
           coalesce((select sum(amount) from erp.supplier_payments where purchase_id=v_purchase and status='POSTED'),0)
    into v_current_ap,v_invoice_ap,v_paid
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id and i.purchase_id=v_purchase;
    if v_paid>v_current_ap-v_invoice_ap+0.01 then
      raise exception 'Reverse supplier payments first: payment % would exceed projected final AP %',
        v_paid,v_current_ap-v_invoice_ap;
    end if;
  end loop;

  if exists(
    select 1
    from erp.material_supplier_invoice_lines l
    join erp.material_supplier_return_items ri on ri.purchase_item_id=l.purchase_item_id
    join erp.material_supplier_returns rh on rh.id=ri.return_id
    where l.invoice_id=h.id and rh.status='POSTED'
      and coalesce(ri.ap_relief_qty_snapshot,0)>0
  ) then
    raise exception 'Reverse AP-backed supplier returns before reversing this invoice';
  end if;

  select id into v_journal from erp.journal_entries
  where source_type='MATERIAL_SUPPLIER_INVOICE' and source_id=h.id and status='POSTED'
  order by posting_at desc,id desc limit 1;
  if exists(
    select 1 from erp.material_supplier_invoice_lines
    where invoice_id=h.id and(
      coalesce(grni_clear_amount_snapshot,0)<>0
      or coalesce(ap_create_amount_snapshot,0)<>0
      or coalesce(inventory_revaluation_snapshot,0)<>0
    )
  ) and v_journal is null then
    raise exception 'Supplier invoice journal is missing; reversal aborted to protect AP/GRNI/HPP';
  end if;

  update erp.material_supplier_invoices
  set status='REVERSED',reversed_at=clock_timestamp(),reversal_reason=btrim(p_reason)
  where id=h.id;
  if v_journal is not null then perform erp.reverse_journal(v_journal,p_reason); end if;

  for r in
    select distinct l.purchase_item_id
    from erp.material_supplier_invoice_lines l
    where l.invoice_id=h.id order by l.purchase_item_id
  loop
    perform erp.refresh_material_purchase_item_cost(r.purchase_item_id);
    perform erp.refresh_material_purchase_item_match_state(r.purchase_item_id);
  end loop;

  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id order by i.purchase_id
  loop
    select ih.invoice_number,ih.due_date into v_latest
    from erp.material_supplier_invoices ih
    join erp.material_supplier_invoice_lines il on il.invoice_id=ih.id
    join erp.material_purchase_items pi on pi.id=il.purchase_item_id
    where pi.purchase_id=v_purchase and ih.status='POSTED'
    order by ih.posted_at desc,ih.id desc limit 1;
    select erp.material_purchase_final_ap_total(v_purchase),
           coalesce((select sum(amount) from erp.supplier_payments where purchase_id=v_purchase and status='POSTED'),0)
    into v_current_ap,v_paid;
    update erp.material_purchase_headers
    set supplier_invoice_number=v_latest.invoice_number,
        due_date=v_latest.due_date,
        payment_status=case when v_paid>=v_current_ap-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end
    where id=v_purchase;
  end loop;

  insert into erp.audit_logs(entity_type,entity_id,action,changed_by,change_reason)
  values('material_supplier_invoices',h.id,'REVERSE',erp.current_app_user_id(),p_reason);
end;
$$;

create or replace function erp.save_material_supplier_invoice_draft_v2(
  p_payload jsonb,p_client_request_id uuid,p_expected_version bigint
)
returns jsonb
language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_id uuid:=nullif(p_payload->>'id','')::uuid;
  v_action text:=upper(coalesce(nullif(p_payload->>'action',''),'SAVE'));
  h erp.material_supplier_invoices%rowtype;
  j jsonb;v_reason text:=nullif(btrim(p_payload->>'change_reason'),'');
begin
  perform erp.require_owner_admin();
  if v_reason is null then raise exception 'change_reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('save_material_supplier_invoice_draft_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',v_reason,true);

  if v_action='DELETE' then
    if v_id is null or p_expected_version is null then raise exception 'id and expected_version are required for delete'; end if;
    select * into h from erp.material_supplier_invoices where id=v_id for update;
    if h.id is null then raise exception 'Supplier invoice draft not found'; end if;
    if h.status<>'DRAFT' then raise exception 'Only a DRAFT supplier invoice may be deleted'; end if;
    if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
    delete from erp.material_supplier_invoices where id=h.id;
    v_response:=jsonb_build_object('supplier_invoice_id',v_id,'deleted',true);
    return erp._idempotency_complete('save_material_supplier_invoice_draft_v2',p_client_request_id,v_response);
  elsif v_action<>'SAVE' then
    raise exception 'Unsupported action %',v_action;
  end if;

  if nullif(btrim(p_payload->>'invoice_number'),'') is null then raise exception 'invoice_number is required'; end if;
  if nullif(p_payload->>'supplier_id','') is null then raise exception 'supplier_id is required'; end if;
  if nullif(p_payload->>'invoice_date','') is null then raise exception 'invoice_date is required'; end if;
  if (p_payload->>'invoice_date')::date>current_date then raise exception 'invoice_date cannot be in the future'; end if;
  if coalesce(jsonb_typeof(p_payload->'lines'),'null')<>'array'
     or jsonb_array_length(p_payload->'lines')=0 then raise exception 'At least one invoice line is required'; end if;

  if v_id is null then
    v_id:=gen_random_uuid();
    insert into erp.material_supplier_invoices(
      id,invoice_number,supplier_id,invoice_date,received_at,due_date,notes,created_by
    ) values(
      v_id,btrim(p_payload->>'invoice_number'),(p_payload->>'supplier_id')::uuid,
      (p_payload->>'invoice_date')::date,
      coalesce(nullif(p_payload->>'received_at','')::timestamptz,clock_timestamp()),
      nullif(p_payload->>'due_date','')::date,nullif(btrim(p_payload->>'notes'),''),
      erp.current_app_user_id()
    );
  else
    if p_expected_version is null then raise exception 'expected_version is required for update'; end if;
    select * into h from erp.material_supplier_invoices where id=v_id for update;
    if h.id is null or h.status<>'DRAFT' then raise exception 'Supplier invoice must be DRAFT'; end if;
    if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
    update erp.material_supplier_invoices
    set invoice_number=btrim(p_payload->>'invoice_number'),
        supplier_id=(p_payload->>'supplier_id')::uuid,
        invoice_date=(p_payload->>'invoice_date')::date,
        received_at=coalesce(nullif(p_payload->>'received_at','')::timestamptz,received_at),
        due_date=nullif(p_payload->>'due_date','')::date,
        notes=nullif(btrim(p_payload->>'notes'),'')
    where id=v_id;
    delete from erp.material_supplier_invoice_lines where invoice_id=v_id;
  end if;

  for j in select value from jsonb_array_elements(p_payload->'lines') loop
    insert into erp.material_supplier_invoice_lines(
      invoice_id,purchase_item_id,qty_invoiced,unit_price,discount_amount,notes
    ) values(
      v_id,(j->>'purchase_item_id')::uuid,(j->>'qty_invoiced')::numeric,
      (j->>'unit_price')::numeric,coalesce(nullif(j->>'discount_amount','')::numeric,0),
      nullif(btrim(j->>'notes'),'')
    );
  end loop;
  update erp.material_supplier_invoices set updated_at=clock_timestamp() where id=v_id;
  select * into h from erp.material_supplier_invoices where id=v_id;
  v_response:=jsonb_build_object(
    'supplier_invoice_id',h.id,'invoice_number',h.invoice_number,'status',h.status,
    'row_version',h.row_version,
    'line_count',(select count(*) from erp.material_supplier_invoice_lines where invoice_id=h.id),
    'gross_amount',(select coalesce(sum(gross_amount),0) from erp.material_supplier_invoice_lines where invoice_id=h.id),
    'discount_amount',(select coalesce(sum(discount_amount),0) from erp.material_supplier_invoice_lines where invoice_id=h.id),
    'net_amount',(select coalesce(sum(net_amount),0) from erp.material_supplier_invoice_lines where invoice_id=h.id)
  );
  return erp._idempotency_complete('save_material_supplier_invoice_draft_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.post_material_supplier_invoice_v2(
  p_invoice_id uuid,p_client_request_id uuid,p_expected_version bigint,p_reason text
)
returns jsonb
language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare v_hash text;v_cached jsonb;v_response jsonb;h erp.material_supplier_invoices%rowtype;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'posting reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('invoice_id',p_invoice_id,'expected_version',p_expected_version,'reason',btrim(p_reason)));
  v_cached:=erp._idempotency_begin('post_material_supplier_invoice_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.material_supplier_invoices where id=p_invoice_id for update;
  if h.id is null or h.status<>'DRAFT' then raise exception 'Supplier invoice must be DRAFT'; end if;
  if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
  update erp.material_supplier_invoices set posting_reason=btrim(p_reason) where id=h.id;
  perform erp.post_material_supplier_invoice(h.id);
  select * into h from erp.material_supplier_invoices where id=h.id;
  v_response:=jsonb_build_object(
    'supplier_invoice_id',h.id,'invoice_number',h.invoice_number,'status',h.status,
    'row_version',h.row_version,
    'net_amount',(select coalesce(sum(net_amount),0) from erp.material_supplier_invoice_lines where invoice_id=h.id)
  );
  return erp._idempotency_complete('post_material_supplier_invoice_v2',p_client_request_id,v_response);
end;
$$;

create or replace function erp.reverse_material_supplier_invoice_v2(
  p_invoice_id uuid,p_reason text,p_client_request_id uuid,p_expected_version bigint
)
returns jsonb
language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare v_hash text;v_cached jsonb;v_response jsonb;h erp.material_supplier_invoices%rowtype;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'reversal reason is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object('invoice_id',p_invoice_id,'expected_version',p_expected_version,'reason',btrim(p_reason)));
  v_cached:=erp._idempotency_begin('reverse_material_supplier_invoice_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  select * into h from erp.material_supplier_invoices where id=p_invoice_id for update;
  if h.id is null then raise exception 'Supplier invoice not found'; end if;
  if h.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version; end if;
  perform erp.reverse_material_supplier_invoice(h.id,p_reason);
  select * into h from erp.material_supplier_invoices where id=h.id;
  v_response:=jsonb_build_object(
    'supplier_invoice_id',h.id,'invoice_number',h.invoice_number,'status',h.status,
    'row_version',h.row_version
  );
  return erp._idempotency_complete('reverse_material_supplier_invoice_v2',p_client_request_id,v_response);
end;
$$;

-- Compatibility successor for the v2.6.2 single-receipt finalization API.
-- Optional qty_invoiced and discount_amount now permit partial matching; omitted
-- qty means "all remaining" exactly as the legacy call expected.
create or replace function erp.finalize_material_purchase_invoice_v2(
  p_payload jsonb,p_client_request_id uuid,p_expected_version bigint
)
returns jsonb
language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_purchase uuid:=nullif(p_payload->>'purchase_id','')::uuid;
  ph erp.material_purchase_headers%rowtype;
  ih erp.material_supplier_invoices%rowtype;
  j jsonb;i erp.material_purchase_items%rowtype;
  v_qty numeric;v_remaining numeric;v_state text;
begin
  perform erp.require_owner_admin();
  if v_purchase is null then raise exception 'purchase_id is required'; end if;
  if nullif(btrim(p_payload->>'supplier_invoice_number'),'') is null then raise exception 'supplier_invoice_number is required'; end if;
  if nullif(p_payload->>'invoice_date','') is null then raise exception 'invoice_date is required'; end if;
  if nullif(btrim(p_payload->>'reason'),'') is null then raise exception 'reason is required'; end if;
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if coalesce(jsonb_typeof(p_payload->'lines'),'null')<>'array'
     or jsonb_array_length(p_payload->'lines')=0 then raise exception 'At least one final invoice line is required'; end if;

  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('finalize_material_purchase_invoice_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_payload->>'reason'),true);

  select * into ph from erp.material_purchase_headers where id=v_purchase for update;
  if ph.id is null or ph.status<>'POSTED' then raise exception 'Purchase must be POSTED'; end if;
  if ph.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,ph.row_version; end if;
  if ph.supplier_id is null then raise exception 'Purchase supplier is required'; end if;

  insert into erp.material_supplier_invoices(
    invoice_number,supplier_id,invoice_date,received_at,due_date,notes,posting_reason,created_by
  ) values(
    btrim(p_payload->>'supplier_invoice_number'),ph.supplier_id,(p_payload->>'invoice_date')::date,
    coalesce(nullif(p_payload->>'received_at','')::timestamptz,clock_timestamp()),
    nullif(p_payload->>'due_date','')::date,nullif(btrim(p_payload->>'notes'),''),
    btrim(p_payload->>'reason'),erp.current_app_user_id()
  ) returning * into ih;

  for j in select value from jsonb_array_elements(p_payload->'lines') loop
    select * into i from erp.material_purchase_items
    where id=(j->>'purchase_item_id')::uuid and purchase_id=ph.id for update;
    if i.id is null then raise exception 'Final invoice line does not belong to purchase'; end if;
    v_remaining:=erp.material_purchase_invoice_capacity(i.id)-erp.material_purchase_posted_invoice_qty(i.id);
    v_qty:=coalesce(nullif(j->>'qty_invoiced','')::numeric,v_remaining);
    if v_qty<=0 then raise exception 'No unmatched quantity remains for purchase item %',i.id; end if;
    insert into erp.material_supplier_invoice_lines(
      invoice_id,purchase_item_id,qty_invoiced,unit_price,discount_amount,notes
    ) values(
      ih.id,i.id,v_qty,(j->>'final_unit_price')::numeric,
      coalesce(nullif(j->>'discount_amount','')::numeric,0),nullif(btrim(j->>'notes'),'')
    );
  end loop;

  perform erp.post_material_supplier_invoice(ih.id);
  select case when bool_and(i.price_state='FINAL') then 'FINAL' else 'PARTIAL' end
  into v_state
  from erp.material_supplier_invoice_lines l
  join erp.material_purchase_items i on i.id=l.purchase_item_id
  where l.invoice_id=ih.id;
  select * into ph from erp.material_purchase_headers where id=ph.id;
  v_response:=jsonb_build_object(
    'purchase_id',ph.id,'correction_id',ih.id,'supplier_invoice_id',ih.id,
    'supplier_invoice_number',ih.invoice_number,'price_state',v_state,
    'row_version',ph.row_version
  );
  return erp._idempotency_complete('finalize_material_purchase_invoice_v2',p_client_request_id,v_response);
end;
$$;

-- ---------------------------------------------------------------------------
-- 5. Supplier return split: final AP relief versus uninvoiced GRNI relief
-- ---------------------------------------------------------------------------

create or replace function erp.post_material_supplier_return(p_return_id uuid)
returns void
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare
  h erp.material_supplier_returns%rowtype;
  r record;
  v_purchase uuid;
  v_invoiced_qty numeric;
  v_prior_ap_qty numeric;
  v_ap_qty numeric;
  v_grni_qty numeric;
  v_paid numeric;
  v_payable numeric;
  v_proposed_relief numeric;
  v_carry numeric(24,6):=0;
  v_ap_relief numeric(24,6):=0;
  v_grni_relief numeric(24,6):=0;
  v_line_carry numeric(24,6);
  v_variance numeric(24,6);
  v_lines jsonb:='[]'::jsonb;
begin
  perform erp.require_internal();
  select * into h from erp.material_supplier_returns where id=p_return_id for update;
  if h.id is null or h.status<>'DRAFT' then raise exception 'Supplier return must be DRAFT'; end if;
  if h.location_id is null then raise exception 'Supplier return location is required'; end if;
  if not exists(select 1 from erp.material_supplier_return_items where return_id=h.id) then
    raise exception 'Supplier return has no lines';
  end if;

  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_return_items ri
    join erp.material_purchase_items i on i.id=ri.purchase_item_id
    where ri.return_id=h.id order by i.purchase_id
  loop
    perform 1 from erp.material_purchase_headers where id=v_purchase for update;
  end loop;

  -- Allocate each physical return against already-final AP first; any remaining
  -- quantity cancels the receipt estimate in GRNI. These snapshots are immutable
  -- once the document posts and make reversal deterministic.
  for r in
    select ri.*,i.qty as receipt_qty,i.unit_price as estimate_unit_cost,
           i.invoice_match_state,i.purchase_id
    from erp.material_supplier_return_items ri
    join erp.material_purchase_items i on i.id=ri.purchase_item_id
    where ri.return_id=h.id order by i.id,ri.id
  loop
    perform 1 from erp.material_purchase_items where id=r.purchase_item_id for update;
    v_invoiced_qty:=case when r.invoice_match_state='DIRECT_FINAL'
      then r.receipt_qty else erp.material_purchase_posted_invoice_qty(r.purchase_item_id) end;
    select coalesce(sum(coalesce(x.ap_relief_qty_snapshot,0)),0)
    into v_prior_ap_qty
    from erp.material_supplier_return_items x
    join erp.material_supplier_returns xh on xh.id=x.return_id
    where x.purchase_item_id=r.purchase_item_id and xh.status='POSTED';
    v_ap_qty:=least(r.qty,greatest(v_invoiced_qty-v_prior_ap_qty,0));
    v_grni_qty:=r.qty-v_ap_qty;
    update erp.material_supplier_return_items
    set ap_relief_qty_snapshot=v_ap_qty,
        grni_relief_qty_snapshot=v_grni_qty,
        ap_relief_amount_snapshot=v_ap_qty*r.supplier_credit_unit_price,
        grni_relief_amount_snapshot=v_grni_qty*r.estimate_unit_cost
    where id=r.id;
  end loop;

  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_return_items ri
    join erp.material_purchase_items i on i.id=ri.purchase_item_id
    where ri.return_id=h.id order by i.purchase_id
  loop
    select erp.material_purchase_final_ap_total(v_purchase),
           coalesce((select sum(amount) from erp.supplier_payments where purchase_id=v_purchase and status='POSTED'),0),
           coalesce(sum(ri.ap_relief_amount_snapshot),0)
    into v_payable,v_paid,v_proposed_relief
    from erp.material_supplier_return_items ri
    join erp.material_purchase_items i on i.id=ri.purchase_item_id
    where ri.return_id=h.id and i.purchase_id=v_purchase;
    if v_paid>v_payable-v_proposed_relief+0.01 then
      raise exception 'Supplier return would make payment % exceed projected final AP %. Reverse/correct supplier payment first.',
        v_paid,v_payable-v_proposed_relief;
    end if;
  end loop;

  update erp.material_supplier_returns set status='POSTED' where id=h.id;

  for r in
    select ri.*
    from erp.material_supplier_return_items ri
    where ri.return_id=h.id order by ri.material_id,ri.id
  loop
    insert into erp.material_stock_movements(
      material_id,roll_id,location_id,movement_type,qty_signed,
      source_type,source_id,physical_at,created_by,note
    ) values(
      r.material_id,r.roll_id,h.location_id,'SUPPLIER_RETURN',-r.qty,
      'MATERIAL_SUPPLIER_RETURN_ITEM',r.id,h.physical_at,erp.current_app_user_id(),h.reason
    );

    -- GRNI-backed returns reduce the cost-basis quantity. Recompute the source
    -- purchase layer before replaying chronological MA.
    perform erp.refresh_material_purchase_item_cost(r.purchase_item_id);
    select r.qty*coalesce(msm.unit_cost_snapshot,0)
    into v_line_carry
    from erp.material_stock_movements msm
    where msm.source_type='MATERIAL_SUPPLIER_RETURN_ITEM' and msm.source_id=r.id
    order by msm.system_created_at desc,msm.id desc limit 1;
    v_carry:=v_carry+coalesce(v_line_carry,0);
    v_ap_relief:=v_ap_relief+coalesce(r.ap_relief_amount_snapshot,0);
    v_grni_relief:=v_grni_relief+coalesce(r.grni_relief_amount_snapshot,0);
    if r.roll_id is not null then
      update erp.material_rolls
      set status=case when cached_qty=0 then 'RETURNED_SUPPLIER' else status end,updated_at=now()
      where id=r.roll_id;
    end if;
  end loop;

  v_variance:=v_carry-v_ap_relief-v_grni_relief;
  if v_ap_relief>0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','AP_SUPPLIER','debit',round(v_ap_relief,2),'credit',0));
  end if;
  if v_grni_relief>0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','GRNI_MATERIAL','debit',round(v_grni_relief,2),'credit',0));
  end if;
  if v_variance>0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','MATERIAL_PURCHASE_VARIANCE','debit',round(v_variance,2),'credit',0));
  elsif v_variance< -0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','MATERIAL_PURCHASE_VARIANCE','debit',0,'credit',round(abs(v_variance),2)));
  end if;
  if v_carry>0.005 then
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object(
      'mapping_key','MATERIAL_INVENTORY','debit',0,'credit',round(v_carry,2)));
  end if;
  if jsonb_array_length(v_lines)>=2 then
    perform erp.post_journal(
      'MATERIAL_SUPPLIER_RETURN',h.id,h.physical_at::date,
      'Material returned to supplier; AP/GRNI relief split',v_lines
    );
  end if;

  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_return_items ri
    join erp.material_purchase_items i on i.id=ri.purchase_item_id
    where ri.return_id=h.id order by i.purchase_id
  loop
    select erp.material_purchase_final_ap_total(v_purchase),
           coalesce((select sum(amount) from erp.supplier_payments where purchase_id=v_purchase and status='POSTED'),0)
    into v_payable,v_paid;
    update erp.material_purchase_headers
    set payment_status=case when v_paid>=v_payable-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end
    where id=v_purchase;
  end loop;
end;
$$;

create or replace function erp.reverse_material_supplier_return(p_return_id uuid,p_reason text)
returns void
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare
  h erp.material_supplier_returns%rowtype;
  r record;
  v_journal uuid;
  v_purchase uuid;
  v_payable numeric;
  v_paid numeric;
  v_roll_qty numeric;
  v_cost numeric;
begin
  perform erp.require_owner_admin();
  if nullif(btrim(p_reason),'') is null then raise exception 'Alasan reversal retur supplier wajib diisi'; end if;
  select * into h from erp.material_supplier_returns where id=p_return_id for update;
  if h.id is null then raise exception 'Retur supplier tidak ditemukan'; end if;
  if h.status='REVERSED' then return; end if;
  if h.status<>'POSTED' then raise exception 'Hanya retur supplier POSTED yang dapat direverse'; end if;

  perform erp.lock_supplier_return_source_purchases(h.id);
  select id into v_journal from erp.journal_entries
  where source_type='MATERIAL_SUPPLIER_RETURN' and source_id=h.id and status='POSTED'
  order by posting_at desc,id desc limit 1;
  if exists(
    select 1 from erp.material_supplier_return_items
    where return_id=h.id and(
      coalesce(ap_relief_amount_snapshot,0)<>0
      or coalesce(grni_relief_amount_snapshot,0)<>0
    )
  ) and v_journal is null then
    raise exception 'Jurnal retur supplier tidak ditemukan; reversal dibatalkan agar stok/AP/GRNI tidak rusak';
  end if;

  update erp.material_supplier_returns set status='REVERSED',updated_at=now() where id=h.id;

  -- Recalculate the purchase source input before reverse_material_movement runs,
  -- so its single chronological replay sees the restored GRNI cost-basis.
  for r in
    select distinct ri.purchase_item_id,i.material_id
    from erp.material_supplier_return_items ri
    join erp.material_purchase_items i on i.id=ri.purchase_item_id
    where ri.return_id=h.id order by ri.purchase_item_id
  loop
    v_cost:=erp.material_purchase_current_unit_cost(r.purchase_item_id);
    update erp.material_stock_movements msm
    set input_unit_cost=v_cost
    where msm.movement_type='PURCHASE' and msm.qty_signed>0 and(
      (msm.source_type='MATERIAL_PURCHASE_ITEM' and msm.source_id=r.purchase_item_id)
      or
      (msm.source_type='MATERIAL_PURCHASE_ROLL' and msm.source_id in(
        select mr.id from erp.material_rolls mr where mr.purchase_item_id=r.purchase_item_id
      ))
    );
  end loop;

  for r in
    select msm.id,ri.roll_id,ri.purchase_item_id
    from erp.material_stock_movements msm
    join erp.material_supplier_return_items ri on ri.id=msm.source_id
    where ri.return_id=h.id
      and msm.source_type='MATERIAL_SUPPLIER_RETURN_ITEM'
      and msm.movement_type='SUPPLIER_RETURN'
      and not exists(select 1 from erp.material_stock_movements rv where rv.reversal_of_id=msm.id)
    order by msm.physical_at desc,msm.id desc
  loop
    perform erp.reverse_material_movement(r.id,p_reason);
    perform erp.refresh_material_purchase_item_match_state(r.purchase_item_id);
    if r.roll_id is not null then
      select coalesce(sum(qty_signed),0) into v_roll_qty
      from erp.material_stock_movements where roll_id=r.roll_id;
      update erp.material_rolls
      set cached_qty=v_roll_qty,
          status=case when v_roll_qty<=0 then 'EXHAUSTED'
                      when v_roll_qty<original_qty then 'HALF_USED' else 'AVAILABLE' end,
          updated_at=now()
      where id=r.roll_id;
    end if;
  end loop;

  if v_journal is not null then perform erp.reverse_journal(v_journal,p_reason); end if;
  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_return_items ri
    join erp.material_purchase_items i on i.id=ri.purchase_item_id
    where ri.return_id=h.id order by i.purchase_id
  loop
    select erp.material_purchase_final_ap_total(v_purchase),
           coalesce((select sum(amount) from erp.supplier_payments where purchase_id=v_purchase and status='POSTED'),0)
    into v_payable,v_paid;
    update erp.material_purchase_headers
    set payment_status=case when v_paid>=v_payable-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end
    where id=v_purchase;
  end loop;
  insert into erp.audit_logs(entity_type,entity_id,action,changed_by,change_reason)
  values('material_supplier_returns',h.id,'REVERSE',erp.current_app_user_id(),p_reason);
end;
$$;

-- ---------------------------------------------------------------------------
-- 6. Owner/browser read models: estimated liability is never mislabeled as AP
-- ---------------------------------------------------------------------------

create or replace view erp.v_material_supplier_invoice_browser
with(security_invoker=true)
as
select
  h.id supplier_invoice_id,h.invoice_number,h.supplier_id,s.supplier_code,s.supplier_name,
  h.invoice_date,h.received_at,h.due_date,h.status,h.notes,h.posting_reason,h.reversal_reason,
  count(l.id) line_count,count(distinct i.purchase_id) receipt_count,
  coalesce(sum(l.qty_invoiced),0) matched_qty,
  coalesce(sum(l.gross_amount),0) gross_amount,
  coalesce(sum(l.discount_amount),0) discount_amount,
  coalesce(sum(l.net_amount),0) net_amount,
  min(ph.physical_at) oldest_receipt_at,
  case when min(ph.physical_at) is null then 0
       else greatest(h.received_at::date-min(ph.physical_at)::date,0) end invoice_delay_days,
  h.row_version,h.created_at,h.updated_at,h.posted_at,h.reversed_at,
  concat_ws(' ',h.invoice_number,s.supplier_code,s.supplier_name,h.status,h.notes) search_text
from erp.material_supplier_invoices h
join erp.suppliers s on s.id=h.supplier_id
left join erp.material_supplier_invoice_lines l on l.invoice_id=h.id
left join erp.material_purchase_items i on i.id=l.purchase_item_id
left join erp.material_purchase_headers ph on ph.id=i.purchase_id
group by h.id,s.id;

create or replace view erp.v_material_purchase_liability_status
with(security_invoker=true)
as
select
  h.id purchase_id,h.purchase_number,h.supplier_id,s.supplier_code,s.supplier_name,
  h.physical_at,h.status,h.payment_status,
  coalesce(sum(i.line_total),0) receipt_estimate_amount,
  erp.material_purchase_final_ap_total(h.id) final_ap_amount,
  erp.material_purchase_grni_total(h.id) grni_estimated_amount,
  erp.material_purchase_total_liability(h.id) total_liability_amount,
  coalesce((select sum(p.amount) from erp.supplier_payments p where p.purchase_id=h.id and p.status='POSTED'),0) paid_amount,
  greatest(
    erp.material_purchase_final_ap_total(h.id)
      -coalesce((select sum(p.amount) from erp.supplier_payments p where p.purchase_id=h.id and p.status='POSTED'),0),0
  ) final_ap_outstanding,
  case
    when erp.material_purchase_grni_total(h.id)>0.005
         and erp.material_purchase_final_ap_total(h.id)>0.005 then 'PARTIAL_INVOICE'
    when erp.material_purchase_grni_total(h.id)>0.005 then 'KASBON_BELUM_DITERIMA_ESTIMASI_KEWAJIBAN'
    when erp.material_purchase_final_ap_total(h.id)>0.005 then 'FINAL_AP'
    else 'NO_LIABILITY'
  end liability_state,
  (select string_agg(distinct ih.invoice_number,', ' order by ih.invoice_number)
   from erp.material_supplier_invoice_lines il
   join erp.material_supplier_invoices ih on ih.id=il.invoice_id
   join erp.material_purchase_items pi on pi.id=il.purchase_item_id
   where pi.purchase_id=h.id and ih.status='POSTED') active_invoice_numbers,
  (select min(ih.due_date)
   from erp.material_supplier_invoice_lines il
   join erp.material_supplier_invoices ih on ih.id=il.invoice_id
   join erp.material_purchase_items pi on pi.id=il.purchase_item_id
   where pi.purchase_id=h.id and ih.status='POSTED') earliest_due_date,
  case when erp.material_purchase_grni_total(h.id)>0.005
       then greatest(current_date-h.physical_at::date,0) else 0 end unfinalized_days,
  h.row_version,h.created_at,h.updated_at,
  concat_ws(' ',h.purchase_number,s.supplier_code,s.supplier_name,h.status) search_text
from erp.material_purchase_headers h
left join erp.suppliers s on s.id=h.supplier_id
left join erp.material_purchase_items i on i.purchase_id=h.id
group by h.id,s.id;

create or replace view erp.v_material_grni_aging
with(security_invoker=true)
as
select * from erp.v_material_purchase_liability_status
where status='POSTED' and grni_estimated_amount>0.005;

create or replace view erp.v_supplier_ap_aging
with(security_invoker=true)
as
with ap as(
  select
    h.id purchase_id,h.purchase_number,h.supplier_id,s.supplier_name,
    coalesce((
      select string_agg(distinct ih.invoice_number,', ' order by ih.invoice_number)
      from erp.material_supplier_invoice_lines il
      join erp.material_supplier_invoices ih on ih.id=il.invoice_id
      join erp.material_purchase_items pi on pi.id=il.purchase_item_id
      where pi.purchase_id=h.id and ih.status='POSTED'
    ),h.supplier_invoice_number)::varchar(100) supplier_invoice_number,
    h.physical_at,
    coalesce((
      select min(ih.due_date)
      from erp.material_supplier_invoice_lines il
      join erp.material_supplier_invoices ih on ih.id=il.invoice_id
      join erp.material_purchase_items pi on pi.id=il.purchase_item_id
      where pi.purchase_id=h.id and ih.status='POSTED'
    ),h.due_date) due_date,
    erp.material_purchase_final_ap_total(h.id) payable_amount,
    coalesce((select sum(sp.amount) from erp.supplier_payments sp where sp.purchase_id=h.id and sp.status='POSTED'),0) paid_amount
  from erp.material_purchase_headers h
  left join erp.suppliers s on s.id=h.supplier_id
  where h.status='POSTED'
)
select
  purchase_id,purchase_number,supplier_id,supplier_name,supplier_invoice_number,
  physical_at,due_date,payable_amount,paid_amount,
  greatest(payable_amount-paid_amount,0)::numeric outstanding_amount,
  case when due_date is null or payable_amount<=paid_amount then 0
       else greatest(current_date-due_date,0) end::integer days_overdue,
  case when payable_amount<=paid_amount then 'PAID'
       when due_date is null or current_date<=due_date then 'CURRENT'
       when current_date-due_date<=30 then '1_30'
       when current_date-due_date<=60 then '31_60'
       when current_date-due_date<=90 then '61_90'
       else '90_PLUS' end::text aging_bucket
from ap
where payable_amount>0.005 or paid_amount>0.005;

grant select on erp.v_material_supplier_invoice_browser,
  erp.v_material_purchase_liability_status,
  erp.v_material_grni_aging,
  erp.v_supplier_ap_aging
to authenticated;
revoke all on erp.v_material_supplier_invoice_browser,
  erp.v_material_purchase_liability_status,
  erp.v_material_grni_aging,
  erp.v_supplier_ap_aging
from anon;

-- ---------------------------------------------------------------------------
-- 7. Financial integrity gates
-- ---------------------------------------------------------------------------

create or replace function erp.run_v267_financial_truth_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language sql stable security definer
set search_path=erp,public,pg_catalog,information_schema,pg_temp
as $$
  select 'V267_GRNI_MAPPING_INVALID','CRITICAL',count(*)::bigint,
         'GRNI_MATERIAL must map to an active CREDIT liability account'
  from erp.accounting_account_mappings m
  join erp.chart_accounts a on a.id=m.account_id
  where m.mapping_key='GRNI_MATERIAL'
    and not(a.account_type='LIABILITY' and a.normal_balance='CREDIT' and a.is_active and a.is_postable)

  union all
  select 'V267_MISSING_GRNI_MAPPING','CRITICAL',case when exists(
    select 1 from erp.accounting_account_mappings where mapping_key='GRNI_MATERIAL'
  ) then 0 else 1 end::bigint,'GRNI mapping is required'

  union all
  select 'V267_ESTIMATED_RECEIPT_MISSING_GRNI_RECLASS','CRITICAL',count(*)::bigint,
         'Posted estimated receipts require an AP-to-GRNI reclassification journal'
  from erp.material_purchase_headers h
  where h.status='POSTED' and erp.material_purchase_grni_total(h.id)>0.005
    and not exists(
      select 1 from erp.journal_entries j
      where j.source_type='MATERIAL_PURCHASE_GRNI_RECLASS' and j.source_id=h.id
        and j.status in('POSTED','REVERSED')
    )

  union all
  select 'V267_POSTED_INVOICE_MISSING_JOURNAL','CRITICAL',count(*)::bigint,
         'Every non-zero posted supplier invoice requires an AP/GRNI journal'
  from erp.material_supplier_invoices h
  where h.status='POSTED'
    and exists(select 1 from erp.material_supplier_invoice_lines l where l.invoice_id=h.id and(l.net_amount<>0 or l.grni_clear_amount_snapshot<>0))
    and not exists(
      select 1 from erp.journal_entries j
      where j.source_type='MATERIAL_SUPPLIER_INVOICE' and j.source_id=h.id and j.status='POSTED'
    )

  union all
  select 'V267_INVOICE_MATCH_OVER_RECEIPT','CRITICAL',count(*)::bigint,
         'Posted supplier-invoice quantity exceeds receipt quantity net of GRNI-backed returns'
  from erp.material_purchase_items i
  where erp.material_purchase_posted_invoice_qty(i.id)>erp.material_purchase_invoice_capacity(i.id)+0.000001

  union all
  select 'V267_PAYMENT_EXCEEDS_FINAL_AP','CRITICAL',count(*)::bigint,
         'Supplier payment must never consume GRNI or exceed final AP'
  from erp.material_purchase_headers h
  where coalesce((select sum(p.amount) from erp.supplier_payments p where p.purchase_id=h.id and p.status='POSTED'),0)
        >erp.material_purchase_final_ap_total(h.id)+0.01

  union all
  select 'V267_LEGACY_CORRECTION_ON_GRNI','CRITICAL',count(*)::bigint,
         'Legacy price corrections may only touch DIRECT_FINAL receipt items'
  from erp.material_purchase_cost_correction_items ci
  join erp.material_purchase_cost_corrections c on c.id=ci.correction_id
  join erp.material_purchase_items i on i.id=ci.purchase_item_id
  where c.status='POSTED' and i.invoice_match_state<>'DIRECT_FINAL'

  union all
  select 'V267_POSTED_RETURN_MISSING_LIABILITY_SNAPSHOT','CRITICAL',count(*)::bigint,
         'Posted supplier returns require AP/GRNI quantity and amount snapshots'
  from erp.material_supplier_return_items ri
  join erp.material_supplier_returns rh on rh.id=ri.return_id
  where rh.status='POSTED' and(
    ri.ap_relief_qty_snapshot is null or ri.grni_relief_qty_snapshot is null
    or ri.ap_relief_amount_snapshot is null or ri.grni_relief_amount_snapshot is null
  )

  union all
  select 'V267_GRNI_GL_SUBLEDGER_MISMATCH','CRITICAL',case when abs(
    coalesce((select sum(a.credit_total-a.debit_total)
      from erp.account_daily_balances a
      where a.account_id=erp.account_id('GRNI_MATERIAL')),0)
    -coalesce((select sum(erp.material_purchase_grni_total(h.id))
      from erp.material_purchase_headers h where h.status='POSTED'),0)
  )>0.01 then 1 else 0 end::bigint,
  'GRNI general ledger must equal estimated unmatched receipt liability'

  union all
  select 'V267_AP_GL_SUBLEDGER_MISMATCH','CRITICAL',case when abs(
    coalesce((select sum(a.credit_total-a.debit_total)
      from erp.account_daily_balances a
      where a.account_id=erp.account_id('AP_SUPPLIER')),0)
    -coalesce((select sum(greatest(
      erp.material_purchase_final_ap_total(h.id)
      -coalesce((select sum(p.amount) from erp.supplier_payments p where p.purchase_id=h.id and p.status='POSTED'),0),0
    )) from erp.material_purchase_headers h where h.status='POSTED'),0)
  )>0.01 then 1 else 0 end::bigint,
  'Supplier AP general ledger must equal final-invoice subledger net of payment/returns'

  union all
  select 'V267_BROWSER_ROLE_DIRECT_INVOICE_WRITE','CRITICAL',count(*)::bigint,
         'Supplier invoice aggregate must be writable only through v2 RPCs'
  from information_schema.role_table_grants g
  where g.table_schema='erp' and g.table_name in('material_supplier_invoices','material_supplier_invoice_lines')
    and g.grantee in('PUBLIC','anon','authenticated')
    and g.privilege_type in('INSERT','UPDATE','DELETE');
$$;

-- Low-level accounting/cost helpers stay private. Browser roles receive only
-- idempotent, optimistic-locking aggregate RPCs and read models.
revoke all on function
  erp.material_purchase_grni_return_qty(uuid),
  erp.material_purchase_posted_invoice_qty(uuid),
  erp.material_purchase_invoice_capacity(uuid),
  erp.material_purchase_grni_total(uuid),
  erp.material_purchase_final_ap_total(uuid),
  erp.material_purchase_total_liability(uuid),
  erp.refresh_material_purchase_item_match_state(uuid),
  erp.refresh_material_purchase_item_cost(uuid),
  erp.post_material_supplier_invoice(uuid),
  erp.reverse_material_supplier_invoice(uuid,text)
from public,anon,authenticated;

grant execute on function
  erp.material_purchase_grni_return_qty(uuid),
  erp.material_purchase_posted_invoice_qty(uuid),
  erp.material_purchase_invoice_capacity(uuid),
  erp.material_purchase_grni_total(uuid),
  erp.material_purchase_final_ap_total(uuid),
  erp.material_purchase_total_liability(uuid),
  erp.refresh_material_purchase_item_match_state(uuid),
  erp.refresh_material_purchase_item_cost(uuid),
  erp.post_material_supplier_invoice(uuid),
  erp.reverse_material_supplier_invoice(uuid,text)
to service_role;

revoke all on function
  erp.save_material_supplier_invoice_draft_v2(jsonb,uuid,bigint),
  erp.post_material_supplier_invoice_v2(uuid,uuid,bigint,text),
  erp.reverse_material_supplier_invoice_v2(uuid,text,uuid,bigint),
  erp.finalize_material_purchase_invoice_v2(jsonb,uuid,bigint),
  erp.run_v267_financial_truth_checks()
from public,anon;

grant execute on function
  erp.save_material_supplier_invoice_draft_v2(jsonb,uuid,bigint),
  erp.post_material_supplier_invoice_v2(uuid,uuid,bigint,text),
  erp.reverse_material_supplier_invoice_v2(uuid,text,uuid,bigint),
  erp.finalize_material_purchase_invoice_v2(jsonb,uuid,bigint),
  erp.run_v267_financial_truth_checks()
to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.7',
  'GRNI versus final AP, multi-receipt partial supplier invoices, discount/reversal history, and AP/GRNI supplier-return split',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828093617','erp_v267_financial_truth_grni_late_invoice',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828093617 erp_v267_financial_truth_grni_late_invoice

-- BEGIN PLATFORM MIGRATION 20260828094048 v2_6_7a_multi_receipt_header_compat
-- ERP Garment v2.6.7a
-- Preserve the legacy one-invoice-number-per-receipt header constraint while
-- v2.6.7 stores authoritative cross-receipt matches in invoice aggregate tables.

set lock_timeout='10s';
set statement_timeout='60s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_7a',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.7') then
    raise exception 'ERP Garment v2.6.7 is required before v2.6.7a';
  end if;
end;
$$;

create or replace function erp.guard_multi_receipt_invoice_header_compat()
returns trigger
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare v_purchase_count bigint;
begin
  if new.supplier_invoice_number is distinct from old.supplier_invoice_number
     and new.supplier_invoice_number is not null then
    select count(distinct pi.purchase_id) into v_purchase_count
    from erp.material_supplier_invoices ih
    join erp.material_supplier_invoice_lines il on il.invoice_id=ih.id
    join erp.material_purchase_items pi on pi.id=il.purchase_item_id
    where ih.supplier_id=new.supplier_id
      and lower(btrim(ih.invoice_number))=lower(btrim(new.supplier_invoice_number))
      and ih.status='POSTED';
    if v_purchase_count>1 then
      new.supplier_invoice_number:=old.supplier_invoice_number;
      new.due_date:=old.due_date;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_01_guard_multi_receipt_invoice_header_compat on erp.material_purchase_headers;
create trigger trg_01_guard_multi_receipt_invoice_header_compat
before update of supplier_invoice_number,due_date on erp.material_purchase_headers
for each row execute function erp.guard_multi_receipt_invoice_header_compat();

revoke all on function erp.guard_multi_receipt_invoice_header_compat() from public,anon,authenticated;
grant execute on function erp.guard_multi_receipt_invoice_header_compat() to service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.7a',
  'Keep cross-receipt supplier invoice identity in the v2.6.7 aggregate without violating the legacy receipt-header uniqueness rule',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828094048','v2_6_7a_multi_receipt_header_compat',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828094048 v2_6_7a_multi_receipt_header_compat

-- BEGIN PLATFORM MIGRATION 20260828094232 v2_6_7b_reversal_dependency_order
-- ERP Garment v2.6.7b
-- Report the real blocking dependency when an AP-backed supplier return must
-- be reversed before its source supplier invoice.

set lock_timeout='10s';
set statement_timeout='60s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_7b',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.7a') then
    raise exception 'ERP Garment v2.6.7a is required before v2.6.7b';
  end if;
end;
$$;

create or replace function erp.reverse_material_supplier_invoice(p_invoice_id uuid,p_reason text)
returns void
language plpgsql security definer
set search_path=erp,public,pg_temp
as $$
declare
  h erp.material_supplier_invoices%rowtype;
  r record;
  v_purchase uuid;
  v_current_ap numeric;
  v_invoice_ap numeric;
  v_paid numeric;
  v_journal uuid;
  v_latest record;
begin
  perform erp.require_owner_admin();
  if nullif(btrim(p_reason),'') is null then raise exception 'Supplier invoice reversal reason is required'; end if;
  select * into h from erp.material_supplier_invoices where id=p_invoice_id for update;
  if h.id is null then raise exception 'Material supplier invoice not found'; end if;
  if h.status='REVERSED' then return; end if;
  if h.status<>'POSTED' then raise exception 'Only a POSTED supplier invoice may be reversed'; end if;

  if exists(
    select 1
    from erp.material_supplier_invoice_lines l
    join erp.material_supplier_return_items ri on ri.purchase_item_id=l.purchase_item_id
    join erp.material_supplier_returns rh on rh.id=ri.return_id
    where l.invoice_id=h.id and rh.status='POSTED'
      and coalesce(ri.ap_relief_qty_snapshot,0)>0
  ) then
    raise exception 'Reverse AP-backed supplier returns before reversing this invoice';
  end if;

  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id order by i.purchase_id
  loop
    perform 1 from erp.material_purchase_headers where id=v_purchase for update;
    select erp.material_purchase_final_ap_total(v_purchase),
           coalesce(sum(l.net_amount),0),
           coalesce((select sum(amount) from erp.supplier_payments where purchase_id=v_purchase and status='POSTED'),0)
    into v_current_ap,v_invoice_ap,v_paid
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id and i.purchase_id=v_purchase;
    if v_paid>v_current_ap-v_invoice_ap+0.01 then
      raise exception 'Reverse supplier payments first: payment % would exceed projected final AP %',
        v_paid,v_current_ap-v_invoice_ap;
    end if;
  end loop;

  select id into v_journal from erp.journal_entries
  where source_type='MATERIAL_SUPPLIER_INVOICE' and source_id=h.id and status='POSTED'
  order by posting_at desc,id desc limit 1;
  if exists(
    select 1 from erp.material_supplier_invoice_lines
    where invoice_id=h.id and(
      coalesce(grni_clear_amount_snapshot,0)<>0
      or coalesce(ap_create_amount_snapshot,0)<>0
      or coalesce(inventory_revaluation_snapshot,0)<>0
    )
  ) and v_journal is null then
    raise exception 'Supplier invoice journal is missing; reversal aborted to protect AP/GRNI/HPP';
  end if;

  update erp.material_supplier_invoices
  set status='REVERSED',reversed_at=clock_timestamp(),reversal_reason=btrim(p_reason)
  where id=h.id;
  if v_journal is not null then perform erp.reverse_journal(v_journal,p_reason); end if;

  for r in
    select distinct l.purchase_item_id
    from erp.material_supplier_invoice_lines l
    where l.invoice_id=h.id order by l.purchase_item_id
  loop
    perform erp.refresh_material_purchase_item_cost(r.purchase_item_id);
    perform erp.refresh_material_purchase_item_match_state(r.purchase_item_id);
  end loop;

  for v_purchase in
    select distinct i.purchase_id
    from erp.material_supplier_invoice_lines l
    join erp.material_purchase_items i on i.id=l.purchase_item_id
    where l.invoice_id=h.id order by i.purchase_id
  loop
    select ih.invoice_number,ih.due_date into v_latest
    from erp.material_supplier_invoices ih
    join erp.material_supplier_invoice_lines il on il.invoice_id=ih.id
    join erp.material_purchase_items pi on pi.id=il.purchase_item_id
    where pi.purchase_id=v_purchase and ih.status='POSTED'
    order by ih.posted_at desc,ih.id desc limit 1;
    select erp.material_purchase_final_ap_total(v_purchase),
           coalesce((select sum(amount) from erp.supplier_payments where purchase_id=v_purchase and status='POSTED'),0)
    into v_current_ap,v_paid;
    update erp.material_purchase_headers
    set supplier_invoice_number=v_latest.invoice_number,
        due_date=v_latest.due_date,
        payment_status=case when v_paid>=v_current_ap-0.01 then 'PAID' when v_paid>0 then 'PARTIAL' else 'UNPAID' end
    where id=v_purchase;
  end loop;

  insert into erp.audit_logs(entity_type,entity_id,action,changed_by,change_reason)
  values('material_supplier_invoices',h.id,'REVERSE',erp.current_app_user_id(),p_reason);
end;
$$;

revoke all on function erp.reverse_material_supplier_invoice(uuid,text) from public,anon,authenticated;
grant execute on function erp.reverse_material_supplier_invoice(uuid,text) to service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.7b',
  'Check AP-backed supplier-return dependency before supplier-payment projection during invoice reversal',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828094232','v2_6_7b_reversal_dependency_order',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828094232 v2_6_7b_reversal_dependency_order

-- BEGIN PLATFORM MIGRATION 20260828094907 v2_6_8_owner_financial_truth_reporting
-- ERP Garment v2.6.8
-- Owner financial truth: balanced SOFP including current earnings, one compact
-- owner snapshot, and controls that make stale/contradictory reports visible.

set lock_timeout='10s';
set statement_timeout='120s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_8',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.7b') then
    raise exception 'ERP Garment v2.6.7b is required before v2.6.8';
  end if;
end;
$$;

-- The old balance-sheet function omitted unclosed/current earnings. Every
-- journal could be balanced while the displayed SOFP looked insolvent or out
-- of balance. Preserve the existing result signature and add one synthetic,
-- non-postable current-earnings row.
create or replace function erp.get_balance_sheet(p_as_of date)
returns table(
  account_type varchar,
  report_group varchar,
  account_code varchar,
  account_name varchar,
  amount numeric
)
language plpgsql stable security definer
set search_path=erp,public,pg_catalog,pg_temp
as $$
begin
  perform erp.require_internal();
  if p_as_of is null then raise exception 'p_as_of is required'; end if;

  return query
  with bs as(
    select
      ca.account_type,ca.report_group,ca.account_code,ca.account_name,
      case when ca.normal_balance='CREDIT'
           then sum(adb.credit_total-adb.debit_total)
           else sum(adb.debit_total-adb.credit_total) end::numeric amount
    from erp.account_daily_balances adb
    join erp.chart_accounts ca on ca.id=adb.account_id
    where adb.balance_date<=p_as_of
      and ca.account_type in('ASSET','LIABILITY','EQUITY')
    group by ca.account_type,ca.report_group,ca.account_code,ca.account_name,ca.normal_balance
  ), current_earnings as(
    select coalesce(sum(adb.credit_total-adb.debit_total),0)::numeric amount
    from erp.account_daily_balances adb
    join erp.chart_accounts ca on ca.id=adb.account_id
    where adb.balance_date<=p_as_of
      and ca.account_type in('REVENUE','EXPENSE')
  )
  select x.account_type,x.report_group,x.account_code,x.account_name,x.amount
  from(
    select b.account_type,b.report_group,b.account_code,b.account_name,b.amount from bs b
    union all
    select 'EQUITY'::varchar,'CURRENT_EARNINGS'::varchar,'3999-CURRENT'::varchar,
           'Laba (Rugi) Berjalan / Current Earnings'::varchar,c.amount
    from current_earnings c
  ) x
  order by
    case x.account_type when 'ASSET' then 1 when 'LIABILITY' then 2 else 3 end,
    x.account_code;
end;
$$;

-- Security-invoker liability views call these pure read helpers. Without
-- explicit EXECUTE the browser role can have SELECT on the view and still fail
-- at runtime. These helpers disclose no more than the already-granted views.
grant execute on function erp.material_purchase_grni_total(uuid) to authenticated;
grant execute on function erp.material_purchase_final_ap_total(uuid) to authenticated;
grant execute on function erp.material_purchase_total_liability(uuid) to authenticated;

create or replace function erp.run_v268_financial_report_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language plpgsql stable security definer
set search_path=erp,public,pg_catalog,information_schema,pg_temp
as $$
begin
  perform erp.require_owner_admin();

  return query
  with expected_daily as(
    select je.transaction_date balance_date,jl.account_id,
           sum(jl.debit)::numeric debit_total,sum(jl.credit)::numeric credit_total
    from erp.journal_entries je
    join erp.journal_lines jl on jl.journal_entry_id=je.id
    where je.status in('POSTED','REVERSED')
    group by je.transaction_date,jl.account_id
  ), daily_mismatch as(
    select 1
    from expected_daily e
    full join erp.account_daily_balances a
      on a.balance_date=e.balance_date and a.account_id=e.account_id
    where abs(coalesce(e.debit_total,0)-coalesce(a.debit_total,0))>0.01
       or abs(coalesce(e.credit_total,0)-coalesce(a.credit_total,0))>0.01
  ), bs as(
    select
      coalesce(sum(case when ca.account_type='ASSET' then adb.debit_total-adb.credit_total else 0 end),0)::numeric assets,
      coalesce(sum(case when ca.account_type='LIABILITY' then adb.credit_total-adb.debit_total else 0 end),0)::numeric liabilities,
      coalesce(sum(case when ca.account_type='EQUITY' then adb.credit_total-adb.debit_total else 0 end),0)::numeric equity,
      coalesce(sum(case when ca.account_type in('REVENUE','EXPENSE') then adb.credit_total-adb.debit_total else 0 end),0)::numeric current_earnings
    from erp.account_daily_balances adb
    join erp.chart_accounts ca on ca.id=adb.account_id
  ), ar as(
    select
      coalesce((select sum(a.debit_total-a.credit_total) from erp.account_daily_balances a
                where a.account_id=erp.account_id('AR_CUSTOMER')),0)::numeric gl_amount,
      coalesce((select sum(greatest(
        erp.sale_net_total(h.id)-coalesce((select sum(p.amount) from erp.sales_payments p
                                           where p.sale_id=h.id and p.status='POSTED'),0),0
      )) from erp.sales_headers h
          where h.status in('POSTED','PARTIAL_PAID','PAID')),0)::numeric subledger_amount
  )
  select 'V268_DAILY_BALANCE_LEDGER_MISMATCH','CRITICAL',count(*)::bigint,
         'account_daily_balances must exactly equal posted/reversed journal lines by GL date and account'
  from daily_mismatch

  union all
  select 'V268_UNBALANCED_POSTED_JOURNAL','CRITICAL',count(*)::bigint,
         'Every posted/reversed journal entry must remain debit-equals-credit'
  from(
    select je.id from erp.journal_entries je
    join erp.journal_lines jl on jl.journal_entry_id=je.id
    where je.status in('POSTED','REVERSED')
    group by je.id having abs(sum(jl.debit)-sum(jl.credit))>0.01
  ) q

  union all
  select 'V268_BALANCE_SHEET_EQUATION','CRITICAL',
         case when abs(assets-liabilities-equity-current_earnings)>0.01 then 1 else 0 end::bigint,
         'Assets must equal liabilities plus recorded equity plus current earnings'
  from bs

  union all
  select 'V268_AR_GL_SUBLEDGER_MISMATCH','CRITICAL',
         case when abs(gl_amount-subledger_amount)>0.01 then 1 else 0 end::bigint,
         'Customer AR general ledger must equal active sales net of posted returns and customer payments'
  from ar

  union all
  select r.check_name,r.severity,r.issue_count,r.details
  from erp.run_v267_financial_truth_checks() r
  where r.check_name in('V267_GRNI_GL_SUBLEDGER_MISMATCH','V267_AP_GL_SUBLEDGER_MISMATCH')

  union all
  select 'V268_ACTIVE_SALE_MISSING_JOURNAL','CRITICAL',count(*)::bigint,
         'Every non-zero active sale requires its SALE journal'
  from erp.sales_headers h
  where h.status in('POSTED','PARTIAL_PAID','PAID')
    and(
      coalesce((select sum(i.line_total) from erp.sales_items i where i.sale_id=h.id),0)>0.005
      or coalesce((select sum(a.qty_pcs*a.unit_hpp_snapshot)
                   from erp.sale_stock_allocations a
                   join erp.sales_items i on i.id=a.sale_item_id where i.sale_id=h.id),0)>0.005
    )
    and not exists(select 1 from erp.journal_entries j
                   where j.source_type='SALE' and j.source_id=h.id and j.status='POSTED')

  union all
  select 'V268_POSTED_SALES_RETURN_MISSING_JOURNAL','CRITICAL',count(*)::bigint,
         'Every non-zero posted sales return requires its SALES_RETURN journal'
  from erp.sales_returns h
  where h.status='POSTED'
    and coalesce((select sum(i.refund_amount+i.qty_pcs*i.unit_hpp_snapshot)
                  from erp.sales_return_items i where i.return_id=h.id),0)>0.005
    and not exists(select 1 from erp.journal_entries j
                   where j.source_type='SALES_RETURN' and j.source_id=h.id and j.status='POSTED')

  union all
  select 'V268_POSTED_CUSTOMER_PAYMENT_MISSING_JOURNAL','CRITICAL',count(*)::bigint,
         'Every posted non-zero customer payment requires its SALES_PAYMENT journal'
  from erp.sales_payments p
  where p.status='POSTED' and p.amount>0.005
    and not exists(select 1 from erp.journal_entries j
                   where j.source_type='SALES_PAYMENT' and j.source_id=p.id and j.status='POSTED')

  union all
  select 'V268_PRODUCTION_FG_WITHOUT_CURRENT_HPP','CRITICAL',count(*)::bigint,
         'Every active production FG lot must have exactly one current HPP version'
  from erp.fg_lots l
  where l.lot_origin='PRODUCTION' and l.initial_qty_pcs>0
    and (select count(*) from erp.hpp_versions h where h.lot_id=l.id and h.is_current)<>1

  union all
  select 'V268_COST_RECALC_EXHAUSTED','CRITICAL',count(*)::bigint,
         'A permanently failed HPP recalc means owner profitability is not reliable'
  from erp.cost_recalc_queue q where q.status='FAILED' and q.attempt_count>=3

  union all
  select 'V268_COST_RECALC_PENDING','WARNING',count(*)::bigint,
         'Pending/running/retryable HPP recalc means profitability is provisional until the queue clears'
  from erp.cost_recalc_queue q
  where q.status in('PENDING','RUNNING') or(q.status='FAILED' and q.attempt_count<3)

  union all
  select 'V268_LIABILITY_VIEW_HELPER_PRIVILEGE','CRITICAL',count(*)::bigint,
         'Authenticated browser role needs EXECUTE on pure read helpers used by security-invoker liability views'
  from(values
    ('erp.material_purchase_grni_total(uuid)'),
    ('erp.material_purchase_final_ap_total(uuid)'),
    ('erp.material_purchase_total_liability(uuid)')
  ) f(signature)
  where not has_function_privilege('authenticated',f.signature,'EXECUTE')

  union all
  select 'V268_BROWSER_DIRECT_FINANCIAL_WRITE','CRITICAL',count(*)::bigint,
         'Browser roles must not directly mutate posted-source financial tables'
  from information_schema.role_table_grants g
  where g.table_schema='erp'
    and g.table_name in(
      'journal_entries','journal_lines','account_daily_balances',
      'material_supplier_invoices','material_supplier_invoice_lines',
      'sales_headers','sales_items','sales_returns','sales_return_items',
      'sales_payments','supplier_payments'
    )
    and g.grantee in('PUBLIC','anon','authenticated')
    and g.privilege_type in('INSERT','UPDATE','DELETE');
end;
$$;

create or replace function erp.get_owner_financial_snapshot_v2(
  p_from date,
  p_to date,
  p_as_of date default current_date
)
returns jsonb
language plpgsql stable security definer
set search_path=erp,public,pg_catalog,pg_temp
as $$
declare
  v_assets numeric:=0;v_liabilities numeric:=0;v_equity numeric:=0;v_current_earnings numeric:=0;
  v_cash numeric:=0;v_ar numeric:=0;v_material numeric:=0;v_wip numeric:=0;v_fg numeric:=0;
  v_ap numeric:=0;v_grni numeric:=0;
  v_sales_revenue numeric:=0;v_cogs numeric:=0;v_other_income numeric:=0;v_opex numeric:=0;v_net_profit numeric:=0;
  v_gross_sales numeric:=0;v_discounts numeric:=0;v_sales_returns numeric:=0;
  v_qc_good numeric:=0;v_qc_bs numeric:=0;
  v_laundry_good numeric:=0;v_laundry_bs numeric:=0;v_laundry_stuck numeric:=0;v_laundry_missing numeric:=0;
  v_grni_docs bigint:=0;v_grni_oldest integer:=0;v_ap_docs bigint:=0;v_ap_overdue numeric:=0;
  v_critical bigint:=0;v_warning bigint:=0;v_pending bigint:=0;
begin
  perform erp.require_owner_admin();
  if p_from is null or p_to is null or p_as_of is null then raise exception 'p_from, p_to and p_as_of are required'; end if;
  if p_from>p_to then raise exception 'p_from cannot be after p_to'; end if;
  if p_to>p_as_of then raise exception 'p_to cannot be after p_as_of'; end if;

  select
    coalesce(sum(case when ca.account_type='ASSET' then a.debit_total-a.credit_total else 0 end),0),
    coalesce(sum(case when ca.account_type='LIABILITY' then a.credit_total-a.debit_total else 0 end),0),
    coalesce(sum(case when ca.account_type='EQUITY' then a.credit_total-a.debit_total else 0 end),0),
    coalesce(sum(case when ca.account_type in('REVENUE','EXPENSE') then a.credit_total-a.debit_total else 0 end),0)
  into v_assets,v_liabilities,v_equity,v_current_earnings
  from erp.account_daily_balances a join erp.chart_accounts ca on ca.id=a.account_id
  where a.balance_date<=p_as_of;

  select coalesce(sum(a.debit_total-a.credit_total),0) into v_cash
  from erp.account_daily_balances a
  where a.balance_date<=p_as_of and a.account_id in(
    select ca.coa_account_id from erp.cash_accounts ca
    union select erp.account_id('CASH')
  );
  select coalesce(sum(a.debit_total-a.credit_total),0) into v_ar from erp.account_daily_balances a where a.balance_date<=p_as_of and a.account_id=erp.account_id('AR_CUSTOMER');
  select coalesce(sum(a.debit_total-a.credit_total),0) into v_material from erp.account_daily_balances a where a.balance_date<=p_as_of and a.account_id=erp.account_id('MATERIAL_INVENTORY');
  select coalesce(sum(a.debit_total-a.credit_total),0) into v_wip from erp.account_daily_balances a where a.balance_date<=p_as_of and a.account_id=erp.account_id('WIP');
  select coalesce(sum(a.debit_total-a.credit_total),0) into v_fg from erp.account_daily_balances a where a.balance_date<=p_as_of and a.account_id=erp.account_id('FG_INVENTORY');
  select coalesce(sum(a.credit_total-a.debit_total),0) into v_ap from erp.account_daily_balances a where a.balance_date<=p_as_of and a.account_id=erp.account_id('AP_SUPPLIER');
  select coalesce(sum(a.credit_total-a.debit_total),0) into v_grni from erp.account_daily_balances a where a.balance_date<=p_as_of and a.account_id=erp.account_id('GRNI_MATERIAL');

  select
    coalesce(sum(case when a.account_id=erp.account_id('SALES_REVENUE') then a.credit_total-a.debit_total else 0 end),0),
    coalesce(sum(case when a.account_id=erp.account_id('COGS') then a.debit_total-a.credit_total else 0 end),0),
    coalesce(sum(case when ca.account_type='REVENUE' and a.account_id<>erp.account_id('SALES_REVENUE') then a.credit_total-a.debit_total else 0 end),0),
    coalesce(sum(case when ca.account_type='EXPENSE' and a.account_id<>erp.account_id('COGS') then a.debit_total-a.credit_total else 0 end),0),
    coalesce(sum(case when ca.account_type in('REVENUE','EXPENSE') then a.credit_total-a.debit_total else 0 end),0)
  into v_sales_revenue,v_cogs,v_other_income,v_opex,v_net_profit
  from erp.account_daily_balances a join erp.chart_accounts ca on ca.id=a.account_id
  where a.balance_date between p_from and p_to;

  select coalesce(sum(i.qty_pcs*i.unit_price_snapshot),0),coalesce(sum(i.discount_amount),0)
  into v_gross_sales,v_discounts
  from erp.sales_items i join erp.sales_headers h on h.id=i.sale_id
  where h.status in('POSTED','PARTIAL_PAID','PAID') and h.sale_date::date between p_from and p_to;
  select coalesce(sum(i.refund_amount),0) into v_sales_returns
  from erp.sales_return_items i join erp.sales_returns h on h.id=i.return_id
  where h.status='POSTED' and h.physical_at::date between p_from and p_to;

  select coalesce(sum(i.qty_good_pcs),0),coalesce(sum(i.qty_bs_pcs),0)
  into v_qc_good,v_qc_bs
  from erp.qc_inspection_items i join erp.qc_inspections h on h.id=i.inspection_id
  where h.status='POSTED' and h.physical_at::date between p_from and p_to;
  select coalesce(sum(i.qty_good_received),0),coalesce(sum(i.qty_bs_laundry),0),
         coalesce(sum(i.qty_stuck),0),coalesce(sum(i.qty_missing),0)
  into v_laundry_good,v_laundry_bs,v_laundry_stuck,v_laundry_missing
  from erp.laundry_receipt_lines i join erp.laundry_receipts h on h.id=i.receipt_id
  where h.status='POSTED' and h.physical_at::date between p_from and p_to;

  select count(*)::bigint,coalesce(max(unfinalized_days),0)::integer
  into v_grni_docs,v_grni_oldest from erp.v_material_grni_aging;
  select count(*)::bigint,coalesce(sum(case when days_overdue>0 then outstanding_amount else 0 end),0)
  into v_ap_docs,v_ap_overdue from erp.v_supplier_ap_aging where outstanding_amount>0.005;

  select coalesce(sum(issue_count) filter(where severity='CRITICAL'),0)::bigint,
         coalesce(sum(issue_count) filter(where severity='WARNING'),0)::bigint
  into v_critical,v_warning from erp.run_v268_financial_report_checks();
  select count(*)::bigint into v_pending from erp.cost_recalc_queue
  where status in('PENDING','RUNNING') or(status='FAILED' and attempt_count<3);

  return jsonb_build_object(
    'basis',jsonb_build_object(
      'period_from',p_from,'period_to',p_to,'balance_sheet_as_of',p_as_of,
      'supplier_exposure_basis','CURRENT_OPERATIONAL_STATE'
    ),
    'data_confidence',jsonb_build_object(
      'status',case when v_critical>0 then 'BLOCKED'
                    when v_pending>0 then 'RECALC_PENDING' else 'READY' end,
      'critical_issue_count',v_critical,'warning_issue_count',v_warning,
      'pending_cost_recalc_count',v_pending
    ),
    'financial_position',jsonb_build_object(
      'assets',round(v_assets,2),'cash',round(v_cash,2),'customer_ar',round(v_ar,2),
      'material_inventory',round(v_material,2),'wip_inventory',round(v_wip,2),'fg_inventory',round(v_fg,2),
      'liabilities',round(v_liabilities,2),'supplier_final_ap',round(v_ap,2),
      'grni_estimated_liability',round(v_grni,2),'recorded_equity',round(v_equity,2),
      'current_earnings',round(v_current_earnings,2),
      'liabilities_plus_equity',round(v_liabilities+v_equity+v_current_earnings,2),
      'balance_difference',round(v_assets-v_liabilities-v_equity-v_current_earnings,2)
    ),
    'performance',jsonb_build_object(
      'sales_revenue_gl',round(v_sales_revenue,2),'cogs_gl',round(v_cogs,2),
      'gross_profit',round(v_sales_revenue-v_cogs,2),
      'gross_margin_pct',case when abs(v_sales_revenue)>0.005 then round((v_sales_revenue-v_cogs)*100/v_sales_revenue,4) else null end,
      'other_income',round(v_other_income,2),'operating_and_other_expense',round(v_opex,2),
      'net_profit',round(v_net_profit,2),
      'net_margin_pct',case when abs(v_sales_revenue)>0.005 then round(v_net_profit*100/v_sales_revenue,4) else null end,
      'gross_sales_before_discount',round(v_gross_sales,2),'line_discounts',round(v_discounts,2),
      'posted_sales_returns',round(v_sales_returns,2),
      'operational_net_sales',round(v_gross_sales-v_discounts-v_sales_returns,2)
    ),
    'quality',jsonb_build_object(
      'qc_good_pcs',v_qc_good,'qc_bs_pcs',v_qc_bs,
      'qc_defect_rate_pct',case when v_qc_good+v_qc_bs>0 then round(v_qc_bs*100/(v_qc_good+v_qc_bs),4) else null end,
      'laundry_good_received_pcs',v_laundry_good,'laundry_bs_pcs',v_laundry_bs,
      'laundry_bs_rate_on_resolved_receipts_pct',case when v_laundry_good+v_laundry_bs>0 then round(v_laundry_bs*100/(v_laundry_good+v_laundry_bs),4) else null end,
      'laundry_stuck_pcs',v_laundry_stuck,'laundry_missing_pcs',v_laundry_missing
    ),
    'supplier_exposure',jsonb_build_object(
      'unfinalized_receipt_count',v_grni_docs,'oldest_unfinalized_days',v_grni_oldest,
      'open_final_ap_document_count',v_ap_docs,'overdue_final_ap_amount',round(v_ap_overdue,2)
    )
  );
end;
$$;

revoke all on function erp.run_v268_financial_report_checks() from public,anon;
revoke all on function erp.get_owner_financial_snapshot_v2(date,date,date) from public,anon;
grant execute on function erp.run_v268_financial_report_checks() to authenticated,service_role;
grant execute on function erp.get_owner_financial_snapshot_v2(date,date,date) to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.8',
  'Balanced SOFP current earnings, owner financial/performance/quality snapshot, report confidence and GL-subledger controls',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828094907','v2_6_8_owner_financial_truth_reporting',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828094907 v2_6_8_owner_financial_truth_reporting

-- BEGIN PLATFORM MIGRATION 20260828095008 v2_6_8a_financial_control_scope
-- ERP Garment v2.6.8a
-- Draft operational CRUD is intentionally allowed under RLS/status guards.
-- Direct ledger and supplier-invoice aggregate writes remain forbidden.

set lock_timeout='10s';
set statement_timeout='60s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_8a',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.8') then
    raise exception 'ERP Garment v2.6.8 is required before v2.6.8a';
  end if;
  if to_regprocedure('erp.run_v268_financial_report_checks_v268_raw()') is null then
    alter function erp.run_v268_financial_report_checks()
      rename to run_v268_financial_report_checks_v268_raw;
  end if;
end;
$$;

revoke all on function erp.run_v268_financial_report_checks_v268_raw() from public,anon,authenticated;
grant execute on function erp.run_v268_financial_report_checks_v268_raw() to service_role;

create or replace function erp.run_v268_financial_report_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language plpgsql stable security definer
set search_path=erp,public,pg_catalog,information_schema,pg_temp
as $$
begin
  perform erp.require_owner_admin();
  return query
  select r.check_name,r.severity,r.issue_count,r.details
  from erp.run_v268_financial_report_checks_v268_raw() r
  where r.check_name<>'V268_BROWSER_DIRECT_FINANCIAL_WRITE'

  union all
  select 'V268_BROWSER_DIRECT_LEDGER_OR_INVOICE_WRITE','CRITICAL',count(*)::bigint,
         'Browser roles must not directly mutate the ledger or supplier-invoice aggregate; operational DRAFT tables are protected separately by RLS and posted-state guards'
  from information_schema.role_table_grants g
  where g.table_schema='erp'
    and g.table_name in(
      'journal_entries','journal_lines','account_daily_balances',
      'material_supplier_invoices','material_supplier_invoice_lines'
    )
    and g.grantee in('PUBLIC','anon','authenticated')
    and g.privilege_type in('INSERT','UPDATE','DELETE');
end;
$$;

revoke all on function erp.run_v268_financial_report_checks() from public,anon;
grant execute on function erp.run_v268_financial_report_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.8a',
  'Scope browser direct-write control to ledger and supplier-invoice aggregate while preserving guarded DRAFT CRUD',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828095008','v2_6_8a_financial_control_scope',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828095008 v2_6_8a_financial_control_scope

-- BEGIN PLATFORM MIGRATION 20260828095633 v2_6_7c_compat_and_trigger_security
-- ERP Garment v2.6.7c
-- Fix the legacy final-invoice compatibility RPC alias and close default
-- PUBLIC EXECUTE on v2.6.7 trigger-only functions.

set lock_timeout='10s';
set statement_timeout='60s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_7c',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.7b') then
    raise exception 'ERP Garment v2.6.7b is required before v2.6.7c';
  end if;
end;
$$;

create or replace function erp.finalize_material_purchase_invoice_v2(
  p_payload jsonb,p_client_request_id uuid,p_expected_version bigint
)
returns jsonb
language plpgsql security definer
set search_path=erp,public,auth,extensions,pg_temp
as $$
declare
  v_hash text;v_cached jsonb;v_response jsonb;
  v_purchase uuid:=nullif(p_payload->>'purchase_id','')::uuid;
  ph erp.material_purchase_headers%rowtype;
  ih erp.material_supplier_invoices%rowtype;
  j jsonb;i erp.material_purchase_items%rowtype;
  v_qty numeric;v_remaining numeric;v_state text;
begin
  perform erp.require_owner_admin();
  if v_purchase is null then raise exception 'purchase_id is required'; end if;
  if nullif(btrim(p_payload->>'supplier_invoice_number'),'') is null then raise exception 'supplier_invoice_number is required'; end if;
  if nullif(p_payload->>'invoice_date','') is null then raise exception 'invoice_date is required'; end if;
  if nullif(btrim(p_payload->>'reason'),'') is null then raise exception 'reason is required'; end if;
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if coalesce(jsonb_typeof(p_payload->'lines'),'null')<>'array'
     or jsonb_array_length(p_payload->'lines')=0 then raise exception 'At least one final invoice line is required'; end if;

  v_hash:=erp._request_hash(jsonb_build_object('payload',p_payload,'expected_version',p_expected_version));
  v_cached:=erp._idempotency_begin('finalize_material_purchase_invoice_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',btrim(p_payload->>'reason'),true);

  select * into ph from erp.material_purchase_headers where id=v_purchase for update;
  if ph.id is null or ph.status<>'POSTED' then raise exception 'Purchase must be POSTED'; end if;
  if ph.row_version<>p_expected_version then raise exception 'STALE_VERSION expected %, current %',p_expected_version,ph.row_version; end if;
  if ph.supplier_id is null then raise exception 'Purchase supplier is required'; end if;

  insert into erp.material_supplier_invoices(
    invoice_number,supplier_id,invoice_date,received_at,due_date,notes,posting_reason,created_by
  ) values(
    btrim(p_payload->>'supplier_invoice_number'),ph.supplier_id,(p_payload->>'invoice_date')::date,
    coalesce(nullif(p_payload->>'received_at','')::timestamptz,clock_timestamp()),
    nullif(p_payload->>'due_date','')::date,nullif(btrim(p_payload->>'notes'),''),
    btrim(p_payload->>'reason'),erp.current_app_user_id()
  ) returning * into ih;

  for j in select value from jsonb_array_elements(p_payload->'lines') loop
    select * into i from erp.material_purchase_items
    where id=(j->>'purchase_item_id')::uuid and purchase_id=ph.id for update;
    if i.id is null then raise exception 'Final invoice line does not belong to purchase'; end if;
    v_remaining:=erp.material_purchase_invoice_capacity(i.id)-erp.material_purchase_posted_invoice_qty(i.id);
    v_qty:=coalesce(nullif(j->>'qty_invoiced','')::numeric,v_remaining);
    if v_qty<=0 then raise exception 'No unmatched quantity remains for purchase item %',i.id; end if;
    insert into erp.material_supplier_invoice_lines(
      invoice_id,purchase_item_id,qty_invoiced,unit_price,discount_amount,notes
    ) values(
      ih.id,i.id,v_qty,(j->>'final_unit_price')::numeric,
      coalesce(nullif(j->>'discount_amount','')::numeric,0),nullif(btrim(j->>'notes'),'')
    );
  end loop;

  perform erp.post_material_supplier_invoice(ih.id);
  select case when bool_and(mi.price_state='FINAL') then 'FINAL' else 'PARTIAL' end
  into v_state
  from erp.material_supplier_invoice_lines l
  join erp.material_purchase_items mi on mi.id=l.purchase_item_id
  where l.invoice_id=ih.id;
  select * into ph from erp.material_purchase_headers where id=ph.id;
  v_response:=jsonb_build_object(
    'purchase_id',ph.id,'correction_id',ih.id,'supplier_invoice_id',ih.id,
    'supplier_invoice_number',ih.invoice_number,'price_state',v_state,
    'row_version',ph.row_version
  );
  return erp._idempotency_complete('finalize_material_purchase_invoice_v2',p_client_request_id,v_response);
end;
$$;

revoke all on function
  erp.guard_direct_final_cost_correction_state(),
  erp.normalize_material_purchase_invoice_match_state(),
  erp.sync_direct_final_cost_correction_item_state(),
  erp.sync_material_purchase_grni_on_status(),
  erp.validate_material_supplier_invoice_line()
from public,anon,authenticated;

grant execute on function
  erp.guard_direct_final_cost_correction_state(),
  erp.normalize_material_purchase_invoice_match_state(),
  erp.sync_direct_final_cost_correction_item_state(),
  erp.sync_material_purchase_grni_on_status(),
  erp.validate_material_supplier_invoice_line()
to service_role;

revoke all on function erp.finalize_material_purchase_invoice_v2(jsonb,uuid,bigint) from public,anon;
grant execute on function erp.finalize_material_purchase_invoice_v2(jsonb,uuid,bigint) to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.7c',
  'Fix legacy invoice-finalization alias ambiguity and revoke PUBLIC EXECUTE from v2.6.7 trigger functions',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828095633','v2_6_7c_compat_and_trigger_security',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828095633 v2_6_7c_compat_and_trigger_security

-- BEGIN PLATFORM MIGRATION 20260828095901 v2_6_8b_internal_check_hygiene
-- ERP Garment v2.6.8b
-- Keep the pre-scope compatibility body private and outside run_* discovery so
-- automated integrity runners execute only the authoritative v2.6.8 check set.

set lock_timeout='10s';
set statement_timeout='60s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_8b',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.8a') then
    raise exception 'ERP Garment v2.6.8a is required before v2.6.8b';
  end if;
  if to_regprocedure('erp._v268_financial_report_checks_pre_scope()') is null
     and to_regprocedure('erp.run_v268_financial_report_checks_v268_raw()') is not null then
    alter function erp.run_v268_financial_report_checks_v268_raw()
      rename to _v268_financial_report_checks_pre_scope;
  end if;
end;
$$;

revoke all on function erp._v268_financial_report_checks_pre_scope() from public,anon,authenticated;
grant execute on function erp._v268_financial_report_checks_pre_scope() to service_role;

create or replace function erp.run_v268_financial_report_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language plpgsql stable security definer
set search_path=erp,public,pg_catalog,information_schema,pg_temp
as $$
begin
  perform erp.require_owner_admin();
  return query
  select r.check_name,r.severity,r.issue_count,r.details
  from erp._v268_financial_report_checks_pre_scope() r
  where r.check_name<>'V268_BROWSER_DIRECT_FINANCIAL_WRITE'

  union all
  select 'V268_BROWSER_DIRECT_LEDGER_OR_INVOICE_WRITE','CRITICAL',count(*)::bigint,
         'Browser roles must not directly mutate the ledger or supplier-invoice aggregate; operational DRAFT tables are protected separately by RLS and posted-state guards'
  from information_schema.role_table_grants g
  where g.table_schema='erp'
    and g.table_name in(
      'journal_entries','journal_lines','account_daily_balances',
      'material_supplier_invoices','material_supplier_invoice_lines'
    )
    and g.grantee in('PUBLIC','anon','authenticated')
    and g.privilege_type in('INSERT','UPDATE','DELETE');
end;
$$;

revoke all on function erp.run_v268_financial_report_checks() from public,anon;
grant execute on function erp.run_v268_financial_report_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.8b',
  'Move obsolete pre-scope control body outside run-check discovery and retain one authoritative v2.6.8 suite',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828095901','v2_6_8b_internal_check_hygiene',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828095901 v2_6_8b_internal_check_hygiene

-- BEGIN PLATFORM MIGRATION 20260828100105 v2_6_8c_control_dedup
-- ERP Garment v2.6.8c
-- Deduplicate the direct-write control across upgraded and fresh-install paths.

set lock_timeout='10s';
set statement_timeout='60s';
select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_8c',0));

do $$
begin
  if not exists(select 1 from erp.schema_migrations where version='v2.6.8b') then
    raise exception 'ERP Garment v2.6.8b is required before v2.6.8c';
  end if;
end;
$$;

create or replace function erp.run_v268_financial_report_checks()
returns table(check_name text,severity text,issue_count bigint,details text)
language plpgsql stable security definer
set search_path=erp,public,pg_catalog,information_schema,pg_temp
as $$
begin
  perform erp.require_owner_admin();
  return query
  select r.check_name,r.severity,r.issue_count,r.details
  from erp._v268_financial_report_checks_pre_scope() r
  where r.check_name not in(
    'V268_BROWSER_DIRECT_FINANCIAL_WRITE',
    'V268_BROWSER_DIRECT_LEDGER_OR_INVOICE_WRITE'
  )

  union all
  select 'V268_BROWSER_DIRECT_LEDGER_OR_INVOICE_WRITE','CRITICAL',count(*)::bigint,
         'Browser roles must not directly mutate the ledger or supplier-invoice aggregate; operational DRAFT tables are protected separately by RLS and posted-state guards'
  from information_schema.role_table_grants g
  where g.table_schema='erp'
    and g.table_name in(
      'journal_entries','journal_lines','account_daily_balances',
      'material_supplier_invoices','material_supplier_invoice_lines'
    )
    and g.grantee in('PUBLIC','anon','authenticated')
    and g.privilege_type in('INSERT','UPDATE','DELETE');
end;
$$;

revoke all on function erp.run_v268_financial_report_checks() from public,anon;
grant execute on function erp.run_v268_financial_report_checks() to authenticated,service_role;

insert into erp.schema_migrations(version,description,installed_at)
values(
  'v2.6.8c',
  'Return one authoritative direct ledger/invoice write control on both upgrade and fresh-install paths',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828100105','v2_6_8c_control_dedup',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828100105 v2_6_8c_control_dedup

-- BEGIN PLATFORM MIGRATION 20260828153334 erp_v2_6_9_cutting_correction_v2
-- ERP Garment v2.6.9
-- Safe Koreksi Potongan contract: complete downstream quantity floor,
-- idempotent/optimistically locked posting and reversal, plus browser read models.

set lock_timeout = '10s';
set statement_timeout = '180s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_9', 0));

do $$
begin
  if not exists (
    select 1 from erp.schema_migrations where version = 'v2.6.8c'
  ) then
    raise exception 'ERP Garment v2.6.8c is required before v2.6.9';
  end if;
end;
$$;

-- A quantity correction may not reduce a Potongan below any physical evidence
-- already recorded after cutting. Work completion is component-based, so the
-- floor is the largest cumulative component quantity rather than the sum of
-- all BOM components (which would count the same garment more than once).
create or replace function erp.cutting_group_downstream_committed_qty(
  p_cutting_group_id uuid
)
returns bigint
language sql
stable
security definer
set search_path = erp, public, pg_temp
as $$
  select greatest(
    coalesce((
      select max(s.stage_qty)
      from (
        select w.stage_to, sum(coalesce(w.qty_pcs, 0))::bigint as stage_qty
        from erp.wip_stage_events w
        where w.cutting_group_id = p_cutting_group_id
          and w.stage_to in ('SEWING','LAUNDRY','QC','FINISHED','ON_HOLD')
        group by w.stage_to
      ) s
    ), 0),
    coalesce((
      select max(s.component_qty)
      from (
        select l.po_component_snapshot_id,
               sum(l.qty_completed)::bigint as component_qty
        from erp.work_completion_events h
        join erp.work_completion_lines l on l.completion_id = h.id
        where h.cutting_group_id = p_cutting_group_id
          and h.status = 'POSTED'
        group by l.po_component_snapshot_id
      ) s
    ), 0),
    coalesce((
      select sum(ldl.qty_sent_pcs)::bigint
      from erp.laundry_delivery_lines ldl
      join erp.laundry_deliveries ld on ld.id = ldl.delivery_id
      where ldl.cutting_group_id = p_cutting_group_id
        and ld.status not in ('DRAFT','REVERSED')
    ), 0),
    coalesce((
      select sum(qi.qty_good_pcs + qi.qty_bs_pcs)::bigint
      from erp.qc_inspection_items qi
      join erp.qc_inspections qh on qh.id = qi.inspection_id
      where qi.cutting_group_id = p_cutting_group_id
        and qh.status = 'POSTED'
    ), 0),
    coalesce((
      select sum(fl.initial_qty_pcs)::bigint
      from erp.fg_lots fl
      where fl.cutting_group_id = p_cutting_group_id
        and fl.lot_origin = 'PRODUCTION'
    ), 0),
    coalesce((
      select sum(b.qty_pcs)::bigint
      from erp.bs_cases b
      where b.cutting_group_id = p_cutting_group_id
        and b.status <> 'CANCELLED'
    ), 0)
  );
$$;

revoke all on function erp.cutting_group_downstream_committed_qty(uuid)
  from public, anon;
grant execute on function erp.cutting_group_downstream_committed_qty(uuid)
  to authenticated, service_role;

create or replace view erp.v_cutting_qty_correction_batch_browser
with (security_invoker = true)
as
select
  b.id as cutting_batch_id,
  b.batch_number,
  b.cut_at,
  b.status as batch_status,
  b.row_version,
  b.po_id,
  po.po_number,
  po.status as po_status,
  po.current_stage,
  pm.model_code,
  pm.model_name,
  coalesce(g.group_count, 0)::bigint as group_count,
  coalesce(g.original_pcs, 0)::bigint as original_pcs,
  coalesce(g.adjustment_pcs, 0)::bigint as adjustment_pcs,
  coalesce(g.effective_pcs, 0)::bigint as effective_pcs,
  coalesce(g.downstream_committed_pcs, 0)::bigint as downstream_committed_pcs,
  coalesce(g.presewing_editable_group_count, 0)::bigint as presewing_editable_group_count,
  coalesce(c.correction_count, 0)::bigint as correction_count,
  c.last_correction_at,
  coalesce(c.correction_count, 0) > 0 as has_correction_history
from erp.cutting_batches b
join erp.production_orders po on po.id = b.po_id
join erp.product_models pm on pm.id = po.model_id
left join lateral (
  select
    count(*)::bigint as group_count,
    coalesce(sum(q.original_pcs), 0)::bigint as original_pcs,
    coalesce(sum(q.adjustment_pcs), 0)::bigint as adjustment_pcs,
    coalesce(sum(q.effective_pcs), 0)::bigint as effective_pcs,
    coalesce(sum(erp.cutting_group_downstream_committed_qty(cg.id)), 0)::bigint
      as downstream_committed_pcs,
    count(*) filter (
      where erp.is_cutting_group_presewing_reversible(cg.id)
    )::bigint as presewing_editable_group_count
  from erp.cutting_groups cg
  left join erp.v_cutting_group_quantity_detail q
    on q.cutting_group_id = cg.id
  where cg.cutting_batch_id = b.id
) g on true
left join lateral (
  select count(*)::bigint as correction_count,
         max(cq.physical_at) as last_correction_at
  from erp.cutting_qty_corrections cq
  where cq.cutting_batch_id = b.id
) c on true;

create or replace view erp.v_cutting_qty_correction_history
with (security_invoker = true)
as
select
  c.id as correction_id,
  c.correction_number,
  c.cutting_batch_id,
  b.batch_number,
  b.row_version as batch_row_version,
  b.po_id,
  po.po_number,
  pm.model_code,
  pm.model_name,
  c.correction_type,
  c.reason_code,
  c.reason,
  c.physical_at,
  c.created_at,
  c.posted_by,
  u.full_name as posted_by_name,
  coalesce(l.line_count, 0)::bigint as line_count,
  coalesce(l.net_delta_pcs, 0)::bigint as net_delta_pcs,
  c.reversal_of_id,
  src.correction_number as reversal_of_number,
  rv.id as reversed_by_id,
  rv.correction_number as reversed_by_number,
  rv.physical_at as reversed_at,
  case
    when c.correction_type = 'REVERSAL' then 'REVERSAL'
    when rv.id is not null then 'REVERSED'
    else 'POSTED'
  end as correction_status
from erp.cutting_qty_corrections c
join erp.cutting_batches b on b.id = c.cutting_batch_id
join erp.production_orders po on po.id = b.po_id
join erp.product_models pm on pm.id = po.model_id
left join erp.app_users u on u.id = c.posted_by
left join erp.cutting_qty_corrections src on src.id = c.reversal_of_id
left join erp.cutting_qty_corrections rv on rv.reversal_of_id = c.id
left join lateral (
  select count(*)::bigint as line_count,
         coalesce(sum(cl.qty_delta_pcs), 0)::bigint as net_delta_pcs
  from erp.cutting_qty_correction_lines cl
  where cl.correction_id = c.id
) l on true;

revoke all on erp.v_cutting_qty_correction_batch_browser
  from public, anon;
revoke all on erp.v_cutting_qty_correction_history
  from public, anon;
grant select on erp.v_cutting_qty_correction_batch_browser
  to authenticated, service_role;
grant select on erp.v_cutting_qty_correction_history
  to authenticated, service_role;

create or replace function erp.post_cutting_qty_correction_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_batch erp.cutting_batches%rowtype;
  v_batch_id uuid := nullif(p_payload->>'cutting_batch_id', '')::uuid;
  v_type text := upper(nullif(btrim(p_payload->>'correction_type'), ''));
  v_reason_code text := upper(nullif(btrim(p_payload->>'reason_code'), ''));
  v_reason text := nullif(btrim(p_payload->>'reason'), '');
  v_lines jsonb := p_payload->'lines';
  v_physical_at timestamptz;
  v_correction_id uuid;
  v_correction_number text;
  v_net_delta bigint;
  v_totals record;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if v_batch_id is null then raise exception 'cutting_batch_id is required'; end if;
  if v_type is null then raise exception 'correction_type is required'; end if;
  if v_reason_code is null then raise exception 'reason_code is required'; end if;
  if v_reason is null then raise exception 'Correction reason is required'; end if;
  if jsonb_typeof(v_lines) <> 'array' or jsonb_array_length(v_lines) = 0 then
    raise exception 'Correction requires at least one line';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'payload', p_payload,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(
    'post_cutting_qty_correction_v2', p_client_request_id, v_hash
  );
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  select * into v_batch
  from erp.cutting_batches
  where id = v_batch_id
  for update;
  if v_batch.id is null then raise exception 'Cutting batch not found'; end if;
  if v_batch.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',
      p_expected_version, v_batch.row_version;
  end if;

  v_physical_at := coalesce(
    nullif(p_payload->>'physical_at', '')::timestamptz,
    clock_timestamp()
  );
  if v_physical_at > clock_timestamp() + interval '5 minutes' then
    raise exception 'Tanggal/jam Koreksi Potongan berada di masa depan';
  end if;
  v_correction_id := erp._post_cutting_qty_correction(
    v_batch_id, v_type, v_reason_code, v_reason,
    v_lines, v_physical_at, null
  );

  -- Touching the aggregate root makes every successful correction invalidate
  -- stale browser drafts through the existing row-version trigger.
  update erp.cutting_batches
  set updated_at = clock_timestamp()
  where id = v_batch_id
  returning * into v_batch;

  select c.correction_number, coalesce(sum(l.qty_delta_pcs), 0)::bigint
  into v_correction_number, v_net_delta
  from erp.cutting_qty_corrections c
  join erp.cutting_qty_correction_lines l on l.correction_id = c.id
  where c.id = v_correction_id
  group by c.correction_number;

  select original_pcs, adjustment_pcs, effective_pcs
  into v_totals
  from erp.v_cutting_batch_totals
  where cutting_batch_id = v_batch_id;

  v_response := jsonb_build_object(
    'correction_id', v_correction_id,
    'correction_number', v_correction_number,
    'cutting_batch_id', v_batch_id,
    'correction_type', v_type,
    'net_delta_pcs', v_net_delta,
    'original_pcs', coalesce(v_totals.original_pcs, 0),
    'adjustment_pcs', coalesce(v_totals.adjustment_pcs, 0),
    'effective_pcs', coalesce(v_totals.effective_pcs, 0),
    'row_version', v_batch.row_version,
    'status', 'POSTED'
  );
  return erp._idempotency_complete(
    'post_cutting_qty_correction_v2', p_client_request_id, v_response
  );
end;
$$;

create or replace function erp.reverse_cutting_qty_correction_v2(
  p_correction_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_reason text := nullif(btrim(p_reason), '');
  v_source erp.cutting_qty_corrections%rowtype;
  v_batch erp.cutting_batches%rowtype;
  v_reversal_id uuid;
  v_reversal_number text;
  v_net_delta bigint;
  v_totals record;
begin
  perform erp.require_owner_admin();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  if p_correction_id is null then raise exception 'correction_id is required'; end if;
  if v_reason is null then raise exception 'Reversal reason is required'; end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'correction_id', p_correction_id,
    'reason', v_reason,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(
    'reverse_cutting_qty_correction_v2', p_client_request_id, v_hash
  );
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason', v_reason, true);

  select * into v_source
  from erp.cutting_qty_corrections
  where id = p_correction_id;
  if v_source.id is null then raise exception 'Correction not found'; end if;
  if v_source.correction_type = 'REVERSAL' then
    raise exception 'A REVERSAL cannot be reversed; post a new reasoned correction instead';
  end if;

  select * into v_batch
  from erp.cutting_batches
  where id = v_source.cutting_batch_id
  for update;
  if v_batch.id is null then raise exception 'Cutting batch not found'; end if;
  if v_batch.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',
      p_expected_version, v_batch.row_version;
  end if;

  select * into v_source
  from erp.cutting_qty_corrections
  where id = p_correction_id
  for update;
  if exists (
    select 1 from erp.cutting_qty_corrections
    where reversal_of_id = p_correction_id
  ) then
    raise exception 'Correction has already been reversed';
  end if;

  v_reversal_id := erp.reverse_cutting_qty_correction(
    p_correction_id, v_reason
  );

  update erp.cutting_batches
  set updated_at = clock_timestamp()
  where id = v_source.cutting_batch_id
  returning * into v_batch;

  select c.correction_number, coalesce(sum(l.qty_delta_pcs), 0)::bigint
  into v_reversal_number, v_net_delta
  from erp.cutting_qty_corrections c
  join erp.cutting_qty_correction_lines l on l.correction_id = c.id
  where c.id = v_reversal_id
  group by c.correction_number;

  select original_pcs, adjustment_pcs, effective_pcs
  into v_totals
  from erp.v_cutting_batch_totals
  where cutting_batch_id = v_source.cutting_batch_id;

  v_response := jsonb_build_object(
    'correction_id', p_correction_id,
    'reversal_id', v_reversal_id,
    'reversal_number', v_reversal_number,
    'cutting_batch_id', v_source.cutting_batch_id,
    'net_delta_pcs', v_net_delta,
    'original_pcs', coalesce(v_totals.original_pcs, 0),
    'adjustment_pcs', coalesce(v_totals.adjustment_pcs, 0),
    'effective_pcs', coalesce(v_totals.effective_pcs, 0),
    'row_version', v_batch.row_version,
    'status', 'REVERSED'
  );
  return erp._idempotency_complete(
    'reverse_cutting_qty_correction_v2', p_client_request_id, v_response
  );
end;
$$;

-- Browser callers must use the guarded v2 contract. Legacy entry points remain
-- available only to service-role compatibility jobs.
revoke all on function erp.post_cutting_qty_correction(
  uuid, text, text, text, jsonb, timestamptz
) from public, anon, authenticated;
revoke all on function erp.reverse_cutting_qty_correction(uuid, text)
  from public, anon, authenticated;
grant execute on function erp.post_cutting_qty_correction(
  uuid, text, text, text, jsonb, timestamptz
) to service_role;
grant execute on function erp.reverse_cutting_qty_correction(uuid, text)
  to service_role;

revoke all on function erp.post_cutting_qty_correction_v2(jsonb, uuid, bigint)
  from public, anon;
revoke all on function erp.reverse_cutting_qty_correction_v2(
  uuid, text, uuid, bigint
) from public, anon;
grant execute on function erp.post_cutting_qty_correction_v2(jsonb, uuid, bigint)
  to authenticated, service_role;
grant execute on function erp.reverse_cutting_qty_correction_v2(
  uuid, text, uuid, bigint
) to authenticated, service_role;

create or replace function erp.run_v269_cutting_correction_integrity_checks()
returns table(
  check_name text,
  severity text,
  issue_count bigint,
  details text
)
language plpgsql
stable
security definer
set search_path = erp, public, pg_catalog, information_schema, pg_temp
as $$
begin
  perform erp.require_owner_admin();

  return query
  select
    'V269_EFFECTIVE_QTY_NEGATIVE', 'CRITICAL', count(*)::bigint,
    'Effective Potongan quantity may never be negative'
  from erp.v_cutting_group_quantity_detail q
  where q.effective_pcs < 0

  union all
  select
    'V269_EFFECTIVE_BELOW_DOWNSTREAM', 'CRITICAL', count(*)::bigint,
    'Effective Potongan quantity must cover sewing/WIP/laundry/QC/FG/BS evidence'
  from erp.v_cutting_group_quantity_detail q
  where q.effective_pcs < erp.cutting_group_downstream_committed_qty(q.cutting_group_id)

  union all
  select
    'V269_CORRECTION_WITHOUT_LINES', 'CRITICAL', count(*)::bigint,
    'Every posted quantity correction must retain at least one immutable line'
  from erp.cutting_qty_corrections c
  where not exists (
    select 1 from erp.cutting_qty_correction_lines l
    where l.correction_id = c.id
  )

  union all
  select
    'V269_REVERSAL_LINE_MISMATCH', 'CRITICAL', count(*)::bigint,
    'Every reversal must exactly negate its source by Potongan and size slot'
  from (
    select src.id
    from erp.cutting_qty_corrections src
    join erp.cutting_qty_corrections rv on rv.reversal_of_id = src.id
    where exists (
      select 1
      from (
        select
          coalesce(a.cutting_group_id, b.cutting_group_id) as cutting_group_id,
          coalesce(a.size_slot_id, b.size_slot_id) as size_slot_id,
          coalesce(a.qty, 0) + coalesce(b.qty, 0) as net_qty
        from (
          select cutting_group_id, size_slot_id, sum(qty_delta_pcs)::bigint as qty
          from erp.cutting_qty_correction_lines
          where correction_id = src.id
          group by cutting_group_id, size_slot_id
        ) a
        full join (
          select cutting_group_id, size_slot_id, sum(qty_delta_pcs)::bigint as qty
          from erp.cutting_qty_correction_lines
          where correction_id = rv.id
          group by cutting_group_id, size_slot_id
        ) b
          on b.cutting_group_id = a.cutting_group_id
         and b.size_slot_id is not distinct from a.size_slot_id
      ) mismatch
      where mismatch.net_qty <> 0
    )
  ) bad

  union all
  select
    'V269_FUTURE_PHYSICAL_TIME', 'ERROR', count(*)::bigint,
    'Koreksi Potongan physical_at may not be more than five minutes in the future'
  from erp.cutting_qty_corrections c
  where c.physical_at > clock_timestamp() + interval '5 minutes'

  union all
  select
    'V269_LEGACY_RPC_BROWSER_EXECUTE', 'CRITICAL', count(*)::bigint,
    'Browser roles must use idempotent and optimistically locked v2 correction RPCs'
  from information_schema.routine_privileges p
  where p.routine_schema = 'erp'
    and p.routine_name in (
      'post_cutting_qty_correction', 'reverse_cutting_qty_correction'
    )
    and p.grantee in ('PUBLIC','anon','authenticated')
    and p.privilege_type = 'EXECUTE'

  union all
  select
    'V269_DIRECT_CORRECTION_WRITE', 'CRITICAL', count(*)::bigint,
    'Browser roles must not directly mutate append-only cutting correction tables'
  from information_schema.role_table_grants g
  where g.table_schema = 'erp'
    and g.table_name in (
      'cutting_qty_corrections', 'cutting_qty_correction_lines'
    )
    and g.grantee in ('PUBLIC','anon','authenticated')
    and g.privilege_type in ('INSERT','UPDATE','DELETE');
end;
$$;

revoke all on function erp.run_v269_cutting_correction_integrity_checks()
  from public, anon;
grant execute on function erp.run_v269_cutting_correction_integrity_checks()
  to authenticated, service_role;

comment on function erp.post_cutting_qty_correction_v2(jsonb, uuid, bigint) is
  'Reasoned/idempotent/optimistically locked Koreksi Potongan posting; HPP rebuild remains atomic in the legacy domain core.';
comment on function erp.reverse_cutting_qty_correction_v2(uuid, text, uuid, bigint) is
  'OWNER/ADMIN append-only reversal of Koreksi Potongan with idempotency and aggregate optimistic locking.';
comment on view erp.v_cutting_qty_correction_batch_browser is
  'Browse-first Koreksi Potongan workspace with original, adjustment, effective, and downstream floor quantities.';
comment on view erp.v_cutting_qty_correction_history is
  'Immutable Koreksi Potongan and reversal history for the browser workspace.';

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.9',
  'Safe cutting correction v2, sewing-aware quantity floor, immutable history read models, and legacy RPC closure',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828153334','erp_v2_6_9_cutting_correction_v2',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828153334 erp_v2_6_9_cutting_correction_v2

-- BEGIN PLATFORM MIGRATION 20260828153601 erp_v2_6_9a_cutting_correction_indexes
-- ERP Garment v2.6.9a
-- Targeted indexes for the sewing-aware Koreksi Potongan quantity floor.

set lock_timeout = '10s';
set statement_timeout = '180s';

select pg_advisory_xact_lock(hashtextextended('erp_garment_v2_6_9a', 0));

do $$
begin
  if not exists (
    select 1 from erp.schema_migrations where version = 'v2.6.9'
  ) then
    raise exception 'ERP Garment v2.6.9 is required before v2.6.9a';
  end if;
end;
$$;

create index if not exists idx_wip_stage_events_cutting_group_stage
  on erp.wip_stage_events(cutting_group_id, stage_to)
  include (qty_pcs)
  where cutting_group_id is not null;

create index if not exists idx_work_completion_events_cutting_group_status
  on erp.work_completion_events(cutting_group_id, status, id)
  where cutting_group_id is not null;

create index if not exists idx_qc_inspection_items_cutting_group_inspection
  on erp.qc_inspection_items(cutting_group_id, inspection_id)
  include (qty_good_pcs, qty_bs_pcs)
  where cutting_group_id is not null;

create index if not exists idx_bs_cases_cutting_group_status
  on erp.bs_cases(cutting_group_id, status)
  include (qty_pcs)
  where cutting_group_id is not null;

create or replace function erp.run_v269a_cutting_correction_performance_checks()
returns table(
  check_name text,
  severity text,
  issue_count bigint,
  details text
)
language plpgsql
stable
security definer
set search_path = erp, public, pg_catalog, pg_temp
as $$
begin
  perform erp.require_owner_admin();
  return query
  select
    'V269A_REQUIRED_INDEX_MISSING', 'ERROR', count(*)::bigint,
    'Koreksi Potongan downstream floor requires four cutting-group lookup indexes'
  from unnest(array[
    'erp.idx_wip_stage_events_cutting_group_stage',
    'erp.idx_work_completion_events_cutting_group_status',
    'erp.idx_qc_inspection_items_cutting_group_inspection',
    'erp.idx_bs_cases_cutting_group_status'
  ]) expected(index_name)
  where to_regclass(expected.index_name) is null;
end;
$$;

revoke all on function erp.run_v269a_cutting_correction_performance_checks()
  from public, anon;
grant execute on function erp.run_v269a_cutting_correction_performance_checks()
  to authenticated, service_role;

insert into erp.schema_migrations(version, description, installed_at)
values (
  'v2.6.9a',
  'Targeted downstream indexes for the sewing-aware cutting correction quantity floor',
  now()
);
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260828153601','erp_v2_6_9a_cutting_correction_indexes',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260828153601 erp_v2_6_9a_cutting_correction_indexes

-- BEGIN PLATFORM MIGRATION 20260829185830 erp_v2_6_10_fg_partial_completion
-- ERP Garment v2.6.10
-- Partial Finished Goods completion through immutable QC postings.
--
-- Contract:
--   * every partial completion is its own POSTED QC document;
--   * GOOD creates its own FG lot, stock movement, HPP version, and reimbursement snapshot;
--   * retrying the same client_request_id returns the original response;
--   * stale browser drafts fail through cutting_groups.row_version;
--   * cumulative GOOD + BS cannot exceed effective Potongan quantity;
--   * a PO cannot become FINISHED while any Potongan source remains unaccounted.

create or replace view erp.v_fg_partial_completion_progress
with (security_invoker = true)
as
with qc as (
  select
    i.cutting_group_id,
    coalesce(sum(i.qty_good_pcs), 0)::bigint as qc_good_qty_pcs,
    coalesce(sum(i.qty_bs_pcs), 0)::bigint as qc_bs_qty_pcs,
    coalesce(sum(i.qty_good_pcs + i.qty_bs_pcs), 0)::bigint as qc_accounted_qty_pcs,
    coalesce(sum(i.qty_good_pcs + i.qty_bs_pcs)
      filter (where i.source_laundry_receipt_line_id is null), 0)::bigint as direct_qc_accounted_qty_pcs,
    count(distinct q.id)::bigint as completion_count,
    max(q.physical_at) as last_completion_at
  from erp.qc_inspection_items i
  join erp.qc_inspections q on q.id = i.inspection_id
  where q.status = 'POSTED'
  group by i.cutting_group_id
), laundry as (
  select
    l.cutting_group_id,
    coalesce(sum(l.qty_sent_pcs), 0)::bigint as laundry_sent_qty_pcs
  from erp.laundry_delivery_lines l
  join erp.laundry_deliveries d on d.id = l.delivery_id
  where d.status not in ('DRAFT', 'REVERSED')
  group by l.cutting_group_id
)
select
  g.id as cutting_group_id,
  g.po_id,
  g.group_number,
  g.row_version,
  po.status as po_status,
  coalesce(t.total_pcs, 0)::bigint as effective_qty_pcs,
  coalesce(q.qc_good_qty_pcs, 0)::bigint as qc_good_qty_pcs,
  coalesce(q.qc_bs_qty_pcs, 0)::bigint as qc_bs_qty_pcs,
  coalesce(q.qc_accounted_qty_pcs, 0)::bigint as qc_accounted_qty_pcs,
  greatest(coalesce(t.total_pcs, 0) - coalesce(q.qc_accounted_qty_pcs, 0), 0)::bigint as remaining_qc_qty_pcs,
  coalesce(q.direct_qc_accounted_qty_pcs, 0)::bigint as direct_qc_accounted_qty_pcs,
  coalesce(l.laundry_sent_qty_pcs, 0)::bigint as laundry_sent_qty_pcs,
  (coalesce(q.direct_qc_accounted_qty_pcs, 0) + coalesce(l.laundry_sent_qty_pcs, 0))::bigint as source_accounted_qty_pcs,
  greatest(
    coalesce(t.total_pcs, 0)
      - coalesce(q.direct_qc_accounted_qty_pcs, 0)
      - coalesce(l.laundry_sent_qty_pcs, 0),
    0
  )::bigint as remaining_source_qty_pcs,
  coalesce(q.completion_count, 0)::bigint as completion_count,
  q.last_completion_at,
  case
    when po.status = 'FINISHED' then 'FINISHED'
    when coalesce(q.qc_accounted_qty_pcs, 0) = 0 then 'OPEN'
    when coalesce(q.qc_accounted_qty_pcs, 0) < coalesce(t.total_pcs, 0) then 'PARTIAL'
    else 'QC_COMPLETE'
  end::text as completion_status
from erp.cutting_groups g
join erp.production_orders po on po.id = g.po_id
left join erp.v_cutting_group_totals t on t.cutting_group_id = g.id
left join qc q on q.cutting_group_id = g.id
left join laundry l on l.cutting_group_id = g.id;

comment on view erp.v_fg_partial_completion_progress is
  'Authoritative cumulative Finished Goods/QC progress per Potongan. PARTIAL is a posted fact, not an editable document status.';

create or replace function erp.guard_qc_laundry_source_matches_group()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
declare
  v_source_group_id uuid;
begin
  if new.source_laundry_receipt_line_id is null then
    return new;
  end if;

  select dl.cutting_group_id
  into v_source_group_id
  from erp.laundry_receipt_lines rl
  join erp.laundry_delivery_lines dl on dl.id = rl.delivery_line_id
  where rl.id = new.source_laundry_receipt_line_id;

  if v_source_group_id is null then
    raise exception 'QC laundry receipt source was not found';
  end if;
  if new.cutting_group_id is null or v_source_group_id is distinct from new.cutting_group_id then
    raise exception 'QC laundry source belongs to a different Potongan';
  end if;
  return new;
end;
$function$;

drop trigger if exists trg_qc_laundry_source_matches_group on erp.qc_inspection_items;
create trigger trg_qc_laundry_source_matches_group
before insert or update of cutting_group_id, source_laundry_receipt_line_id
on erp.qc_inspection_items
for each row execute function erp.guard_qc_laundry_source_matches_group();

create or replace function erp.guard_finished_po_source_accounting()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
declare
  r record;
begin
  if new.status = 'FINISHED' and old.status is distinct from 'FINISHED' then
    select
      p.cutting_group_id,
      p.group_number,
      p.effective_qty_pcs,
      p.source_accounted_qty_pcs,
      p.remaining_source_qty_pcs
    into r
    from erp.v_fg_partial_completion_progress p
    where p.po_id = new.id
      and p.effective_qty_pcs > 0
      and p.source_accounted_qty_pcs is distinct from p.effective_qty_pcs
    order by p.group_number, p.cutting_group_id
    limit 1;

    if found then
      raise exception
        'PO belum boleh FINISHED. Potongan % baru terjelaskan % dari % pcs; sisa sumber % pcs.',
        r.group_number,
        r.source_accounted_qty_pcs,
        r.effective_qty_pcs,
        r.remaining_source_qty_pcs;
    end if;
  end if;
  return new;
end;
$function$;

drop trigger if exists trg_guard_finished_po_source_accounting on erp.production_orders;
create trigger trg_guard_finished_po_source_accounting
before update of status on erp.production_orders
for each row execute function erp.guard_finished_po_source_accounting();

create or replace function erp.get_fg_partial_completion_context(p_cutting_group_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
declare
  v_group erp.cutting_groups%rowtype;
  v_progress jsonb;
  v_sizes jsonb;
  v_unassigned_adjustment bigint;
begin
  perform erp.require_internal();

  select * into v_group
  from erp.cutting_groups
  where id = p_cutting_group_id;
  if v_group.id is null then
    raise exception 'Potongan not found';
  end if;

  select to_jsonb(p) into v_progress
  from erp.v_fg_partial_completion_progress p
  where p.cutting_group_id = v_group.id;

  with original as (
    select s.size_id, sum(y.qty_pcs)::bigint as qty_pcs
    from erp.cutting_group_size_slots s
    left join erp.cutting_roll_yields y on y.size_slot_id = s.id
    where s.cutting_group_id = v_group.id
    group by s.size_id
  ), adjustment as (
    select s.size_id, sum(l.qty_delta_pcs)::bigint as qty_pcs
    from erp.cutting_qty_correction_lines l
    join erp.cutting_group_size_slots s on s.id = l.size_slot_id
    where l.cutting_group_id = v_group.id
    group by s.size_id
  ), posted as (
    select pr.size_id,
      sum(i.qty_good_pcs)::bigint as good_qty_pcs,
      sum(i.qty_bs_pcs)::bigint as bs_qty_pcs
    from erp.qc_inspection_items i
    join erp.qc_inspections q on q.id = i.inspection_id and q.status = 'POSTED'
    join erp.products pr on pr.id = i.final_product_id
    where i.cutting_group_id = v_group.id
    group by pr.size_id
  ), size_ids as (
    select size_id from original
    union select size_id from adjustment
    union select size_id from posted
  )
  select coalesce(jsonb_agg(jsonb_build_object(
    'size_id', z.size_id,
    'size_code', sz.size_code,
    'target_qty_pcs', coalesce(o.qty_pcs, 0) + coalesce(a.qty_pcs, 0),
    'good_qty_pcs', coalesce(p.good_qty_pcs, 0),
    'bs_qty_pcs', coalesce(p.bs_qty_pcs, 0),
    'remaining_qty_pcs', greatest(
      coalesce(o.qty_pcs, 0) + coalesce(a.qty_pcs, 0)
        - coalesce(p.good_qty_pcs, 0) - coalesce(p.bs_qty_pcs, 0),
      0
    ),
    'suggested_product_id', (
      select pr.id
      from erp.products pr
      join erp.production_orders po on po.model_id = pr.model_id
      where po.id = v_group.po_id
        and pr.size_id = z.size_id
        and pr.is_active = true
        and pr.effective_from <= clock_timestamp()
        and (pr.effective_to is null or pr.effective_to > clock_timestamp())
      order by pr.effective_from desc, pr.created_at desc, pr.id desc
      limit 1
    )
  ) order by sz.sort_order, sz.size_code), '[]'::jsonb)
  into v_sizes
  from size_ids z
  join erp.sizes sz on sz.id = z.size_id
  left join original o on o.size_id = z.size_id
  left join adjustment a on a.size_id = z.size_id
  left join posted p on p.size_id = z.size_id;

  select coalesce(sum(l.qty_delta_pcs), 0)::bigint
  into v_unassigned_adjustment
  from erp.cutting_qty_correction_lines l
  where l.cutting_group_id = v_group.id
    and l.size_slot_id is null;

  return jsonb_build_object(
    'cutting_group_id', v_group.id,
    'po_id', v_group.po_id,
    'group_number', v_group.group_number,
    'row_version', v_group.row_version,
    'progress', coalesce(v_progress, '{}'::jsonb),
    'sizes', coalesce(v_sizes, '[]'::jsonb),
    'unassigned_adjustment_qty_pcs', v_unassigned_adjustment
  );
end;
$function$;

create or replace function erp.post_fg_partial_completion_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'post_fg_partial_completion_v2';
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_group erp.cutting_groups%rowtype;
  v_po_status text;
  v_group_id uuid := nullif(p_payload->>'cutting_group_id', '')::uuid;
  v_destination_location_id uuid := nullif(p_payload->>'destination_location_id', '')::uuid;
  v_physical_at timestamptz := coalesce(
    nullif(p_payload->>'physical_at', '')::timestamptz,
    clock_timestamp()
  );
  v_reason text := nullif(btrim(p_payload->>'reason'), '');
  v_lines jsonb := p_payload->'lines';
  v_qc_id uuid := gen_random_uuid();
  v_inspection_number text;
  v_total_qty bigint;
  v_good_qty bigint;
  v_bs_qty bigint;
  v_effective_qty bigint;
  v_prior_qty bigint;
  v_stock_qty bigint;
  v_stock_event_count bigint;
  v_progress erp.v_fg_partial_completion_progress%rowtype;
begin
  perform erp.require_internal();
  if p_expected_version is null then
    raise exception 'expected_version is required';
  end if;
  if v_group_id is null then
    raise exception 'cutting_group_id is required';
  end if;
  if v_destination_location_id is null then
    raise exception 'destination_location_id is required';
  end if;
  if v_reason is null then
    raise exception 'Completion reason is required';
  end if;
  if v_physical_at > clock_timestamp() + interval '5 minutes' then
    raise exception 'Tanggal/jam penyelesaian FG berada di masa depan';
  end if;
  if jsonb_typeof(v_lines) <> 'array' or jsonb_array_length(v_lines) = 0 then
    raise exception 'Partial FG completion requires at least one line';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'payload', p_payload,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then
    return v_cached;
  end if;

  perform set_config('app.change_reason', v_reason, true);

  select * into v_group
  from erp.cutting_groups
  where id = v_group_id
  for update;
  if v_group.id is null then
    raise exception 'Potongan not found';
  end if;
  if v_group.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',
      p_expected_version, v_group.row_version;
  end if;

  select status into v_po_status
  from erp.production_orders
  where id = v_group.po_id
  for update;
  if v_po_status in ('FINISHED', 'CANCELLED') then
    raise exception 'PO berstatus % dan tidak menerima penyelesaian FG baru', v_po_status;
  end if;

  if not exists (
    select 1 from erp.locations l
    where l.id = v_destination_location_id
      and l.is_active = true
      and l.location_type = 'FG_WAREHOUSE'
  ) then
    raise exception 'Destination must be an active FG warehouse';
  end if;

  if exists (
    select 1
    from jsonb_to_recordset(v_lines) as x(
      final_product_id uuid,
      qty_good_pcs integer,
      qty_bs_pcs integer,
      source_laundry_receipt_line_id uuid,
      notes text
    )
    where coalesce(x.qty_good_pcs, 0) < 0
       or coalesce(x.qty_bs_pcs, 0) < 0
       or coalesce(x.qty_good_pcs, 0) + coalesce(x.qty_bs_pcs, 0) <= 0
       or x.final_product_id is null
  ) then
    raise exception 'Every completion line requires a SKU and a positive GOOD/BS quantity';
  end if;

  if exists (
    select 1
    from jsonb_to_recordset(v_lines) as x(
      final_product_id uuid,
      qty_good_pcs integer,
      qty_bs_pcs integer,
      source_laundry_receipt_line_id uuid,
      notes text
    )
    group by x.final_product_id, x.source_laundry_receipt_line_id
    having count(*) > 1
  ) then
    raise exception 'Duplicate SKU and laundry source lines are not allowed';
  end if;

  select
    sum(coalesce(x.qty_good_pcs, 0) + coalesce(x.qty_bs_pcs, 0))::bigint,
    sum(coalesce(x.qty_good_pcs, 0))::bigint,
    sum(coalesce(x.qty_bs_pcs, 0))::bigint
  into v_total_qty, v_good_qty, v_bs_qty
  from jsonb_to_recordset(v_lines) as x(
    final_product_id uuid,
    qty_good_pcs integer,
    qty_bs_pcs integer,
    source_laundry_receipt_line_id uuid,
    notes text
  );

  select effective_qty_pcs, qc_accounted_qty_pcs
  into v_effective_qty, v_prior_qty
  from erp.v_fg_partial_completion_progress
  where cutting_group_id = v_group.id;
  if coalesce(v_effective_qty, 0) <= 0 then
    raise exception 'Potongan has no effective quantity available for FG';
  end if;
  if coalesce(v_prior_qty, 0) + coalesce(v_total_qty, 0) > v_effective_qty then
    raise exception
      'Qty penyelesaian melebihi sisa Potongan. Efektif %, sudah diposting %, input %.',
      v_effective_qty, coalesce(v_prior_qty, 0), coalesce(v_total_qty, 0);
  end if;

  v_inspection_number := 'FGP-'
    || to_char(v_physical_at, 'YYMMDD') || '-'
    || upper(substr(replace(p_client_request_id::text, '-', ''), 1, 10));

  insert into erp.qc_inspections(
    id, inspection_number, po_id, physical_at, status,
    notes, created_by, destination_location_id
  ) values (
    v_qc_id, v_inspection_number, v_group.po_id, v_physical_at, 'DRAFT',
    'Partial FG completion: ' || v_reason,
    erp.current_app_user_id(), v_destination_location_id
  );

  insert into erp.qc_inspection_items(
    inspection_id, cutting_group_id, source_laundry_receipt_line_id,
    final_product_id, qty_good_pcs, qty_bs_pcs, notes
  )
  select
    v_qc_id,
    v_group.id,
    x.source_laundry_receipt_line_id,
    x.final_product_id,
    coalesce(x.qty_good_pcs, 0),
    coalesce(x.qty_bs_pcs, 0),
    nullif(btrim(x.notes), '')
  from jsonb_to_recordset(v_lines) as x(
    final_product_id uuid,
    qty_good_pcs integer,
    qty_bs_pcs integer,
    source_laundry_receipt_line_id uuid,
    notes text
  );

  perform erp.post_qc(v_qc_id);

  -- Invalidate stale partial-completion drafts after every successful posting.
  update erp.cutting_groups
  set updated_at = clock_timestamp()
  where id = v_group.id
  returning * into v_group;

  select * into v_progress
  from erp.v_fg_partial_completion_progress
  where cutting_group_id = v_group.id;

  select
    coalesce(sum(m.qty_signed), 0)::bigint,
    count(*)::bigint
  into v_stock_qty, v_stock_event_count
  from erp.fg_stock_movements m
  where m.movement_type = 'QC_GOOD'
    and m.source_type = 'QC_ITEM'
    and m.source_id in (
      select i.id from erp.qc_inspection_items i where i.inspection_id = v_qc_id
    );

  v_response := jsonb_build_object(
    'qc_inspection_id', v_qc_id,
    'inspection_number', v_inspection_number,
    'cutting_group_id', v_group.id,
    'po_id', v_group.po_id,
    'completion_status', v_progress.completion_status,
    'posted_qty_pcs', v_total_qty,
    'good_qty_pcs', v_good_qty,
    'bs_qty_pcs', v_bs_qty,
    'fg_stock_in_qty_pcs', v_stock_qty,
    'fg_stock_event_count', v_stock_event_count,
    'cumulative_qc_qty_pcs', v_progress.qc_accounted_qty_pcs,
    'remaining_qc_qty_pcs', v_progress.remaining_qc_qty_pcs,
    'completion_count', v_progress.completion_count,
    'row_version', v_group.row_version,
    'document_status', 'POSTED'
  );

  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

comment on function erp.post_fg_partial_completion_v2(jsonb, uuid, bigint) is
  'Posts one immutable partial FG/QC completion. Uses UUID idempotency, Potongan optimistic locking, cumulative quantity guards, and existing FG/HPP/reimbursement ledgers.';
comment on function erp.get_fg_partial_completion_context(uuid) is
  'Returns authoritative Potongan progress, row_version, and size-level suggested SKU context for the partial FG writer.';

revoke all on function erp.guard_qc_laundry_source_matches_group() from public, anon, authenticated;
revoke all on function erp.guard_finished_po_source_accounting() from public, anon, authenticated;
revoke all on function erp.post_fg_partial_completion_v2(jsonb, uuid, bigint) from public, anon;
revoke all on function erp.get_fg_partial_completion_context(uuid) from public, anon;

grant execute on function erp.post_fg_partial_completion_v2(jsonb, uuid, bigint) to authenticated, service_role;
grant execute on function erp.get_fg_partial_completion_context(uuid) to authenticated, service_role;
grant select on erp.v_fg_partial_completion_progress to authenticated, service_role;

notify pgrst, 'reload schema';
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260829185830','erp_v2_6_10_fg_partial_completion',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260829185830 erp_v2_6_10_fg_partial_completion

-- BEGIN PLATFORM MIGRATION 20260829204632 erp_v2_6_11_operational_reservations_and_completion_scope
-- ERP Garment v2.6.11
-- Operational truth for partial FG, Laundry outstanding, and all-day sales drafts.
--
-- Business contract:
--   * PARTIAL_SELECTION means the operator intentionally posts only part of the
--     physical quantity that is already eligible for QC/FG.
--   * WAITING_LAUNDRY means physical pieces are still outside at Laundry; it is
--     never presented as a partial FG choice.
--   * a DRAFT sale immediately reduces sellable FG through SALE_RESERVE.
--   * editing/cancelling a DRAFT releases the old reservation first.
--   * posting a sale converts SALE_RESERVE to SALE without a second qty movement.

alter table erp.qc_inspections
  add column if not exists completion_mode varchar(30);

alter table erp.qc_inspections
  drop constraint if exists qc_inspections_completion_mode_check;
alter table erp.qc_inspections
  add constraint qc_inspections_completion_mode_check
  check (completion_mode is null or completion_mode in ('ALL_READY','PARTIAL_SELECTION'));

comment on column erp.qc_inspections.completion_mode is
  'Operator intent for an FG completion. PARTIAL_SELECTION is only valid when already-returned eligible pieces are deliberately left for a later completion.';

create or replace view erp.v_fg_partial_completion_progress
with (security_invoker = true)
as
with qc as (
  select
    i.cutting_group_id,
    coalesce(sum(i.qty_good_pcs), 0)::bigint as qc_good_qty_pcs,
    coalesce(sum(i.qty_bs_pcs), 0)::bigint as qc_bs_qty_pcs,
    coalesce(sum(i.qty_good_pcs + i.qty_bs_pcs), 0)::bigint as qc_accounted_qty_pcs,
    coalesce(sum(i.qty_good_pcs + i.qty_bs_pcs)
      filter (where i.source_laundry_receipt_line_id is not null), 0)::bigint as laundry_qc_accounted_qty_pcs,
    coalesce(sum(i.qty_good_pcs + i.qty_bs_pcs)
      filter (where i.source_laundry_receipt_line_id is null), 0)::bigint as direct_qc_accounted_qty_pcs,
    count(distinct q.id)::bigint as completion_count,
    max(q.physical_at) as last_completion_at
  from erp.qc_inspection_items i
  join erp.qc_inspections q on q.id = i.inspection_id
  where q.status = 'POSTED'
  group by i.cutting_group_id
), latest_completion as (
  select distinct on (i.cutting_group_id)
    i.cutting_group_id,
    q.completion_mode
  from erp.qc_inspection_items i
  join erp.qc_inspections q on q.id = i.inspection_id
  where q.status = 'POSTED'
    and q.completion_mode is not null
  order by i.cutting_group_id, q.physical_at desc, q.id desc
), laundry as (
  select
    l.cutting_group_id,
    coalesce(sum(l.qty_sent_pcs), 0)::bigint as laundry_sent_qty_pcs
  from erp.laundry_delivery_lines l
  join erp.laundry_deliveries d on d.id = l.delivery_id
  where d.status not in ('DRAFT', 'REVERSED')
  group by l.cutting_group_id
), laundry_returned as (
  select
    dl.cutting_group_id,
    coalesce(sum(rl.qty_good_received), 0)::bigint as laundry_good_returned_qty_pcs,
    coalesce(sum(rl.qty_bs_laundry), 0)::bigint as laundry_bs_returned_qty_pcs,
    coalesce(sum(rl.qty_good_received + rl.qty_bs_laundry), 0)::bigint as laundry_returned_qty_pcs
  from erp.laundry_receipt_lines rl
  join erp.laundry_receipts r on r.id = rl.receipt_id
  join erp.laundry_delivery_lines dl on dl.id = rl.delivery_line_id
  join erp.laundry_deliveries d on d.id = dl.delivery_id
  where r.status = 'POSTED'
    and d.status <> 'REVERSED'
  group by dl.cutting_group_id
), resolved_claim as (
  select
    dl.cutting_group_id,
    coalesce(sum(c.qty_claimed), 0)::bigint as resolved_claim_qty_pcs
  from erp.laundry_claims c
  join erp.laundry_receipt_lines rl on rl.id = c.receipt_line_id
  join erp.laundry_delivery_lines dl on dl.id = rl.delivery_line_id
  where c.claim_type in ('MISSING','STUCK')
    and c.status in ('SETTLED','WRITTEN_OFF')
  group by dl.cutting_group_id
), progress as (
  select
    g.id as cutting_group_id,
    g.po_id,
    g.group_number,
    g.row_version,
    po.status as po_status,
    coalesce(t.total_pcs, 0)::bigint as effective_qty_pcs,
    coalesce(q.qc_good_qty_pcs, 0)::bigint as qc_good_qty_pcs,
    coalesce(q.qc_bs_qty_pcs, 0)::bigint as qc_bs_qty_pcs,
    coalesce(q.qc_accounted_qty_pcs, 0)::bigint as qc_accounted_qty_pcs,
    greatest(coalesce(t.total_pcs, 0) - coalesce(q.qc_accounted_qty_pcs, 0), 0)::bigint as remaining_qc_qty_pcs,
    coalesce(q.direct_qc_accounted_qty_pcs, 0)::bigint as direct_qc_accounted_qty_pcs,
    coalesce(q.laundry_qc_accounted_qty_pcs, 0)::bigint as laundry_qc_accounted_qty_pcs,
    coalesce(l.laundry_sent_qty_pcs, 0)::bigint as laundry_sent_qty_pcs,
    coalesce(lr.laundry_good_returned_qty_pcs, 0)::bigint as laundry_good_returned_qty_pcs,
    coalesce(lr.laundry_bs_returned_qty_pcs, 0)::bigint as laundry_bs_returned_qty_pcs,
    coalesce(lr.laundry_returned_qty_pcs, 0)::bigint as laundry_returned_qty_pcs,
    coalesce(rc.resolved_claim_qty_pcs, 0)::bigint as resolved_claim_qty_pcs,
    greatest(
      coalesce(lr.laundry_returned_qty_pcs, 0)
        - coalesce(q.laundry_qc_accounted_qty_pcs, 0),
      0
    )::bigint as ready_for_qc_qty_pcs,
    greatest(
      coalesce(l.laundry_sent_qty_pcs, 0)
        - coalesce(lr.laundry_returned_qty_pcs, 0)
        - coalesce(rc.resolved_claim_qty_pcs, 0),
      0
    )::bigint as laundry_outstanding_qty_pcs,
    (coalesce(q.direct_qc_accounted_qty_pcs, 0) + coalesce(l.laundry_sent_qty_pcs, 0))::bigint as source_accounted_qty_pcs,
    greatest(
      coalesce(t.total_pcs, 0)
        - coalesce(q.direct_qc_accounted_qty_pcs, 0)
        - coalesce(l.laundry_sent_qty_pcs, 0),
      0
    )::bigint as remaining_source_qty_pcs,
    coalesce(q.completion_count, 0)::bigint as completion_count,
    q.last_completion_at,
    lc.completion_mode as last_completion_mode
  from erp.cutting_groups g
  join erp.production_orders po on po.id = g.po_id
  left join erp.v_cutting_group_totals t on t.cutting_group_id = g.id
  left join qc q on q.cutting_group_id = g.id
  left join latest_completion lc on lc.cutting_group_id = g.id
  left join laundry l on l.cutting_group_id = g.id
  left join laundry_returned lr on lr.cutting_group_id = g.id
  left join resolved_claim rc on rc.cutting_group_id = g.id
)
select
  p.cutting_group_id,
  p.po_id,
  p.group_number,
  p.row_version,
  p.po_status,
  p.effective_qty_pcs,
  p.qc_good_qty_pcs,
  p.qc_bs_qty_pcs,
  p.qc_accounted_qty_pcs,
  p.remaining_qc_qty_pcs,
  p.direct_qc_accounted_qty_pcs,
  p.laundry_sent_qty_pcs,
  p.source_accounted_qty_pcs,
  p.remaining_source_qty_pcs,
  p.completion_count,
  p.last_completion_at,
  case
    when p.po_status = 'FINISHED' then 'FINISHED'
    when p.qc_accounted_qty_pcs = 0 then 'OPEN'
    when p.ready_for_qc_qty_pcs > 0 and p.last_completion_mode = 'PARTIAL_SELECTION' then 'PARTIAL_SELECTION'
    when p.ready_for_qc_qty_pcs > 0 then 'READY_FOR_QC'
    when p.laundry_outstanding_qty_pcs > 0 then 'WAITING_LAUNDRY'
    when p.remaining_qc_qty_pcs > 0 and p.last_completion_mode = 'PARTIAL_SELECTION' then 'PARTIAL_SELECTION'
    when p.remaining_qc_qty_pcs > 0 then 'OPEN_SOURCE'
    else 'QC_COMPLETE'
  end::text as completion_status,
  p.laundry_qc_accounted_qty_pcs,
  p.laundry_good_returned_qty_pcs,
  p.laundry_bs_returned_qty_pcs,
  p.laundry_returned_qty_pcs,
  p.resolved_claim_qty_pcs,
  p.ready_for_qc_qty_pcs,
  p.laundry_outstanding_qty_pcs,
  p.last_completion_mode
from progress p;

comment on view erp.v_fg_partial_completion_progress is
  'FG progress with separate ready-for-QC and Laundry-outstanding quantities. PARTIAL_SELECTION represents an explicit operator choice, never a Stuck Laundry balance.';

create or replace view erp.v_laundry_po_operational_progress
with (security_invoker = true)
as
with sent as (
  select d.po_id, sum(l.qty_sent_pcs)::bigint as sent_qty_pcs
  from erp.laundry_deliveries d
  join erp.laundry_delivery_lines l on l.delivery_id = d.id
  where d.status not in ('DRAFT','REVERSED')
  group by d.po_id
), returned as (
  select d.po_id,
    sum(rl.qty_good_received)::bigint as good_returned_qty_pcs,
    sum(rl.qty_bs_laundry)::bigint as bs_returned_qty_pcs,
    sum(rl.qty_good_received + rl.qty_bs_laundry)::bigint as returned_qty_pcs
  from erp.laundry_deliveries d
  join erp.laundry_receipts r on r.delivery_id = d.id and r.status = 'POSTED'
  join erp.laundry_receipt_lines rl on rl.receipt_id = r.id
  where d.status <> 'REVERSED'
  group by d.po_id
), resolved as (
  select d.po_id, sum(c.qty_claimed)::bigint as resolved_claim_qty_pcs
  from erp.laundry_claims c
  join erp.laundry_deliveries d on d.id = c.delivery_id
  where c.claim_type in ('MISSING','STUCK')
    and c.status in ('SETTLED','WRITTEN_OFF')
    and d.status <> 'REVERSED'
  group by d.po_id
)
select
  po.id as po_id,
  po.po_number,
  po.status as po_status,
  coalesce(s.sent_qty_pcs,0)::bigint as sent_qty_pcs,
  coalesce(r.good_returned_qty_pcs,0)::bigint as good_returned_qty_pcs,
  coalesce(r.bs_returned_qty_pcs,0)::bigint as bs_returned_qty_pcs,
  coalesce(r.returned_qty_pcs,0)::bigint as returned_qty_pcs,
  coalesce(x.resolved_claim_qty_pcs,0)::bigint as resolved_claim_qty_pcs,
  greatest(
    coalesce(s.sent_qty_pcs,0)
      - coalesce(r.returned_qty_pcs,0)
      - coalesce(x.resolved_claim_qty_pcs,0),
    0
  )::bigint as laundry_outstanding_qty_pcs
from erp.production_orders po
join sent s on s.po_id = po.id
left join returned r on r.po_id = po.id
left join resolved x on x.po_id = po.id;

comment on view erp.v_laundry_po_operational_progress is
  'PO-level Laundry balance. Posted physical returns and settled/written-off Stuck or Missing claims automatically reduce operational Laundry outstanding.';

do $migration$
begin
  if to_regprocedure('erp.post_fg_partial_completion_v2_legacy_v2610(jsonb,uuid,bigint)') is null
     and to_regprocedure('erp.post_fg_partial_completion_v2(jsonb,uuid,bigint)') is not null then
    alter function erp.post_fg_partial_completion_v2(jsonb, uuid, bigint)
      rename to post_fg_partial_completion_v2_legacy_v2610;
  end if;
end;
$migration$;

create or replace function erp.post_fg_partial_completion_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_mode text := upper(coalesce(nullif(btrim(p_payload->>'completion_mode'),''),'ALL_READY'));
  v_result jsonb;
  v_qc_id uuid;
  v_progress erp.v_fg_partial_completion_progress%rowtype;
begin
  perform erp.require_internal();
  if v_mode not in ('ALL_READY','PARTIAL_SELECTION') then
    raise exception 'completion_mode must be ALL_READY or PARTIAL_SELECTION';
  end if;

  v_result := erp.post_fg_partial_completion_v2_legacy_v2610(
    p_payload,
    p_client_request_id,
    p_expected_version
  );
  v_qc_id := nullif(v_result->>'qc_inspection_id','')::uuid;

  update erp.qc_inspections
  set completion_mode = v_mode
  where id = v_qc_id
    and completion_mode is distinct from v_mode;

  select * into v_progress
  from erp.v_fg_partial_completion_progress
  where cutting_group_id = nullif(v_result->>'cutting_group_id','')::uuid;

  return v_result || jsonb_build_object(
    'completion_mode', v_mode,
    'completion_status', v_progress.completion_status,
    'ready_for_qc_qty_pcs', v_progress.ready_for_qc_qty_pcs,
    'laundry_outstanding_qty_pcs', v_progress.laundry_outstanding_qty_pcs,
    'remaining_qc_qty_pcs', v_progress.remaining_qc_qty_pcs
  );
end;
$function$;

comment on function erp.post_fg_partial_completion_v2(jsonb, uuid, bigint) is
  'Posts one immutable FG completion and persists explicit ALL_READY versus PARTIAL_SELECTION intent. Stuck Laundry is reported separately.';

-- ---------------------------------------------------------------------------
-- Sales Draft reservation ledger
-- ---------------------------------------------------------------------------

alter table erp.sales_headers
  add column if not exists row_version bigint not null default 1;
alter table erp.sales_headers
  drop constraint if exists sales_headers_row_version_check;
alter table erp.sales_headers
  add constraint sales_headers_row_version_check check (row_version > 0);

drop trigger if exists trg_sales_row_version on erp.sales_headers;
create trigger trg_sales_row_version
before update on erp.sales_headers
for each row execute function erp.bump_row_version();

alter table erp.fg_stock_movements
  drop constraint if exists fg_stock_movements_movement_type_check;
alter table erp.fg_stock_movements
  add constraint fg_stock_movements_movement_type_check
  check (movement_type in (
    'OPENING','QC_GOOD','SALE_RESERVE','SALE','SALE_RETURN',
    'REBRAND_OUT','REBRAND_IN','BS_OUT','REWORK_IN','ADJUSTMENT','REVERSAL'
  ));

create or replace function erp._release_sale_draft_reservations(
  p_sale_id uuid,
  p_reason text
)
returns bigint
language plpgsql
security definer
set search_path = erp, public, pg_temp
as $function$
declare
  r record;
  v_reversal_id uuid;
  v_released bigint := 0;
begin
  perform erp.require_internal();
  for r in
    select m.*
    from erp.fg_stock_movements m
    join erp.sales_items i on i.id = m.source_id
    where i.sale_id = p_sale_id
      and m.source_type = 'SALE_ITEM'
      and m.movement_type = 'SALE_RESERVE'
      and not exists (
        select 1 from erp.fg_stock_movements rv where rv.reversal_of_id = m.id
      )
    order by m.physical_at, m.book_order, m.id
    for update of m
  loop
    v_reversal_id := erp.post_fg_movement(
      r.product_id,r.lot_id,r.location_id,r.quality_grade,
      'REVERSAL',-r.qty_signed,r.unit_hpp_snapshot,r.customer_id,
      'FG_MOVEMENT_REVERSAL',r.id,r.physical_at,
      coalesce(nullif(btrim(p_reason),''),'Release sales Draft reservation'),false
    );
    update erp.fg_stock_movements
    set reversal_of_id = r.id
    where id = v_reversal_id;
    v_released := v_released + abs(r.qty_signed);
  end loop;

  delete from erp.sale_stock_allocations a
  using erp.sales_items i
  where a.sale_item_id = i.id
    and i.sale_id = p_sale_id;
  return v_released;
end;
$function$;

create or replace function erp._reserve_sale_draft(p_sale_id uuid)
returns bigint
language plpgsql
security definer
set search_path = erp, public, pg_temp
as $function$
declare
  h erp.sales_headers%rowtype;
  item record;
  lotrow record;
  v_need integer;
  v_take integer;
  v_hpp numeric(18,6);
  v_reserved bigint := 0;
begin
  perform erp.require_internal();
  select * into h from erp.sales_headers where id = p_sale_id for update;
  if h.id is null or h.status <> 'DRAFT' then
    raise exception 'Sale must be DRAFT before reservation';
  end if;
  if h.source_location_id is null then
    raise exception 'Sale source FG location is required';
  end if;
  if not exists (select 1 from erp.sales_items where sale_id = h.id) then
    raise exception 'Sale has no items';
  end if;
  if exists (
    select 1
    from erp.fg_stock_movements m
    join erp.sales_items i on i.id = m.source_id
    where i.sale_id = h.id
      and m.movement_type = 'SALE_RESERVE'
      and not exists (select 1 from erp.fg_stock_movements rv where rv.reversal_of_id = m.id)
  ) then
    raise exception 'Active Draft reservation already exists; release it before rebuilding';
  end if;

  for item in
    select * from erp.sales_items where sale_id = h.id order by product_id,id
  loop
    insert into erp.fg_inventory_balances(product_id,location_id,quality_grade,cached_qty_pcs)
    values(item.product_id,h.source_location_id,'GRADE_A',0)
    on conflict(product_id,location_id,quality_grade) do nothing;
    perform 1
    from erp.fg_inventory_balances
    where product_id = item.product_id
      and location_id = h.source_location_id
      and quality_grade = 'GRADE_A'
    for update;

    v_need := item.qty_pcs;
    for lotrow in
      select fl.id,sum(fm.qty_signed)::integer as location_qty,fl.produced_at
      from erp.fg_lots fl
      join erp.fg_stock_movements fm on fm.lot_id = fl.id
      where fl.product_id = item.product_id
        and fm.location_id = h.source_location_id
        and fm.quality_grade = 'GRADE_A'
      group by fl.id,fl.produced_at
      having sum(fm.qty_signed) > 0
      order by fl.produced_at,fl.id
    loop
      exit when v_need <= 0;
      perform 1 from erp.fg_lots where id = lotrow.id for update;
      v_take := least(v_need,lotrow.location_qty);
      v_hpp := coalesce(erp.lock_current_hpp_per_pcs(lotrow.id),0);
      insert into erp.sale_stock_allocations(
        sale_item_id,lot_id,location_id,qty_pcs,unit_hpp_snapshot
      ) values (
        item.id,lotrow.id,h.source_location_id,v_take,v_hpp
      );
      perform erp.post_fg_movement(
        item.product_id,lotrow.id,h.source_location_id,'GRADE_A',
        'SALE_RESERVE',-v_take,v_hpp,h.customer_id,'SALE_ITEM',item.id,
        h.sale_date,'Draft invoice reserve · reduces sellable stock',false
      );
      v_need := v_need - v_take;
      v_reserved := v_reserved + v_take;
    end loop;
    if v_need > 0 then
      raise exception 'Insufficient FG stock for product %; short % pcs',item.product_id,v_need;
    end if;
  end loop;
  return v_reserved;
end;
$function$;

create or replace function erp.save_sale_draft_v2(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'save_sale_draft_v2';
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  v_sale_id uuid := nullif(p_payload->>'sale_id','')::uuid;
  v_sale_number text := nullif(btrim(p_payload->>'sale_number'),'');
  v_customer_id uuid := nullif(p_payload->>'customer_id','')::uuid;
  v_location_id uuid := nullif(p_payload->>'source_location_id','')::uuid;
  v_sale_date timestamptz := nullif(p_payload->>'sale_date','')::timestamptz;
  v_due_date date := nullif(p_payload->>'due_date','')::date;
  v_payment_terms text := nullif(btrim(p_payload->>'payment_terms'),'');
  v_notes text := nullif(btrim(p_payload->>'notes'),'');
  v_reason text := nullif(btrim(p_payload->>'reason'),'');
  v_items jsonb := p_payload->'items';
  h erp.sales_headers%rowtype;
  v_reserved bigint;
  v_released bigint := 0;
  v_total numeric(24,6);
begin
  perform erp.require_internal();
  if v_sale_number is null or v_customer_id is null or v_location_id is null or v_sale_date is null then
    raise exception 'sale_number, customer_id, source_location_id, and sale_date are required';
  end if;
  if v_reason is null then raise exception 'Draft save reason is required'; end if;
  if v_sale_date > clock_timestamp() + interval '5 minutes' then
    raise exception 'Tanggal/jam invoice berada di masa depan';
  end if;
  if jsonb_typeof(v_items) <> 'array' or jsonb_array_length(v_items) = 0 then
    raise exception 'Sale Draft requires at least one item';
  end if;
  if not exists (select 1 from erp.customers where id=v_customer_id and is_active=true) then
    raise exception 'Active customer is required';
  end if;
  if not exists (
    select 1 from erp.locations
    where id=v_location_id and is_active=true and location_type='FG_WAREHOUSE'
  ) then raise exception 'Active FG warehouse is required'; end if;
  if exists (
    select 1 from jsonb_to_recordset(v_items) as x(
      product_id uuid,qty_pcs integer,unit_price_snapshot numeric,discount_amount numeric,notes text
    )
    where x.product_id is null or coalesce(x.qty_pcs,0)<=0
      or coalesce(x.unit_price_snapshot,0)<0 or coalesce(x.discount_amount,0)<0
      or coalesce(x.discount_amount,0)>coalesce(x.qty_pcs,0)*coalesce(x.unit_price_snapshot,0)
  ) then raise exception 'Every sale line requires valid product, qty, price, and discount'; end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'payload',p_payload,'expected_version',p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation,p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  perform set_config('app.change_reason',v_reason,true);

  if v_sale_id is null then
    if p_expected_version is not null then
      raise exception 'expected_version must be null when creating a Sale Draft';
    end if;
    insert into erp.sales_headers(
      sale_number,customer_id,sale_date,due_date,status,payment_terms,notes,created_by,source_location_id
    ) values (
      v_sale_number,v_customer_id,v_sale_date,v_due_date,'DRAFT',v_payment_terms,v_notes,
      erp.current_app_user_id(),v_location_id
    ) returning * into h;
    v_sale_id := h.id;
  else
    if p_expected_version is null then raise exception 'expected_version is required when editing a Sale Draft'; end if;
    select * into h from erp.sales_headers where id=v_sale_id for update;
    if h.id is null then raise exception 'Sale Draft not found'; end if;
    if h.status <> 'DRAFT' then raise exception 'Only a DRAFT sale can be edited'; end if;
    if h.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version;
    end if;
    v_released := erp._release_sale_draft_reservations(v_sale_id,'Edit Draft · release previous reservation');
    delete from erp.sales_items where sale_id=v_sale_id;
    update erp.sales_headers set
      sale_number=v_sale_number,customer_id=v_customer_id,sale_date=v_sale_date,
      due_date=v_due_date,payment_terms=v_payment_terms,notes=v_notes,
      source_location_id=v_location_id
    where id=v_sale_id
    returning * into h;
  end if;

  insert into erp.sales_items(
    sale_id,product_id,qty_pcs,unit_price_snapshot,discount_amount,notes
  )
  select v_sale_id,x.product_id,x.qty_pcs,x.unit_price_snapshot,
    coalesce(x.discount_amount,0),nullif(btrim(x.notes),'')
  from jsonb_to_recordset(v_items) as x(
    product_id uuid,qty_pcs integer,unit_price_snapshot numeric,discount_amount numeric,notes text
  );

  v_reserved := erp._reserve_sale_draft(v_sale_id);
  select * into h from erp.sales_headers where id=v_sale_id;
  select coalesce(sum(line_total),0) into v_total from erp.sales_items where sale_id=v_sale_id;
  v_response := jsonb_build_object(
    'sale_id',v_sale_id,'sale_number',h.sale_number,'status',h.status,
    'reserved_qty_pcs',v_reserved,'released_previous_qty_pcs',v_released,
    'sellable_stock_delta_pcs',-v_reserved,'invoice_total',v_total,
    'row_version',h.row_version
  );
  return erp._idempotency_complete(v_operation,p_client_request_id,v_response);
end;
$function$;

create or replace function erp.cancel_sale_draft_v2(
  p_sale_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  h erp.sales_headers%rowtype;
  v_released bigint;
begin
  perform erp.require_internal();
  if nullif(btrim(p_reason),'') is null then raise exception 'Cancellation reason is required'; end if;
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  v_hash := erp._request_hash(jsonb_build_object(
    'sale_id',p_sale_id,'reason',btrim(p_reason),'expected_version',p_expected_version
  ));
  v_cached := erp._idempotency_begin('cancel_sale_draft_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  select * into h from erp.sales_headers where id=p_sale_id for update;
  if h.id is null then raise exception 'Sale Draft not found'; end if;
  if h.status <> 'DRAFT' then raise exception 'Only a DRAFT sale can be cancelled'; end if;
  if h.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version;
  end if;
  perform set_config('app.change_reason',btrim(p_reason),true);
  v_released := erp._release_sale_draft_reservations(h.id,btrim(p_reason));
  update erp.sales_headers set status='CANCELLED' where id=h.id returning * into h;
  v_response := jsonb_build_object(
    'sale_id',h.id,'sale_number',h.sale_number,'status',h.status,
    'released_qty_pcs',v_released,'sellable_stock_delta_pcs',v_released,
    'row_version',h.row_version
  );
  return erp._idempotency_complete('cancel_sale_draft_v2',p_client_request_id,v_response);
end;
$function$;

create or replace function erp.post_sale(p_sale_id uuid)
returns void
language plpgsql
security definer
set search_path = erp, public, pg_temp
as $function$
declare
  h erp.sales_headers%rowtype;
  v_sales numeric(24,6) := 0;
  v_cogs numeric(24,6) := 0;
  v_item_qty bigint;
  v_reserved_qty bigint;
  v_lines jsonb := '[]'::jsonb;
begin
  perform erp.require_internal();
  select * into h from erp.sales_headers where id=p_sale_id for update;
  if h.id is null or h.status<>'DRAFT' then raise exception 'Sale must be DRAFT'; end if;
  if h.source_location_id is null then raise exception 'Sale source FG location is required'; end if;
  if not exists(select 1 from erp.sales_items where sale_id=p_sale_id) then raise exception 'Sale has no items'; end if;

  select coalesce(sum(qty_pcs),0),coalesce(sum(line_total),0)
  into v_item_qty,v_sales
  from erp.sales_items where sale_id=h.id;
  select coalesce(sum(abs(m.qty_signed)),0)
  into v_reserved_qty
  from erp.fg_stock_movements m
  join erp.sales_items i on i.id=m.source_id
  where i.sale_id=h.id and m.source_type='SALE_ITEM' and m.movement_type='SALE_RESERVE'
    and not exists(select 1 from erp.fg_stock_movements rv where rv.reversal_of_id=m.id);

  if v_reserved_qty=0 then
    v_reserved_qty:=erp._reserve_sale_draft(h.id);
  end if;
  if v_reserved_qty<>v_item_qty then
    raise exception 'Sale Draft reservation mismatch. Items %, active reservation %',v_item_qty,v_reserved_qty;
  end if;
  if exists (
    select 1 from erp.sales_items i
    left join (
      select sale_item_id,sum(qty_pcs)::bigint qty_pcs
      from erp.sale_stock_allocations group by sale_item_id
    ) a on a.sale_item_id=i.id
    where i.sale_id=h.id and coalesce(a.qty_pcs,0)<>i.qty_pcs
  ) then raise exception 'Sale allocation does not match Draft line quantity'; end if;

  select coalesce(sum(a.qty_pcs*a.unit_hpp_snapshot),0)
  into v_cogs
  from erp.sale_stock_allocations a
  join erp.sales_items i on i.id=a.sale_item_id
  where i.sale_id=h.id;

  -- This is the key invariant: posting changes classification only. Quantity was
  -- already deducted at Draft time and must not be deducted a second time.
  update erp.fg_stock_movements m
  set movement_type='SALE', notes='Sale posted · quantity already reserved in Draft'
  from erp.sales_items i
  where i.id=m.source_id and i.sale_id=h.id
    and m.source_type='SALE_ITEM' and m.movement_type='SALE_RESERVE'
    and not exists(select 1 from erp.fg_stock_movements rv where rv.reversal_of_id=m.id);

  update erp.sales_headers set status='POSTED' where id=h.id;
  if abs(v_sales)>0.005 then
    v_lines:=v_lines||jsonb_build_array(
      jsonb_build_object('mapping_key','AR_CUSTOMER','debit',round(v_sales,2),'credit',0,'customer_id',h.customer_id),
      jsonb_build_object('mapping_key','SALES_REVENUE','debit',0,'credit',round(v_sales,2),'customer_id',h.customer_id));
  end if;
  if abs(v_cogs)>0.005 then
    v_lines:=v_lines||jsonb_build_array(
      jsonb_build_object('mapping_key','COGS','debit',round(v_cogs,2),'credit',0,'customer_id',h.customer_id),
      jsonb_build_object('mapping_key','FG_INVENTORY','debit',0,'credit',round(v_cogs,2),'customer_id',h.customer_id));
  end if;
  if jsonb_array_length(v_lines)>=2 then
    perform erp.post_journal('SALE',h.id,h.sale_date::date,'Sales to customer/toko',v_lines);
  end if;
end;
$function$;

create or replace function erp.post_sale_v2(
  p_sale_id uuid,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_hash text;
  v_cached jsonb;
  v_response jsonb;
  h erp.sales_headers%rowtype;
  v_before bigint;
  v_after bigint;
  v_qty bigint;
begin
  perform erp.require_internal();
  if p_expected_version is null then raise exception 'expected_version is required'; end if;
  v_hash:=erp._request_hash(jsonb_build_object(
    'sale_id',p_sale_id,'expected_version',p_expected_version
  ));
  v_cached:=erp._idempotency_begin('post_sale_v2',p_client_request_id,v_hash);
  if v_cached is not null then return v_cached; end if;
  select * into h from erp.sales_headers where id=p_sale_id for update;
  if h.id is null then raise exception 'Sale not found'; end if;
  if h.status<>'DRAFT' then raise exception 'Sale must be DRAFT'; end if;
  if h.row_version<>p_expected_version then
    raise exception 'STALE_VERSION expected %, current %',p_expected_version,h.row_version;
  end if;
  select coalesce(sum(b.cached_qty_pcs),0) into v_before
  from erp.fg_inventory_balances b
  where b.location_id=h.source_location_id and b.quality_grade='GRADE_A'
    and b.product_id in (select product_id from erp.sales_items where sale_id=h.id);
  select coalesce(sum(qty_pcs),0) into v_qty from erp.sales_items where sale_id=h.id;
  perform erp.post_sale(h.id);
  select * into h from erp.sales_headers where id=h.id;
  select coalesce(sum(b.cached_qty_pcs),0) into v_after
  from erp.fg_inventory_balances b
  where b.location_id=h.source_location_id and b.quality_grade='GRADE_A'
    and b.product_id in (select product_id from erp.sales_items where sale_id=h.id);
  if v_before is distinct from v_after then
    raise exception 'Invariant violation: posting changed FG balance after Draft reservation';
  end if;
  v_response:=jsonb_build_object(
    'sale_id',h.id,'sale_number',h.sale_number,'status',h.status,
    'posted_qty_pcs',v_qty,'post_stock_delta_pcs',0,'row_version',h.row_version
  );
  return erp._idempotency_complete('post_sale_v2',p_client_request_id,v_response);
end;
$function$;

create or replace view erp.v_sale_reservation_progress
with (security_invoker = true)
as
with items as (
  select sale_id,sum(qty_pcs)::bigint as item_qty_pcs
  from erp.sales_items group by sale_id
), allocations as (
  select i.sale_id,sum(a.qty_pcs)::bigint as allocated_qty_pcs
  from erp.sales_items i
  join erp.sale_stock_allocations a on a.sale_item_id=i.id
  group by i.sale_id
), reservations as (
  select i.sale_id,sum(abs(m.qty_signed))::bigint as active_reserved_qty_pcs
  from erp.sales_items i
  join erp.fg_stock_movements m on m.source_id=i.id
  where m.source_type='SALE_ITEM' and m.movement_type='SALE_RESERVE'
    and not exists(select 1 from erp.fg_stock_movements rv where rv.reversal_of_id=m.id)
  group by i.sale_id
)
select
  h.id as sale_id,h.sale_number,h.customer_id,h.source_location_id,h.sale_date,
  h.status,h.row_version,
  coalesce(i.item_qty_pcs,0)::bigint as item_qty_pcs,
  coalesce(a.allocated_qty_pcs,0)::bigint as allocated_qty_pcs,
  coalesce(r.active_reserved_qty_pcs,0)::bigint as active_reserved_qty_pcs,
  case
    when h.status='DRAFT'
      and coalesce(i.item_qty_pcs,0)=coalesce(a.allocated_qty_pcs,0)
      and coalesce(i.item_qty_pcs,0)=coalesce(r.active_reserved_qty_pcs,0)
      and coalesce(i.item_qty_pcs,0)>0 then 'RESERVED'
    when h.status='DRAFT' then 'RESERVATION_MISMATCH'
    else h.status
  end::text as reservation_status
from erp.sales_headers h
left join items i on i.sale_id=h.id
left join allocations a on a.sale_id=h.id
left join reservations r on r.sale_id=h.id;

comment on view erp.v_sale_reservation_progress is
  'Draft invoice reservation truth. A valid Draft has item qty = FIFO allocation qty = active SALE_RESERVE qty; Post creates no second stock delta.';

revoke all on function erp._release_sale_draft_reservations(uuid,text) from public,anon,authenticated;
revoke all on function erp._reserve_sale_draft(uuid) from public,anon,authenticated;
revoke all on function erp.post_fg_partial_completion_v2_legacy_v2610(jsonb,uuid,bigint) from public,anon,authenticated;
revoke all on function erp.save_sale_draft_v2(jsonb,uuid,bigint) from public,anon;
revoke all on function erp.cancel_sale_draft_v2(uuid,text,uuid,bigint) from public,anon;
revoke all on function erp.post_sale_v2(uuid,uuid,bigint) from public,anon;
revoke all on function erp.post_fg_partial_completion_v2(jsonb,uuid,bigint) from public,anon;

grant execute on function erp.save_sale_draft_v2(jsonb,uuid,bigint) to authenticated,service_role;
grant execute on function erp.cancel_sale_draft_v2(uuid,text,uuid,bigint) to authenticated,service_role;
grant execute on function erp.post_sale_v2(uuid,uuid,bigint) to authenticated,service_role;
grant execute on function erp.post_fg_partial_completion_v2(jsonb,uuid,bigint) to authenticated,service_role;
grant select on erp.v_fg_partial_completion_progress to authenticated,service_role;
grant select on erp.v_laundry_po_operational_progress to authenticated,service_role;
grant select on erp.v_sale_reservation_progress to authenticated,service_role;

notify pgrst, 'reload schema';
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260829204632','erp_v2_6_11_operational_reservations_and_completion_scope',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260829204632 erp_v2_6_11_operational_reservations_and_completion_scope

-- BEGIN PLATFORM MIGRATION 20260830140645 erp_v2_6_12_attendance_and_stock_explainability
-- ERP Garment v2.6.12
-- Attendance roster/rate history and truthful stock explainability foundation.
--
-- This is an additive delta after the v2.6.11a UAT closure. It deliberately:
--   * does not edit or replay the v2.6.11a artifacts;
--   * preserves existing attendance rows and payroll snapshots;
--   * keeps erp.* tables private and exposes only narrow public RPCs;
--   * treats fg_inventory_balances.cached_qty_pcs as AVAILABLE stock because
--     SALE_RESERVE has already reduced that cache;
--   * does not invent demand, lead-time, WIP-to-SKU, HPP, or reorder formula
--     inputs that are not yet authoritative in the backend.

begin;

set local lock_timeout = '10s';
set local statement_timeout = '120s';

do $migration_guard$
begin
  if to_regclass('erp.contractor_workers') is null
     or to_regclass('erp.attendance_records') is null
     or to_regclass('erp.payroll_attendance_items') is null
     or to_regclass('erp.payroll_settlements') is null
     or to_regclass('erp.fg_inventory_balances') is null
     or to_regclass('erp.fg_stock_movements') is null then
    raise exception 'ERP v2.6.12 requires the ERP Garment baseline schema before this additive delta';
  end if;
end;
$migration_guard$;

-- ---------------------------------------------------------------------------
-- 1. Lightweight worker roster and effective-dated daily rates
-- ---------------------------------------------------------------------------

alter table erp.contractor_workers
  add column if not exists job_description text,
  add column if not exists row_version bigint not null default 1,
  add column if not exists created_by uuid references erp.app_users(id),
  add column if not exists updated_by uuid references erp.app_users(id);

alter table erp.contractor_workers
  drop constraint if exists contractor_workers_row_version_check;
alter table erp.contractor_workers
  add constraint contractor_workers_row_version_check check (row_version > 0);

alter table erp.contractor_workers
  drop constraint if exists contractor_workers_active_dates_check;
alter table erp.contractor_workers
  add constraint contractor_workers_active_dates_check
  check (left_at is null or joined_at is null or left_at >= joined_at);

drop trigger if exists trg_00_worker_row_version on erp.contractor_workers;
create trigger trg_00_worker_row_version
before update on erp.contractor_workers
for each row execute function erp.bump_row_version();

create or replace function erp.guard_worker_daily_rate_cache()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
begin
  if new.daily_rate is distinct from old.daily_rate
     and current_setting('app.worker_rate_write', true) is distinct from 'on' then
    raise exception 'contractor_workers.daily_rate is a current cache; use erp_set_worker_daily_rate_v1';
  end if;
  return new;
end;
$function$;

drop trigger if exists trg_01_guard_worker_daily_rate_cache on erp.contractor_workers;
create trigger trg_01_guard_worker_daily_rate_cache
before update of daily_rate on erp.contractor_workers
for each row execute function erp.guard_worker_daily_rate_cache();

create table if not exists erp.worker_daily_rate_versions (
  id uuid primary key default gen_random_uuid(),
  worker_id uuid not null references erp.contractor_workers(id),
  daily_rate numeric(24,6) not null check (daily_rate >= 0),
  effective_from date not null,
  effective_to date,
  change_reason text not null check (btrim(change_reason) <> ''),
  created_by uuid references erp.app_users(id),
  created_at timestamptz not null default clock_timestamp(),
  constraint worker_daily_rate_versions_dates_check
    check (effective_to is null or effective_to >= effective_from),
  constraint worker_daily_rate_versions_worker_from_key
    unique (worker_id, effective_from)
);

create index if not exists idx_worker_rate_versions_lookup
  on erp.worker_daily_rate_versions(worker_id, effective_from desc);

create or replace function erp.guard_worker_daily_rate_version()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
declare
  v_worker_id uuid := case when tg_op = 'DELETE' then old.worker_id else new.worker_id end;
begin
  if current_setting('app.worker_rate_write', true) is distinct from 'on' then
    raise exception 'Worker rate history is write-protected; use erp_set_worker_daily_rate_v1';
  end if;

  if tg_op = 'DELETE' then
    raise exception 'Worker rate history cannot be deleted';
  end if;

  if tg_op = 'UPDATE'
     and (new.worker_id, new.daily_rate, new.effective_from, new.change_reason,
          new.created_by, new.created_at)
         is distinct from
         (old.worker_id, old.daily_rate, old.effective_from, old.change_reason,
          old.created_by, old.created_at) then
    raise exception 'Existing worker rate facts are immutable; only effective_to may be closed';
  end if;

  perform pg_advisory_xact_lock(hashtextextended('WORKER_RATE|' || v_worker_id::text, 0));

  if exists (
    select 1
    from erp.worker_daily_rate_versions r
    where r.worker_id = v_worker_id
      and r.id <> coalesce(new.id, gen_random_uuid())
      and daterange(r.effective_from, coalesce(r.effective_to + 1, 'infinity'::date), '[)')
          && daterange(new.effective_from, coalesce(new.effective_to + 1, 'infinity'::date), '[)')
  ) then
    raise exception 'Worker daily-rate periods cannot overlap';
  end if;

  return new;
end;
$function$;

drop trigger if exists trg_guard_worker_daily_rate_version
  on erp.worker_daily_rate_versions;
create trigger trg_guard_worker_daily_rate_version
before insert or update or delete on erp.worker_daily_rate_versions
for each row execute function erp.guard_worker_daily_rate_version();

drop trigger if exists trg_audit_worker_daily_rate_versions
  on erp.worker_daily_rate_versions;
create trigger trg_audit_worker_daily_rate_versions
after insert or update or delete on erp.worker_daily_rate_versions
for each row execute function erp.audit_row_change();

select set_config('app.worker_rate_write', 'on', true);

insert into erp.worker_daily_rate_versions(
  worker_id, daily_rate, effective_from, change_reason, created_by
)
select
  w.id,
  w.daily_rate,
  least(
    coalesce(w.joined_at, 'infinity'::date),
    coalesce((
      select min(a.attendance_date)
      from erp.attendance_records a
      where a.worker_id = w.id
    ), 'infinity'::date),
    coalesce(w.created_at::date, current_date)
  ),
  'v2.6.12 baseline copied from contractor_workers.daily_rate; no existing payroll snapshot changed',
  w.created_by
from erp.contractor_workers w
where not exists (
  select 1 from erp.worker_daily_rate_versions r where r.worker_id = w.id
)
on conflict (worker_id, effective_from) do nothing;

select set_config('app.worker_rate_write', 'off', true);

create or replace function erp.worker_daily_rate_version_id_at(
  p_worker_id uuid,
  p_effective_date date
)
returns uuid
language sql
stable
security invoker
set search_path = erp, public, pg_temp
as $function$
  select r.id
  from erp.worker_daily_rate_versions r
  where r.worker_id = p_worker_id
    and p_effective_date >= r.effective_from
    and (r.effective_to is null or p_effective_date <= r.effective_to)
  order by r.effective_from desc, r.created_at desc, r.id desc
  limit 1
$function$;

create or replace function erp.worker_daily_rate_at(
  p_worker_id uuid,
  p_effective_date date
)
returns numeric
language sql
stable
security invoker
set search_path = erp, public, pg_temp
as $function$
  select r.daily_rate
  from erp.worker_daily_rate_versions r
  where r.worker_id = p_worker_id
    and p_effective_date >= r.effective_from
    and (r.effective_to is null or p_effective_date <= r.effective_to)
  order by r.effective_from desc, r.created_at desc, r.id desc
  limit 1
$function$;

create or replace function erp.require_worker_daily_rate_at(
  p_worker_id uuid,
  p_effective_date date
)
returns numeric
language plpgsql
stable
security invoker
set search_path = erp, public, pg_temp
as $function$
declare
  v_rate numeric;
begin
  v_rate := erp.worker_daily_rate_at(p_worker_id, p_effective_date);
  if v_rate is null then
    raise exception 'Worker % has no daily-rate version covering %', p_worker_id, p_effective_date;
  end if;
  return v_rate;
end;
$function$;

create or replace function erp.set_worker_daily_rate_v1(
  p_worker_id uuid,
  p_daily_rate numeric,
  p_effective_from date,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'set_worker_daily_rate_v1';
  v_hash text;
  v_cached jsonb;
  v_worker erp.contractor_workers%rowtype;
  v_next_from date;
  v_new_id uuid;
  v_response jsonb;
begin
  perform erp.require_owner_admin();

  if p_worker_id is null or p_effective_from is null or p_expected_version is null then
    raise exception 'worker_id, effective_from, and expected_version are required';
  end if;
  if p_daily_rate is null or p_daily_rate < 0 then
    raise exception 'daily_rate must be zero or positive';
  end if;
  if coalesce(btrim(p_reason), '') = '' then
    raise exception 'Rate change reason is required';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'worker_id', p_worker_id,
    'daily_rate', p_daily_rate,
    'effective_from', p_effective_from,
    'reason', p_reason,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_worker
  from erp.contractor_workers
  where id = p_worker_id
  for update;

  if v_worker.id is null then raise exception 'Worker not found'; end if;
  if v_worker.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_worker.row_version;
  end if;
  if v_worker.joined_at is not null and p_effective_from < v_worker.joined_at then
    raise exception 'Rate effective date cannot be earlier than worker start date';
  end if;
  if exists (
    select 1 from erp.worker_daily_rate_versions r
    where r.worker_id = p_worker_id and r.effective_from = p_effective_from
  ) then
    raise exception 'A worker rate version already starts on this date; use a later effective date';
  end if;

  perform set_config('app.change_reason', p_reason, true);
  perform set_config('app.worker_rate_write', 'on', true);
  perform pg_advisory_xact_lock(hashtextextended('WORKER_RATE|' || p_worker_id::text, 0));

  select min(r.effective_from) into v_next_from
  from erp.worker_daily_rate_versions r
  where r.worker_id = p_worker_id and r.effective_from > p_effective_from;

  update erp.worker_daily_rate_versions r
  set effective_to = p_effective_from - 1
  where r.worker_id = p_worker_id
    and r.effective_from < p_effective_from
    and (r.effective_to is null or r.effective_to >= p_effective_from);

  insert into erp.worker_daily_rate_versions(
    worker_id, daily_rate, effective_from, effective_to, change_reason, created_by
  ) values (
    p_worker_id, p_daily_rate, p_effective_from,
    case when v_next_from is null then null else v_next_from - 1 end,
    p_reason, erp.current_app_user_id()
  ) returning id into v_new_id;

  update erp.contractor_workers w
  set daily_rate = coalesce(erp.worker_daily_rate_at(w.id, current_date), w.daily_rate),
      updated_by = erp.current_app_user_id()
  where w.id = p_worker_id;

  select jsonb_build_object(
    'worker_id', w.id,
    'rate_version_id', v_new_id,
    'daily_rate', p_daily_rate,
    'effective_from', p_effective_from,
    'effective_to', case when v_next_from is null then null else v_next_from - 1 end,
    'current_daily_rate', w.daily_rate,
    'row_version', w.row_version
  ) into v_response
  from erp.contractor_workers w
  where w.id = p_worker_id;

  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

create table if not exists erp.worker_employment_periods (
  id uuid primary key default gen_random_uuid(),
  worker_id uuid not null references erp.contractor_workers(id),
  started_on date not null,
  ended_on date,
  start_reason text not null check (btrim(start_reason) <> ''),
  end_reason text,
  created_by uuid references erp.app_users(id),
  ended_by uuid references erp.app_users(id),
  created_at timestamptz not null default clock_timestamp(),
  ended_at timestamptz,
  constraint worker_employment_periods_dates_check
    check (ended_on is null or ended_on >= started_on),
  constraint worker_employment_periods_end_reason_check
    check ((ended_on is null and end_reason is null)
      or (ended_on is not null and btrim(coalesce(end_reason, '')) <> '')),
  constraint worker_employment_periods_worker_start_key
    unique (worker_id, started_on)
);

create index if not exists idx_worker_employment_periods_lookup
  on erp.worker_employment_periods(worker_id, started_on desc);

create or replace function erp.guard_worker_employment_period()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
declare
  v_worker_id uuid := case when tg_op = 'DELETE' then old.worker_id else new.worker_id end;
begin
  if current_setting('app.worker_employment_write', true) is distinct from 'on' then
    raise exception 'Worker employment history is write-protected; use erp_save_worker_roster_v1';
  end if;
  if tg_op = 'DELETE' then
    raise exception 'Worker employment history cannot be deleted';
  end if;
  if tg_op = 'UPDATE'
     and (new.worker_id, new.started_on, new.start_reason, new.created_by, new.created_at)
         is distinct from
         (old.worker_id, old.started_on, old.start_reason, old.created_by, old.created_at) then
    raise exception 'Existing employment starts are immutable; only the stop fact may be added';
  end if;

  perform pg_advisory_xact_lock(hashtextextended('WORKER_EMPLOYMENT|' || v_worker_id::text, 0));
  if exists (
    select 1
    from erp.worker_employment_periods e
    where e.worker_id = v_worker_id
      and e.id <> new.id
      and daterange(e.started_on, coalesce(e.ended_on + 1, 'infinity'::date), '[)')
          && daterange(new.started_on, coalesce(new.ended_on + 1, 'infinity'::date), '[)')
  ) then
    raise exception 'Worker employment periods cannot overlap';
  end if;
  return new;
end;
$function$;

drop trigger if exists trg_guard_worker_employment_period
  on erp.worker_employment_periods;
create trigger trg_guard_worker_employment_period
before insert or update or delete on erp.worker_employment_periods
for each row execute function erp.guard_worker_employment_period();

drop trigger if exists trg_audit_worker_employment_periods
  on erp.worker_employment_periods;
create trigger trg_audit_worker_employment_periods
after insert or update or delete on erp.worker_employment_periods
for each row execute function erp.audit_row_change();

select set_config('app.worker_employment_write', 'on', true);

insert into erp.worker_employment_periods(
  worker_id, started_on, ended_on, start_reason, end_reason, created_by, ended_by, ended_at
)
select
  w.id,
  least(
    coalesce(w.joined_at, 'infinity'::date),
    coalesce((select min(a.attendance_date) from erp.attendance_records a where a.worker_id = w.id), 'infinity'::date),
    coalesce(w.left_at, 'infinity'::date),
    coalesce(w.created_at::date, current_date)
  ),
  w.left_at,
  'v2.6.12 baseline employment episode; no attendance/payroll history changed',
  case when w.left_at is null then null else 'Legacy stop date copied from contractor_workers.left_at' end,
  w.created_by,
  case when w.left_at is null then null else w.updated_by end,
  case when w.left_at is null then null else coalesce(w.updated_at, clock_timestamp()) end
from erp.contractor_workers w
where not exists (
  select 1 from erp.worker_employment_periods e where e.worker_id = w.id
)
on conflict (worker_id, started_on) do nothing;

select set_config('app.worker_employment_write', 'off', true);

create or replace function erp.worker_is_employed_on(
  p_worker_id uuid,
  p_effective_date date
)
returns boolean
language sql
stable
security invoker
set search_path = erp, public, pg_temp
as $function$
  select exists (
    select 1
    from erp.worker_employment_periods e
    where e.worker_id = p_worker_id
      and p_effective_date >= e.started_on
      and (e.ended_on is null or p_effective_date <= e.ended_on)
  )
$function$;

create or replace function erp.save_worker_roster_v1(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'save_worker_roster_v1';
  v_hash text;
  v_cached jsonb;
  v_worker_id uuid := nullif(p_payload->>'worker_id', '')::uuid;
  v_contractor_id uuid := nullif(p_payload->>'contractor_id', '')::uuid;
  v_worker_name text := nullif(btrim(p_payload->>'worker_name'), '');
  v_job_description text := nullif(btrim(p_payload->>'job_description'), '');
  v_pay_scheme text := upper(coalesce(nullif(btrim(p_payload->>'pay_scheme'), ''), 'DAILY'));
  v_joined_at date := nullif(p_payload->>'joined_at', '')::date;
  v_left_at date := nullif(p_payload->>'left_at', '')::date;
  v_reactivated_on date := nullif(p_payload->>'reactivated_at', '')::date;
  v_is_active boolean := coalesce((p_payload->>'is_active')::boolean, true);
  v_initial_rate numeric := coalesce((p_payload->>'initial_daily_rate')::numeric, 0);
  v_rate_from date := coalesce(nullif(p_payload->>'rate_effective_from', '')::date, v_joined_at, current_date);
  v_reason text := nullif(btrim(p_payload->>'reason'), '');
  v_existing erp.contractor_workers%rowtype;
  v_response jsonb;
begin
  perform erp.require_owner_admin();

  if v_contractor_id is null or v_worker_name is null
     or v_job_description is null or v_joined_at is null then
    raise exception 'contractor_id, worker_name, job_description, and joined_at are required';
  end if;
  if not exists (
    select 1 from erp.contractors c
    where c.id = v_contractor_id and c.contractor_type = 'MANDOR'
  ) then
    raise exception 'Worker roster contractor must be an existing MANDOR';
  end if;
  if v_reason is null then raise exception 'Worker change reason is required'; end if;
  if v_pay_scheme not in ('DAILY','PIECE','HYBRID','NONE') then
    raise exception 'Unsupported pay_scheme';
  end if;
  if v_left_at is not null and v_is_active then
    raise exception 'An active worker cannot have a stop date; clear left_at or deactivate the worker';
  end if;
  if not v_is_active and v_left_at is null then
    raise exception 'A deactivated worker requires left_at';
  end if;
  if not v_is_active and v_left_at > current_date then
    raise exception 'A worker stop date cannot be in the future because roster status changes immediately';
  end if;
  if v_reactivated_on > current_date then
    raise exception 'reactivated_at cannot be in the future because roster status changes immediately';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'payload', p_payload,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  perform set_config('app.change_reason', v_reason, true);

  if v_worker_id is null then
    if p_expected_version is not null then
      raise exception 'expected_version must be null when creating a worker';
    end if;
    if v_initial_rate < 0 then
      raise exception 'initial_daily_rate cannot be negative';
    end if;
    if v_rate_from > v_joined_at then
      raise exception 'Initial daily rate must cover the worker start date';
    end if;
    if exists (
      select 1
      from erp.attendance_periods p
      where p.contractor_id = v_contractor_id
        and p.status in ('POSTED','CORRECTED')
        and daterange(p.period_start, p.period_end + 1, '[)')
            && daterange(v_joined_at, coalesce(v_left_at + 1, 'infinity'::date), '[)')
    ) then
      raise exception 'A new worker start cannot overlap posted attendance history; reverse/correct roster chronology first';
    end if;

    insert into erp.contractor_workers(
      contractor_id, worker_code, worker_name, job_description, pay_scheme,
      daily_rate, is_active, joined_at, left_at, notes, created_by, updated_by
    ) values (
      v_contractor_id, nullif(btrim(p_payload->>'worker_code'), ''), v_worker_name,
      v_job_description, v_pay_scheme,
      v_initial_rate, v_is_active, v_joined_at, v_left_at,
      nullif(btrim(p_payload->>'notes'), ''),
      erp.current_app_user_id(), erp.current_app_user_id()
    ) returning id into v_worker_id;

    perform set_config('app.worker_rate_write', 'on', true);
    insert into erp.worker_daily_rate_versions(
      worker_id, daily_rate, effective_from, change_reason, created_by
    ) values (
      v_worker_id, v_initial_rate, v_rate_from, v_reason, erp.current_app_user_id()
    );

    perform set_config('app.worker_employment_write', 'on', true);
    insert into erp.worker_employment_periods(
      worker_id, started_on, ended_on, start_reason, end_reason,
      created_by, ended_by, ended_at
    ) values (
      v_worker_id, v_joined_at, v_left_at, v_reason,
      case when v_left_at is null then null else v_reason end,
      erp.current_app_user_id(),
      case when v_left_at is null then null else erp.current_app_user_id() end,
      case when v_left_at is null then null else clock_timestamp() end
    );
  else
    select * into v_existing
    from erp.contractor_workers
    where id = v_worker_id
    for update;

    if v_existing.id is null then raise exception 'Worker not found'; end if;
    if p_expected_version is null or v_existing.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_existing.row_version;
    end if;
    if v_existing.contractor_id <> v_contractor_id then
      raise exception 'A worker cannot be moved between contractors; create a new roster identity';
    end if;
    if v_pay_scheme is distinct from v_existing.pay_scheme and exists (
      select 1
      from erp.attendance_periods p
      join erp.worker_employment_periods e on e.worker_id = v_worker_id
      where p.contractor_id = v_contractor_id
        and p.status in ('POSTED','CORRECTED')
        and daterange(p.period_start, p.period_end + 1, '[)')
            && daterange(e.started_on, coalesce(e.ended_on + 1, 'infinity'::date), '[)')
    ) then
      raise exception 'Worker pay_scheme cannot change across posted attendance history';
    end if;
    if v_joined_at is distinct from v_existing.joined_at then
      raise exception 'Original worker start date is immutable; use employment episodes for reactivation';
    end if;
    if v_joined_at is not null and v_joined_at < (
      select min(r.effective_from)
      from erp.worker_daily_rate_versions r
      where r.worker_id = v_worker_id
    ) then
      raise exception 'Worker start date cannot precede the first daily-rate version';
    end if;
    if exists (
      select 1
      from erp.attendance_records a
      where a.worker_id = v_worker_id
        and (a.attendance_date < v_joined_at
          or (v_left_at is not null and a.attendance_date > v_left_at))
    ) then
      raise exception 'Worker start/stop dates cannot exclude existing attendance history';
    end if;

    perform set_config('app.worker_employment_write', 'on', true);
    if v_existing.is_active and not v_is_active then
      update erp.worker_employment_periods e
      set ended_on = v_left_at,
          end_reason = v_reason,
          ended_by = erp.current_app_user_id(),
          ended_at = clock_timestamp()
      where e.worker_id = v_worker_id and e.ended_on is null;
      if not found then
        raise exception 'Active worker has no open employment episode';
      end if;
    elsif not v_existing.is_active and v_is_active then
      if v_reactivated_on is null then
        raise exception 'reactivated_at is required when activating a stopped worker';
      end if;
      if v_reactivated_on <= coalesce((
        select max(e.ended_on) from erp.worker_employment_periods e where e.worker_id = v_worker_id
      ), '-infinity'::date) then
        raise exception 'reactivated_at must be after the previous employment stop date';
      end if;
      if exists (
        select 1
        from erp.attendance_periods p
        where p.contractor_id = v_contractor_id
          and p.status in ('POSTED','CORRECTED')
          and daterange(p.period_start, p.period_end + 1, '[)')
              && daterange(v_reactivated_on, 'infinity'::date, '[)')
      ) then
        raise exception 'A reactivation start cannot overlap posted attendance history; reverse/correct roster chronology first';
      end if;
      perform erp.require_worker_daily_rate_at(v_worker_id, v_reactivated_on);
      insert into erp.worker_employment_periods(
        worker_id, started_on, start_reason, created_by
      ) values (
        v_worker_id, v_reactivated_on, v_reason, erp.current_app_user_id()
      );
    elsif not v_existing.is_active and not v_is_active
          and v_left_at is distinct from v_existing.left_at then
      raise exception 'Stopped employment date is historical; reactivate then create a new episode';
    end if;

    update erp.contractor_workers
    set worker_code = nullif(btrim(p_payload->>'worker_code'), ''),
        worker_name = v_worker_name,
        job_description = v_job_description,
        pay_scheme = v_pay_scheme,
        is_active = v_is_active,
        joined_at = v_joined_at,
        left_at = v_left_at,
        notes = nullif(btrim(p_payload->>'notes'), ''),
        updated_by = erp.current_app_user_id()
    where id = v_worker_id;
  end if;

  select jsonb_build_object(
    'worker_id', w.id,
    'contractor_id', w.contractor_id,
    'worker_name', w.worker_name,
    'job_description', w.job_description,
    'pay_scheme', w.pay_scheme,
    'daily_rate', erp.worker_daily_rate_at(w.id, current_date),
    'is_active', w.is_active,
    'joined_at', w.joined_at,
    'left_at', w.left_at,
    'reactivated_at', (
      select max(e.started_on) from erp.worker_employment_periods e where e.worker_id = w.id
    ),
    'notes', w.notes,
    'row_version', w.row_version
  ) into v_response
  from erp.contractor_workers w
  where w.id = v_worker_id;

  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

-- ---------------------------------------------------------------------------
-- 2. Attendance period/header lifecycle and immutable payroll snapshots
-- ---------------------------------------------------------------------------

create table if not exists erp.attendance_periods (
  id uuid primary key default gen_random_uuid(),
  period_number varchar(80) not null unique,
  contractor_id uuid not null references erp.contractors(id),
  period_start date not null,
  period_end date not null,
  pay_date date not null,
  status varchar(20) not null default 'DRAFT'
    check (status in ('DRAFT','POSTED','CORRECTED','REVERSED')),
  correction_of_period_id uuid references erp.attendance_periods(id),
  notes text,
  posting_reason text,
  reversal_reason text,
  created_by uuid references erp.app_users(id),
  posted_by uuid references erp.app_users(id),
  reversed_by uuid references erp.app_users(id),
  created_at timestamptz not null default clock_timestamp(),
  updated_at timestamptz not null default clock_timestamp(),
  posted_at timestamptz,
  reversed_at timestamptz,
  row_version bigint not null default 1 check (row_version > 0),
  constraint attendance_periods_dates_check check (period_end >= period_start),
  constraint attendance_periods_correction_self_check
    check (correction_of_period_id is null or correction_of_period_id <> id)
);

create index if not exists idx_attendance_periods_contractor_dates
  on erp.attendance_periods(contractor_id, period_start desc, period_end desc);

create or replace function erp.guard_attendance_period_overlap()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
begin
  perform pg_advisory_xact_lock(hashtextextended('ATTENDANCE_PERIOD|' || new.contractor_id::text, 0));

  if new.status <> 'REVERSED' and exists (
    select 1
    from erp.attendance_periods p
    where p.contractor_id = new.contractor_id
      and p.id <> new.id
      and p.status in ('DRAFT','POSTED')
      and p.id is distinct from new.correction_of_period_id
      and p.correction_of_period_id is distinct from new.id
      and daterange(p.period_start, p.period_end + 1, '[)')
          && daterange(new.period_start, new.period_end + 1, '[)')
  ) then
    raise exception 'Active attendance periods for one contractor cannot overlap';
  end if;
  return new;
end;
$function$;

create or replace function erp.guard_attendance_period_lifecycle()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
begin
  if tg_op = 'DELETE' then
    raise exception 'Attendance periods cannot be deleted; reverse them with a reason';
  end if;

  if old.status <> 'DRAFT'
     and current_setting('app.attendance_period_lifecycle', true) is distinct from 'on' then
    raise exception 'Posted attendance is immutable; use correction/reversal workflow';
  end if;

  if old.status = 'DRAFT' and new.status not in ('DRAFT','POSTED','REVERSED')
     and current_setting('app.attendance_period_lifecycle', true) is distinct from 'on' then
    raise exception 'Invalid attendance lifecycle transition';
  end if;

  return new;
end;
$function$;

drop trigger if exists trg_00_attendance_period_row_version on erp.attendance_periods;
create trigger trg_00_attendance_period_row_version
before update on erp.attendance_periods
for each row execute function erp.bump_row_version();

drop trigger if exists trg_attendance_period_touch on erp.attendance_periods;
create trigger trg_attendance_period_touch
before update on erp.attendance_periods
for each row execute function erp.touch_updated_at();

drop trigger if exists trg_attendance_period_overlap on erp.attendance_periods;
create trigger trg_attendance_period_overlap
before insert or update of contractor_id, period_start, period_end, status
on erp.attendance_periods
for each row execute function erp.guard_attendance_period_overlap();

drop trigger if exists trg_guard_attendance_period_lifecycle on erp.attendance_periods;
create trigger trg_guard_attendance_period_lifecycle
before update or delete on erp.attendance_periods
for each row execute function erp.guard_attendance_period_lifecycle();

drop trigger if exists trg_audit_attendance_periods on erp.attendance_periods;
create trigger trg_audit_attendance_periods
after insert or update or delete on erp.attendance_periods
for each row execute function erp.audit_row_change();

alter table erp.attendance_records
  add column if not exists attendance_period_id uuid references erp.attendance_periods(id),
  add column if not exists record_lifecycle varchar(20),
  add column if not exists supersedes_attendance_record_id uuid references erp.attendance_records(id),
  add column if not exists row_version bigint not null default 1,
  add column if not exists created_by uuid references erp.app_users(id),
  add column if not exists updated_by uuid references erp.app_users(id),
  add column if not exists change_reason text;

alter table erp.attendance_records
  drop constraint if exists attendance_records_row_version_check;
alter table erp.attendance_records
  add constraint attendance_records_row_version_check check (row_version > 0);

alter table erp.attendance_records
  drop constraint if exists attendance_records_lifecycle_check;
alter table erp.attendance_records
  add constraint attendance_records_lifecycle_check
  check (record_lifecycle is null or record_lifecycle in ('DRAFT','POSTED','CORRECTED','REVERSED'));

-- Legacy rows keep record_lifecycle NULL and remain current posted facts. New
-- periods use explicit lifecycle values so a correction can coexist as DRAFT
-- without rewriting the original attendance fact.
alter table erp.attendance_records
  drop constraint if exists attendance_records_worker_id_attendance_date_key;

create unique index if not exists uq_attendance_current_worker_date
  on erp.attendance_records(worker_id, attendance_date)
  where record_lifecycle is null or record_lifecycle = 'POSTED';

create unique index if not exists uq_attendance_period_worker_date
  on erp.attendance_records(attendance_period_id, worker_id, attendance_date)
  where attendance_period_id is not null;

create index if not exists idx_attendance_records_period_worker_date
  on erp.attendance_records(attendance_period_id, worker_id, attendance_date);

create or replace function erp.guard_attendance_record_period_and_dates()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
declare
  v_worker erp.contractor_workers%rowtype;
  v_period erp.attendance_periods%rowtype;
  v_existing_period_id uuid := case when tg_op = 'INSERT' then null else old.attendance_period_id end;
begin
  if tg_op = 'DELETE' then
    if v_existing_period_id is not null then
      select * into v_period from erp.attendance_periods where id = v_existing_period_id;
      if v_period.status <> 'DRAFT' then
        raise exception 'Posted attendance details cannot be deleted';
      end if;
    end if;
    return old;
  end if;

  if tg_op = 'INSERT' and new.attendance_period_id is null
     and new.record_lifecycle is not null then
    raise exception 'New attendance rows require an attendance period';
  end if;

  select * into v_worker from erp.contractor_workers where id = new.worker_id;
  if v_worker.id is null or v_worker.contractor_id <> new.contractor_id then
    raise exception 'Worker does not belong to selected contractor';
  end if;
  if not erp.worker_is_employed_on(new.worker_id, new.attendance_date) then
    raise exception 'Attendance date is outside the worker employment periods';
  end if;

  if new.attendance_period_id is not null then
    select * into v_period
    from erp.attendance_periods
    where id = new.attendance_period_id;

    if v_period.id is null then raise exception 'Attendance period not found'; end if;
    if v_period.status <> 'DRAFT'
       and current_setting('app.attendance_period_lifecycle', true) is distinct from 'on' then
      raise exception 'Posted attendance details are immutable';
    end if;
    if v_period.contractor_id <> new.contractor_id then
      raise exception 'Attendance record contractor does not match its period';
    end if;
    if new.attendance_date not between v_period.period_start and v_period.period_end then
      raise exception 'Attendance date is outside its period';
    end if;
  end if;

  if tg_op = 'UPDATE' and v_existing_period_id is not null then
    select * into v_period from erp.attendance_periods where id = v_existing_period_id;
    if v_period.status <> 'DRAFT'
       and current_setting('app.attendance_period_lifecycle', true) is distinct from 'on' then
      raise exception 'Posted attendance details are immutable';
    end if;
  end if;

  return new;
end;
$function$;

drop trigger if exists trg_00_attendance_row_version on erp.attendance_records;
create trigger trg_00_attendance_row_version
before update on erp.attendance_records
for each row execute function erp.bump_row_version();

drop trigger if exists trg_guard_attendance_record_period_and_dates
  on erp.attendance_records;
create trigger trg_guard_attendance_record_period_and_dates
before insert or update or delete on erp.attendance_records
for each row execute function erp.guard_attendance_record_period_and_dates();

create or replace function erp.save_attendance_period_v1(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null,
  p_preview_only boolean default false
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'save_attendance_period_v1';
  v_hash text;
  v_cached jsonb;
  v_period_id uuid := nullif(p_payload->>'period_id', '')::uuid;
  v_contractor_id uuid := nullif(p_payload->>'contractor_id', '')::uuid;
  v_period_number text := nullif(btrim(p_payload->>'period_number'), '');
  v_period_start date := nullif(p_payload->>'period_start', '')::date;
  v_period_end date := nullif(p_payload->>'period_end', '')::date;
  v_pay_date date := nullif(p_payload->>'pay_date', '')::date;
  v_correction_of uuid := nullif(p_payload->>'correction_of_period_id', '')::uuid;
  v_reason text := nullif(btrim(p_payload->>'reason'), '');
  v_lines jsonb := coalesce(p_payload->'attendance', '[]'::jsonb);
  v_period erp.attendance_periods%rowtype;
  v_original erp.attendance_periods%rowtype;
  v_preview jsonb;
  v_response jsonb;
  v_duplicate_count integer;
  r record;
begin
  perform erp.require_internal();

  if v_contractor_id is null or v_period_number is null
     or v_period_start is null or v_period_end is null or v_pay_date is null then
    raise exception 'contractor_id, period_number, period_start, period_end, and pay_date are required';
  end if;
  if v_period_end < v_period_start then raise exception 'period_end cannot precede period_start'; end if;
  if v_reason is null then raise exception 'Attendance change reason is required'; end if;
  if jsonb_typeof(v_lines) <> 'array' then raise exception 'attendance must be a JSON array'; end if;
  if v_correction_of is not null then perform erp.require_owner_admin(); end if;
  if not exists (
    select 1 from erp.contractors c
    where c.id = v_contractor_id and c.contractor_type = 'MANDOR'
  ) then
    raise exception 'Attendance contractor must be an existing MANDOR';
  end if;

  select count(*) - count(distinct (x.worker_id::text || '|' || x.attendance_date::text))
  into v_duplicate_count
  from jsonb_to_recordset(v_lines) as x(
    worker_id uuid,
    attendance_date date,
    status text,
    paid_fraction numeric,
    notes text,
    supersedes_attendance_record_id uuid
  );
  if v_duplicate_count > 0 then
    raise exception 'Duplicate worker/date exists in attendance payload';
  end if;

  for r in
    select *
    from jsonb_to_recordset(v_lines) as x(
      worker_id uuid,
      attendance_date date,
      status text,
      paid_fraction numeric,
      notes text,
      supersedes_attendance_record_id uuid
    )
  loop
    if r.worker_id is null or r.attendance_date is null then
      raise exception 'Each attendance line requires worker_id and attendance_date';
    end if;
    if upper(coalesce(r.status, 'PRESENT')) not in
       ('PRESENT','ABSENT','HALF_DAY','SICK','LEAVE','OFF') then
      raise exception 'Unsupported attendance status %', r.status;
    end if;
    if r.paid_fraction is not null and (r.paid_fraction < 0 or r.paid_fraction > 1) then
      raise exception 'paid_fraction must be between 0 and 1';
    end if;
    if upper(coalesce(r.status, 'PRESENT')) = 'HALF_DAY'
       and coalesce(r.paid_fraction, 0.5) > 0.5 then
      raise exception 'HALF_DAY paid_fraction cannot exceed 0.5';
    end if;
    if r.attendance_date not between v_period_start and v_period_end then
      raise exception 'Attendance date % is outside period', r.attendance_date;
    end if;
    if not exists (
      select 1
      from erp.contractor_workers w
      where w.id = r.worker_id
        and w.contractor_id = v_contractor_id
        and erp.worker_is_employed_on(w.id, r.attendance_date)
    ) then
      raise exception 'Worker % is not eligible on %', r.worker_id, r.attendance_date;
    end if;
  end loop;

  select jsonb_build_object(
    'line_count', count(*),
    'paid_day_equivalent', coalesce(sum(
      case
        when upper(coalesce(x.status, 'PRESENT')) in ('ABSENT','OFF') then 0
        when upper(coalesce(x.status, 'PRESENT')) = 'HALF_DAY' then least(coalesce(x.paid_fraction, 0.5), 0.5)
        else coalesce(x.paid_fraction, 1)
      end
    ), 0),
    'estimated_amount', coalesce(sum(
      erp.require_worker_daily_rate_at(x.worker_id, x.attendance_date) *
      case
        when upper(coalesce(x.status, 'PRESENT')) in ('ABSENT','OFF') then 0
        when upper(coalesce(x.status, 'PRESENT')) = 'HALF_DAY' then least(coalesce(x.paid_fraction, 0.5), 0.5)
        else coalesce(x.paid_fraction, 1)
      end
    ), 0),
    'preview_only', p_preview_only
  ) into v_preview
  from jsonb_to_recordset(v_lines) as x(
    worker_id uuid,
    attendance_date date,
    status text,
    paid_fraction numeric,
    notes text,
    supersedes_attendance_record_id uuid
  );

  if p_preview_only then return v_preview; end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'payload', p_payload,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  perform set_config('app.change_reason', v_reason, true);

  if v_period_id is null then
    if p_expected_version is not null then
      raise exception 'expected_version must be null when creating an attendance period';
    end if;

    if v_correction_of is not null then
      select * into v_original
      from erp.attendance_periods
      where id = v_correction_of
      for update;

      if v_original.id is null or v_original.status <> 'POSTED' then
        raise exception 'Correction source must be a POSTED attendance period';
      end if;
      if v_original.contractor_id <> v_contractor_id
         or v_original.period_start <> v_period_start
         or v_original.period_end <> v_period_end then
        raise exception 'Correction must keep contractor and attendance date range';
      end if;
      if exists (
        select 1
        from erp.payroll_attendance_items pai
        join erp.payroll_settlements ps on ps.id = pai.payroll_id
        join erp.attendance_records ar on ar.id = pai.attendance_record_id
        where ar.attendance_period_id = v_original.id
          and ps.status <> 'REVERSED'
      ) then
        raise exception 'Attendance correction requires its consuming payroll to be reversed first';
      end if;
      if exists (
        select 1
        from erp.attendance_records source_row
        where source_row.attendance_period_id = v_original.id
          and not exists (
            select 1
            from jsonb_to_recordset(v_lines) as x(
              worker_id uuid,
              attendance_date date,
              status text,
              paid_fraction numeric,
              notes text,
              supersedes_attendance_record_id uuid
            )
            where x.worker_id = source_row.worker_id
              and x.attendance_date = source_row.attendance_date
              and x.supersedes_attendance_record_id = source_row.id
          )
      ) then
        raise exception 'Correction must explicitly supersede every source attendance row';
      end if;
    end if;

    insert into erp.attendance_periods(
      period_number, contractor_id, period_start, period_end, pay_date,
      correction_of_period_id, notes, created_by
    ) values (
      v_period_number, v_contractor_id, v_period_start, v_period_end, v_pay_date,
      v_correction_of, nullif(btrim(p_payload->>'notes'), ''), erp.current_app_user_id()
    ) returning * into v_period;
    v_period_id := v_period.id;
  else
    select * into v_period
    from erp.attendance_periods
    where id = v_period_id
    for update;

    if v_period.id is null then raise exception 'Attendance period not found'; end if;
    if v_period.status <> 'DRAFT' then
      raise exception 'Only DRAFT attendance can be saved';
    end if;
    if p_expected_version is null or v_period.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_period.row_version;
    end if;
    if v_period.contractor_id <> v_contractor_id then
      raise exception 'Attendance contractor cannot be changed';
    end if;
    if v_period.correction_of_period_id is not null then
      perform erp.require_owner_admin();
      if v_correction_of is distinct from v_period.correction_of_period_id then
        raise exception 'correction_of_period_id cannot change or be omitted while editing a correction';
      end if;
    end if;
    if exists (
      select 1
      from erp.attendance_records a
      where a.attendance_period_id = v_period.id
        and a.attendance_date not between v_period_start and v_period_end
    ) then
      raise exception 'Attendance period cannot shrink while DRAFT rows exist outside the new date range';
    end if;

    update erp.attendance_periods
    set period_number = v_period_number,
        period_start = v_period_start,
        period_end = v_period_end,
        pay_date = v_pay_date,
        notes = nullif(btrim(p_payload->>'notes'), '')
    where id = v_period_id
    returning * into v_period;
  end if;

  if v_period.correction_of_period_id is null and exists (
    select 1
    from jsonb_to_recordset(v_lines) as x(
      worker_id uuid,
      attendance_date date,
      status text,
      paid_fraction numeric,
      notes text,
      supersedes_attendance_record_id uuid
    )
    where x.supersedes_attendance_record_id is not null
  ) then
    raise exception 'Non-correction attendance cannot declare supersedes lineage';
  end if;

  if v_period.correction_of_period_id is not null and exists (
    select 1
    from erp.attendance_records source_row
    where source_row.attendance_period_id = v_period.correction_of_period_id
      and not exists (
        select 1
        from jsonb_to_recordset(v_lines) as x(
          worker_id uuid,
          attendance_date date,
          status text,
          paid_fraction numeric,
          notes text,
          supersedes_attendance_record_id uuid
        )
        where x.worker_id = source_row.worker_id
          and x.attendance_date = source_row.attendance_date
          and x.supersedes_attendance_record_id = source_row.id
      )
  ) then
    raise exception 'Correction must explicitly supersede every source attendance row';
  end if;

  if v_period.correction_of_period_id is not null and exists (
    select 1
    from jsonb_to_recordset(v_lines) as x(
      worker_id uuid,
      attendance_date date,
      status text,
      paid_fraction numeric,
      notes text,
      supersedes_attendance_record_id uuid
    )
    where not exists (
      select 1
      from erp.attendance_records source_row
      where source_row.attendance_period_id = v_period.correction_of_period_id
        and source_row.id = x.supersedes_attendance_record_id
        and source_row.worker_id = x.worker_id
        and source_row.attendance_date = x.attendance_date
    )
  ) then
    raise exception 'Every correction line must supersede its exact source worker/date row';
  end if;

  for r in
    select *
    from jsonb_to_recordset(v_lines) as x(
      worker_id uuid,
      attendance_date date,
      status text,
      paid_fraction numeric,
      notes text,
      supersedes_attendance_record_id uuid
    )
  loop
    insert into erp.attendance_records(
      contractor_id, worker_id, attendance_date, status, paid_fraction, notes,
      attendance_period_id, record_lifecycle, supersedes_attendance_record_id,
      created_by, updated_by, change_reason
    ) values (
      v_contractor_id, r.worker_id, r.attendance_date,
      upper(coalesce(r.status, 'PRESENT')),
      case
        when upper(coalesce(r.status, 'PRESENT')) in ('ABSENT','OFF') then 0
        when upper(coalesce(r.status, 'PRESENT')) = 'HALF_DAY'
          then least(coalesce(r.paid_fraction, 0.5), 0.5)
        else coalesce(r.paid_fraction, 1)
      end,
      r.notes,
      v_period_id, 'DRAFT', r.supersedes_attendance_record_id,
      erp.current_app_user_id(), erp.current_app_user_id(), v_reason
    )
    on conflict (attendance_period_id, worker_id, attendance_date)
      where attendance_period_id is not null
    do update set
      status = excluded.status,
      paid_fraction = excluded.paid_fraction,
      notes = excluded.notes,
      supersedes_attendance_record_id = excluded.supersedes_attendance_record_id,
      updated_by = erp.current_app_user_id(),
      change_reason = v_reason;
  end loop;

  -- The payload is a full DRAFT matrix snapshot. A missing cell is unrecorded,
  -- never silently inferred as ABSENT/OFF. DRAFT-only removal is audited by the
  -- existing row audit trigger; POSTED history remains undeletable.
  delete from erp.attendance_records a
  where a.attendance_period_id = v_period_id
    and a.record_lifecycle = 'DRAFT'
    and not exists (
      select 1
      from jsonb_to_recordset(v_lines) as x(
        worker_id uuid,
        attendance_date date,
        status text,
        paid_fraction numeric,
        notes text,
        supersedes_attendance_record_id uuid
      )
      where x.worker_id = a.worker_id
        and x.attendance_date = a.attendance_date
    );

  -- Detail writes are part of the period document and advance its optimistic
  -- lock even when header fields did not change.
  if v_period.row_version = coalesce(p_expected_version, v_period.row_version) then
    update erp.attendance_periods
    set updated_at = clock_timestamp()
    where id = v_period_id
    returning * into v_period;
  else
    select * into v_period from erp.attendance_periods where id = v_period_id;
  end if;

  v_response := jsonb_build_object(
    'period_id', v_period.id,
    'period_number', v_period.period_number,
    'status', v_period.status,
    'row_version', v_period.row_version,
    'preview', v_preview - 'preview_only',
    'attendance_required', (
      select c.attendance_required from erp.contractors c where c.id = v_contractor_id
    )
  );

  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

create or replace function erp.post_attendance_period_v1(
  p_period_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'post_attendance_period_v1';
  v_hash text;
  v_cached jsonb;
  v_period erp.attendance_periods%rowtype;
  v_original erp.attendance_periods%rowtype;
  v_response jsonb;
  v_missing_count bigint;
  v_uncovered_rate_count bigint;
begin
  perform erp.require_internal();
  if p_period_id is null or p_expected_version is null then
    raise exception 'period_id and expected_version are required';
  end if;
  if coalesce(btrim(p_reason), '') = '' then
    raise exception 'Attendance posting reason is required';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'period_id', p_period_id,
    'reason', p_reason,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_period
  from erp.attendance_periods
  where id = p_period_id
  for update;

  if v_period.id is null then raise exception 'Attendance period not found'; end if;
  if v_period.status <> 'DRAFT' then raise exception 'Only DRAFT attendance can be posted'; end if;
  if v_period.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_period.row_version;
  end if;

  if v_period.correction_of_period_id is not null then
    perform erp.require_owner_admin();
  end if;

  if (select attendance_required from erp.contractors where id = v_period.contractor_id)
     and not exists (
       select 1 from erp.attendance_records a where a.attendance_period_id = v_period.id
     ) then
    raise exception 'Attendance-required contractor needs attendance details before posting';
  end if;

  if (select attendance_required from erp.contractors where id = v_period.contractor_id) then
    select count(*) into v_missing_count
    from erp.contractor_workers w
    cross join lateral generate_series(
      v_period.period_start::timestamptz,
      v_period.period_end::timestamptz,
      interval '1 day'
    ) day_value
    where w.contractor_id = v_period.contractor_id
      and w.pay_scheme in ('DAILY','HYBRID')
      and erp.worker_is_employed_on(w.id, day_value::date)
      and not exists (
        select 1
        from erp.attendance_records a
        where a.attendance_period_id = v_period.id
          and a.worker_id = w.id
          and a.attendance_date = day_value::date
          and a.record_lifecycle = 'DRAFT'
      );

    if v_missing_count > 0 then
      raise exception 'Attendance period has % unrecorded eligible worker/day cells; blanks are not ABSENT or OFF',
        v_missing_count;
    end if;

    select count(*) into v_uncovered_rate_count
    from erp.contractor_workers w
    cross join lateral generate_series(
      v_period.period_start::timestamptz,
      v_period.period_end::timestamptz,
      interval '1 day'
    ) day_value
    where w.contractor_id = v_period.contractor_id
      and w.pay_scheme in ('DAILY','HYBRID')
      and erp.worker_is_employed_on(w.id, day_value::date)
      and erp.worker_daily_rate_at(w.id, day_value::date) is null;

    if v_uncovered_rate_count > 0 then
      raise exception 'Attendance period has % eligible worker/day cells without an effective daily rate',
        v_uncovered_rate_count;
    end if;
  end if;

  perform set_config('app.change_reason', p_reason, true);
  perform set_config('app.attendance_period_lifecycle', 'on', true);

  if v_period.correction_of_period_id is not null then
    select * into v_original
    from erp.attendance_periods
    where id = v_period.correction_of_period_id
    for update;

    if v_original.status <> 'POSTED' then
      raise exception 'Correction source is no longer POSTED';
    end if;
    if exists (
      select 1
      from erp.payroll_attendance_items pai
      join erp.payroll_settlements ps on ps.id = pai.payroll_id
      join erp.attendance_records ar on ar.id = pai.attendance_record_id
      where ar.attendance_period_id = v_original.id
        and ps.status <> 'REVERSED'
    ) then
      raise exception 'Attendance correction requires its consuming payroll to be reversed first';
    end if;
    if exists (
      select 1
      from erp.attendance_records source_row
      where source_row.attendance_period_id = v_original.id
        and not exists (
          select 1
          from erp.attendance_records replacement
          where replacement.attendance_period_id = v_period.id
            and replacement.worker_id = source_row.worker_id
            and replacement.attendance_date = source_row.attendance_date
            and replacement.supersedes_attendance_record_id = source_row.id
        )
    ) then
      raise exception 'Correction does not explicitly supersede every source attendance row';
    end if;

    update erp.attendance_records
    set record_lifecycle = 'CORRECTED',
        change_reason = p_reason,
        updated_by = erp.current_app_user_id()
    where attendance_period_id = v_original.id;

    update erp.attendance_periods
    set status = 'CORRECTED', posting_reason = p_reason
    where id = v_original.id;
  end if;

  if exists (
    select 1
    from erp.attendance_records draft_row
    join erp.attendance_records current_row
      on current_row.worker_id = draft_row.worker_id
     and current_row.attendance_date = draft_row.attendance_date
     and current_row.id <> draft_row.id
     and coalesce(current_row.record_lifecycle, 'POSTED') = 'POSTED'
    where draft_row.attendance_period_id = v_period.id
  ) then
    raise exception 'Another posted attendance fact already exists for worker/date';
  end if;

  update erp.attendance_records
  set record_lifecycle = 'POSTED',
      change_reason = p_reason,
      updated_by = erp.current_app_user_id()
  where attendance_period_id = v_period.id;

  update erp.attendance_periods
  set status = 'POSTED',
      posting_reason = p_reason,
      posted_at = clock_timestamp(),
      posted_by = erp.current_app_user_id()
  where id = v_period.id
  returning * into v_period;

  v_response := jsonb_build_object(
    'period_id', v_period.id,
    'status', v_period.status,
    'row_version', v_period.row_version,
    'posted_at', v_period.posted_at,
    'correction_of_period_id', v_period.correction_of_period_id
  );
  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

create or replace function erp.reverse_attendance_period_v1(
  p_period_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'reverse_attendance_period_v1';
  v_hash text;
  v_cached jsonb;
  v_period erp.attendance_periods%rowtype;
  v_source erp.attendance_periods%rowtype;
  v_response jsonb;
begin
  perform erp.require_owner_admin();
  if p_period_id is null or p_expected_version is null then
    raise exception 'period_id and expected_version are required';
  end if;
  if coalesce(btrim(p_reason), '') = '' then
    raise exception 'Attendance reversal reason is required';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'period_id', p_period_id,
    'reason', p_reason,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_period
  from erp.attendance_periods
  where id = p_period_id
  for update;

  if v_period.id is null then raise exception 'Attendance period not found'; end if;
  if v_period.status <> 'POSTED' then raise exception 'Only POSTED attendance can be reversed'; end if;
  if v_period.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_period.row_version;
  end if;
  if exists (
    select 1
    from erp.payroll_attendance_items pai
    join erp.payroll_settlements ps on ps.id = pai.payroll_id
    join erp.attendance_records ar on ar.id = pai.attendance_record_id
    where ar.attendance_period_id = v_period.id
      and ps.status <> 'REVERSED'
  ) then
    raise exception 'Attendance reversal requires its consuming payroll to be reversed first';
  end if;

  perform set_config('app.change_reason', p_reason, true);
  perform set_config('app.attendance_period_lifecycle', 'on', true);

  if v_period.correction_of_period_id is not null then
    select * into v_source
    from erp.attendance_periods
    where id = v_period.correction_of_period_id
    for update;
    if v_source.id is null or v_source.status <> 'CORRECTED' then
      raise exception 'Correction source cannot be restored from status %', v_source.status;
    end if;
  end if;

  update erp.attendance_records
  set record_lifecycle = 'REVERSED',
      change_reason = p_reason,
      updated_by = erp.current_app_user_id()
  where attendance_period_id = v_period.id;

  if v_source.id is not null then
    update erp.attendance_records
    set record_lifecycle = 'POSTED',
        change_reason = 'Restored after correction reversal: ' || p_reason,
        updated_by = erp.current_app_user_id()
    where attendance_period_id = v_source.id
      and record_lifecycle = 'CORRECTED';

    update erp.attendance_periods
    set status = 'POSTED',
        posting_reason = 'Restored after correction reversal: ' || p_reason
    where id = v_source.id;
  end if;

  update erp.attendance_periods
  set status = 'REVERSED',
      reversal_reason = p_reason,
      reversed_at = clock_timestamp(),
      reversed_by = erp.current_app_user_id()
  where id = v_period.id
  returning * into v_period;

  v_response := jsonb_build_object(
    'period_id', v_period.id,
    'status', v_period.status,
    'row_version', v_period.row_version,
    'reversed_at', v_period.reversed_at,
    'restored_source_period_id', v_source.id
  );
  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

alter table erp.payroll_attendance_items
  add column if not exists worker_rate_version_id uuid references erp.worker_daily_rate_versions(id),
  add column if not exists attendance_date_snapshot date,
  add column if not exists worker_name_snapshot text,
  add column if not exists job_description_snapshot text;

create index if not exists idx_payroll_attendance_rate_version
  on erp.payroll_attendance_items(worker_rate_version_id)
  where worker_rate_version_id is not null;

-- Replace only the attendance-rate lookup in the existing payroll builder.
-- Every other payroll/HPP/deduction rule remains byte-for-byte equivalent in
-- behavior to the audited implementation.
create or replace function erp.populate_payroll_draft(p_payroll_id uuid)
returns void
language plpgsql
security definer
set search_path = erp, public, pg_temp
as $function$
declare
  p erp.payroll_settlements%rowtype;
  r record;
  v_remaining numeric(24,6);
  v_apply numeric(24,6);
  v_budget numeric(24,6) := 0;
  v_attendance_required boolean;
begin
  perform erp.require_internal();
  select * into p from erp.payroll_settlements where id = p_payroll_id for update;
  if p.id is null or p.status not in ('DRAFT','CALCULATED','REVIEW') then
    raise exception 'Payroll draft cannot be rebuilt in current status';
  end if;
  perform pg_advisory_xact_lock(hashtextextended(p.contractor_id::text, 0));

  delete from erp.payroll_work_items where payroll_id = p.id;
  delete from erp.payroll_attendance_items where payroll_id = p.id;
  delete from erp.payroll_deductions
    where payroll_id = p.id and contractor_issue_item_id is not null;
  delete from erp.payroll_reimbursements
    where payroll_id = p.id and source_type = 'ACCESSORY_BOM';

  insert into erp.payroll_work_items(
    payroll_id, po_id, work_component_id, source_type, source_id,
    qty_payable, rate_snapshot
  )
  select p.id, e.po_id, e.work_component_id, e.source_type, e.source_id,
         e.remaining_qty, e.rate_snapshot
  from erp.v_payroll_eligible_work_lines e
  where e.contractor_id = p.contractor_id
    and e.eligible_at::date <= p.period_end
    and e.remaining_qty > 0
  order by e.eligible_at, e.source_type, e.source_id;

  select attendance_required into v_attendance_required
  from erp.contractors where id = p.contractor_id;

  if v_attendance_required then
    insert into erp.payroll_attendance_items(
      payroll_id, worker_id, attendance_record_id,
      paid_fraction_snapshot, daily_rate_snapshot,
      worker_rate_version_id, attendance_date_snapshot,
      worker_name_snapshot, job_description_snapshot
    )
    select
      p.id,
      ar.worker_id,
      ar.id,
      ar.paid_fraction,
      erp.require_worker_daily_rate_at(ar.worker_id, ar.attendance_date),
      erp.worker_daily_rate_version_id_at(ar.worker_id, ar.attendance_date),
      ar.attendance_date,
      cw.worker_name,
      cw.job_description
    from erp.attendance_records ar
    join erp.contractor_workers cw on cw.id = ar.worker_id
    left join erp.attendance_periods ap on ap.id = ar.attendance_period_id
    where ar.contractor_id = p.contractor_id
      and ar.attendance_date between p.period_start and p.period_end
      and cw.pay_scheme in ('DAILY','HYBRID')
      and ar.paid_fraction > 0
      and (ar.attendance_period_id is null or ap.status = 'POSTED')
      and coalesce(ar.record_lifecycle, 'POSTED') = 'POSTED'
    order by ar.attendance_date, ar.id;
  end if;

  insert into erp.payroll_reimbursements(
    payroll_id, amount, description, source_type, source_id, po_id
  )
  select p.id, round(e.amount, 2),
         'Accessory reimbursement from accepted GOOD FG',
         'ACCESSORY_BOM', e.id, e.po_id
  from erp.contractor_accessory_reimbursement_entitlements e
  where e.contractor_id = p.contractor_id
    and e.amount > 0
    and e.payroll_status <> 'CANCELLED'
    and e.physical_at::date <= p.period_end
    and not exists (
      select 1
      from erp.payroll_reimbursements pr
      join erp.payroll_settlements ps2 on ps2.id = pr.payroll_id
      where pr.source_type = 'ACCESSORY_BOM'
        and pr.source_id = e.id
        and ps2.id <> p.id
        and ps2.status <> 'REVERSED'
    )
  order by e.physical_at, e.id;

  update erp.contractor_accessory_reimbursement_entitlements e
  set payroll_status = 'ALLOCATED'
  where exists (
    select 1
    from erp.payroll_reimbursements pr
    where pr.payroll_id = p.id
      and pr.source_type = 'ACCESSORY_BOM'
      and pr.source_id = e.id
  );

  perform erp.recalculate_payroll(p.id);
  select greatest(net_payable, 0) into v_budget
  from erp.payroll_settlements where id = p.id;

  for r in
    select
      cmii.id,
      cmii.total_receivable,
      cmi.physical_at,
      cmii.total_receivable - coalesce((
        select sum(pd.amount)
        from erp.payroll_deductions pd
        join erp.payroll_settlements ps2 on ps2.id = pd.payroll_id
        where pd.contractor_issue_item_id = cmii.id
          and ps2.id <> p.id
          and ps2.status <> 'REVERSED'
      ), 0) as remaining_amount
    from erp.contractor_material_issue_items cmii
    join erp.contractor_material_issues cmi on cmi.id = cmii.issue_id
    where cmi.contractor_id = p.contractor_id
      and cmi.status = 'POSTED'
      and cmi.physical_at::date <= p.period_end
    order by cmi.physical_at, cmii.id
  loop
    exit when v_budget <= 0;
    v_remaining := greatest(r.remaining_amount, 0);
    v_apply := least(v_remaining, v_budget);
    if v_apply > 0 then
      insert into erp.payroll_deductions(
        payroll_id, deduction_type, contractor_issue_item_id, amount, notes
      ) values (
        p.id, 'MATERIAL_KASBON', r.id, round(v_apply, 2),
        'Auto capped outstanding material/accessory kasbon (FIFO)'
      );
      v_budget := greatest(v_budget - round(v_apply, 2), 0);
    end if;
  end loop;

  perform erp.recalculate_payroll(p.id);
  for r in
    select cmii.id
    from erp.contractor_material_issue_items cmii
    join erp.contractor_material_issues cmi on cmi.id = cmii.issue_id
    where cmi.contractor_id = p.contractor_id
      and cmi.status = 'POSTED'
  loop
    perform erp.refresh_contractor_issue_payroll_status(r.id);
  end loop;
end;
$function$;

-- ---------------------------------------------------------------------------
-- 3. Versioned stock policy + immutable explainability snapshots
-- ---------------------------------------------------------------------------

create table if not exists erp.stock_policy_versions (
  id uuid primary key default gen_random_uuid(),
  subject_type varchar(20) not null check (subject_type in ('FG','MATERIAL')),
  product_id uuid references erp.products(id),
  material_id uuid references erp.materials(id),
  location_id uuid references erp.locations(id),
  basis_source varchar(30) not null
    check (basis_source in ('BELUM_DIATUR','MANUAL','REKOMENDASI_SISTEM')),
  manual_reorder_point_qty numeric(24,6),
  manual_target_stock_qty numeric(24,6),
  minimum_sample_days integer not null default 30 check (minimum_sample_days > 0),
  effective_from date not null,
  effective_to date,
  reason text not null check (btrim(reason) <> ''),
  formula_version text not null default 'STOCK_EXPLAINABILITY_V1',
  approved_by uuid references erp.app_users(id),
  created_by uuid references erp.app_users(id),
  created_at timestamptz not null default clock_timestamp(),
  constraint stock_policy_subject_check check (
    (subject_type = 'FG' and product_id is not null and material_id is null)
    or (subject_type = 'MATERIAL' and material_id is not null and product_id is null)
  ),
  constraint stock_policy_dates_check
    check (effective_to is null or effective_to >= effective_from),
  constraint stock_policy_manual_values_check check (
    (basis_source = 'MANUAL'
      and manual_reorder_point_qty is not null
      and manual_target_stock_qty is not null
      and manual_reorder_point_qty >= 0
      and manual_target_stock_qty >= manual_reorder_point_qty)
    or (basis_source <> 'MANUAL'
      and manual_reorder_point_qty is null
      and manual_target_stock_qty is null)
  )
);

create index if not exists idx_stock_policy_fg_lookup
  on erp.stock_policy_versions(product_id, location_id, effective_from desc)
  where subject_type = 'FG';
create index if not exists idx_stock_policy_material_lookup
  on erp.stock_policy_versions(material_id, location_id, effective_from desc)
  where subject_type = 'MATERIAL';

create or replace function erp.guard_stock_policy_version()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
declare
  v_key text;
begin
  if current_setting('app.stock_policy_write', true) is distinct from 'on' then
    raise exception 'Stock policy history is write-protected; use erp_set_fg_stock_policy_v1';
  end if;

  if tg_op = 'DELETE' then
    raise exception 'Stock policy history cannot be deleted';
  end if;

  if tg_op = 'UPDATE'
     and (new.subject_type, new.product_id, new.material_id, new.location_id,
          new.basis_source, new.manual_reorder_point_qty,
          new.manual_target_stock_qty, new.minimum_sample_days,
          new.effective_from, new.reason, new.formula_version,
          new.approved_by, new.created_by, new.created_at)
         is distinct from
         (old.subject_type, old.product_id, old.material_id, old.location_id,
          old.basis_source, old.manual_reorder_point_qty,
          old.manual_target_stock_qty, old.minimum_sample_days,
          old.effective_from, old.reason, old.formula_version,
          old.approved_by, old.created_by, old.created_at) then
    raise exception 'Existing stock policy facts are immutable; only effective_to may be closed';
  end if;

  v_key := new.subject_type || '|' ||
    coalesce(new.product_id::text, new.material_id::text) || '|' ||
    coalesce(new.location_id::text, '*');
  perform pg_advisory_xact_lock(hashtextextended('STOCK_POLICY|' || v_key, 0));

  if exists (
    select 1
    from erp.stock_policy_versions p
    where p.subject_type = new.subject_type
      and p.id <> new.id
      and p.product_id is not distinct from new.product_id
      and p.material_id is not distinct from new.material_id
      and p.location_id is not distinct from new.location_id
      and daterange(p.effective_from, coalesce(p.effective_to + 1, 'infinity'::date), '[)')
          && daterange(new.effective_from, coalesce(new.effective_to + 1, 'infinity'::date), '[)')
  ) then
    raise exception 'Stock policy periods cannot overlap for the same item/location';
  end if;

  return new;
end;
$function$;

drop trigger if exists trg_guard_stock_policy_version on erp.stock_policy_versions;
create trigger trg_guard_stock_policy_version
before insert or update or delete on erp.stock_policy_versions
for each row execute function erp.guard_stock_policy_version();

drop trigger if exists trg_audit_stock_policy_versions on erp.stock_policy_versions;
create trigger trg_audit_stock_policy_versions
after insert or update or delete on erp.stock_policy_versions
for each row execute function erp.audit_row_change();

create or replace function erp.set_fg_stock_policy_v1(
  p_product_id uuid,
  p_location_id uuid,
  p_basis_source text,
  p_manual_reorder_point_qty numeric,
  p_manual_target_stock_qty numeric,
  p_minimum_sample_days integer,
  p_effective_from date,
  p_reason text,
  p_expected_policy_id uuid,
  p_client_request_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'set_fg_stock_policy_v1';
  v_basis text := upper(coalesce(nullif(btrim(p_basis_source), ''), 'BELUM_DIATUR'));
  v_hash text;
  v_cached jsonb;
  v_current erp.stock_policy_versions%rowtype;
  v_next_from date;
  v_new erp.stock_policy_versions%rowtype;
  v_response jsonb;
begin
  perform erp.require_owner_admin();

  if p_product_id is null or p_effective_from is null then
    raise exception 'product_id and effective_from are required';
  end if;
  if not exists (select 1 from erp.products p where p.id = p_product_id) then
    raise exception 'Finished-good product not found';
  end if;
  if p_location_id is not null and not exists (
    select 1 from erp.locations l
    where l.id = p_location_id and l.location_type = 'FG_WAREHOUSE'
  ) then
    raise exception 'FG stock policy location must be an FG warehouse';
  end if;
  if v_basis not in ('BELUM_DIATUR','MANUAL') then
    raise exception 'REKOMENDASI_SISTEM cannot be selected by a user before an authoritative recommendation snapshot exists';
  end if;
  if v_basis = 'MANUAL' and (
    p_manual_reorder_point_qty is null or p_manual_target_stock_qty is null
    or p_manual_reorder_point_qty < 0
    or p_manual_target_stock_qty < p_manual_reorder_point_qty
  ) then
    raise exception 'Manual policy requires target_stock >= reorder_point >= 0';
  end if;
  if v_basis = 'BELUM_DIATUR' and (
    p_manual_reorder_point_qty is not null or p_manual_target_stock_qty is not null
  ) then
    raise exception 'BELUM_DIATUR cannot carry manual threshold values';
  end if;
  if coalesce(p_minimum_sample_days, 30) <= 0 then
    raise exception 'minimum_sample_days must be positive';
  end if;
  if coalesce(btrim(p_reason), '') = '' then
    raise exception 'Stock policy reason is required';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'product_id', p_product_id,
    'location_id', p_location_id,
    'basis_source', v_basis,
    'manual_reorder_point_qty', p_manual_reorder_point_qty,
    'manual_target_stock_qty', p_manual_target_stock_qty,
    'minimum_sample_days', coalesce(p_minimum_sample_days, 30),
    'effective_from', p_effective_from,
    'reason', p_reason,
    'expected_policy_id', p_expected_policy_id
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  perform pg_advisory_xact_lock(hashtextextended(
    'STOCK_POLICY|FG|' || p_product_id::text || '|' || coalesce(p_location_id::text, '*'), 0
  ));

  select * into v_current
  from erp.stock_policy_versions p
  where p.subject_type = 'FG'
    and p.product_id = p_product_id
    and p.location_id is not distinct from p_location_id
    and p_effective_from >= p.effective_from
    and (p.effective_to is null or p_effective_from <= p.effective_to)
  order by p.effective_from desc, p.id desc
  limit 1
  for update;

  if v_current.id is distinct from p_expected_policy_id then
    raise exception 'STALE_POLICY expected %, current %', p_expected_policy_id, v_current.id;
  end if;
  if v_current.effective_from = p_effective_from then
    raise exception 'A stock policy already starts on this date; create a later effective version';
  end if;

  perform set_config('app.change_reason', p_reason, true);
  perform set_config('app.stock_policy_write', 'on', true);

  select min(p.effective_from) into v_next_from
  from erp.stock_policy_versions p
  where p.subject_type = 'FG'
    and p.product_id = p_product_id
    and p.location_id is not distinct from p_location_id
    and p.effective_from > p_effective_from;

  update erp.stock_policy_versions p
  set effective_to = p_effective_from - 1
  where p.subject_type = 'FG'
    and p.product_id = p_product_id
    and p.location_id is not distinct from p_location_id
    and p.effective_from < p_effective_from
    and (p.effective_to is null or p.effective_to >= p_effective_from);

  insert into erp.stock_policy_versions(
    subject_type, product_id, location_id, basis_source,
    manual_reorder_point_qty, manual_target_stock_qty, minimum_sample_days,
    effective_from, effective_to, reason, approved_by, created_by
  ) values (
    'FG', p_product_id, p_location_id, v_basis,
    case when v_basis = 'MANUAL' then p_manual_reorder_point_qty else null end,
    case when v_basis = 'MANUAL' then p_manual_target_stock_qty else null end,
    coalesce(p_minimum_sample_days, 30), p_effective_from,
    case when v_next_from is null then null else v_next_from - 1 end,
    p_reason, erp.current_app_user_id(), erp.current_app_user_id()
  ) returning * into v_new;

  v_response := jsonb_build_object(
    'policy_version_id', v_new.id,
    'product_id', v_new.product_id,
    'location_id', v_new.location_id,
    'basis_source', v_new.basis_source,
    'manual_reorder_point_qty', v_new.manual_reorder_point_qty,
    'manual_target_stock_qty', v_new.manual_target_stock_qty,
    'minimum_sample_days', v_new.minimum_sample_days,
    'effective_from', v_new.effective_from,
    'effective_to', v_new.effective_to,
    'formula_version', v_new.formula_version
  );
  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

create table if not exists erp.stock_explainability_snapshots (
  id uuid primary key default gen_random_uuid(),
  subject_type varchar(20) not null check (subject_type in ('FG','MATERIAL')),
  product_id uuid references erp.products(id),
  material_id uuid references erp.materials(id),
  location_id uuid references erp.locations(id),
  calculated_at timestamptz not null default clock_timestamp(),
  source_as_of timestamptz not null,
  health_status varchar(30) not null check (health_status in (
    'BELUM_CUKUP_DATA','AMAN','RENDAH','PERLU_PESAN','PERLU_PRODUKSI','KRITIS'
  )),
  basis_source varchar(30) not null check (basis_source in (
    'BELUM_DIATUR','MANUAL','REKOMENDASI_SISTEM'
  )),
  policy_version_id uuid references erp.stock_policy_versions(id),
  physical_stock_qty numeric(24,6) not null,
  reserved_qty numeric(24,6) not null default 0,
  available_stock_qty numeric(24,6) not null,
  confirmed_incoming_qty numeric(24,6),
  projected_stock_qty numeric(24,6),
  average_daily_demand numeric(24,6),
  data_period_start date,
  data_period_end date,
  available_days integer,
  stockout_days integer,
  lead_time_days numeric(12,3),
  safety_stock_qty numeric(24,6),
  reorder_point_qty numeric(24,6),
  target_stock_qty numeric(24,6),
  recommended_qty numeric(24,6),
  confidence numeric(7,6),
  formula_version text not null,
  formula_expression text not null,
  source_manifest jsonb not null default '{}'::jsonb,
  calculation_key text not null unique,
  created_by uuid references erp.app_users(id),
  constraint stock_explainability_subject_check check (
    (subject_type = 'FG' and product_id is not null and material_id is null)
    or (subject_type = 'MATERIAL' and material_id is not null and product_id is null)
  ),
  constraint stock_explainability_balance_check
    check (physical_stock_qty = available_stock_qty + reserved_qty),
  constraint stock_explainability_nonnegative_check check (
    physical_stock_qty >= 0 and reserved_qty >= 0 and available_stock_qty >= 0
    and (confirmed_incoming_qty is null or confirmed_incoming_qty >= 0)
    and (recommended_qty is null or recommended_qty >= 0)
    and (confidence is null or (confidence >= 0 and confidence <= 1))
  ),
  constraint stock_explainability_projected_check check (
    projected_stock_qty is null
    or (confirmed_incoming_qty is not null
        and projected_stock_qty = available_stock_qty + confirmed_incoming_qty)
  ),
  constraint stock_explainability_period_check check (
    data_period_end is null or data_period_start is null
    or data_period_end >= data_period_start
  )
);

create index if not exists idx_stock_explainability_fg_latest
  on erp.stock_explainability_snapshots(product_id, location_id, calculated_at desc)
  where subject_type = 'FG';

create or replace function erp.guard_stock_explainability_immutable()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
begin
  raise exception 'Stock explainability snapshots are immutable; write a new snapshot';
end;
$function$;

drop trigger if exists trg_guard_stock_explainability_immutable
  on erp.stock_explainability_snapshots;
create trigger trg_guard_stock_explainability_immutable
before update or delete on erp.stock_explainability_snapshots
for each row execute function erp.guard_stock_explainability_immutable();

drop trigger if exists trg_audit_stock_explainability_snapshots
  on erp.stock_explainability_snapshots;
create trigger trg_audit_stock_explainability_snapshots
after insert or update or delete on erp.stock_explainability_snapshots
for each row execute function erp.audit_row_change();

create or replace view erp.v_fg_stock_position_v1
with (security_invoker = true)
as
with active_reservations as (
  select
    m.product_id,
    m.location_id,
    m.quality_grade,
    sum(abs(m.qty_signed))::bigint as reserved_qty_pcs
  from erp.fg_stock_movements m
  where m.movement_type = 'SALE_RESERVE'
    and not exists (
      select 1
      from erp.fg_stock_movements rv
      where rv.reversal_of_id = m.id
    )
  group by m.product_id, m.location_id, m.quality_grade
)
select
  b.product_id,
  b.location_id,
  b.quality_grade,
  (b.cached_qty_pcs + coalesce(r.reserved_qty_pcs, 0))::bigint as physical_stock_qty_pcs,
  coalesce(r.reserved_qty_pcs, 0)::bigint as reserved_qty_pcs,
  b.cached_qty_pcs::bigint as available_stock_qty_pcs,
  b.updated_at as stock_updated_at
from erp.fg_inventory_balances b
left join active_reservations r
  on r.product_id = b.product_id
 and r.location_id = b.location_id
 and r.quality_grade = b.quality_grade;

comment on view erp.v_fg_stock_position_v1 is
  'Authoritative FG position: cached_qty_pcs is already sellable/available after SALE_RESERVE; physical = available + active reservation. Never subtract reservation twice.';

-- ---------------------------------------------------------------------------
-- 4. Narrow public RPC facade (no direct erp schema/table exposure)
-- ---------------------------------------------------------------------------

create or replace function public.erp_save_worker_roster_v1(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.save_worker_roster_v1(p_payload, p_client_request_id, p_expected_version)
$function$;

create or replace function public.erp_set_worker_daily_rate_v1(
  p_worker_id uuid,
  p_daily_rate numeric,
  p_effective_from date,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.set_worker_daily_rate_v1(
    p_worker_id, p_daily_rate, p_effective_from, p_reason,
    p_client_request_id, p_expected_version
  )
$function$;

create or replace function public.erp_save_attendance_period_v1(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null,
  p_preview_only boolean default false
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.save_attendance_period_v1(
    p_payload, p_client_request_id, p_expected_version, p_preview_only
  )
$function$;

create or replace function public.erp_post_attendance_period_v1(
  p_period_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.post_attendance_period_v1(
    p_period_id, p_reason, p_client_request_id, p_expected_version
  )
$function$;

create or replace function public.erp_reverse_attendance_period_v1(
  p_period_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.reverse_attendance_period_v1(
    p_period_id, p_reason, p_client_request_id, p_expected_version
  )
$function$;

create or replace function public.erp_set_fg_stock_policy_v1(
  p_product_id uuid,
  p_location_id uuid,
  p_basis_source text,
  p_manual_reorder_point_qty numeric,
  p_manual_target_stock_qty numeric,
  p_minimum_sample_days integer,
  p_effective_from date,
  p_reason text,
  p_expected_policy_id uuid,
  p_client_request_id uuid
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.set_fg_stock_policy_v1(
    p_product_id, p_location_id, p_basis_source,
    p_manual_reorder_point_qty, p_manual_target_stock_qty,
    p_minimum_sample_days, p_effective_from, p_reason,
    p_expected_policy_id, p_client_request_id
  )
$function$;

create or replace function public.erp_get_attendance_workspace_v1(
  p_contractor_id uuid,
  p_period_start date,
  p_period_end date,
  p_include_inactive boolean default false
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
declare
  v_result jsonb;
begin
  perform erp.require_internal();
  if p_contractor_id is null or p_period_start is null or p_period_end is null
     or p_period_end < p_period_start then
    raise exception 'Valid contractor_id, period_start, and period_end are required';
  end if;

  select jsonb_build_object(
    'contractor', jsonb_build_object(
      'id', c.id,
      'name', c.contractor_name,
      'attendance_required', c.attendance_required
    ),
    'period_start', p_period_start,
    'period_end', p_period_end,
    'workers', coalesce((
      select jsonb_agg(jsonb_build_object(
        'worker_id', w.id,
        'worker_code', w.worker_code,
        'worker_name', w.worker_name,
        'job_description', w.job_description,
        'pay_scheme', w.pay_scheme,
        'current_daily_rate', erp.worker_daily_rate_at(w.id, current_date),
        'joined_at', w.joined_at,
        'left_at', w.left_at,
        'is_active', w.is_active,
        'notes', w.notes,
        'row_version', w.row_version,
        'rate_versions', (
          select coalesce(jsonb_agg(to_jsonb(rv) order by rv.effective_from), '[]'::jsonb)
          from erp.worker_daily_rate_versions rv where rv.worker_id = w.id
        ),
        'employment_periods', (
          select coalesce(jsonb_agg(jsonb_build_object(
            'id', ep.id,
            'started_on', ep.started_on,
            'ended_on', ep.ended_on,
            'start_reason', ep.start_reason,
            'end_reason', ep.end_reason
          ) order by ep.started_on), '[]'::jsonb)
          from erp.worker_employment_periods ep where ep.worker_id = w.id
        ),
        'attendance', (
          select coalesce(jsonb_agg(jsonb_build_object(
            'id', a.id,
            'attendance_period_id', a.attendance_period_id,
            'attendance_date', a.attendance_date,
            'status', a.status,
            'record_lifecycle', coalesce(a.record_lifecycle, 'LEGACY_POSTED'),
            'supersedes_attendance_record_id', a.supersedes_attendance_record_id,
            'paid_fraction', a.paid_fraction,
            'notes', a.notes,
            'row_version', a.row_version
          ) order by a.attendance_date), '[]'::jsonb)
          from erp.attendance_records a
          where a.worker_id = w.id
            and a.attendance_date between p_period_start and p_period_end
        )
      ) order by w.worker_name, w.id)
      from erp.contractor_workers w
      where w.contractor_id = c.id
        and (p_include_inactive or w.is_active)
        and exists (
          select 1
          from erp.worker_employment_periods ep
          where ep.worker_id = w.id
            and daterange(ep.started_on, coalesce(ep.ended_on + 1, 'infinity'::date), '[)')
                && daterange(p_period_start, p_period_end + 1, '[)')
        )
    ), '[]'::jsonb),
    'periods', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', ap.id,
        'period_number', ap.period_number,
        'period_start', ap.period_start,
        'period_end', ap.period_end,
        'pay_date', ap.pay_date,
        'status', ap.status,
        'correction_of_period_id', ap.correction_of_period_id,
        'row_version', ap.row_version
      ) order by ap.period_start, ap.id)
      from erp.attendance_periods ap
      where ap.contractor_id = c.id
        and daterange(ap.period_start, ap.period_end + 1, '[)')
            && daterange(p_period_start, p_period_end + 1, '[)')
    ), '[]'::jsonb)
  ) into v_result
  from erp.contractors c
  where c.id = p_contractor_id;

  if v_result is null then raise exception 'Contractor not found'; end if;
  return v_result;
end;
$function$;

create or replace function public.erp_get_fg_stock_explainability_v1(
  p_product_id uuid default null,
  p_location_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
declare
  v_result jsonb;
begin
  perform erp.require_internal();

  with positions as (
    select p.*
    from erp.v_fg_stock_position_v1 p
    where (p_product_id is null or p.product_id = p_product_id)
      and (p_location_id is null or p.location_id = p_location_id)
      and p.quality_grade = 'GRADE_A'
  )
  select coalesce(jsonb_agg(jsonb_build_object(
    'product_id', p.product_id,
    'location_id', p.location_id,
    'quality_grade', p.quality_grade,
    'physical_stock_qty_pcs', p.physical_stock_qty_pcs,
    'reserved_qty_pcs', p.reserved_qty_pcs,
    'available_stock_qty_pcs', p.available_stock_qty_pcs,
    'confirmed_incoming_qty_pcs', null,
    'projected_stock_qty_pcs', null,
    'average_daily_demand', null,
    'lead_time_days', null,
    'safety_stock_qty_pcs', null,
    'reorder_point_qty_pcs', null,
    'recommended_qty_pcs', null,
    'health_status', 'BELUM_CUKUP_DATA',
    'basis_source', coalesce(policy.basis_source, 'BELUM_DIATUR'),
    'policy_version_id', policy.id,
    'manual_reorder_point_qty_pcs', policy.manual_reorder_point_qty,
    'manual_target_stock_qty_pcs', policy.manual_target_stock_qty,
    'minimum_sample_days', policy.minimum_sample_days,
    'confidence', null,
    'calculation_readiness', 'BLOCKED_AUTHORITATIVE_INPUTS',
    'manual_policy_status', case
      when policy.basis_source = 'MANUAL' then 'STORED_NOT_CALCULATED'
      else null
    end,
    'formula_version', 'STOCK_EXPLAINABILITY_V1_INPUTS_NOT_CONNECTED',
    'formula', 'physical = available + reserved; projected/demand/lead-time recommendation awaits authoritative adapters',
    'stock_updated_at', p.stock_updated_at,
    'calculated_at', null,
    'read_at', clock_timestamp(),
    'links', jsonb_build_object(
      'stock_movements', jsonb_build_object('product_id', p.product_id, 'location_id', p.location_id),
      'sale_reservations', jsonb_build_object('movement_type', 'SALE_RESERVE')
    )
  ) order by p.product_id, p.location_id, p.quality_grade), '[]'::jsonb)
  into v_result
  from positions p
  left join lateral (
    select sp.*
    from erp.stock_policy_versions sp
    where sp.subject_type = 'FG'
      and sp.product_id = p.product_id
      and (sp.location_id is null or sp.location_id = p.location_id)
      and current_date >= sp.effective_from
      and (sp.effective_to is null or current_date <= sp.effective_to)
    order by (sp.location_id is not null) desc, sp.effective_from desc, sp.id desc
    limit 1
  ) policy on true;

  return v_result;
end;
$function$;

-- New tables stay private. RLS is defense in depth, not an API grant.
alter table erp.worker_daily_rate_versions enable row level security;
alter table erp.worker_employment_periods enable row level security;
alter table erp.attendance_periods enable row level security;
alter table erp.stock_policy_versions enable row level security;
alter table erp.stock_explainability_snapshots enable row level security;

drop policy if exists internal_read on erp.worker_daily_rate_versions;
create policy internal_read on erp.worker_daily_rate_versions
for select to authenticated
using ((select erp.current_app_role()) in ('OWNER','ADMIN','STAFF'));

drop policy if exists internal_read on erp.worker_employment_periods;
create policy internal_read on erp.worker_employment_periods
for select to authenticated
using ((select erp.current_app_role()) in ('OWNER','ADMIN','STAFF'));

drop policy if exists internal_read on erp.attendance_periods;
create policy internal_read on erp.attendance_periods
for select to authenticated
using ((select erp.current_app_role()) in ('OWNER','ADMIN','STAFF'));

drop policy if exists internal_read on erp.stock_policy_versions;
create policy internal_read on erp.stock_policy_versions
for select to authenticated
using ((select erp.current_app_role()) in ('OWNER','ADMIN','STAFF'));

drop policy if exists internal_read on erp.stock_explainability_snapshots;
create policy internal_read on erp.stock_explainability_snapshots
for select to authenticated
using ((select erp.current_app_role()) in ('OWNER','ADMIN','STAFF'));

revoke all on erp.worker_daily_rate_versions from public, anon, authenticated;
revoke all on erp.worker_employment_periods from public, anon, authenticated;
revoke all on erp.attendance_periods from public, anon, authenticated;
revoke all on erp.stock_policy_versions from public, anon, authenticated;
revoke all on erp.stock_explainability_snapshots from public, anon, authenticated;
revoke all on erp.v_fg_stock_position_v1 from public, anon, authenticated;

grant all on erp.worker_daily_rate_versions to service_role;
grant all on erp.worker_employment_periods to service_role;
grant all on erp.attendance_periods to service_role;
grant all on erp.stock_policy_versions to service_role;
grant all on erp.stock_explainability_snapshots to service_role;
grant select on erp.v_fg_stock_position_v1 to service_role;

revoke execute on function public.erp_save_worker_roster_v1(
  jsonb, uuid, bigint
) from public, anon;
revoke execute on function public.erp_set_worker_daily_rate_v1(
  uuid, numeric, date, text, uuid, bigint
) from public, anon;
revoke execute on function public.erp_save_attendance_period_v1(
  jsonb, uuid, bigint, boolean
) from public, anon;
revoke execute on function public.erp_post_attendance_period_v1(
  uuid, text, uuid, bigint
) from public, anon;
revoke execute on function public.erp_reverse_attendance_period_v1(
  uuid, text, uuid, bigint
) from public, anon;
revoke execute on function public.erp_set_fg_stock_policy_v1(
  uuid, uuid, text, numeric, numeric, integer, date, text, uuid, uuid
) from public, anon;
revoke execute on function public.erp_get_attendance_workspace_v1(
  uuid, date, date, boolean
) from public, anon;
revoke execute on function public.erp_get_fg_stock_explainability_v1(
  uuid, uuid
) from public, anon;

grant execute on function public.erp_save_worker_roster_v1(
  jsonb, uuid, bigint
) to authenticated, service_role;
grant execute on function public.erp_set_worker_daily_rate_v1(
  uuid, numeric, date, text, uuid, bigint
) to authenticated, service_role;
grant execute on function public.erp_save_attendance_period_v1(
  jsonb, uuid, bigint, boolean
) to authenticated, service_role;
grant execute on function public.erp_post_attendance_period_v1(
  uuid, text, uuid, bigint
) to authenticated, service_role;
grant execute on function public.erp_reverse_attendance_period_v1(
  uuid, text, uuid, bigint
) to authenticated, service_role;
grant execute on function public.erp_set_fg_stock_policy_v1(
  uuid, uuid, text, numeric, numeric, integer, date, text, uuid, uuid
) to authenticated, service_role;
grant execute on function public.erp_get_attendance_workspace_v1(
  uuid, date, date, boolean
) to authenticated, service_role;
grant execute on function public.erp_get_fg_stock_explainability_v1(
  uuid, uuid
) to authenticated, service_role;

-- Internal helpers are never direct browser endpoints.
revoke execute on function erp.save_worker_roster_v1(jsonb, uuid, bigint)
  from public, anon, authenticated;
revoke execute on function erp.set_worker_daily_rate_v1(
  uuid, numeric, date, text, uuid, bigint
) from public, anon, authenticated;
revoke execute on function erp.worker_daily_rate_at(uuid, date)
  from public, anon, authenticated;
revoke execute on function erp.require_worker_daily_rate_at(uuid, date)
  from public, anon, authenticated;
revoke execute on function erp.worker_is_employed_on(uuid, date)
  from public, anon, authenticated;
revoke execute on function erp.worker_daily_rate_version_id_at(uuid, date)
  from public, anon, authenticated;
revoke execute on function erp.save_attendance_period_v1(jsonb, uuid, bigint, boolean)
  from public, anon, authenticated;
revoke execute on function erp.post_attendance_period_v1(uuid, text, uuid, bigint)
  from public, anon, authenticated;
revoke execute on function erp.reverse_attendance_period_v1(uuid, text, uuid, bigint)
  from public, anon, authenticated;
revoke execute on function erp.set_fg_stock_policy_v1(
  uuid, uuid, text, numeric, numeric, integer, date, text, uuid, uuid
) from public, anon, authenticated;

grant execute on function erp.save_worker_roster_v1(jsonb, uuid, bigint) to service_role;
grant execute on function erp.set_worker_daily_rate_v1(
  uuid, numeric, date, text, uuid, bigint
) to service_role;
grant execute on function erp.worker_daily_rate_at(uuid, date) to service_role;
grant execute on function erp.require_worker_daily_rate_at(uuid, date) to service_role;
grant execute on function erp.worker_is_employed_on(uuid, date) to service_role;
grant execute on function erp.worker_daily_rate_version_id_at(uuid, date) to service_role;
grant execute on function erp.save_attendance_period_v1(jsonb, uuid, bigint, boolean)
  to service_role;
grant execute on function erp.post_attendance_period_v1(uuid, text, uuid, bigint)
  to service_role;
grant execute on function erp.reverse_attendance_period_v1(uuid, text, uuid, bigint)
  to service_role;
grant execute on function erp.set_fg_stock_policy_v1(
  uuid, uuid, text, numeric, numeric, integer, date, text, uuid, uuid
) to service_role;

comment on table erp.worker_daily_rate_versions is
  'Effective-dated worker daily-rate facts. Payroll snapshots resolve by attendance date; history is never overwritten.';
comment on table erp.worker_employment_periods is
  'Effective-dated employment episodes for leave/rejoin gaps under one stable worker ID.';
comment on table erp.attendance_periods is
  'Attendance document header. DRAFT may change; POSTED/CORRECTED/REVERSED facts require lifecycle RPCs.';
comment on table erp.stock_policy_versions is
  'Effective-dated policy/basis history. Health status is deliberately not user-editable and lives only in calculated results.';
comment on table erp.stock_explainability_snapshots is
  'Immutable calculation evidence. Insert only after authoritative demand/incoming adapters exist; never fabricate inputs.';

notify pgrst, 'reload schema';

commit;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260830140645','erp_v2_6_12_attendance_and_stock_explainability',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260830140645 erp_v2_6_12_attendance_and_stock_explainability

-- BEGIN PLATFORM MIGRATION 20260830190955 erp_v2_6_13_manual_reminders_v1
-- ERP Garment v2.6.13
-- Private, own-user manual reminders for ERP Enteng UAT.
--
-- Deliberately excluded from V1:
--   * automatic reminders derived from business transactions;
--   * cross-user assignment;
--   * cron, push, email, or WhatsApp delivery;
--   * hard deletion.

begin;

set local lock_timeout = '10s';
set local statement_timeout = '120s';

do $migration_guard$
begin
  if to_regclass('erp.app_users') is null
     or to_regclass('erp.idempotency_requests') is null
     or to_regclass('erp.audit_logs') is null
     or to_regprocedure('erp.current_app_user_id()') is null
     or to_regprocedure('erp.current_app_role()') is null
     or to_regprocedure('erp.require_internal()') is null
     or to_regprocedure('erp._request_hash(jsonb)') is null
     or to_regprocedure('erp._idempotency_begin(text,uuid,text)') is null
     or to_regprocedure('erp._idempotency_complete(text,uuid,jsonb)') is null
     or to_regprocedure('erp.bump_row_version()') is null then
    raise exception 'Manual reminders V1 requires the ERP Enteng baseline and idempotency helpers';
  end if;
end;
$migration_guard$;

create table if not exists erp.manual_reminders (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references erp.app_users(id) on delete restrict,
  title text not null,
  note text not null default '',
  due_at timestamptz not null,
  priority varchar(10) not null default 'NORMAL',
  module varchar(80) not null default 'Operasional',
  status varchar(12) not null default 'OPEN',
  completed_at timestamptz,
  completed_by uuid references erp.app_users(id) on delete restrict,
  cancelled_at timestamptz,
  cancelled_by uuid references erp.app_users(id) on delete restrict,
  cancellation_reason text,
  created_at timestamptz not null default clock_timestamp(),
  created_by uuid not null references erp.app_users(id) on delete restrict,
  updated_at timestamptz not null default clock_timestamp(),
  updated_by uuid not null references erp.app_users(id) on delete restrict,
  last_client_request_id uuid not null,
  row_version bigint not null default 1,
  constraint manual_reminders_title_check
    check (btrim(title) <> '' and char_length(title) <= 200),
  constraint manual_reminders_note_check
    check (char_length(note) <= 4000),
  constraint manual_reminders_due_at_check
    check (isfinite(due_at)),
  constraint manual_reminders_priority_check
    check (priority in ('URGENT','NORMAL','LOW')),
  constraint manual_reminders_module_check
    check (btrim(module) <> '' and char_length(module) <= 80),
  constraint manual_reminders_status_check
    check (status in ('OPEN','DONE','CANCELLED')),
  constraint manual_reminders_reason_check
    check (cancellation_reason is null or (
      btrim(cancellation_reason) <> '' and char_length(cancellation_reason) <= 1000
    )),
  constraint manual_reminders_actor_check
    check (
      owner_user_id = created_by
      and owner_user_id = updated_by
      and (completed_by is null or completed_by = owner_user_id)
      and (cancelled_by is null or cancelled_by = owner_user_id)
    ),
  constraint manual_reminders_lifecycle_check
    check (
      (status = 'OPEN'
        and completed_at is null and completed_by is null
        and cancelled_at is null and cancelled_by is null
        and cancellation_reason is null)
      or
      (status = 'DONE'
        and completed_at is not null and completed_by is not null
        and cancelled_at is null and cancelled_by is null
        and cancellation_reason is null)
      or
      (status = 'CANCELLED'
        and ((completed_at is null and completed_by is null)
          or (completed_at is not null and completed_by is not null))
        and cancelled_at is not null and cancelled_by is not null
        and btrim(coalesce(cancellation_reason, '')) <> '')
    ),
  constraint manual_reminders_row_version_check check (row_version > 0)
);

-- OPEN is the dashboard hot path. The management page passes ACTIVE/other filters explicitly.
create index if not exists idx_manual_reminders_open_due
  on erp.manual_reminders(owner_user_id, due_at, id)
  where status = 'OPEN';

create or replace function erp.guard_manual_reminder_write()
returns trigger
language plpgsql
set search_path = erp, public, pg_temp
as $function$
begin
  if tg_op = 'DELETE' then
    raise exception 'Manual reminders cannot be deleted; use erp_cancel_my_reminder_v1';
  end if;

  if current_setting('app.manual_reminder_write', true) is distinct from 'on' then
    raise exception 'Manual reminders are write-protected; use the reminder RPC facade';
  end if;

  if tg_op = 'UPDATE' then
    if (new.id, new.owner_user_id, new.created_at, new.created_by)
       is distinct from
       (old.id, old.owner_user_id, old.created_at, old.created_by) then
      raise exception 'Reminder identity, owner, and creation facts are immutable';
    end if;
    if old.status = 'CANCELLED' then
      raise exception 'Cancelled reminders are terminal';
    end if;
  end if;

  return new;
end;
$function$;

create or replace function erp.audit_manual_reminder_change()
returns trigger
language plpgsql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
declare
  v_action text := coalesce(nullif(current_setting('app.manual_reminder_action', true), ''), tg_op);
  v_old jsonb;
  v_new jsonb;
begin
  -- audit_logs is shared with internal staff, so title, note, module, and the
  -- private cancellation reason are intentionally never copied into it.
  if tg_op = 'UPDATE' then
    v_old := jsonb_build_object(
      'row_version', old.row_version,
      'content_redacted', true
    );
  end if;

  v_new := jsonb_build_object(
    'row_version', new.row_version,
    'title_changed', case when tg_op = 'INSERT' then true else new.title is distinct from old.title end,
    'note_changed', case when tg_op = 'INSERT' then true else new.note is distinct from old.note end,
    'module_changed', case when tg_op = 'INSERT' then true else new.module is distinct from old.module end,
    'content_redacted', true
  );

  insert into erp.audit_logs(
    entity_type, entity_id, action, old_data, new_data, changed_by, change_reason
  ) values (
    'manual_reminders', new.id, case when tg_op = 'INSERT' then 'INSERT' else 'UPDATE' end,
    v_old, v_new, erp.current_app_user_id(),
    'Manual reminder ' || lower(v_action)
  );

  return new;
end;
$function$;

drop trigger if exists trg_00_guard_manual_reminder_write on erp.manual_reminders;
create trigger trg_00_guard_manual_reminder_write
before insert or update or delete on erp.manual_reminders
for each row execute function erp.guard_manual_reminder_write();

drop trigger if exists trg_01_bump_manual_reminder_version on erp.manual_reminders;
create trigger trg_01_bump_manual_reminder_version
before update on erp.manual_reminders
for each row execute function erp.bump_row_version();

drop trigger if exists trg_90_audit_manual_reminder on erp.manual_reminders;
create trigger trg_90_audit_manual_reminder
after insert or update on erp.manual_reminders
for each row execute function erp.audit_manual_reminder_change();

create or replace function erp.require_manual_reminder_actor()
returns uuid
language plpgsql
stable
security definer
set search_path = erp, public, auth, pg_temp
as $function$
declare
  v_actor uuid;
  v_role text;
begin
  perform erp.require_internal();
  v_actor := erp.current_app_user_id();
  v_role := erp.current_app_role();
  if v_actor is null or v_role not in ('OWNER','ADMIN','STAFF') then
    raise exception 'Mapped active internal ERP user required';
  end if;
  return v_actor;
end;
$function$;

create or replace function erp.list_my_reminders_v1(
  p_filter text default 'ACTIVE',
  p_limit integer default 200
)
returns jsonb
language plpgsql
stable
security definer
set search_path = erp, public, auth, pg_temp
as $function$
declare
  v_actor uuid := erp.require_manual_reminder_actor();
  v_filter text := upper(coalesce(nullif(btrim(p_filter), ''), 'ACTIVE'));
  v_items jsonb;
  v_counts jsonb;
begin
  if v_filter not in ('ACTIVE','OPEN','DONE','CANCELLED','ALL') then
    raise exception 'Reminder filter must be ACTIVE, OPEN, DONE, CANCELLED, or ALL';
  end if;
  if p_limit is null or p_limit < 1 or p_limit > 200 then
    raise exception 'Reminder limit must be between 1 and 200';
  end if;

  select coalesce(jsonb_agg(q.item order by q.status_rank, q.priority_rank, q.sort_at, q.id), '[]'::jsonb)
  into v_items
  from (
    select
      r.id,
      case r.status when 'OPEN' then 0 when 'DONE' then 1 else 2 end as status_rank,
      case r.priority when 'URGENT' then 0 when 'NORMAL' then 1 else 2 end as priority_rank,
      case when r.status = 'OPEN' then r.due_at else r.updated_at end as sort_at,
      jsonb_build_object(
        'id', r.id,
        'title', r.title,
        'note', r.note,
        'due_at', r.due_at,
        'priority', r.priority,
        'module', r.module,
        'status', r.status,
        'completed_at', r.completed_at,
        'cancelled_at', r.cancelled_at,
        'cancellation_reason', r.cancellation_reason,
        'created_at', r.created_at,
        'updated_at', r.updated_at,
        'row_version', r.row_version
      ) as item
    from erp.manual_reminders r
    where r.owner_user_id = v_actor
      and (
        v_filter = 'ALL'
        or (v_filter = 'ACTIVE' and r.status in ('OPEN','DONE'))
        or r.status = v_filter
      )
    order by
      case r.status when 'OPEN' then 0 when 'DONE' then 1 else 2 end,
      case r.priority when 'URGENT' then 0 when 'NORMAL' then 1 else 2 end,
      case when r.status = 'OPEN' then r.due_at else r.updated_at end,
      r.id
    limit p_limit
  ) q;

  select jsonb_build_object(
    'open', count(*) filter (where r.status = 'OPEN'),
    'done', count(*) filter (where r.status = 'DONE'),
    'cancelled', count(*) filter (where r.status = 'CANCELLED')
  ) into v_counts
  from erp.manual_reminders r
  where r.owner_user_id = v_actor;

  return jsonb_build_object(
    'items', v_items,
    'counts', v_counts,
    'read_at', statement_timestamp()
  );
end;
$function$;

create or replace function erp.save_my_reminder_v1(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'save_my_reminder_v1';
  v_actor uuid := erp.require_manual_reminder_actor();
  v_id uuid;
  v_title text;
  v_note text;
  v_due_text text;
  v_due_at timestamptz;
  v_priority text;
  v_module text;
  v_hash text;
  v_cached jsonb;
  v_row erp.manual_reminders%rowtype;
  v_response jsonb;
begin
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception 'Reminder payload must be a JSON object';
  end if;
  if exists (
    select 1 from jsonb_object_keys(p_payload) k
    where k not in ('id','title','note','due_at','priority','module')
  ) then
    raise exception 'Reminder payload contains unsupported fields';
  end if;
  if exists (
    select 1
    from jsonb_each(p_payload) item
    where item.key in ('id','title','note','due_at','priority','module')
      and jsonb_typeof(item.value) not in ('string','null')
  ) then
    raise exception 'Reminder payload fields must be strings or null';
  end if;

  begin
    v_id := nullif(btrim(p_payload->>'id'), '')::uuid;
  exception when invalid_text_representation then
    raise exception 'Reminder id must be a UUID';
  end;

  v_title := btrim(coalesce(p_payload->>'title', ''));
  v_note := coalesce(p_payload->>'note', '');
  v_due_text := btrim(coalesce(p_payload->>'due_at', ''));
  v_priority := upper(coalesce(nullif(btrim(p_payload->>'priority'), ''), 'NORMAL'));
  v_module := coalesce(nullif(btrim(p_payload->>'module'), ''), 'Operasional');

  if v_title = '' or char_length(v_title) > 200 then
    raise exception 'Reminder title must contain 1 to 200 characters';
  end if;
  if char_length(v_note) > 4000 then
    raise exception 'Reminder note cannot exceed 4000 characters';
  end if;
  if char_length(v_module) > 80 then
    raise exception 'Reminder module cannot exceed 80 characters';
  end if;
  if v_priority not in ('URGENT','NORMAL','LOW') then
    raise exception 'Reminder priority must be URGENT, NORMAL, or LOW';
  end if;
  if v_due_text = '' or v_due_text !~* '(Z|[+-][0-9]{2}:[0-9]{2})$' then
    raise exception 'Reminder due_at must be ISO-8601 with an explicit UTC offset';
  end if;
  begin
    v_due_at := v_due_text::timestamptz;
  exception when others then
    raise exception 'Reminder due_at is invalid';
  end;
  if not isfinite(v_due_at) then
    raise exception 'Reminder due_at must be finite';
  end if;

  if v_id is null and p_expected_version is not null then
    raise exception 'expected_version must be null when creating a reminder';
  end if;
  if v_id is not null and (p_expected_version is null or p_expected_version < 1) then
    raise exception 'A positive expected_version is required when updating a reminder';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'id', v_id,
    'title', v_title,
    'note', v_note,
    'due_at', v_due_at,
    'priority', v_priority,
    'module', v_module,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  if v_id is null then
    perform set_config('app.manual_reminder_write', 'on', true);
    perform set_config('app.manual_reminder_action', 'CREATE', true);
    insert into erp.manual_reminders(
      owner_user_id, title, note, due_at, priority, module,
      created_by, updated_by, last_client_request_id
    ) values (
      v_actor, v_title, v_note, v_due_at, v_priority, v_module,
      v_actor, v_actor, p_client_request_id
    ) returning * into v_row;
  else
    select * into v_row
    from erp.manual_reminders r
    where r.id = v_id and r.owner_user_id = v_actor
    for update;

    if v_row.id is null then raise exception 'Reminder not found'; end if;
    if v_row.row_version <> p_expected_version then
      raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_row.row_version;
    end if;
    if v_row.status <> 'OPEN' then
      raise exception 'Only OPEN reminders can be edited; reopen DONE reminders first';
    end if;

    if (v_row.title, v_row.note, v_row.due_at, v_row.priority, v_row.module)
       is distinct from
       (v_title, v_note, v_due_at, v_priority, v_module) then
      perform set_config('app.manual_reminder_write', 'on', true);
      perform set_config('app.manual_reminder_action', 'EDIT', true);
      update erp.manual_reminders r
      set title = v_title,
          note = v_note,
          due_at = v_due_at,
          priority = v_priority,
          module = v_module,
          updated_at = clock_timestamp(),
          updated_by = v_actor,
          last_client_request_id = p_client_request_id
      where r.id = v_id and r.owner_user_id = v_actor
      returning * into v_row;
    end if;
  end if;

  perform set_config('app.manual_reminder_write', 'off', true);
  perform set_config('app.manual_reminder_action', '', true);

  v_response := jsonb_build_object(
    'reminder', jsonb_build_object(
      'id', v_row.id,
      'title', v_row.title,
      'note', v_row.note,
      'due_at', v_row.due_at,
      'priority', v_row.priority,
      'module', v_row.module,
      'status', v_row.status,
      'completed_at', v_row.completed_at,
      'cancelled_at', v_row.cancelled_at,
      'cancellation_reason', v_row.cancellation_reason,
      'created_at', v_row.created_at,
      'updated_at', v_row.updated_at,
      'row_version', v_row.row_version
    ),
    'client_request_id', p_client_request_id
  );
  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

create or replace function erp.set_my_reminder_done_v1(
  p_reminder_id uuid,
  p_done boolean,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'set_my_reminder_done_v1';
  v_actor uuid := erp.require_manual_reminder_actor();
  v_hash text;
  v_cached jsonb;
  v_row erp.manual_reminders%rowtype;
  v_target_status text;
  v_response jsonb;
begin
  if p_reminder_id is null or p_done is null or p_expected_version is null or p_expected_version < 1 then
    raise exception 'reminder_id, done, and a positive expected_version are required';
  end if;
  v_target_status := case when p_done then 'DONE' else 'OPEN' end;
  v_hash := erp._request_hash(jsonb_build_object(
    'reminder_id', p_reminder_id,
    'done', p_done,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_row
  from erp.manual_reminders r
  where r.id = p_reminder_id and r.owner_user_id = v_actor
  for update;

  if v_row.id is null then raise exception 'Reminder not found'; end if;
  if v_row.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_row.row_version;
  end if;
  if v_row.status = 'CANCELLED' then raise exception 'Cancelled reminders are terminal'; end if;

  if v_row.status <> v_target_status then
    perform set_config('app.manual_reminder_write', 'on', true);
    perform set_config('app.manual_reminder_action', case when p_done then 'COMPLETE' else 'REOPEN' end, true);
    update erp.manual_reminders r
    set status = v_target_status,
        completed_at = case when p_done then clock_timestamp() else null end,
        completed_by = case when p_done then v_actor else null end,
        updated_at = clock_timestamp(),
        updated_by = v_actor,
        last_client_request_id = p_client_request_id
    where r.id = p_reminder_id and r.owner_user_id = v_actor
    returning * into v_row;
  end if;

  perform set_config('app.manual_reminder_write', 'off', true);
  perform set_config('app.manual_reminder_action', '', true);

  v_response := jsonb_build_object(
    'reminder_id', v_row.id,
    'status', v_row.status,
    'completed_at', v_row.completed_at,
    'row_version', v_row.row_version,
    'client_request_id', p_client_request_id
  );
  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

create or replace function erp.cancel_my_reminder_v1(
  p_reminder_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = erp, public, auth, extensions, pg_temp
as $function$
declare
  v_operation constant text := 'cancel_my_reminder_v1';
  v_actor uuid := erp.require_manual_reminder_actor();
  v_reason text := btrim(coalesce(p_reason, ''));
  v_hash text;
  v_cached jsonb;
  v_row erp.manual_reminders%rowtype;
  v_response jsonb;
begin
  if p_reminder_id is null or p_expected_version is null or p_expected_version < 1 then
    raise exception 'reminder_id and a positive expected_version are required';
  end if;
  if v_reason = '' or char_length(v_reason) > 1000 then
    raise exception 'Cancellation reason must contain 1 to 1000 characters';
  end if;

  v_hash := erp._request_hash(jsonb_build_object(
    'reminder_id', p_reminder_id,
    'reason', v_reason,
    'expected_version', p_expected_version
  ));
  v_cached := erp._idempotency_begin(v_operation, p_client_request_id, v_hash);
  if v_cached is not null then return v_cached; end if;

  select * into v_row
  from erp.manual_reminders r
  where r.id = p_reminder_id and r.owner_user_id = v_actor
  for update;

  if v_row.id is null then raise exception 'Reminder not found'; end if;
  if v_row.row_version <> p_expected_version then
    raise exception 'STALE_VERSION expected %, current %', p_expected_version, v_row.row_version;
  end if;
  if v_row.status = 'CANCELLED' then raise exception 'Cancelled reminders are terminal'; end if;

  perform set_config('app.manual_reminder_write', 'on', true);
  perform set_config('app.manual_reminder_action', 'CANCEL', true);
  update erp.manual_reminders r
  set status = 'CANCELLED',
      cancelled_at = clock_timestamp(),
      cancelled_by = v_actor,
      cancellation_reason = v_reason,
      updated_at = clock_timestamp(),
      updated_by = v_actor,
      last_client_request_id = p_client_request_id
  where r.id = p_reminder_id and r.owner_user_id = v_actor
  returning * into v_row;

  perform set_config('app.manual_reminder_write', 'off', true);
  perform set_config('app.manual_reminder_action', '', true);

  v_response := jsonb_build_object(
    'reminder_id', v_row.id,
    'status', v_row.status,
    'cancelled_at', v_row.cancelled_at,
    'row_version', v_row.row_version,
    'client_request_id', p_client_request_id
  );
  return erp._idempotency_complete(v_operation, p_client_request_id, v_response);
end;
$function$;

-- Public browser facades. Every internal function rechecks the mapped actor.
create or replace function public.erp_list_my_reminders_v1(
  p_filter text default 'ACTIVE',
  p_limit integer default 200
)
returns jsonb
language sql
stable
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.list_my_reminders_v1(p_filter, p_limit)
$function$;

create or replace function public.erp_save_my_reminder_v1(
  p_payload jsonb,
  p_client_request_id uuid,
  p_expected_version bigint default null
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.save_my_reminder_v1(p_payload, p_client_request_id, p_expected_version)
$function$;

create or replace function public.erp_set_my_reminder_done_v1(
  p_reminder_id uuid,
  p_done boolean,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.set_my_reminder_done_v1(
    p_reminder_id, p_done, p_client_request_id, p_expected_version
  )
$function$;

create or replace function public.erp_cancel_my_reminder_v1(
  p_reminder_id uuid,
  p_reason text,
  p_client_request_id uuid,
  p_expected_version bigint
)
returns jsonb
language sql
security definer
set search_path = erp, public, auth, pg_temp
as $function$
  select erp.cancel_my_reminder_v1(
    p_reminder_id, p_reason, p_client_request_id, p_expected_version
  )
$function$;

alter table erp.manual_reminders enable row level security;

drop policy if exists own_internal_read on erp.manual_reminders;
create policy own_internal_read on erp.manual_reminders
for select to authenticated
using (
  owner_user_id = (select erp.current_app_user_id())
  and (select erp.current_app_role()) in ('OWNER','ADMIN','STAFF')
);

revoke all on erp.manual_reminders from public, anon, authenticated;
grant all on erp.manual_reminders to service_role;

revoke execute on function public.erp_list_my_reminders_v1(text, integer)
  from public, anon, authenticated;
revoke execute on function public.erp_save_my_reminder_v1(jsonb, uuid, bigint)
  from public, anon, authenticated;
revoke execute on function public.erp_set_my_reminder_done_v1(uuid, boolean, uuid, bigint)
  from public, anon, authenticated;
revoke execute on function public.erp_cancel_my_reminder_v1(uuid, text, uuid, bigint)
  from public, anon, authenticated;

grant execute on function public.erp_list_my_reminders_v1(text, integer)
  to authenticated, service_role;
grant execute on function public.erp_save_my_reminder_v1(jsonb, uuid, bigint)
  to authenticated, service_role;
grant execute on function public.erp_set_my_reminder_done_v1(uuid, boolean, uuid, bigint)
  to authenticated, service_role;
grant execute on function public.erp_cancel_my_reminder_v1(uuid, text, uuid, bigint)
  to authenticated, service_role;

-- Private implementations and trigger helpers are never browser endpoints.
revoke execute on function erp.require_manual_reminder_actor()
  from public, anon, authenticated;
revoke execute on function erp.list_my_reminders_v1(text, integer)
  from public, anon, authenticated;
revoke execute on function erp.save_my_reminder_v1(jsonb, uuid, bigint)
  from public, anon, authenticated;
revoke execute on function erp.set_my_reminder_done_v1(uuid, boolean, uuid, bigint)
  from public, anon, authenticated;
revoke execute on function erp.cancel_my_reminder_v1(uuid, text, uuid, bigint)
  from public, anon, authenticated;
revoke execute on function erp.guard_manual_reminder_write()
  from public, anon, authenticated;
revoke execute on function erp.audit_manual_reminder_change()
  from public, anon, authenticated;

grant execute on function erp.require_manual_reminder_actor() to service_role;
grant execute on function erp.list_my_reminders_v1(text, integer) to service_role;
grant execute on function erp.save_my_reminder_v1(jsonb, uuid, bigint) to service_role;
grant execute on function erp.set_my_reminder_done_v1(uuid, boolean, uuid, bigint)
  to service_role;
grant execute on function erp.cancel_my_reminder_v1(uuid, text, uuid, bigint)
  to service_role;
grant execute on function erp.guard_manual_reminder_write() to service_role;
grant execute on function erp.audit_manual_reminder_change() to service_role;

comment on table erp.manual_reminders is
  'Own-user manual reminders. V1 has no cross-user assignment, delivery scheduler, automatic business triggers, or hard delete.';
comment on function public.erp_list_my_reminders_v1(text, integer) is
  'Lists only the authenticated internal user own reminders; ACTIVE hides cancelled rows.';
comment on function public.erp_save_my_reminder_v1(jsonb, uuid, bigint) is
  'Creates or edits an OPEN own-user reminder with idempotency and optimistic locking.';
comment on function public.erp_set_my_reminder_done_v1(uuid, boolean, uuid, bigint) is
  'Completes or reopens an own-user reminder with idempotency and optimistic locking.';
comment on function public.erp_cancel_my_reminder_v1(uuid, text, uuid, bigint) is
  'Cancels without deleting an own-user reminder; cancellation is terminal and reasoned.';

notify pgrst, 'reload schema';

commit;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260830190955','erp_v2_6_13_manual_reminders_v1',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260830190955 erp_v2_6_13_manual_reminders_v1

-- BEGIN PLATFORM MIGRATION 20260831031520 manual_reminders_v1_acl_hardening
-- ERP Garment v2.6.13a
-- Forward-only hardening for the already-installed own-user reminder contract.
-- No reminder data or public facade signature is changed.

begin;

set local lock_timeout = '10s';
set local statement_timeout = '120s';

do $migration_guard$
declare
  v_marker regprocedure := to_regprocedure(
    'erp.manual_reminders_v1_acl_hardening_marker()'
  );
  v_definition_aggregate text;
  v_stable_definition_aggregate text;
begin
  if to_regclass('erp.manual_reminders') is null
     or to_regprocedure('erp.guard_manual_reminder_write()') is null
     or to_regprocedure('erp.bump_row_version()') is null
     or to_regprocedure('erp.audit_manual_reminder_change()') is null
     or to_regprocedure('erp.require_manual_reminder_actor()') is null
     or to_regprocedure('erp.list_my_reminders_v1(text,integer)') is null
     or to_regprocedure('erp.save_my_reminder_v1(jsonb,uuid,bigint)') is null
     or to_regprocedure('erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)') is null
     or to_regprocedure('erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)') is null
     or to_regprocedure('public.erp_list_my_reminders_v1(text,integer)') is null
     or to_regprocedure('public.erp_save_my_reminder_v1(jsonb,uuid,bigint)') is null
     or to_regprocedure('public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)') is null
     or to_regprocedure('public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)') is null then
    raise exception 'Reminder ACL hardening requires the complete ERP v2.6.13 reminder contract';
  end if;

  if has_schema_privilege('anon','erp','CREATE')
     or has_schema_privilege('authenticated','erp','CREATE')
     or has_schema_privilege('service_role','erp','CREATE')
     or has_schema_privilege('anon','public','CREATE')
     or has_schema_privilege('authenticated','public','CREATE')
     or has_schema_privilege('service_role','public','CREATE')
     or has_schema_privilege('anon','auth','CREATE')
     or has_schema_privilege('authenticated','auth','CREATE')
     or has_schema_privilege('service_role','auth','CREATE')
     or has_schema_privilege('anon','extensions','CREATE')
     or has_schema_privilege('authenticated','extensions','CREATE')
     or has_schema_privilege('service_role','extensions','CREATE') then
    raise exception 'Untrusted API roles must not CREATE in a reminder SECURITY DEFINER search_path schema';
  end if;

  select md5(string_agg(e.signature||':'||md5(pg_get_functiondef(
           to_regprocedure(e.signature))),E'\n' order by e.signature))
  into v_definition_aggregate
  from (values
    ('erp.guard_manual_reminder_write()'),
    ('erp.audit_manual_reminder_change()'),
    ('erp.require_manual_reminder_actor()'),
    ('erp.list_my_reminders_v1(text,integer)'),
    ('erp.save_my_reminder_v1(jsonb,uuid,bigint)'),
    ('erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
    ('erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)'),
    ('public.erp_list_my_reminders_v1(text,integer)'),
    ('public.erp_save_my_reminder_v1(jsonb,uuid,bigint)'),
    ('public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
    ('public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)')
  ) e(signature);

  -- Optimistic locking and append-only audit are part of the reminder write
  -- contract. Pin all trigger routes, including no-WHEN/no-argument shape,
  -- and the shared row-version helper before either a fresh hardening or replay.
  if (select p.proowner<>to_regrole('postgres')::oid
             or p.prosecdef
             or p.provolatile<>'v'::"char"
             or p.proconfig is distinct from
                array['search_path=erp, public, pg_temp']::text[]
             or md5(pg_get_functiondef(p.oid)) is distinct from
                'c53b58206389af747279e6397c258acd'
      from pg_proc p where p.oid='erp.bump_row_version()'::regprocedure)
     or exists (
       select 1
       from pg_proc p,
            lateral aclexplode(coalesce(p.proacl,
              acldefault('f',p.proowner))) a
       where p.oid='erp.bump_row_version()'::regprocedure
         and (a.is_grantable or a.grantee<>p.proowner
              or a.privilege_type<>'EXECUTE')
     )
     or (select count(*) from pg_trigger t
         where t.tgrelid='erp.manual_reminders'::regclass
           and not t.tgisinternal)<>3
     or exists (
       select 1
       from (values
         ('trg_00_guard_manual_reminder_write',
           'erp.guard_manual_reminder_write()'::regprocedure,
           'ea0d7ed5b4571688f8b421b5cf2d9747'),
         ('trg_01_bump_manual_reminder_version',
           'erp.bump_row_version()'::regprocedure,
           '56a244850f61e92a5d9da1770ebac281'),
         ('trg_90_audit_manual_reminder',
           'erp.audit_manual_reminder_change()'::regprocedure,
           '59b83ca7eb05fa3c21cf63e583e81bd8')
       ) e(tgname,tgfoid,definition_md5)
       where not exists (
         select 1 from pg_trigger t
         where t.tgrelid='erp.manual_reminders'::regclass
           and t.tgname=e.tgname and t.tgfoid=e.tgfoid
           and not t.tgisinternal and t.tgenabled='O'
           and t.tgqual is null and t.tgnargs=0
           and md5(pg_get_triggerdef(t.oid,true))=e.definition_md5
       )
     ) then
    raise exception 'Reminder audit/version trigger or bump helper identity drifted';
  end if;

  select md5(string_agg(e.signature||':'||md5(pg_get_functiondef(
           to_regprocedure(e.signature))),E'\n' order by e.signature))
  into v_stable_definition_aggregate
  from (values
    ('erp.audit_manual_reminder_change()'),
    ('erp.require_manual_reminder_actor()'),
    ('erp.list_my_reminders_v1(text,integer)'),
    ('erp.save_my_reminder_v1(jsonb,uuid,bigint)'),
    ('erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
    ('erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)'),
    ('public.erp_list_my_reminders_v1(text,integer)'),
    ('public.erp_save_my_reminder_v1(jsonb,uuid,bigint)'),
    ('public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
    ('public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)')
  ) e(signature);

  if v_marker is null then
    if v_definition_aggregate is distinct from
         '28cd9257bf921cf769ca5b1752533e1c'
       or (select p.proowner<>to_regrole('postgres')::oid
                    or p.prosecdef
                    or p.provolatile<>'v'::"char"
                    or p.proconfig is distinct from
                       array['search_path=erp, public, pg_temp']::text[]
           from pg_proc p
           where p.oid='erp.guard_manual_reminder_write()'::regprocedure)
       or not has_table_privilege('service_role','erp.manual_reminders','SELECT')
       or not has_table_privilege('service_role','erp.manual_reminders','INSERT')
       or not has_table_privilege('service_role','erp.manual_reminders','UPDATE')
       or not has_table_privilege('service_role','erp.manual_reminders','DELETE')
       or not has_table_privilege('service_role','erp.manual_reminders','TRUNCATE')
       or has_table_privilege('anon','erp.manual_reminders','SELECT')
       or has_table_privilege('authenticated','erp.manual_reminders','SELECT') then
      raise exception 'Reminder v2.6.13 baseline drifted; refusing partial ACL hardening';
    end if;
  else
    if position('ERP_V2_6_13A_REMINDER_RPC_ONLY_V1' in
         pg_get_functiondef(v_marker))=0
       or v_stable_definition_aggregate is distinct from
          '514f765a5153d8fda88fcd79f662a283'
       or md5(pg_get_functiondef(
          'erp.guard_manual_reminder_write()'::regprocedure)) is distinct from
          '63d58dca7617907c5547bdb71d111832'
       or position('current_user <> ''postgres''' in pg_get_functiondef(
         'erp.guard_manual_reminder_write()'::regprocedure))=0
       or not (select c.relrowsecurity from pg_class c
               where c.oid='erp.manual_reminders'::regclass)
       or (select c.relowner<>to_regrole('postgres')::oid
           from pg_class c where c.oid='erp.manual_reminders'::regclass)
       or not has_table_privilege('service_role','erp.manual_reminders','SELECT')
       or has_table_privilege('service_role','erp.manual_reminders','INSERT')
       or has_table_privilege('service_role','erp.manual_reminders','UPDATE')
       or has_table_privilege('service_role','erp.manual_reminders','DELETE')
       or has_table_privilege('service_role','erp.manual_reminders','TRUNCATE')
       or has_table_privilege('service_role','erp.manual_reminders','REFERENCES')
       or has_table_privilege('service_role','erp.manual_reminders','TRIGGER')
       or has_table_privilege('anon','erp.manual_reminders','SELECT')
       or has_table_privilege('authenticated','erp.manual_reminders','SELECT')
       or exists (
         select 1
         from pg_class c,
              lateral aclexplode(coalesce(c.relacl,
                acldefault('r',c.relowner))) a
         where c.oid='erp.manual_reminders'::regclass
           and (
             a.is_grantable
             or a.grantee not in (c.relowner,to_regrole('service_role')::oid)
             or (a.grantee=to_regrole('service_role')::oid
                 and a.privilege_type<>'SELECT')
           )
       )
       or exists (
         select 1
         from (values
           ('erp.guard_manual_reminder_write()'),
           ('erp.audit_manual_reminder_change()'),
           ('erp.require_manual_reminder_actor()'),
           ('erp.list_my_reminders_v1(text,integer)'),
           ('erp.save_my_reminder_v1(jsonb,uuid,bigint)'),
           ('erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
           ('erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)')
         ) e(signature)
         join pg_proc p on p.oid=to_regprocedure(e.signature)
         where p.proowner<>to_regrole('postgres')::oid
            or has_function_privilege('anon',p.oid,'EXECUTE')
            or has_function_privilege('authenticated',p.oid,'EXECUTE')
            or has_function_privilege('service_role',p.oid,'EXECUTE')
            or exists (
              select 1 from aclexplode(coalesce(p.proacl,
                acldefault('f',p.proowner))) a
              where a.is_grantable or a.grantee<>p.proowner
                 or a.privilege_type<>'EXECUTE'
            )
       )
       or exists (
         select 1
         from (values
           ('public.erp_list_my_reminders_v1(text,integer)'),
           ('public.erp_save_my_reminder_v1(jsonb,uuid,bigint)'),
           ('public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
           ('public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)')
         ) e(signature)
         join pg_proc p on p.oid=to_regprocedure(e.signature)
         where p.proowner<>to_regrole('postgres')::oid
            or not p.prosecdef
            or has_function_privilege('anon',p.oid,'EXECUTE')
            or not has_function_privilege('authenticated',p.oid,'EXECUTE')
            or not has_function_privilege('service_role',p.oid,'EXECUTE')
            or exists (
              select 1 from aclexplode(coalesce(p.proacl,
                acldefault('f',p.proowner))) a
              where a.is_grantable
                 or a.privilege_type<>'EXECUTE'
                 or a.grantee not in (
                   p.proowner,to_regrole('authenticated')::oid,
                   to_regrole('service_role')::oid
                 )
            )
       )
       or (select p.proowner<>to_regrole('postgres')::oid
                  or p.prosecdef
                  or p.provolatile<>'i'::"char"
                  or p.proconfig is distinct from
                     array['search_path=pg_catalog, pg_temp']::text[]
           from pg_proc p where p.oid=v_marker)
       or exists (
         select 1
         from pg_proc p,
              lateral aclexplode(coalesce(p.proacl,
                acldefault('f',p.proowner))) a
         where p.oid=v_marker
           and (a.is_grantable or a.grantee<>p.proowner
                or a.privilege_type<>'EXECUTE')
       ) then
      raise exception 'Reminder v2.6.13a marker exists but hardened shape drifted';
    end if;
    return;
  end if;
end;
$migration_guard$;

create or replace function erp.guard_manual_reminder_write()
returns trigger
language plpgsql
security invoker
set search_path = erp, public, pg_temp
as $function$
begin
  if tg_op = 'DELETE' then
    raise exception 'Manual reminders cannot be deleted; use erp_cancel_my_reminder_v1';
  end if;

  -- A custom GUC is only routing context, never authority. Browser/API roles,
  -- including service_role, cannot authorize direct table DML by spoofing it.
  if current_user <> 'postgres'
     or current_setting('app.manual_reminder_write', true) is distinct from 'on' then
    raise exception 'Manual reminders are write-protected; use the reminder RPC facade';
  end if;

  if tg_op = 'UPDATE' then
    if (new.id, new.owner_user_id, new.created_at, new.created_by)
       is distinct from
       (old.id, old.owner_user_id, old.created_at, old.created_by) then
      raise exception 'Reminder identity, owner, and creation facts are immutable';
    end if;
    if old.status = 'CANCELLED' then
      raise exception 'Cancelled reminders are terminal';
    end if;
  end if;

  return new;
end;
$function$;

alter function erp.guard_manual_reminder_write() owner to postgres;
alter function erp.guard_manual_reminder_write() security invoker;

alter table erp.manual_reminders enable row level security;

revoke all on table erp.manual_reminders
  from public, anon, authenticated, service_role;
grant select on table erp.manual_reminders to service_role;

revoke all on function erp.guard_manual_reminder_write()
  from public, anon, authenticated, service_role;
revoke all on function erp.audit_manual_reminder_change()
  from public, anon, authenticated, service_role;
revoke all on function erp.require_manual_reminder_actor()
  from public, anon, authenticated, service_role;
revoke all on function erp.list_my_reminders_v1(text,integer)
  from public, anon, authenticated, service_role;
revoke all on function erp.save_my_reminder_v1(jsonb,uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)
  from public, anon, authenticated, service_role;

-- Reassert the narrow browser surface exactly. The private implementations
-- execute as postgres through these SECURITY DEFINER facades.
revoke all on function public.erp_list_my_reminders_v1(text,integer)
  from public, anon, authenticated, service_role;
revoke all on function public.erp_save_my_reminder_v1(jsonb,uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)
  from public, anon, authenticated, service_role;

grant execute on function public.erp_list_my_reminders_v1(text,integer)
  to authenticated, service_role;
grant execute on function public.erp_save_my_reminder_v1(jsonb,uuid,bigint)
  to authenticated, service_role;
grant execute on function public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)
  to authenticated, service_role;
grant execute on function public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)
  to authenticated, service_role;

comment on table erp.manual_reminders is
  'Own-user manual reminders. Writes are RPC-only; service_role has SELECT only and no TRUNCATE/DML authority.';

create or replace function erp.manual_reminders_v1_acl_hardening_marker()
returns text
language sql
immutable
set search_path = pg_catalog, pg_temp
as $function$
  select 'ERP_V2_6_13A_REMINDER_RPC_ONLY_V1'::text
$function$;

revoke all on function erp.manual_reminders_v1_acl_hardening_marker()
  from public, anon, authenticated, service_role;

notify pgrst, 'reload schema';

commit;
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260831031520','manual_reminders_v1_acl_hardening',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260831031520 manual_reminders_v1_acl_hardening

-- BEGIN PLATFORM MIGRATION 20260831032911 erp_v2_6_13a_manual_reminders_acl_hardening
-- ERP Garment v2.6.13a
-- Forward-only hardening for the already-installed own-user reminder contract.
-- No reminder data or public facade signature is changed.

set local lock_timeout = '10s';
set local statement_timeout = '120s';

do $migration_guard$
declare
  v_marker regprocedure := to_regprocedure(
    'erp.manual_reminders_v1_acl_hardening_marker()'
  );
  v_definition_aggregate text;
  v_stable_definition_aggregate text;
begin
  if to_regclass('erp.manual_reminders') is null
     or to_regprocedure('erp.guard_manual_reminder_write()') is null
     or to_regprocedure('erp.bump_row_version()') is null
     or to_regprocedure('erp.audit_manual_reminder_change()') is null
     or to_regprocedure('erp.require_manual_reminder_actor()') is null
     or to_regprocedure('erp.list_my_reminders_v1(text,integer)') is null
     or to_regprocedure('erp.save_my_reminder_v1(jsonb,uuid,bigint)') is null
     or to_regprocedure('erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)') is null
     or to_regprocedure('erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)') is null
     or to_regprocedure('public.erp_list_my_reminders_v1(text,integer)') is null
     or to_regprocedure('public.erp_save_my_reminder_v1(jsonb,uuid,bigint)') is null
     or to_regprocedure('public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)') is null
     or to_regprocedure('public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)') is null then
    raise exception 'Reminder ACL hardening requires the complete ERP v2.6.13 reminder contract';
  end if;

  if has_schema_privilege('anon','erp','CREATE')
     or has_schema_privilege('authenticated','erp','CREATE')
     or has_schema_privilege('service_role','erp','CREATE')
     or has_schema_privilege('anon','public','CREATE')
     or has_schema_privilege('authenticated','public','CREATE')
     or has_schema_privilege('service_role','public','CREATE')
     or has_schema_privilege('anon','auth','CREATE')
     or has_schema_privilege('authenticated','auth','CREATE')
     or has_schema_privilege('service_role','auth','CREATE')
     or has_schema_privilege('anon','extensions','CREATE')
     or has_schema_privilege('authenticated','extensions','CREATE')
     or has_schema_privilege('service_role','extensions','CREATE') then
    raise exception 'Untrusted API roles must not CREATE in a reminder SECURITY DEFINER search_path schema';
  end if;

  select md5(string_agg(e.signature||':'||md5(pg_get_functiondef(
           to_regprocedure(e.signature))),E'\n' order by e.signature))
  into v_definition_aggregate
  from (values
    ('erp.guard_manual_reminder_write()'),
    ('erp.audit_manual_reminder_change()'),
    ('erp.require_manual_reminder_actor()'),
    ('erp.list_my_reminders_v1(text,integer)'),
    ('erp.save_my_reminder_v1(jsonb,uuid,bigint)'),
    ('erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
    ('erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)'),
    ('public.erp_list_my_reminders_v1(text,integer)'),
    ('public.erp_save_my_reminder_v1(jsonb,uuid,bigint)'),
    ('public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
    ('public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)')
  ) e(signature);

  -- Optimistic locking and append-only audit are part of the reminder write
  -- contract. Pin all trigger routes, including no-WHEN/no-argument shape,
  -- and the shared row-version helper before either a fresh hardening or replay.
  if (select p.proowner<>to_regrole('postgres')::oid
             or p.prosecdef
             or p.provolatile<>'v'::"char"
             or p.proconfig is distinct from
                array['search_path=erp, public, pg_temp']::text[]
             or md5(pg_get_functiondef(p.oid)) is distinct from
                'c53b58206389af747279e6397c258acd'
      from pg_proc p where p.oid='erp.bump_row_version()'::regprocedure)
     or exists (
       select 1
       from pg_proc p,
            lateral aclexplode(coalesce(p.proacl,
              acldefault('f',p.proowner))) a
       where p.oid='erp.bump_row_version()'::regprocedure
         and (a.is_grantable or a.grantee<>p.proowner
              or a.privilege_type<>'EXECUTE')
     )
     or (select count(*) from pg_trigger t
         where t.tgrelid='erp.manual_reminders'::regclass
           and not t.tgisinternal)<>3
     or exists (
       select 1
       from (values
         ('trg_00_guard_manual_reminder_write',
           'erp.guard_manual_reminder_write()'::regprocedure,
           'ea0d7ed5b4571688f8b421b5cf2d9747'),
         ('trg_01_bump_manual_reminder_version',
           'erp.bump_row_version()'::regprocedure,
           '56a244850f61e92a5d9da1770ebac281'),
         ('trg_90_audit_manual_reminder',
           'erp.audit_manual_reminder_change()'::regprocedure,
           '59b83ca7eb05fa3c21cf63e583e81bd8')
       ) e(tgname,tgfoid,definition_md5)
       where not exists (
         select 1 from pg_trigger t
         where t.tgrelid='erp.manual_reminders'::regclass
           and t.tgname=e.tgname and t.tgfoid=e.tgfoid
           and not t.tgisinternal and t.tgenabled='O'
           and t.tgqual is null and t.tgnargs=0
           and md5(pg_get_triggerdef(t.oid,true))=e.definition_md5
       )
     ) then
    raise exception 'Reminder audit/version trigger or bump helper identity drifted';
  end if;

  select md5(string_agg(e.signature||':'||md5(pg_get_functiondef(
           to_regprocedure(e.signature))),E'\n' order by e.signature))
  into v_stable_definition_aggregate
  from (values
    ('erp.audit_manual_reminder_change()'),
    ('erp.require_manual_reminder_actor()'),
    ('erp.list_my_reminders_v1(text,integer)'),
    ('erp.save_my_reminder_v1(jsonb,uuid,bigint)'),
    ('erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
    ('erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)'),
    ('public.erp_list_my_reminders_v1(text,integer)'),
    ('public.erp_save_my_reminder_v1(jsonb,uuid,bigint)'),
    ('public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
    ('public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)')
  ) e(signature);

  if v_marker is null then
    if v_definition_aggregate is distinct from
         '28cd9257bf921cf769ca5b1752533e1c'
       or (select p.proowner<>to_regrole('postgres')::oid
                    or p.prosecdef
                    or p.provolatile<>'v'::"char"
                    or p.proconfig is distinct from
                       array['search_path=erp, public, pg_temp']::text[]
           from pg_proc p
           where p.oid='erp.guard_manual_reminder_write()'::regprocedure)
       or not has_table_privilege('service_role','erp.manual_reminders','SELECT')
       or not has_table_privilege('service_role','erp.manual_reminders','INSERT')
       or not has_table_privilege('service_role','erp.manual_reminders','UPDATE')
       or not has_table_privilege('service_role','erp.manual_reminders','DELETE')
       or not has_table_privilege('service_role','erp.manual_reminders','TRUNCATE')
       or has_table_privilege('anon','erp.manual_reminders','SELECT')
       or has_table_privilege('authenticated','erp.manual_reminders','SELECT') then
      raise exception 'Reminder v2.6.13 baseline drifted; refusing partial ACL hardening';
    end if;
  else
    if position('ERP_V2_6_13A_REMINDER_RPC_ONLY_V1' in
         pg_get_functiondef(v_marker))=0
       or v_stable_definition_aggregate is distinct from
          '514f765a5153d8fda88fcd79f662a283'
       or md5(pg_get_functiondef(
          'erp.guard_manual_reminder_write()'::regprocedure)) is distinct from
          '63d58dca7617907c5547bdb71d111832'
       or position('current_user <> ''postgres''' in pg_get_functiondef(
         'erp.guard_manual_reminder_write()'::regprocedure))=0
       or not (select c.relrowsecurity from pg_class c
               where c.oid='erp.manual_reminders'::regclass)
       or (select c.relowner<>to_regrole('postgres')::oid
           from pg_class c where c.oid='erp.manual_reminders'::regclass)
       or not has_table_privilege('service_role','erp.manual_reminders','SELECT')
       or has_table_privilege('service_role','erp.manual_reminders','INSERT')
       or has_table_privilege('service_role','erp.manual_reminders','UPDATE')
       or has_table_privilege('service_role','erp.manual_reminders','DELETE')
       or has_table_privilege('service_role','erp.manual_reminders','TRUNCATE')
       or has_table_privilege('service_role','erp.manual_reminders','REFERENCES')
       or has_table_privilege('service_role','erp.manual_reminders','TRIGGER')
       or has_table_privilege('anon','erp.manual_reminders','SELECT')
       or has_table_privilege('authenticated','erp.manual_reminders','SELECT')
       or exists (
         select 1
         from pg_class c,
              lateral aclexplode(coalesce(c.relacl,
                acldefault('r',c.relowner))) a
         where c.oid='erp.manual_reminders'::regclass
           and (
             a.is_grantable
             or a.grantee not in (c.relowner,to_regrole('service_role')::oid)
             or (a.grantee=to_regrole('service_role')::oid
                 and a.privilege_type<>'SELECT')
           )
       )
       or exists (
         select 1
         from (values
           ('erp.guard_manual_reminder_write()'),
           ('erp.audit_manual_reminder_change()'),
           ('erp.require_manual_reminder_actor()'),
           ('erp.list_my_reminders_v1(text,integer)'),
           ('erp.save_my_reminder_v1(jsonb,uuid,bigint)'),
           ('erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
           ('erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)')
         ) e(signature)
         join pg_proc p on p.oid=to_regprocedure(e.signature)
         where p.proowner<>to_regrole('postgres')::oid
            or has_function_privilege('anon',p.oid,'EXECUTE')
            or has_function_privilege('authenticated',p.oid,'EXECUTE')
            or has_function_privilege('service_role',p.oid,'EXECUTE')
            or exists (
              select 1 from aclexplode(coalesce(p.proacl,
                acldefault('f',p.proowner))) a
              where a.is_grantable or a.grantee<>p.proowner
                 or a.privilege_type<>'EXECUTE'
            )
       )
       or exists (
         select 1
         from (values
           ('public.erp_list_my_reminders_v1(text,integer)'),
           ('public.erp_save_my_reminder_v1(jsonb,uuid,bigint)'),
           ('public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)'),
           ('public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)')
         ) e(signature)
         join pg_proc p on p.oid=to_regprocedure(e.signature)
         where p.proowner<>to_regrole('postgres')::oid
            or not p.prosecdef
            or has_function_privilege('anon',p.oid,'EXECUTE')
            or not has_function_privilege('authenticated',p.oid,'EXECUTE')
            or not has_function_privilege('service_role',p.oid,'EXECUTE')
            or exists (
              select 1 from aclexplode(coalesce(p.proacl,
                acldefault('f',p.proowner))) a
              where a.is_grantable
                 or a.privilege_type<>'EXECUTE'
                 or a.grantee not in (
                   p.proowner,to_regrole('authenticated')::oid,
                   to_regrole('service_role')::oid
                 )
            )
       )
       or (select p.proowner<>to_regrole('postgres')::oid
                  or p.prosecdef
                  or p.provolatile<>'i'::"char"
                  or p.proconfig is distinct from
                     array['search_path=pg_catalog, pg_temp']::text[]
           from pg_proc p where p.oid=v_marker)
       or exists (
         select 1
         from pg_proc p,
              lateral aclexplode(coalesce(p.proacl,
                acldefault('f',p.proowner))) a
         where p.oid=v_marker
           and (a.is_grantable or a.grantee<>p.proowner
                or a.privilege_type<>'EXECUTE')
       ) then
      raise exception 'Reminder v2.6.13a marker exists but hardened shape drifted';
    end if;
    return;
  end if;
end;
$migration_guard$;

create or replace function erp.guard_manual_reminder_write()
returns trigger
language plpgsql
security invoker
set search_path = erp, public, pg_temp
as $function$
begin
  if tg_op = 'DELETE' then
    raise exception 'Manual reminders cannot be deleted; use erp_cancel_my_reminder_v1';
  end if;

  -- A custom GUC is only routing context, never authority. Browser/API roles,
  -- including service_role, cannot authorize direct table DML by spoofing it.
  if current_user <> 'postgres'
     or current_setting('app.manual_reminder_write', true) is distinct from 'on' then
    raise exception 'Manual reminders are write-protected; use the reminder RPC facade';
  end if;

  if tg_op = 'UPDATE' then
    if (new.id, new.owner_user_id, new.created_at, new.created_by)
       is distinct from
       (old.id, old.owner_user_id, old.created_at, old.created_by) then
      raise exception 'Reminder identity, owner, and creation facts are immutable';
    end if;
    if old.status = 'CANCELLED' then
      raise exception 'Cancelled reminders are terminal';
    end if;
  end if;

  return new;
end;
$function$;

alter function erp.guard_manual_reminder_write() owner to postgres;
alter function erp.guard_manual_reminder_write() security invoker;

alter table erp.manual_reminders enable row level security;

revoke all on table erp.manual_reminders
  from public, anon, authenticated, service_role;
grant select on table erp.manual_reminders to service_role;

revoke all on function erp.guard_manual_reminder_write()
  from public, anon, authenticated, service_role;
revoke all on function erp.audit_manual_reminder_change()
  from public, anon, authenticated, service_role;
revoke all on function erp.require_manual_reminder_actor()
  from public, anon, authenticated, service_role;
revoke all on function erp.list_my_reminders_v1(text,integer)
  from public, anon, authenticated, service_role;
revoke all on function erp.save_my_reminder_v1(jsonb,uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function erp.set_my_reminder_done_v1(uuid,boolean,uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function erp.cancel_my_reminder_v1(uuid,text,uuid,bigint)
  from public, anon, authenticated, service_role;

-- Reassert the narrow browser surface exactly. The private implementations
-- execute as postgres through these SECURITY DEFINER facades.
revoke all on function public.erp_list_my_reminders_v1(text,integer)
  from public, anon, authenticated, service_role;
revoke all on function public.erp_save_my_reminder_v1(jsonb,uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)
  from public, anon, authenticated, service_role;

grant execute on function public.erp_list_my_reminders_v1(text,integer)
  to authenticated, service_role;
grant execute on function public.erp_save_my_reminder_v1(jsonb,uuid,bigint)
  to authenticated, service_role;
grant execute on function public.erp_set_my_reminder_done_v1(uuid,boolean,uuid,bigint)
  to authenticated, service_role;
grant execute on function public.erp_cancel_my_reminder_v1(uuid,text,uuid,bigint)
  to authenticated, service_role;

comment on table erp.manual_reminders is
  'Own-user manual reminders. Writes are RPC-only; service_role has SELECT only and no TRUNCATE/DML authority.';

create or replace function erp.manual_reminders_v1_acl_hardening_marker()
returns text
language sql
immutable
set search_path = pg_catalog, pg_temp
as $function$
  select 'ERP_V2_6_13A_REMINDER_RPC_ONLY_V1'::text
$function$;

revoke all on function erp.manual_reminders_v1_acl_hardening_marker()
  from public, anon, authenticated, service_role;

notify pgrst, 'reload schema';
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260831032911','erp_v2_6_13a_manual_reminders_acl_hardening',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260831032911 erp_v2_6_13a_manual_reminders_acl_hardening

-- BEGIN PLATFORM MIGRATION 20260831032949 erp_v2_6_13b_auth_profile_facade_tracking
-- ERP Garment v2.6.13b
-- Forward-only source tracking for the v2.6.11a UAT Auth self-profile facade.
--
-- The original v2.6.11a closure was applied manually and is immutable evidence.
-- This focused delta adopts an already-exact facade or creates it when wholly
-- absent. Any partial or drifted object fails before DDL. The operator must
-- externally verify project ref siimvrusnzxexizpyoib; PostgreSQL cannot prove a
-- Supabase project ref or the Data API exposed-schema allowlist. The latter must
-- remain public + graphql_public; erp must stay unexposed. Canonical project
-- vlxdhpkjeevubjxexnfo is forbidden.

set local application_name = 'erp_v2_6_13b_auth_profile_facade_tracking';
set local lock_timeout = '10s';
set local statement_timeout = '120s';
set local search_path = pg_catalog, public, pg_temp;

do $migration_guard$
declare
  v_view regclass := to_regclass('public.v_erp_my_profile');
  v_columns text[];
  v_types text[];
  v_not_null boolean[];
begin
  if current_user <> 'postgres' then
    raise exception 'AUTH_PROFILE_TARGET_GUARD: migration must run as postgres';
  end if;

  if not pg_try_advisory_xact_lock(2613, 20260830) then
    raise exception 'AUTH_PROFILE_EXECUTION_GUARD: another facade migration or acceptance test is active';
  end if;

  if current_setting('server_version_num')::integer < 150000 then
    raise exception 'AUTH_PROFILE_TARGET_GUARD: SECURITY INVOKER views require PostgreSQL 15 or newer';
  end if;

  if to_regrole('anon') is null
     or to_regrole('authenticated') is null
     or to_regrole('service_role') is null
     or to_regrole('postgres') is null then
    raise exception 'AUTH_PROFILE_TARGET_GUARD: required Supabase API roles are missing';
  end if;

  if to_regnamespace('public') is null
     or to_regnamespace('erp') is null
     or to_regnamespace('auth') is null
     or to_regnamespace('extensions') is null
     or to_regclass('supabase_migrations.schema_migrations') is null
     or to_regclass('erp.schema_migrations') is null
     or to_regclass('erp.system_release_info') is null
     or to_regclass('erp.app_users') is null
     or to_regprocedure('auth.uid()') is null then
    raise exception 'AUTH_PROFILE_TARGET_GUARD: required UAT schemas, history, table, or auth.uid() are missing';
  end if;

  -- This is a UAT lineage guard, not a substitute for the external project-ref
  -- allowlist. Avoid total migration counts because later forward deltas are valid.
  if not exists (
       select 1
       from supabase_migrations.schema_migrations
       where version = '20260826112217' and name = 'compact_replay_001'
     )
     or not exists (
       select 1
       from supabase_migrations.schema_migrations
       where version = '20260830140645'
         and name = 'erp_v2_6_12_attendance_and_stock_explainability'
     )
     or not exists (
       select 1
       from supabase_migrations.schema_migrations
       where version = '20260830190955'
         and name = 'erp_v2_6_13_manual_reminders_v1'
     )
     or (select count(*)
         from erp.schema_migrations
         where version = 'v2.6.11a'
           and description = 'UAT phase-0 public self-profile facade and direct legacy RPC closure'
           and installed_at is not null) <> 1
     or not exists (
       select 1
       from erp.system_release_info
       where singleton_id = 1
         and position('[v2.6.11a/UAT_PRECONNECT]' in coalesce(notes, '')) > 0
     ) then
    raise exception 'AUTH_PROFILE_TARGET_GUARD: expected the verified ERP Enteng UAT lineage; externally verify siimvrusnzxexizpyoib';
  end if;

  if exists (
       select 1
       from (values ('anon'),('authenticated'),('service_role')) r(role_name)
       cross join (values ('erp'),('public'),('auth'),('extensions')) s(schema_name)
       where has_schema_privilege(r.role_name, s.schema_name, 'CREATE')
     )
     or exists (
       select 1
       from pg_namespace n
       cross join lateral aclexplode(
         coalesce(n.nspacl, acldefault('n', n.nspowner))
       ) a
       where n.nspname in ('erp','public','auth','extensions')
         and a.grantee = 0
         and a.privilege_type = 'CREATE'
     ) then
    raise exception 'AUTH_PROFILE_BASELINE_DRIFT: untrusted API roles may CREATE in a trusted schema';
  end if;

  if not has_schema_privilege('authenticated', 'public', 'USAGE')
     or not has_schema_privilege('authenticated', 'auth', 'USAGE')
     or not has_function_privilege('authenticated', 'auth.uid()', 'EXECUTE')
     or has_schema_privilege('anon', 'erp', 'USAGE') then
    raise exception 'AUTH_PROFILE_BASELINE_DRIFT: public/auth helper or private ERP schema boundary differs';
  end if;

  select
    array_agg(a.attname::text order by a.attnum),
    array_agg(format_type(a.atttypid, a.atttypmod) order by a.attnum),
    array_agg(a.attnotnull order by a.attnum)
  into v_columns, v_types, v_not_null
  from pg_attribute a
  where a.attrelid = 'erp.app_users'::regclass
    and a.attnum > 0
    and not a.attisdropped;

  if v_columns is distinct from array[
       'id','auth_user_id','full_name','role','is_active',
       'created_at','updated_at','row_version'
     ]::text[]
     or v_types is distinct from array[
       'uuid','uuid','character varying(150)','character varying(20)','boolean',
       'timestamp with time zone','timestamp with time zone','bigint'
     ]::text[]
     or v_not_null is distinct from array[
       true,false,true,true,true,true,true,true
     ]::boolean[] then
    raise exception 'AUTH_PROFILE_BASELINE_DRIFT: erp.app_users column contract differs';
  end if;

  if not exists (
       select 1
       from pg_class c
       where c.oid = 'erp.app_users'::regclass
         and c.relkind = 'r'
         and c.relowner = to_regrole('postgres')::oid
         and c.relrowsecurity
         and not c.relforcerowsecurity
     )
     or not exists (
       select 1
       from pg_constraint c
       where c.conrelid = 'erp.app_users'::regclass
         and c.contype = 'u'
         and pg_get_constraintdef(c.oid, true) = 'UNIQUE (auth_user_id)'
     )
     or (select count(*) from pg_policy
         where polrelid = 'erp.app_users'::regclass) <> 1
     or not exists (
       select 1
       from pg_policy p
       where p.polrelid = 'erp.app_users'::regclass
         and p.polname = 'app_users_select_v262'
         and p.polcmd = 'r'
         and p.polpermissive
         and p.polroles = array[to_regrole('authenticated')::oid]
         and p.polwithcheck is null
         and md5(pg_get_expr(p.polqual, p.polrelid)) =
             'ce7c898347068ed07331b3af7c67e94f'
     ) then
    raise exception 'AUTH_PROFILE_BASELINE_DRIFT: erp.app_users owner, RLS, uniqueness, or policy differs';
  end if;

  -- Missing authenticated SELECT/ERP USAGE is an allowed all-or-none grant
  -- state and is normalized below. Any broader or foreign grant is drift.
  if exists (
       select 1
       from pg_class c
       cross join lateral aclexplode(
         coalesce(c.relacl, acldefault('r', c.relowner))
       ) a
       where c.oid = 'erp.app_users'::regclass
         and (
           a.is_grantable
           or a.grantee = 0
           or a.grantee = to_regrole('anon')::oid
           or (a.grantee = to_regrole('authenticated')::oid
               and a.privilege_type <> 'SELECT')
           or a.grantee not in (
             c.relowner,
             to_regrole('authenticated')::oid,
             to_regrole('service_role')::oid
           )
         )
     )
     or exists (
       select 1
       from pg_attribute a
       where a.attrelid = 'erp.app_users'::regclass
         and a.attnum > 0
         and not a.attisdropped
         and a.attacl is not null
     ) then
    raise exception 'AUTH_PROFILE_BASELINE_DRIFT: erp.app_users direct or column ACL differs';
  end if;

  if v_view is null then
    if to_regtype('public.v_erp_my_profile') is not null then
      raise exception 'AUTH_PROFILE_PARTIAL_INSTALL: profile relation is absent but its type name is occupied';
    end if;
  else
    select
      array_agg(a.attname::text order by a.attnum),
      array_agg(format_type(a.atttypid, a.atttypmod) order by a.attnum)
    into v_columns, v_types
    from pg_attribute a
    where a.attrelid = v_view
      and a.attnum > 0
      and not a.attisdropped;

    if not exists (
         select 1
         from pg_class c
         where c.oid = v_view
           and c.relkind = 'v'
           and c.relowner = to_regrole('postgres')::oid
           and coalesce(cardinality(c.reloptions), 0) = 3
           and c.reloptions @> array[
             'security_invoker=true',
             'security_barrier=true',
             'check_option=local'
           ]::text[]
       )
       or v_columns is distinct from array[
         'id','auth_user_id','full_name','role','is_active','row_version'
       ]::text[]
       or v_types is distinct from array[
         'uuid','uuid','character varying(150)','character varying(20)',
         'boolean','bigint'
       ]::text[]
       or not exists (
         select 1
         from information_schema.views v
         where v.table_schema = 'public'
           and v.table_name = 'v_erp_my_profile'
           and v.check_option = 'LOCAL'
       )
       or md5(pg_get_viewdef(v_view, true)) is distinct from
          'efd4feeaf2b1dac307638394d33c60c1'
       or obj_description(v_view, 'pg_class') is distinct from
          'Phase-0 Auth bootstrap facade. Returns only the authenticated user own ERP profile columns through explicit auth.uid filtering, SECURITY INVOKER, and SECURITY BARRIER. The erp schema must remain unexposed.'
       or not exists (
         select 1
         from pg_class c
         cross join lateral aclexplode(
           coalesce(c.relacl, acldefault('r', c.relowner))
         ) a
         where c.oid = v_view
           and a.grantee = to_regrole('authenticated')::oid
           and a.privilege_type = 'SELECT'
           and not a.is_grantable
       )
       or exists (
         select 1
         from pg_class c
         cross join lateral aclexplode(
           coalesce(c.relacl, acldefault('r', c.relowner))
         ) a
         where c.oid = v_view
           and (
             a.is_grantable
             or a.grantee not in (c.relowner, to_regrole('authenticated')::oid)
             or (a.grantee = to_regrole('authenticated')::oid
                 and a.privilege_type <> 'SELECT')
           )
       )
       or exists (
         select 1
         from pg_attribute a
         where a.attrelid = v_view
           and a.attnum > 0
           and not a.attisdropped
           and a.attacl is not null
       )
       or has_table_privilege('anon', v_view, 'SELECT')
       or has_table_privilege('service_role', v_view, 'SELECT')
       or has_table_privilege('authenticated', v_view, 'INSERT')
       or has_table_privilege('authenticated', v_view, 'UPDATE')
       or has_table_privilege('authenticated', v_view, 'DELETE') then
      raise exception 'AUTH_PROFILE_REPLAY_DRIFT: existing profile facade is not the exact audited v2.6.11a object';
    end if;
  end if;
end;
$migration_guard$;

-- Normalize only the privileges required by a SECURITY INVOKER facade. Keep
-- service_role's existing operational access to the private table unchanged.
revoke create on schema public, erp
  from public, anon, authenticated, service_role;
revoke all on schema erp from public, anon;
grant usage on schema public, erp to authenticated;

revoke all on table erp.app_users from public, anon, authenticated;
grant select on table erp.app_users to authenticated;

create or replace view public.v_erp_my_profile
with (security_invoker = true, security_barrier = true)
as
select
  u.id,
  u.auth_user_id,
  u.full_name,
  u.role,
  u.is_active,
  u.row_version
from erp.app_users u
where u.auth_user_id = (select auth.uid())
with local check option;

alter view public.v_erp_my_profile owner to postgres;

revoke all on public.v_erp_my_profile
  from public, anon, authenticated, service_role;
grant select on public.v_erp_my_profile to authenticated;

comment on view public.v_erp_my_profile is
  'Phase-0 Auth bootstrap facade. Returns only the authenticated user own ERP profile columns through explicit auth.uid filtering, SECURITY INVOKER, and SECURITY BARRIER. The erp schema must remain unexposed.';

do $self_check$
declare
  v_view regclass := to_regclass('public.v_erp_my_profile');
  v_columns text[];
  v_types text[];
begin
  if v_view is null then
    raise exception 'AUTH_PROFILE_SELF_CHECK: profile facade was not created';
  end if;

  select
    array_agg(a.attname::text order by a.attnum),
    array_agg(format_type(a.atttypid, a.atttypmod) order by a.attnum)
  into v_columns, v_types
  from pg_attribute a
  where a.attrelid = v_view
    and a.attnum > 0
    and not a.attisdropped;

  if not exists (
       select 1
       from pg_class c
       where c.oid = v_view
         and c.relkind = 'v'
         and c.relowner = to_regrole('postgres')::oid
         and coalesce(cardinality(c.reloptions), 0) = 3
         and c.reloptions @> array[
           'security_invoker=true',
           'security_barrier=true',
           'check_option=local'
         ]::text[]
     )
     or v_columns is distinct from array[
       'id','auth_user_id','full_name','role','is_active','row_version'
     ]::text[]
     or v_types is distinct from array[
       'uuid','uuid','character varying(150)','character varying(20)',
       'boolean','bigint'
     ]::text[]
     or md5(pg_get_viewdef(v_view, true)) is distinct from
        'efd4feeaf2b1dac307638394d33c60c1'
     or obj_description(v_view, 'pg_class') is distinct from
        'Phase-0 Auth bootstrap facade. Returns only the authenticated user own ERP profile columns through explicit auth.uid filtering, SECURITY INVOKER, and SECURITY BARRIER. The erp schema must remain unexposed.'
     or not exists (
       select 1
       from information_schema.views v
       where v.table_schema = 'public'
         and v.table_name = 'v_erp_my_profile'
         and v.check_option = 'LOCAL'
     )
     or not has_schema_privilege('authenticated', 'erp', 'USAGE')
     or has_schema_privilege('anon', 'erp', 'USAGE')
     or not has_table_privilege('authenticated', 'erp.app_users', 'SELECT')
     or has_table_privilege('authenticated', 'erp.app_users', 'INSERT')
     or has_table_privilege('authenticated', 'erp.app_users', 'UPDATE')
     or has_table_privilege('authenticated', 'erp.app_users', 'DELETE')
     or has_table_privilege('authenticated', 'erp.app_users', 'TRUNCATE')
     or has_table_privilege('anon', 'erp.app_users', 'SELECT')
     or not has_table_privilege('authenticated', v_view, 'SELECT')
     or has_table_privilege('anon', v_view, 'SELECT')
     or has_table_privilege('service_role', v_view, 'SELECT')
     or has_table_privilege('authenticated', v_view, 'INSERT')
     or has_table_privilege('authenticated', v_view, 'UPDATE')
     or has_table_privilege('authenticated', v_view, 'DELETE')
     or exists (
       select 1
       from pg_attribute a
       where a.attrelid = v_view
         and a.attnum > 0
         and not a.attisdropped
         and a.attacl is not null
     )
     or exists (
       select 1
       from pg_class c
       cross join lateral aclexplode(
         coalesce(c.relacl, acldefault('r', c.relowner))
       ) a
       where c.oid = v_view
         and (
           a.is_grantable
           or a.grantee not in (c.relowner, to_regrole('authenticated')::oid)
           or (a.grantee = to_regrole('authenticated')::oid
               and a.privilege_type <> 'SELECT')
         )
     ) then
    raise exception 'AUTH_PROFILE_SELF_CHECK: facade shape, filter, RLS reachability, or ACL differs';
  end if;
end;
$self_check$;

notify pgrst, 'reload schema';
insert into supabase_migrations.schema_migrations(version,name,statements)
values('20260831032949','erp_v2_6_13b_auth_profile_facade_tracking',array[]::text[])
on conflict(version) do update set name=excluded.name, statements=excluded.statements;
-- END PLATFORM MIGRATION 20260831032949 erp_v2_6_13b_auth_profile_facade_tracking

